/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ateneo.web;

import ateneo.ejb.AteneoLocal;
import ateneo.ejb.AteneoLocalHome;
import java.io.*;
import java.net.*;
import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.*;
import javax.servlet.http.*;
import utils.exceptions.WebServiceException;

/**
 *
 * @author benve
 */
public class DownloadServlet extends HttpServlet {
   
    /** 
    * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        try {
            OutputStream out = response.getOutputStream();

            byte[] file = lookupAteneoBean().downloadDocument(request.getParameter("ID"));

            response.setContentType("application/x-download");
            response.setHeader("Content-Disposition", "attachment; filename=" + request.getParameter("ID") + ".pdf");

            out.write(file);

            out.close();
        } catch (WebServiceException ex) {
            ex.printStackTrace();
        }
            
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }

    private AteneoLocal lookupAteneoBean() {
        try {
            Context c = new InitialContext();
            AteneoLocalHome rv = (AteneoLocalHome) c.lookup("java:comp/env/AteneoBean");
            return rv.create();
        } catch (NamingException ne) {
            java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        } catch (CreateException ce) {
            java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
            throw new RuntimeException(ce);
        }
    }
    // </editor-fold>
}
