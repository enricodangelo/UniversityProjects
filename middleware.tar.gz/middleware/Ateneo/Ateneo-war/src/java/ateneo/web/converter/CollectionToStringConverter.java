/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ateneo.web.converter;

import java.util.Collection;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import utils.Convert;

/**
 *
 * @author benve
 */
public class CollectionToStringConverter implements Converter {

    public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) throws ConverterException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getAsString(FacesContext arg0, UIComponent arg1, Object collection) throws ConverterException {
        String ret = "";
				
				ret = Convert.collectionToString((Collection)collection);

        return ret;
		}
}
