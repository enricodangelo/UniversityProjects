/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ateneo.web;

import ateneo.ejb.AteneoLocal;
import ateneo.ejb.AteneoLocalHome;
import java.io.*;
import java.net.*;

import java.util.Collection;
import java.util.Iterator;
import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.*;
import javax.servlet.http.*;
import utils.SearchDetails;
import utils.SearchResult;
import utils.exceptions.FinderCatalogException;
import utils.exceptions.WebServiceException;

/**
 *
 * @author benve
 */
public class adminServlet extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            AteneoLocal ateneo = lookupAteneoBean();


            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet adminServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet adminServlet at " + request.getContextPath() + "</h1>");
            out.println("<pre>");
            Collection catalog = ateneo.getCatalog();
            for (Iterator it = catalog.iterator(); it.hasNext();) {
                out.println(((SearchResult) it.next()).getDocID());

            }
            out.println("----------------------------------------------------------------------");
            String[] tmps = new String[1];
            tmps[0] = "fantastico";
            //tmps[0] = "Il mio titolo fantastico";
            String[] ciao = new String[1];
            ciao[0] = "";
            SearchDetails sd = new SearchDetails(ciao, tmps, tmps, -1, ciao, -1, tmps, 0);
            Collection documents = ateneo.searchDocuments(sd);
            for (Iterator it = documents.iterator(); it.hasNext();) {
                out.println(((SearchResult) it.next()).getDocID());

            }


            out.println("</pre>");
            out.println("</body>");
            out.println("</html>");

        } catch (WebServiceException ex) {
            ex.printStackTrace();
        } catch (FinderCatalogException ex) {
            ex.printStackTrace();
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }

    private AteneoLocal lookupAteneoBean() {
        try {
            Context c = new InitialContext();
            AteneoLocalHome rv = (AteneoLocalHome) c.lookup("java:comp/env/AteneoBean");
            return rv.create();
        } catch (NamingException ne) {
            java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        } catch (CreateException ce) {
            java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
            throw new RuntimeException(ce);
        }
    }
    // </editor-fold>
}
