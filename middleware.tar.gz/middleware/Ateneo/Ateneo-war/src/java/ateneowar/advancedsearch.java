/*
 * advancedsearch.java
 *
 * Created on Jan 30, 2008, 3:03:02 PM
 */
package ateneowar;

import ateneo.ejb.AteneoLocal;
import ateneo.ejb.AteneoLocalHome;
import ateneo.ejb.DepartmentLocal;
import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.Calendar;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.MessageGroup;
import com.sun.rave.web.ui.component.Page;
import com.sun.rave.web.ui.component.PanelGroup;
import com.sun.rave.web.ui.component.RadioButtonGroup;
import com.sun.rave.web.ui.component.StaticText;
import com.sun.rave.web.ui.component.TextField;
import com.sun.rave.web.ui.model.SingleSelectOptionsList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import javax.ejb.CreateException;
import javax.faces.FacesException;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIColumn;
import javax.faces.component.UIComponent;
import javax.faces.component.UISelectItems;
import javax.faces.component.html.HtmlDataTable;
import javax.faces.component.html.HtmlOutputLink;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.component.html.HtmlSelectOneMenu;
import javax.faces.component.html.HtmlSelectOneRadio;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;
import utils.Convert;
import utils.SearchDetails;
import utils.exceptions.WebServiceException;

/**
 * <p>Page bean that corresponds to a similarly named JSP page.  This
 * class contains component definitions (and initialization code) for
 * all components that you have defined on this page, as well as
 * lifecycle methods and event handlers where you may add behavior
 * to respond to incoming events.</p>
 *
 * @author benve
 */
public class advancedsearch extends AbstractPageBean {

	private String allDepartmentString = "Tutti";
	// <editor-fold defaultstate="collapsed" desc="Managed Component Definition">
	/**
	 * <p>Automatically managed component initialization.  <strong>WARNING:</strong>
	 * This method is automatically generated, so any user-specified code inserted
	 * here is subject to being replaced.</p>
	 */
	private void _init() throws Exception {
		typeRadioButtonGroupDefaultOptions.setOptions(new com.sun.rave.web.ui.model.Option[]{new com.sun.rave.web.ui.model.Option("0", "Tutti"), new com.sun.rave.web.ui.model.Option("1", "Report"), new com.sun.rave.web.ui.model.Option("2", "Raccolte")});
		typeRadioButtonGroupDefaultOptions.setSelectedValue("0");
	}
	private Page page1 = new Page();

	public Page getPage1() {
		return page1;
	}

	public void setPage1(Page p) {
		this.page1 = p;
	}
	private Html html1 = new Html();

	public Html getHtml1() {
		return html1;
	}

	public void setHtml1(Html h) {
		this.html1 = h;
	}
	private Head head1 = new Head();

	public Head getHead1() {
		return head1;
	}

	public void setHead1(Head h) {
		this.head1 = h;
	}
	private Link link1 = new Link();

	public Link getLink1() {
		return link1;
	}

	public void setLink1(Link l) {
		this.link1 = l;
	}
	private Body body1 = new Body();

	public Body getBody1() {
		return body1;
	}

	public void setBody1(Body b) {
		this.body1 = b;
	}
	private Form form1 = new Form();

	public Form getForm1() {
		return form1;
	}

	public void setForm1(Form f) {
		this.form1 = f;
	}
	private HtmlPanelGrid searchMenuGridPanel = new HtmlPanelGrid();

	public HtmlPanelGrid getSearchMenuGridPanel() {
		return searchMenuGridPanel;
	}

	public void setSearchMenuGridPanel(HtmlPanelGrid hpg) {
		this.searchMenuGridPanel = hpg;
	}
	private Label docIDLabel = new Label();

	public Label getDocIDLabel() {
		return docIDLabel;
	}

	public void setDocIDLabel(Label l) {
		this.docIDLabel = l;
	}
	private TextField docIDTextField = new TextField();

	public TextField getDocIDTextField() {
		return docIDTextField;
	}

	public void setDocIDTextField(TextField tf) {
		this.docIDTextField = tf;
	}
	private Label titleLabel = new Label();

	public Label getTitleLabel() {
		return titleLabel;
	}

	public void setTitleLabel(Label l) {
		this.titleLabel = l;
	}
	private TextField titleTextField = new TextField();

	public TextField getTitleTextField() {
		return titleTextField;
	}

	public void setTitleTextField(TextField tf) {
		this.titleTextField = tf;
	}
	private Label authorLabel = new Label();

	public Label getAuthorLabel() {
		return authorLabel;
	}

	public void setAuthorLabel(Label l) {
		this.authorLabel = l;
	}
	private Label keywordLabel = new Label();

	public Label getKeywordLabel() {
		return keywordLabel;
	}

	public void setKeywordLabel(Label l) {
		this.keywordLabel = l;
	}
	private TextField authorTextField = new TextField();

	public TextField getAuthorTextField() {
		return authorTextField;
	}

	public void setAuthorTextField(TextField tf) {
		this.authorTextField = tf;
	}
	private TextField keywordTextField = new TextField();

	public TextField getKeywordTextField() {
		return keywordTextField;
	}

	public void setKeywordTextField(TextField tf) {
		this.keywordTextField = tf;
	}
	private Label departmentLabel = new Label();

	public Label getDepartmentLabel() {
		return departmentLabel;
	}

	public void setDepartmentLabel(Label l) {
		this.departmentLabel = l;
	}
	private HtmlSelectOneMenu departmentDropdown = new HtmlSelectOneMenu();

	public HtmlSelectOneMenu getDepartmentDropdown() {
		return departmentDropdown;
	}

	public void setDepartmentDropdown(HtmlSelectOneMenu hsom) {
		this.departmentDropdown = hsom;
	}
	private UISelectItems departmentdropdownSelectItems = new UISelectItems();

	public UISelectItems getDepartmentdropdownSelectItems() {
		return departmentdropdownSelectItems;
	}

	public void setDepartmentdropdownSelectItems(UISelectItems uisi) {
		this.departmentdropdownSelectItems = uisi;
	}
	private Label typeLabel = new Label();

	public Label getTypeLabel() {
		return typeLabel;
	}

	public void setTypeLabel(Label l) {
		this.typeLabel = l;
	}
	private HtmlSelectOneRadio typeRadioButtonList = new HtmlSelectOneRadio();

	public HtmlSelectOneRadio getTypeRadioButtonList() {
		return typeRadioButtonList;
	}

	public void setTypeRadioButtonList(HtmlSelectOneRadio hsor) {
		this.typeRadioButtonList = hsor;
	}
	private UISelectItems radioButtonList1SelectItems = new UISelectItems();

	public UISelectItems getRadioButtonList1SelectItems() {
		return radioButtonList1SelectItems;
	}

	public void setRadioButtonList1SelectItems(UISelectItems uisi) {
		this.radioButtonList1SelectItems = uisi;
	}
	private Calendar dateStartCalendar = new Calendar();

	public Calendar getDateStartCalendar() {
		return dateStartCalendar;
	}

	public void setDateStartCalendar(Calendar c) {
		this.dateStartCalendar = c;
	}
	private Label dataLabel = new Label();

	public Label getDataLabel() {
		return dataLabel;
	}

	public void setDataLabel(Label l) {
		this.dataLabel = l;
	}
	private Calendar dateEndCalendar = new Calendar();

	public Calendar getDateEndCalendar() {
		return dateEndCalendar;
	}

	public void setDateEndCalendar(Calendar c) {
		this.dateEndCalendar = c;
	}
	private PanelGroup dataGroupPanel = new PanelGroup();

	public PanelGroup getDataGroupPanel() {
		return dataGroupPanel;
	}

	public void setDataGroupPanel(PanelGroup pg) {
		this.dataGroupPanel = pg;
	}
	private MessageGroup messageGroup1 = new MessageGroup();

	public MessageGroup getMessageGroup1() {
		return messageGroup1;
	}

	public void setMessageGroup1(MessageGroup mg) {
		this.messageGroup1 = mg;
	}
	private Button searchButton = new Button();

	public Button getSearchButton() {
		return searchButton;
	}

	public void setSearchButton(Button b) {
		this.searchButton = b;
	}
	private RadioButtonGroup typeRadioButtonGroup = new RadioButtonGroup();

	public RadioButtonGroup getTypeRadioButtonGroup() {
		return typeRadioButtonGroup;
	}

	public void setTypeRadioButtonGroup(RadioButtonGroup rbg) {
		this.typeRadioButtonGroup = rbg;
	}
	private SingleSelectOptionsList typeRadioButtonGroupDefaultOptions = new SingleSelectOptionsList();

	public SingleSelectOptionsList getTypeRadioButtonGroupDefaultOptions() {
		return typeRadioButtonGroupDefaultOptions;
	}

	public void setTypeRadioButtonGroupDefaultOptions(SingleSelectOptionsList ssol) {
		this.typeRadioButtonGroupDefaultOptions = ssol;
	}
	private StaticText documentStaticText = new StaticText();

	public StaticText getDocumentStaticText() {
		return documentStaticText;
	}

	public void setDocumentStaticText(StaticText st) {
		this.documentStaticText = st;
	}
	private HtmlDataTable documentDataTable = new HtmlDataTable();

	public HtmlDataTable getDocumentDataTable() {
		return documentDataTable;
	}

	public void setDocumentDataTable(HtmlDataTable hdt) {
		this.documentDataTable = hdt;
	}
	private UIColumn departmentColumn = new UIColumn();

	public UIColumn getDepartmentColumn() {
		return departmentColumn;
	}

	public void setDepartmentColumn(UIColumn uic) {
		this.departmentColumn = uic;
	}
	private HtmlOutputText departmentContentOutputText = new HtmlOutputText();

	public HtmlOutputText getDepartmentContentOutputText() {
		return departmentContentOutputText;
	}

	public void setDepartmentContentOutputText(HtmlOutputText hot) {
		this.departmentContentOutputText = hot;
	}
	private HtmlOutputText departmentOutputText = new HtmlOutputText();

	public HtmlOutputText getDepartmentOutputText() {
		return departmentOutputText;
	}

	public void setDepartmentOutputText(HtmlOutputText hot) {
		this.departmentOutputText = hot;
	}
	private UIColumn IDColumn = new UIColumn();

	public UIColumn getIDColumn() {
		return IDColumn;
	}

	public void setIDColumn(UIColumn uic) {
		this.IDColumn = uic;
	}
	private HtmlOutputText IDOutputText = new HtmlOutputText();

	public HtmlOutputText getIDOutputText() {
		return IDOutputText;
	}

	public void setIDOutputText(HtmlOutputText hot) {
		this.IDOutputText = hot;
	}
	private HtmlOutputText IDContentOutputText = new HtmlOutputText();

	public HtmlOutputText getIDContentOutputText() {
		return IDContentOutputText;
	}

	public void setIDContentOutputText(HtmlOutputText hot) {
		this.IDContentOutputText = hot;
	}
	private UIColumn titleColumn = new UIColumn();

	public UIColumn getTitleColumn() {
		return titleColumn;
	}

	public void setTitleColumn(UIColumn uic) {
		this.titleColumn = uic;
	}
	private HtmlOutputText titleContentOutputText = new HtmlOutputText();

	public HtmlOutputText getTitleContentOutputText() {
		return titleContentOutputText;
	}

	public void setTitleContentOutputText(HtmlOutputText hot) {
		this.titleContentOutputText = hot;
	}
	private HtmlOutputText titleOutputText = new HtmlOutputText();

	public HtmlOutputText getTitleOutputText() {
		return titleOutputText;
	}

	public void setTitleOutputText(HtmlOutputText hot) {
		this.titleOutputText = hot;
	}
	private UIColumn creationDateColumn = new UIColumn();

	public UIColumn getCreationDateColumn() {
		return creationDateColumn;
	}

	public void setCreationDateColumn(UIColumn uic) {
		this.creationDateColumn = uic;
	}
	private HtmlOutputText creationDateContentOutputText = new HtmlOutputText();

	public HtmlOutputText getCreationDateContentOutputText() {
		return creationDateContentOutputText;
	}

	public void setCreationDateContentOutputText(HtmlOutputText hot) {
		this.creationDateContentOutputText = hot;
	}
	private HtmlOutputText creationDateOutputText = new HtmlOutputText();

	public HtmlOutputText getCreationDateOutputText() {
		return creationDateOutputText;
	}

	public void setCreationDateOutputText(HtmlOutputText hot) {
		this.creationDateOutputText = hot;
	}
	private UIColumn authorsColumn = new UIColumn();

	public UIColumn getAuthorsColumn() {
		return authorsColumn;
	}

	public void setAuthorsColumn(UIColumn uic) {
		this.authorsColumn = uic;
	}
	private HtmlOutputText authorsContentOutputText = new HtmlOutputText();

	public HtmlOutputText getAuthorsContentOutputText() {
		return authorsContentOutputText;
	}

	public void setAuthorsContentOutputText(HtmlOutputText hot) {
		this.authorsContentOutputText = hot;
	}
	private HtmlOutputText authorsOutputText = new HtmlOutputText();

	public HtmlOutputText getAuthorsOutputText() {
		return authorsOutputText;
	}

	public void setAuthorsOutputText(HtmlOutputText hot) {
		this.authorsOutputText = hot;
	}
	private UIColumn keywordsColumn = new UIColumn();

	public UIColumn getKeywordsColumn() {
		return keywordsColumn;
	}

	public void setKeywordsColumn(UIColumn uic) {
		this.keywordsColumn = uic;
	}
	private HtmlOutputText keywordsContentOutputText = new HtmlOutputText();

	public HtmlOutputText getKeywordsContentOutputText() {
		return keywordsContentOutputText;
	}

	public void setKeywordsContentOutputText(HtmlOutputText hot) {
		this.keywordsContentOutputText = hot;
	}
	private HtmlOutputText keywordsOutputText = new HtmlOutputText();

	public HtmlOutputText getKeywordsOutputText() {
		return keywordsOutputText;
	}

	public void setKeywordsOutputText(HtmlOutputText hot) {
		this.keywordsOutputText = hot;
	}
	private UIColumn typeColumn = new UIColumn();

	public UIColumn getTypeColumn() {
		return typeColumn;
	}

	public void setTypeColumn(UIColumn uic) {
		this.typeColumn = uic;
	}
	private HtmlOutputText typeOutputText = new HtmlOutputText();

	public HtmlOutputText getTypeOutputText() {
		return typeOutputText;
	}

	public void setTypeOutputText(HtmlOutputText hot) {
		this.typeOutputText = hot;
	}
	private HtmlOutputText typeContentOutputText = new HtmlOutputText();

	public HtmlOutputText getTypeContentOutputText() {
		return typeContentOutputText;
	}

	public void setTypeContentOutputText(HtmlOutputText hot) {
		this.typeContentOutputText = hot;
	}
	private UIColumn downloadColumn = new UIColumn();

	public UIColumn getDownloadColumn() {
		return downloadColumn;
	}

	public void setDownloadColumn(UIColumn uic) {
		this.downloadColumn = uic;
	}
	private HtmlOutputText downloadOutputText = new HtmlOutputText();

	public HtmlOutputText getDownloadOutputText() {
		return downloadOutputText;
	}

	public void setDownloadOutputText(HtmlOutputText hot) {
		this.downloadOutputText = hot;
	}
	private HtmlOutputLink downloadHyperlink = new HtmlOutputLink();

	public HtmlOutputLink getDownloadHyperlink() {
		return downloadHyperlink;
	}

	public void setDownloadHyperlink(HtmlOutputLink hol) {
		this.downloadHyperlink = hol;
	}
	private HtmlOutputText hyperlink2Text1 = new HtmlOutputText();

	public HtmlOutputText getHyperlink2Text1() {
		return hyperlink2Text1;
	}

	public void setHyperlink2Text1(HtmlOutputText hot) {
		this.hyperlink2Text1 = hot;
	}
	private HtmlPanelGrid gridPanel2 = new HtmlPanelGrid();

	public HtmlPanelGrid getGridPanel2() {
		return gridPanel2;
	}

	public void setGridPanel2(HtmlPanelGrid hpg) {
		this.gridPanel2 = hpg;
	}
	private HtmlPanelGrid gridPanel3 = new HtmlPanelGrid();

	public HtmlPanelGrid getGridPanel3() {
		return gridPanel3;
	}

	public void setGridPanel3(HtmlPanelGrid hpg) {
		this.gridPanel3 = hpg;
	}
	private HtmlPanelGrid gridPanel4 = new HtmlPanelGrid();

	public HtmlPanelGrid getGridPanel4() {
		return gridPanel4;
	}

	public void setGridPanel4(HtmlPanelGrid hpg) {
		this.gridPanel4 = hpg;
	}
	private StaticText staticText2 = new StaticText();

	public StaticText getStaticText2() {
		return staticText2;
	}

	public void setStaticText2(StaticText st) {
		this.staticText2 = st;
	}
	private StaticText staticText3 = new StaticText();

	public StaticText getStaticText3() {
		return staticText3;
	}

	public void setStaticText3(StaticText st) {
		this.staticText3 = st;
	}
	private HtmlPanelGrid resultGridPanel = new HtmlPanelGrid();

	public HtmlPanelGrid getResultGridPanel() {
		return resultGridPanel;
	}

	public void setResultGridPanel(HtmlPanelGrid hpg) {
		this.resultGridPanel = hpg;
	}
	private HtmlPanelGrid advancedSearchGridPanel = new HtmlPanelGrid();

	public HtmlPanelGrid getAdvancedSearchGridPanel() {
		return advancedSearchGridPanel;
	}

	public void setAdvancedSearchGridPanel(HtmlPanelGrid hpg) {
		this.advancedSearchGridPanel = hpg;
	}

	// </editor-fold>
	/**
	 * <p>Construct a new Page bean instance.</p>
	 */
	public advancedsearch() {
	}

	/**
	 * <p>Callback method that is called whenever a page is navigated to,
	 * either directly via a URL, or indirectly via page navigation.
	 * Customize this method to acquire resources that will be needed
	 * for event handlers and lifecycle methods, whether or not this
	 * page is performing post back processing.</p>
	 * 
	 * <p>Note that, if the current request is a postback, the property
	 * values of the components do <strong>not</strong> represent any
	 * values submitted with this request.  Instead, they represent the
	 * property values that were saved for this view when it was rendered.</p>
	 */
	public void init() {
		// Perform initializations inherited from our superclass
		super.init();

		FacesContext fc = FacesContext.getCurrentInstance();
		HttpSession session = ((HttpSession) fc.getExternalContext().getSession(false));

		if (session != null) {
			session.invalidate();
		}
		// Perform application initialization that must complete
		// *before* managed components are initialized
		// TODO - add your own initialiation code here

		// <editor-fold defaultstate="collapsed" desc="Managed Component Initialization">
		// Initialize automatically managed components
		// *Note* - this logic should NOT be modified
		try {
			_init();
		} catch (Exception e) {
			log("advancedsearch Initialization Failure", e);
			throw e instanceof FacesException ? (FacesException) e : new FacesException(e);
		}

	// </editor-fold>
	// Perform application initialization that must complete
	// *after* managed components are initialized
	// TODO - add your own initialization code here
	}

	/**
	 * <p>Callback method that is called after the component tree has been
	 * restored, but before any event processing takes place.  This method
	 * will <strong>only</strong> be called on a postback request that
	 * is processing a form submit.  Customize this method to allocate
	 * resources that will be required in your event handlers.</p>
	 */
	public void preprocess() {
	}

	/**
	 * <p>Callback method that is called just before rendering takes place.
	 * This method will <strong>only</strong> be called for the page that
	 * will actually be rendered (and not, for example, on a page that
	 * handled a postback and then navigated to a different page).  Customize
	 * this method to allocate resources that will be required for rendering
	 * this page.</p>
	 */
	public void prerender() {
	}

	/**
	 * <p>Callback method that is called after rendering is completed for
	 * this request, if <code>init()</code> was called (regardless of whether
	 * or not this was the page that was actually rendered).  Customize this
	 * method to release resources acquired in the <code>init()</code>,
	 * <code>preprocess()</code>, or <code>prerender()</code> methods (or
	 * acquired during execution of an event handler).</p>
	 */
	public void destroy() {
	}

	public Collection getDepartmentNames() {//TODO: Gestire eccezzione
		ArrayList departments = new ArrayList();
		ArrayList departmentNames = new ArrayList();

		departments = (ArrayList) getAteneoApplicationBean().getDepartments();

		for (Iterator it = departments.iterator(); it.hasNext();) {
			departmentNames.add(new SelectItem(((DepartmentLocal) it.next()).getPk()));
		}
		departmentNames.add(new SelectItem(allDepartmentString));

		return departmentNames;
	}

	public void dateEndCalendar_validate(FacesContext context, UIComponent component, Object value) {
		Date startDateValue = dateStartCalendar.getSelectedDate();

		if (startDateValue != null && value != null) {
			java.util.Calendar endDate = GregorianCalendar.getInstance();
			endDate.setTime((Date) value);
			java.util.Calendar startDate = GregorianCalendar.getInstance();
			startDate.setTime(startDateValue);

			if (startDate.after(endDate)) {
				throw new ValidatorException(new FacesMessage("End date must be after start date."));//TODO Tradurre
			}
		}
	}

	public String searchButton_action() {
		Object authorTextFieldValue = authorTextField.getValue();
		Object docIDTextFieldValue = docIDTextField.getValue();
		Object keywordTextFieldValue = keywordTextField.getValue();
		Object titleTextFieldValue = titleTextField.getValue();
		Date dateStartCalendarValue = dateStartCalendar.getSelectedDate();
		Date dateEndCalendarValue = dateEndCalendar.getSelectedDate();
		String dropdownValue = (String) departmentDropdown.getValue();

		String[] searchAuthors;
		if (authorTextFieldValue != null) {
			searchAuthors = Convert.stringToArray(((String) authorTextFieldValue).trim());
		} else {
			searchAuthors = new String[1];
			searchAuthors[0] = "";
		}

		String[] searchID;
		if (docIDTextFieldValue != null) {
			searchID = Convert.stringToArray(((String) docIDTextFieldValue).trim());
		} else {
			searchID = new String[1];
			searchID[0] = "";
		}

		long endDate;
		if (dateEndCalendarValue != null) {
			endDate = dateEndCalendarValue.getTime();
		} else {
			endDate = -1;
		}

		String[] searchKey;
		if (keywordTextFieldValue != null) {
			searchKey = Convert.stringToArray(((String) keywordTextFieldValue).trim());
		} else {
			searchKey = new String[1];
			searchKey[0] = "";
		}

		long startDate;
		if (dateStartCalendarValue != null) {
			startDate = dateStartCalendarValue.getTime();
		} else {
			startDate = -1;
		}

		String[] searchTitle;
		if (titleTextFieldValue != null) {
			searchTitle = Convert.stringToArray(((String) titleTextFieldValue).trim());
		//System.out.println(searchID[0]);
		} else {
			searchTitle = new String[1];
			searchTitle[0] = "";
		}

		String[] searchString = new String[1];

		searchString[0] = "";//(String) titleTextField.getValue();

		int type = Integer.parseInt((String) typeRadioButtonGroup.getSelected());

		SearchDetails searchDetails = new SearchDetails(searchAuthors, searchString, searchID, endDate, searchKey, startDate, searchTitle, type);

		if (dropdownValue.equals(allDepartmentString)) {
			try {
				getAteneoRequestBean().setSearchResult(lookupAteneoBean().searchDocuments(searchDetails));
			} catch (WebServiceException ex) {
				error(ex.getMessage());
			}
		} else {
			try {
				getAteneoRequestBean().setSearchResult(lookupAteneoBean().searchDocuments(searchDetails, dropdownValue));
			} catch (WebServiceException ex) {
				error(ex.getMessage());
			}
		}
		return null;
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected AteneoSessionBean getAteneoSessionBean() {
		return (AteneoSessionBean) getBean("AteneoSessionBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected AteneoApplicationBean getAteneoApplicationBean() {
		return (AteneoApplicationBean) getBean("AteneoApplicationBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected AteneoRequestBean getAteneoRequestBean() {
		return (AteneoRequestBean) getBean("AteneoRequestBean");
	}

	private AteneoLocal lookupAteneoBean() {
		try {
			Context c = new InitialContext();
			AteneoLocalHome rv = (AteneoLocalHome) c.lookup("java:comp/env/AteneoBean");
			return rv.create();
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		} catch (CreateException ce) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
			throw new RuntimeException(ce);
		}
	}
}
