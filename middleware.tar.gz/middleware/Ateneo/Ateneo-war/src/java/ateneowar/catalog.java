/*
 * catalogo.java
 *
 * Created on Jan 14, 2008, 6:37:23 PM
 */
package ateneowar;

import ateneo.ejb.AteneoLocal;
import ateneo.ejb.AteneoLocalHome;
import com.sun.rave.faces.data.DefaultTableDataModel;
import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.Checkbox;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import com.sun.rave.web.ui.component.StaticText;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import javax.ejb.CreateException;
import javax.faces.FacesException;
import javax.faces.component.UIColumn;
import javax.faces.component.html.HtmlDataTable;
import javax.faces.component.html.HtmlOutputLink;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;
import utils.exceptions.FinderCatalogException;
import utils.exceptions.WebServiceException;

/**
 * <p>Page bean that corresponds to a similarly named JSP page.  This
 * class contains component definitions (and initialization code) for
 * all components that you have defined on this page, as well as
 * lifecycle methods and event handlers where you may add behavior
 * to respond to incoming events.</p>
 *
 * @author benve
 */
public class catalog extends AbstractPageBean {
	// <editor-fold defaultstate="collapsed" desc="Managed Component Definition">
	/**
	 * <p>Automatically managed component initialization.  <strong>WARNING:</strong>
	 * This method is automatically generated, so any user-specified code inserted
	 * here is subject to being replaced.</p>
	 */
	private void _init() throws Exception {
	}
	private Page page1 = new Page();

	public Page getPage1() {
		return page1;
	}

	public void setPage1(Page p) {
		this.page1 = p;
	}
	private Html html1 = new Html();

	public Html getHtml1() {
		return html1;
	}

	public void setHtml1(Html h) {
		this.html1 = h;
	}
	private Head head1 = new Head();

	public Head getHead1() {
		return head1;
	}

	public void setHead1(Head h) {
		this.head1 = h;
	}
	private Link link1 = new Link();

	public Link getLink1() {
		return link1;
	}

	public void setLink1(Link l) {
		this.link1 = l;
	}
	private Body body1 = new Body();

	public Body getBody1() {
		return body1;
	}

	public void setBody1(Body b) {
		this.body1 = b;
	}
	private Form form1 = new Form();

	public Form getForm1() {
		return form1;
	}

	public void setForm1(Form f) {
		this.form1 = f;
	}
	private StaticText titleStaticText = new StaticText();

	public StaticText getTitleStaticText() {
		return titleStaticText;
	}

	public void setTitleStaticText(StaticText st) {
		this.titleStaticText = st;
	}
	private HtmlPanelGrid gridPanel1 = new HtmlPanelGrid();

	public HtmlPanelGrid getGridPanel1() {
		return gridPanel1;
	}

	public void setGridPanel1(HtmlPanelGrid hpg) {
		this.gridPanel1 = hpg;
	}
	private Button catalogButton = new Button();

	public Button getCatalogButton() {
		return catalogButton;
	}

	public void setCatalogButton(Button b) {
		this.catalogButton = b;
	}
	private HtmlDataTable catalogDataTable = new HtmlDataTable();

	public HtmlDataTable getCatalogDataTable() {
		return catalogDataTable;
	}

	public void setCatalogDataTable(HtmlDataTable hdt) {
		this.catalogDataTable = hdt;
	}
	private UIColumn departmentColumn = new UIColumn();

	public UIColumn getDepartmentColumn() {
		return departmentColumn;
	}

	public void setDepartmentColumn(UIColumn uic) {
		this.departmentColumn = uic;
	}
	private HtmlOutputText departmentContentOutputText = new HtmlOutputText();

	public HtmlOutputText getDepartmentContentOutputText() {
		return departmentContentOutputText;
	}

	public void setDepartmentContentOutputText(HtmlOutputText hot) {
		this.departmentContentOutputText = hot;
	}
	private HtmlOutputText departmentOutputText = new HtmlOutputText();

	public HtmlOutputText getDepartmentOutputText() {
		return departmentOutputText;
	}

	public void setDepartmentOutputText(HtmlOutputText hot) {
		this.departmentOutputText = hot;
	}
	private UIColumn IDColumn = new UIColumn();

	public UIColumn getIDColumn() {
		return IDColumn;
	}

	public void setIDColumn(UIColumn uic) {
		this.IDColumn = uic;
	}
	private HtmlOutputText IDOutputText = new HtmlOutputText();

	public HtmlOutputText getIDOutputText() {
		return IDOutputText;
	}

	public void setIDOutputText(HtmlOutputText hot) {
		this.IDOutputText = hot;
	}
	private HtmlOutputText IDContentOutputText = new HtmlOutputText();

	public HtmlOutputText getIDContentOutputText() {
		return IDContentOutputText;
	}

	public void setIDContentOutputText(HtmlOutputText hot) {
		this.IDContentOutputText = hot;
	}
	private UIColumn titleColumn = new UIColumn();

	public UIColumn getTitleColumn() {
		return titleColumn;
	}

	public void setTitleColumn(UIColumn uic) {
		this.titleColumn = uic;
	}
	private HtmlOutputText titleContentoutputText = new HtmlOutputText();

	public HtmlOutputText getTitleContentoutputText() {
		return titleContentoutputText;
	}

	public void setTitleContentoutputText(HtmlOutputText hot) {
		this.titleContentoutputText = hot;
	}
	private HtmlOutputText titleOutputText = new HtmlOutputText();

	public HtmlOutputText getTitleOutputText() {
		return titleOutputText;
	}

	public void setTitleOutputText(HtmlOutputText hot) {
		this.titleOutputText = hot;
	}
	private UIColumn creationDateColumn = new UIColumn();

	public UIColumn getCreationDateColumn() {
		return creationDateColumn;
	}

	public void setCreationDateColumn(UIColumn uic) {
		this.creationDateColumn = uic;
	}
	private HtmlOutputText creationDateContentOutputText = new HtmlOutputText();

	public HtmlOutputText getCreationDateContentOutputText() {
		return creationDateContentOutputText;
	}

	public void setCreationDateContentOutputText(HtmlOutputText hot) {
		this.creationDateContentOutputText = hot;
	}
	private HtmlOutputText creationDateOutputText = new HtmlOutputText();

	public HtmlOutputText getCreationDateOutputText() {
		return creationDateOutputText;
	}

	public void setCreationDateOutputText(HtmlOutputText hot) {
		this.creationDateOutputText = hot;
	}
	private UIColumn authorsColumn = new UIColumn();

	public UIColumn getAuthorsColumn() {
		return authorsColumn;
	}

	public void setAuthorsColumn(UIColumn uic) {
		this.authorsColumn = uic;
	}
	private HtmlOutputText authorsContentOutputText = new HtmlOutputText();

	public HtmlOutputText getAuthorsContentOutputText() {
		return authorsContentOutputText;
	}

	public void setAuthorsContentOutputText(HtmlOutputText hot) {
		this.authorsContentOutputText = hot;
	}
	private HtmlOutputText authorsOutputText = new HtmlOutputText();

	public HtmlOutputText getAuthorsOutputText() {
		return authorsOutputText;
	}

	public void setAuthorsOutputText(HtmlOutputText hot) {
		this.authorsOutputText = hot;
	}
	private UIColumn keywordsColumn = new UIColumn();

	public UIColumn getKeywordsColumn() {
		return keywordsColumn;
	}

	public void setKeywordsColumn(UIColumn uic) {
		this.keywordsColumn = uic;
	}
	private HtmlOutputText keywordsContentOutputText = new HtmlOutputText();

	public HtmlOutputText getKeywordsContentOutputText() {
		return keywordsContentOutputText;
	}

	public void setKeywordsContentOutputText(HtmlOutputText hot) {
		this.keywordsContentOutputText = hot;
	}
	private HtmlOutputText keywordsOutputText = new HtmlOutputText();

	public HtmlOutputText getKeywordsOutputText() {
		return keywordsOutputText;
	}

	public void setKeywordsOutputText(HtmlOutputText hot) {
		this.keywordsOutputText = hot;
	}
	private UIColumn typeColumn = new UIColumn();

	public UIColumn getTypeColumn() {
		return typeColumn;
	}

	public void setTypeColumn(UIColumn uic) {
		this.typeColumn = uic;
	}
	private HtmlOutputText typeOutputText = new HtmlOutputText();

	public HtmlOutputText getTypeOutputText() {
		return typeOutputText;
	}

	public void setTypeOutputText(HtmlOutputText hot) {
		this.typeOutputText = hot;
	}
	private HtmlOutputText typeContentOutputText = new HtmlOutputText();

	public HtmlOutputText getTypeContentOutputText() {
		return typeContentOutputText;
	}

	public void setTypeContentOutputText(HtmlOutputText hot) {
		this.typeContentOutputText = hot;
	}
	private UIColumn downloadColumn = new UIColumn();

	public UIColumn getDownloadColumn() {
		return downloadColumn;
	}

	public void setDownloadColumn(UIColumn uic) {
		this.downloadColumn = uic;
	}
	private HtmlOutputText downloadOutputText = new HtmlOutputText();

	public HtmlOutputText getDownloadOutputText() {
		return downloadOutputText;
	}

	public void setDownloadOutputText(HtmlOutputText hot) {
		this.downloadOutputText = hot;
	}
	private HtmlOutputLink hyperlink1 = new HtmlOutputLink();

	public HtmlOutputLink getHyperlink1() {
		return hyperlink1;
	}

	public void setHyperlink1(HtmlOutputLink hol) {
		this.hyperlink1 = hol;
	}
	private HtmlOutputText hyperlink2Text1 = new HtmlOutputText();

	public HtmlOutputText getHyperlink2Text1() {
		return hyperlink2Text1;
	}

	public void setHyperlink2Text1(HtmlOutputText hot) {
		this.hyperlink2Text1 = hot;
	}
	private HtmlPanelGrid gridPanel2 = new HtmlPanelGrid();

	public HtmlPanelGrid getGridPanel2() {
		return gridPanel2;
	}

	public void setGridPanel2(HtmlPanelGrid hpg) {
		this.gridPanel2 = hpg;
	}
	private HtmlDataTable departmentsDataTable = new HtmlDataTable();

	public HtmlDataTable getDepartmentsDataTable() {
		return departmentsDataTable;
	}

	public void setDepartmentsDataTable(HtmlDataTable hdt) {
		this.departmentsDataTable = hdt;
	}
	private DefaultTableDataModel dataTable2Model = new DefaultTableDataModel();

	public DefaultTableDataModel getDataTable2Model() {
		return dataTable2Model;
	}

	public void setDataTable2Model(DefaultTableDataModel dtdm) {
		this.dataTable2Model = dtdm;
	}
	private UIColumn departmentNameColumn = new UIColumn();

	public UIColumn getDepartmentNameColumn() {
		return departmentNameColumn;
	}

	public void setDepartmentNameColumn(UIColumn uic) {
		this.departmentNameColumn = uic;
	}
	private HtmlOutputText departmentNameOutputText = new HtmlOutputText();

	public HtmlOutputText getDepartmentNameOutputText() {
		return departmentNameOutputText;
	}

	public void setDepartmentNameOutputText(HtmlOutputText hot) {
		this.departmentNameOutputText = hot;
	}
	private HtmlPanelGrid gridPanel3 = new HtmlPanelGrid();

	public HtmlPanelGrid getGridPanel3() {
		return gridPanel3;
	}

	public void setGridPanel3(HtmlPanelGrid hpg) {
		this.gridPanel3 = hpg;
	}
	private Button allDepartmentButton = new Button();

	public Button getAllDepartmentButton() {
		return allDepartmentButton;
	}

	public void setAllDepartmentButton(Button b) {
		this.allDepartmentButton = b;
	}
	private Checkbox departmentCheckbox = new Checkbox();

	public Checkbox getDepartmentCheckbox() {
		return departmentCheckbox;
	}

	public void setDepartmentCheckbox(Checkbox c) {
		this.departmentCheckbox = c;
	}
	private UIColumn checkColumn = new UIColumn();

	public UIColumn getCheckColumn() {
		return checkColumn;
	}

	public void setCheckColumn(UIColumn uic) {
		this.checkColumn = uic;
	}
	private UIColumn departmentIDColumn = new UIColumn();

	public UIColumn getDepartmentIDColumn() {
		return departmentIDColumn;
	}

	public void setDepartmentIDColumn(UIColumn uic) {
		this.departmentIDColumn = uic;
	}
	private HtmlOutputText departmentIDOutputText = new HtmlOutputText();

	public HtmlOutputText getDepartmentIDOutputText() {
		return departmentIDOutputText;
	}

	public void setDepartmentIDOutputText(HtmlOutputText hot) {
		this.departmentIDOutputText = hot;
	}

	// </editor-fold>
	/**
	 * <p>Construct a new Page bean instance.</p>
	 */
	public catalog() {
	}

	/**
	 * <p>Callback method that is called whenever a page is navigated to,
	 * either directly via a URL, or indirectly via page navigation.
	 * Customize this method to acquire resources that will be needed
	 * for event handlers and lifecycle methods, whether or not this
	 * page is performing post back processing.</p>
	 * 
	 * <p>Note that, if the current request is a postback, the property
	 * values of the components do <strong>not</strong> represent any
	 * values submitted with this request.  Instead, they represent the
	 * property values that were saved for this view when it was rendered.</p>
	 */
	public void init() {
		// Perform initializations inherited from our superclass
		super.init();

		FacesContext fc = FacesContext.getCurrentInstance();
		HttpSession session = ((HttpSession) fc.getExternalContext().getSession(false));

		if (session != null) {
			session.invalidate();
		}
		// Perform application initialization that must complete
		// *before* managed components are initialized
		// TODO - add your own initialiation code here

		// <editor-fold defaultstate="collapsed" desc="Managed Component Initialization">
		// Initialize automatically managed components
		// *Note* - this logic should NOT be modified
		try {
			_init();
		} catch (Exception e) {
			log("catalogo Initialization Failure", e);
			throw e instanceof FacesException ? (FacesException) e : new FacesException(e);
		}

	// </editor-fold>
	// Perform application initialization that must complete
	// *after* managed components are initialized
	// TODO - add your own initialization code here
	}

	/**
	 * <p>Callback method that is called after the component tree has been
	 * restored, but before any event processing takes place.  This method
	 * will <strong>only</strong> be called on a postback request that
	 * is processing a form submit.  Customize this method to allocate
	 * resources that will be required in your event handlers.</p>
	 */
	public void preprocess() {
	}

	/**
	 * <p>Callback method that is called just before rendering takes place.
	 * This method will <strong>only</strong> be called for the page that
	 * will actually be rendered (and not, for example, on a page that
	 * handled a postback and then navigated to a different page).  Customize
	 * this method to allocate resources that will be required for rendering
	 * this page.</p>
	 */
	public void prerender() {
	}

	/**
	 * <p>Callback method that is called after rendering is completed for
	 * this request, if <code>init()</code> was called (regardless of whether
	 * or not this was the page that was actually rendered).  Customize this
	 * method to release resources acquired in the <code>init()</code>,
	 * <code>preprocess()</code>, or <code>prerender()</code> methods (or
	 * acquired during execution of an event handler).</p>
	 */
	public void destroy() {
	}

	public Collection getDepartments() {
		return lookupAteneoBean().getAllDepartments();
	}

	public String allDepartmentButton_action() {
		Collection results = null;
		
		try {
			AteneoLocal ateneo = lookupAteneoBean();

			results = ateneo.getCatalog();
			
			getAteneoRequestBean().setSearchResult(results);
		} catch (FinderCatalogException ex) {
            error(ex.getMessage());
        } catch (WebServiceException ex) {
            error(ex.getMessage());
        }
		return null;
	}

	public String catalogButton_action() {
		AteneoLocal ateneo = lookupAteneoBean();
		Collection results, oldResults;
		int first = departmentsDataTable.getFirst();
		int rows = getDepartments().size();
		ArrayList depts = new ArrayList();

		for (int index = first; index < (first + rows); index++) {
			departmentsDataTable.setRowIndex(index);
			if (departmentCheckbox.isChecked()) {
				depts.add(departmentIDOutputText.getValue().toString());
			}
		}

		departmentsDataTable.setRowIndex(-1);

		for (Iterator it = depts.iterator(); it.hasNext();) {
            try {
                results = ateneo.getCatalog((String) it.next());
                oldResults = getAteneoRequestBean().getSearchResult();
                if (oldResults != null) {
                    results.addAll(oldResults);
                }
                getAteneoRequestBean().setSearchResult(results);
            } catch (WebServiceException ex) {
                error(ex.getMessage());
            }
		}

		return null;
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected AteneoSessionBean getAteneoSessionBean() {
		return (AteneoSessionBean) getBean("AteneoSessionBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected AteneoApplicationBean getAteneoApplicationBean() {
		return (AteneoApplicationBean) getBean("AteneoApplicationBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected AteneoRequestBean getAteneoRequestBean() {
		return (AteneoRequestBean) getBean("AteneoRequestBean");
	}

	private AteneoLocal lookupAteneoBean() {
		try {
			Context c = new InitialContext();
			AteneoLocalHome rv = (AteneoLocalHome) c.lookup("java:comp/env/AteneoBean");
			return rv.create();
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		} catch (CreateException ce) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
			throw new RuntimeException(ce);
		}
	}
}

