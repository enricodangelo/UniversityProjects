/*
 * search.java
 *
 * Created on Jan 28, 2008, 4:40:30 PM
 */
package ateneowar;

import ateneo.ejb.AteneoLocal;
import ateneo.ejb.AteneoLocalHome;
import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.HiddenField;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Hyperlink;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.MessageGroup;
import com.sun.rave.web.ui.component.Page;
import com.sun.rave.web.ui.component.StaticText;
import com.sun.rave.web.ui.component.TextField;
import java.util.Collection;
import javax.ejb.CreateException;
import javax.faces.FacesException;
import javax.faces.component.UIColumn;
import javax.faces.component.html.HtmlDataTable;
import javax.faces.component.html.HtmlOutputLink;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.faces.convert.DateTimeConverter;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;
import utils.SearchDetails;
import utils.exceptions.WebServiceException;

/**
 * <p>Page bean that corresponds to a similarly named JSP page.  This
 * class contains component definitions (and initialization code) for
 * all components that you have defined on this page, as well as
 * lifecycle methods and event handlers where you may add behavior
 * to respond to incoming events.</p>
 *
 * @author benve
 */
public class search extends AbstractPageBean {
	// <editor-fold defaultstate="collapsed" desc="Managed Component Definition">
	/**
	 * <p>Automatically managed component initialization.  <strong>WARNING:</strong>
	 * This method is automatically generated, so any user-specified code inserted
	 * here is subject to being replaced.</p>
	 */
	private void _init() throws Exception {
	}
	private Page page1 = new Page();

	public Page getPage1() {
		return page1;
	}

	public void setPage1(Page p) {
		this.page1 = p;
	}
	private Html html1 = new Html();

	public Html getHtml1() {
		return html1;
	}

	public void setHtml1(Html h) {
		this.html1 = h;
	}
	private Head head1 = new Head();

	public Head getHead1() {
		return head1;
	}

	public void setHead1(Head h) {
		this.head1 = h;
	}
	private Link link1 = new Link();

	public Link getLink1() {
		return link1;
	}

	public void setLink1(Link l) {
		this.link1 = l;
	}
	private Body body1 = new Body();

	public Body getBody1() {
		return body1;
	}

	public void setBody1(Body b) {
		this.body1 = b;
	}
	private Form form1 = new Form();

	public Form getForm1() {
		return form1;
	}

	public void setForm1(Form f) {
		this.form1 = f;
	}
	private TextField searchTextField = new TextField();

	public TextField getSearchTextField() {
		return searchTextField;
	}

	public void setSearchTextField(TextField tf) {
		this.searchTextField = tf;
	}
	private Button searchButton = new Button();

	public Button getSearchButton() {
		return searchButton;
	}

	public void setSearchButton(Button b) {
		this.searchButton = b;
	}
	private HtmlDataTable dataTable1 = new HtmlDataTable();

	public HtmlDataTable getDataTable1() {
		return dataTable1;
	}

	public void setDataTable1(HtmlDataTable hdt) {
		this.dataTable1 = hdt;
	}
	private UIColumn column1 = new UIColumn();

	public UIColumn getColumn1() {
		return column1;
	}

	public void setColumn1(UIColumn uic) {
		this.column1 = uic;
	}
	private HtmlOutputText outputText2 = new HtmlOutputText();

	public HtmlOutputText getOutputText2() {
		return outputText2;
	}

	public void setOutputText2(HtmlOutputText hot) {
		this.outputText2 = hot;
	}
	private UIColumn column2 = new UIColumn();

	public UIColumn getColumn2() {
		return column2;
	}

	public void setColumn2(UIColumn uic) {
		this.column2 = uic;
	}
	private HtmlOutputText outputText3 = new HtmlOutputText();

	public HtmlOutputText getOutputText3() {
		return outputText3;
	}

	public void setOutputText3(HtmlOutputText hot) {
		this.outputText3 = hot;
	}
	private HtmlOutputText outputText4 = new HtmlOutputText();

	public HtmlOutputText getOutputText4() {
		return outputText4;
	}

	public void setOutputText4(HtmlOutputText hot) {
		this.outputText4 = hot;
	}
	private UIColumn column3 = new UIColumn();

	public UIColumn getColumn3() {
		return column3;
	}

	public void setColumn3(UIColumn uic) {
		this.column3 = uic;
	}
	private HtmlOutputText outputText5 = new HtmlOutputText();

	public HtmlOutputText getOutputText5() {
		return outputText5;
	}

	public void setOutputText5(HtmlOutputText hot) {
		this.outputText5 = hot;
	}
	private HtmlOutputText outputText6 = new HtmlOutputText();

	public HtmlOutputText getOutputText6() {
		return outputText6;
	}

	public void setOutputText6(HtmlOutputText hot) {
		this.outputText6 = hot;
	}
	private MessageGroup messageGroup1 = new MessageGroup();

	public MessageGroup getMessageGroup1() {
		return messageGroup1;
	}

	public void setMessageGroup1(MessageGroup mg) {
		this.messageGroup1 = mg;
	}
	private HtmlOutputText outputText7 = new HtmlOutputText();

	public HtmlOutputText getOutputText7() {
		return outputText7;
	}

	public void setOutputText7(HtmlOutputText hot) {
		this.outputText7 = hot;
	}
	private UIColumn column4 = new UIColumn();

	public UIColumn getColumn4() {
		return column4;
	}

	public void setColumn4(UIColumn uic) {
		this.column4 = uic;
	}
	private HtmlOutputText outputText8 = new HtmlOutputText();

	public HtmlOutputText getOutputText8() {
		return outputText8;
	}

	public void setOutputText8(HtmlOutputText hot) {
		this.outputText8 = hot;
	}
	private HtmlOutputText outputText9 = new HtmlOutputText();

	public HtmlOutputText getOutputText9() {
		return outputText9;
	}

	public void setOutputText9(HtmlOutputText hot) {
		this.outputText9 = hot;
	}
	private UIColumn column5 = new UIColumn();

	public UIColumn getColumn5() {
		return column5;
	}

	public void setColumn5(UIColumn uic) {
		this.column5 = uic;
	}
	private HtmlOutputText outputText10 = new HtmlOutputText();

	public HtmlOutputText getOutputText10() {
		return outputText10;
	}

	public void setOutputText10(HtmlOutputText hot) {
		this.outputText10 = hot;
	}
	private HtmlOutputText outputText11 = new HtmlOutputText();

	public HtmlOutputText getOutputText11() {
		return outputText11;
	}

	public void setOutputText11(HtmlOutputText hot) {
		this.outputText11 = hot;
	}
	private UIColumn column7 = new UIColumn();

	public UIColumn getColumn7() {
		return column7;
	}

	public void setColumn7(UIColumn uic) {
		this.column7 = uic;
	}
	private HtmlOutputText outputText12 = new HtmlOutputText();

	public HtmlOutputText getOutputText12() {
		return outputText12;
	}

	public void setOutputText12(HtmlOutputText hot) {
		this.outputText12 = hot;
	}
	private HtmlOutputText outputText13 = new HtmlOutputText();

	public HtmlOutputText getOutputText13() {
		return outputText13;
	}

	public void setOutputText13(HtmlOutputText hot) {
		this.outputText13 = hot;
	}
	private UIColumn column6 = new UIColumn();

	public UIColumn getColumn6() {
		return column6;
	}

	public void setColumn6(UIColumn uic) {
		this.column6 = uic;
	}
	private HtmlOutputText outputText15 = new HtmlOutputText();

	public HtmlOutputText getOutputText15() {
		return outputText15;
	}

	public void setOutputText15(HtmlOutputText hot) {
		this.outputText15 = hot;
	}
	private UIColumn column8 = new UIColumn();

	public UIColumn getColumn8() {
		return column8;
	}

	public void setColumn8(UIColumn uic) {
		this.column8 = uic;
	}
	private HtmlOutputText outputText1 = new HtmlOutputText();

	public HtmlOutputText getOutputText1() {
		return outputText1;
	}

	public void setOutputText1(HtmlOutputText hot) {
		this.outputText1 = hot;
	}
	private Button downloadButton = new Button();

	public Button getDownloadButton() {
		return downloadButton;
	}

	public void setDownloadButton(Button b) {
		this.downloadButton = b;
	}
	private Form form2 = new Form();

	public Form getForm2() {
		return form2;
	}

	public void setForm2(Form f) {
		this.form2 = f;
	}
	private Form form3 = new Form();

	public Form getForm3() {
		return form3;
	}

	public void setForm3(Form f) {
		this.form3 = f;
	}
	private Hyperlink hyperlink1 = new Hyperlink();

	public Hyperlink getHyperlink1() {
		return hyperlink1;
	}

	public void setHyperlink1(Hyperlink h) {
		this.hyperlink1 = h;
	}
	private HtmlOutputLink hyperlink2 = new HtmlOutputLink();

	public HtmlOutputLink getHyperlink2() {
		return hyperlink2;
	}

	public void setHyperlink2(HtmlOutputLink hol) {
		this.hyperlink2 = hol;
	}
	private HtmlOutputText hyperlink2Text = new HtmlOutputText();

	public HtmlOutputText getHyperlink2Text() {
		return hyperlink2Text;
	}

	public void setHyperlink2Text(HtmlOutputText hot) {
		this.hyperlink2Text = hot;
	}
	private HtmlOutputText outputText14 = new HtmlOutputText();

	public HtmlOutputText getOutputText14() {
		return outputText14;
	}

	public void setOutputText14(HtmlOutputText hot) {
		this.outputText14 = hot;
	}
	private HtmlOutputText outputText16 = new HtmlOutputText();

	public HtmlOutputText getOutputText16() {
		return outputText16;
	}

	public void setOutputText16(HtmlOutputText hot) {
		this.outputText16 = hot;
	}
	private StaticText staticText1 = new StaticText();

	public StaticText getStaticText1() {
		return staticText1;
	}

	public void setStaticText1(StaticText st) {
		this.staticText1 = st;
	}
	private HtmlPanelGrid gridPanel1 = new HtmlPanelGrid();

	public HtmlPanelGrid getGridPanel1() {
		return gridPanel1;
	}

	public void setGridPanel1(HtmlPanelGrid hpg) {
		this.gridPanel1 = hpg;
	}
	private HtmlPanelGrid gridPanel2 = new HtmlPanelGrid();

	public HtmlPanelGrid getGridPanel2() {
		return gridPanel2;
	}

	public void setGridPanel2(HtmlPanelGrid hpg) {
		this.gridPanel2 = hpg;
	}
	private HiddenField hiddenField1 = new HiddenField();

	public HiddenField getHiddenField1() {
		return hiddenField1;
	}

	public void setHiddenField1(HiddenField hf) {
		this.hiddenField1 = hf;
	}
	private HiddenField hiddenField2 = new HiddenField();

	public HiddenField getHiddenField2() {
		return hiddenField2;
	}

	public void setHiddenField2(HiddenField hf) {
		this.hiddenField2 = hf;
	}
	private HiddenField hiddenField3 = new HiddenField();

	public HiddenField getHiddenField3() {
		return hiddenField3;
	}

	public void setHiddenField3(HiddenField hf) {
		this.hiddenField3 = hf;
	}
	private HiddenField hiddenField4 = new HiddenField();

	public HiddenField getHiddenField4() {
		return hiddenField4;
	}

	public void setHiddenField4(HiddenField hf) {
		this.hiddenField4 = hf;
	}
	private StaticText staticText2 = new StaticText();

	public StaticText getStaticText2() {
		return staticText2;
	}

	public void setStaticText2(StaticText st) {
		this.staticText2 = st;
	}

	// </editor-fold>
	/**
	 * <p>Construct a new Page bean instance.</p>
	 */
	public search() {
	}

	/**
	 * <p>Callback method that is called whenever a page is navigated to,
	 * either directly via a URL, or indirectly via page navigation.
	 * Customize this method to acquire resources that will be needed
	 * for event handlers and lifecycle methods, whether or not this
	 * page is performing post back processing.</p>
	 * 
	 * <p>Note that, if the current request is a postback, the property
	 * values of the components do <strong>not</strong> represent any
	 * values submitted with this request.  Instead, they represent the
	 * property values that were saved for this view when it was rendered.</p>
	 */
	public void init() {
		// Perform initializations inherited from our superclass
		super.init();

		FacesContext fc = FacesContext.getCurrentInstance();
		HttpSession session = ((HttpSession) fc.getExternalContext().getSession(false));

		if (session != null) {
			session.invalidate();
		}
		// Perform application initialization that must complete
		// *before* managed components are initialized
		// TODO - add your own initialiation code here

		// <editor-fold defaultstate="collapsed" desc="Managed Component Initialization">
		// Initialize automatically managed components
		// *Note* - this logic should NOT be modified
		try {
			_init();
		} catch (Exception e) {
			log("search Initialization Failure", e);
			throw e instanceof FacesException ? (FacesException) e : new FacesException(e);
		}

	// </editor-fold>
	// Perform application initialization that must complete
	// *after* managed components are initialized
	// TODO - add your own initialization code here
	}

	/**
	 * <p>Callback method that is called after the component tree has been
	 * restored, but before any event processing takes place.  This method
	 * will <strong>only</strong> be called on a postback request that
	 * is processing a form submit.  Customize this method to allocate
	 * resources that will be required in your event handlers.</p>
	 */
	public void preprocess() {
	}

	/**
	 * <p>Callback method that is called just before rendering takes place.
	 * This method will <strong>only</strong> be called for the page that
	 * will actually be rendered (and not, for example, on a page that
	 * handled a postback and then navigated to a different page).  Customize
	 * this method to allocate resources that will be required for rendering
	 * this page.</p>
	 */
	public void prerender() {
	}

	/**
	 * <p>Callback method that is called after rendering is completed for
	 * this request, if <code>init()</code> was called (regardless of whether
	 * or not this was the page that was actually rendered).  Customize this
	 * method to release resources acquired in the <code>init()</code>,
	 * <code>preprocess()</code>, or <code>prerender()</code> methods (or
	 * acquired during execution of an event handler).</p>
	 */
	public void destroy() {
	}

	public String searchButton_action() {
		Object value;
		String[] searchString = new String[1];

		value = searchTextField.getValue();
		
		if (value != null) {
            try {
                searchString[0] = ((String) value).trim();

                SearchDetails searchDetails = new SearchDetails(searchString, searchString, searchString, -1, searchString, -1, searchString, 0);
                Collection result;

                result = lookupAteneoBean().searchDocuments(searchDetails);
                getAteneoRequestBean().setSearchResult(result);
            } catch (WebServiceException ex) {
                error(ex.getMessage());
            }
		}
		
		return null;
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected AteneoSessionBean getAteneoSessionBean() {
		return (AteneoSessionBean) getBean("AteneoSessionBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected AteneoApplicationBean getAteneoApplicationBean() {
		return (AteneoApplicationBean) getBean("AteneoApplicationBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected AteneoRequestBean getAteneoRequestBean() {
		return (AteneoRequestBean) getBean("AteneoRequestBean");
	}

	private AteneoLocal lookupAteneoBean() {
		try {
			Context c = new InitialContext();
			AteneoLocalHome rv = (AteneoLocalHome) c.lookup("java:comp/env/AteneoBean");
			return rv.create();
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		} catch (CreateException ce) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
			throw new RuntimeException(ce);
		}
	}
}

