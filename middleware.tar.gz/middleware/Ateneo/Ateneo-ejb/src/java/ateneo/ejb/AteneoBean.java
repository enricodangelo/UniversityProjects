/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ateneo.ejb;

import dipartimento.ws.DipartimentoWS;
import java.net.MalformedURLException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import utils.SearchDetails;
import utils.SearchResult;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import java.rmi.RemoteException;
import dipartimento.ws.DipartimentoWS;
import javax.xml.namespace.QName;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import javax.ejb.FinderException;
import javax.xml.rpc.ServiceFactory;
import utils.DocumentDetails;
import utils.ID;
import utils.SearchResult;
import utils.exceptions.FinderCatalogException;
import utils.exceptions.WebServiceException;

/**
 *
 * @author benve
 */
public class AteneoBean implements SessionBean {

	private SessionContext context;
	private DepartmentLocalHome dipHome;


	// <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click the + sign on the left to edit the code.">;
	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(SessionContext aContext) {
		context = aContext;
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() {

	}

	// </editor-fold>;
	/**
	 * See section 7.10.3 of the EJB 2.0 specification
	 * See section 7.11.3 of the EJB 2.1 specification
	 */
	public void ejbCreate() {
		dipHome = lookupDepartmentBean();
	}

	public Collection getAllDepartments() {//TODO: gestire eccezioni
		Collection result = null;

		try {
			result = dipHome.findAllDepartments();
		} catch (FinderException ex) {
			ex.printStackTrace();
		}

		return result;
	}

	public Collection getCatalog() throws FinderCatalogException, WebServiceException {
		ArrayList c = new ArrayList();
		DepartmentLocal dep = null;

		try {
			Collection dipartimenti = dipHome.findAllDepartments();

			for (Iterator it = dipartimenti.iterator(); it.hasNext();) {
				c.addAll(getCatalog(((DepartmentLocal) it.next()).getPk()));
			}
		} catch (FinderException ex) {
			throw new FinderCatalogException("Impossibile trovare i dipartimenti");
		}
		return c;
	}

	public Collection getCatalog(String depname) throws WebServiceException {
		ArrayList c = new ArrayList();
		try {
			DepartmentLocal dep = dipHome.findByPrimaryKey(depname);
			SearchResult[] sr = getWS(dep).getAllDocuments();
			for (int i = 0; i < sr.length; i++) {
				sr[i].setDepartment(dep.getPk());
				c.add(new DocumentDetails(sr[i]));
			}

		} catch (RemoteException ex) {
			throw new WebServiceException("Impossibile connettersi al dipartimento:" + depname);
		} catch (FinderException ex) {
			throw new WebServiceException("Impossibile connettersi al dipartimento:" + depname);
		}

		return c;
	}

	public Collection searchDocuments(SearchDetails searchDetails, String department) throws WebServiceException {
		ArrayList c = new ArrayList();
		try {
			DepartmentLocal departmentLocal = lookupDepartmentBean().findByPrimaryKey(department);
			SearchResult[] sr = getWS(departmentLocal).getDocuments(searchDetails);
			for (int i = 0; i < sr.length; i++) {
				c.add(new DocumentDetails(sr[i]));
			}
		} catch (RemoteException ex) {
			throw new WebServiceException("Impossibile connettersi al dipartimento:" + department);
		} catch (FinderException ex) {
			throw new WebServiceException("Impossibile connettersi al dipartimento:" + department);
		}

		return c;
	}

	public Collection searchDocuments(SearchDetails searchDetails) throws WebServiceException {
		ArrayList c = new ArrayList();
		try {
			Collection dipartimenti = dipHome.findAllDepartments();

			for (Iterator it = dipartimenti.iterator(); it.hasNext();) {
				DepartmentLocal dep = (DepartmentLocal) it.next();
				SearchResult[] sr = getWS(dep).getDocuments(searchDetails);
				for (int i = 0; i < sr.length; i++) {
					c.add(new DocumentDetails(sr[i]));
				}
			}
		} catch (RemoteException ex) {
			throw new WebServiceException("Impossibile connettersi al dipartimento");
		} catch (FinderException ex) {
			throw new WebServiceException("Impossibile connettersi al dipartimento");
		}

		return c;
	}

	private DipartimentoWS getWS(DepartmentLocal dipartimento) throws WebServiceException {
		DipartimentoWS ws = null;
		try {
			URL url = new URL("http://" + dipartimento.getUrl() + "/Dipartimento-ejb/DipartimentoWSBean?WSDL");
			QName qname = new QName("http://ejb.dipartimento/", "DipartimentoService");
			ServiceFactory factory = ServiceFactory.newInstance();
			Service service = factory.createService(url, qname);
			ws = (DipartimentoWS) service.getPort(DipartimentoWS.class);

		} catch (ServiceException ex) {
			throw new WebServiceException("Impossibile connettersi a" + dipartimento.getUrl());
		} catch (MalformedURLException ex) {
			throw new WebServiceException("Impossibile connettersi a" + dipartimento.getUrl());
		}
		return ws;
	}

	public byte[] downloadDocument(String id) throws WebServiceException {
		try {

			ID myID = new ID(id);

			DepartmentLocal dep = dipHome.findByPrimaryKey(myID.getDepartment());
			byte[] file = getWS(dep).getDocumentFile(id);

			return file;

		} catch (RemoteException ex) {
			throw new WebServiceException("Impossibile connettersi al dipartimento");
		} catch (FinderException ex) {
			throw new WebServiceException("Impossibile connettersi al dipartimento");
		}

	}

	private DepartmentLocalHome lookupDepartmentBean() {
		try {
			Context c = new InitialContext();
			DepartmentLocalHome rv = (DepartmentLocalHome) c.lookup("java:comp/env/DepartmentBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}
}
