/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ateneo.ejb;

import javax.ejb.EJBLocalObject;

/**
 *
 * @author benve
 */
public interface DepartmentLocal extends EJBLocalObject {

    java.lang.String getPk();

    String getUrl();

    void setUrl(String url);

    String getName();

    void setName(String name);

}
