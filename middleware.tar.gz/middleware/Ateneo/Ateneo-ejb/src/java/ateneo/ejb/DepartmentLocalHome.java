/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ateneo.ejb;

import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;

/**
 *
 * @author benve
 */
public interface DepartmentLocalHome extends EJBLocalHome {

    ateneo.ejb.DepartmentLocal findByPrimaryKey(java.lang.String key)  throws FinderException;
    
    ateneo.ejb.DepartmentLocal create(java.lang.String key)  throws CreateException;

    Collection findAllDepartments() throws FinderException;

}
