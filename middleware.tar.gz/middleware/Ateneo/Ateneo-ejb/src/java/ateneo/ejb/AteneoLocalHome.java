/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ateneo.ejb;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 *
 * @author benve
 */
public interface AteneoLocalHome extends EJBLocalHome {
    
    ateneo.ejb.AteneoLocal create()  throws CreateException;

}
