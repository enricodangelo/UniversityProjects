/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ateneo.ejb;

import java.util.Collection;
import javax.ejb.EJBLocalObject;
import utils.SearchDetails;
import utils.exceptions.FinderCatalogException;
import utils.exceptions.WebServiceException;

/**
 *
 * @author benve
 */
public interface AteneoLocal extends EJBLocalObject {

	Collection getCatalog() throws FinderCatalogException, WebServiceException;

	Collection searchDocuments(SearchDetails searchDetails) throws WebServiceException;

	Collection getCatalog(String depname) throws WebServiceException;

	byte[] downloadDocument(String id) throws WebServiceException;

	Collection getAllDepartments();

	Collection searchDocuments(SearchDetails searchDetails, String department) throws WebServiceException;
}
