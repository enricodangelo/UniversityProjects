package itext_prove;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author satomi
 */
public class Main {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		if (args.length < 6) {
			System.out.println("Usage: makepdf <AUTHORS> <TITLE> <ID> <KEYWORDS> <CREATION DATE> <TYPE> [<FILE NAME>]");
		} else {
			try {
				String authors = args[0];
				String title = args[1];
				String id = args[2];
				String keywords = args[3];
				String creationDate = args[4];
				String type = args[5];
				String filename = "file.pdf";
				if ((args.length > 6) && (args[6] != null)) {filename = args[6];}
				String content = "";
				
				Document document = new Document();
				PdfWriter.getInstance(document, new FileOutputStream(filename));

				document.addAuthor(authors);
				document.addTitle(title);
				document.addHeader("ID", id);
				document.addKeywords(keywords);
				document.addHeader("Created", creationDate);
				document.addHeader("Type", type);
				
				content = "authors = " + authors + "\n" +
								"title = " + title + "\n" +
								"id = " + id + "\n" +
								"keywords = " + keywords + "\n" +
								"creationDate = " + creationDate + "\n" +
								"type = " + type + "\n";
				
				document.open();

				document.add(new Paragraph(content));

				document.close();

			} catch (DocumentException ex) {
				Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
			} catch (FileNotFoundException ex) {
				Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}
}
