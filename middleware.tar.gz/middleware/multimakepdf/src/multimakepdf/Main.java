package multimakepdf;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

	public static void main(String[] args) {
		File inputFile = new File(args[0]);
		
		if (args.length != 1) {
			System.out.println("TODO");
		} else {
			DataInputStream inputStream = null;
			try {
				inputStream = new DataInputStream(new BufferedInputStream(new FileInputStream(inputFile)));

				while (inputStream.available() != 0) {
					String authors = "";
					String title = "";
					String id = "";
					String keywords = "";
					String creationDate = "";
					String type = "";
					String outputFileName = "";
					String content = "";
					String line = inputStream.readLine();

					StringTokenizer lineToken = new StringTokenizer(line, ";");
					while (lineToken.hasMoreTokens()) {
						authors = lineToken.nextToken().trim();
						title = lineToken.nextToken().trim();
						id = lineToken.nextToken().trim();
						keywords = lineToken.nextToken().trim();
						creationDate = lineToken.nextToken().trim();
						type = lineToken.nextToken().trim();
						outputFileName = lineToken.nextToken().trim();
					}

					Document document = new Document();
					PdfWriter.getInstance(document, new FileOutputStream(outputFileName));

					document.addAuthor(authors);
					document.addTitle(title);
					document.addHeader("ID", id);
					document.addKeywords(keywords);
					document.addHeader("Created", creationDate);
					document.addHeader("Type", type);

					content = "authors = " + authors + "\n" +
									"title = " + title + "\n" +
									"id = " + id + "\n" +
									"keywords = " + keywords + "\n" +
									"creationDate = " + creationDate + "\n" +
									"type = " + type + "\n";

					document.open();

					document.add(new Paragraph(content));

					document.close();
				}
			} catch (DocumentException ex) {
				Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
			} catch (IOException ex) {
				Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
			} finally {
				try {
					inputStream.close();
				} catch (IOException ex) {
					Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		}
	}
}
