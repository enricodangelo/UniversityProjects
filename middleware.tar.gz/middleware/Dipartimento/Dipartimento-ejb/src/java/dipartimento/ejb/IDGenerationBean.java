/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import java.util.Calendar;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import utils.ID;
import utils.exceptions.DuplicateIDException;

/**
 *
 * @author benve
 */
public abstract class IDGenerationBean implements EntityBean {

	private AuthorLocalHome authorHome;
	private PendingIDLocalHome pendingHome;
	private EntityContext context;

	// <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click on the + sign on the left to edit the code.">

	/**
	 * @see javax.ejb.EntityBean#setEntityContext(javax.ejb.EntityContext)
	 */
	public void setEntityContext(EntityContext aContext) {
		context = aContext;
	}

	/**
	 * @see javax.ejb.EntityBean#ejbActivate()
	 */
	public void ejbActivate() {

	}

	/**
	 * @see javax.ejb.EntityBean#ejbPassivate()
	 */
	public void ejbPassivate() {

	}

	/**
	 * @see javax.ejb.EntityBean#ejbRemove()
	 */
	public void ejbRemove() {
	
	}

	/**
	 * @see javax.ejb.EntityBean#unsetEntityContext()
	 */
	public void unsetEntityContext() {
		context = null;
	}

	/**
	 * @see javax.ejb.EntityBean#ejbLoad()
	 */
	public void ejbLoad() {

	}

	/**
	 * @see javax.ejb.EntityBean#ejbStore()
	 */
	public void ejbStore() {

	}

	// </editor-fold>
	
	public abstract java.lang.String getPk();

	public abstract void setPk(java.lang.String key);
	
	public java.lang.String ejbCreate() throws CreateException {
		return null;
	}

	public void ejbPostCreate() {
	}

	public abstract String getDepName();

	public abstract void setDepName(String depName);

	public abstract int getYear();
	
	public abstract void setYear(int year);

	public abstract int getId();

	public abstract void setId(int id);

	public ID getNextID() throws DuplicateIDException {
		int year = Calendar.getInstance().get(Calendar.YEAR);

		if (pendingHome == null) {
			pendingHome = lookupPendingIDBean();
		}

		if (authorHome == null) {
			authorHome = lookupAuthorBean();
		}

		if (getYear() != year) {
			setYear(year);
			setId(0);
		}

		int changevalue = getId();
		changevalue++;
		setId(changevalue);
		//ID newID = new ID(getDepName(), new Integer(year), new Integer(changevalue));
		ID newID = new ID(getPk(), new Integer(year), new Integer(changevalue));

		try {
			if (pendingHome.findByPrimaryKey(newID.toString()) != null) {
				throw new DuplicateIDException(newID.toString());
			}
		} catch (FinderException ex) {}

		try {
			PendingIDLocal pending = pendingHome.create(newID.toString());
			AuthorLocal author = authorHome.findByPrimaryKey(context.getCallerPrincipal().getName());
			pending.setAuthor(author);

		} catch (CreateException ex) {
			ex.printStackTrace();
		} catch (FinderException ex) {
			ex.printStackTrace();
		}

		return newID;
	}

	private AuthorLocalHome lookupAuthorBean() {
		try {
			Context c = new InitialContext();
			AuthorLocalHome rv = (AuthorLocalHome) c.lookup("java:comp/env/AuthorBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}

	}

	private PendingIDLocalHome lookupPendingIDBean() {
		try {
			Context c = new InitialContext();
			PendingIDLocalHome rv = (PendingIDLocalHome) c.lookup("java:comp/env/PendingIDBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}
}
