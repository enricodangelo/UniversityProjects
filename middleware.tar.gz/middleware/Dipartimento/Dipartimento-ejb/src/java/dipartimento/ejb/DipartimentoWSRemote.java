/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import utils.SearchDetails;
import utils.SearchResult;

/**
 *
 * @author benve
 */
public interface DipartimentoWSRemote extends EJBObject {

    SearchResult[] getAllDocuments() throws RemoteException;
    
    byte[] getDocumentFile(String id) throws RemoteException;
		
    SearchResult[] getDocuments(SearchDetails sd) throws RemoteException;
}
