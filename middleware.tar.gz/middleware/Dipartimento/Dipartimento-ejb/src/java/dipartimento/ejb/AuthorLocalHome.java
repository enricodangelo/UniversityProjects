/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;

/**
 *
 * @author satomi
 */
public interface AuthorLocalHome extends EJBLocalHome {

    dipartimento.ejb.AuthorLocal findByPrimaryKey(java.lang.String key)  throws FinderException;
    
    dipartimento.ejb.AuthorLocal create(java.lang.String key)  throws CreateException;

    dipartimento.ejb.AuthorLocal create(String id, String name) throws CreateException;

    AuthorLocal findByName(String name) throws FinderException;

}
