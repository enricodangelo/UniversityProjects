/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;

/**
 *
 * @author satomi
 */
public abstract class AuthorBean implements EntityBean {

	private EntityContext context;

	// <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click on the + sign on the left to edit the code.">

	/**
	 * @see javax.ejb.EntityBean#setEntityContext(javax.ejb.EntityContext)
	 */
	public void setEntityContext(EntityContext aContext) {
		context = aContext;
	}

	/**
	 * @see javax.ejb.EntityBean#ejbActivate()
	 */
	public void ejbActivate() {

	}

	/**
	 * @see javax.ejb.EntityBean#ejbPassivate()
	 */
	public void ejbPassivate() {

	}

	/**
	 * @see javax.ejb.EntityBean#ejbRemove()
	 */
	public void ejbRemove() {

	}

	/**
	 * @see javax.ejb.EntityBean#unsetEntityContext()
	 */
	public void unsetEntityContext() {
		context = null;
	}

	/**
	 * @see javax.ejb.EntityBean#ejbLoad()
	 */
	public void ejbLoad() {

	}

	/**
	 * @see javax.ejb.EntityBean#ejbStore()
	 */
	public void ejbStore() {

	}

	// </editor-fold>
	
	public abstract java.lang.String getPk();

	public abstract void setPk(java.lang.String key);

	public java.lang.String ejbCreate(java.lang.String key) throws CreateException {
		if (key == null) {
			throw new CreateException("The field \"key\" must not be null");
		}

		setPk(key);

		return null;
	}

	public void ejbPostCreate(java.lang.String key) {
	}

	public abstract String getName();

	public abstract void setName(String name);

	public abstract java.util.Collection getDocuments();

	public abstract void setDocuments(java.util.Collection value);

	public abstract java.util.Collection getPendingIDs();

	public abstract void setPendingIDs(java.util.Collection ids);

	public String ejbCreate(String id, String name) throws CreateException {
		setPk(id);
		setName(name);

		return id;
	}

	public void ejbPostCreate(String id, String name) throws CreateException {
	}
}
