/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import utils.DocumentDetails;
import utils.exceptions.ConflictingDocException;
import utils.exceptions.CreateDocException;
import utils.exceptions.FinderAuthorException;

/**
 *
 * @author benve
 */
public class AdminBean implements SessionBean {

	private PendingIDLocalHome pendingHome;
	private AuthorLocalHome authorHome;
	private IDGenerationLocalHome idgenHome;
	private DocumentLocalHome documentHome;
	private SessionContext context;

	// <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click the + sign on the left to edit the code.">;
	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(SessionContext aContext) {
		context = aContext;
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() {

	}

	// </editor-fold>;
	/**
	 * See section 7.10.3 of the EJB 2.0 specification
	 * See section 7.11.3 of the EJB 2.1 specification
	 */
	public void ejbCreate() {
		idgenHome = lookupIDGenerationBean();
		authorHome = lookupAuthorBean();
		pendingHome = lookupPendingIDBean();
		documentHome = lookupDocumentBean();
	}

	public void createAuthor(String id, String name) throws CreateException {
		AuthorLocal author = authorHome.create(id, name);
	}

	public void loadServerDir(String dir) {
		DipartimentoLocal dipartimento = lookupDipartimentoBean();
		File directory = new File(dir);
		if (directory.isDirectory()) {
			File[] files = directory.listFiles();
			for (int i = 0; i < files.length; i++) {
				try {
					File file = files[i];
					if (file.getName().endsWith(".pdf")) {
						DocumentDetails dd = DocumentDetails.makeDocumentDetails(file);
						DocumentLocal doc = null;

						try {
							doc = documentHome.findByPrimaryKey(dd.getDocID().toString());
						} catch (FinderException ex) {
						}
						if (doc != null) {
							throw new ConflictingDocException(dd.getDocID().toString());
						}

						ArrayList authors = new ArrayList();//Salvo bean degli autori del documento

						Iterator it = dd.getAuthors().iterator();
						String currentAuthor = "";
						while (it.hasNext()) {
							try {
								currentAuthor = (String) it.next();
								AuthorLocal tmpAuthor = authorHome.findByName((currentAuthor));//controllo se l'autore appartiene al DB degli autori
								authors.add(tmpAuthor);//Salvo bean degli autori del documento

							} catch (FinderException ex) {
								throw new FinderAuthorException(currentAuthor);
							}

						}

						//creo il documento
						try {
							doc = documentHome.create(dd);
						} catch (CreateException ex) {
							throw new CreateDocException(dd.getDocID().toString());
						}

						//creo la relazione tra documento ed autori
						doc.setAuthors(authors);

					}
				} catch (ConflictingDocException ex) {
					ex.printStackTrace();
				} catch (FinderAuthorException ex) {
					ex.printStackTrace();
				} catch (CreateDocException ex) {
					ex.printStackTrace();
				} catch (IOException ex) {
					ex.printStackTrace();
				} catch (ParseException ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	private IDGenerationLocalHome lookupIDGenerationBean() {
		try {
			Context c = new InitialContext();
			IDGenerationLocalHome rv = (IDGenerationLocalHome) c.lookup("java:comp/env/IDGenerationBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private AuthorLocalHome lookupAuthorBean() {
		try {
			Context c = new InitialContext();
			AuthorLocalHome rv = (AuthorLocalHome) c.lookup("java:comp/env/AuthorBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private PendingIDLocalHome lookupPendingIDBean() {
		try {
			Context c = new InitialContext();

			PendingIDLocalHome rv = (PendingIDLocalHome) c.lookup("java:comp/env/PendingIDBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private DocumentLocalHome lookupDocumentBean() {
		try {
			Context c = new InitialContext();
			DocumentLocalHome rv = (DocumentLocalHome) c.lookup("java:comp/env/DocumentBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private DipartimentoLocal lookupDipartimentoBean() {
		try {
			Context c = new InitialContext();
			DipartimentoLocalHome rv = (DipartimentoLocalHome) c.lookup("java:comp/env/DipartimentoBean");
			return rv.create();
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		} catch (CreateException ce) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
			throw new RuntimeException(ce);
		}
	}
}
