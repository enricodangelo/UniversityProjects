/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import javax.ejb.EJBLocalObject;

/**
 *
 * @author benve
 */
public interface PendingIDLocal extends EJBLocalObject {

    java.lang.String getPk();
    
    dipartimento.ejb.AuthorLocal getAuthor();
    
    void setAuthor(dipartimento.ejb.AuthorLocal author);

}
