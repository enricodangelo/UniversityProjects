/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 *
 * @author satomi
 */
public interface UserInfoLocalHome extends EJBLocalHome {
    
    dipartimento.ejb.UserInfoLocal create()  throws CreateException;

}
