/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import javax.ejb.EJBLocalObject;
import utils.SearchDetails;
import utils.SearchResult;

/**
 *
 * @author benve
 */
public interface DipartimentoWSLocal extends EJBLocalObject {

    SearchResult[] getAllDocuments();
    
    byte[] getDocumentFile(String id);
    
    SearchResult[] getDocuments(SearchDetails sd);
    
}
