/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import java.util.ArrayList;
import java.util.Iterator;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import utils.ID;
import utils.DocumentDetails;
import utils.exceptions.*;

/**
 *
 * @author satomi
 */
public class DipartimentoBean implements SessionBean {

	private PendingIDLocalHome pendingidHome;
	private AuthorLocalHome authorHome;
	private DocumentLocalHome docHome;
	private IDGenerationLocalHome idgenHome;
	private SessionContext context;

	// <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click the + sign on the left to edit the code.">;
	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(SessionContext aContext) {
		context = aContext;
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() {

	}

	// </editor-fold>;
	/**
	 * See section 7.10.3 of the EJB 2.0 specification
	 * See section 7.11.3 of the EJB 2.1 specification
	 */
	public void ejbCreate() {
		idgenHome = lookupIDGenerationBean();
		docHome = lookupDocumentBean();
		authorHome = lookupAuthorBean();
		pendingidHome = lookupPendingIDBean();
	}
	
	public ID getNewID() throws DuplicateIDException, DatabaseInitializationException {
		ArrayList ids = null;
		IDGenerationLocal id = null;

		if (idgenHome == null) {
			throw new DatabaseInitializationException("IDGenerationBean non è presente.");
		}
		
		try {
			ids = (ArrayList) idgenHome.findAllID();
		} catch (FinderException ex) {
			throw new DatabaseInitializationException("IDGenerationBean non contiene alcun elemento.");
		}
		//ids contiene sempre un solo elemento
		id = (IDGenerationLocal) ids.get(0);

		return id.getNextID();
	}

	public void uploadDocument(DocumentDetails documentDetails) throws ConflictingDocException, NotReservedIDException, UnallowedUserException, FinderAuthorException, CreateDocException, RemoveException {
		DocumentLocal doc = null;
		AuthorLocal author = null;
		PendingIDLocal pendingid = null;
		String id = documentDetails.getDocID().toString();
		String user = context.getCallerPrincipal().getName();

		// Controllo che il documento non sia già stato inserito
		try {
			doc = docHome.findByPrimaryKey(id);
		} catch (FinderException ex) {
		}
		if (doc != null) {
			throw new ConflictingDocException(id);
		}

		//Controllo che l'ids sia pendente e che sia stato richiesto dall'autore
		try {
			pendingid = pendingidHome.findByPrimaryKey(id);
		} catch (FinderException ex) {
			throw new NotReservedIDException(id);
		}

		author = pendingid.getAuthor();

		if (!author.getPk().equals(user)) {
			throw new UnallowedUserException(user);
		}

		ArrayList authors = new ArrayList();//Salvo bean degli autori del documento

		//Controllo che l'utente sia presente tra gli autori del documento e che tutti gli autori esistano
		//tutti gli autori devono essere presenti nel DB!!! se non ci sono è un errore!!
		boolean ok = false;
		Iterator i = documentDetails.getAuthors().iterator();
		String currentAuthor = "";
		while (i.hasNext()) {
			try {
				currentAuthor = (String) i.next();
				AuthorLocal tmpAuthor = authorHome.findByName((currentAuthor));//controllo se l'autore appartiene al DB degli autori
				authors.add(tmpAuthor);//Salvo bean degli autori del documento
				if (tmpAuthor.equals(author) && !ok) {
					ok = true;
				}
			} catch (FinderException ex) {
				throw new FinderAuthorException(currentAuthor);
			}
		}

		if (!ok) {
			throw new UnallowedUserException(user);
		}

		//creo il documento
		try {
			doc = docHome.create(documentDetails);
		} catch (CreateException ex) {
			throw new CreateDocException(id);
		}

		//creo la relazione tra documento ed autori
		doc.setAuthors(authors);

		// cancello l'ids del documento tra quelli pendenti dell'autore
		pendingid.remove();
	}

	public void updateDocument(DocumentDetails documentDetails) throws FinderDocException, UnallowedUserException, FinderAuthorException {
		DocumentLocal doc = null;
		String id = documentDetails.getDocID().toString();
		String user = context.getCallerPrincipal().getName();

		//Controllo che il documento sia già stato inserito
		try {
			doc = docHome.findByPrimaryKey(id);
		} catch (FinderException ex) {
			throw new FinderDocException(id);
		}

		//Controllo che l'utente sia presente tra gli autori del _vechhio_ documento
		boolean ok = false;
		Iterator k = doc.getAuthors().iterator();
		while (k.hasNext() && !ok) {
			if (((AuthorLocal) k.next()).getPk().equals(user)) {
				ok = true;
			}
		}
		if (!ok) {
			throw new UnallowedUserException(user);
		}

		//Controllo che l'utente sia presente tra gli autori del _nuovo_ documento
		//Controllo che tutti gli autori del nuovo documento esistano del DB degli autori
		ArrayList authors = new ArrayList();//Salvo bean degli autori del documento
		ok = false;
		Iterator i = documentDetails.getAuthors().iterator();
		String currentAuthor = "";
		while (i.hasNext()) {
			try {
				currentAuthor = (String) i.next();
				AuthorLocal tmpAuthor = authorHome.findByName((currentAuthor));//controllo se l'autore appartiene al DB degli autori
				authors.add(tmpAuthor);//Salvo bean degli autori del documento
				if (tmpAuthor.getPk().equals(user) && !ok) {
					ok = true;
				}
			} catch (FinderException ex) {
				throw new FinderAuthorException(currentAuthor);
			}
		}

		if (!ok) {
			throw new UnallowedUserException(user);
		}

		//Aggiorno Documento  DocumentLocal.update(DocumentDetails documentDetails)
		doc.update(documentDetails);

		//Sostituisco le vecchie relazioni tra il Documento e gli Autori con le nuove
		doc.setAuthors(authors);
	}

	public void deleteDocument(ID documentID) throws FinderDocException, UnallowedUserException, RemoveException {
		DocumentLocal doc = null;
		String user = context.getCallerPrincipal().getName();

		//Controllo che il documento sia già stato inserito
		try {
			doc = docHome.findByPrimaryKey(documentID.toString());
		} catch (FinderException ex) {
			throw new FinderDocException(documentID.toString());
		}

		//Controllo che l'utente sia presente tra gli autori del documento
		boolean ok = false;
		Iterator k = doc.getAuthors().iterator();
		while (k.hasNext() && !ok) {
			if (((AuthorLocal) k.next()).getPk().equals(user)) {
				ok = true;
			}
		}
		if (!ok) {
			throw new UnallowedUserException(user);
		}

		//Cancello tutte le relazioni
		doc.setAuthors(new ArrayList());

		//Cancello il documento
		doc.remove();
	}

	private IDGenerationLocalHome lookupIDGenerationBean() {
		try {
			Context c = new InitialContext();
			IDGenerationLocalHome rv = (IDGenerationLocalHome) c.lookup("java:comp/env/IDGenerationBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private DocumentLocalHome lookupDocumentBean() {
		try {
			Context c = new InitialContext();
			DocumentLocalHome rv = (DocumentLocalHome) c.lookup("java:comp/env/DocumentBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private AuthorLocalHome lookupAuthorBean() {
		try {
			Context c = new InitialContext();
			AuthorLocalHome rv = (AuthorLocalHome) c.lookup("java:comp/env/AuthorBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private PendingIDLocalHome lookupPendingIDBean() {
		try {
			Context c = new InitialContext();
			PendingIDLocalHome rv = (PendingIDLocalHome) c.lookup("java:comp/env/PendingIDBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}
}
