/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 *
 * @author benve
 */
public interface DipartimentoWSLocalHome extends EJBLocalHome {
    
    dipartimento.ejb.DipartimentoWSLocal create()  throws CreateException;

}
