/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import utils.ID;

/**
 *
 * @author satomi
 */
public class UserInfoBean implements SessionBean {

	private SessionContext context;

	// <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click the + sign on the left to edit the code.">;

	// TODO Add code to acquire and use other enterprise resources (DataSource, JMS, enterprise bean, Web services)
	// TODO Add business methods or web service operations
	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(SessionContext aContext) {
		context = aContext;
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() {

	}

	// </editor-fold>;
	/**
	 * See section 7.10.3 of the EJB 2.0 specification
	 * See section 7.11.3 of the EJB 2.1 specification
	 */
	public void ejbCreate() {
	}

	public String getUserName(String userID) {
		String userName = "";

		try {
			userName = lookupAuthorBean().findByPrimaryKey(userID).getName();
		} catch (FinderException ex) {
		//Se non trova niente significa che siamo loggati come amministratori
		//altrimenti il database non e' coerente in quanto esiste un utente autorizzato che non compare tra gli autori
		//ex.printStackTrace();
		} finally {
			return userName;
		}
	}

	//Ritorna una Collecrtion di oggetti di tipo ID
	public Collection getPendingIDs() {
		ArrayList pendingIDs = new ArrayList();

		try {
			Collection pids = lookupPendingIDBean().findByAuthor(context.getCallerPrincipal().getName());

			for (Iterator it = pids.iterator(); it.hasNext();) {
				pendingIDs.add(new ID(((PendingIDLocal) it.next()).getPk()));
			}
		} catch (FinderException ex) {
			ex.printStackTrace();
		}

		return pendingIDs;
	}

	public Collection getUserDocuments() {
		ArrayList documents = new ArrayList();

		try {
			Collection d = lookupDocumentBean().findByAuthor(context.getCallerPrincipal().getName());

			for (Iterator it = d.iterator(); it.hasNext();) {
				documents.add(((DocumentLocal) it.next()).getDocumentDetails());
			}
		} catch (FinderException ex) {
			ex.printStackTrace();
		}

		return documents;
	}
	
	public DocumentLocal getUserDocument(String docID) {
		DocumentLocal result;
		
		try {
			result = lookupDocumentBean().findByPrimaryKey(docID);
		} catch (FinderException ex) {
			result = null;
		}
		
		return result;
	}

	private PendingIDLocalHome lookupPendingIDBean() {
		try {
			Context c = new InitialContext();
			PendingIDLocalHome rv = (PendingIDLocalHome) c.lookup("java:comp/env/PendingIDBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private DocumentLocalHome lookupDocumentBean() {
		try {
			Context c = new InitialContext();
			DocumentLocalHome rv = (DocumentLocalHome) c.lookup("java:comp/env/DocumentBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private AuthorLocalHome lookupAuthorBean() {
		try {
			Context c = new InitialContext();
			AuthorLocalHome rv = (AuthorLocalHome) c.lookup("java:comp/env/AuthorBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

}
