/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import javax.ejb.EJBLocalObject;
import utils.DocumentDetails;

/**
 *
 * @author satomi
 */
public interface DocumentLocal extends EJBLocalObject {

    java.lang.String getPk();

    String getTitle();

    void setTitle(String title);

    long getCreationDate();

    void setCreationDate(long creationDate);

    int getType();

    void setType(int type);

    String getKeywords();

    void setKeywords(String keywords);

    void update(DocumentDetails documentDetails);

    java.util.Collection getAuthors();

    void setAuthors(java.util.Collection value);

    DocumentDetails getDocumentDetails();

    byte [] getFile();

    void setFile(byte [] file);

}
