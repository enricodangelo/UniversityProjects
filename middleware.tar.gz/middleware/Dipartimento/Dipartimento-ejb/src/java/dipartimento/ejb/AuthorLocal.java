/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import javax.ejb.EJBLocalObject;

/**
 *
 * @author satomi
 */
public interface AuthorLocal extends EJBLocalObject {

    java.lang.String getPk();

    String getName();

    void setName(String name);

    java.util.Collection getDocuments();

    void setDocuments(java.util.Collection value);
    
    java.util.Collection getPendingIDs();
        
    void setPendingIDs(java.util.Collection ids);
}
