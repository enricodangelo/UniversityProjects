/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;

/**
 *
 * @author benve
 */
public interface PendingIDLocalHome extends EJBLocalHome {

    dipartimento.ejb.PendingIDLocal findByPrimaryKey(java.lang.String key)  throws FinderException;
    
    dipartimento.ejb.PendingIDLocal create(java.lang.String key)  throws CreateException;

    Collection findAllPendigID() throws FinderException;

		Collection findByAuthor(String author) throws FinderException;

}
