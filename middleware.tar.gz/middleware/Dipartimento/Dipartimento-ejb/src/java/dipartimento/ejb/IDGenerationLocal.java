/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import javax.ejb.EJBLocalObject;
import utils.exceptions.DuplicateIDException;
import utils.ID;

/**
 *
 * @author benve
 */
public interface IDGenerationLocal extends EJBLocalObject {

	java.lang.String getPk();

	java.lang.String getDepName();

	ID getNextID() throws DuplicateIDException;

	void setDepName(String depName);

	int getYear();

	void setYear(int year);

	int getId();

	void setId(int id);
}
