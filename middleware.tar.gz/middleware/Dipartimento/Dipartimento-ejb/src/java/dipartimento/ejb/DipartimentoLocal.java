/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import utils.DocumentDetails;
import utils.ID;
import javax.ejb.EJBLocalObject;
import javax.ejb.RemoveException;
import utils.exceptions.*;

/**
 *
 * @author satomi
 */
public interface DipartimentoLocal extends EJBLocalObject {

	ID getNewID() throws DuplicateIDException, DatabaseInitializationException;

	void uploadDocument(DocumentDetails document) throws ConflictingDocException, NotReservedIDException, UnallowedUserException, FinderAuthorException, CreateDocException, RemoveException;
        
	void updateDocument(DocumentDetails document) throws FinderDocException, UnallowedUserException, FinderAuthorException;
        
	void deleteDocument(ID documentID) throws FinderDocException, UnallowedUserException, RemoveException;
    
}
