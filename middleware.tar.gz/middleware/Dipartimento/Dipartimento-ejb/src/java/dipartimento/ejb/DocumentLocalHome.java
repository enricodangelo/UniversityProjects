/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;
import utils.DocumentDetails;

/**
 *
 * @author satomi
 */
public interface DocumentLocalHome extends EJBLocalHome {

	dipartimento.ejb.DocumentLocal findByPrimaryKey(java.lang.String key) throws FinderException;

	dipartimento.ejb.DocumentLocal create(java.lang.String key) throws CreateException;

	dipartimento.ejb.DocumentLocal create(DocumentDetails document) throws CreateException;

	Collection findByType(int type) throws FinderException;

	Collection findAllDocuments() throws FinderException;

	Collection findByTitle(String word) throws FinderException;

	Collection findByKeyword(String keyword) throws FinderException;

	Collection findByAuthor(String author) throws FinderException;

	Collection findByDate(long start, long end) throws FinderException;
}
