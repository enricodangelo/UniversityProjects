/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.ejb.FinderException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import utils.SearchDetails;
import utils.SearchResult;

/**
 *
 * @author benve
 */
public class DipartimentoWSBean implements SessionBean {

	private DocumentLocalHome documentHome;
//	private AuthorLocalHome authorHome;
	private SessionContext context;

	// <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click the + sign on the left to edit the code.">;
	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(SessionContext aContext) {
		context = aContext;
	}

	/**
	 * @see javax.ejb.SessionBean#ejbActivate()
	 */
	public void ejbActivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbPassivate()
	 */
	public void ejbPassivate() {

	}

	/**
	 * @see javax.ejb.SessionBean#ejbRemove()
	 */
	public void ejbRemove() {

	}

	// </editor-fold>;
	/**
	 * See section 7.10.3 of the EJB 2.0 specification
	 * See section 7.11.3 of the EJB 2.1 specification
	 */
	public void ejbCreate() {

	}

	public SearchResult[] getDocuments(SearchDetails sd) {//OR
		Set result = Collections.synchronizedSet(new HashSet());
		documentHome = lookupDocumentBean();

		//DOCID

		String[] docids = sd.getDocID();

		if (!(docids[0].equals(""))) {
			for (int i = 0; i < docids.length; i++) {
				try {
					DocumentLocal tmpdoc = documentHome.findByPrimaryKey(docids[i]);
					result.add(tmpdoc.getDocumentDetails().toSearchResult());//Torna true se l'elemento è inserito (non era già presente)

				} catch (FinderException ex) {
				}
			}
		}

		//TITLE

		String[] titles = sd.getTitle();

		if (!(titles[0].equals(""))) {
			for (int i = 0; i < titles.length; i++) {
				try {
					Collection docs = documentHome.findByTitle("%" + titles[i] + "%");
					for (Iterator it = docs.iterator(); it.hasNext();) {
						DocumentLocal tmpdoc = (DocumentLocal) it.next();
						result.add(tmpdoc.getDocumentDetails().toSearchResult());//Torna true se l'elemento è inserito (non era già presente)
					}
				} catch (FinderException ex) {
				}
			}
		}

		//AUTHORS

		String[] authors = sd.getAuthor();
		if (!(authors[0].equals(""))) {
			for (int i = 0; i < authors.length; i++) {
				try {
					Collection docs = documentHome.findByAuthor(lookupAuthorBean().findByName(authors[i]).getPk());
					for (Iterator it = docs.iterator(); it.hasNext();) {
						DocumentLocal tmpdoc = (DocumentLocal) it.next();
						result.add(tmpdoc.getDocumentDetails().toSearchResult());//Torna true se l'elemento è inserito (non era già presente)
					}
				} catch (FinderException ex) {
				}
			}
		}

		//KEYWORDS

		String[] keys = sd.getKeyword();
		if (!(keys[0].equals(""))) {
			for (int i = 0; i < keys.length; i++) {
				try {

					Collection docs = documentHome.findByKeyword("%" + keys[i] + "%");
					for (Iterator it = docs.iterator(); it.hasNext();) {
						DocumentLocal tmpdoc = (DocumentLocal) it.next();
						result.add(tmpdoc.getDocumentDetails().toSearchResult());//Torna true se l'elemento è inserito (non era già presente)
					}
				} catch (FinderException ex) {
				}
			}
		}

		//DATE

		long startDate = sd.getStartDate();
		long endDate = sd.getEndDate();

		if (!(startDate == -1 && endDate == -1)) {// nessuna data
			if (startDate != -1 && endDate == -1) {// tutti i documenti successivi una certa data
				endDate = new Date().getTime();
			} else if (startDate == -1 && endDate != -1) {//tutti i documenti precedenti una certa data
				GregorianCalendar gc = (GregorianCalendar) GregorianCalendar.getInstance();
				gc.clear();
				startDate = gc.getTime().getTime();
			}

			Collection docs = null;
			try {
				docs = documentHome.findByDate(startDate, endDate);
			} catch (FinderException ex) {
				ex.printStackTrace();
			}

			for (Iterator it = docs.iterator(); it.hasNext();) {
				DocumentLocal tmpdoc = (DocumentLocal) it.next();
				result.add(tmpdoc.getDocumentDetails().toSearchResult());//Torna true se l'elemento è inserito (non era già presente)
			}
		}

		//TYPE

		int type = sd.getType();
		if (type == 2 || type == 1) {
			if (result.isEmpty()) {//Ricerche solo per tipo
				SearchResult[] tmpsr = getAllDocuments();
				for (int i = 0; i < tmpsr.length; i++) {
					SearchResult searchResult = tmpsr[i];
					if (searchResult.getType() == type) {
						result.add(searchResult);
					}
				}
			} else {//Filtra la ricerca per tipo
				for (Iterator it = result.iterator(); it.hasNext();) {
					SearchResult sr = (SearchResult) it.next();
					if (sr.getType() != type) {
						it.remove();
					}
				}
			}
		}


		return (SearchResult[]) result.toArray(new SearchResult[result.size()]);
	}

	public byte[] getDocumentFile(String id) {
		try {
			documentHome = lookupDocumentBean();
			DocumentLocal document = documentHome.findByPrimaryKey(id);
			return document.getFile();

		} catch (FinderException e) {//TODO: ritornare l'eccezione nel WS
			e.printStackTrace();
		}
		return null;

	}

	public SearchResult[] getAllDocuments() {
		LinkedHashSet result = new LinkedHashSet();
		try {
			documentHome = lookupDocumentBean();
			Collection documents = documentHome.findAllDocuments();

			for (Iterator it = documents.iterator(); it.hasNext();) {
				DocumentLocal doc = (DocumentLocal) it.next();
				result.add(doc.getDocumentDetails().toSearchResult());
			}
		} catch (FinderException ex) {
			ex.printStackTrace();
		}
		return (SearchResult[]) result.toArray(new SearchResult[result.size()]);
	}

	private DocumentLocalHome lookupDocumentBean() {
		try {
			Context c = new InitialContext();
			DocumentLocalHome rv = (DocumentLocalHome) c.lookup("java:comp/env/DocumentBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}

	private AuthorLocalHome lookupAuthorBean() {
		try {
			Context c = new InitialContext();
			AuthorLocalHome rv = (AuthorLocalHome) c.lookup("java:comp/env/AuthorBean");
			return rv;
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		}
	}
}
