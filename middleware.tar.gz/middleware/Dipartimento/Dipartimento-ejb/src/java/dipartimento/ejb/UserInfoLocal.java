/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import java.util.Collection;
import javax.ejb.EJBLocalObject;

/**
 *
 * @author satomi
 */
public interface UserInfoLocal extends EJBLocalObject {

	Collection getPendingIDs();

	Collection getUserDocuments();

	String getUserName(String userID);

	DocumentLocal getUserDocument(String docID);
    
}
