/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.ejb;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalObject;

/**
 *
 * @author benve
 */
public interface AdminLocal extends EJBLocalObject {

    void createAuthor(String id, String name) throws CreateException;

    void loadServerDir(String dir);
    
}
