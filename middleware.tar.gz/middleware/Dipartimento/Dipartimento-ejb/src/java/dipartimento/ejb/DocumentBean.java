/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ejb;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import utils.Convert;
import utils.DocumentDetails;
import utils.ID;

/**
 *
 * @author satomi
 */
public abstract class DocumentBean implements EntityBean {

    private EntityContext context;

    // <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click on the + sign on the left to edit the code.">

    /**
     * @see javax.ejb.EntityBean#setEntityContext(javax.ejb.EntityContext)
     */
    public void setEntityContext(EntityContext aContext) {
        context = aContext;
    }

    /**
     * @see javax.ejb.EntityBean#ejbActivate()
     */
    public void ejbActivate() {

    }

    /**
     * @see javax.ejb.EntityBean#ejbPassivate()
     */
    public void ejbPassivate() {

    }

    /**
     * @see javax.ejb.EntityBean#ejbRemove()
     */
    public void ejbRemove() {

    }

    /**
     * @see javax.ejb.EntityBean#unsetEntityContext()
     */
    public void unsetEntityContext() {
        context = null;
    }

    /**
     * @see javax.ejb.EntityBean#ejbLoad()
     */
    public void ejbLoad() {

    }

    /**
     * @see javax.ejb.EntityBean#ejbStore()
     */
    public void ejbStore() {

    }

    // </editor-fold>
		
    public abstract java.lang.String getPk();

    public abstract void setPk(java.lang.String key);

    public java.lang.String ejbCreate(java.lang.String key) throws CreateException {
        if (key == null) {
            throw new CreateException("The field \"key\" must not be null");
        }

        setPk(key);

        return null;
    }

    public void ejbPostCreate(java.lang.String key) {
    }

    public abstract String getTitle();

    public abstract void setTitle(String title);

    public abstract long getCreationDate();

    public abstract void setCreationDate(long creationDate);

    public abstract int getType();

    public abstract void setType(int type);

    public abstract String getKeywords();

    public abstract void setKeywords(String keywords);

    public abstract java.util.Collection getAuthors();

    public abstract void setAuthors(java.util.Collection value);

    public java.lang.String ejbCreate(DocumentDetails document) throws CreateException {
        setPk(document.getDocID().toString());
        setDocFields(document);
        return null;
    }

    public void ejbPostCreate(DocumentDetails document) throws CreateException {
    }

    public void update(DocumentDetails documentDetails) {
        setDocFields(documentDetails);

    }

    private void setDocFields(DocumentDetails documentDetails) {
        try {
            setTitle(documentDetails.getTitle());
            setCreationDate(documentDetails.getCreationDate().getTime());
            setType(documentDetails.getType());
            setKeywords(Convert.collectionToString(documentDetails.getKeywords()));
            setFile(Convert.fileToByte(documentDetails.getFile()));
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public DocumentDetails getDocumentDetails() {
        Collection ab = getAuthors();
        Collection a = new ArrayList();
        Iterator i = ab.iterator();
        
        while (i.hasNext()) {
            a.add(((AuthorLocal) i.next()).getName());
        }
        
        return new DocumentDetails(a,
                getTitle(),
                Convert.stringToCollection(getKeywords()),
                new Date(getCreationDate()),
                getType(),
                new ID(getPk()),
                null);
    }

    public abstract byte [] getFile();

    public abstract void setFile(byte [] file);
}
