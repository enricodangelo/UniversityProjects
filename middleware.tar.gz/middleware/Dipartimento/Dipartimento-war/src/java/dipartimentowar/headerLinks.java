/*
 * headerLinks.java
 *
 * Created on Feb 4, 2008, 6:38:20 PM
 */
package dipartimentowar;

import com.sun.rave.web.ui.appbase.AbstractFragmentBean;
import com.sun.rave.web.ui.component.Hyperlink;
import com.sun.rave.web.ui.component.StaticText;
import dipartimento.ejb.UserInfoLocal;
import dipartimento.ejb.UserInfoLocalHome;
import javax.ejb.CreateException;
import javax.faces.FacesException;
import javax.faces.component.html.HtmlGraphicImage;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

/**
 * <p>Fragment bean that corresponds to a similarly named JSP page
 * fragment.  This class contains component definitions (and initialization
 * code) for all components that you have defined on this fragment, as well as
 * lifecycle methods and event handlers where you may add behavior
 * to respond to incoming events.</p>
 *
 * @author satomi
 */
public class headerLinks extends AbstractFragmentBean {
	// <editor-fold defaultstate="collapsed" desc="Managed Component Definition">
	/**
	 * <p>Automatically managed component initialization. <strong>WARNING:</strong>
	 * This method is automatically generated, so any user-specified code inserted
	 * here is subject to being replaced.</p>
	 */
	private void _init() throws Exception {
	}
	
	private HtmlGraphicImage logo = new HtmlGraphicImage();

	public HtmlGraphicImage getLogo() {
		return logo;
	}

	public void setLogo(HtmlGraphicImage hgi) {
		this.logo = hgi;
	}
	private HtmlGraphicImage testata = new HtmlGraphicImage();

	public HtmlGraphicImage getTestata() {
		return testata;
	}

	public void setTestata(HtmlGraphicImage hgi) {
		this.testata = hgi;
	}
	private Hyperlink hyperlink1 = new Hyperlink();

	public Hyperlink getHyperlink1() {
		return hyperlink1;
	}

	public void setHyperlink1(Hyperlink h) {
		this.hyperlink1 = h;
	}
	private Hyperlink newIDLink = new Hyperlink();

	public Hyperlink getNewIDLink() {
		return newIDLink;
	}

	public void setNewIDLink(Hyperlink h) {
		this.newIDLink = h;
	}
	private Hyperlink uploadLink = new Hyperlink();

	public Hyperlink getUploadLink() {
		return uploadLink;
	}

	public void setUploadLink(Hyperlink h) {
		this.uploadLink = h;
	}
	private Hyperlink updateLink = new Hyperlink();

	public Hyperlink getUpdateLink() {
		return updateLink;
	}

	public void setUpdateLink(Hyperlink h) {
		this.updateLink = h;
	}
	private Hyperlink deleteLink = new Hyperlink();

	public Hyperlink getDeleteLink() {
		return deleteLink;
	}

	public void setDeleteLink(Hyperlink h) {
		this.deleteLink = h;
	}
	private StaticText staticText1 = new StaticText();

	public StaticText getStaticText1() {
		return staticText1;
	}

	public void setStaticText1(StaticText st) {
		this.staticText1 = st;
	}
	private StaticText staticText2 = new StaticText();

	public StaticText getStaticText2() {
		return staticText2;
	}

	public void setStaticText2(StaticText st) {
		this.staticText2 = st;
	}
	private StaticText staticText3 = new StaticText();

	public StaticText getStaticText3() {
		return staticText3;
	}

	public void setStaticText3(StaticText st) {
		this.staticText3 = st;
	}
	private HtmlPanelGrid linkGridPanel1 = new HtmlPanelGrid();

	public HtmlPanelGrid getLinkGridPanel1() {
		return linkGridPanel1;
	}

	public void setLinkGridPanel1(HtmlPanelGrid hpg) {
		this.linkGridPanel1 = hpg;
	}
	
//	private Hyperlink uploadHyperlink = new Hyperlink();
//
//	public Hyperlink getUploadHyperlink() {
//		return uploadHyperlink;
//	}
//
//	public void setUploadHyperlink(Hyperlink h) {
//		this.uploadHyperlink = h;
//	}
//	
//	private Hyperlink updateHyperlink = new Hyperlink();
//
//	public Hyperlink getUpdateHyperlink() {
//		return updateHyperlink;
//	}
//
//	public void setUpdateHyperlink(Hyperlink h) {
//		this.updateHyperlink = h;
//	}
//	
//	private Hyperlink deleteHyperlink = new Hyperlink();
//
//	public Hyperlink getDeleteHyperlink() {
//		return deleteHyperlink;
//	}
//
//	public void setDeleteHyperlink(Hyperlink h) {
//		this.deleteHyperlink = h;
//	}
	
	private Hyperlink adminHyperlink = new Hyperlink();

	public Hyperlink getAdminHyperlink() {
		return adminHyperlink;
	}

	public void setAdminHyperlink(Hyperlink h) {
		this.adminHyperlink = h;
	}
	
//	private Hyperlink newIDHyperlink = new Hyperlink();
//
//	public Hyperlink getNewIDHyperlink() {
//		return newIDHyperlink;
//	}
//
//	public void setNewIDHyperlink(Hyperlink h) {
//		this.newIDHyperlink = h;
//	}
//	
//	private Hyperlink homeHyperlink = new Hyperlink();
//
//	public Hyperlink getHomeHyperlink() {
//		return homeHyperlink;
//	}
//
//	public void setHomeHyperlink(Hyperlink h) {
//		this.homeHyperlink = h;
//	}
	
	private StaticText userNameStaticText = new StaticText();

	public StaticText getUserNameStaticText() {
		return userNameStaticText;
	}

	public void setUserNameStaticText(StaticText st) {
		this.userNameStaticText = st;
	}
	private Hyperlink logoutHyperlink = new Hyperlink();

	public Hyperlink getLogoutHyperlink() {
		return logoutHyperlink;
	}

	public void setLogoutHyperlink(Hyperlink h) {
		this.logoutHyperlink = h;
	}
	private Hyperlink homeHyperlink = new Hyperlink();

	public Hyperlink getHomeHyperlink() {
		return homeHyperlink;
	}

	public void setHomeHyperlink(Hyperlink h) {
		this.homeHyperlink = h;
	}
	private Hyperlink newIDHyperlink = new Hyperlink();

	public Hyperlink getNewIDHyperlink() {
		return newIDHyperlink;
	}

	public void setNewIDHyperlink(Hyperlink h) {
		this.newIDHyperlink = h;
	}
	private Hyperlink uploadupdateHyperlink = new Hyperlink();

	public Hyperlink getUploadupdateHyperlink() {
		return uploadupdateHyperlink;
	}

	public void setUploadupdateHyperlink(Hyperlink h) {
		this.uploadupdateHyperlink = h;
	}
	private Hyperlink deleteHyperlink = new Hyperlink();

	public Hyperlink getDeleteHyperlink() {
		return deleteHyperlink;
	}

	public void setDeleteHyperlink(Hyperlink h) {
		this.deleteHyperlink = h;
	}
	
//	private Hyperlink adminHyperlink2 = new Hyperlink();
//
//	public Hyperlink getAdminHyperlink2() {
//		return adminHyperlink2;
//	}
//
//	public void setAdminHyperlink2(Hyperlink h) {
//		this.adminHyperlink2 = h;
//	}
	// </editor-fold>
	public headerLinks() {
	}

	/**
	 * <p>Callback method that is called whenever a page containing
	 * this page fragment is navigated to, either directly via a URL,
	 * or indirectly via page navigation.  Override this method to acquire
	 * resources that will be needed for event handlers and lifecycle methods.</p>
	 * 
	 * <p>The default implementation does nothing.</p>
	 */
	public void init() {
		// Perform initializations inherited from our superclass
		super.init();
		// Perform application initialization that must complete
		// *before* managed components are initialized
		// TODO - add your own initialiation code here

		String adminID = "amministratore";
		if (!getDipartimentoSessionBean().getUserID().equals(adminID)) {
			this.adminHyperlink.setDisabled(true);
		}

		// <editor-fold defaultstate="collapsed" desc="Visual-Web-managed Component Initialization">
		// Initialize automatically managed components
		// *Note* - this logic should NOT be modified
		try {
			_init();
		} catch (Exception e) {
			log("Page1 Initialization Failure", e);
			throw e instanceof FacesException ? (FacesException) e : new FacesException(e);
		}

	// </editor-fold>
	// Perform application initialization that must complete
	// *after* managed components are initialized
	// TODO - add your own initialization code here
	}

	/**
	 * <p>Callback method that is called after rendering is completed for
	 * this request, if <code>init()</code> was called.  Override this
	 * method to release resources acquired in the <code>init()</code>
	 * resources that will be needed for event handlers and lifecycle methods.</p>
	 * 
	 * <p>The default implementation does nothing.</p>
	 */
	public void destroy() {
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected DipartimentoApplicationBean getDipartimentoApplicationBean() {
		return (DipartimentoApplicationBean) getBean("DipartimentoApplicationBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected DipartimentoSessionBean getDipartimentoSessionBean() {
		return (DipartimentoSessionBean) getBean("DipartimentoSessionBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected DipartimentoRequestBean getDipartimentoRequestBean() {
		return (DipartimentoRequestBean) getBean("DipartimentoRequestBean");
	}

	public String getUserName() {
		return getDipartimentoSessionBean().getUser();
	}

	private UserInfoLocal lookupUserInfoBean() {
		try {
			Context c = new InitialContext();
			UserInfoLocalHome rv = (UserInfoLocalHome) c.lookup("java:comp/env/UserInfoBean");
			return rv.create();
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		} catch (CreateException ce) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
			throw new RuntimeException(ce);
		}
	}
}
