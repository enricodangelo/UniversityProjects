/*
 * home.java
 *
 * Created on Jan 30, 2008, 3:49:56 PM
 */
package dipartimentowar;

import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import com.sun.rave.web.ui.component.StaticText;
import dipartimento.ejb.UserInfoLocal;
import dipartimento.ejb.UserInfoLocalHome;
import java.util.Collection;
import javax.ejb.CreateException;
import javax.faces.FacesException;
import javax.faces.component.UIColumn;
import javax.faces.component.html.HtmlDataTable;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 * <p>Page bean that corresponds to a similarly named JSP page.  This
 * class contains component definitions (and initialization code) for
 * all components that you have defined on this page, as well as
 * lifecycle methods and event handlers where you may add behavior
 * to respond to incoming events.</p>
 *
 * @author satomi
 */
public class home extends AbstractPageBean {
	// <editor-fold defaultstate="collapsed" desc="Managed Component Definition">
	/**
	 * <p>Automatically managed component initialization.  <strong>WARNING:</strong>
	 * This method is automatically generated, so any user-specified code inserted
	 * here is subject to being replaced.</p>
	 */
	private void _init() throws Exception {
	}
	private Page page1 = new Page();

	public Page getPage1() {
		return page1;
	}

	public void setPage1(Page p) {
		this.page1 = p;
	}
	private Html html1 = new Html();

	public Html getHtml1() {
		return html1;
	}

	public void setHtml1(Html h) {
		this.html1 = h;
	}
	private Head head1 = new Head();

	public Head getHead1() {
		return head1;
	}

	public void setHead1(Head h) {
		this.head1 = h;
	}
	private Link link1 = new Link();

	public Link getLink1() {
		return link1;
	}

	public void setLink1(Link l) {
		this.link1 = l;
	}
	private Body body1 = new Body();

	public Body getBody1() {
		return body1;
	}

	public void setBody1(Body b) {
		this.body1 = b;
	}
	private Form form1 = new Form();

	public Form getForm1() {
		return form1;
	}

	public void setForm1(Form f) {
		this.form1 = f;
	}
	private HtmlDataTable pendingIDDataTable = new HtmlDataTable();

	public HtmlDataTable getPendingIDDataTable() {
		return pendingIDDataTable;
	}

	public void setPendingIDDataTable(HtmlDataTable hdt) {
		this.pendingIDDataTable = hdt;
	}
	private UIColumn column1 = new UIColumn();

	public UIColumn getColumn1() {
		return column1;
	}

	public void setColumn1(UIColumn uic) {
		this.column1 = uic;
	}
	private HtmlOutputText outputText1 = new HtmlOutputText();

	public HtmlOutputText getOutputText1() {
		return outputText1;
	}

	public void setOutputText1(HtmlOutputText hot) {
		this.outputText1 = hot;
	}
	private HtmlDataTable documentDataTable = new HtmlDataTable();

	public HtmlDataTable getDocumentDataTable() {
		return documentDataTable;
	}

	public void setDocumentDataTable(HtmlDataTable hdt) {
		this.documentDataTable = hdt;
	}
	private UIColumn IDColumn = new UIColumn();

	public UIColumn getIDColumn() {
		return IDColumn;
	}

	public void setIDColumn(UIColumn uic) {
		this.IDColumn = uic;
	}
	private HtmlOutputText IDOutputText = new HtmlOutputText();

	public HtmlOutputText getIDOutputText() {
		return IDOutputText;
	}

	public void setIDOutputText(HtmlOutputText hot) {
		this.IDOutputText = hot;
	}
	private HtmlOutputText IDContentOutputText = new HtmlOutputText();

	public HtmlOutputText getIDContentOutputText() {
		return IDContentOutputText;
	}

	public void setIDContentOutputText(HtmlOutputText hot) {
		this.IDContentOutputText = hot;
	}
	private UIColumn titleColumn = new UIColumn();

	public UIColumn getTitleColumn() {
		return titleColumn;
	}

	public void setTitleColumn(UIColumn uic) {
		this.titleColumn = uic;
	}
	private HtmlOutputText titleContentOutputText = new HtmlOutputText();

	public HtmlOutputText getTitleContentOutputText() {
		return titleContentOutputText;
	}

	public void setTitleContentOutputText(HtmlOutputText hot) {
		this.titleContentOutputText = hot;
	}
	private HtmlOutputText titleOutputText = new HtmlOutputText();

	public HtmlOutputText getTitleOutputText() {
		return titleOutputText;
	}

	public void setTitleOutputText(HtmlOutputText hot) {
		this.titleOutputText = hot;
	}
	private UIColumn creationDateColumn = new UIColumn();

	public UIColumn getCreationDateColumn() {
		return creationDateColumn;
	}

	public void setCreationDateColumn(UIColumn uic) {
		this.creationDateColumn = uic;
	}
	private HtmlOutputText creationDateContentOutputText = new HtmlOutputText();

	public HtmlOutputText getCreationDateContentOutputText() {
		return creationDateContentOutputText;
	}

	public void setCreationDateContentOutputText(HtmlOutputText hot) {
		this.creationDateContentOutputText = hot;
	}
	private HtmlOutputText creationDateOutputText = new HtmlOutputText();

	public HtmlOutputText getCreationDateOutputText() {
		return creationDateOutputText;
	}

	public void setCreationDateOutputText(HtmlOutputText hot) {
		this.creationDateOutputText = hot;
	}
	private UIColumn authorsColumn = new UIColumn();

	public UIColumn getAuthorsColumn() {
		return authorsColumn;
	}

	public void setAuthorsColumn(UIColumn uic) {
		this.authorsColumn = uic;
	}
	private HtmlOutputText authorsContentOutputText = new HtmlOutputText();

	public HtmlOutputText getAuthorsContentOutputText() {
		return authorsContentOutputText;
	}

	public void setAuthorsContentOutputText(HtmlOutputText hot) {
		this.authorsContentOutputText = hot;
	}
	private HtmlOutputText authorsOutputText = new HtmlOutputText();

	public HtmlOutputText getAuthorsOutputText() {
		return authorsOutputText;
	}

	public void setAuthorsOutputText(HtmlOutputText hot) {
		this.authorsOutputText = hot;
	}
	private UIColumn keywordsColumn = new UIColumn();

	public UIColumn getKeywordsColumn() {
		return keywordsColumn;
	}

	public void setKeywordsColumn(UIColumn uic) {
		this.keywordsColumn = uic;
	}
	private HtmlOutputText keywordsContentOutputText = new HtmlOutputText();

	public HtmlOutputText getKeywordsContentOutputText() {
		return keywordsContentOutputText;
	}

	public void setKeywordsContentOutputText(HtmlOutputText hot) {
		this.keywordsContentOutputText = hot;
	}
	private HtmlOutputText keywordsOutputText = new HtmlOutputText();

	public HtmlOutputText getKeywordsOutputText() {
		return keywordsOutputText;
	}

	public void setKeywordsOutputText(HtmlOutputText hot) {
		this.keywordsOutputText = hot;
	}
	private UIColumn typeColumn = new UIColumn();

	public UIColumn getTypeColumn() {
		return typeColumn;
	}

	public void setTypeColumn(UIColumn uic) {
		this.typeColumn = uic;
	}
	private HtmlOutputText typeContentOutputText = new HtmlOutputText();

	public HtmlOutputText getTypeContentOutputText() {
		return typeContentOutputText;
	}

	public void setTypeContentOutputText(HtmlOutputText hot) {
		this.typeContentOutputText = hot;
	}
	private HtmlOutputText typeOutputText = new HtmlOutputText();

	public HtmlOutputText getTypeOutputText() {
		return typeOutputText;
	}

	public void setTypeOutputText(HtmlOutputText hot) {
		this.typeOutputText = hot;
	}
	private StaticText documentStaticText = new StaticText();

	public StaticText getDocumentStaticText() {
		return documentStaticText;
	}

	public void setDocumentStaticText(StaticText st) {
		this.documentStaticText = st;
	}
	private StaticText pendingIDStaticText = new StaticText();

	public StaticText getPendingIDStaticText() {
		return pendingIDStaticText;
	}

	public void setPendingIDStaticText(StaticText st) {
		this.pendingIDStaticText = st;
	}

	// </editor-fold>
	/**
	 * <p>Construct a new Page bean instance.</p>
	 */
	public home() {
	}

	/**
	 * <p>Callback method that is called whenever a page is navigated to,
	 * either directly via a URL, or indirectly via page navigation.
	 * Customize this method to acquire resources that will be needed
	 * for event handlers and lifecycle methods, whether or not this
	 * page is performing post back processing.</p>
	 * 
	 * <p>Note that, if the current request is a postback, the property
	 * values of the components do <strong>not</strong> represent any
	 * values submitted with this request.  Instead, they represent the
	 * property values that were saved for this view when it was rendered.</p>
	 */
	public void init() {
		// Perform initializations inherited from our superclass
		super.init();
		
		DipartimentoSessionBean dipartimentoSessionBean = getDipartimentoSessionBean();
		dipartimentoSessionBean.setUserID(FacesContext.getCurrentInstance().getExternalContext().getRemoteUser());
		dipartimentoSessionBean.setUser(lookupUserInfoBean().getUserName(FacesContext.getCurrentInstance().getExternalContext().getRemoteUser()));
		
		
		// Perform application initialization that must complete
		// *before* managed components are initialized
		// TODO - add your own initialiation code here

		// <editor-fold defaultstate="collapsed" desc="Managed Component Initialization">
		// Initialize automatically managed components
		// *Note* - this logic should NOT be modified
		try {
			_init();
		} catch (Exception e) {
			log("home Initialization Failure", e);
			throw e instanceof FacesException ? (FacesException) e : new FacesException(e);
		}

	// </editor-fold>
	// Perform application initialization that must complete
	// *after* managed components are initialized
	// TODO - add your own initialization code here
	}

	/**
	 * <p>Callback method that is called after the component tree has been
	 * restored, but before any event processing takes place.  This method
	 * will <strong>only</strong> be called on a postback request that
	 * is processing a form submit.  Customize this method to allocate
	 * resources that will be required in your event handlers.</p>
	 */
	public void preprocess() {
	}

	/**
	 * <p>Callback method that is called just before rendering takes place.
	 * This method will <strong>only</strong> be called for the page that
	 * will actually be rendered (and not, for example, on a page that
	 * handled a postback and then navigated to a different page).  Customize
	 * this method to allocate resources that will be required for rendering
	 * this page.</p>
	 */
	public void prerender() {
	}

	/**
	 * <p>Callback method that is called after rendering is completed for
	 * this request, if <code>init()</code> was called (regardless of whether
	 * or not this was the page that was actually rendered).  Customize this
	 * method to release resources acquired in the <code>init()</code>,
	 * <code>preprocess()</code>, or <code>prerender()</code> methods (or
	 * acquired during execution of an event handler).</p>
	 */
	public void destroy() {
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected DipartimentoSessionBean getDipartimentoSessionBean() {
		return (DipartimentoSessionBean) getBean("DipartimentoSessionBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected DipartimentoRequestBean getDipartimentoRequestBean() {
		return (DipartimentoRequestBean) getBean("DipartimentoRequestBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected DipartimentoApplicationBean getDipartimentoApplicationBean() {
		return (DipartimentoApplicationBean) getBean("DipartimentoApplicationBean");
	}
	
	public Collection getPendingIDs() {
		return lookupUserInfoBean().getPendingIDs();
	}

	public Collection getDocuments() {
		return lookupUserInfoBean().getUserDocuments();
	}

	private UserInfoLocal lookupUserInfoBean() {
		try {
			Context c = new InitialContext();
			UserInfoLocalHome rv = (UserInfoLocalHome) c.lookup("java:comp/env/UserInfoBean");
			return rv.create();
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		} catch (CreateException ce) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
			throw new RuntimeException(ce);
		}
	}
}

