/*
 * upload.java
 *
 * Created on Jan 15, 2008, 6:46:55 PM
 */
package dipartimentowar;

import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.HiddenField;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.MessageGroup;
import com.sun.rave.web.ui.component.Page;
import com.sun.rave.web.ui.component.PanelLayout;
import com.sun.rave.web.ui.component.StaticText;
import com.sun.rave.web.ui.component.Upload;
import com.sun.rave.web.ui.model.UploadedFile;
import dipartimento.ejb.DipartimentoLocal;
import dipartimento.ejb.DipartimentoLocalHome;
import dipartimento.ejb.DocumentLocal;
import dipartimento.ejb.UserInfoLocal;
import dipartimento.ejb.UserInfoLocalHome;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import javax.ejb.CreateException;
import javax.ejb.RemoveException;
import javax.faces.FacesException;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.event.ValueChangeEvent;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import utils.Convert;
import utils.DocumentDetails;
import utils.exceptions.AthenaeumDepartementException;

/**
 * <p>Page bean that corresponds to a similarly named JSP page.  This
 * class contains component definitions (and initialization code) for
 * all components that you have defined on this page, as well as
 * lifecycle methods and event handlers where you may add behavior
 * to respond to incoming events.</p>
 *
 * @author benve
 */
public class uploadupdate extends AbstractPageBean {

	private String realFilePath;
	private static final String IMAGE_URL = "resources/file";

	// <editor-fold defaultstate="collapsed" desc="Managed Component Definition">
	/**
	 * <p>Automatically managed component initialization.  <strong>WARNING:</strong>
	 * This method is automatically generated, so any user-specified code inserted
	 * here is subject to being replaced.</p>
	 */
	private void _init() throws Exception {
	}
	private Page page1 = new Page();

	public Page getPage1() {
		return page1;
	}

	public void setPage1(Page p) {
		this.page1 = p;
	}
	private Html html1 = new Html();

	public Html getHtml1() {
		return html1;
	}

	public void setHtml1(Html h) {
		this.html1 = h;
	}
	private Head head1 = new Head();

	public Head getHead1() {
		return head1;
	}

	public void setHead1(Head h) {
		this.head1 = h;
	}
	private Link link1 = new Link();

	public Link getLink1() {
		return link1;
	}

	public void setLink1(Link l) {
		this.link1 = l;
	}
	private Body body1 = new Body();

	public Body getBody1() {
		return body1;
	}

	public void setBody1(Body b) {
		this.body1 = b;
	}
	private Form form1 = new Form();

	public Form getForm1() {
		return form1;
	}

	public void setForm1(Form f) {
		this.form1 = f;
	}
	private StaticText newDocumentFileSizeStaticText = new StaticText();

	public StaticText getNewDocumentFileSizeStaticText() {
		return newDocumentFileSizeStaticText;
	}

	public void setNewDocumentFileSizeStaticText(StaticText st) {
		this.newDocumentFileSizeStaticText = st;
	}
	private StaticText newDocumentFileNameStaticText = new StaticText();

	public StaticText getNewDocumentFileNameStaticText() {
		return newDocumentFileNameStaticText;
	}

	public void setNewDocumentFileNameStaticText(StaticText st) {
		this.newDocumentFileNameStaticText = st;
	}
	private StaticText newDocumentFileTypeStaticText = new StaticText();

	public StaticText getNewDocumentFileTypeStaticText() {
		return newDocumentFileTypeStaticText;
	}

	public void setNewDocumentFileTypeStaticText(StaticText st) {
		this.newDocumentFileTypeStaticText = st;
	}
	private Label label1 = new Label();

	public Label getLabel1() {
		return label1;
	}

	public void setLabel1(Label l) {
		this.label1 = l;
	}
	private Button uploadFileButton = new Button();

	public Button getUploadFileButton() {
		return uploadFileButton;
	}

	public void setUploadFileButton(Button b) {
		this.uploadFileButton = b;
	}
	private Label label2 = new Label();

	public Label getLabel2() {
		return label2;
	}

	public void setLabel2(Label l) {
		this.label2 = l;
	}
	private Upload fileUpload = new Upload();

	public Upload getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(Upload u) {
		this.fileUpload = u;
	}
	private Label label3 = new Label();

	public Label getLabel3() {
		return label3;
	}

	public void setLabel3(Label l) {
		this.label3 = l;
	}
	private Label label4 = new Label();

	public Label getLabel4() {
		return label4;
	}

	public void setLabel4(Label l) {
		this.label4 = l;
	}
	private Label label5 = new Label();

	public Label getLabel5() {
		return label5;
	}

	public void setLabel5(Label l) {
		this.label5 = l;
	}
	private Label label6 = new Label();

	public Label getLabel6() {
		return label6;
	}

	public void setLabel6(Label l) {
		this.label6 = l;
	}
	private Label label7 = new Label();

	public Label getLabel7() {
		return label7;
	}

	public void setLabel7(Label l) {
		this.label7 = l;
	}
	private Label label8 = new Label();

	public Label getLabel8() {
		return label8;
	}

	public void setLabel8(Label l) {
		this.label8 = l;
	}
	private Label label9 = new Label();

	public Label getLabel9() {
		return label9;
	}

	public void setLabel9(Label l) {
		this.label9 = l;
	}
	private Label label10 = new Label();

	public Label getLabel10() {
		return label10;
	}

	public void setLabel10(Label l) {
		this.label10 = l;
	}
	private StaticText newDocumentIDStaticText = new StaticText();

	public StaticText getNewDocumentIDStaticText() {
		return newDocumentIDStaticText;
	}

	public void setNewDocumentIDStaticText(StaticText st) {
		this.newDocumentIDStaticText = st;
	}
	private StaticText newDocumentCreationDateStaticText = new StaticText();

	public StaticText getNewDocumentCreationDateStaticText() {
		return newDocumentCreationDateStaticText;
	}

	public void setNewDocumentCreationDateStaticText(StaticText st) {
		this.newDocumentCreationDateStaticText = st;
	}
	private StaticText newDocumentKeywordsStaticText = new StaticText();

	public StaticText getNewDocumentKeywordsStaticText() {
		return newDocumentKeywordsStaticText;
	}

	public void setNewDocumentKeywordsStaticText(StaticText st) {
		this.newDocumentKeywordsStaticText = st;
	}
	private StaticText newDocumentAuthorsStaticText = new StaticText();

	public StaticText getNewDocumentAuthorsStaticText() {
		return newDocumentAuthorsStaticText;
	}

	public void setNewDocumentAuthorsStaticText(StaticText st) {
		this.newDocumentAuthorsStaticText = st;
	}
	private StaticText newDocumentTypeStaticText = new StaticText();

	public StaticText getNewDocumentTypeStaticText() {
		return newDocumentTypeStaticText;
	}

	public void setNewDocumentTypeStaticText(StaticText st) {
		this.newDocumentTypeStaticText = st;
	}
	private StaticText newDocumentTitleStaticText = new StaticText();

	public StaticText getNewDocumentTitleStaticText() {
		return newDocumentTitleStaticText;
	}

	public void setNewDocumentTitleStaticText(StaticText st) {
		this.newDocumentTitleStaticText = st;
	}
	private StaticText staticText1 = new StaticText();

	public StaticText getStaticText1() {
		return staticText1;
	}

	public void setStaticText1(StaticText st) {
		this.staticText1 = st;
	}
	private Button uploadButton = new Button();

	public Button getUploadButton() {
		return uploadButton;
	}

	public void setUploadButton(Button b) {
		this.uploadButton = b;
	}
	private HtmlPanelGrid gridPanel1 = new HtmlPanelGrid();

	public HtmlPanelGrid getGridPanel1() {
		return gridPanel1;
	}

	public void setGridPanel1(HtmlPanelGrid hpg) {
		this.gridPanel1 = hpg;
	}
	private HtmlPanelGrid newDocumentGridPanel = new HtmlPanelGrid();

	public HtmlPanelGrid getNewDocumentGridPanel() {
		return newDocumentGridPanel;
	}

	public void setNewDocumentGridPanel(HtmlPanelGrid hpg) {
		this.newDocumentGridPanel = hpg;
	}
	private Label label11 = new Label();

	public Label getLabel11() {
		return label11;
	}

	public void setLabel11(Label l) {
		this.label11 = l;
	}
	private StaticText staticText2 = new StaticText();

	public StaticText getStaticText2() {
		return staticText2;
	}

	public void setStaticText2(StaticText st) {
		this.staticText2 = st;
	}
	private HiddenField hiddenField1 = new HiddenField();

	public HiddenField getHiddenField1() {
		return hiddenField1;
	}

	public void setHiddenField1(HiddenField hf) {
		this.hiddenField1 = hf;
	}
	private HtmlPanelGrid fileUploadGridPanel = new HtmlPanelGrid();

	public HtmlPanelGrid getFileUploadGridPanel() {
		return fileUploadGridPanel;
	}

	public void setFileUploadGridPanel(HtmlPanelGrid hpg) {
		this.fileUploadGridPanel = hpg;
	}
	private HtmlPanelGrid oldDocumentGridPanel = new HtmlPanelGrid();

	public HtmlPanelGrid getOldDocumentGridPanel() {
		return oldDocumentGridPanel;
	}

	public void setOldDocumentGridPanel(HtmlPanelGrid hpg) {
		this.oldDocumentGridPanel = hpg;
	}
	private StaticText staticText3 = new StaticText();

	public StaticText getStaticText3() {
		return staticText3;
	}

	public void setStaticText3(StaticText st) {
		this.staticText3 = st;
	}
	private HiddenField hiddenField2 = new HiddenField();

	public HiddenField getHiddenField2() {
		return hiddenField2;
	}

	public void setHiddenField2(HiddenField hf) {
		this.hiddenField2 = hf;
	}
	private Label label15 = new Label();

	public Label getLabel15() {
		return label15;
	}

	public void setLabel15(Label l) {
		this.label15 = l;
	}
	private StaticText oldDocumentTitleStaticText = new StaticText();

	public StaticText getOldDocumentTitleStaticText() {
		return oldDocumentTitleStaticText;
	}

	public void setOldDocumentTitleStaticText(StaticText st) {
		this.oldDocumentTitleStaticText = st;
	}
	private Label label16 = new Label();

	public Label getLabel16() {
		return label16;
	}

	public void setLabel16(Label l) {
		this.label16 = l;
	}
	private StaticText oldDocumentAuthorsStaticText = new StaticText();

	public StaticText getOldDocumentAuthorsStaticText() {
		return oldDocumentAuthorsStaticText;
	}

	public void setOldDocumentAuthorsStaticText(StaticText st) {
		this.oldDocumentAuthorsStaticText = st;
	}
	private Label label17 = new Label();

	public Label getLabel17() {
		return label17;
	}

	public void setLabel17(Label l) {
		this.label17 = l;
	}
	private StaticText oldDocumentCreationDateStaticText = new StaticText();

	public StaticText getOldDocumentCreationDateStaticText() {
		return oldDocumentCreationDateStaticText;
	}

	public void setOldDocumentCreationDateStaticText(StaticText st) {
		this.oldDocumentCreationDateStaticText = st;
	}
	private Label label18 = new Label();

	public Label getLabel18() {
		return label18;
	}

	public void setLabel18(Label l) {
		this.label18 = l;
	}
	private StaticText oldDocumentIDStaticText = new StaticText();

	public StaticText getOldDocumentIDStaticText() {
		return oldDocumentIDStaticText;
	}

	public void setOldDocumentIDStaticText(StaticText st) {
		this.oldDocumentIDStaticText = st;
	}
	private Label label19 = new Label();

	public Label getLabel19() {
		return label19;
	}

	public void setLabel19(Label l) {
		this.label19 = l;
	}
	private StaticText oldDocumentTypeStaticText = new StaticText();

	public StaticText getOldDocumentTypeStaticText() {
		return oldDocumentTypeStaticText;
	}

	public void setOldDocumentTypeStaticText(StaticText st) {
		this.oldDocumentTypeStaticText = st;
	}
	private Label label20 = new Label();

	public Label getLabel20() {
		return label20;
	}

	public void setLabel20(Label l) {
		this.label20 = l;
	}
	private StaticText oldDocumentKeywordsStaticText = new StaticText();

	public StaticText getOldDocumentKeywordsStaticText() {
		return oldDocumentKeywordsStaticText;
	}

	public void setOldDocumentKeywordsStaticText(StaticText st) {
		this.oldDocumentKeywordsStaticText = st;
	}
	private Button updateButton = new Button();

	public Button getUpdateButton() {
		return updateButton;
	}

	public void setUpdateButton(Button b) {
		this.updateButton = b;
	}
    private MessageGroup messageGroup1 = new MessageGroup();

    public MessageGroup getMessageGroup1() {
        return messageGroup1;
    }

    public void setMessageGroup1(MessageGroup mg) {
        this.messageGroup1 = mg;
    }

	// </editor-fold>
	/**
	 * <p>Construct a new Page bean instance.</p>
	 */
	public uploadupdate() {
	}

	/**
	 * <p>Callback method that is called whenever a page is navigated to,
	 * either directly via a URL, or indirectly via page navigation.
	 * Customize this method to acquire resources that will be needed
	 * for event handlers and lifecycle methods, whether or not this
	 * page is performing post back processing.</p>
	 * 
	 * <p>Note that, if the current request is a postback, the property
	 * values of the components do <strong>not</strong> represent any
	 * values submitted with this request.  Instead, they represent the
	 * property values that were saved for this view when it was rendered.</p>
	 */
	public void init() {
		// Perform initializations inherited from our superclass
		super.init();
		// Perform application initialization that must complete
		// *before* managed components are initialized
		// TODO - add your own initialiation code here

		// <editor-fold defaultstate="collapsed" desc="Managed Component Initialization">
		// Initialize automatically managed components
		// *Note* - this logic should NOT be modified
		try {
			_init();
		} catch (Exception e) {
			log("upload Initialization Failure", e);
			throw e instanceof FacesException ? (FacesException) e : new FacesException(e);
		}

		// </editor-fold>
		// Perform application initialization that must complete
		// *after* managed components are initialized
		// TODO - add your own initialization code here

		this.realFilePath = "tmp";

	}

	/**
	 * <p>Callback method that is called after the component tree has been
	 * restored, but before any event processing takes place.  This method
	 * will <strong>only</strong> be called on a postback request that
	 * is processing a form submit.  Customize this method to allocate
	 * resources that will be required in your event handlers.</p>
	 */
	public void preprocess() {
	}

	/**
	 * <p>Callback method that is called just before rendering takes place.
	 * This method will <strong>only</strong> be called for the page that
	 * will actually be rendered (and not, for example, on a page that
	 * handled a postback and then navigated to a different page).  Customize
	 * this method to allocate resources that will be required for rendering
	 * this page.</p>
	 */
	public void prerender() {
	}

	/**
	 * <p>Callback method that is called after rendering is completed for
	 * this request, if <code>init()</code> was called (regardless of whether
	 * or not this was the page that was actually rendered).  Customize this
	 * method to release resources acquired in the <code>init()</code>,
	 * <code>preprocess()</code>, or <code>prerender()</code> methods (or
	 * acquired during execution of an event handler).</p>
	 */
	public void destroy() {
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected DipartimentoSessionBean getDipartimentoSessionBean() {
		return (DipartimentoSessionBean) getBean("DipartimentoSessionBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected DipartimentoRequestBean getDipartimentoRequestBean() {
		return (DipartimentoRequestBean) getBean("DipartimentoRequestBean");
	}

	/**
	 * <p>Return a reference to the scoped data bean.</p>
	 *
	 * @return reference to the scoped data bean
	 */
	protected DipartimentoApplicationBean getDipartimentoApplicationBean() {
		return (DipartimentoApplicationBean) getBean("DipartimentoApplicationBean");
	}

	public String uploadFileButton_action() {
		UploadedFile uploadedFile = fileUpload.getUploadedFile();
		if (uploadedFile == null) {
			return null;
		}

		String uploadedFileName = uploadedFile.getOriginalName();
		int index = uploadedFileName.lastIndexOf('/');
		String justFileName;
		if (index >= 0) {
			justFileName = uploadedFileName.substring(index + 1);
		} else {
			// Try backslash
			index = uploadedFileName.lastIndexOf('\\');
			if (index >= 0) {
				justFileName = uploadedFileName.substring(index + 1);
			} else {
				// No forward or back slashes
				justFileName = uploadedFileName;
			}
		}

		this.newDocumentFileNameStaticText.setValue(justFileName);
		Long uploadedFileSize = new Long(uploadedFile.getSize());
		this.newDocumentFileSizeStaticText.setValue(uploadedFileSize);
		String uploadedFileType = uploadedFile.getContentType();
		this.newDocumentFileTypeStaticText.setValue(uploadedFileType);

		if (uploadedFileType.equals("application/pdf")) {
			File file = null;
			try {
				file = new File(this.realFilePath);
				uploadedFile.write(file);
			} catch (Exception ex) {
				error("Impossibile caricare il file: " + justFileName);
			}

			try {
				DocumentDetails newDocumentDetails = DocumentDetails.makeDocumentDetails(file);
				DocumentLocal oldDocument = lookupUserInfoBean().getUserDocument(newDocumentDetails.getDocID().toString());

				this.newDocumentIDStaticText.setValue(newDocumentDetails.getDocID().toString());
				this.newDocumentTitleStaticText.setValue(newDocumentDetails.getTitle());
				this.newDocumentCreationDateStaticText.setValue(newDocumentDetails.getCreationDate());
				this.newDocumentAuthorsStaticText.setValue(Convert.collectionToString(newDocumentDetails.getAuthors()));
				this.newDocumentTypeStaticText.setValue(Convert.typeIntToTypeString(newDocumentDetails.getType()));
				this.newDocumentKeywordsStaticText.setValue(Convert.collectionToString(newDocumentDetails.getKeywords()));
				//TODO: hack
				this.newDocumentGridPanel.setStyle(this.newDocumentGridPanel.getStyle().replaceAll("visibility: hidden", "visibility: visible"));
				
				getDipartimentoSessionBean().setNewDocumentDetails(newDocumentDetails);
				
				if (oldDocument != null) {	//stiamo modificando un documento
					DocumentDetails oldDocumentDetails = oldDocument.getDocumentDetails();

					this.uploadButton.setVisible(false);
					
					this.oldDocumentIDStaticText.setValue(oldDocumentDetails.getDocID().toString());
					this.oldDocumentTitleStaticText.setValue(oldDocumentDetails.getTitle());
					this.oldDocumentCreationDateStaticText.setValue(oldDocumentDetails.getCreationDate());
					this.oldDocumentAuthorsStaticText.setValue(Convert.collectionToString(oldDocumentDetails.getAuthors()));
					this.oldDocumentTypeStaticText.setValue(Convert.typeIntToTypeString(oldDocumentDetails.getType()));
					this.oldDocumentKeywordsStaticText.setValue(Convert.collectionToString(oldDocumentDetails.getKeywords()));
					//TODO: hack
					this.oldDocumentGridPanel.setStyle(this.oldDocumentGridPanel.getStyle().replaceAll("visibility: hidden", "visibility: visible"));

					getDipartimentoSessionBean().setOldDocumentDetails(oldDocumentDetails);
				}	
			} catch (IOException ex) {
				ex.printStackTrace();
			} catch (ParseException ex) {
				ex.printStackTrace();
			}

		} else {
			error("Devi selezionare un file in formato PDF.");
			new File(this.realFilePath).delete();
		}

		return null;
	}

	public void fileUpload_processValueChange(ValueChangeEvent event) {
	}

	public String uploadButton_action() {
		try {
			DipartimentoLocal dipartimento = lookupDipartimentoBean();
			dipartimento.uploadDocument(getDipartimentoSessionBean().getNewDocumentDetails());
		} catch (RemoveException ex) {
			ex.printStackTrace();
		} catch (AthenaeumDepartementException ex) {

			error(ex.getMessage());
		}

		return null;
	}

	public String updateButton_action() {
		try {
			DipartimentoLocal dipartimento = lookupDipartimentoBean();
			dipartimento.updateDocument(getDipartimentoSessionBean().getNewDocumentDetails());
		} catch (AthenaeumDepartementException ex) {
			error(ex.getMessage());
		}

		return null;
	}

	private DipartimentoLocal lookupDipartimentoBean() {
		try {
			Context c = new InitialContext();
			DipartimentoLocalHome rv = (DipartimentoLocalHome) c.lookup("java:comp/env/DipartimentoBean");
			return rv.create();
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		} catch (CreateException ce) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
			throw new RuntimeException(ce);
		}
	}

	private UserInfoLocal lookupUserInfoBean() {
		try {
			Context c = new InitialContext();
			UserInfoLocalHome rv = (UserInfoLocalHome) c.lookup("java:comp/env/UserInfoBean");
			return rv.create();
		} catch (NamingException ne) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ne);
			throw new RuntimeException(ne);
		} catch (CreateException ce) {
			java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE, "exception caught", ce);
			throw new RuntimeException(ce);
		}
	}
}
