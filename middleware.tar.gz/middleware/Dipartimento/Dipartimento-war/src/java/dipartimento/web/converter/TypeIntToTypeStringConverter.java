/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dipartimento.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import utils.Convert;

/**
 *
 * @author satomi
 */
public class TypeIntToTypeStringConverter implements Converter {
	
public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) throws ConverterException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getAsString(FacesContext arg0, UIComponent arg1, Object type) throws ConverterException {
        String ret = "";
				
				ret = Convert.typeIntToTypeString(((Integer)type).intValue());
				
        return ret;
		}
}
