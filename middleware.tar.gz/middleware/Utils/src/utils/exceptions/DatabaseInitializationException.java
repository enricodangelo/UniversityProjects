/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.exceptions;

/**
 *
 * @author satomi
 */
public class DatabaseInitializationException extends AthenaeumDepartementException {

	public DatabaseInitializationException(String msg) {
		super("Database non inizializzato correttamente. " + msg);
	}
}
