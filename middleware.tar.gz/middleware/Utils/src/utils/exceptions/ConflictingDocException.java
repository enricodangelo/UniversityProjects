/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.exceptions;

/**
 *
 * @author benve
 */
public class ConflictingDocException extends AthenaeumDepartementException {

    public ConflictingDocException(String id) {
        super("Il documento " + id + " è già presente nell'archivio.");
    }
}
