/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils.exceptions;

/**
 *
 * @author benve
 */
public class InconsistentDatabaseException extends AthenaeumDepartementException {

	public InconsistentDatabaseException(String message) {
		super(message);
	}
}
