/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.exceptions;

/**
 *
 * @author benve
 */
public class CreateDocException extends AthenaeumDepartementException {
    
    public CreateDocException(String id) {
        super("Un documento con l'ID " + id + "è già presente");
    }

}
