/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.exceptions;

/**
 *
 * @author satomi
 */
public class AthenaeumDepartementException  extends Exception {
	
	public AthenaeumDepartementException(String message) {
		super(message);
	}
}
