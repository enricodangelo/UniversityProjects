/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.exceptions;

/**
 *
 * @author benve
 */
public class FinderAuthorException extends AthenaeumDepartementException {
	
	public FinderAuthorException(String author) {
		super("Autore " + author + " non trovato nell'archivio.");
	}
}
