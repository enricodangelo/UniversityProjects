/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.exceptions;

/**
 *
 * @author benve
 */
public class FinderCatalogException extends AthenaeumDepartementException {

    public FinderCatalogException(String dep) {
        super(dep);
    }
            
}
