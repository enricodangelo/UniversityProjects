/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.exceptions;

/**
 *
 * @author benve
 */
public class NotReservedIDException extends AthenaeumDepartementException {

	public NotReservedIDException(String id) {
		super("L'ID fornito, " + id + ", non è stato riservato per l'upload di un nouvo documento.");
	}
}
