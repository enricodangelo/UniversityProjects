/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;

/**
 * TODO: ATTENZIONE TUTTE LE STRINGHE HANNO GLI ELEMENTI DIVISI DA ,
 * @author benve
 */
public class Convert {

    private static final String delimiter = ",";
		
		static public String typeIntToTypeString(int i) {
			String s = "";
			
			if (i == 1) {
				s = "Report";
			}
			else {
				s = "Raccolta di reports";
			}
			
			return s;
		}
    
    static public String arrayToString(String[] a) {
        String s = a[0];

        for (int i = 1; i < a.length; i++) {
            s = s + delimiter + a[i];
        }
        return s;
    }
    
    static public String[] stringToArray(String s) {
        String[] array = s.split(delimiter);
        
        return array;
    }

    static public Collection stringToCollection(String s) {
        StringTokenizer token = new StringTokenizer(s, delimiter);
        ArrayList c = new ArrayList();
        while (token.hasMoreTokens()) {
            c.add(token.nextToken().trim());
        }
        return c;
    }
    
    static public String collectionToString(Collection c) {
        String s = "";
        
        Iterator i = c.iterator();
        
        if (i.hasNext())
            s = (String) i.next();
        
        while (i.hasNext()) {
            s = s + ", " + ((String) i.next());
        }
        
        return s;
    }
    
    static public byte[] fileToByte(File file) throws FileNotFoundException, IOException {
        byte[] b = new byte[(int) file.length()];
        FileInputStream strm = new FileInputStream(file);
        strm.read(b);
        return b;
    }
    
    static public String[] collectionToArray(Collection c) {
        return (String[]) c.toArray(new String[c.size()]); 
    }
    
    static public Collection arrayToCollection(String[] s) {
        ArrayList c = new ArrayList(s.length);
        for (int i = 0; i < s.length; i++) {
            c.add(s[i]);
        }
        return c;
    }
}
