/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author satomi
 */
public class SearchResult implements java.io.Serializable {

	private String[] authors;
	private long creationDate;
	private String department;
	private String docID;
	private String[] keywords;
	private String title;
	private int type;

	//ATTENZIONE: non modificare l'ordine !!!
	public SearchResult(String[] authors,
					long creationDate,
					String department,
					String docID,
					String[] keywords,
					String title,
					int type) {

		this.docID = docID;
		this.title = title;

		this.creationDate = creationDate;
		this.keywords = keywords;

		this.type = type;
		this.authors = authors;
		this.department = department;

	}

	public int hashCode() {
		return getDocID().hashCode();
	}

	public boolean equals(Object sr) { //Controlla solo l'ID per valutare se sono uguali
		if (sr == this) {
			return true;
		}
		if (sr == null) {
			return false;
		}
		if (getClass() != sr.getClass()) {
			return false;
		}
		SearchResult seare = (SearchResult) sr;
		return seare.getDocID().equals(this.getDocID());
	}

	public String getDocID() {
		return docID;
	}

	public void setDocID(String docID) {
		this.docID = docID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(long creationDate) {
		this.creationDate = creationDate;
	}

	public String[] getKeywords() {
		return keywords;
	}

	public void setKeywords(String[] keywords) {
		this.keywords = keywords;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String[] getAuthors() {
		return authors;
	}

	public void setAuthors(String[] authors) {
		this.authors = authors;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
}
