/*
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.Serializable;

/**
 *
 * @author benve
 */
public class ID implements Serializable {

    private String department = null;
    private Integer year = null;
    private Integer number = null;

    /** Creates a new instance of ID */
    public ID(String department, Integer year, Integer number) {
        this.department = department;
        this.year = year;
        this.number = number;
    }

    public ID(String s) {
        String[] idArray = s.split("-");
        this.department = idArray[0];
        this.year = Integer.valueOf(idArray[1]);
        this.number = Integer.valueOf(idArray[2]);
    }

    public String toString() {
        return department + "-" + year.toString() + "-" + number.toString();
    }

    public String getDepartment() {
        return department;
    }

    public Integer getYear() {
        return year;
    }

    public Integer getNumber() {
        return number;
    }

    
    public int hashCode() {
        return (((department.hashCode() * 10000) + year.intValue()) * 1000) + number.intValue();
    }
    
    public boolean equals(Object sr) {
        if (sr == this) {
            return true;
        }
        if (sr == null) {
            return false;
        }
        if (getClass() != sr.getClass()) {
            return false;
        }
        ID id = (ID) sr;
        if (id.getDepartment().equals(this.getDepartment()) && id.getNumber().equals(this.getDepartment()) && id.getYear().equals(this.getYear())) {
            return true;
        }
        return false;
    }
}
