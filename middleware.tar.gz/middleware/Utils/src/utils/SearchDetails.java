/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author satomi
 */
public class SearchDetails {

	private String[] author; //Cerca "nome cognome"
   /*Data precisa, <, >, intervallo
	 * ["", ""] tutte le date 
	 * [11/11/2004, 11/11/2004] solo in quella data
	 * [11/11/2004, 13/04/2004] intervallo
	 * [11/11/2004, ""] tutti articoli precedenti (< di data)
	 * ["", 11/11/2004] tutti articoli successivi (> di data)
	 * 
	 */
	private long startDate;
	private long endDate;
	private String[] department;
	private String[] docID; //Cerca ID esatto/i
	private String[] keyword; //Cerca "*key,*"
	private String[] title; //Cerca "parole" contenute nei titoli
	private int type; //se 0 tutti i tipi

	public SearchDetails(String[] author,
					String[] department,
					String[] docID,
					long endDate,
					String[] keyword,
					long startDate,
					String[] title,
					int type) {

		this.docID = docID;
		this.title = title;

		this.startDate = startDate;
		this.endDate = endDate;
		this.keyword = keyword;

		this.type = type;
		this.author = author;
		this.department = department;

	}

	public String[] getAuthor() {
		return author;
	}

	public void setAuthor(String[] author) {
		this.author = author;
	}

	public String[] getDepartment() {
		return department;
	}

	public void setDepartment(String[] department) {
		this.department = department;
	}

	public String[] getDocID() {
		return docID;
	}

	public void setDocID(String[] docID) {
		this.docID = docID;
	}

	public String[] getKeyword() {
		return keyword;
	}

	public void setKeyword(String[] keyword) {
		this.keyword = keyword;
	}

	public String[] getTitle() {
		return title;
	}

	public void setTitle(String[] title) {
		this.title = title;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public long getStartDate() {
		return startDate;
	}

	public void setStartDate(long startDate) {
		this.startDate = startDate;
	}

	public long getEndDate() {
		return endDate;
	}

	public void setEndDate(long endDate) {
		this.endDate = endDate;
	}
}
