/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import com.lowagie.text.pdf.PdfReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Formato per lo scambio di informazioni all'interno del Dipartimento
 * @author benve
 */
public class DocumentDetails implements Serializable {

    private ID docID;
    private String title;
    private java.util.Date creationDate;
    private Collection keywords;
    private int type;
    private File file;
    private Collection authors;
    static final int REPORT = 1;
    static final int COLLECTION = 2;

    /**
     * @param id
     * @param title
     * @param creationDate
     * @param keywords
     * @param type
     * @param file
     */
    public DocumentDetails(
            Collection authors,
            String title,
            Collection keywords,
            java.util.Date creationDate,
            int type,
            ID id,
            File file) {
        this.authors = authors;
        this.title = title;
        this.keywords = keywords;
        this.creationDate = creationDate;
        this.type = type;
        this.docID = id;
        this.file = file;
    }
    
    public DocumentDetails(SearchResult searchResult)  {
        this.authors = Convert.arrayToCollection(searchResult.getAuthors());
        this.title = searchResult.getTitle();
        this.keywords = Convert.arrayToCollection(searchResult.getKeywords());
        this.creationDate = new Date(searchResult.getCreationDate());
        this.type = searchResult.getType();
        this.docID = new ID(searchResult.getDocID());
        this.file = null;
    }

    public String toString() {
        String output;

        output = "[";
        output += authors + ", ";
        output += title + ", ";
        output += keywords.toString() + ", ";
        output += creationDate + ", ";
        output += type + ", ";
        output += docID.toString() + "]";
        
        return output;
    }
		    
    public SearchResult toSearchResult() {
       return new SearchResult(Convert.collectionToArray(getAuthors()),
                        getCreationDate().getTime(),
                        "",
                        getDocID().toString(),
                        Convert.collectionToArray(getKeywords()),
                        getTitle(),
                        getType()
                        );
        
    }

    /**
     * @return Returns the creationDate.
     */
    public java.util.Date getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate The creationDate to set.
     */
    public void setCreationDate(java.util.Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return Returns the iD.
     */
    public ID getDocID() {
        return docID;
    }

    /**
     * @param id The iD to set.
     */
    public void setDocID(ID id) {
        docID = id;
    }

    /**
     * @return Returns the keywords.
     */
    public Collection getKeywords() {
        return keywords;
    }

    /**
     * @param keywords The keywords to set.
     */
    public void setKeywords(Collection keywords) {
        this.keywords = keywords;
    }

    /**
     * @return Returns the title.
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title The title to set.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return Returns the type.
     */
    public int getType() {
        return type;
    }

    /**
     * @param type The type to set.
     */
    public void setType(int type) {
        this.type = type;
    }

    public Collection getAuthors() {
        return authors;
    }

    public void setAuthors(Collection authors) {
        this.authors = authors;
    }

    static public DocumentDetails makeDocumentDetails(File file) throws IOException, ParseException {
        byte[] aPdfIn;
        String title, creationDate, uri;
        int type;
        Collection authors, keywords;
        ID id;
        String authorsTMP, keywordsTMP, idTMP;

        aPdfIn = new byte[(int) file.length()];
        FileInputStream strm = new FileInputStream(file);
        strm.read(aPdfIn);

        PdfReader reader = new PdfReader(aPdfIn);
        Map info = reader.getInfo();

        authorsTMP = (String) info.get("Author");
        title = (String) info.get("Title");
        keywordsTMP = (String) info.get("Keywords");
        creationDate = (String) info.get("Created");
        type = new Integer((String) info.get("Type")).intValue();
        idTMP = (String) info.get("ID");
        

        StringTokenizer authorsToken = new StringTokenizer(authorsTMP, ",");
        authors = new ArrayList();
        while (authorsToken.hasMoreTokens()) {
            authors.add(authorsToken.nextToken().trim());
        }

        StringTokenizer keywordsToken = new StringTokenizer(keywordsTMP, ",");
        keywords = new ArrayList();
				while (keywordsToken.hasMoreTokens()) {
            keywords.add(keywordsToken.nextToken().trim());
        }
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        java.util.Date date = dateFormat.parse(creationDate);
        //TODO: settare in data ore minuti secondi millisecondi a 0
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        
        StringTokenizer idToken = new StringTokenizer(idTMP, "-");
        id = new ID(idToken.nextToken(), new Integer(idToken.nextToken()), new Integer(idToken.nextToken()));

        DocumentDetails documentDetails = new DocumentDetails(authors, title, keywords, date, type, id, file);

        return documentDetails;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }
}
