/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dipartimento.ws;

import java.rmi.Remote;
import java.rmi.RemoteException;
import utils.SearchDetails;
import utils.SearchResult;

/**
 *
 * @author benve
 */
public interface DipartimentoWS extends Remote {

	public SearchResult[] getAllDocuments() throws RemoteException;

	public byte[] getDocumentFile(String id) throws RemoteException;

	public SearchResult[] getDocuments(SearchDetails sd) throws RemoteException;
}
