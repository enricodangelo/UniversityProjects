--------------------------------------------------------------------------------
LOGIN CON DATABASE
--------------------------------------------------------------------------------

Documentazione:
http://docs.jboss.org/jbossas/getting_started/v4/html/dukesbank.html


Da aggiungere a $JBOSS/server/default/conf/login-config.xml (va inserito prima di  <application-policy name = "other"> che e' la configurazione di default)

<application-policy name="ateneo"> 
    <authentication> 
        <login-module code="org.jboss.security.auth.spi.DatabaseServerLoginModule" 
        flag="required"> 
            <module-option name="dsJndiName">java:/DefaultDS</module-option> 
            <module-option name="principalsQuery">select passwd from Users where username=?</module-option> 
            <module-option name="rolesQuery">select userRoles,'Roles' from UserRoles where username=?</module-option> 
            <module-option name="hashAlgorithm">MD5</module-option> 
            <module-option name="hashEncoding">base64</module-option>
        </login-module> 
    </authentication> 
</application-policy>

<application-policy name="dipartimento"> 
    <authentication> 
        <login-module code="org.jboss.security.auth.spi.DatabaseServerLoginModule" 
        flag="required"> 
            <module-option name="dsJndiName">java:/DefaultDS</module-option> 
            <module-option name="principalsQuery">select passwd from Users where username=?</module-option> 
            <module-option name="rolesQuery">select userRoles,'Roles' from UserRoles where username=?</module-option> 
            <module-option name="hashAlgorithm">MD5</module-option> 
            <module-option name="hashEncoding">base64</module-option>
        </login-module> 
    </authentication> 
</application-policy> 


Per creare le tabelle necessarie e inserire i valori (la password va gia' inserita in hash)
CREATE TABLE Users(username VARCHAR(64) PRIMARY KEY, passwd VARCHAR(64)) 
CREATE TABLE UserRoles(username VARCHAR(64), userRoles VARCHAR(32))
                        
INSERT INTO Users VALUES ('USER','PASSWORDMD5') 
INSERT INTO UserRoles VALUES ('USER','SECURITYROLE')


Per generare l'hash di una password
echo -n "PASSWORD" | openssl dgst -md5 -binary | openssl base64 


--------------------------------------------------------------------------------
IDGENERATIONBEAN
--------------------------------------------------------------------------------

L'entity Bean IDGenerationBean ha gia' al momento del deploy i valori corretti settati.
ad es.
-------------------------------
| Informatica | CS | 2008 | 0 |
-------------------------------
I valori sono il nome del dipartimento (pk), la sigla del dipartimento (depname), l'anno corrente (year), e il numero progressivo dell'id (id).
Il valore del numero progressivo dell'id va settato al valore precedente del primo valore valido (in modo che ogni volta basta incrementare di 1 per avere il primo valore corretto)

QUERY per creare la tabella:
CREATE TABLE IDGENERATIONBEAN(pk VARCHAR(64) PRIMARY KEY, depname VARCHAR(64), year INTEGER, id INTEGER)

QUERY per inserire i valori in tabella:
INSERT INTO IDGENERATIONBEAN VALUES ('Informatica','CS', 2008, 0)


--------------------------------------------------------------------------------
DEPARTMENTBEAN
--------------------------------------------------------------------------------

...


--------------------------------------------------------------------------------
GENERARE IL WSDL
--------------------------------------------------------------------------------

$NETBEANS_PROJECTS_DIR/Dipartimento/Dipartimento-ejb/src/conf$ $JBOSS_HOME/bin/wstools.sh -config $NETBEANS_PROJECTS_DIR/Dipartimento/Dipartimento-ejb/src/conf/wstool-config.xml -cp $NETBEANS_PROJECTS_DIR/Utils/dist/Utils.jar

Ricordarsi poi di cambiare l'indirizzo del wsdl, es. <soap:address location='http://192.168.0.101:8080/Dipartimento-ejb/DipartimentoWSBean'/>


--------------------------------------------------------------------------------
CREARE UN PDF PER IL PROGETTO
--------------------------------------------------------------------------------

java -jar makepdf.jar <AUTHORS> <TITLE> <ID> <KEYWORDS> <CREATION DATE> <TYPE> [<FILE NAME>]

Per AUTHORS, TITLE e KEYWORDS delimitare il tutto con ". Ad es. "Enrico D'Angelo, Giacomo Benvenuti" "Titolo con piu' parole" "key1a key1b, key2"
La data va nel formato gg/mm/aaaa
makepdf.jar e' su http://groups.google.com/group/progetto-ingegneria-middleware
Se il nome del file non viene passato mi pare che usi "file.pdf"


--------------------------------------------------------------------------------
EVITARE IL REWRITING DI soap:address NEL WSDL DA PARTE DI JBOSS
--------------------------------------------------------------------------------

Nel file: $JBOSS_HOME/server/default/deploy/jbossws14.sar/jbossws.beans/META-INF/jboss-beans.xml
modificare: <property name="alwaysModifySOAPAddress">true</property>
in: <property name="alwaysModifySOAPAddress">false</property>

Se $JBOSS_HOME/server/default/deploy/jbossws14.sar/jbossws.beans non e' una directory ma e' un file occorre scompattarlo, in realta' e' un archivio zip, e mettere il suo contenuto (una directory META-INF) all'interno di una directory col nome "jbossws.beans". Attenzione che la directory da creare ha lo stesso nome dell'archivio.