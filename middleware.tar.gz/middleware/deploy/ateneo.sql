DROP TABLE departmentbean if exists;


CREATE TABLE departmentbean(
  pk VARCHAR(64) PRIMARY KEY,
  url VARCHAR(64),
  name VARCHAR(64));

INSERT INTO departmentbean VALUES ('CS','192.168.0.142:8080','Dipartimento di Scienze dell Informazione')
INSERT INTO departmentbean VALUES ('DM','192.168.0.143:8080','Dipartimento di Matematica')
INSERT INTO departmentbean VALUES ('LF','192.168.0.101:8080','Dipartimento di Lettere e Filofosia')