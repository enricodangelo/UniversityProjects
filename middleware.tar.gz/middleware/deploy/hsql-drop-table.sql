DROP TABLE users if exists;
DROP TABLE userroles if exists;
DROP TABLE authorbean if exists;
DROP TABLE authorbean_documents_documentbean_authors if exists;
DROP TABLE documentbean if exists;
DROP TABLE idgenerationbean if exists;
DROP TABLE pendingidbean if exists;