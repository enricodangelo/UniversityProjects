INSERT INTO users VALUES ('berardi','V6qIuOI/kkemjJYS4+gzHw==')
INSERT INTO userroles VALUES ('berardi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('berardi','Amanda Berardi')

INSERT INTO users VALUES ('neri','JhJFsbciymgejoZFHLQiFg==')
INSERT INTO userroles VALUES ('neri','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('neri','Andrea Neri')

INSERT INTO users VALUES ('lisi','3DqPFnDWW+ppt7ZQSKCsQA==')
INSERT INTO userroles VALUES ('lisi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('lisi','Alessandro Lisi')

INSERT INTO users VALUES ('giovagnoli','QZqYSU+t9DSbMDCj5+V0CQ==')
INSERT INTO userroles VALUES ('giovagnoli','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('giovagnoli','Alfredo Giovagnoli')

INSERT INTO users VALUES ('succi','+lY0bAnWRhr7TgFNzb5UUA==')
INSERT INTO userroles VALUES ('succi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('succi','Arianna Succi')

INSERT INTO users VALUES ('pagliarani','7OWGBbJxrx+h5oeS2sUeNA==')
INSERT INTO userroles VALUES ('pagliarani','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('pagliarani','Augusto Pagliarani')

INSERT INTO users VALUES ('arlotti','DTq2l6tE+uSupAl9QQJHGA==')
INSERT INTO userroles VALUES ('arlotti','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('arlotti','Beppe Arlotti')

INSERT INTO users VALUES ('zamagni','NpoqlXE9yJpbXNamDvLG0Q==')
INSERT INTO userroles VALUES ('zamagni','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('zamagni','Cristina Zamagni')

INSERT INTO users VALUES ('sartini','PXB8nSKWOU/IEXy+2Ct6ag==')
INSERT INTO userroles VALUES ('sartini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('sartini','Daniele Sartini')

INSERT INTO users VALUES ('canini','vYO5a8TyE0vDipGPvGryUg==')
INSERT INTO userroles VALUES ('canini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('canini','Diana Canini')

INSERT INTO users VALUES ('fantini','MK3ZY7Cjx9gKuRCN66mT7A==')
INSERT INTO userroles VALUES ('fantini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('fantini','Elena Fantini')

INSERT INTO users VALUES ('paganelli','3sotpEe6sLMfgmex99nZ4g==')
INSERT INTO userroles VALUES ('paganelli','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('paganelli','Enzo Paganelli')

INSERT INTO users VALUES ('gasperoni','JTB5yWUjw1JZSItU35tuRQ==')
INSERT INTO userroles VALUES ('gasperoni','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('gasperoni','Fabiano Gasperoni')

INSERT INTO users VALUES ('cavalli','yvtxhBFTBBX8tzRFfkjLWA==')
INSERT INTO userroles VALUES ('cavalli','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('cavalli','Fabrizio Cavalli')

INSERT INTO users VALUES ('bianchini','rDfMewUiJVAj6o074jfWmA==')
INSERT INTO userroles VALUES ('bianchini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('bianchini','Filippo Bianchini')

INSERT INTO users VALUES ('mazzotti','ap7X6A15kg4Vrpnrmap+dQ==')
INSERT INTO userroles VALUES ('mazzotti','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('mazzotti','Francesca Mazzotti')

INSERT INTO users VALUES ('manfroni','eSno1B1Nh7bbY7ffsNG3nw==')
INSERT INTO userroles VALUES ('manfroni','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('manfroni','Francesco Manfroni')

INSERT INTO users VALUES ('guerra','eJqYCU1pgmY3/973uldf7g==')
INSERT INTO userroles VALUES ('guerra','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('guerra','Franco Guerra')

INSERT INTO users VALUES ('mondaini','wDQIrEvTilxB1jhYxdS7EQ==')
INSERT INTO userroles VALUES ('mondaini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('mondaini','Giovanna Mondaini')

INSERT INTO users VALUES ('bartolini','EwcNh6k4QZjgrPcR6XUAOQ==')
INSERT INTO userroles VALUES ('bartolini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('bartolini','Luca Bartolini')