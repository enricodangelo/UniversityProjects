DROP TABLE idgenerationbean if exists;

CREATE TABLE idgenerationbean(pk VARCHAR(64) PRIMARY KEY, depname VARCHAR(64), year INTEGER, id INTEGER)

INSERT INTO idgenerationbean VALUES ('LF','Dipartimento di Lettere e Filosofia',2008,0)