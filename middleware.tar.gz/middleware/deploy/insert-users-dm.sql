INSERT INTO users VALUES ('pesaresi','yWwDQWHa6YfaGhyU/yOSjg==')
INSERT INTO userroles VALUES ('pesaresi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('pesaresi','Abele Pesaresi')

INSERT INTO users VALUES ('carlini','zd6JxUa+UnWdHOB5WBE32g==')
INSERT INTO userroles VALUES ('carlini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('carlini','Ada Carlini')

INSERT INTO users VALUES ('bernardi','ZytKseqMi2HMdz4A9+lFvg==')
INSERT INTO userroles VALUES ('bernardi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('bernardi','Abramo Bernardi')

INSERT INTO users VALUES ('giannini','yOjJcqevifP74IBh2OmzZg==')
INSERT INTO userroles VALUES ('giannini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('giannini','Alessandra Giannini')

INSERT INTO users VALUES ('zaghini','GQhBRuzhB2FhtQ8UFDUsAQ==')
INSERT INTO userroles VALUES ('zaghini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('zaghini','Adamo Zaghini')

INSERT INTO users VALUES ('balducci','4nuIoADzBboJ7Iu/lSRZuQ==')
INSERT INTO userroles VALUES ('balducci','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('balducci','Anna Balducci')

INSERT INTO users VALUES ('grossi','ZnchryH5ElmRGBd01jQN7A==')
INSERT INTO userroles VALUES ('grossi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('grossi','Alessandro Grossi')

INSERT INTO users VALUES ('conti','I2xaUUe/fgIDueJ4rFqUpA==')
INSERT INTO userroles VALUES ('conti','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('conti','Berenice Conti')

INSERT INTO users VALUES ('frisoni','Wn7jkKmfkoUUT8BZTtIskw==')
INSERT INTO userroles VALUES ('frisoni','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('frisoni','Andrea Frisoni')

INSERT INTO users VALUES ('moretti','RYhwO3acb4gtjXwbhpOdSA==')
INSERT INTO userroles VALUES ('moretti','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('moretti','Carmela Moretti')

INSERT INTO users VALUES ('galli','FJZYMZwL1DNShA8aBUuPsw==')
INSERT INTO userroles VALUES ('galli','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('galli','Barnaba Galli')

INSERT INTO users VALUES ('ugolini','ETxnknslhceMRF3C6b01Aw==')
INSERT INTO userroles VALUES ('ugolini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('ugolini','Luisa Ugolini')

INSERT INTO users VALUES ('vandi','5WPr2eRgs4jll598dFDAsg==')
INSERT INTO userroles VALUES ('vandi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('vandi','Bartolomeo Vandi')

INSERT INTO users VALUES ('perazzini','SFZoy8st1rr5yqvpEY3aBQ==')
INSERT INTO userroles VALUES ('perazzini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('perazzini','Chloe Perazzini')

INSERT INTO users VALUES ('nanni','uRTv9hqOk96tGWYvcS1jlA==')
INSERT INTO userroles VALUES ('nanni','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('nanni','Beniamino Nanni')

INSERT INTO users VALUES ('sarti','QRo+dG+Z5noXdfSRL+DV8A==')
INSERT INTO userroles VALUES ('sarti','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('sarti','Claudia Sarti')

INSERT INTO users VALUES ('corbelli','/So40kTA9CVhnZJZz8qfZA==')
INSERT INTO userroles VALUES ('corbelli','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('corbelli','Christian Corbelli')

INSERT INTO users VALUES ('amati','xRXv+OuVk/3V3qbynWLIng==')
INSERT INTO userroles VALUES ('amati','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('amati','Crystal Amati')

INSERT INTO users VALUES ('tosi','9ViHP9o+CBf04ULE0tKZCA==')
INSERT INTO userroles VALUES ('tosi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('tosi','Clemente Tosi')

INSERT INTO users VALUES ('bugli','1eKFjc7VHiMighq8UXHWbg==')
INSERT INTO userroles VALUES ('bugli','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('bugli','Deborah Bugli')