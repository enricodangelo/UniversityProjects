DROP TABLE users if exists;
DROP TABLE userroles if exists;
DROP TABLE authorbean if exists;

CREATE TABLE users(
  username VARCHAR(64) PRIMARY KEY,
  passwd VARCHAR(64));

CREATE TABLE userroles(
  username VARCHAR(64) PRIMARY KEY,
  userRoles VARCHAR(64));

CREATE TABLE authorbean(
  pk VARCHAR(64) PRIMARY KEY,
  name VARCHAR(64));