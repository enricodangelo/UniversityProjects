INSERT INTO users VALUES ('amministratore','55LNlmURmxJE6K/PNvtfSA==')
INSERT INTO userroles VALUES ('amministratore','Amministratore')