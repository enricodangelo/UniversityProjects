INSERT INTO users VALUES ('donati','ZWmRxROQHJxlFQZVUbjNvQ==')
INSERT INTO userroles VALUES ('donati','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('donati','Ilaria Donati')

INSERT INTO users VALUES ('mussoni','+6Z0/MzivlgEnu7Ji7WgcQ==')
INSERT INTO userroles VALUES ('mussoni','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('mussoni','Christian Mussoni')

INSERT INTO users VALUES ('guidi','TEy5Q1X9arqDjAt+H1B4gg==')
INSERT INTO userroles VALUES ('guidi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('guidi','Viola Guidi')

INSERT INTO users VALUES ('bertozzi','vpStnmRIrwFHlKjkHvSzzw==')
INSERT INTO userroles VALUES ('bertozzi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('bertozzi','Alessandro Bertozzi')

INSERT INTO users VALUES ('mancini','4iW4hZEKx2mSOstl9A277w==')
INSERT INTO userroles VALUES ('mancini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('mancini','Ludovica Mancini')

INSERT INTO users VALUES ('fabbri','bERm7jMN1hdREEEhnx8jUA==')
INSERT INTO userroles VALUES ('fabbri','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('fabbri','Andrea Fabbri')

INSERT INTO users VALUES ('rossi','K/ZSdct/Xclf69fUbNfQrw==')
INSERT INTO userroles VALUES ('rossi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('rossi','Giulia Rossi')

INSERT INTO users VALUES ('bianchi','H1yMPOXjxjWriZ1ZyGNQCQ==')
INSERT INTO userroles VALUES ('bianchi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('bianchi','Lorenzo Bianchi')

INSERT INTO users VALUES ('casadei','7OzQL1SSQkQne6Mgo/k+vA==')
INSERT INTO userroles VALUES ('casadei','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('casadei','Alessia Casadei')

INSERT INTO users VALUES ('semprini','OLVzQfyx1/NFuEK3x7AmNg==')
INSERT INTO userroles VALUES ('semprini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('semprini','Simone Semprini')

INSERT INTO users VALUES ('morri','P56IorYqO+QshC/WmGNnNw==')
INSERT INTO userroles VALUES ('morri','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('morri','Alice Morri')

INSERT INTO users VALUES ('urbinati','88/k+ABv0ZctxQSgCaqZnA==')
INSERT INTO userroles VALUES ('urbinati','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('urbinati','Paolo Urbinati')

INSERT INTO users VALUES ('montanari','JjQo8y84GWOhAAMh+NS+8w==')
INSERT INTO userroles VALUES ('montanari','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('montanari','Chiara Montanari')

INSERT INTO users VALUES ('ricci','CD0hgtyP3wg0sRIlaAKuKg==')
INSERT INTO userroles VALUES ('ricci','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('ricci','Marco Ricci')

INSERT INTO users VALUES ('pari','ApHQ7oCetg3u3IZODBA4DQ==')
INSERT INTO userroles VALUES ('pari','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('pari','Gaia Pari')

INSERT INTO users VALUES ('angelini','9ebIoqa5G1Oz5LG6+DyXBw==')
INSERT INTO userroles VALUES ('angelini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('angelini','Francesco Angelini')

INSERT INTO users VALUES ('magnani','YkEkytiVKXRK+kLGCr2AeQ==')
INSERT INTO userroles VALUES ('magnani','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('magnani','Ginevra Magnani')

INSERT INTO users VALUES ('tamburini','I6f+zRAul43g4cqJMyGeaw==')
INSERT INTO userroles VALUES ('tamburini','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('tamburini','Luca Tamburini')

INSERT INTO users VALUES ('rinaldi','XLNXRLw318Rv02ZKUMtPlQ==')
INSERT INTO userroles VALUES ('rinaldi','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('rinaldi','Emma Rinaldi')

INSERT INTO users VALUES ('celli','c2ERX23kDz1APZUoFOfVqw==')
INSERT INTO userroles VALUES ('celli','AfferenteDipartimento')
INSERT INTO authorbean VALUES ('celli','Tommaso Celli')