// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using PiDuce.Types;
using PiDuce.Common;
using PiDuce.Web;

using IPattern = PiDuce.Common.ISchema;

namespace PiDuce.Compiler
{
	public class ExpressionSchemaContext
	{
		private readonly IDictionary<IExpression, ISchema> context;

		public void SetSchema(IExpression expr, ISchema s)
		{
			Debug.Assert(!context.ContainsKey(expr));
			context.Add(expr, s);
		}

		public ISchema GetSchema(IExpression expr)
		{
			Debug.Assert(context.ContainsKey(expr));
			return context[expr];
		}

		public ExpressionSchemaContext()
		{ context = new Dictionary<IExpression, ISchema>(); }
	}

	public class SchemaOfExpressionVisitor : IExpressionVisitor
	{
		private readonly ISchema boolSchema = new BasicSchema(new BoolType());
		private readonly ISchema intSchema = new BasicSchema(new IntType());
		private readonly ISchema floatSchema = new BasicSchema(new FloatType());
		private readonly ISchema stringSchema = new BasicSchema(new StringType());
		private readonly LocationContext locationContext;
		private readonly ExpressionSchemaContext schemaContext;
		private readonly ISchemaChecker checker;
		private ISchema result;

		private ISchema MaxSchema(ISchema s1, ISchema s2)
		{
			if (checker.IsSubschema(s1, boolSchema) && checker.IsSubschema(s2, boolSchema))
				return boolSchema;
			else if (checker.IsSubschema(s1, intSchema))
				if (checker.IsSubschema(s2, intSchema))
					return intSchema;
				else if (checker.IsSubschema(s2, floatSchema))
					return floatSchema;
				else
					return null;
			else if (checker.IsSubschema(s1, floatSchema))
				if (checker.IsSubschema(s2, intSchema) || checker.IsSubschema(s2, floatSchema))
					return floatSchema;
				else
					return null;
			else if (checker.IsSubschema(s1, stringSchema) && checker.IsSubschema(s2, stringSchema))
				return stringSchema;
			else
				return null;
		}

		public SchemaOfExpressionVisitor(LocationContext locationContext, ExpressionSchemaContext schemaContext, ISchemaChecker checker)
		{
			this.locationContext = locationContext;
			this.schemaContext = schemaContext;
			this.checker = checker;
		}

		public ISchema SchemaOf(IExpression expr)
		{
			locationContext.Enter(expr);
			try {
				expr.Accept(this);
				locationContext.Exit(expr);
				schemaContext.SetSchema(expr, result);
				return result;
			} catch (Exception) {
				locationContext.Exit(expr);
				throw;
			}
		}

		public void VisitVoidExpr(VoidExpr expr)
		{ result = new VoidSchema(); }

		public void VisitLiteralExpr(LiteralExpr expr)
		{ result = new BasicSchemaLiteralSchema(expr.Content); }

		public void VisitVariableExpr(VariableExpr expr)
		{
			Debug.Assert(expr.Entry != null, "no entry");
			Debug.Assert(expr.Entry.Schema != null, "no schema for " + expr.Name);
			result = expr.Entry.Schema;
		}

		public void VisitSelectExpr(SelectExpr expr)
		{
			ISchema s = SchemaOf(expr.Content);
			if (s is ServiceSchema) {
				ServiceSchema r = (ServiceSchema) s;
				if (r.Operations.ContainsKey(expr.Field))
					result = r.Operations[expr.Field];
				else {
					CompilerOutput.Error("record schema " + s + " has no field named `" + expr.Field + "'", locationContext.GetLocation(expr));
					result = null;
				}
			} else {
				CompilerOutput.Error("type mismatch: expected record schema, got " + s, locationContext.GetLocation(expr));
				result = null;
			}
		}

		public void VisitRecordExpr(RecordExpr expr)
		{
			IDictionary<string, ISchema> fields = new Dictionary<string, ISchema>();
			foreach (KeyValuePair<string, IExpression> pair in expr.Fields)
				fields.Add(pair.Key, SchemaOf(pair.Value));
			result = new ServiceSchema(fields);
		}

		public void VisitLabelledExpr(LabelledExpr expr)
		{ result = new LabelledSchema(LabelSet.Singleton(expr.Label), SchemaOf(expr.Content)); }

		public void VisitSequenceExpr(SequenceExpr expr)
		{ result = new SequenceSchema(SchemaOf(expr.Head), SchemaOf(expr.Tail)); }

		public void VisitBinaryOpExpr(BinaryOpExpr expr)
		{
			ISchema left = SchemaOf(expr.Left);
			ISchema right = SchemaOf(expr.Right);
			result = null;
			ISchema maxSchema = MaxSchema(left, right);

			switch (expr.Op) {
				case BinaryOp.PLUS:
				case BinaryOp.MINUS:
				case BinaryOp.TIMES:
				case BinaryOp.DIVIDE:
          if (maxSchema == null || (!checker.IsSubschema(maxSchema, intSchema) && !checker.IsSubschema(maxSchema, floatSchema)))
						CompilerOutput.Error("type mismatch: " + left + " is not compatible with " + right, locationContext.GetLocation(expr));
          result = maxSchema;
					break;
				case BinaryOp.EQ:
				case BinaryOp.NE:
				case BinaryOp.LT:
				case BinaryOp.GT:
				case BinaryOp.LE:
				case BinaryOp.GE:
          if (maxSchema == null)
						CompilerOutput.Error("type mismatch: " + left + " is not compatible with " + right, locationContext.GetLocation(expr));
					result = boolSchema;
          break;
				case BinaryOp.LAND:
				case BinaryOp.LOR:
          if (!checker.IsSubschema(left, boolSchema) || !checker.IsSubschema(right, boolSchema))
						CompilerOutput.Error("type mismatch: " + left + " is not compatible with " + right, locationContext.GetLocation(expr));
					result = boolSchema;
          break;
        default:
					Debug.Assert(false); // IMPOSSIBLE
          break;
      }

			if (result == null) {
				result = new ErrorSchema();
			}
		}

		public void VisitUnaryOpExpr(UnaryOpExpr expr)
		{
			ISchema content = SchemaOf(expr.Content);
			ISchema intSchema = new BasicSchema(new IntType());
			ISchema boolSchema = new BasicSchema(new BoolType());
			result = null;

			switch (expr.Op) {
				case UnaryOp.UMINUS:
         	if (!checker.IsSubschema(content, intSchema))
						CompilerOutput.Error("int expected", locationContext.GetLocation(expr));
					result = intSchema;
					break;
				case UnaryOp.LNOT:
					if (!checker.IsSubschema(content, boolSchema))
						CompilerOutput.Error("bool expected", locationContext.GetLocation(expr));
					result = boolSchema;
					break;
				default:
					Debug.Assert(false); // IMPOSSIBLE
					break;
			}

			if (result == null) {
				result = new ErrorSchema();
			}
		}
	}

	public class SchemaOfPatternVisitor : AbstractSchemaVisitor
	{
		private readonly LocationContext locationContext;
		private readonly ISchemaChecker checker;
    private IDictionary<IEntry, ISchema> entries;
		private ISchema result;

		public SchemaOfPatternVisitor(LocationContext locationContext, ISchemaChecker checker)
		{
			this.locationContext = locationContext;
			this.checker = checker;
		}

    public ISchema SchemaOf(IPattern pattern)
    {
      SchemaOf(pattern, out entries);
      foreach (KeyValuePair<IEntry, ISchema> pair in entries) {
        Debug.Assert(pair.Key.Schema == null);
        pair.Key.Schema = pair.Value;
				//Console.WriteLine("binding {0} schema {1}", pair.Key.Name, pair.Key.Schema);
      }
      return result;
    }

		private ISchema SchemaOf(IPattern pattern, out IDictionary<IEntry, ISchema> entries)
		{
			pattern.Accept(this);
			entries = this.entries;
			return result;
		}

    private static IDictionary<IEntry, ISchema> Empty()
    { return new Dictionary<IEntry, ISchema>(); }

		public override void VisitLabelledSchema(LabelledSchema s)
		{
			ISchema content = SchemaOf(s.Content, out entries);
			if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new LabelledSchema(s.Labels, content);
		}

		public override void VisitSequenceSchema(SequenceSchema s)
		{
			IDictionary<IEntry, ISchema> headEntries;
			IDictionary<IEntry, ISchema> tailEntries;
			ISchema head = SchemaOf(s.Head, out headEntries);
			ISchema tail = SchemaOf(s.Tail, out tailEntries);
			if (Object.ReferenceEquals(head, s.Head) && Object.ReferenceEquals(tail, s.Tail))
				result = s;
			else
				result = new SequenceSchema(head, tail);
      entries = Empty();
      foreach (KeyValuePair<IEntry, ISchema> pair in headEntries)
        if (tailEntries.ContainsKey(pair.Key))
          entries.Add(pair.Key, new SequenceSchema(pair.Value, tailEntries[pair.Key]));
        else
          entries.Add(pair.Key, pair.Value);
      foreach (KeyValuePair<IEntry, ISchema> pair in tailEntries)
        if (!headEntries.ContainsKey(pair.Key))
          entries.Add(pair.Key, pair.Value);
    }

		public override void VisitUnionSchema(UnionSchema s)
		{
			IDictionary<IEntry, ISchema> leftEntries;
			IDictionary<IEntry, ISchema> rightEntries;
			ISchema left = SchemaOf(s.Left, out leftEntries);
			ISchema right = SchemaOf(s.Right, out rightEntries);
			if (Object.ReferenceEquals(left, s.Left) && Object.ReferenceEquals(right, s.Right))
				result = s;
			else
				result = UnionSchema.Make(left, right);
      entries = Empty();
      foreach (KeyValuePair<IEntry, ISchema> pair in leftEntries)
        if (rightEntries.ContainsKey(pair.Key))
          entries.Add(pair.Key, UnionSchema.Make(pair.Value, rightEntries[pair.Key]));
        else
          entries.Add(pair.Key, new RepetitionSchema(pair.Value, 0, 1));
      foreach (KeyValuePair<IEntry, ISchema> pair in rightEntries)
        if (!leftEntries.ContainsKey(pair.Key))
          entries.Add(pair.Key, new RepetitionSchema(pair.Value, 0, 1));
		}

		public override void VisitStarSchema(StarSchema s)
		{
      IDictionary<IEntry, ISchema> contentEntries;
			ISchema content = SchemaOf(s.Content, out contentEntries);
			if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new StarSchema(content);
      entries = Empty();
      foreach (KeyValuePair<IEntry, ISchema> pair in contentEntries)
        entries.Add(pair.Key, new StarSchema(pair.Value));
		}

		public override void VisitPlusSchema(PlusSchema s)
		{
      IDictionary<IEntry, ISchema> contentEntries;
      ISchema content = SchemaOf(s.Content, out contentEntries);
			if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new PlusSchema(content);
      entries = Empty();
      foreach (KeyValuePair<IEntry, ISchema> pair in contentEntries)
        entries.Add(pair.Key, new StarSchema(pair.Value));
		}

		public override void VisitRepetitionSchema(RepetitionSchema s)
		{
      IDictionary<IEntry, ISchema> contentEntries;
      ISchema content = SchemaOf(s.Content, out contentEntries);
      if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new RepetitionSchema(content, s.MinOccurs, s.MaxOccurs);
      entries = Empty();
      foreach (KeyValuePair<IEntry, ISchema> pair in contentEntries)
        entries.Add(pair.Key, new RepetitionSchema(pair.Value, s.MinOccurs, s.MaxOccurs));
		}

		public override void VisitVoidSchema(VoidSchema s)
		{
			result = s;
			entries = Empty();
		}

		public override void VisitBasicSchema(BasicSchema s)
		{
			result = s;
			entries = Empty();
		}

		public override void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
		{
			result = s;
			entries = Empty();
		}

		public override void VisitConstantSchema(ConstantSchema s)
		{
			result = s;
			entries = Empty();
		}

		public override void VisitChannelSchema(ChannelSchema s)
		{
			ISchema content = SchemaOf(s.Content, out entries);
			if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new ChannelSchema(content, s.Capability);
			entries = Empty();
		}

		public override void VisitFunctionSchema(FunctionSchema s)
		{
			IDictionary<IEntry, ISchema> inputEntries;
			IDictionary<IEntry, ISchema> outputEntries;
			ISchema input = SchemaOf(s.Input, out inputEntries);
			ISchema output = SchemaOf(s.Output, out outputEntries);
			if (Object.ReferenceEquals(input, s.Input) && Object.ReferenceEquals(output, s.Output))
				result = s;
			else
				result = new FunctionSchema(input, output);
			entries = Empty();
		}

		public override void VisitErrorSchema(ErrorSchema s)
		{
			result = s;
			entries = Empty();
		}

		public override void VisitBindSchema(BindSchema s)
		{
			result = SchemaOf(s.Content, out entries);
			Debug.Assert(s.Entry != null);
      entries = Empty();
			entries.Add(s.Entry, result);
#if false
			if (s.Entry.Schema == null) {
				s.Entry.Schema = result;
			} else {
				if (!checker.IsSubschema(s.Entry.Schema, result) || !checker.IsSubschema(result, s.Entry.Schema))
					CompilerOutput.Error("all occurrences of `" + s.Entry.Name + "' must have the same type", locationContext.GetLocation(s));
			}
#endif
		}
	}

	public class CheckProcessVisitor : IProcessVisitor
	{
		private readonly LocationContext locationContext;
		private readonly ISchemaChecker checker;
		private readonly SchemaOfPatternVisitor patternVisitor;
		private readonly SchemaOfExpressionVisitor exprVisitor;
		private readonly IDictionary<IPattern, ISchema> map;

		public CheckProcessVisitor(LocationContext locationContext, ExpressionSchemaContext schemaContext, ISchemaChecker checker)
		{
			this.locationContext = locationContext;
			this.checker = checker;
			this.patternVisitor = new SchemaOfPatternVisitor(this.locationContext, checker);
			this.exprVisitor = new SchemaOfExpressionVisitor(this.locationContext, schemaContext, checker);
			this.map = new Dictionary<IPattern, ISchema>();
		}

		public void Check(IProcess p)
		{
			locationContext.Enter(p);
			try {
				p.Accept(this);
				locationContext.Exit(p);
			} catch (Exception) {
				locationContext.Exit(p);
				throw;
			}
		}

		private ISchema SchemaOf(IExpression expr)
		{ return exprVisitor.SchemaOf(expr); }

		private ISchema SchemaOf(IPattern p)
		{
			if (map.ContainsKey(p)) {
				// since the type of the entries in the pattern is modified
				// imperatively each time the schema of the pattern is requested this
				// should NOT happen
				Debug.Assert(false, "should not happen");
				return map[p];
			} else {
				ISchema schema = patternVisitor.SchemaOf(p);
				map[p] = schema;
				return schema;
			}
		}

		public void VisitNilProcess(NilProcess p)
		{ }

		public void VisitSpawnProcess(SpawnProcess p)
		{
			Check(p.Left);
			Check(p.Right);
		}

		public void VisitOutputProcess(OutputProcess p)
		{
			ISchema t = SchemaOf(p.Expression);
      ISchema s = SchemaOf(p.Destination);
      if (s == null)
        CompilerOutput.Error("type mismatch: " + p.Destination.ToString() + " is not channel", locationContext.GetLocation(p));
      else
      {
        if (!checker.IsSubschema(s, new ChannelSchema(t, ChannelType.CAPABILITY.OUT)))
          CompilerOutput.Error("type mismatch: expected channel with output capability for " + t, locationContext.GetLocation(p));
      }
		}

		public void VisitInputProcess(InputProcess p)
		{
			ISchema t = SchemaOf(p.Pattern);
      string error;
      if (!checker.IsCorrect(t, out error))
        CompilerOutput.Error("input pattern - error " + error, locationContext.GetLocation(p));
      else {
        ISchema s = SchemaOf(p.Source);
        if (s == null)
          CompilerOutput.Error("type mismatch: " + p.Source.ToString() + " is not channel", locationContext.GetLocation(p));
        else
        {
          if (!checker.IsSubschema(s, new ChannelSchema(t, ChannelType.CAPABILITY.IN)))
            CompilerOutput.Error("type mismatch:\n  expected channel with input capability for\n\t" + t + "\n  got\n\t" + s, locationContext.GetLocation(p));
        }
      }

			Check(p.Continuation);
		}

		public void VisitJoinProcess(JoinProcess p)
		{
			foreach (JoinPatternRow row in p.Rows) {
				IList<string> channels = new List<string>();
				foreach (JoinPatternAtom atom in row.Atoms) {
					if (channels.Contains(atom.Entry.Name))
						CompilerOutput.Error("non-linear join pattern detected: " + atom.Entry.Name + " channel is used multiple times", locationContext.GetLocation(row));
					channels.Add(atom.Entry.Name);
          ISchema s = SchemaOf(atom.Source);
					ISchema t = SchemaOf(atom.Pattern);
      		string error = "";
      		if (!checker.IsCorrect(t, out error))
        		CompilerOutput.Error("input pattern - error " + error, locationContext.GetLocation(atom));
          if (!(atom.Entry.Schema is ChannelSchema || atom.Entry.Schema is FunctionSchema))
						CompilerOutput.Error("channel schema expected", locationContext.GetLocation(atom));
					else {
						if (!((ValueEntry) atom.Entry).Local)
							CompilerOutput.Error("source - " + atom.Source + " - is not local, it cannot be used in a join definition", locationContext.GetLocation(atom));
						if (!checker.IsSubschema(s, new ChannelSchema(t, ChannelType.CAPABILITY.IN)))
              CompilerOutput.Error("type mismatch:\n the pattern is not exhaustive for - " + atom.Entry.Name + "- got\n\t" + t + "\n for\n\t" + s, locationContext.GetLocation(atom));
					}            
        }
				Check(row.Continuation);
			}
		}

		public void VisitMatchProcess(MatchProcess p)
		{
			ISchema schemaofexp = SchemaOf(p.Expression);

			IList<ISchema> schemasofpatterns = new List<ISchema>();
			foreach (MatchProcess.Branch branch in p.Branches) {
				ISchema s = SchemaOf(branch.Pattern);
				string error;
				if (!checker.IsCorrect(s, out error))
					CompilerOutput.Error("pattern - error " + error, locationContext.GetLocation(p));
				schemasofpatterns.Add(s);
				if (branch.Condition != null) {
					ISchema condition = SchemaOf(branch.Condition);
					if (!checker.IsSubschema(condition, new BasicSchema(new BoolType())))
						CompilerOutput.Error("type mismatch: " + condition + " is not compatible with bool", locationContext.GetLocation(condition));
				}
				Check(branch.Process);
			}

			ISchema t = schemasofpatterns[0];
      //a branch is useless iff:
      //(a) it is a subtype of the union of the previous patterns; 
      //(b) the schema of the expression is not a subtype of the previous patterns (previous patterns are exahustive without using the branch)
      //(c) it does not intersect the type of the expression to match
      //if (TypesOperations.EmptyIntersection(checker.SchemaToType(t), checker.SchemaToType(schemaofexp)))
        //CompilerOutput.Warning("pattern matching useless branch (intersection with expression type is empty)", locationContext.GetLocation(((MatchProcess.Branch) p.Branches[0]).Pattern));
			for (int i = 1; i < p.Branches.Count; i++) {
        //if (TypesOperations.EmptyIntersection(checker.SchemaToType(schemasofpatterns[i]), checker.SchemaToType(schemaofexp)))
          //CompilerOutput.Warning("useless branch (intersection with expression type is empty)", locationContext.GetLocation(((MatchProcess.Branch) p.Branches[i]).Pattern));
        //else if (checker.IsSubschema(schemasofpatterns[i], t) || checker.IsSubschema(schemaofexp, t))
          //CompilerOutput.Warning("redundant branch (" + schemasofpatterns[i] + "<:" + t +")", locationContext.GetLocation(((MatchProcess.Branch) p.Branches[i]).Pattern));
				if (p.Branches[i].Condition == null)
					t = UnionSchema.Make(t, schemasofpatterns[i]);
			}
#if true
			if (!checker.IsSubschema(schemaofexp, t))
				CompilerOutput.Error("pattern matching must be exhaustive", locationContext.GetLocation(p));
#endif
		}

    public void VisitImportProcess(ImportProcess p)
    {
      //Compile time wsdl verification
      if (Compiler.CheckWsdl)
      {
        try
        {
          WebClient wc = new WebClient();
          wc.DownloadData(p.Wsdl);
          ServiceSchema localSchema = new ServiceSchema(p.Operations);
          ServiceSchema serviceSchema = AbstractWsdlReader.CompileAbstractWsdl(wc.OpenRead(p.Wsdl));
          if (!checker.IsSubschema(localSchema, serviceSchema))
          { CompilerOutput.Error("service declaration is not compatible with: \" - " + p.Wsdl + " - got\n\t" + localSchema + "\nfor\n\t" + serviceSchema, locationContext.GetLocation(p)); }
        }
        catch (WebException e)
        { CompilerOutput.Warning("\"" + p.Wsdl + "\" is not available " + e.Message, locationContext.GetLocation(p)); }
      }
      else CompilerOutput.Warning("\"" + p.Wsdl + "\" not verified", locationContext.GetLocation(p));
      foreach (KeyValuePair<string, ISchema> operation in p.Operations)
      {
        Debug.Assert(operation.Value != null);
        string error;
 CHE_SIZE = 2048;

    /** Prune stale entries. */
    protected boolean removeEldestEntry(Map.Entry eldest)
    {	// XXX - FIXME Use Map.Entry, not just Entry  as gcj 3.1 workaround.
      return size() > MAX_CACHE_SIZE;
    }
  };

  /** The most recently generated keystroke, or null. */
  private static AWTKeyStroke recent;

  /**
   * The no-arg constructor of a subclass, or null to use AWTKeyStroke. Note
   * that this will be left accessible, to get around private access; but
   * it should not be a security risk as it is highly unlikely that creating
   * protected instances of the subclass via reflection will do much damage.
   */
  private static Constructor ctor;

  /**
   * A table of keyCode names to values.
   *
   * @see #getAWTKeyStroke(String)
   */
  private static final HashMap vktable = new HashMap();
  static
  {
    // Using reflection saves the hassle of keeping this in sync with KeyEvent,
    // at the price of an expensive initialization.
    AccessController.doPrivileged(new PrivilegedAction()
      {
        public Object run()
        {
          Field[] fields = KeyEvent.class.getFields();
          int i = fields.length;
          try
            {
              while (--i >= 0)
                {
                  Field f = fields[i];
                  String name = f.getName();
                  if (name.startsWith("VK_"))
                    vktable.put(name.substring(3), f.get(null));
                }
            }
          catch (Exception e)
            {
              throw (Error) new InternalError().initCause(e);
            }
          return null;
        }
      });
  }

  /**
   * The typed character, or CHAR_UNDEFINED for key presses and releases.
   *
   * @serial the keyChar
   */
  private char keyChar;

  /**
   * The virtual key code, or VK_UNDEFINED for key typed. Package visible for
   * use by Component.
   *
   * @serial the keyCode
   */
  int keyCode;

  /**
   * The modifiers in effect. To match Sun, this stores the old style masks
   * for shift, control, alt, meta, and alt-graph (but not button1); as well
   * as the new style of extended modifiers for all modifiers.
   *
   * @serial bitwise or of the *_DOWN_MASK modifiers
   */
  private int modifiers;

  /**
   * True if this is a key release; should only be true if keyChar is
   * CHAR_UNDEFINED.
   *
   * @serial true to distinguish key pressed from key released
   */
  private boolean onKeyRelease;

  /**
   * Construct a keystroke with default values: it will be interpreted as a
   * key typed event with an invalid character and no modifiers. Client code
   * should use the factory methods instead.
   *
   * @see #getAWTKeyStroke(char)
   * @see #getAWTKeyStroke(Character, int)
   * @see #getAWTKeyStroke(int, int, boolean)
   * @see #getAWTKeyStroke(int, int)
   * @see #getAWTKeyStrokeForEvent(KeyEvent)
   * @see #getAWTKeyStroke(String)
   */
  protected AWTKeyStroke()
  {
    keyChar = KeyEvent.CHAR_UNDEFINED;
  }

  /**
   * Construct 