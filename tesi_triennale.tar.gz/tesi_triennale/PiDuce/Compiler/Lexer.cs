// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Text.RegularExpressions;
using System.Collections;

namespace PiDuce.Compiler
{
	public class GenericValue
	{
		private readonly int location;

		public int Location { get { return location; } }

		public GenericValue(int location)
		{ this.location = location; }
	}

	public class IntValue : GenericValue
	{
		private readonly int val;

		public int Value { get { return val; } }

		public IntValue(int val, int location) : base(location)
		{ this.val = val; }
	}

	public class FloatValue : GenericValue
	{
		private readonly float val;

		public float Value { get { return val; } }

		public FloatValue(float val, int location) : base(location)
		{ this.val = val; }
	}

	public class StringValue : GenericValue
	{
		private readonly String val;

		public String Value { get { return val; } }

		public StringValue(String val, int location) : base(location)
		{ this.val = val; }
	}
    
	public interface IToken
	{		
		/* integer returned by Token's jay class
		 * that correspond at this keyword*/
		int Token { get; }
		/* return true if <code>str</code>
		 * match with this token */
		bool Match(string str, ref int length);
	}

	internal class SimpleToken : IToken	
	{	
		private readonly int token;
		private readonly String val;

		public int Token { get { return token; } }

		public SimpleToken(string val, int token)
		{
			this.val = val;
			this.token = token;
		}

		public bool Match(String str, ref int length)
		{
			length = val.Length;
			return (str.StartsWith(val));
		}
	}

	internal class RegexpToken : IToken	
	{	
		private readonly int token;
		private readonly Regex val;

		public int Token { get { return token; } }

		public RegexpToken(string pattern, int token)
		{
			this.val = new Regex("^(" + pattern + "){1}");
			this.token = token;
		}

		public bool Match(String str, ref int length)
		{
			Match m = val.Match(str);
			length = m.Length;

			return m.Success;
		}
	}
	
	public class Lexer : yyParser.yyInput
	{
		public Object Value;
		private static ArrayList tokens;
    public static ArrayList Tokens { get { return tokens; } }
		private static Hashtable keywords;
    public static Hashtable Keywords { get { return keywords; } }
		private static Regex annotation = new Regex("^(//.*\n)");
		private string m_input = "";
		//line number
		public int location;

    static Lexer() 
    {
      tokens = new ArrayList();
      keywords = new Hashtable();

      tokens.Add(new RegexpToken("\"([^\"]*|(\\\")*)*\"", Token.TEXT));
      tokens.Add(new RegexpToken("([0-9]+\\.[0-9]*)|([0-9]*\\.[0-9]+)", Token.FLOAT));
      tokens.Add(new RegexpToken("[0-9][0-9]*", Token.INT));
      tokens.Add(new RegexpToken("[A-Za-z][A-Za-z0-9_]*", Token.ID));
      tokens.Add(new RegexpToken("`[A-Za-z_]['\\-''.'A-Za-z0-9_]*", Token.ID));
      tokens.Add(new SimpleToken("->", Token.ARROW));
      tokens.Add(new SimpleToken("=>", Token.DARROW));
      tokens.Add(new SimpleToken("!", Token.EMARK));
      tokens.Add(new SimpleToken("?", Token.QMARK));
      tokens.Add(new SimpleToken("&", Token.AMPERSAND));
      tokens.Add(new SimpleToken("-", Token.MINUS));
      tokens.Add(new SimpleToken("==", Token.EQEQ));
      tokens.Add(new SimpleToken("=", Token.EQ));
      tokens.Add(new SimpleToken("^IO", Token.INOUT_CAP));
      tokens.Add(new SimpleToken("^I", Token.IN_CAP));
      tokens.Add(new SimpleToken("^O", Token.OUT_CAP));
      tokens.Add(new SimpleToken("!=", Token.NE));
      tokens.Add(new SimpleToken("{", Token.LBRACE));
      tokens.Add(new SimpleToken("}", Token.RBRACE));
      tokens.Add(new SimpleToken("(", Token.LPAREN));
      tokens.Add(new SimpleToken(")", Token.RPAREN));
      tokens.Add(new SimpleToken("[", Token.LBRACK));
      tokens.Add(new SimpleToken("]", Token.RBRACK));
      tokens.Add(new Simp   inline _InputIterator
    find(_InputIterator __first, _InputIterator __last,
	 const _Tp& __val)
    {
      // concept requirements
      __glibcxx_function_requires(_InputIteratorConcept<_InputIterator>)
      __glibcxx_function_requires(_EqualOpConcept<
		typename iterator_traits<_InputIterator>::value_type, _Tp>)
      __glibcxx_requires_valid_range(__first, __last);
      return std::find(__first, __last, __val,
		       std::__iterator_category(__first));
    }

  /**
   *  @brief Find the first element in a sequence for which a predicate is true.
   *  @param  first  An input iterator.
   *  @param  last   An input iterator.
   *  @param  pred   A predicate.
   *  @return   The first iterator @c i in the range @p [first,last)
   *  such that @p pred(*i) is true, or @p last if no such iterator exists.
  */
  template<typename _InputIterator, typename _Predicate>
    inline _InputIterator
    find_if(_InputIterator __first, _InputIterator __last,
	    _Predicate __pred)
    {
      // concept requirements
      __glibcxx_function_requires(_InputIteratorConcept<_InputIterator>)
      __glibcxx_function_requires(_UnaryPredicateConcept<_Predicate,
	      typename iterator_traits<_InputIterator>::value_type>)
      __glibcxx_requires_valid_range(__first, __last);
      return std::find_if(__first, __last, __pred,
			  std::__iterator_category(__first));
    }

  /**
   *  @brief Find two adjacent values in a sequence that are equal.
   *  @param  first  A forward iterator.
   *  @param  last   A forward iterator.
   *  @return   The first iterator @c i such that @c i and @c i+1 are both
   *  valid iterators in @p [first,last) and such that @c *i == @c *(i+1),
   *  or @p last if no such iterator exists.
  */
  template<typename _ForwardIterator>
    _ForwardIterator
    adjacent_find(_ForwardIterator __first, _ForwardIterator __last)
    {
      // concept requirements
      __glibcxx_function_requires(_ForwardIteratorConcept<_ForwardIterator>)
      __glibcxx_function_requires(_EqualityComparableConcept<
	    typename iterator_traits<_ForwardIterator>::value_type>)
      __glibcxx_requires_valid_range(__first, __last);
      if (__first == __last)
	return __last;
      _ForwardIterator __next = __first;
      while(++__next != __last)
	{
	  if (*__first == *__next)
	    return __first;
	  __first = __next;
	}
      return __last;
    }

  /**
   *  @brief Find two adjacent values in a sequence using a predicate.
   *  @param  first         A forward iterator.
   *  @param  last          A forward iterator.
   *  @param  binary_pred   A binary predicate.
   *  @return   The first iterator @c i such that @c i and @c i+1 are both
   *  valid iterators in @p [first,last) and such that
   *  @p binary_pred(*i,*(i+1)) is true, or @p last if no such iterator
   *  exists.
  */
  template<typename _ForwardIterator, typename _BinaryPredicate>
    _ForwardIterator
    adjacent_find(_ForwardIterator __first, _ForwardIterator __last,
		  _BinaryPredicate __binary_pred)
    {
      // concept requirements
      __glibcxx_function_requires(_ForwardIteratorConcept<_ForwardIterator>)
      __glibcxx_function_requires(_BinaryPredicateConcept<_BinaryPredicate,
	    typename iterator_traits<_ForwardIterator>::value_type,
	    typename iterator_traits<_ForwardIterator>::value_type>)
      __glibcxx_requires_valid_range(__first, __last);
      if (__first == __last)
	return __last;
      _ForwardIterator __next = __first;
      while(++__next != __last)
	{
	  if (__binary_pred(*__first, *__next))
	    return __first;
	  __first = __]{ ^{ _{ `{ a{ b{ c{ d{ e{ f{ g{ h{ i{ j{ k{ l{ m{ n{ o{ p{ q{ r{ s{ t{ u{ v{ w{ x{ y{ z{ {{ |{