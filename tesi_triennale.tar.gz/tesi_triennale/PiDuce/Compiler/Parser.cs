// created by jay 0.7 (c) 1998 Axel.Schreiner@informatik.uni-osnabrueck.de

#line 2 "Parser.jay"
// -*-csharp-*-
// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics;
using PiDuce.Types;
using PiDuce.Common;

// the following aliases are needed because currently Jay does not recognize
// generic types within < ... >

using IPattern = PiDuce.Common.ISchema;
using ISet_string = PiDuce.Common.ISet<string>;
using IList_IProcess = System.Collections.Generic.IList<PiDuce.Common.IProcess>;
using IList_JoinPatternRow = System.Collections.Generic.IList<PiDuce.Common.JoinPatternRow>;
using IList_JoinPatternAtom = System.Collections.Generic.IList<PiDuce.Common.JoinPatternAtom>;
using IDictionary_FieldDecList = System.Collections.Generic.IDictionary<string, PiDuce.Common.ISchema>;
using IDictionary_FieldDefList = System.Collections.Generic.IDictionary<string, PiDuce.Common.IExpression>;
using IList_SchemaProcess_Declaration = System.Collections.Generic.IList<PiDuce.Common.SchemaProcess.Declaration>;
using IList_MatchProcess_Branch = System.Collections.Generic.IList<PiDuce.Common.MatchProcess.Branch>;

namespace PiDuce.Compiler {

	public class SyntaxError : Exception
	{
		public SyntaxError(string msg) : base(msg)
		{ }
	}

	public class LocationContext
	{
		private readonly Stack<int> locations;

		public LocationContext()
		{
			this.locations = new Stack<int>();
		}

		public int GetLocation(Object obj)
		{
			if (PiDuceParser.HasLocation(obj))
				return PiDuceParser.GetLocation(obj);
			else if (locations.Count > 0)
				return locations.Peek();
			else
				return -1;
		}

		public void Enter(Object obj)
		{
			if (PiDuceParser.HasLocation(obj))
				locations.Push(PiDuceParser.GetLocation(obj));
		}

		public void Exit(Object obj)
		{
			if (PiDuceParser.HasLocation(obj))
				locations.Pop();
		}
	}

	public class PiDuceParser {
  	private Lexer lexer;
  	private static IDictionary<Object, int> locationMap;
  	public static int yacc_verbose_flag = 2;

#line default

  /** error output stream.
      It should be changeable.
    */
  public System.IO.TextWriter ErrorOutput = System.Console.Out;

  /** simplified error message.
      @see <a href="#yyerror(java.lang.String, java.lang.String[])">yyerror</a>
    */
  public void yyerror (string message) {
    yyerror(message, null);
  }

  /** (syntax) error message.
      Can be overwritten to control message format.
      @param message text to be displayed.
      @param expected vector of acceptable tokens, if available.
    */
  public void yyerror (string message, string[] expected) {
    CompilerOutput.Error("syntax error", lexer.location);
    if ((yacc_verbose_flag > 0) && (expected != null) && (expected.Length  > 0)) {
      ErrorOutput.Write (message+", expecting");
      for (int n = 0; n < expected.Length; ++ n)
        ErrorOutput.Write (" "+expected[n]);
        ErrorOutput.WriteLine ();
    } else
      ErrorOutput.WriteLine (message);
  }

  /** debugging support, requires the package jay.yydebug.
      Set to null to suppress debugging messages.
    */
//t  internal yydebug.yyDebug debug;

  protected static  int yyFinal = 20;
//t  public static  string [] yyRule = {
//t    "$accept : process",
//t    "process : KW_NIL",
//t    "process : expr EMARK expr",
//t    "process : expr QMARK star_opt pattern DARROW process",
//t    "process : KW_SCHEMA schema_decl_ne_list KW_IN process",
//t    "process : KW_LET pattern EQ expr KW_IN process",
//t    "process : KW_NEW ID operations location_opt KW_IN process",
//t    "process : KW_IMPORT ID operations location_opt KW_IN process",
//t    "process : KW_SPAWN LBRACE process RBRACE process",
//t    "process : KW_MATCH expr KW_WITH LBRACE branch_ne_list RBRACE",
//t    "process : star_opt KW_JOIN LBRACE join_pattern_row_ne_list RBRACE",
//t    "process : KW_IF expr KW_THEN process else_opt",
//t    "process : LBRACE process LBRACE",
//t    "else_opt :",
//t    "else_opt : KW_ELSE process",
//t    "operations : LBRACE field_dec_ne_list RBRACE",
//t    "operations : COLON schema",
//t    "field_dec_ne_list : ID COLON schema",
//t    "field_dec_ne_list : ID COLON schema SEMICOLON field_dec_ne_list",
//t    "star_opt :",
//t    "star_opt : TIMES",
//t    "join_pattern_row_ne_list : join_pattern_row",
//t    "join_pattern_row_ne_list : join_pattern_row_ne_list OR join_pattern_row",
//t    "join_pattern_row : join_pattern_atom_ne_list DARROW process",
//t    "join_pattern_atom_ne_list : join_pattern_atom",
//t    "join_pattern_atom_ne_list : join_pattern_atom_ne_list AMPERSAND join_pattern_atom",
//t    "join_pattern_atom : expr QMARK pattern_opt",
//t    "schema_decl_ne_list : schema_decl",
//t    "schema_decl_ne_list : schema_decl_ne_list KW_AND schema_decl",
//t    "schema_decl : ID EQ schema",
//t    "branch_ne_list : branch",
//t    "branch_ne_list : branch_ne_list OR branch",
//t    "branch : pattern when_opt DARROW process",
//t    "when_opt :",
//t    "when_opt : KW_WHEN expr",
//t    "pattern_opt :",
//t    "pattern_opt : pattern",
//t    "expr_opt :",
//t    "expr_opt : expr",
//t    "literal : INT",
//t    "literal : FLOAT",
//t    "literal : TEXT",
//t    "literal : KW_FALSE",
//t    "literal : KW_TRUE",
//t    "field_def_list :",
//t    "field_def_list : field_def_ne_list",
//t    "field_def_ne_list : ID EQ expr",
//t    "field_def_ne_list : ID EQ expr SEMICOLON field_def_ne_list",
//t    "expr : LPAREN expr_opt RPAREN",
//t    "expr : ID",
//t    "expr : expr DOT ID",
//t    "expr : LBRACE field_def_list RBRACE",
//t    "expr : literal",
//t    "expr : ID LBRACK expr_opt RBRACK",
//t    "expr : expr PLUS expr",
//t    "expr : expr MINUS expr",
//t    "expr : expr TIMES expr",
//t    "expr : expr DIVIDE expr",
//t    "expr : expr LAND expr",
//t    "expr : expr LOR expr",
//t    "expr : expr EQEQ expr",
//t    "expr : expr NE expr",
//t    "expr : expr GT expr",
//t    "expr : expr GE expr",
//t    "expr : expr LT expr",
//t    "expr : expr LE expr",
//t    "expr : expr COMMA expr",
//t    "expr : EMARK expr",
//t    "expr : MINUS expr",
//t    "label_set : ID",
//t    "label_set : TILDE",
//t    "label_set : LBRACE label_comma_list RBRACE",
//t    "label_set : LBRACE TILDE BACKSLASH label_ne_comma_list RBRACE",
//t    "label_comma_list :",
//t    "label_comma_list : label_ne_comma_list",
//t    "label_ne_comma_list : ID",
//t    "label_ne_comma_list : label_ne_comma_list COMMA ID",
//t    "schema_opt :",
//t    "schema_opt : schema",
//t    "basic_type : KW_BOOL",
//t    "basic_type : KW_INT",
//t    "basic_type : KW_FLOAT",
//t    "basic_type : KW_STRING",
//t    "schema : basic_type",
//t    "schema : literal",
//t    "schema : LT schema_opt GT capability_opt",
//t    "schema : schema ARROW capability_opt schema",
//t    "schema : schema OR schema",
//t    "schema : ID",
//t    "schema : ID COLON schema",
//t    "schema : LPAREN RPAREN",
//t    "schema : LPAREN schema RPAREN",
//t    "schema : label_set LBRACK schema_opt RBRACK",
//t    "schema : schema COMMA schema",
//t    "schema : schema TIMES",
//t    "schema : schema PLUS",
//t    "schema : schema LBRACE INT RBRACE",
//t    "schema : schema LBRACE INT COMMA INT RBRACE",
//t    "schema : schema QMARK",
//t    "capability : IN_CAP",
//t    "capability : OUT_CAP",
//t    "capability : INOUT_CAP",
//t    "capability_opt :",
//t    "capability_opt : capability",
//t    "location : KW_LOCATION EQ TEXT",
//t    "location_opt :",
//t    "location_opt : location",
//t    "pattern : schema",
//t  };
  protected static  string [] yyNames = {    
    "end-of-file",null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,"ERROR","TEXT","INT","FLOAT","ID",
    "ARROW","DARROW","LBRACE","RBRACE","LPAREN","RPAREN","LBRACK",
    "RBRACK","QMARK","EMARK","COLON","SEMICOLON","DOT","PLUS","MINUS",
    "TIMES","DIVIDE","AMPERSAND","BACKSLASH","EQ","EQEQ","NE","LT","LE",
    "GT","GE","COMMA","TILDE","OR","LAND","LOR","IN_CAP","OUT_CAP",
    "INOUT_CAP","KW_IN","KW_AND","KW_BOOL","KW_INT","KW_FLOAT",
    "KW_STRING","KW_WITH","KW_LOCATION","KW_WSDL","KW_NIL","KW_SCHEMA",
    "KW_LET","KW_NEW","KW_JOIN","KW_SPAWN","KW_MATCH","KW_WHEN",
    "KW_IMPORT","KW_FALSE","KW_TRUE","KW_IF","KW_THEN","KW_ELSE",
    "Selectdec","UMINUS",
  };

  /** index-checked interface to yyNames[].
      @param token single character or %token value.
      @return token name or [illegal] or [unknown].
    */
  public static string yyname (int token) {
    if ((token < 0) || (token > yyNames.Length)) return "[illegal]";
    string name;
    if ((name = yyNames[token]) != null) return name;
    return "[unknown]";
  }

  /** computes list of expected tokens on error by tracing the tables.
      @param state for which to compute the list.
      @return list of token names.
    */
  protected string[] yyExpecting (int state) {
    int token, n, len = 0;
    bool[] ok = new bool[yyNames.Length];

    if ((n = yySindex[state]) != 0)
      for (token = n < 0 ? -n : 0;
           (token < yyNames.Length) && (n+token < yyTable.Length); ++ token)
        if (yyCheck[n+token] == token && !ok[token] && yyNames[token] != null) {
          ++ len;
          ok[token] = true;
        }
    if ((n = yyRindex[state]) != 0)
      for (token = n < 0 ? -n : 0;
           (token < yyNames.Length) && (n+token < yyTable.Length); ++ token)
        if (yyCheck[n+token] == token && !ok[token] && yyNames[token] != null) {
          ++ len;
          ok[token] = true;
        }

    string [] result = new string[len];
    for (n = token = 0; n < len;  ++ token)
      if (ok[token]) result[n++] = yyNames[token];
    return result;
  }

  /** the generated parser, with debugging messages.
      Maintains a state and a value stack, currently with fixed maximum size.
      @param yyLex scanner.
      @param yydebug debug message writer implementing yyDebug, or null.
      @return result of the last reduction, if any.
      @throws yyException on irrecoverable parse error.
    */
  internal Object yyparse (yyParser.yyInput yyLex, Object yyd)
				 {
//t    this.debug = (yydebug.yyDebug)yyd;
    return yyparse(yyLex);
  }

  /** initial size and increment of the state/value stack [default 256].
      This is not final so that it can be overwritten outside of invocations
      of yyparse().
    */
  protected int yyMax;

  /** executed at the beginning of a reduce action.
      Used as $$ = yyDefault($1), prior to the user-specified action, if any.
      Can be overwritten to provide deep copy, etc.
      @param first value for $1, or null.
      @return first.
    */
  protected Object yyDefault (Object first) {
    return first;
  }

  /** the generated parser.
      Maintains a state and a value stack, currently with fixed maximum size.
      @param yyLex scanner.
      @return result of the last reduction, if any.
      @throws yyException on irrecoverable parse error.
    */
  internal Object yyparse (yyParser.yyInput yyLex)
				{
    if (yyMax <= 0) yyMax = 256;			// initial size
    int yyState = 0;                                   // state stack ptr
    int [] yyStates = new int[yyMax];	                // state stack 
    Object yyVal = null;                               // value stack ptr
    Object [] yyVals = new Object[yyMax];	        // value stack
    int yyToken = -1;					// current input
    int yyErrorFlag = 0;				// #tks to shift

    int yyTop = 0;
    goto skip;
    yyLoop:
    yyTop++;
    skip:
    for (;; ++ yyTop) {
      if (yyTop >= yyStates.Length) {			// dynamically increase
        int[] i = new int[yyStates.Length+yyMax];
        yyStates.CopyTo (i, 0);
        yyStates = i;
        Object[] o = new Object[yyVals.Length+yyMax];
        yyVals.CopyTo (o, 0);
        yyVals = o;
      }
      yyStates[yyTop] = yyState;
      yyVals[yyTop] = yyVal;
//t      if (debug != null) debug.push(yyState, yyVal);

      yyDiscarded: for (;;) {	// discarding a token does not change stack
        int yyN;
        if ((yyN = yyDefRed[yyState]) == 0) {	// else [default] reduce (yyN)
          if (yyToken < 0) {
            yyToken = yyLex.advance() ? yyLex.token() : 0;
//t            if (debug != null)
//t              debug.lex(yyState, yyToken, yyname(yyToken), yyLex.value());
          }
          if ((yyN = yySindex[yyState]) != 0 && ((yyN += yyToken) >= 0)
              && (yyN < yyTable.Length) && (yyCheck[yyN] == yyToken)) {
//t            if (debug != null)
//t              debug.shift(yyState, yyTable[yyN], yyErrorFlag-1);
            yyState = yyTable[yyN];		// shift to yyN
            yyVal = yyLex.value();
            yyToken = -1;
            if (yyErrorFlag > 0) -- yyErrorFlag;
            goto yyLoop;
          }
          if ((yyN = yyRindex[yyState]) != 0 && (yyN += yyToken) >= 0
              && yyN < yyTable.Length && yyCheck[yyN] == yyToken)
            yyN = yyTable[yyN];			// reduce (yyN)
          else
            switch (yyErrorFlag) {
  
            case 0:
              yyerror(String.Format ("syntax error, got token `{0}'", yyname (yyToken)), yyExpecting(yyState));
//t              if (debug != null) debug.error("syntax error");
              goto case 1;
            case 1: case 2:
              yyErrorFlag = 3;
              do {
                if ((yyN = yySindex[yyStates[yyTop]]) != 0
                    && (yyN += Token.yyErrorCode) >= 0 && yyN < yyTable.Length
                    && yyCheck[yyN] == Token.yyErrorCode) {
//t                  if (debug != null)
//t                    debug.shift(yyStates[yyTop], yyTable[yyN], 3);
                  yyState = yyTable[yyN];
                  yyVal = yyLex.value();
                  goto yyLoop;
                }
//t                if (debug != null) debug.pop(yyStates[yyTop]);
              } while (-- yyTop >= 0);
//t              if (debug != null) debug.reject();
              throw new yyParser.yyException("irrecoverable syntax error");
  
            case 3:
              if (yyToken == 0) {
//t                if (debug != null) debug.reject();
                throw new yyParser.yyException("irrecoverable syntax error at end-of-file");
              }
//t              if (debug != null)
//t                debug.discard(yyState, yyToken, yyname(yyToken),
//t  							yyLex.value());
              yyToken = -1;
              goto yyDiscarded;		// leave stack alone
            }
        }
        int yyV = yyTop + 1-yyLen[yyN];
//t        if (debug != null)
//t          debug.reduce(yyState, yyStates[yyV-1], yyN, yyRule[yyN], yyLen[yyN]);
        yyVal = yyDefault(yyV > yyTop ? null : yyVals[yyV]);
        switch (yyN) {
case 1:
#line 193 "Parser.jay"
  {
		yyVal = new NilProcess();
		SetLocation(yyVal, ((GenericValue)yyVals[0+yyTop]).Location);
	}
  break;
case 2:
#line 199 "Parser.jay"
  {
		yyVal = new OutputProcess(((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 3:
#line 205 "Parser.jay"
  {
		yyVal = new InputProcess(((IExpression)yyVals[-5+yyTop]), ((bool)yyVals[-3+yyTop]), ((IPattern)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-5+yyTop])));
	}
  break;
case 4:
#line 211 "Parser.jay"
  {
		yyVal = new SchemaProcess(((IList_SchemaProcess_Declaration)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-3+yyTop]).Location);
	}
  break;
case 5:
#line 217 "Parser.jay"
  {
		MatchProcess.Branch branch = new MatchProcess.Branch(((IPattern)yyVals[-4+yyTop]), null, ((IProcess)yyVals[0+yyTop]));
		SetLocation(branch, GetLocation(((IPattern)yyVals[-4+yyTop])));
	  IList<MatchProcess.Branch> branches = new List<MatchProcess.Branch>();
		branches.Add(branch);
	  yyVal = new MatchProcess(((IExpression)yyVals[-2+yyTop]), branches);
		SetLocation(yyVal, ((GenericValue)yyVals[-5+yyTop]).Location);
	}
  break;
case 6:
#line 227 "Parser.jay"
  {
		yyVal = new NewProcess(((StringValue)yyVals[-4+yyTop]).Value, ((IDictionary_FieldDecList)yyVals[-3+yyTop]), ((string)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-5+yyTop]).Location);
	}
  break;
case 7:
#line 233 "Parser.jay"
  {
		yyVal = new ImportProcess(((StringValue)yyVals[-4+yyTop]).Value, ((IDictionary_FieldDecList)yyVals[-3+yyTop]), ((string)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-5+yyTop]).Location);
	}
  break;
case 8:
#line 239 "Parser.jay"
  {
		yyVal = new SpawnProcess(((IProcess)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-4+yyTop]).Location);
	}
  break;
case 9:
#line 245 "Parser.jay"
  {
		yyVal = new MatchProcess(((IExpression)yyVals[-4+yyTop]), ((IList_MatchProcess_Branch)yyVals[-1+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-5+yyTop]).Location);
	}
  break;
case 10:
#line 251 "Parser.jay"
  {
		yyVal = new JoinProcess(((bool)yyVals[-4+yyTop]), ((IList_JoinPatternRow)yyVals[-1+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-3+yyTop]).Location);
	}
  break;
case 11:
#line 257 "Parser.jay"
  {
		IList<MatchProcess.Branch> branches = new List<MatchProcess.Branch>();
		MatchProcess.Branch trueBranch = new MatchProcess.Branch(new BasicSchemaLiteralSchema(new BoolLiteral(true)), null, ((IProcess)yyVals[-1+yyTop]));
		MatchProcess.Branch falseBranch = new MatchProcess.Branch(new BasicSchema(new BoolType()), null, ((IProcess)yyVals[0+yyTop]));
		SetLocation(trueBranch, ((GenericValue)yyVals[-2+yyTop]).Location);
		SetLocation(falseBranch, GetLocation(((IProcess)yyVals[-1+yyTop])));
		branches.Add(trueBranch);
		branches.Add(falseBranch);
		yyVal = new MatchProcess(((IExpression)yyVals[-3+yyTop]), branches);
		SetLocation(yyVal, ((GenericValue)yyVals[-4+yyTop]).Location);
	}
  break;
case 12:
#line 270 "Parser.jay"
  { yyVal = ((IProcess)yyVals[-1+yyTop]); }
  break;
case 13:
#line 275 "Parser.jay"
  { yyVal = new NilProcess(); }
  break;
case 14:
#line 278 "Parser.jay"
  { yyVal = ((IProcess)yyVals[0+yyTop]); }
  break;
case 15:
#line 283 "Parser.jay"
  { yyVal = ((IDictionary_FieldDecList)yyVals[-1+yyTop]); }
  break;
case 16:
#line 286 "Parser.jay"
  { IDictionary<string, ISchema> operations = new Dictionary<string, ISchema>();
	  operations.Add("default", ((ISchema)yyVals[0+yyTop]));
		yyVal = operations;
	}
  break;
case 17:
#line 294 "Parser.jay"
  { IDictionary<string, ISchema> operations = new Dictionary<string, ISchema>();
		operations.Add(((StringValue)yyVals[-2+yyTop]).Value, ((ISchema)yyVals[0+yyTop]));
		yyVal = operations;
	}
  break;
case 18:
#line 300 "Parser.jay"
  { IDictionary<string, ISchema> operations = (Dictionary<string, ISchema>) ((IDictionary_FieldDecList)yyVals[0+yyTop]);
	 	operations.Add(((StringValue)yyVals[-4+yyTop]).Value, ((ISchema)yyVals[-2+yyTop]));
	 	yyVal = operations; 	
	}
  break;
case 19:
#line 308 "Parser.jay"
  { yyVal = false; }
  break;
case 20:
#line 311 "Parser.jay"
  { yyVal = true; }
  break;
case 21:
#line 316 "Parser.jay"
  {
	  List<JoinPatternRow> rows = new List<JoinPatternRow>();
		rows.Add(((JoinPatternRow)yyVals[0+yyTop]));
		yyVal = rows;
	}
  break;
case 22:
#line 323 "Parser.jay"
  {
	  IList<JoinPatternRow> rows = (IList<JoinPatternRow>) ((IList_JoinPatternRow)yyVals[-2+yyTop]);
		rows.Add(((JoinPatternRow)yyVals[0+yyTop]));
		yyVal = rows;
	}
  break;
case 23:
#line 332 "Parser.jay"
  {
		yyVal = new JoinPatternRow(((IList_JoinPatternAtom)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-1+yyTop]).Location); /* TODO: IMPROVE THIS LOCATION*/
	}
  break;
case 24:
#line 340 "Parser.jay"
  {
		IList<JoinPatternAtom> atoms = new List<JoinPatternAtom>();
		atoms.Add(((JoinPatternAtom)yyVals[0+yyTop]));
		yyVal = atoms;
	}
  break;
case 25:
#line 347 "Parser.jay"
  {
		IList<JoinPatternAtom> atoms = (IList<JoinPatternAtom>) ((IList_JoinPatternAtom)yyVals[-2+yyTop]);
		atoms.Add(((JoinPatternAtom)yyVals[0+yyTop]));
		yyVal = atoms;
	}
  break;
case 26:
#line 356 "Parser.jay"
  {
		yyVal = new JoinPatternAtom(((IExpression)yyVals[-2+yyTop]), ((IPattern)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 27:
#line 364 "Parser.jay"
  {
		IList<SchemaProcess.Declaration> decls = new List<SchemaProcess.Declaration>();
		decls.Add(((SchemaProcess.Declaration)yyVals[0+yyTop]));
		yyVal = decls;
	}
  break;
case 28:
#line 371 "Parser.jay"
  {
		IList<SchemaProcess.Declaration> decls = (IList<SchemaProcess.Declaration>) ((IList_SchemaProcess_Declaration)yyVals[-2+yyTop]);
		decls.Add(((SchemaProcess.Declaration)yyVals[0+yyTop]));
		yyVal = decls;
	}
  break;
case 29:
#line 380 "Parser.jay"
  {
		yyVal = new SchemaProcess.Declaration(((StringValue)yyVals[-2+yyTop]).Value, ((ISchema)yyVals[0+yyTop]));
		SetLocation(yyVal, ((StringValue)yyVals[-2+yyTop]).Location);
	}
  break;
case 30:
#line 388 "Parser.jay"
  {
	  yyVal = new List<MatchProcess.Branch>();
		((List<MatchProcess.Branch>) yyVal).Add(((MatchProcess.Branch)yyVals[0+yyTop]));
	}
  break;
case 31:
#line 394 "Parser.jay"
  {
		((IList_MatchProcess_Branch)yyVals[-2+yyTop]).Add(((MatchProcess.Branch)yyVals[0+yyTop]));
		yyVal = ((IList_MatchProcess_Branch)yyVals[-2+yyTop]);
	}
  break;
case 32:
#line 402 "Parser.jay"
  {
		yyVal = new MatchProcess.Branch(((IPattern)yyVals[-3+yyTop]), ((IExpression)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IPattern)yyVals[-3+yyTop])));
	}
  break;
case 33:
#line 410 "Parser.jay"
  { yyVal = null; }
  break;
case 34:
#line 413 "Parser.jay"
  {
		yyVal = ((IExpression)yyVals[0+yyTop]);
		SetLocation(yyVal, ((GenericValue)yyVals[-1+yyTop]).Location);
	}
  break;
case 35:
#line 421 "Parser.jay"
  {
		yyVal = new VoidSchema();
		SetLocation(yyVal, lexer.location);
	}
  break;
case 36:
#line 427 "Parser.jay"
  { yyVal = ((IPattern)yyVals[0+yyTop]); }
  break;
case 37:
#line 432 "Parser.jay"
  {
		yyVal = new VoidExpr();
		SetLocation(yyVal, lexer.location);
	}
  break;
case 38:
#line 438 "Parser.jay"
  { yyVal = ((IExpression)yyVals[0+yyTop]); }
  break;
case 39:
#line 443 "Parser.jay"
  {
		yyVal = new IntLiteral(((IntValue)yyVals[0+yyTop]).Value);
		SetLocation(yyVal, ((IntValue)yyVals[0+yyTop]).Location);
	}
  break;
case 40:
#line 449 "Parser.jay"
  {
		yyVal = new FloatLiteral(((FloatValue)yyVals[0+yyTop]).Value);
		SetLocation(yyVal, ((FloatValue)yyVals[0+yyTop]).Location);
	}
  break;
case 41:
#line 455 "Parser.jay"
  {
		yyVal = new StringLiteral(((StringValue)yyVals[0+yyTop]).Value);
		SetLocation(yyVal, ((StringValue)yyVals[0+yyTop]).Location);
	}
  break;
case 42:
#line 461 "Parser.jay"
  {
		yyVal = new BoolLiteral(false);
		SetLocation(yyVal, ((GenericValue)yyVals[0+yyTop]).Location);
	}
  break;
case 43:
#line 467 "Parser.jay"
  {
		yyVal = new BoolLiteral(true);
		SetLocation(yyVal, ((GenericValue)yyVals[0+yyTop]).Location);
	}
  break;
case 44:
#line 475 "Parser.jay"
  { yyVal = new Dictionary<string, IExpression>(); }
  break;
case 45:
#line 478 "Parser.jay"
  { yyVal = ((IDictionary_FieldDefList)yyVals[0+yyTop]); }
  break;
case 46:
#line 483 "Parser.jay"
  {
		IDictionary<string, IExpression> fields = new Dictionary<string, IExpression>();
		fields.Add(((StringValue)yyVals[-2+yyTop]).Value, ((IExpression)yyVals[0+yyTop]));
		yyVal = fields;
	}
  break;
case 47:
#line 490 "Parser.jay"
  {
		IDictionary<string, IExpression> fields = (IDictionary<string, IExpression>) ((IDictionary_FieldDefList)yyVals[0+yyTop]);
		fields.Add(((StringValue)yyVals[-4+yyTop]).Value, ((IExpression)yyVals[-2+yyTop]));
		yyVal = fields;
	}
  break;
case 48:
#line 499 "Parser.jay"
  { yyVal = ((IExpression)yyVals[-1+yyTop]); }
  break;
case 49:
#line 502 "Parser.jay"
  {
		yyVal = new VariableExpr(((StringValue)yyVals[0+yyTop]).Value);
		SetLocation(yyVal, ((StringValue)yyVals[0+yyTop]).Location);
	}
  break;
case 50:
#line 508 "Parser.jay"
  {
		yyVal = new SelectExpr(((IExpression)yyVals[-2+yyTop]), ((StringValue)yyVals[0+yyTop]).Value);
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 51:
#line 514 "Parser.jay"
  {
		yyVal = new RecordExpr(((IDictionary_FieldDefList)yyVals[-1+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-2+yyTop]).Location);
	}
  break;
case 52:
#line 520 "Parser.jay"
  {
		yyVal = new LiteralExpr(((IBasicTypeLiteral)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IBasicTypeLiteral)yyVals[0+yyTop])));
	}
  break;
case 53:
#line 526 "Parser.jay"
  {
		yyVal = new LabelledExpr(((StringValue)yyVals[-3+yyTop]).Value, ((IExpression)yyVals[-1+yyTop]));
		SetLocation(yyVal, ((StringValue)yyVals[-3+yyTop]).Location);
	}
  break;
case 54:
#line 532 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.PLUS, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 55:
#line 538 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.MINUS, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 56:
#line 544 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.TIMES, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 57:
#line 550 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.DIVIDE, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 58:
#line 556 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.LAND, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 59:
#line 562 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.LOR, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 60:
#line 568 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.EQ, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 61:
#line 574 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.NE, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 62:
#line 580 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.GT, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 63:
#line 586 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.GE, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 64:
#line 592 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.LT, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 65:
#line 598 "Parser.jay"
  {
		yyVal = new BinaryOpExpr(BinaryOp.LE, ((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 66:
#line 604 "Parser.jay"
  {
		yyVal = new SequenceExpr(((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IExpression)yyVals[-2+yyTop])));
	}
  break;
case 67:
#line 610 "Parser.jay"
  {
		yyVal = new UnaryOpExpr(UnaryOp.LNOT, ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-1+yyTop]).Location);
	}
  break;
case 68:
#line 616 "Parser.jay"
  {
		yyVal = new UnaryOpExpr(UnaryOp.UMINUS, ((IExpression)yyVals[0+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-1+yyTop]).Location);
	}
  break;
case 69:
#line 624 "Parser.jay"
  {
		yyVal = LabelSet.Singleton(((StringValue)yyVals[0+yyTop]).Value);
		SetLocation(yyVal, ((StringValue)yyVals[0+yyTop]).Location);
	}
  break;
case 70:
#line 630 "Parser.jay"
  {
		yyVal = LabelSet.Any();
		SetLocation(yyVal, ((GenericValue)yyVals[0+yyTop]).Location);
	}
  break;
case 71:
#line 636 "Parser.jay"
  {
		yyVal = LabelSet.With((ISet<string>)((ISet_string)yyVals[-1+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-2+yyTop]).Location);
	}
  break;
case 72:
#line 642 "Parser.jay"
  {
		yyVal = LabelSet.Without((ISet<string>)((ISet_string)yyVals[-1+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-4+yyTop]).Location);
	}
  break;
case 73:
#line 650 "Parser.jay"
  { yyVal = new ArraySet<string>(); }
  break;
case 74:
#line 653 "Parser.jay"
  { yyVal = ((ISet_string)yyVals[0+yyTop]); }
  break;
case 75:
#line 658 "Parser.jay"
  {
		ISet<string> labels = new ArraySet<string>();
		labels.Add(((StringValue)yyVals[0+yyTop]).Value);
		yyVal = labels;
	}
  break;
case 76:
#line 665 "Parser.jay"
  {
		Debug.Assert(yyVal is ISet<string>);
		ISet<string> labels = (ArraySet<string>) yyVal;
		labels.Add(((StringValue)yyVals[0+yyTop]).Value);
	}
  break;
case 77:
#line 674 "Parser.jay"
  {
		yyVal = new VoidSchema();
		SetLocation(yyVal, lexer.location);
	}
  break;
case 78:
#line 680 "Parser.jay"
  { yyVal = ((ISchema)yyVals[0+yyTop]); }
  break;
case 79:
#line 685 "Parser.jay"
  {
		yyVal = new BoolType();
	}
  break;
case 80:
#line 690 "Parser.jay"
  {
		yyVal = new IntType();
	}
  break;
case 81:
#line 695 "Parser.jay"
  {
		yyVal = new FloatType();
	}
  break;
case 82:
#line 700 "Parser.jay"
  {
		yyVal = new StringType();
	}
  break;
case 83:
#line 707 "Parser.jay"
  {
		yyVal = new BasicSchema(((IBasicType)yyVals[0+yyTop]));
		SetLocation(yyVal, lexer.location);
	}
  break;
case 84:
#line 713 "Parser.jay"
  {
		yyVal = new BasicSchemaLiteralSchema(((IBasicTypeLiteral)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((IBasicTypeLiteral)yyVals[0+yyTop])));
	}
  break;
case 85:
#line 719 "Parser.jay"
  {
		yyVal = new ChannelSchema(((ISchema)yyVals[-2+yyTop]), ((ChannelType.CAPABILITY)yyVals[0+yyTop]));
		SetLocation(yyVal, ((GenericValue)yyVals[-3+yyTop]).Location);
	}
  break;
case 86:
#line 725 "Parser.jay"
  {
		yyVal = new FunctionSchema(((ISchema)yyVals[-3+yyTop]), ((ISchema)yyVals[0+yyTop]), ((ChannelType.CAPABILITY)yyVals[-1+yyTop]));
		SetLocation(yyVal, GetLocation(((ISchema)yyVals[-3+yyTop])));
	}
  break;
case 87:
#line 731 "Parser.jay"
  {
		yyVal = UnionSchema.MakeNew(((ISchema)yyVals[-2+yyTop]), ((ISchema)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((ISchema)yyVals[-2+yyTop])));
	}
  break;
case 88:
#line 737 "Parser.jay"
  {
		yyVal = new ConstantSchema(((StringValue)yyVals[0+yyTop]).Value);
		SetLocation(yyVal, ((StringValue)yyVals[0+yyTop]).Location);
	}
  break;
case 89:
#line 743 "Parser.jay"
  {
		yyVal = new BindSchema(((StringValue)yyVals[-2+yyTop]).Value, ((ISchema)yyVals[0+yyTop]));
		SetLocation(yyVal, ((StringValue)yyVals[-2+yyTop]).Location);
	}
  break;
case 90:
#line 749 "Parser.jay"
  {
		yyVal = new VoidSchema();
		SetLocation(yyVal, ((GenericValue)yyVals[-1+yyTop]).Location);
	}
  break;
case 91:
#line 755 "Parser.jay"
  { yyVal = ((ISchema)yyVals[-1+yyTop]); }
  break;
case 92:
#line 758 "Parser.jay"
  {
		yyVal = new LabelledSchema(((ILabelSet)yyVals[-3+yyTop]), ((ISchema)yyVals[-1+yyTop]));
		SetLocation(yyVal, GetLocation(((ILabelSet)yyVals[-3+yyTop])));
	}
  break;
case 93:
#line 764 "Parser.jay"
  {
		yyVal = new SequenceSchema(((ISchema)yyVals[-2+yyTop]), ((ISchema)yyVals[0+yyTop]));
		SetLocation(yyVal, GetLocation(((ISchema)yyVals[-2+yyTop])));
	}
  break;
case 94:
#line 770 "Parser.jay"
  {
		yyVal = new StarSchema(((ISchema)yyVals[-1+yyTop]));
		SetLocation(yyVal, GetLocation(((ISchema)yyVals[-1+yyTop])));
	}
  break;
case 95:
#line 776 "Parser.jay"
  {
		yyVal = new PlusSchema(((ISchema)yyVals[-1+yyTop]));
		SetLocation(yyVal, GetLocation(((ISchema)yyVals[-1+yyTop])));
	}
  break;
case 96:
#line 782 "Parser.jay"
  {
		yyVal = new RepetitionSchema(((ISchema)yyVals[-3+yyTop]), (uint) ((IntValue)yyVals[-1+yyTop]).Value, (uint) ((IntValue)yyVals[-1+yyTop]).Value);
		SetLocation(yyVal, GetLocation(((ISchema)yyVals[-3+yyTop])));
	}
  break;
case 97:
#line 788 "Parser.jay"
  {
		yyVal = new RepetitionSchema(((ISchema)yyVals[-5+yyTop]), (uint) ((IntValue)yyVals[-3+yyTop]).Value, (uint) ((IntValue)yyVals[-1+yyTop]).Value);
		SetLocation(yyVal, GetLocation(((ISchema)yyVals[-5+yyTop])));
	}
  break;
case 98:
#line 794 "Parser.jay"
  {
		yyVal = new RepetitionSchema(((ISchema)yyVals[-1+yyTop]), 0, 1);
		SetLocation(yyVal, GetLocation(((ISchema)yyVals[-1+yyTop])));
	}
  break;
case 99:
#line 802 "Parser.jay"
  { yyVal = ChannelType.CAPABILITY.IN; }
  break;
case 100:
#line 805 "Parser.jay"
  { yyVal = ChannelType.CAPABILITY.OUT; }
  break;
case 101:
#line 808 "Parser.jay"
  { yyVal = ChannelType.CAPABILITY.INOUT; }
  break;
case 102:
#line 813 "Parser.jay"
  { yyVal = ChannelType.CAPABILITY.OUT; }
  break;
case 103:
#line 816 "Parser.jay"
  { yyVal = ((ChannelType.CAPABILITY)yyVals[0+yyTop]); }
  break;
case 104:
#line 821 "Parser.jay"
  { yyVal = ((StringValue)yyVals[0+yyTop]).Value; }
  break;
case 105:
#line 825 "Parser.jay"
  { yyVal = ""; }
  break;
case 106:
#line 828 "Parser.jay"
  { yyVal = ((string)yyVals[0+yyTop]); }
  break;
case 107:
#line 833 "Parser.jay"
  { yyVal = ((ISchema)yyVals[0+yyTop]); }
  break;
#line default
        }
        yyTop -= yyLen[yyN];
        yyState = yyStates[yyTop];
        int yyM = yyLhs[yyN];
        if (yyState == 0 && yyM == 0) {
//t          if (debug != null) debug.shift(0, yyFinal);
          yyState = yyFinal;
          if (yyToken < 0) {
            yyToken = yyLex.advance() ? yyLex.token() : 0;
//t            if (debug != null)
//t               debug.lex(yyState, yyToken,yyname(yyToken), yyLex.value());
          }
          if (yyToken == 0) {
//t            if (debug != null) debug.accept(yyVal);
            return yyVal;
          }
          goto yyLoop;
        }
        if (((yyN = yyGindex[yyM]) != 0) && ((yyN += yyState) >= 0)
            && (yyN < yyTable.Length) && (yyCheck[yyN] == yyState))
          yyState = yyTable[yyN];
        else
          yyState = yyDgoto[yyM];
//t        if (debug != null) debug.shift(yyStates[yyTop], yyState);
	 goto yyLoop;
      }
    }
  }

   static  short [] yyLhs  = {              -1,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    1,    1,   28,   28,   27,   27,    3,    3,
   21,   21,   24,   22,   22,   25,   23,   23,   26,    4,
    4,    5,    2,    2,    7,    7,   10,   10,    8,    8,
    8,    8,    8,   30,   30,   29,   29,    9,    9,    9,
    9,    9,    9,    9,    9,    9,    9,    9,    9,    9,
    9,    9,    9,    9,    9,    9,    9,    9,   14,   14,
   14,   14,   15,   15,   16,   16,   13,   13,   11,   11,
   11,   11,   12,   12,   12,   12,   12,   12,   12,   12,
   12,   12,   12,   12,   12,   12,   12,   12,   17,   17,
   17,   18,   18,   19,   20,   20,    6,
  };
   static  short [] yyLen = {           2,
    1,    3,    6,    4,    6,    6,    6,    5,    6,    5,
    5,    3,    0,    2,    3,    2,    3,    5,    0,    1,
    1,    3,    3,    1,    3,    3,    1,    3,    3,    1,
    3,    4,    0,    2,    0,    1,    0,    1,    1,    1,
    1,    1,    1,    0,    1,    3,    5,    3,    1,    3,
    3,    1,    4,    3,    3,    3,    3,    3,    3,    3,
    3,    3,    3,    3,    3,    3,    2,    2,    1,    1,
    3,    5,    0,    1,    1,    3,    0,    1,    1,    1,
    1,    1,    1,    1,    4,    4,    3,    1,    3,    2,
    3,    4,    3,    2,    2,    4,    6,    2,    1,    1,
    1,    0,    1,    3,    0,    1,    1,
  };
   static  short [] yyDefRed = {            0,
   41,   39,   40,    0,    0,    0,    0,    0,   20,    1,
    0,    0,    0,    0,    0,    0,   42,   43,    0,    0,
    0,   52,    0,    0,    0,    0,   45,    0,    0,    0,
    0,   67,   68,    0,    0,   27,    0,    0,    0,    0,
   70,   79,   80,   81,   82,    0,   84,   83,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   12,   51,    0,   48,    0,    0,
    0,    0,   75,    0,    0,    0,   90,    0,    0,    0,
    0,    0,    0,   98,   95,   94,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   50,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   53,    0,    0,    4,   28,    0,    0,
   71,    0,   91,    0,    0,   99,  100,  101,  103,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  106,    0,
    0,    0,    0,    0,    0,    0,    0,   21,   24,    0,
    0,    0,   76,   85,    0,    0,   96,    0,   92,    0,
   15,    0,    0,    8,    0,   30,    0,    0,    0,   11,
    0,   10,    0,    0,    0,    0,   47,   72,    5,    0,
    0,  104,    6,    9,    0,    0,    0,    7,   14,   36,
   26,   22,   23,   25,    3,   97,    0,   31,    0,    0,
   18,   32,
  };
  protected static  short [] yyDgoto  = {            20,
  180,  197,   21,  175,  176,  177,  201,   22,   23,   31,
   48,   49,   90,   50,   85,   86,  139,  140,  149,  150,
  156,  157,   35,  158,  159,   36,  146,  102,   27,   28,
  };
  protected static  short [] yySindex = {          -69,
    0,    0,    0, -254,  538,   41,   41,   41,    0,    0,
 -232,  566, -227, -210,   41, -200,    0,    0,   41,    0,
 -229,    0,  845,   41, -225, -182,    0, -179, -178,  945,
 -162,    0,    0, -173, -208,    0, -161, -257, -137,  566,
    0,    0,    0,    0,    0, -166,    0,    0,  184, -143,
 -239,  -69,  822, -239,  -63, -130, -141,   41, -123,   41,
   41,   41,   41,   41,   41,   41,   41,   41,   41,   41,
   41,   41, -129,   41,    0,    0, -140,    0,  566,  -69,
 -232,  566,    0, -138, -117, -139,    0, -240,  184, -121,
   41, -176,  -93,    0,    0,    0,  566,  566,  566,  -94,
  566, -133,  -89,  -82, -133,  -69,   41,  566,  945,    0,
 -183, -183, -103, -103, -120, -120, -120, -120, -120, -120,
  466,  466,  466,    0,  926,  184,    0,    0,  239,  -78,
    0,  -77,    0, -176,  883,    0,    0,    0,    0,  566,
 -252,  239,  239,  -83,  -84,  -66,  184,  -85,    0,  -96,
  -69,  566,  -95, -115,  906, -259, -256,    0,    0,  -59,
 -178, -246,    0,    0,  -69, -185,    0,  -53,    0,  566,
    0,  -49,  -69,    0, -250,    0, -102,  -69,  -69,    0,
  566,    0,   41,  -69,   41,  -69,    0,    0,    0,  -48,
  443,    0,    0,    0,  566,   41,  -47,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  -94,    0,  945,  -69,
    0,    0,
  };
  protected static  short [] yyRindex = {          -91,
    0,    0,    0,    1, -260,  -41,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  -39,  864,    0,    0,    0,  -34, -214,
    0,    0,    0,    0,    0,    0,  672,  -33,    0,  -52,
    0,    0,    0,    0,    0,    0,    0,    0, -261,    0,
    0,  -91,    0,    0,    0,    0,  610,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,  -91,
    0,    0,    0,    0,    0,  -32,    0,    0, -228,    0,
    0,  629,    0,    0,    0,    0,    0,    0,  -29,    0,
    0,  -61,    0,    0,  -61,  -91,    0,    0,   46,    0,
  153,  193,   57,  113,  227,  261,  295,  329,  363,  406,
  393,  465,  499,    0,  -22, -165,    0,    0,  736,    0,
    0,    0,    0,  716,    0,    0,    0,    0,    0,    0,
    0,  771,  791,    0,    0,    0, -244,    0,    0,    0,
  -91,    0,    0,   16,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,  -91, -153,    0,    0,    0,    0,
    0,    0,  -91,    0,    0,    0,  -15,  -91,  -91,    0,
 -251,    0,    0,  -91,    0,  -91,    0,    0,    0,    0,
  -16,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  -13,  -91,
    0,    0,
  };
  protected static  short [] yyGindex = {           -5,
    0,    0,  194,    0,   58,   -9,    0,   -1,    2,  228,
    0,    5,  156,    0,    0,  126,    0,  123,    0,  154,
    0,    0,    0,   75,   77,  179,   56,  213,  108,    0,
  };
  protected static  short [] yyTable = {            26,
   49,  107,   46,   83,   44,  182,  184,   30,   32,   33,
   47,   35,  167,   24,  194,   13,   53,  107,  188,  107,
   55,   92,  185,   93,  100,   30,  133,   35,   34,   94,
  183,   84,  101,   51,   95,  168,   96,   47,   47,  195,
   78,  132,   24,   88,   89,    2,  103,   97,   19,   98,
  107,   16,   38,   52,   38,   74,   56,   78,   16,  109,
   54,  111,  112,  113,  114,  115,  116,  117,  118,  119,
  120,  121,  122,  123,  127,  125,   92,   47,   93,   56,
   47,   75,   77,  126,   94,   76,  129,   80,   81,   95,
   59,   96,  135,   62,   63,   47,   47,   47,  160,   47,
  154,  142,  143,   89,   78,  147,   47,   79,  155,   86,
   82,   86,   57,   86,   91,   86,  136,  137,  138,   86,
    1,    2,    3,   37,   99,   86,   38,   86,   39,   87,
   29,   29,   86,  107,   86,    9,   86,  110,   47,  124,
   74,  130,   86,   86,  166,  174,   40,  131,  132,   86,
   47,   41,   54,   59,   60,   61,   62,   63,   86,  189,
   42,   43,   44,   45,  134,  141,  145,  193,   47,  148,
   59,  200,  198,  199,  191,  151,   17,   18,  203,   47,
  205,  152,   83,  163,  155,  169,  155,  170,    1,    2,
    3,    4,   55,   47,    5,  172,    6,  209,  171,  173,
  178,    7,  179,  186,  212,  190,    8,    9,  192,  196,
   59,   60,   61,   62,   63,  210,  206,   19,   64,   65,
   66,   67,   68,   69,   70,   37,   60,   71,   72,   37,
   44,   73,   74,   77,  105,   10,   11,   12,   13,   77,
   14,   15,   46,   16,   17,   18,   19,   33,   17,   34,
  108,   73,  208,  106,  144,  162,  164,  202,  153,  128,
   61,  204,  211,   49,   49,   49,  105,   49,  187,   49,
   49,   49,    0,   49,   49,   49,   49,   49,   49,   13,
   13,    0,   49,   49,   49,   49,   49,   49,   49,    0,
   49,   49,   49,    0,   64,    0,   49,    0,    1,    2,
    3,    4,   49,    0,   29,   13,    6,    0,    0,    2,
    2,    7,    0,    0,    0,    0,    8,   49,   49,   56,
   56,   56,    0,   56,    0,   56,   56,   56,   65,   56,
    0,   56,   56,   56,   56,    2,    0,    0,   56,   56,
   56,   56,   56,   56,   56,    0,   56,   56,   56,    0,
    0,    0,   56,    0,   17,   18,    0,    0,   56,    0,
    0,    0,   62,    2,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   56,   56,   57,   57,   57,    0,   57,
    0,   57,   57,   57,    0,   57,    0,   57,   57,   57,
   57,    0,   66,    0,   57,   57,   57,   57,   57,   57,
   57,    0,   57,   57,   57,   63,    0,    0,   57,    0,
    0,    0,    0,    0,   57,   54,   54,   54,    0,   54,
    0,   54,   54,   54,    0,   54,    0,   54,   54,   57,
   57,    0,    0,    0,   54,   54,   54,   54,   54,   54,
   54,    0,   54,   54,   54,   92,    0,   93,   54,    0,
    0,    0,    0,   94,   54,   55,   55,   55,   95,   55,
   96,   55,   55,   55,   58,   55,    0,   55,   55,   54,
   54,   97,    0,   98,   55,   55,   55,   55,   55,   55,
   55,    0,   55,   55,   55,    0,    0,    0,   55,   60,
   60,   60,    0,   60,   55,   60,   60,   60,   59,   60,
   92,    0,   93,    0,    0,    0,    0,    0,   94,   55,
   55,    0,    0,   95,   60,   96,   60,   60,   60,    0,
    0,    0,   60,   61,   61,   61,   97,   61,   60,   61,
   61,   61,    0,   61,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   60,   60,    0,    0,    0,   61,    0,
   61,   61,   61,    0,    0,    0,   61,   64,   64,   64,
    0,   64,   61,   64,   64,   64,    0,   64,    0,    0,
    0,    0,    0,    0,    0,    0,    0,   61,   61,    0,
    0,    0,   64,    0,   64,   64,   64,    0,    0,    0,
   64,   65,   65,   65,    0,   65,   64,   65,   65,   65,
    0,   65,    0,    0,    0,    0,    0,    0,    0,    0,
    0,   64,   64,    0,    0,    0,   65,    0,   65,   65,
   65,    0,    0,    0,   65,   62,   62,   62,    0,   62,
   65,   62,   62,   62,    0,   62,    0,    0,    0,    0,
    0,    0,    0,    0,    0,   65,   65,    0,    0,    0,
   62,    0,   62,   62,   62,   66,   66,   66,   62,   66,
    0,   66,   66,   66,   62,   66,    0,    0,   63,   63,
   63,    0,   63,    0,   63,   63,   63,    0,   63,   62,
   62,    0,   66,   66,   66,    0,    0,    0,   66,    0,
    0,    0,    0,   63,   66,   63,   63,   63,    0,    0,
    0,   63,    0,    0,   92,    0,   93,   63,    0,   66,
   66,    0,   94,    0,    0,  207,    0,   95,    0,   96,
    0,    0,   63,   63,    0,    0,    0,   58,   58,   58,
   97,   58,   98,   58,   58,   58,    0,   58,    0,   59,
   60,   61,   62,   63,    0,    0,    0,   64,   65,   66,
   67,   68,   69,   70,   58,   58,   58,    0,    0,    0,
   58,   59,   59,   59,    0,   59,   58,   59,   59,   59,
    0,   59,    0,    0,    0,    0,    0,    0,    0,    0,
    0,   58,   58,    0,    0,    0,    0,    0,   59,   59,
   59,    0,    0,    0,   59,    1,    2,    3,   25,    0,
   59,    5,    0,    6,    0,    0,    0,    0,    7,    0,
    0,    0,    0,    8,    9,   59,   59,    0,    0,    0,
    0,    0,    0,    1,    2,    3,   37,    0,    0,   38,
    0,   39,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,   10,   11,   12,   13,    0,   14,   15,   40,
   16,   17,   18,   19,   41,    0,    0,    0,    0,    0,
    0,    0,    0,   42,   43,   44,   45,   19,   19,   19,
   19,    0,    0,   19,    0,   19,    0,    0,    0,   17,
   18,    0,    0,    0,    0,    0,  102,  102,  102,  102,
    0,    0,  102,   19,  102,    0,    0,    0,   19,    0,
    0,    0,    0,    0,    0,    0,    0,   19,   19,   19,
   19,    0,  102,    0,    0,    0,    0,  102,    0,    0,
    0,    0,    0,   19,   19,    0,  102,  102,  102,  102,
    0,    0,    0,   88,   88,   88,   88,    0,   88,   69,
   88,   88,  102,  102,   88,    0,   88,    0,   88,    0,
   88,    0,   88,    0,    0,    0,    0,   88,    0,   88,
    0,   88,    0,    0,    0,    0,    0,   88,   88,    0,
    0,    0,    0,    0,   88,    0,    0,  102,  102,  102,
  102,    0,  102,   88,  102,  102,    0,    0,  102,    0,
  102,    0,  102,    0,  102,    0,  102,    0,   89,    0,
   89,  102,   89,  102,   89,  102,    0,    0,   89,    0,
    0,  102,  102,    0,   89,    0,   89,    0,  102,    0,
    0,   89,    0,    0,    0,   89,    0,  102,    0,    0,
    0,   89,   89,   93,    0,   93,    0,   93,   89,   93,
    0,    0,    0,   93,    0,    0,    0,   89,    0,   93,
    0,   93,    0,   87,    0,   87,   93,   87,    0,   87,
   93,    0,    0,   87,    0,    0,   93,   93,    0,   87,
    0,   87,    0,   93,    0,    0,   87,    0,    0,    0,
   87,    0,   93,    0,    0,    0,   87,   87,    0,    0,
    0,    0,    0,   87,    0,   59,   60,   61,   62,   63,
    0,    0,   87,   64,   65,   66,   67,   68,   69,   70,
    0,    0,   71,   72,   57,   58,    0,    0,   59,   60,
   61,   62,   63,  104,    0,    0,   64,   65,   66,   67,
   68,   69,   70,   49,   49,   71,   72,   49,   49,   49,
   49,   49,    0,    0,    0,   49,   49,   49,   49,   49,
   49,   49,    0,    0,   49,   49,   59,   60,   61,   62,
   63,    0,    0,    0,   64,   65,   66,   67,   68,   69,
   70,    0,    0,   71,   72,  181,    0,    0,  165,   59,
   60,   61,   62,   63,    0,    0,    0,   64,   65,   66,
   67,   68,   69,   70,    0,    0,   71,   72,  161,   59,
   60,   61,   62,   63,    0,    0,    0,   64,   65,   66,
   67,   68,   69,   70,    0,    0,   71,   72,   59,   60,
   61,   62,   63,    0,    0,    0,   64,   65,   66,   67,
   68,   69,   70,    0,    0,   71,   72,
  };
  protected static  short [] yyCheck = {             5,
    0,  263,   12,  261,  265,  265,  263,    6,    7,    8,
   12,  263,  265,  268,  265,    0,   15,  279,  265,  281,
   19,  262,  279,  264,  264,   24,  267,  279,  261,  270,
  290,  289,  272,  261,  275,  288,  277,   39,   40,  290,
  269,  288,  268,   39,   40,    0,   52,  288,  309,  290,
  312,  296,  267,  264,  269,  281,    0,  286,  303,   58,
  261,   60,   61,   62,   63,   64,   65,   66,   67,   68,
   69,   70,   71,   72,   80,   74,  262,   79,  264,  309,
   82,  264,  261,   79,  270,  265,   82,  296,  297,  275,
  274,  277,   91,  277,  278,   97,   98,   99,  108,  101,
  106,   97,   98,   99,  267,  101,  108,  281,  107,  263,
  272,  265,    0,  267,  281,  269,  293,  294,  295,  273,
  258,  259,  260,  261,  268,  279,  264,  281,  266,  267,
  296,  297,  286,  264,  288,  277,  290,  261,  140,  269,
  281,  280,  296,  297,  140,  151,  284,  265,  288,  303,
  152,  289,    0,  274,  275,  276,  277,  278,  312,  165,
  298,  299,  300,  301,  286,  259,  261,  173,  170,  303,
  274,  181,  178,  179,  170,  265,  314,  315,  184,  181,
  186,  264,  261,  261,  183,  269,  185,  272,  258,  259,
  260,  261,    0,  195,  264,  281,  266,  196,  265,  296,
  296,  271,  318,  263,  210,  259,  276,  277,  258,  312,
  274,  275,  276,  277,  278,  263,  265,  309,  282,  283,
  284,  285,  286,  287,  288,  267,    0,  291,  292,  269,
  265,  265,  265,  286,  296,  305,  306,  307,  308,  269,
  310,  311,  265,  313,  314,  315,  316,  263,  265,  263,
   57,   24,  195,  317,   99,  130,  134,  183,  105,   81,
    0,  185,  207,  263,  264,  265,   54,  267,  161,  269,
  270,  271,   -1,  273,  274,  275,  276,  277,  278,  264,
  265,   -1,  282,  283,  284,  285,  286,  287,  288,   -1,
  290,  291,  292,   -1,    0,   -1,  296,   -1,  258,  259,
  260,  261,  302,   -1,  264,  290,  266,   -1,   -1,  264,
  265,  271,   -1,   -1,   -1,   -1,  276,  317,  318,  263,
  264,  265,   -1,  267,   -1,  269,  270,  271,    0,  273,
   -1,  275,  276,  277,  278,  290,   -1,   -1,  282,  283,
  284,  285,  286,  287,  288,   -1,  290,  291,  292,   -1,
   -1,   -1,  296,   -1,  314,  315,   -1,   -1,  302,   -1,
   -1,   -1,    0,  318,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,  317,  318,  263,  264,  265,   -1,  267,
   -1,  269,  270,  271,   -1,  273,   -1,  275,  276,  277,
  278,   -1,    0,   -1,  282,  283,  284,  285,  286,  287,
  288,   -1,  290,  291,  292,    0,   -1,   -1,  296,   -1,
   -1,   -1,   -1,   -1,  302,  263,  264,  265,   -1,  267,
   -1,  269,  270,  271,   -1,  273,   -1,  275,  276,  317,
  318,   -1,   -1,   -1,  282,  283,  284,  285,  286,  287,
  288,   -1,  290,  291,  292,  262,   -1,  264,  296,   -1,
   -1,   -1,   -1,  270,  302,  263,  264,  265,  275,  267,
  277,  269,  270,  271,    0,  273,   -1,  275,  276,  317,
  318,  288,   -1,  290,  282,  283,  284,  285,  286,  287,
  288,   -1,  290,  291,  292,   -1,   -1,   -1,  296,  263,
  264,  265,   -1,  267,  302,  269,  270,  271,    0,  273,
  262,   -1,  264,   -1,   -1,   -1,   -1,   -1,  270,  317,
  318,   -1,   -1,  275,  288,  277,  290,  291,  292,   -1,
   -1,   -1,  296,  263,  264,  265,  288,  267,  302,  269,
  270,  271,   -1,  273,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,  317,  318,   -1,   -1,   -1,  288,   -1,
  290,  291,  292,   -1,   -1,   -1,  296,  263,  264,  265,
   -1,  267,  302,  269,  270,  271,   -1,  273,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,  317,  318,   -1,
   -1,   -1,  288,   -1,  290,  291,  292,   -1,   -1,   -1,
  296,  263,  264,  265,   -1,  267,  302,  269,  270,  271,
   -1,  273,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,  317,  318,   -1,   -1,   -1,  288,   -1,  290,  291,
  292,   -1,   -1,   -1,  296,  263,  264,  265,   -1,  267,
  302,  269,  270,  271,   -1,  273,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,  317,  318,   -1,   -1,   -1,
  288,   -1,  290,  291,  292,  263,  264,  265,  296,  267,
   -1,  269,  270,  271,  302,  273,   -1,   -1,  263,  264,
  265,   -1,  267,   -1,  269,  270,  271,   -1,  273,  317,
  318,   -1,  290,  291,  292,   -1,   -1,   -1,  296,   -1,
   -1,   -1,   -1,  288,  302,  290,  291,  292,   -1,   -1,
   -1,  296,   -1,   -1,  262,   -1,  264,  302,   -1,  317,
  318,   -1,  270,   -1,   -1,  273,   -1,  275,   -1,  277,
   -1,   -1,  317,  318,   -1,   -1,   -1,  263,  264,  265,
  288,  267,  290,  269,  270,  271,   -1,  273,   -1,  274,
  275,  276,  277,  278,   -1,   -1,   -1,  282,  283,  284,
  285,  286,  287,  288,  290,  291,  292,   -1,   -1,   -1,
  296,  263,  264,  265,   -1,  267,  302,  269,  270,  271,
   -1,  273,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,  317,  318,   -1,   -1,   -1,   -1,   -1,  290,  291,
  292,   -1,   -1,   -1,  296,  258,  259,  260,  261,   -1,
  302,  264,   -1,  266,   -1,   -1,   -1,   -1,  271,   -1,
   -1,   -1,   -1,  276,  277,  317,  318,   -1,   -1,   -1,
   -1,   -1,   -1,  258,  259,  260,  261,   -1,   -1,  264,
   -1,  266,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,  305,  306,  307,  308,   -1,  310,  311,  284,
  313,  314,  315,  316,  289,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,  298,  299,  300,  301,  258,  259,  260,
  261,   -1,   -1,  264,   -1,  266,   -1,   -1,   -1,  314,
  315,   -1,   -1,   -1,   -1,   -1,  258,  259,  260,  261,
   -1,   -1,  264,  284,  266,   -1,   -1,   -1,  289,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,  298,  299,  300,
  301,   -1,  284,   -1,   -1,   -1,   -1,  289,   -1,   -1,
   -1,   -1,   -1,  314,  315,   -1,  298,  299,  300,  301,
   -1,   -1,   -1,  262,  263,  264,  265,   -1,  267,  268,
  269,  270,  314,  315,  273,   -1,  275,   -1,  277,   -1,
  279,   -1,  281,   -1,   -1,   -1,   -1,  286,   -1,  288,
   -1,  290,   -1,   -1,   -1,   -1,   -1,  296,  297,   -1,
   -1,   -1,   -1,   -1,  303,   -1,   -1,  262,  263,  264,
  265,   -1,  267,  312,  269,  270,   -1,   -1,  273,   -1,
  275,   -1,  277,   -1,  279,   -1,  281,   -1,  263,   -1,
  265,  286,  267,  288,  269,  290,   -1,   -1,  273,   -1,
   -1,  296,  297,   -1,  279,   -1,  281,   -1,  303,   -1,
   -1,  286,   -1,   -1,   -1,  290,   -1,  312,   -1,   -1,
   -1,  296,  297,  263,   -1,  265,   -1,  267,  303,  269,
   -1,   -1,   -1,  273,   -1,   -1,   -1,  312,   -1,  279,
   -1,  281,   -1,  263,   -1,  265,  286,  267,   -1,  269,
  290,   -1,   -1,  273,   -1,   -1,  296,  297,   -1,  279,
   -1,  281,   -1,  303,   -1,   -1,  286,   -1,   -1,   -1,
  290,   -1,  312,   -1,   -1,   -1,  296,  297,   -1,   -1,
   -1,   -1,   -1,  303,   -1,  274,  275,  276,  277,  278,
   -1,   -1,  312,  282,  283,  284,  285,  286,  287,  288,
   -1,   -1,  291,  292,  270,  271,   -1,   -1,  274,  275,
  276,  277,  278,  302,   -1,   -1,  282,  283,  284,  285,
  286,  287,  288,  270,  271,  291,  292,  274,  275,  276,
  277,  278,   -1,   -1,   -1,  282,  283,  284,  285,  286,
  287,  288,   -1,   -1,  291,  292,  274,  275,  276,  277,
  278,   -1,   -1,   -1,  282,  283,  284,  285,  286,  287,
  288,   -1,   -1,  291,  292,  270,   -1,   -1,  296,  274,
  275,  276,  277,  278,   -1,   -1,   -1,  282,  283,  284,
  285,  286,  287,  288,   -1,   -1,  291,  292,  273,  274,
  275,  276,  277,  278,   -1,   -1,   -1,  282,  283,  284,
  285,  286,  287,  288,   -1,   -1,  291,  292,  274,  275,
  276,  277,  278,   -1,   -1,   -1,  282,  283,  284,  285,
  286,  287,  288,   -1,   -1,  291,  292,
  };

#line 836 "Parser.jay"

    public IProcess Parse(string file)
    {
      locationMap = new Dictionary<Object, int>();
      lexer = new Lexer(file);
      return (IProcess) yyparse(lexer);
    }

		public static bool HasLocation(Object obj)
		{
			return locationMap.ContainsKey(obj);
		}

    public static int GetLocation(Object obj)
    {
			Debug.Assert(locationMap.ContainsKey(obj), "no location for " + obj);
			return (int) locationMap[obj];
		}

		private static void SetLocation(Object obj, int location)
		{
		// Console.WriteLine("setting location {1} of {0}", obj, location);
			locationMap.Add(obj, location);
		}
}
#line default
namespace yydebug {
        using System;
	 internal interface yyDebug {
		 void push (int state, Object value);
		 void lex (int state, int token, string name, Object value);
		 void shift (int from, int to, int errorFlag);
		 void pop (int state);
		 void discard (int state, int token, string name, Object value);
		 void reduce (int from, int to, int rule, string text, int len);
		 void shift (int from, int to);
		 void accept (Object value);
		 void error (string message);
		 void reject ();
	 }
	 
	 class yyDebugSimple : yyDebug {
		 void println (string s){
			 Console.Error.WriteLine (s);
		 }
		 
		 public void push (int state, Object value) {
			 println ("push\tstate "+state+"\tvalue "+value);
		 }
		 
		 public void lex (int state, int token, string name, Object value) {
			 println("lex\tstate "+state+"\treading "+name+"\tvalue "+value);
		 }
		 
		 public void shift (int from, int to, int errorFlag) {
			 switch (errorFlag) {
			 default:				// normally
				 println("shift\tfrom state "+from+" to "+to);
				 break;
			 case 0: case 1: case 2:		// in error recovery
				 println("shift\tfrom state "+from+" to "+to
					     +"\t"+errorFlag+" left to recover");
				 break;
			 case 3:				// normally
				 println("shift\tfrom state "+from+" to "+to+"\ton error");
				 break;
			 }
		 }
		 
		 public void pop (int state) {
			 println("pop\tstate "+state+"\ton error");
		 }
		 
		 public void discard (int state, int token, string name, Object value) {
			 println("discard\tstate "+state+"\ttoken "+name+"\tvalue "+value);
		 }
		 
		 public void reduce (int from, int to, int rule, string text, int len) {
			 println("reduce\tstate "+from+"\tuncover "+to
				     +"\trule ("+rule+") "+text);
		 }
		 
		 public void shift (int from, int to) {
			 println("goto\tfrom state "+from+" to "+to);
		 }
		 
		 public void accept (Object value) {
			 println("accept\tvalue "+value);
		 }
		 
		 public void error (string message) {
			 println("error\t"+message);
		 }
		 
		 puccurs="0" maxOccurs="1">
                  <labelled>
                    <with>
                      <label name="offer" />
                    </with>
                    <string />
                  </labelled>
                </repeat>
                <sequence>
                  <repeat minOccurs="0" maxOccurs="1">
                    <labelled>
                      <with>
                        <label name="offerpage" />
                      </with>
                      <string />
                    </labelled>
                  </repeat>
                  <repeat minOccurs="0" maxOccurs="1">
                    <labelled>
                      <with>
                        <label name="locale" />
                      </with>
                      <string />
                    </labelled>
                  </repeat>
                </sequence>
              </sequence>
            </sequence>
          </sequence>
        </sequence>
      </sequence>
    </schemadec>
    <schemadec name="BlendedRequest">
      <sequence>
        <labelled>
          <with>
            <label name="blended" />
          </with>
          <string />
        </labelled>
        <sequence>
          <labelled>
            <with>
              <label name="tag" />
            </with>
            <string />
          </labelled>
          <sequence>
            <labelled>
              <with>
                <label name="type" />
              </with>
              <string />
            </labelled>
            <sequence>
              <labelled>
                <with>
                  <label name="devtag" />
                </with>
                <string />
              </labelled>
              <repeat minOccurs="0" maxOccurs="1">
                <labelled>
                  <with>
                    <label name="locale" />
                  </with>
                  <string />
                </labelled>
              </repeat>
            </sequence>
          </sequence>
        </sequence>
      </sequence>
    </schemadec>
    <schemadec name="UpcRequest">
      <sequence>
        <labelled>
          <with>
            <label name="upc" />
          </with>
          <string />
        </labelled>
        <sequence>
          <labelled>
            <with>
              <label name="mode" />
            </with>
            <string />
          </labelled>
          <sequence>
            <labelled>
              <with>
                <label name="tag" />
              </with>
              <string />
            </labelled>
            <sequence>
              <labelled>
                <with>
                  <label name="type" />
                </with>
                <string />
              </labelled>
              <sequence>
                <labelled>
                  <with>
                    <label name="devtag" />
                  </with>
                  <string />
                </labelled>
                <sequence>
                  <repeat minOccurs="0" maxOccurs="1">
                    <labelled>
                      <with>
                        <label name="sort" />
            