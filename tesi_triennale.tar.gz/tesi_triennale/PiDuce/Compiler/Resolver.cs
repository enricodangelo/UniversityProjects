// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Diagnostics;
using System.Collections.Generic;
using PiDuce.Common;
using PiDuce.Types;

using IPattern = PiDuce.Common.ISchema;

namespace PiDuce.Compiler
{
	public class CompilerResolveNamesSchemaVisitor : ResolveNamesSchemaVisitor
	{
		private readonly LocationContext locationContext;

		public CompilerResolveNamesSchemaVisitor(LocationContext locationContext,
			SchemaSymbolTable st) : base(st)
		{
			this.locationContext = locationContext;
		}

		public override void ResolveNames(ISchema s)
		{
			locationContext.Enter(s);
			try {
				base.ResolveNames(s);
				locationContext.Exit(s);
			} catch (Exception) {
				locationContext.Exit(s);
				throw;
			}
		}
	}

#if false
	public class ResolveNamesPatternVisitor : ResolveNamesSchemaVisitor
	{
		private readonly LocationContext locationContext;
		private readonly ValueSymbolTable vst;

		public ResolveNamesPatternVisitor(LocationContext locationContext, SchemaSymbolTable sst, ValueSymbolTable vst)
			: base(sst)
		{
			this.vst = vst;
			this.locationContext = locationContext;
		}

		public override void ResolveNames(IPattern p)
		{
			locationContext.Enter(p);
			try {
				base.ResolveNames(p);
				locationContext.Exit(p);
			} catch (Exception) {
				locationContext.Exit(p);
			}
		}

		public override void VisitBindPattern(BindPattern p)
		{
			ResolveNames(p.Content);
			// the type associated with this name will be
			// initialized during the type-checking visit
			ValueEntry entry = vst.New(p.Name, null);
			vst.Add(entry);
			p.Entry = entry;
		}
	}
#endif

  public class AuxiliaryExpressionResolver {
    public static IEntry GetChannelEntry(IExpression expr)
    {
      if (expr is VariableExpr) {
        VariableExpr var = (VariableExpr)expr;
        Debug.Assert(var.Entry != null);
        Debug.Assert(var.Entry is ValueEntry);
        return (ValueEntry) var.Entry;
      } else if (expr is SelectExpr) {
        SelectExpr e = (SelectExpr)expr;
        IEntry entry = GetChannelEntry(e.Content);
        if (entry is ServiceEntry) {
          ServiceEntry service = (ServiceEntry)entry;
          string operationName = service.Name + "#" + e.Field;
          if (service.Operations.ContainsKey(operationName))
            return service.Operations[operationName];
          else
            return null;
        } else
          return null;
      } else
        return null;
    }
  }

	public class ResolveNamesExpressionVisitor : IExpressionVisitor
	{
		private readonly LocationContext locationContext;
		private readonly ValueSymbolTable st;

		public ResolveNamesExpressionVisitor(LocationContext locationContext,
			ValueSymbolTable st)
		{
			this.locationContext = locationContext;
			this.st = st;
		}

		public void ResolveNames(IExpression expr)
		{	
			locationContext.Enter(expr);
			try {
				expr.Accept(this);
				locationContext.Exit(expr);
			} catch (Exception) {
				locationContext.Exit(expr);
				throw;
			}
		}

		public void VisitVoidExpr(VoidExpr expr)
		{ }

		public void VisitLiteralExpr(LiteralExpr expr)
		{ }

		public void VisitVariableExpr(VariableExpr expr)
		{
			expr.Entry = st.Lookup(expr.Name, locationContext.GetLocation(expr));
			Debug.Assert(expr.Entry != null);
		}

		public void VisitSelectExpr(SelectExpr expr)
		{ expr.Content.Accept(this); }

		public void VisitRecordExpr(RecordExpr expr)
		{
			foreach (KeyValuePair<string, IExpression> pair in expr.Fields)
				pair.Value.Accept(this);
		}

    public void VisitLabelledExpr(LabelledExpr expr)
		{ ResolveNames(expr.Content); }

		public void VisitSequenceExpr(SequenceExpr expr)
		{
			ResolveNames(expr.Head);
			ResolveNames(expr.Tail);
		}

		public void VisitBinaryOpExpr(BinaryOpExpr expr)
		{
			ResolveNames(expr.Left);
			ResolveNames(expr.Right);
		}

		public void VisitUnaryOpExpr(UnaryOpExpr expr)
		{ ResolveNames(expr.Content); }
	}

	public class ResolveNamesPatternVisitor : AbstractSchemaVisitor
	{
		private readonly LocationContext locationContext;
		private readonly ValueSymbolTable vst;
		private IDictionary<string, IEntry> map;
		private ArraySet<IEntry> entries;

		private ResolveNamesPatternVisitor(LocationContext locationContext, ValueSymbolTable vst)
		{
			this.locationContext = locationContext;
			this.vst = vst;
			this.map = new Dictionary<string, IEntry>();
			this.entries = ArraySet<IEntry>.Empty();
		}

		public static ISet<IEntry> ResolveNames(LocationContext locationContext, ValueSymbolTable vst, IPattern pattern)
		{ return new ResolveNamesPatternVisitor(locationContext, vst).ResolveNames(pattern); }

		private ArraySet<IEntry> ResolveNames(IPattern pattern)
		{
			entries = ArraySet<IEntry>.Empty();
			pattern.Accept(this);
			return entries;
		}

		public override void VisitSequenceSchema(SequenceSchema s)
		{
			ArraySet<IEntry> left = ResolveNames(s.Head);
			ArraySet<IEntry> right = ResolveNames(s.Tail);
#if false
			ArraySet<IEntry> common = ArraySet<IEntry>.Intersection(left, right);
			foreach (IEntry entry in common)
				CompilerOutput.Error("nonlinear occurrence of - " + entry.Name, locationContext.GetLocation(s));
#endif
			entries = ArraySet<IEntry>.Union(left, right);
		}

		public override void VisitUnionSchema(UnionSchema s)
		{
			ArraySet<IEntry> left = ResolveNames(s.Left);
			ArraySet<IEntry> right = ResolveNames(s.Right);
#if false
			ArraySet<IEntry> noncommon = ArraySet<IEntry>.Union(ArraySet<IEntry>.Difference(left, right), ArraySet<IEntry>.Difference(right, left));
			foreach (IEntry entry in noncommon)
				CompilerOutput.Error(entry.Name + " must occur on both sides of |", locationContext.GetLocation(s));
#endif
			entries = ArraySet<IEntry>.Union(left, right);
		}

		public override void VisitChannelSchema(ChannelSchema s)
		{
			ArraySet<IEntry> illegal = ResolveNames(s.Content);
			foreach (IEntry entry in illegal)
				CompilerOutput.Error("illegal binding " + entry.Name + " within channel schema", locationContext.GetLocation(s));
		}

		public override void VisitFunctionSchema(FunctionSchema s)
		{
			ArraySet<IEntry> illegal = ArraySet<IEntry>.Union(ResolveNames(s.Input), ResolveNames(s.Output));
			foreach (IEntry entry in illegal)
				CompilerOutput.Error("illegal binding " + entry.Name + " within function schema", locationContext.GetLocation(s));
		}

		public override void VisitBindSchema(BindSchema s)
		{
			ArraySet<IEntry> entries = ResolveNames(s.Content);
			if (map.ContainsKey(s.Name)) {
				IEntry entry = map[s.Name];
				if (entries.Contains(entry))
					CompilerOutput.Error("illegal nested occurrence of " + entry.Name, locationContext.GetLocation(s));
				else
					entries.Add(entry);
				s.Entry = entry;
			} else {
				// the type will be determined during type-checking
				s.Entry = vst.New(s.Name, null);
				map.Add(s.Name, s.Entry);
				entries.Add(s.Entry);
				this.entries = entries;
			}
		}
	}

	public class ResolveNamesProcessVisitor : IProcessVisitor
	{
		private readonly LocationContext locationContext;
		private readonly ValueSymbolTable vst;
		private readonly SchemaSymbolTable sst;
		private readonly CompilerResolveNamesSchemaVisitor schemaVisitor;
		private readonly ResolveNamesExpressionVisitor exprVisitor;

		public ResolveNamesProcessVisitor(SchemaSymbolTable sst, ValueSymbolTable vst)
		{
			this.locationContext = new LocationContext();
			this.sst = sst;
			this.vst = vst;
			this.schemaVisitor = new CompilerResolveNamesSchemaVisitor(this.locationContext, sst);
			this.exprVisitor = new ResolveNamesExpressionVisitor(this.locationContext, vst);
		}

		public void ResolveNames(IProcess p)
		{
			locationContext.Enter(p);
			try {
				p.Accept(this);
			} catch (Exception) {
				locationContext.Exit(p);
				throw;
			}
		}

		private void ResolveNames(ISchema s)
		{ schemaVisitor.ResolveNames(s); }

		private void ResolveNames(IExpression e)
		{ exprVisitor.ResolveNames(e); }

		private void ResolveNamesInPattern(IPattern pattern)
		{
			ResolveNames(pattern);
			ISet<IEntry> entries = ResolveNamesPatternVisitor.ResolveNames(locationContext, vst, pattern);
			foreach (ValueEntry entry in entries) {
				vst.Add(entry);
			}
		}

		public void VisitNilProcess(NilProcess p)
		{ }

		public void VisitSpawnProcess(SpawnProcess p)
		{
      vst.Enter();
			ResolveNames(p.Left);
      vst.Exit();
			ResolveNames(p.Right);
		}

		public void VisitOutputProcess(OutputProcess p)
		{ 
			ResolveNames(p.Destination);
			ResolveNames(p.Expression);
		}
		
		public void VisitInputProcess(InputProcess p)
		{
			ResolveNames(p.Source);
			vst.Enter();
			ResolveNamesInPattern(p.Pattern);
			ResolveNames(p.Continuation);

			foreach (ValueEntry e in vst.Exit())
				if (!e.Used)
					CompilerOutput.Warning("unused variable - " + e.Name, locationContext.GetLocation(p));
		}

		public void VisitJoinProcess(JoinProcess p)
		{
      foreach (JoinPatternRow row in p.Rows) {
				vst.Enter();
      	foreach (JoinPatternAtom atom in row.Atoms) {
					ResolveNames(atom.Source);
					ResolveNamesInPattern(atom.Pattern);
          atom.Entry = AuxiliaryExpressionResolver.GetChannelEntry(atom.Source);
				}
				ResolveNames(row.Continuation);
				foreach (ValueEntry e in vst.Exit())
					if (!e.Used)
						CompilerOutput.Warning("unused variable - " + e.Name, locationContext.GetLocation(row));
			}
		}

		public void VisitMatchProcess(MatchProcess p)
		{
			ResolveNames(p.Expression);
			foreach (MatchProcess.Branch b in p.Branches) {
				vst.Enter();
				ResolveNamesInPattern(b.Pattern);
				if (b.Condition != null)
					ResolveNames(b.Condition);
				ResolveNames(b.Process);
				foreach (ValueEntry e in vst.Exit())
					if (!e.Used)
						CompilerOutput.Warning("unused variable - " + e.Name, locationContext.GetLocation(b.Pattern));
			}
		}
						
		public void VisitImportProcess(ImportProcess p)
		{
      IDictionary<string, ValueEntry> opEntries = new Dictionary<string, ValueEntry>();

      foreach (KeyValuePair<string, ISchema> operation in p.Operations) {
        ResolveNames(operation.Value);
        string channelName = p.Name + "#" + operation.Key;
        opEntries.Add(channelName, vst.New(channelName, operation.Value, false));
      }

			vst.Enter();
			ValueEntry entry = vst.NewService(p.Name, new ServiceSchema(p.Operations), opEntries, false);
			p.Entry = entry;
			vst.Add(entry);
			ResolveNames(p.Continuation);

			foreach (ValueEntry e in vst.Exit())
				if (!e.Used)
					CompilerOutput.Warning("unused variable - " + e.Name, locationContext.GetLocation(p));
		}

		public void VisitNewProcess(NewProcess p)
		{
      IDictionary<string, ValueEntry> opEntries = new Dictionary<string, ValueEntry>();

      foreach (KeyValuePair<string, ISchema> operation in p.Operations) {
        ResolveNames(operation.Value); 
        string channelName = p.Name + "#" + operation.Key;
        opEntries.Add(channelName, vst.New(channelName, operation.Value, true));
			}

			vst.Enter();
			ValueEntry entry = vst.NewService(p.Name, new ServiceSchema(p.Operations), opEntries, true);
			p.Entry = entry;
			vst.Add(entry);
			ResolveNames(p.Continuation);
			foreach (ValueEntry e in vst.Exit())
				if (!e.Used)
					CompilerOutput.Warning("unused channel - " + e.Name, locationContext.GetLocation(p));
		}

		public void VisitSchemaProcess(SchemaProcess p)
		{
			sst.Enter();
			foreach (SchemaProcess.Declaration decl in p.Declarations) {
				if (sst.Clash(decl.Name))
          CompilerOutput.Error("multiple definitions of - " + decl.Name, locationContext.GetLocation(decl));
				SchemaEntry entry = sst.New(decl.Name, null);
				sst.Add(entry);
				decl.Entry = entry;
			}

			foreach (SchemaProcess.Declaration decl in p.Declarations) {
				Debug.Assert(decl.Entry != null);
				ResolveNames(decl.Schema);
				decl.Entry.Schema = decl.Schema;
			}

			ResolveNames(p.Continuation);
			sst.Exit();
			foreach (SchemaProcess.Declaration decl in p.Declarations)
				if (!((SchemaEntry) decl.Entry).Used)
					CompilerOutput.Warning("unused schema - " + decl.Entry.Name, locationC�A     [n�Cum�Cum�C               