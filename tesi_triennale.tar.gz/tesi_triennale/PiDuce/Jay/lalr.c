/*
 * Copyright (c) 1989 The Regents of the University of California.
 * All rights reserved.
 *
 * This code is derived from software contributed to Berkeley by
 * Robert Paul Corbett.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef lint
static char sccsid[] = "@(#)lalr.c	5.3 (Berkeley) 6/1/90";
#endif /* not lint */

#include "defs.h"

typedef
  struct shorts
    {
      struct shorts *next;
      short value;
    }
  shorts;

int tokensetsize;
short *lookaheads;
short *LAruleno;
unsigned *LA;
short *accessing_symbol;
core **state_table;
shifts **shift_table;
reductions **reduction_table;
short *goto_map;
short *from_state;
short *to_state;

short **transpose();

static int infinity;
static int maxrhs;
static int ngotos;
static unsigned *F;
static short **includes;
static shorts **lookback;
static short **R;
static short *INDEX;
static short *VERTICES;
static int top;


lalr()
{
    tokensetsize = WORDSIZE(ntokens);

    set_state_table();
    set_accessing_symbol();
    set_shift_table();
    set_reduction_table();
    set_maxrhs();
    initialize_LA();
    set_goto_map();
    initialize_F();
    build_relations();
    compute_FOLLOWS();
    compute_lookaheads();
}



set_state_table()
{
    register core *sp;

    state_table = NEW2(nstates, core *);
    for (sp = first_state; sp; sp = sp->next)
	state_table[sp->number] = sp;
}



set_accessing_symbol()
{
    register core *sp;

    accessing_symbol = NEW2(nstates, short);
    for (sp = first_state; sp; sp = sp->next)
	accessing_symbol[sp->number] = sp->accessing_symbol;
}



set_shift_table()
{
    register shifts *sp;

    shift_table = NEW2(nstates, shifts *);
    for (sp = first_shift; sp; sp = sp->next)
	shift_table[sp->number] = sp;
}



set_reduction_table()
{
    register reductions *rp;

    reduction_table = NEW2(nstates, reductions *);
    for (rp = first_reduction; rp; rp = rp->next)
	reduction_table[rp->number] = rp;
}



set_maxrhs()
{
  register short *itemp;
  register short *item_end;
  register int length;
  register int max;

  length = 0;
  max = 0;
  item_end = ritem + nitems;
  for (itemp = ritem; itemp < item_end; itemp++)
    {
      if (*itemp >= 0)
	{
	  length++;
	}
      else
	{
	  if (length > max) max = length;
	  length = 0;
	}
    }

  maxrhs = max;
}



initialize_LA()
{
  register int i, j, k;
  register reductions *rp;

  lookaheads = NEW2(nstates + 1, short);

  k = 0;
  for (i = 0; i < nstates; i++)
    {
      lookaheads[i] = k;
      rp = reduction_table[i];
      if (rp)
	k += rp->nreds;
    }
  lookaheads[nstates] = k;

  LA = NEW2(k * tokensetsize, unsigned);
  LAruleno = NEW2(k, short);
  lookback = NEW2(k, shorts *);

  k = 0;
  for (i = 0; i < nstates; i++)
    {
      rp = reduction_table[i];
      if (rp)
	{
	  for (j = 0; j < rp->nreds; j++)
	    {
	      LAruleno[k] = rp->rules[j];
	      k++;
	    }
	}
    }
}


set_goto_map()
{
  register shifts *sp;
  register int i;
  register int symbol;
  register int k;
  register short *temp_map;
  register int state2;
  register int state1;

  goto_map = NEW2(nvars + 1, short) - ntokens;
  temp_map = NEW2(nvars + 1, short) - ntokens;

  ngotos = 0;
  for (sp = first_shift; sp; sp = sp->next)
    {
      for (i = sp->nshifts - 1; i >= 0; i--)
	{
	  symbol = accessing_symbol[sp->shift[i]];

	  if (ISTOKEN(symbol)) break;

	  if (ngotos == MAXSHORT)
	    fatal("too many gotos");

	  ngotos++;
	  goto_map[symbol]++;
        }
    }

  k = 0;
  for (i = ntokens; i < nsyms; i++)
    {
      temp_map[i] = k;
      k += goto_map[i];
    }

  for (i = ntokens; i < nsyms; i++)
    goto_map[i] = temp_map[i];

  goto_map[nsyms] = ngotos;
  temp_map[nsyms] = ngotos;

  from_state = NEW2(ngotos, short);
  to_state = NEW2(ngotos, short);

  for (sp = first_shift; sp; sp = sp->next)
    {
      state1 = sp->number;
      for (i = sp->nshifts - 1; i >= 0; i--)
	{
	  state2 = sp->shift[i];
	  symbol = accessing_symbol[state2];

	  if (ISTOKEN(symbol)) break;

	  k = temp_map[symbol]++;
	  from_state[k] = state1;
	  to_state[k] = state2;
	}
    }

  FREE(temp_map + ntokens);
}



/*  Map_goto maps a state/symbol pair into its numeric representation.	*/

int
map_goto(state, symbol)
int state;
int symbol;
{
    register int high;
    register int low;
    register int middle;
    register int s;

    low = goto_map[symbol];
    high = goto_map[symbol + 1];

    for (;;)
    {
	assert(low <= high);
	middle = (low + high) >> 1;
	s = from_state[middle];
	if (s == state)
	    return (middle);
	else if (s < state)
	    low = middle + 1;
	else
	    high = middle - 1;
    }
}



initialize_F()
{
  register int i;
  register int j;
  register int k;
  register shifts *sp;
  register short *edge;
  register unsigned *rowp;
  register short *rp;
  register short **reads;
  register int nedges;
  register int stateno;
  register int symbol;
  register int nwords;

  nwords = ngotos * tokensetsize;
  F = NEW2(nwords, unsigned);

  reads = NEW2(ngotos, short *);
  edge = NEW2(ngotos + 1, short);
  nedges = 0;

  rowp = F;
  for (i = 0; i < ngotos; i++)
    {
      stateno = to_state[i];
      sp = shift_table[stateno];

      if (sp)
	{
	  k = sp->nshifts;

	  for (j = 0; j < k; j++)
	    {
	      symbol = accessing_symbol[sp->shift[j]];
	      if (ISVAR(symbol))
		break;
	      SETBIT(rowp, symbol);
	    }

	  for (; j < k; j++)
	    {
	      symbol = accessing_symbol[sp->shift[j]];
	      if (nullable[symbol])
		edge[nedges++] = map_goto(stateno, symbol);
	    }
	
	  if (nedges)
	    {
	      reads[i] = rp = NEW2(nedges + 1, short);

	      for (j = 0; j < nedges; j++)
		rp[j] = edge[j];

	      rp[nedges] = -1;
	      nedges = 0;
	    }
	}

      rowp += tokensetsize;
    }

  SETBIT(F, 0);
  digraph(reads);

  for (i = 0; i < ngotos; i++)
    {
      if (reads[i])
	FREE(reads[i]);
    }

  FREE(reads);
  FREE(edge);
}



build_relations()
{
  register int i;
  register int j;
  register int k;
  register short *rulep;
  register short *rp;
  register shifts *sp;
  register int length;
  register int nedges;
  register int done;
  register int state1;
  register int stateno;
  register int symbol1;
  register int symbol2;
  register short *shortp;
  register short *edge;
  register short *states;
  register short **new_includes;

  includes = NEW2(ngotos, short *);
  edge = NEW2(ngotos + 1, short);
  states = NEW2(maxrhs + 1, short);

  for (i = 0; i < ngotos; i++)
    {
      nedges = 0;
      state1 = from_state[i];
      symbol1 = accessing_symbol[to_state[i]];
16  Bernardo Innocenti  <bernie@develer.com>

	* config/cpu/m68k/atomicity.h (__exchange_and_add): Use TAS on
	__mcf5400__. Don't rely on __mc68000__ to detect a bare 68000.
	Document SMP safeness of asm macros.

2003-10-16  Paolo Carlini  <pcarlini@suse.de>

	* src/locale.cc (locale::locale(const char*)): Tweak
	a couple of comparisons to use basic_string operators.

2003-10-16  Paolo Carlini  <pcarlini@suse.de>

	PR libstdc++/12540
	* config/locale/gnu/monetary_members.cc
	(moneypunct<wchar_t, true/false>::_M_initialize_moneypunct):
	Don't leak memory if new throws.
	* src/locale.cc (locale::locale(const char*)): In order not
	to leak memory in case new throws, use a basic_string type
	for __res too and avoid strdup.

2003-10-14  Jeff Bailey  <jbailey@nisa.net>
	
	PR libstdc++/12562
	* crossconfig.m4: Share the config between *-linux* and *-gnu*.
	* configure: Regenerate.

2003-10-14  Carlo Wood  <carlo@alinoe.com>

	PR libstdc++/12600
	* include/bits/demangle.h (session<Allocator>::
	  decode_unqualified_name(string_type& output)): Fail on a
	  <operator-name> when decoding <template-argument>.
	* testsuite/demangle/regression/cw-15.cc: New.

2003-10-14  Paolo Carlini  <pcarlini@unitus.it>

	PR libstdc++/11480
	* include/bits/stl_algo.h (unique): Fix.
	* testsuite/25_algorithms/unique.cc: Move to unique/1.cc.
	* testsuite/25_algorithms/unique/11480.cc: New, from the PR.
	* testsuite/25_algorithms/unique/2.cc: New.

2003-10-14  Paolo Carlini  <pcarlini@unitus.it>

	* src/localename.cc (_M_replace_categories, M_replace_facet):
	Const-ify a couple of variables.

2003-10-14  Petur Runolfsson  <peturr02@ru.is>
	    Andreas Tobler  <a.tobler@schweiz.ch>

	* src/locale.cc (locale::_S_initialize): Workaround a confusion
	of the use of the gthr API when __gthread_active_p() returns true.

2003-10-12  Petur Runolfsson  <peturr02@ru.is>
	    Paolo Carlini  <pcarlini@unitus.it>

	PR libstdc++/11460
	* src/strstream.cc (pbackfail): Fix to use to_int_type.
	* testsuite/backward/11460.cc: New, from the PR.

2003-10-12  Paolo Carlini  <pcarlini@unitus.it>

	* config/locale/ieee_1003.1-2001/codecvt_specializations.h:
	Change #ifdef _GLIBCXX_RESOLVE_LIB_DEFECTS to a comment.
	* include/bits/basic_string.tcc: Likewise.
	* include/bits/ios_base.h: Likewise.
	* include/bits/istream.tcc: Likewise.
	* include/bits/locale_facets.tcc: Likewise.
	* include/bits/ostream.tcc: Likewise.
	* include/bits/stl_function.h: Likewise.
	* include/bits/stl_multiset.h: Likewise.
	* include/bits/stl_pair.h: Likewise.
	* include/bits/stl_set.h: Likewise.
	* include/bits/streambuf_iterator.h
	* include/std/std_iosfwd.h: Likewise.
	* include/std/std_istream.h: Likewise.
	* include/std/std_sstream.h: Likewise.
	* include/std/std_streambuf.h: Likewise.
	* src/ios.cc: Likewise.
	* include/bits/c++config:
	Comment out #define _GLIBCXX_RESOLVE_LIB_DEFECTS 1.
	* testsuite/27_io/ios_base/cons/assign_neg.cc: Tweak a
	dg-error directive due to removal of a blank line.
	* testsuite/27_io/ios_base/cons/copy_neg.cc: Likewise.

2003-10-12  Andreas Tobler  <a.tobler@schweiz.ch>
	    Paolo Carlini  <pcarlini@unitus.it>

	PR libstdc++/11844/11740 (cont)
	* config/os/generic/ctype_inline.h (ctype<char>::is):
	Generically, use a bitmasksize of 15 (instead of 10);
	Fix the logic to actually return (M & m) != 0 as per
	22.2.1.1.2.

2003-10-11  Bernardo Innocenti  <bernie@develer.com>

	* crossconfig.m4 (*-uclinux*): New target.
	* configure: Regenerate.

2003-10-10  Paolo Carlini  <pcarlini@unitus.it>

	* include/bits/ostream.tcc (operator<<(basic_ostream&, _CharT))
	Avoid unnecessarily calling __builtin_alloca and dealing
	explicitly with width() smaller than zero.
	(operator<<(basic_ostream&, char), operator<<(basic_ostream&,
	const _CharT*), operator<<(basic_ostream<_CharT, _Traits>&,
	const char*), operator<<(basic_ostream<char, _Traits>&,
	const char*), operator<<(basic_ostream, const basic_string&)):
	Likewise.

2003-10-09  Benjamin Kosnik  <bkoz@redhat.com>

	* config/linker-map.gnu: Make more *_type_info bits 