using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using PiDuce.Common;

namespace PiDuce.Web
{
  public class SchemaEntry : AbstractEntry
  {
    public SchemaEntry(string name, ISchema schema)
      : base(name, schema)
    { }
  }

  public class IllegalConversionException : Exception
  {
    public IllegalConversionException(string message)
      : base(message)
    { }
  }

  public class XsdImportOutput
  {
    private ISet<string> warnings = new ArraySet<string>();
    private ISet<string> errors = new ArraySet<string>();
    private ISet<string> validationMsg = new ArraySet<string>();

    public void AddWarning(int line, int linePosition, string warning)
    { warnings.Add("line " + line + "," + linePosition + ": " + warning); }

    public void AddWarning(string warning)
    { warnings.Add(warning); }

    public void AddError(int line, int linePosition, string error)
    { errors.Add("line " + line + "," + linePosition + ": " + error); }

    public void AddError(string error)
    { errors.Add(error); }

    public void AddValidationError(string message)
    { validationMsg.Add(message); }

    public ISet<string> Warnings { get { return warnings; } }

    public ISet<string> Errors { get { return errors; } }

    public override String ToString()
    {
      System.Text.StringBuilder builder = new System.Text.StringBuilder();
      foreach (string warning in warnings)
      {
        builder.Append("Warning: " + warning);
        builder.Append(Environment.NewLine);
      }
      foreach (string error in errors)
      {
        builder.Append("Error: " + error);
        builder.Append(Environment.NewLine);
      }
      foreach (string message in validationMsg)
      {
        builder.Append("Validation Error: " + message);
        builder.Append(Environment.NewLine);
      }
      return builder.ToString();
    }
  }

  public class XsdToSchema : IResolver
  {
    public IEntry GetEntry(string name)
    {
      //HACK: here we find unqualified names!
      foreach (XmlQualifiedName qName in this.SchemaDefs.Keys)
      {
        if (qName.Name == name)
          return this.SchemaDefs[qName].Entry;
      }
      Debug.Assert(false);
      return new SchemaEntry(name, this.SchemaDefs[new XmlQualifiedName(name)]);
    }
    private IDictionary<XmlQualifiedName, ConstantSchema> schemaDefs;
    private IDictionary<XmlQualifiedName, ISchema> elementDefs;
    private IDictionary<XmlQualifiedName, XmlAttribute[]> unhandledSchemaAttributes;
    private IDictionary<XmlQualifiedName, XmlAttribute[]> unhandledElementAttributes;
    private XmlSchemaObjectTable schemas;
    private XmlSchemaObjectTable elements;
    private XsdImportOutput output;
    private XmlReader xsd;
    private XmlSchema compiledSchema;

    public XsdImportOutput Output { get { return output; } }
    public IDictionary<XmlQualifiedName, ConstantSchema> SchemaDefs { get { return schemaDefs; } }
    public IDictionary<XmlQualifiedName, ISchema> ElementDefs { get { return elementDefs; } }
    public IDictionary<XmlQualifiedName, XmlAttribute[]> UnhandledSchemaAttributes { get { return unhandledSchemaAttributes; } }
    public IDictionary<XmlQualifiedName, XmlAttribute[]> UnhandledElementAttributes { get { return unhandledElementAttributes; } }

    public XsdToSchema(XmlReader xsd)
    {
      schemaDefs = new Dictionary<XmlQualifiedName, ConstantSchema>();
      elementDefs = new Dictionary<XmlQualifiedName, ISchema>();
      unhandledSchemaAttributes = new Dictionary<XmlQualifiedName, XmlAttribute[]>();
      unhandledElementAttributes = new Dictionary<XmlQualifiedName, XmlAttribute[]>();
      output = new XsdImportOutput();
      this.xsd = xsd;
    }

    public void Compile()
    {
      XmlSchemaSet schemaSet = new XmlSchemaSet();
      ValidationEventHandler vHandler = new ValidationEventHandler(
        delegate(object sender, ValidationEventArgs args)
        { output.AddValidationError(args.Message); });
      
      schemaSet.ValidationEventHandler += vHandler;   
      schemaSet.Add(XmlSchema.Read(xsd, vHandler));
      schemaSet.Compile();

      foreach (XmlSchema schema in schemaSet.Schemas())
      { this.compiledSchema = schema; }

      this.schemas = compiledSchema.SchemaTypes;
      this.elements = compiledSchema.Elements;

      foreach (XmlQualifiedName name in schemas.Names)
      { schemaDefs[name] = new ConstantSchema(name.Name, null); }
      //Creates schema names from element names. This is important for schema references
      foreach (XmlQualifiedName name in elements.Names)
      { schemaDefs[name] = new ConstantSchema(name.Name, null); }

      foreach (XmlQualifiedName name in elements.Names)
      {
        elementDefs[name] = Visit(compiledSchema.Elements[name]);
        unhandledElementAttributes[name] = ((XmlSchemaElement)compiledSchema.Elements[name]).UnhandledAttributes;
        SchemaEntry entry = new SchemaEntry(name.Name, elementDefs[name]);
        schemaDefs[name].Entry = entry;
      }
      foreach (XmlQualifiedName name in schemas.Names)
      {
        SchemaEntry entry = new SchemaEntry(name.Name, Visit(compiledSchema.SchemaTypes[name]));
        schemaDefs[name].Entry = entry;
        unhandledSchemaAttributes[name] = ((XmlSchemaType)compiledSchema.SchemaTypes[name]).UnhandledAttributes;
      }
      //Resolves names
      ResolveNamesSchemaVisitor v = new ResolveNamesSchemaVisitor(this);
      foreach (ISchema schema in elementDefs.Values)
      { schema.Accept(v); }
      foreach (ISchema schema in schemaDefs.Values)
      { schema.Accept(v); }
      //Removes additional schema names generated from elements
      //foreach (XmlQualifiedName name in elements.Names)
      //{ schemaDefs.Remove(name); }
    }

    private ISchema GetBasicSchemaFromName(XmlQualifiedName qName)
    {
      if (!qName.Namespace.Equals(WebNamespace.XmlSchemaNamespace))
        return null;
      else if (qName.Name.Equals("int") || qName.Name.Equals("integer"))
        return new BasicSchema(new IntType());
      else if (qName.Name.Equals("float"))
        return new BasicSchema(new FloatType());
      else if (qName.Name.Equals("boolean"))
        return new BasicSchema(new BoolType());
      else if (qName.Name.Equals("positiveInteger") || qName.Name.Equals("negativeInteger") ||
        qName.Name.Equals("nonPositiveInteger") || qName.Name.Equals("nonNegativeInteger") ||
        qName.Name.Equals("unsignedInt") || qName.Name.Equals("short") || qName.Name.Equals("unsignedShort") ||
        qName.Name.Equals("long") || qName.Name.Equals("unsignedLong"))
      {
        output.AddWarning(qName.Name + "\" imported as integer");
        return new BasicSchema(new IntType());
      }
      else if (qName.Name.Equals("string"))
        return new BasicSchema(new StringType());
      else
      {
        output.AddWarning(qName.Name + "\" imported as string");
        return new BasicSchema(new StringType());
      }
    }

    public ISchema GetSchemaFromName(XmlQualifiedName qName)
    {
      ISchema schema = GetBasicSchemaFromName(qName);
      if (schema != null)
        return schema;
      else if (elementDefs.ContainsKey(qName))
        return elementDefs[qName];
      else if (schemaDefs.ContainsKey(qName))
        return schemaDefs[qName];
      else Debug.Assert(false, qName + " should be defined");
      return null;
    }

    private ISchema BuildRepetition(ISchema t, string minOccurs, string maxOccurs)
    {
      if (minOccurs == null) minOccurs = "1";
      if (maxOccurs == null) maxOccurs = "1";

      uint min = UInt32.Parse(minOccurs);
      if (maxOccurs.Equals("unbounded"))
      {
        if (min == 0) return new StarSchema(t);
        else if (min == 1) return new PlusSchema(t);
        else 
          return new SequenceSchema(new RepetitionSchema(t, min, min), new StarSchema(t));
      }
      else if (min == 1 && UInt32.Parse(maxOccurs) == 1) return t;
      else return new RepetitionSchema(t, min, UInt32.Parse(maxOccurs));
    }

    private ISchema Visit(XmlSchemaObject t)
    {
      if (t is XmlSchemaAny)
        return VisitXmlSchemaAny((XmlSchemaAny)t);
      if (t is XmlSchemaChoice)
        return VisitXmlSchemaChoice((XmlSchemaChoice)t);
      else if (t is XmlSchemaSequence)
        return VisitXmlSchemaSequence((XmlSchemaSequence)t);
      else if (t is XmlSchemaAll)
        return VisitXmlSchemaAll((XmlSchemaAll)t);
      else if (t is XmlSchemaSimpleType)
        return VisitXmlSchemaSimpleType((XmlSchemaSimpleType)t);
      else if (t is XmlSchemaComplexType)
        return VisitXmlSchemaComplexType((XmlSchemaComplexType)t);
      else if (t is XmlSchemaSimpleTypeRestriction)
        return VisitXmlSchemaSimpleTypeRestriction((XmlSchemaSimpleTypeRestriction)t);
      else if (t is XmlSchemaSimpleTypeList)
        return VisitXmlSchemaSimpleTypeList((XmlSchemaSimpleTypeList)t);
      else if (t is XmlSchemaSimpleTypeUnion)
        return VisitXmlSchemaSimpleTypeUnion((XmlSchemaSimpleTypeUnion)t);
      else if (t is XmlSchemaComplexContent)
        return VisitXmlSchemaComplexContent((XmlSchemaComplexContent)t);
      else if (t is XmlSchemaComplexContentExtension)
        return VisitXmlSchemaComplexContentExtension((XmlSchemaComplexContentExtension)t);
      else if (t is XmlSchemaComplexContentRestriction)
        return VisitXmlSchemaComplexContentRestriction((XmlSchemaComplexContentRestriction)t);
      else if (t is XmlSchemaComplexType)
        return VisitXmlSchemaComplexType((XmlSchemaComplexType)t);
      else if (t is XmlSchemaSimpleContent)
        return VisitXmlSchemaSimpleContent((XmlSchemaSimpleContent)t);
      else if (t is XmlSchemaSimpleContentExtension)
        return VisitXmlSchemaSimpleContentExtension((XmlSchemaSimpleContentExtension)t);
      else if (t is XmlSchemaElement)
        return VisitXmlSchemaElement((XmlSchemaElement)t);
      else if (t is XmlSchemaSimpleContentRestriction)
        return VisitXmlSchemaSimpleContentRestriction((XmlSchemaSimpleContentRestriction)t);
      //else if (t is XmlSchemaEnumerationFacet)
       // return VisitXmlSchemaEnumerationFacet((XmlSchemaEnumerationFacet)t);
      else
      {
        output.AddError(t.LineNumber, t.LinePosition, "\"" + t.GetType() + "\" is not supported");
        throw new IllegalConversionException(output.ToString());
      }
    }

    private ISchema VisitXmlSchemaAny(XmlSchemaAny s)
    { return Schema.Any; }

    private ISchema VisitXmlSchemaChoice(XmlSchemaChoice s)
    {
      ISchema content = null;
      if (s.Items.Count == 0)
        content = Schema.Empty;
      foreach (XmlSchemaObject t in s.Items)
      {
        if (content == null) content = Visit(t);
        else content = UnionSchema.Make(content, Visit(t));
      }
      return BuildRepetition(content, s.MinOccursString, s.MaxOccursString);
    }

    private ISchema VisitXmlSchemaSequence(XmlSchemaSequence s)
    {
      ISchema content = null;
      if (s.Items.Count == 0)
        content = Schema.Empty;
      foreach (XmlSchemaObject t in s.Items)
      {
        if (content == null) content = Visit(t);
        else content = new SequenceSchema(content, Visit(t));
      }
      return BuildRepetition(content, s.MinOccursString, s.MaxOccursString);
    }

    private ISchema VisitXmlSchemaAll(XmlSchemaAll s)
    {
      output.AddWarning(s.LineNumber, s.LinePosition, "\"all\" imported as an ordered sequence");
      ISchema content = null;
      if (s.Items.Count == 0)
        content = Schema.Empty;
      foreach (XmlSchemaObject t in s.Items)
      {
        if (content == null) content = Visit(t);
        else content = new AllSchema(content, Visit(t));
      }
      return BuildRepetition(content, s.MinOccursString, s.MaxOccursString);
    }

    private ISchema VisitXmlSchemaSimpleType(XmlSchemaSimpleType s)
    {
      /*
       * <simpleType
       * final = (#all | (list | union | restriction))
       * id = ID
       * name = NCName
       * {any attributes with non-schema namespace . . .}>
       * Content: (annotation?, (restriction | list | union))
       * </simpleType>
       */
      if (s.Final != XmlSchemaDerivationMethod.Empty && s.Final != XmlSchemaDerivationMethod.None)
        output.AddWarning(s.LineNumber, s.LinePosition, "\"final simpleType\" is ignored");
      if (s.IsMixed)
        output.AddWarning(s.LineNumber, s.LinePosition, "\"mixed simpleType\" is ignored");
      return Visit(s.Content);
    }

    private ISchema VisitXmlSchemaSimpleTypeRestriction(XmlSchemaSimpleTypeRestriction s)
    {
      /* <restriction
       * base = QName
       * id = ID
       * {any attributes with non-schema namespace . . .}>
       * Content: (annotation?, (simpleType?, (minExclusive | minInclusive | maxExclusive | maxInclusive | 
       * totalDigits | fractionDigits | length | minLength | maxLength | enumeration | whiteSpace | pattern)*))
       * </restriction>
       */
      ISchema content = null;
      content = GetSchemaFromName(s.BaseTypeName);
      if (content is ConstantSchema)
        content = Visit(this.schemas[s.BaseTypeName]);
      bool enumeration = false;
      bool length = false;
      foreach (XmlSchemaObject f in s.Facets)
      {
        if (f is XmlSchemaEnumerationFacet)
          enumeration = true;
        if (f is XmlSchemaMinLengthFacet || f is XmlSchemaMaxLengthFacet ||
          f is XmlSchemaLengthFacet)
          length = true;
      }
      string minOccurs = "1";
      string maxOccurs = "1";
      ISchema argumentSchema;
      if (content is StarSchema)
      {
        argumentSchema = ((StarSchema)content).Content;
        minOccurs = "0";
        maxOccurs = "unbounded";
      }
      else if (content is PlusSchema)
      {
        argumentSchema = ((PlusSchema)content).Content;
        minOccurs = "1";
        maxOccurs = "unbounded";
      }
      else if (content is RepetitionSchema)
      {
        argumentSchema = ((RepetitionSchema)content).Content;
        minOccurs = ((RepetitionSchema)content).MinOccurs.ToString();
        maxOccurs = ((RepetitionSchema)content).MaxOccurs.ToString();
      }
      else argumentSchema = content;

      if (enumeration)
      {
        ISchema choice = null;
        foreach (XmlSchemaObject f in s.Facets)
        {
          if (f is XmlSchemaEnumerationFacet)
          {
            if (choice == null)
              choice = VisitXmlSchemaEnumerationFacet((XmlSchemaEnumerationFacet)f, argumentSchema);
            else
              choice = UnionSchema.Make(choice,
                VisitXmlSchemaEnumerationFacet((XmlSchemaEnumerationFacet)f, argumentSchema));
          }
        }
        argumentSchema = choice;
      }

      if (length && !(content is StarSchema || content is PlusSchema || content is RepetitionSchema))
        output.AddWarning(s.LineNumber, s.LinePosition, "XmlSchema LengthFacet is not supported for non-list types " + content.GetType());
      else if (length)
      {
        foreach (XmlSchemaObject f in s.Facets)
        {
          if (f is XmlSchemaPatternFacet || f is XmlSchemaWhiteSpaceFacet) //todo Whitespace
            output.AddWarning(f.LineNumber, f.LinePosition, f.GetType() + "is not supported");
        }
        foreach (XmlSchemaObject f in s.Facets)
        {
          if (f is XmlSchemaLengthFacet)
          {
            Debug.Assert(maxOccurs.Equals("unbounded") || UInt32.Parse(maxOccurs) >= UInt32.Parse(((XmlSchemaLengthFacet)f).Value));
            Debug.Assert(UInt32.Parse(minOccurs) <= UInt32.Parse(((XmlSchemaLengthFacet)f).Value));
            minOccurs = maxOccurs = ((XmlSchemaLengthFacet)f).Value;
          }
          else if (f is XmlSchemaMinLengthFacet)
          {
            Debug.Assert(UInt32.Parse(minOccurs) <= UInt32.Parse(((XmlSchemaMinLengthFacet)f).Value));
            minOccurs = ((XmlSchemaMinLengthFacet)f).Value;
          }
          else if (f is XmlSchemaMaxLengthFacet)
          {
            Debug.Assert(maxOccurs.Equals("unbounded") || UInt32.Parse(maxOccurs) >= UInt32.Parse(((XmlSchemaMaxLengthFacet)f).Value));
            maxOccurs = ((XmlSchemaMaxLengthFacet)f).Value;
          }
        }
      }
      return BuildRepetition(argumentSchema, minOccurs, maxOccurs);
    }

    private ISchema VisitXmlSchemaSimpleTypeList(XmlSchemaSimpleTypeList s)
    {
      /*
       * <list
       * id = ID
       * itemType = QName
       * {any attributes with non-schema namespace . . .}>
       * Content: (annotation?, (simpleType?))
       * </list>
       * Possible restrictions: length | maxLength | minLength | enumeration | pattern | whiteSpace
       */
      ISchema content = null;
      if (!s.ItemTypeName.IsEmpty)
      {
        content = GetSchemaFromName(s.ItemTypeName);
        if (content is ConstantSchema)
          content = Visit(schemas[s.ItemTypeName]);
      }
      else
        content = Visit(s.BaseItemType);
      string minOccurs = "0";
      string maxOccurs = "unbounded";
      if (s.ItemType != null && s.ItemType.Content is XmlSchemaSimpleTypeRestriction)
      {
        XmlSchemaSimpleTypeRestriction restriction = (XmlSchemaSimpleTypeRestriction)s.ItemType.Content;
        foreach (XmlSchemaObject f in restriction.Facets)
        {
          if (f is XmlSchemaPatternFacet || f is XmlSchemaWhiteSpaceFacet) //todo Whitespace
            output.AddWarning(f.LineNumber, f.LinePosition, f.GetType() + "is not supported");
        }
        //bool first = true;
        //foreach (XmlSchemaObject f in restriction.Facets)
        //{
        //  if (f is XmlSchemaEnumerationFacet)
        //  {
        //    if (first)
        //    {
        //      content = VisitXmlSchemaEnumerationFacet((XmlSchemaEnumerationFacet)f, content);
        //      first = false;
        //    }
        //    else content = UnionSchema.Make(content, VisitXmlSchemaEnumerationFacet((XmlSchemaEnumerationFacet)f, content));
        //  }
        //}
        foreach (XmlSchemaObject f in restriction.Facets)
        {
          if (f is XmlSchemaLengthFacet)
            minOccurs = maxOccurs = ((XmlSchemaLengthFacet)f).Value;
          else if (f is XmlSchemaMinLengthFacet)
            minOccurs = ((XmlSchemaMinLengthFacet)f).Value;
          else if (f is XmlSchemaMaxLengthFacet)
            maxOccurs = ((XmlSchemaMaxLengthFacet)f).Value;
        }
      }
      return BuildRepetition(content, minOccurs, maxOccurs);
    }

    private ISchema VisitXmlSchemaSimpleTypeUnion(XmlSchemaSimpleTypeUnion s)
    {
      ISchema content = null;
      if (s.MemberTypes != null)
      {
        foreach (XmlQualifiedName baseTypeName in s.MemberTypes)
        {
          if (content == null) content = GetSchemaFromName(baseTypeName);
          else content = UnionSchema.Make(content, GetSchemaFromName(baseTypeName));
        }
      }
      if (s.BaseMemberTypes != null)
      {
        foreach (XmlSchemaSimpleType baseType in s.BaseMemberTypes)
        {
          if (content == null)
            content = VisitXmlSchemaSimpleType(baseType);
          else if (baseType.QualifiedName.Equals(new XmlQualifiedName()))
            content = UnionSchema.Make(content, VisitXmlSchemaSimpleType(baseType));
        }
      }
      return content;
    }

    private ISchema VisitXmlSchemaComplexContent(XmlSchemaComplexContent s)
    {
      if (s.IsMixed)
        output.AddWarning(s.LineNumber, s.LinePosition, "\"mixed content model\" is ignored");
      return Visit(s.Content);
    }

    private ISchema VisitXmlSchemaComplexContentExtension(XmlSchemaComplexContentExtension s)
    {
      ISchema tail = Visit(s.Particle);
      Debug.Assert(!s.BaseTypeName.IsEmpty);
      ISchema head = GetSchemaFromName(s.BaseTypeName);
      return new SequenceSchema(head, tail);
    }

    private ISchema VisitXmlSchemaComplexContentRestriction(XmlSchemaComplexContentRestriction s)
    {
      //complex content restriction allows to add attributes
      XmlQualifiedName arrayQName = new XmlQualifiedName("Array", WebNamespace.SoapEncNamespace);
      if (s.BaseTypeName.Equals(arrayQName)) 
      {
        //<attribute ref="soapenc:arrayType" wsdl:arrayType="xsd:float[]"/> 
        XmlSchemaAttribute attr = (XmlSchemaAttribute)s.Attributes[0];
        string name = String.Empty; 
        string namespaceUri = String.Empty;
        string[] size = null;
        foreach(XmlAttribute a in attr.UnhandledAttributes)
        {
          if (a.NamespaceURI == WebNamespace.WsdlNamespace && a.LocalName == "arrayType")
          {
            string schemaName = a.Value.Substring(0, a.Value.IndexOf('['));
            int pos = schemaName.LastIndexOf(':');
            if (pos > 0)
            {
              namespaceUri = schemaName.Substring(0, pos);
              //this is for MONO that lookups the namespace automatically (.Net does not)
              try 
              { new Uri(namespaceUri, UriKind.Absolute); } 
              catch (Exception)
              { namespaceUri = xsd.LookupNamespace(namespaceUri); }
              name = schemaName.Substring(pos + 1);
            }
            else name = schemaName;
            string boundaries = a.Value.Substring(a.Value.IndexOf('['));
            if (boundaries.Contains(","))
              this.output.AddError(s.LineNumber, s.LinePosition, "Multi-dimensional arrays are not supported (only jagged array are supported");
            boundaries = boundaries.Replace(",", "[]");
            Regex e = new Regex(@"^\[{[0-9] }*\]$");
            size = e.Split(boundaries);
          }
        }
        XmlQualifiedName qName = new XmlQualifiedName(name, namespaceUri);
        ISchema arraySchema = null;
        int j = size.Length - 1;
        do
        {
          size[j] = size[j].Replace(" ", "").Replace("[", "").Replace("]", "");
          if (size[j] == "")
          {
            if (arraySchema == null)
              arraySchema = new ArrayStarSchema(qName, new LabelledSchema(LabelSet.Singleton("Item"), GetSchemaFromName(qName)));
            else new ArrayStarSchema(qName, new LabelledSchema(LabelSet.Singleton("Item"), arraySchema));
          }
          else
          {
            int occurs = int.Parse(size[j]);
            if (arraySchema == null)
              arraySchema = new ArrayRepetitionSchema(qName, new LabelledSchema(LabelSet.Singleton("Item"), GetSchemaFromName(qName)), (uint)occurs);
            else new ArrayRepetitionSchema(qName, new LabelledSchema(LabelSet.Singleton("Item"), arraySchema), (uint)occurs);
          }
          j--;
        } while (j>0);
        return arraySchema;
      }
      else if (s.Particle == null)
      {
        output.AddError(s.LineNumber, s.LinePosition, "\"complex content restriction\" is ignored");
        return new VoidSchema();
      }
      else
        return Visit(s.Particle);
    }

    private ISchema VisitXmlSchemaComplexType(XmlSchemaComplexType s)
    {
      if (s.IsMixed)
        output.AddWarning(s.LineNumber, s.LinePosition, "\"mixed content model\" is ignored");
      if (s.IsAbstract)
        output.AddWarning(s.LineNumber, s.LinePosition, "\"abstract complexType\" is ignored");
      if (s.Final != XmlSchemaDerivationMethod.Empty && s.Final != XmlSchemaDerivationMethod.None)
        output.AddWarning(s.LineNumber, s.LinePosition, "\"final complexType\" is ignored");
      if (s.ContentModel != null)
        return Visit(s.ContentModel);
      else if (s.ContentTypeParticle is XmlSchemaGroupBase)
        return Visit(s.ContentTypeParticle);
      else return new VoidSchema();
    }

    private ISchema VisitXmlSchemaSimpleContent(XmlSchemaSimpleContent s)
    { return Visit(s.Content); }

    private ISchema VisitXmlSchemaSimpleContentExtension(XmlSchemaSimpleContentExtension s)
    {
      output.AddError(s.LineNumber, s.LinePosition, "\"simpleType extension\" is not supported");
      return GetSchemaFromName(s.BaseTypeName);
    }

    private bool IsWithoutElement(XmlSchemaElement s, out ISet<string> labels)
    {
      labels = new ArraySet<string>();
      if (s.UnhandledAttributes == null) return false;
      bool isWithout = false;
      foreach (XmlAttribute a in s.UnhandledAttributes)
        if (a.NamespaceURI.Equals(WebNamespace.PiDuceNamespace) &&
          a.LocalName.Equals("schema") && a.Value.Equals("without"))
        {
          isWithout = true;
          if (s.Annotation != null)
            foreach (XmlSchemaObject annotation in s.Annotation.Items)
              if (annotation is XmlSchemaAppInfo)
                foreach (XmlNode without in ((XmlSchemaAppInfo)annotation).Markup)
                  labels.Add(without.Attributes["label"].Value);
        }
      return isWithout;
    }

    private bool IsPiDuceElement(XmlSchemaElement s, out ISchema schema)
    {
      if (s.UnhandledAttributes == null)
      {
        schema = null;
        return false;
      }
      foreach (XmlAttribute a in s.UnhandledAttributes)
      {
        if (a.NamespaceURI.Equals(WebNamespace.PiDuceNamespace) && a.LocalName.Equals("schema") &&
          a.Value.Equals("PiDuceChannel"))
        {
          ChannelType.CAPABILITY capability = ChannelType.CAPABILITY.OUT;
          if (a.NamespaceURI.Equals(WebNamespace.PiDuceNamespace) && a.LocalName.Equals("capability"))
          {
            if (a.Value.Equals("I"))
              capability = ChannelType.CAPABILITY.IN;
            else if (a.Value.Equals("O"))
              capability = ChannelType.CAPABILITY.OUT;
            else if (a.Value.Equals("IO"))
              capability = ChannelType.CAPABILITY.INOUT;
          }
          foreach (XmlSchemaObject annotation in s.Annotation.Items)
          {
            if (annotation is XmlSchemaAppInfo)
            {
              XmlNode serviceInterface = ((XmlSchemaAppInfo)annotation).Markup[0];
              XmlNamespaceManager nsmgr = new XmlNamespaceManager(xsd.NameTable);
              nsmgr.AddNamespace("piduce", WebNamespace.PiDuceNamespace);
              nsmgr.AddNamespace("xsd", WebNamespace.XmlSchemaNamespace);
              XmlReader xsdSchema = new XmlNodeReader(serviceInterface.SelectSingleNode("/piduce:interface/piduce:types/xsd:schema", nsmgr));
              XsdToSchema tmp = new XsdToSchema(xsdSchema);
              tmp.Compile();
              ISchema inputSchema = null;
              ISchema outputSchema = null;
              XmlNode inputNode = serviceInterface.SelectSingleNode("/piduce:interface/piduce:input", nsmgr);
              if (inputNode != null)
              {
                string messageName = inputNode.Attributes["element", WebNamespace.PiDuceNamespace].Value;
                if (messageName.IndexOf(':') != -1)
                  messageName = messageName.Substring(messageName.IndexOf(':') + 1);
                XmlQualifiedName n = new XmlQualifiedName(messageName, WebNamespace.PiDuceDefaultNamespace);
                bool isWrapper = false;
                if (tmp.UnhandledElementAttributes[n].Length > 0)
                {
                  foreach (XmlAttribute att in tmp.UnhandledElementAttributes[n])
                  {
                    if (att.LocalName == "isWrapper" && att.Value == "yes" && att.NamespaceURI == WebNamespace.PiDuceNamespace)
                      isWrapper = true;
                  }
                }
                inputSchema = tmp.ElementDefs[n];
                if (isWrapper)
                  inputSchema = ((LabelledSchema)inputSchema).Content;
              }
              XmlNode outputNode = serviceInterface.SelectSingleNode("/piduce:interface/piduce:output", nsmgr);
              if (outputNode != null)
              {
                string messageName = outputNode.Attributes["element", WebNamespace.PiDuceNamespace].Value;
                if (messageName.IndexOf(':') != -1)
                  messageName = messageName.Substring(messageName.IndexOf(':') + 1);
                XmlQualifiedName n = new XmlQualifiedName(messageName, WebNamespace.PiDuceDefaultNamespace);
                bool isWrapper = false;
                if (tmp.UnhandledElementAttributes[n].Length > 0)
                {
                  foreach (XmlAttribute att in tmp.UnhandledElementAttributes[n])
                  {
                    if (att.LocalName == "isWrapper" && att.Value == "yes" && att.NamespaceURI == WebNamespace.PiDuceNamespace)
                      isWrapper = true;
                  }
                }
                outputSchema = tmp.ElementDefs[n];
                if (isWrapper)
                  outputSchema = ((LabelledSchema)outputSchema).Content;
              }
              if (outputSchema == null) schema = new ChannelSchema(inputSchema, capability);
              else schema = new FunctionSchema(inputSchema, outputSchema);
              return true;
            }
          }
        }
        else if (a.NamespaceURI.Equals(WebNamespace.PiDuceNamespace) && a.LocalName.Equals("schema") &&
          a.Value.Equals("PiDuceService"))
        {
          foreach (XmlSchemaObject annotation in s.Annotation.Items)
          {
            if (annotation is XmlSchemaAppInfo)
            {
              string wsdl = ((XmlSchemaAppInfo)annotation).Markup[0].OuterXml;
              XsdToSchema converter;
              schema = AbstractWsdlReader.CompileAbstractWsdl(wsdl, out converter);
              return true;
            }
          }
        }
      }
      schema = null;
      return false;
    }

    private ISchema VisitXmlSchemaElement(XmlSchemaElement s)
    {
      /*
       * <element
       * abstract = boolean : false
       * block = (#all | List of (extension | restriction | substitution))
       * default = string
       * final = (#all | List of (extension | restriction))
       * fixed = string
       * form = (qualified | unqualified)
       * id = ID
       * maxOccurs = (nonNegativeInteger | unbounded)  : 1
       * minOccurs = nonNegativeInteger : 1
       * name = NCName
       * nillable = boolean : false
       * ref = QName
       * substitutionGroup = QName
       * schema = QName
       * {any attributes with non-schema namespace . . .}>
       * Content: (annotation?, ((simpleType | complexType)?, (unique | key | keyref)*))
       * </element>
       */
      ISchema schema;
      if (IsPiDuceElement(s, out schema))
        return schema;
      else if (!s.RefName.IsEmpty)  
        return GetSchemaFromName(s.RefName);
      else
      {
        ISchema content = null;
        string name = s.Name;
        if (s.Block != XmlSchemaDerivationMethod.Empty && s.Block != XmlSchemaDerivationMethod.None)
          output.AddWarning(s.LineNumber, s.LinePosition, "\"block\" is ignored");
        if (s.IsAbstract)
          output.AddWarning(s.LineNumber, s.LinePosition, "\"abstract\" is ignored");
        if (s.Form == XmlSchemaForm.Qualified)
          output.AddWarning(s.LineNumber, s.LinePosition, "\"qualified form\" is not supported");
        if (!s.SchemaTypeName.IsEmpty)
        { content = GetSchemaFromName(s.SchemaTypeName); }
        else if (!s.SubstitutionGroup.IsEmpty)
        { content = GetSchemaFromName(s.SubstitutionGroup); }

        if (content == null)
          content = Visit(s.ElementSchemaType);
        Debug.Assert(content != null);

        if (s.FixedValue != null && s.FixedValue.Length != 0)
        {
          if (content is BasicSchema)
          {
            IBasicType type = ((BasicSchema)content).Type;
            if (type is IntType)
              content = new BasicSchemaLiteralSchema(new IntLiteral(Int32.Parse(s.FixedValue)));
            else if (type is StringType)
              content = new BasicSchemaLiteralSchema(new StringLiteral(s.FixedValue));
            else
              output.AddWarning(s.LineNumber, s.LinePosition, "\"fixed\" is supported only for basic types");
          }
        }
        if (s.DefaultValue != null && s.DefaultValue.Length != 0)
          output.AddWarning(s.LineNumber, s.LinePosition, "\"default\" is ignored");
        ISet<string> labels;
        if (IsWithoutElement(s, out labels)) content = new LabelledSchema(LabelSet.Without(labels), content);
        else content = new LabelledSchema(LabelSet.Singleton(name), content);
        if (s.IsNillable) content = UnionSchema.Make(content, new VoidSchema());
        return schema = BuildRepetition(content, s.MinOccursString, s.MaxOccursString);
      }
    }

    private ISchema VisitXmlSchemaEnumerationFacet(XmlSchemaEnumerationFacet s, ISchema baseSchema)
    {
			if (baseSchema is BasicSchema) {
				IBasicType type = ((BasicSchema) baseSchema).Type;
      	if (type is IntType)
        	return new BasicSchemaLiteralSchema(new IntLiteral(Int32.Parse(s.Value)));
      	else if (type is StringType)
        	return new BasicSchemaLiteralSchema(new StringLiteral(s.Value));
			}

      output.AddWarning(s.LineNumber, s.LinePosition, "\"Enumeration\" on " +
        baseSchema + " is ignored (supported only on basic types)");
      return null;
    }

    private ISchema VisitXmlSchemaSimpleContentRestriction(XmlSchemaSimpleContentRestriction s)
    {
      /* <restriction
       * base = QName
       * id = ID
       * {any attributes with non-schema namespace . . .}>
       * Content: (annotation?, (simpleType?, (minExclusive | minInclusive | maxExclusive | maxInclusive | totalDigits 
       * | fractionDigits | length | minLength | maxLength | enumeration | whiteSpace | pattern)*)?, 
       * ((attribute | attributeGroup)*, anyAttribute?))
       * </restriction>
       */
      ISchema content = null;
      if (s.Facets.Count == 0 && !s.BaseTypeName.IsEmpty)
        content = GetSchemaFromName(s.BaseTypeName);
      else if (s.Facets.Count == 0)
        content = Visit(s.BaseType);

      bool first = true;
      foreach (XmlSchemaObject f in s.Facets)
      {
        if (f is XmlSchemaEnumerationFacet)
        {
          if (first)
          {
            content = VisitXmlSchemaEnumerationFacet((XmlSchemaEnumerationFacet)f, content);
            first = false;
          }
          else content = UnionSchema.Make(content, VisitXmlSchemaEnumerationFacet((XmlSchemaEnumerationFacet)f, content));
        }
        else
          output.AddWarning(f.LineNumber, f.LinePosition, "only enumeration is supported");
      }
      return content;
    }
  }
}
