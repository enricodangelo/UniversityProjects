using System;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Diagnostics;
using PiDuce.Types;
using PiDuce.Common;

namespace PiDuce.Web
{
  public class ConstantSchemaVisitor : AbstractSchemaVisitor
  {
    private IDictionary<string, ISchema> schemas = new Dictionary<string, ISchema>();

    public IDictionary<string, ISchema> Schemas { get { return schemas; } }

    public override void VisitConstantSchema(ConstantSchema s)
    { schemas[s.Name] = s.Entry.Schema; }
  }

  public class IsSimpleTypeSchemaVisitor : ISchemaVisitor
  {
    private bool result = false;
    
    public bool Result { get { return result; } }

    private ISet<IEntry> visited = new ArraySet<IEntry>();

    private bool Visit(ISchema s)
    {
      s.Accept(this);
      return result;
    }

    public void VisitLabelledSchema(LabelledSchema s)
    { result = false; }

    public void VisitSequenceSchema(SequenceSchema s)
    { result = Visit(s.Head) && Visit(s.Tail); }

    public void VisitUnionSchema(UnionSchema s)
    { result = Visit(s.Left) && Visit(s.Right); }

    public void VisitStarSchema(StarSchema s)
    { result = Visit(s.Content); }

    public void VisitPlusSchema(PlusSchema s)
    { result = Visit(s.Content); }

    public void VisitRepetitionSchema(RepetitionSchema s)
    { result = Visit(s.Content); }

    public void VisitVoidSchema(VoidSchema s)
    { result = false; }

		public void VisitBasicSchema(BasicSchema s)
		{ result = true; }

    public void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
    { result = true; }

    public void VisitConstantSchema(ConstantSchema s)
    {
      if (!visited.Contains(s.Entry))
      {
        visited.Add(s.Entry);
        result = Visit(s.Entry.Schema);
      }
      else result = true;
    }

    public void VisitChannelSchema(ChannelSchema s)
    { result = false; }

    public void VisitFunctionSchema(FunctionSchema s)
    { result = false; }

    public void VisitErrorSchema(ErrorSchema s)
    { result = false; }

    public void VisitBindSchema(BindSchema s)
    {
      Debug.Assert(false);
      result = Visit(s.Content);
    }

		public void VisitServiceSchema(ServiceSchema s)
		{ result = false; }
  }

  public class SchemaToXsd
  { 
    public static void WriteComplexTypes(IDictionary<string, ISchema> schemas, XmlWriter writer, string targetNamespace)
    {
      writer.WriteStartElement("schema", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("targetNamespace", targetNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.XmlSchemaNamespacePrefix, null, WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.PiDuceNamespacePrefix, null, WebNamespace.PiDuceNamespace);
      writer.WriteAttributeString("elementFormDefault", "qualified");
      ConstantSchemaVisitor v = new ConstantSchemaVisitor();
      foreach (ISchema schema in schemas.Values)
        schema.Accept(v);
      foreach (KeyValuePair<string, ISchema> def in v.Schemas)
        SchemaToXsd.WriteType(def.Key, def.Value, writer, targetNamespace);
      foreach (KeyValuePair<string, ISchema> key in schemas)
        SchemaToXsd.WriteType(key.Key, key.Value, writer, targetNamespace);
      writer.WriteEndElement();
    }

    public static void WriteElementsSchema(IDictionary<string, ISchema> schemas, XmlWriter writer, string targetNamespace)
    {
      writer.WriteStartElement("schema", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.XmlSchemaNamespacePrefix, null, WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.PiDuceNamespacePrefix, null, WebNamespace.PiDuceNamespace);
      writer.WriteAttributeString("targetNamespace", targetNamespace.ToString());
      writer.WriteAttributeString("elementFormDefault", "qualified");
      ConstantSchemaVisitor v = new ConstantSchemaVisitor();
      foreach (ISchema schema in schemas.Values)
        schema.Accept(v);
      foreach (KeyValuePair<string, ISchema> def in v.Schemas)
        SchemaToXsd.WriteType(def.Key, def.Value, writer, targetNamespace);
      foreach (KeyValuePair<string, ISchema> key in schemas)
      {
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", key.Key);
        WriteContent(key.Value, writer, targetNamespace);
        writer.WriteEndElement();
      }
      writer.WriteEndElement();
    }

    public static void WriteContent(ISchema schema, XmlWriter writer, string targetNamespace)
    {
      if (schema is ConstantSchema)
        writer.WriteAttributeString("type", ((ConstantSchema)schema).Name);
			else if (schema is BasicSchema) {
				switch (((BasicSchema) schema).Type.Kind) {
					case BasicTypeKind.BOOL:
						Debug.Assert(false);
						break;
					case BasicTypeKind.INT:
        		writer.WriteAttributeString("type", WebNamespace.XmlSchemaNamespacePrefix + ":int");
						break;
					case BasicTypeKind.STRING:
        		writer.WriteAttributeString("type", WebNamespace.XmlSchemaNamespacePrefix + ":string");
						break;
                    case BasicTypeKind.FLOAT:
                        writer.WriteAttributeString("type", WebNamespace.XmlSchemaNamespacePrefix + ":float");
                        break;
					default:
						Debug.Assert(false);
						break;
				}
      } else
				SchemaToXsd.WriteType(String.Empty, schema, writer, targetNamespace);
    }

    public static void WriteType(string name, ISchema schema, XmlWriter writer, string targetNamespace)
    {
      ISchemaVisitor v = new SchemaToXsdVisitor(writer, targetNamespace);
      if (schema is ConstantSchema)
        WriteType(name, ((ConstantSchema)schema).Entry.Schema, writer, targetNamespace);
      if (!SchemaToXsdVisitor.IsSimpleType(schema))
        writer.WriteStartElement("complexType", WebNamespace.XmlSchemaNamespace);
      else
        writer.WriteStartElement("simpleType", WebNamespace.XmlSchemaNamespace);
      if (!name.Equals(String.Empty))
        writer.WriteAttributeString("name", name);
      schema.Accept(v);
      writer.WriteEndElement();
    }
  }

  public class SchemaToXsdVisitor : ISchemaVisitor
  {
    private XmlWriter writer;
    private string targetNamespace;

    public static bool IsSimpleType(ISchema s)
    {
      IsSimpleTypeSchemaVisitor v = new IsSimpleTypeSchemaVisitor();
      s.Accept(v);
      return v.Result;
    }

    public SchemaToXsdVisitor(XmlWriter writer, string targetNamespace)
    { 
      this.writer = writer;
      this.targetNamespace = targetNamespace;
    }

    public void VisitLabelledSchema(LabelledSchema s)
    {
      if (s.Labels is WithLabels && s.Labels.Labels.Count > 1)
      {
        ISchema schema = null;
        foreach (string label in s.Labels.Labels)
        {
          if (schema == null)
            schema = new LabelledSchema(LabelSet.Singleton(label), s.Content);
          else schema = UnionSchema.Make(schema, new LabelledSchema(LabelSet.Singleton(label), s.Content));
        }
        VisitUnionSchema((UnionSchema)schema);
      }
      else if (s.Labels is WithLabels)
      {
        writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        foreach (string name in s.Labels.Labels)
          writer.WriteAttributeString("name", name);
        SchemaToXsd.WriteContent(s.Content, writer, targetNamespace);
        writer.WriteEndElement();
        writer.WriteEndElement();
      }
      else if (s.Labels is WithoutLabels)
      {
        writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("schema", WebNamespace.PiDuceNamespace, "without");
        string elementName = "a";
        foreach (string name in s.Labels.Labels)
          elementName += name;
        writer.WriteAttributeString("name", elementName);
        if (s.Content is ConstantSchema)
          writer.WriteAttributeString("type", ((ConstantSchema)s.Content).Name);

        //Our without encoding
        writer.WriteStartElement("annotation", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("documentation", WebNamespace.XmlSchemaNamespace);
        writer.WriteString("Without element definition");
        writer.WriteEndElement();
        writer.WriteStartElement("appinfo", WebNamespace.XmlSchemaNamespace);
        foreach (string name in s.Labels.Labels)
        {
          writer.WriteStartElement("without", WebNamespace.PiDuceNamespace);
          writer.WriteAttributeString("label", name);
          writer.WriteEndElement();
        }
        writer.WriteEndElement();//appinfo
        writer.WriteEndElement();//annotation

        if (!(s.Content is ConstantSchema))
        {
          if (!IsSimpleType(s.Content))
            writer.WriteStartElement("complexType", WebNamespace.XmlSchemaNamespace);
          else
            writer.WriteStartElement("simpleType", WebNamespace.XmlSchemaNamespace);
          s.Content.Accept(this);
          writer.WriteEndElement();
        }
        writer.WriteEndElement();
        writer.WriteEndElement();
      }
      else Debug.Assert(false);
    }

    public void VisitBindSchema(BindSchema s)
    {
      Debug.Assert(false);
      s.Content.Accept(this);
    }

    public void VisitSequenceSchema(SequenceSchema s)
    {
      if (!IsSimpleType(s))
      {
        writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
        s.Head.Accept(this);
        s.Tail.Accept(this);
        writer.WriteEndElement();
      }
      else 
      {
        s.Head.Accept(this);
        s.Tail.Accept(this);
      }
    }

    public void VisitUnionSchema(UnionSchema s)
    {
      if (!IsSimpleType(s))
      {
        writer.WriteStartElement("choice", WebNamespace.XmlSchemaNamespace);
        s.Left.Accept(this);
        s.Right.Accept(this);
        writer.WriteEndElement();
      }
      else
      {
        writer.WriteStartElement("union", WebNamespace.XmlSchemaNamespace);
        s.Left.Accept(this);
        s.Right.Accept(this);
        writer.WriteEndElement();
      }
    }

    public void VisitStarSchema(StarSchema s)
    {
      if (!IsSimpleType(s))
      {
        writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("minOccurs", "0");
        writer.WriteAttributeString("maxOccurs", "unbounded");
        s.Content.Accept(this);
        writer.WriteEndElement();
      }
      else
      {
        writer.WriteStartElement("list", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("simpleType", WebNamespace.XmlSchemaNamespace);
        s.Content.Accept(this);
        writer.WriteEndElement();
        writer.WriteEndElement();
      }
    }

    public void VisitPlusSchema(PlusSchema s)
    {
      if (!IsSimpleType(s))
      {
        writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("minOccurs", "0");
        writer.WriteAttributeString("maxOccurs", "unbounded");
        s.Content.Accept(this);
        writer.WriteEndElement();
      }
      else
      {
        writer.WriteStartElement("list", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("simpleType", WebNamespace.XmlSchemaNamespace);
        s.Content.Accept(this);
        writer.WriteEndElement();
        writer.WriteStartElement("restriction", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("minLength", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("value", "1");
        writer.WriteEndElement();
        writer.WriteEndElement();
        writer.WriteEndElement();
        writer.WriteEndElement();
      }
    }

    public void VisitRepetitionSchema(RepetitionSchema s)
    {
      if (!IsSimpleType(s))
      {
        writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("minOccurs", s.MinOccurs.ToString());
        writer.WriteAttributeString("maxOccurs", s.MaxOccurs.ToString());
        s.Content.Accept(this);
        writer.WriteEndElement();
      }
      else
      {
        writer.WriteStartElement("list", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("simpleType", WebNamespace.XmlSchemaNamespace);
        s.Content.Accept(this);
        writer.WriteEndElement();
        writer.WriteStartElement("restriction", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("minLength", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("value", s.MinOccurs.ToString());
        writer.WriteEndElement();
        writer.WriteStartElement("maxLength", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("value", s.MaxOccurs.ToString());
        writer.WriteEndElement();
        writer.WriteEndElement();
        writer.WriteEndElement();
      }
    }

    public void VisitVoidSchema(VoidSchema s)
    {
      writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
      writer.WriteEndElement();
    }

		public void VisitBasicSchema(BasicSchema s)
		{
      writer.WriteStartElement("restriction", WebNamespace.XmlSchemaNamespace);
			switch (s.Type.Kind) {
				case BasicTypeKind.BOOL:
					Debug.Assert(false);
					break;
				case BasicTypeKind.INT:
      		writer.WriteAttributeString("base", WebNamespace.XmlSchemaNamespacePrefix + ":int");
					break;
				case BasicTypeKind.STRING:
      		writer.WriteAttributeString("base", WebNamespace.XmlSchemaNamespacePrefix + ":string");
					break;
				default:
					Debug.Assert(false);
					break;
			}
      writer.WriteEndElement();
		}

    public void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
    {
      writer.WriteStartElement("enumeration", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("value", s.Value.ToString());
      writer.WriteEndElement();
    }

    public void VisitConstantSchema(ConstantSchema s)
    { s.Entry.Schema.Accept(this); }

    public void VisitChannelSchema(ChannelSchema s)
    {
      writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("name", "chan");
      writer.WriteAttributeString("schema", WebNamespace.PiDuceNamespace, "PiDuceChannel");
      if (s.Capability == ChannelType.CAPABILITY.IN)
        writer.WriteAttributeString("capability", WebNamespace.PiDuceNamespace, "I");
      if (s.Capability == ChannelType.CAPABILITY.OUT)
        writer.WriteAttributeString("capability", WebNamespace.PiDuceNamespace, "O");
      if (s.Capability == ChannelType.CAPABILITY.INOUT)
        writer.WriteAttributeString("capability", WebNamespace.PiDuceNamespace, "IO");

      //Our channel encoding
      writer.WriteStartElement("annotation", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("documentation", WebNamespace.XmlSchemaNamespace);
      writer.WriteString("Channel schema definition");
      writer.WriteEndElement();
      writer.WriteStartElement("appinfo", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("interface", WebNamespace.PiDuceNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.XmlSchemaNamespacePrefix, null, WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.WsdlNamespacePrefix, null, WebNamespace.WsdlNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.PiDuceNamespacePrefix, null, WebNamespace.PiDuceNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.PiDuceValueNamespacePrefix, null, WebNamespace.PiDuceValueNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.PiDuceDefaultNamespacePrefix, null, WebNamespace.PiDuceDefaultNamespace);

      writer.WriteStartElement("types", WebNamespace.PiDuceNamespace);
      writer.WriteStartElement("schema", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.XmlSchemaNamespacePrefix, null, WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("xmlns", WebNamespace.PiDuceNamespacePrefix, null, WebNamespace.PiDuceNamespace);
      writer.WriteAttributeString("targetNamespace", targetNamespace);
      writer.WriteAttributeString("elementFormDefault", "qualified");

      WsdlGenerator.WriteAsyncOperationSchema(writer, String.Empty, s.Content, WebNamespace.PiDuceDefaultNamespace);
      
      writer.WriteEndElement();//schema;
      writer.WriteEndElement();//types
      writer.WriteStartElement("input", WebNamespace.PiDuceNamespace);
      writer.WriteAttributeString("type", WebNamespace.PiDuceNamespace, WebNamespace.PiDuceDefaultNamespacePrefix + ":In");
      writer.WriteEndElement();//input
      writer.WriteEndElement();//interface

      writer.WriteEndElement();//appinfo
      writer.WriteEndElement();//annotation

      //channel encoding for the rest of the world
      writer.WriteStartElement("complexType", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("simpleContent", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("extension", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("base", WebNamespace.XmlSchemaNamespacePrefix + ":anyURI");
      writer.WriteStartElement("attribute", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("name", "wsdl");
      writer.WriteAttributeString("type", WebNamespace.XmlSchemaNamespacePrefix + ":anyURI");
      writer.WriteEndElement();
      writer.WriteStartElement("attribute", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("name", "operation");
      writer.WriteAttributeString("type", WebNamespace.XmlSchemaNamespacePrefix + ":string");
      writer.WriteEndElement();
      writer.WriteEndElement();//extension
      writer.WriteEndElement();//simpleContent
      writer.WriteEndElement();//complexType
      writer.WriteEndElement();//element
      writer.WriteEndElement();//sequence
    }

    public void VisitFunctionSchema(FunctionSchema s)
    {
        writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", "chan");

        writer.WriteAttributeString("schema", WebNamespace.PiDuceNamespace, "PiDuceChannel");
        writer.WriteAttributeString("capability", WebNamespace.PiDuceNamespace, "O");

        //Our channel encoding
        writer.WriteStartElement("annotation", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("documentation", WebNamespace.XmlSchemaNamespace);
        writer.WriteString("Function schema definition");
        writer.WriteEndElement();
        writer.WriteStartElement("appinfo", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("interface", WebNamespace.PiDuceNamespace);
        writer.WriteAttributeString("xmlns", WebNamespace.XmlSchemaNamespacePrefix, null, WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("xmlns", WebNamespace.PiDuceNamespacePrefix, null, WebNamespace.PiDuceNamespace);
        writer.WriteAttributeString("xmlns", WebNamespace.PiDuceDefaultNamespacePrefix, null, WebNamespace.PiDuceDefaultNamespace);
        writer.WriteAttributeString("targetNamespace", WebNamespace.PiDuceDefaultNamespace);

        writer.WriteStartElement("types", WebNamespace.PiDuceNamespace);
        writer.WriteStartElement("schema", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("xmlns", WebNamespace.XmlSchemaNamespacePrefix, null, WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("xmlns", WebNamespace.PiDuceNamespacePrefix, null, WebNamespace.PiDuceNamespace);
        writer.WriteAttributeString("targetNamespace", targetNamespace);
        writer.WriteAttributeString("elementFormDefault", "qualified");
        WsdlGenerator.WriteSyncOperationSchema(writer, String.Empty, s.Input, s.Output, WebNamespace.PiDuceDefaultNamespace);
        String inputElementName = "In";
        String outputElementName = "Out";
        writer.WriteEndElement();//schema
        writer.WriteEndElement();//types
        writer.WriteStartElement("input", WebNamespace.PiDuceNamespace);
        writer.WriteAttributeString("element", WebNamespace.PiDuceNamespace, WebNamespace.PiDuceDefaultNamespacePrefix + ":" + inputElementName);
        writer.WriteEndElement();//input
        writer.WriteStartElement("output", WebNamespace.PiDuceNamespace);
        writer.WriteAttributeString("element", WebNamespace.PiDuceNamespace, WebNamespace.PiDuceDefaultNamespacePrefix + ":" + outputElementName);
        writer.WriteEndElement();//output
        writer.WriteEndElement();//interface
        
        writer.WriteEndElement();//appinfo
        writer.WriteEndElement();//annotation
        
        //channel encoding for the rest of the world
        writer.WriteStartElement("complexType", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("simpleContent", WebNamespace.XmlSchemaNamespace);
        writer.WriteStartElement("extension", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("base", WebNamespace.XmlSchemaNamespacePrefix + ":anyURI");
        
        writer.WriteStartElement("attribute", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", "wsdl");
        writer.WriteAttributeString("type", WebNamespace.XmlSchemaNamespacePrefix + ":anyURI");
        writer.WriteEndElement();

        writer.WriteStartElement("attribute", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", "operation");
        writer.WriteAttributeString("type", WebNamespace.XmlSchemaNamespacePrefix + ":string");
        writer.WriteEndElement();

        writer.WriteEndElement();//complexType
        writer.WriteEndElement();//simpleContent
        writer.WriteEndElement();//extension
        
        writer.WriteEndElement();//element
        writer.WriteEndElement();//sequence
    }

		public void VisitServiceSchema(ServiceSchema s)
		{
      writer.WriteStartElement("sequence", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("name", "service");
      writer.WriteAttributeString("schema", WebNamespace.PiDuceNamespace, "PiDuceService");

      //Our service encoding
      writer.WriteStartElement("annotation", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("documentation", WebNamespace.XmlSchemaNamespace);
      writer.WriteString("Service schema definition");
      writer.WriteEndElement();
      writer.WriteStartElement("appinfo", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("serviceInterface", WebNamespace.PiDuceNamespace);

      WsdlGenerator.GenerateAbstractWsdl(s, "Service", WebNamespace.PiDuceDefaultNamespace);

      writer.WriteEndElement();//appinfo
      writer.WriteEndElement();//annotation

      //channel encoding for the rest of the world
      writer.WriteStartElement("complexType", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("simpleContent", WebNamespace.XmlSchemaNamespace);
      writer.WriteStartElement("extension", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("base", WebNamespace.XmlSchemaNamespacePrefix + ":anyURI");
      writer.WriteStartElement("attribute", WebNamespace.XmlSchemaNamespace);
      writer.WriteAttributeString("name", "wsdl");
      writer.WriteAttributeString("type", WebNamespace.XmlSchemaNamespacePrefix + ":anyURI");
      writer.WriteEndElement();//attribute
      writer.WriteEndElement();//extension
      writer.WriteEndElement();//simpleContent
      writer.WriteEndElement();//complexType
      writer.WriteEndElement();//element
      writer.WriteEndElement();//sequence
		}

    public void VisitErrorSchema(ErrorSchema s)
    { Debug.Assert(false); }
  }
}
