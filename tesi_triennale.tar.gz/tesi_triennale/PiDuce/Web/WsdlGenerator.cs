// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Xml;
using System.Text;
using System.Collections;
using System.Diagnostics;
using System.Collections.Generic;
using System.IO;
using System.Net;
using PiDuce.Common;
using PiDuce.Types;


namespace PiDuce.Web
{
  public class WsdlGenerationException : Exception
  {
    public WsdlGenerationException(string message)
      : base(message)
    { }
  }
  
  public class WsdlGenerator
  {
    private static string ComputeElementName(LabelledSchema schema)
    {
      if (schema.Labels is WithLabels)
      {
        foreach (string label in schema.Labels.Labels)
          return label;
      }
      else if (schema.Labels is WithoutLabels)
      {
        string labelName = string.Empty;
        foreach (string label in schema.Labels.Labels)
          labelName += label;
        return labelName;
      }
      return string.Empty;
    }

    public static string WriteAsyncOperationSchema(XmlWriter writer, string operation, 
      ISchema inputSchema, string targetNamespace)
    {
      string inputElementName = null;
      //writes constant schema names contained in the input schema
      ConstantSchemaVisitor v = new ConstantSchemaVisitor();
      inputSchema.Accept(v);
      foreach (KeyValuePair<string, ISchema> def in v.Schemas)
        SchemaToXsd.WriteType(def.Key, def.Value, writer, targetNamespace);

      if (inputSchema is LabelledSchema)
      {
        inputElementName = ComputeElementName((LabelledSchema)inputSchema);
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", inputElementName);
        SchemaToXsd.WriteContent(((LabelledSchema)inputSchema).Content, writer, targetNamespace);
        writer.WriteEndElement();
      }
      else if (inputSchema is VoidSchema) { }
      else
      {
        inputElementName = operation + "In";
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", inputElementName);
        SchemaToXsd.WriteContent(inputSchema, writer, targetNamespace);
        writer.WriteAttributeString(WebNamespace.PiDuceNamespacePrefix, "isWrapper", WebNamespace.PiDuceNamespace, "yes");
        writer.WriteEndElement();
      }      
      return inputElementName;
    }

    public static Pair<string, string> WriteSyncOperationSchema(XmlWriter writer, string operation,
      ISchema inputSchema, ISchema outputSchema, string targetNamespace)
    {
      string inputElementName = null;
      string outputElementName = null;

      //writes constant schema names contained in i/o schemas
      ConstantSchemaVisitor v = new ConstantSchemaVisitor();
      inputSchema.Accept(v);
      if (outputSchema != null) outputSchema.Accept(v);
      foreach (KeyValuePair<string, ISchema> def in v.Schemas)
        SchemaToXsd.WriteType(def.Key, def.Value, writer, targetNamespace);
      if (inputSchema is LabelledSchema)
      {
        inputElementName = ComputeElementName((LabelledSchema)inputSchema);
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", inputElementName);
        SchemaToXsd.WriteContent(((LabelledSchema)inputSchema).Content, writer, targetNamespace);
        writer.WriteEndElement();
      }
      else if (inputSchema is VoidSchema) { }
      else
      {
        inputElementName = operation + "In";
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", inputElementName);
        writer.WriteAttributeString(WebNamespace.PiDuceNamespacePrefix, "isWrapper", WebNamespace.PiDuceNamespace, "yes");
        SchemaToXsd.WriteContent(inputSchema, writer, targetNamespace);
        writer.WriteEndElement();
      }
      if (outputSchema is LabelledSchema)
      {
        outputElementName = ComputeElementName((LabelledSchema)outputSchema);
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", outputElementName);
        SchemaToXsd.WriteContent(((LabelledSchema)outputSchema).Content, writer, targetNamespace);
        writer.WriteEndElement();
      }
      else if (outputSchema is VoidSchema) { }
      else
      {
        outputElementName = operation + "Out";
        writer.WriteStartElement("element", WebNamespace.XmlSchemaNamespace);
        writer.WriteAttributeString("name", outputElementName);
        writer.WriteAttributeString(WebNamespace.PiDuceNamespacePrefix, "isWrapper", WebNamespace.PiDuceNamespace, "yes");
        SchemaToXsd.WriteContent(outputSchema, writer, targetNamespace);
        writer.WriteEndElement();
      }
      return new Pair<string, string>(inputElementName, outputElementName);
    }

    public static string GenerateAbstractWsdl(ServiceSchema serviceSchema, string portTypeName, string targetNamespace)
    {
      StringWriter sw = new StringWriter();
      XmlTextWriter wsdl = new XmlTextWriter(sw);
      wsdl.Formatting = Formatting.Indented;
      wsdl.WriteRaw("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
      wsdl.WriteStartElement("wsdl", "definitions", WebNamespace.WsdlNamespace);
      wsdl.WriteAttributeString("xmlns", WebNamespace.WsdlSoapNamespacePrefix, null, WebNamespace.WsdlSoapNamespace);
      wsdl.WriteAttributeString("xmlns", WebNamespace.XmlSchemaNamespacePrefix, null, WebNamespace.XmlSchemaNamespace);
      wsdl.WriteAttributeString("xmlns", WebNamespace.WsdlNamespacePrefix, null, WebNamespace.WsdlNamespace);
      wsdl.WriteAttributeString("xmlns", WebNamespace.PiDuceNamespacePrefix, null, WebNamespace.PiDuceNamespace);
      wsdl.WriteAttributeString("xmlns", WebNamespace.PiDuceValueNamespacePrefix, null, WebNamespace.PiDuceValueNamespace);
      wsdl.WriteAttributeString("xmlns", WebNamespace.PiDuceDefaultNamespacePrefix, null, WebNamespace.PiDuceDefaultNamespace);
      wsdl.WriteAttributeString("xmlns", "tns", null, targetNamespace);
      wsdl.WriteAttributeString("targetNamespace", targetNamespace);

      //WSDL Types
      wsdl.WriteStartElement("types", WebNamespace.WsdlNamespace);
      wsdl.WriteStartElement("schema", WebNamespace.XmlSchemaNamespace);
      wsdl.WriteAttributeString("xmlns", WebNamespace.XmlSchemaNamespacePrefix, null, WebNamespace.XmlSchemaNamespace);
      wsdl.WriteAttributeString("xmlns", WebNamespace.PiDuceNamespacePrefix, null, WebNamespace.PiDuceNamespace);
      wsdl.WriteAttributeString("targetNamespace", targetNamespace);
      wsdl.WriteAttributeString("elementFormDefault", "qualified");

      IDictionary<string, Object> operationSchemaNames = new Dictionary<string, Object>();
      foreach (KeyValuePair<string, ISchema> operation in serviceSchema.Operations)
      {
        string operationName = operation.Key;
        ISchema operationSchema = operation.Value;
        if (operationSchema is ChannelSchema)
        {
          ISchema inputSchema = ((ChannelSchema)operationSchema).Content;
          operationSchemaNames[operationName] = WriteAsyncOperationSchema(wsdl, operationName, inputSchema, targetNamespace);
        }
        else 
        {
          Debug.Assert(operationSchema is FunctionSchema);
          ISchema inputSchema = ((FunctionSchema)operationSchema).Input;
          ISchema outputSchema = ((FunctionSchema)operationSchema).Output;
          operationSchemaNames[operationName] = WriteSyncOperationSchema(wsdl, operationName, inputSchema, outputSchema, targetNamespace);
        }
      }
      wsdl.WriteEndElement();//schema
      wsdl.WriteEndElement();//types

      foreach (KeyValuePair<string, ISchema> o in serviceSchema.Operations)
      {
        string name = o.Key;
        ISchema operationSchema = o.Value;
        ISchema inputSchema;
        string inputElementName;
        //WSDL Messages
        //input message
        if (operationSchema is ChannelSchema)
        {
          inputSchema = ((ChannelSchema)operationSchema).Content;
          inputElementName = (string)operationSchemaNames[name];
        }
        else
        {
          Debug.Assert(operationSchema is FunctionSchema);
          inputSchema = ((FunctionSchema)operationSchema).Input;
          inputElementName = ((Pair<string,string>)operationSchemaNames[name]).First;
        }

        wsdl.WriteStartElement("message", WebNamespace.WsdlNamespace);
        wsdl.WriteAttributeString("name", name + "In");
        if (!(inputSchema is VoidSchema))
        {
          wsdl.WriteStartElement("part", WebNamespace.WsdlNamespace);
          wsdl.WriteAttributeString("name", "par");
          wsdl.WriteAttributeString("element", "tns:" + inputElementName);
          wsdl.WriteEndElement();//</part>
        }
        wsdl.WriteEndElement();//</message>
        //output message
        if (operationSchema is FunctionSchema)
        {
          ISchema outpuSchema = ((FunctionSchema)operationSchema).Output;
          wsdl.WriteStartElement("message", WebNamespace.WsdlNamespace);
          wsdl.WriteAttributeString("name", name + "Out");
          if (!(outpuSchema is VoidSchema))
          {
            wsdl.WriteStartElement("part", WebNamespace.WsdlNamespace);
            wsdl.WriteAttributeString("name", "res");
            string outputElementName = ((Pair<string, string>)operationSchemaNames[name]).Second;
            wsdl.WriteAttributeString("element", "tns:" + outputElementName);
            wsdl.WriteEndElement();//</part>
          }
          wsdl.WriteEndElement();//</message>
        }
      }

      //WSDL PortType
      wsdl.WriteStartElement("portType", WebNamespace.WsdlNamespace);
      if (portTypeName.LastIndexOf("/") > 0)
        portTypeName = portTypeName.Remove(0, portTypeName.LastIndexOf("/")+1);
      wsdl.WriteAttributeString("name", portTypeName);
      foreach (KeyValuePair<string, ISchema> operation in serviceSchema.Operations)
      {
        string operationName = operation.Key;
        ISchema operationSchema = operation.Value;
        wsdl.WriteStartElement("operation", WebNamespace.WsdlNamespace);
        wsdl.WriteAttributeString("name", operationName);
        if (operationSchema is ChannelSchema)
        {
          string capability = "O";
          if (((ChannelSchema)operationSchema).Capability == ChannelType.CAPABILITY.IN)
            capability = "I";
          else if (((ChannelSchema)operationSchema).Capability == ChannelType.CAPABILITY.INOUT)
            capability = "IO";
          wsdl.WriteAttributeString("capability", WebNamespace.PiDuceNamespace, capability);
        }

        wsdl.WriteStartElement("input", WebNamespace.WsdlNamespace);
        wsdl.WriteAttributeString("message", "tns:" + operationName + "In");
        wsdl.WriteEndElement();

        if (operationSchema is FunctionSchema)
        {
          wsdl.WriteStartElement("output", WebNamespace.WsdlNamespace);
          wsdl.WriteAttributeString("message", "tns:" + operationName + "Out");
          wsdl.WriteEndElement();
        }
        wsdl.WriteEndElement();//</operation>
      }
      wsdl.WriteEndElement(); //</portType>
      wsdl.WriteEndElement(); //<definitions>
      return sw.ToString();
    }

    public static string Generate(ServiceSchema serviceSchema, string portTypeName, string targetNamespace, string localAddress)
    {
      string abstractWsdl = GenerateAbstractWsdl(serviceSchema, portTypeName, targetNamespace);
      int indexOfLastTag = abstractWsdl.LastIndexOf('<');
      string endTag = abstractWsdl.Substring(indexOfLastTag, abstractWsdl.Length - indexOfLastTag);
      abstractWsdl = abstractWsdl.Substring(0, indexOfLastTag);
      StringWriter sw = new StringWriter(new StringBuilder(abstractWsdl));
      XmlTextWriter wsdl = new XmlTextWriter(sw);
      //WSDL Binding (a soap binding over http)
      wsdl.WriteStartElement("binding", WebNamespace.WsdlNamespace);
      wsdl.WriteAttributeString("name", "ServiceSoap");
      wsdl.WriteAttributeString("type", "tns:" + portTypeName);
      wsdl.WriteStartElement("binding", WebNamespace.WsdlSoapNamespace);
      wsdl.WriteAttributeString("style", "document");
      wsdl.WriteAttributeString("transport", "http://schemas.xmlsoap.org/soap/http");
      wsdl.WriteEndElement();

      foreach (KeyValuePair<string, ISchema> operation in serviceSchema.Operations)
      {
        string operationName = operation.Key;
        ISchema operationSchema = operation.Value;
        wsdl.WriteStartElement("operation", WebNamespace.WsdlNamespace);
        wsdl.WriteAttributeString("name", operationName);
        wsdl.WriteStartElement("operation", WebNamespace.WsdlSoapNamespace);
        wsdl.WriteAttributeString("soapAction", localAddress + portTypeName + "/" + operationName);
        wsdl.WriteAttributeString("style", "document");
        wsdl.WriteEndElement();

        wsdl.WriteStartElement("input", WebNamespace.WsdlNamespace);
        wsdl.WriteStartElement("body", WebNamespace.WsdlSoapNamespace);
        wsdl.WriteAttributeString("use", "literal");
        wsdl.WriteEndElement();
        wsdl.WriteEndElement();
        if (operationSchema is FunctionSchema)
        {
          wsdl.WriteStartElement("output", WebNamespace.WsdlNamespace);
          wsdl.WriteStartElement("body", WebNamespace.WsdlSoapNamespace);
          wsdl.WriteAttributeString("use", "literal");
          wsdl.WriteEndElement();
          wsdl.WriteEndElement();
        }
        wsdl.WriteEndElement();//</operation>
      }
      wsdl.WriteEndElement();//</binding>
      
      //WSDL Service
      wsdl.WriteStartElement("service", WebNamespace.WsdlNamespace);
      wsdl.WriteAttributeString("name", portTypeName);
      wsdl.WriteStartElement("port", WebNamespace.WsdlNamespace);
      wsdl.WriteAttributeString("name", portTypeName);
      wsdl.WriteAttributeString("binding", "tns:ServiceSoap");
      wsdl.WriteStartElement("address", WebNamespace.WsdlSoapNamespace);
      if (!portTypeName.StartsWith("http://"))
        wsdl.WriteAttributeString("location", localAddress + portTypeName);
      else //for remote machine
        wsdl.WriteAttributeString("location", portTypeName);
      wsdl.WriteEndElement();
      wsdl.WriteEndElement();
      wsdl.WriteEndElement();
      return sw.ToString() + endTag;
    }
  }
}