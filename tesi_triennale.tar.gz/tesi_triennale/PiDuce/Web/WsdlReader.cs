using System;
using System.Xml;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Collections.Generic;
using PiDuce.Common;
using PiDuce.Types;

namespace PiDuce.Web
{
  public class WsdlImportException : Exception
  {
    public WsdlImportException(string message) : base(message) { }
    public WsdlImportException(string message, Exception innerException)
      : base(message, innerException)
    { }
  }

  public enum WSDLSTYLE { RPC, DOCUMENT }
  public enum WSDLUSE { LITERAL, ENCODED }
  
  public interface IWsdlBinding
  {}

  public class SoapOverHttpBinding : IWsdlBinding
  {
    private string soapAction;
    private WSDLSTYLE inputStyle;
    private WSDLUSE inputUse;
    private WSDLSTYLE outputStyle;
    private WSDLUSE outputUse;

    public SoapOverHttpBinding(string soapAction, WSDLSTYLE inputStyle, WSDLUSE inputUse, WSDLSTYLE outputStyle, WSDLUSE outputUse) 
    {
      this.soapAction = soapAction;
      this.inputStyle = inputStyle;
      this.inputUse = inputUse;
      this.outputStyle = outputStyle;
      this.outputUse = outputUse;
    }

    public string SoapAction
    {
      get { return soapAction; }
      set { soapAction = value; }
    }

    public WSDLSTYLE InputStyle
    {
      get { return inputStyle; }
      set { inputStyle = value; }
    }

    public WSDLUSE InputUse
    {
      get { return inputUse; }
      set { inputUse = value; }
    }

    public WSDLSTYLE OutputStyle
    {
      get { return outputStyle; }
      set { outputStyle = value; }
    }

    public WSDLUSE OutputUse
    {
      get { return outputUse; }
      set { outputUse = value; }
    }

    public override String ToString()
    { return "SoapAction = " + this.SoapAction + " Input Style = " + this.InputStyle + " Input Use = " + this.InputUse + " Output Style = " + this.OutputStyle + " Output Use = " + this.OutputUse; }
  }
 
  public class HttpGetBinding : IWsdlBinding {
    public HttpGetBinding(string name, string location, ISchema schema, string namespaceURI)
    { Debug.Assert(false); }
  }

  public class HttpPostBinding : IWsdlBinding
  {
    public HttpPostBinding(string name, string location, ISchema schema, string namespaceURI)
    { Debug.Assert(false); }
  }

  public class Operation 
  {
    private readonly string name;
    public string Name { get { return name; } }

    private readonly string wsdlLocation;
    public string WsdlLocation { get { return wsdlLocation; } }

    private readonly string chanLocation;
    public string ChanLocation { get { return chanLocation; } }

    private readonly string namespaceUri;
    public string NamespaceUri { get { return namespaceUri; } }

    private readonly ISchema schema;
    public ISchema Schema { get { return schema; } }

    private readonly IWsdlBinding binding;
    public IWsdlBinding Binding { get { return binding; } }

    public Operation(string name, string wsdlLocation, string chanLocation, string namespaceUri, ISchema schema, IWsdlBinding binding)
    {
      this.name = name;
      this.wsdlLocation = wsdlLocation;
      this.chanLocation = chanLocation;
      this.namespaceUri = namespaceUri;
      Debug.Assert(schema is ChannelSchema || schema is FunctionSchema);
      this.schema = schema;
      Debug.Assert(binding is SoapOverHttpBinding);
      this.binding = binding;
    }
  }

  public class AbstractWsdlReader 
  {
    protected static ISchema ReadMessage(XsdToSchema c, XmlNode message, XmlNamespaceManager nsmgr)
    {
      Debug.Assert(message.LocalName == "message");
      ISchema schema = new VoidSchema();
      foreach (XmlNode part in message.SelectNodes("wsdl:part", nsmgr))
      {
        ISchema messageSchema = null;
        if (part.Attributes["element"] != null)
        {
          string value = part.Attributes["element"].Value;
          string ns = part.NamespaceURI;
          if (value.IndexOf(':') != -1)
          {
            ns = part.Attributes["element"].GetNamespaceOfPrefix(value.Substring(0, value.IndexOf(':')));
            value = value.Substring(value.IndexOf(':') + 1);
          }
          XmlQualifiedName qName = new XmlQualifiedName(value, ns);
          messageSchema = c.ElementDefs[qName];
          if (c.UnhandledElementAttributes[qName] != null)
          {
            foreach (XmlAttribute a in c.UnhandledElementAttributes[qName])
            {
              if (a.LocalName == "isWrapper" && a.NamespaceURI == WebNamespace.PiDuceNamespace && a.Value == "yes")
                messageSchema = ((LabelledSchema)c.ElementDefs[qName]).Content;
            }
          }
        }
        else if (part.Attributes["type"] != null)
        {
          string value = part.Attributes["type"].Value;
          string ns = String.Empty;
          if (value.IndexOf(':') != -1)
          {
            ns = part.Attributes["type"].GetNamespaceOfPrefix(value.Substring(0, value.IndexOf(':')));
            value = value.Substring(value.LastIndexOf(':') + 1);
          }
          XmlQualifiedName qName = new XmlQualifiedName(value, ns);
          ILabelSet label = LabelSet.Singleton(part.Attributes["name"].Value);
          messageSchema = new LabelledSchema(label, c.GetSchemaFromName(qName));
        }
        else Debug.Assert(false);
        if (schema is VoidSchema)
          schema = messageSchema;
        else
          schema = new SequenceSchema(schema, messageSchema);
      }
      return schema;
    }

    protected static ServiceSchema ReadPortType(XmlDocument wsdl, XmlNode portTypeNode, XsdToSchema resolver, XmlNamespaceManager nsmgr)
    {
      Debug.Assert(portTypeNode.LocalName == "portType");
      IDictionary<string, ISchema> operations = new Dictionary<string, ISchema>();
      foreach (XmlNode operationDefNode in portTypeNode.SelectNodes("wsdl:operation", nsmgr))
      {
        XmlNode inputMessageNode = null;
        XmlNode outputMessageNode = null;
        bool isReqRespOneWay = true;
        foreach (XmlNode child in operationDefNode.ChildNodes) 
        {
          if (child.LocalName == "input" && child.NamespaceURI == WebNamespace.WsdlNamespace)
            inputMessageNode = child;
          else if (child.LocalName == "output" && child.NamespaceURI == WebNamespace.WsdlNamespace)
          {
            outputMessageNode = child;
            if (inputMessageNode == null) isReqRespOneWay = false;
          }
        }
        if (!isReqRespOneWay) continue; //skip the parsing if the service is not started by the service
        ISchema operationSchema = null;
        ISchema inputSchema = null;
        ISchema outputSchema = null;
        if (inputMessageNode != null)
        {
          string messageName = inputMessageNode.Attributes["message"].Value;
          if (messageName.IndexOf(':') != -1)
            messageName = messageName.Substring(messageName.IndexOf(':') + 1);
          XmlNode messageNode = wsdl.SelectSingleNode("/wsdl:definitions/wsdl:message[@name='" + messageName + "']", nsmgr);
          inputSchema = ReadMessage(resolver, messageNode, nsmgr);
        }
        if (outputMessageNode != null)
        {
          string messageName = outputMessageNode.Attributes["message"].Value;
          if (messageName.IndexOf(':') != -1)
            messageName = messageName.Substring(messageName.IndexOf(':') + 1);
          XmlNode messageNode = wsdl.SelectSingleNode("/wsdl:definitions/wsdl:message[@name='" + messageName + "']", nsmgr);
          outputSchema = ReadMessage(resolver, messageNode, nsmgr);
        }
        if (outputSchema == null)
        {
          string capability = "O";
          if (operationDefNode.Attributes["capability", WebNamespace.PiDuceNamespace] != null)
            capability = operationDefNode.Attributes["capability", WebNamespace.PiDuceNamespace].Value;
          if (capability == "IO")
            operationSchema = new ChannelSchema(inputSchema, ChannelType.CAPABILITY.INOUT);
          else if (capability == "I")
            operationSchema = new ChannelSchema(inputSchema, ChannelType.CAPABILITY.IN);
          else if (capability == "O")
            operationSchema = new ChannelSchema(inputSchema, ChannelType.CAPABILITY.OUT);
        }
        else if (outputSchema != null && inputSchema != null)
          operationSchema = new FunctionSchema(inputSchema, outputSchema);
        else Debug.Assert(false);
        operations[operationDefNode.Attributes["name"].Value] = operationSchema;
      }
      return new ServiceSchema(operations);
    }

    public static ServiceSchema CompileAbstractWsdl(string wsdl)
    {
      XsdToSchema foo;
      return CompileAbstractWsdl(wsdl, out foo);
    }

    public static ServiceSchema CompileAbstractWsdl(string wsdl, out XsdToSchema converter)
    { 
      XmlDocument doc = new XmlDocument();
      doc.LoadXml(wsdl);
      return CompileAbstractWsdl(doc, out converter);
    }

    public static ServiceSchema CompileAbstractWsdl(Stream wsdl)
    {
      XsdToSchema foo;
      return CompileAbstractWsdl(wsdl, out foo);
    }

    public static ServiceSchema CompileAbstractWsdl(Stream wsdl, out XsdToSchema converter)
    { 
      XmlDocument doc = new XmlDocument();
      doc.Load(wsdl);
      return CompileAbstractWsdl(doc, out converter);
    }

    public static ServiceSchema CompileAbstractWsdl(XmlDocument wsdl, out XsdToSchema converter)
    {
      try
      {
        XmlNamespaceManager nsmgr = WebNamespace.MakeDefaultXmlNamespaceManager(wsdl.NameTable);
        nsmgr.AddNamespace("tns", wsdl.SelectSingleNode("/wsdl:definitions/@targetNamespace", nsmgr).Value);
        XmlElement schemaNode = (XmlElement)wsdl.SelectSingleNode("/wsdl:definitions/wsdl:types/xsd:schema", nsmgr);
        string schemaTargetNamespace = wsdl.SelectSingleNode("wsdl:definitions/wsdl:types/xsd:schema/@targetNamespace", nsmgr).Value;
        converter = new XsdToSchema(new XmlNodeReader(schemaNode));
        try
        { converter.Compile(); }
        catch (Exception e)
        { throw new WsdlImportException(converter.Output.ToString(), e); }
        XmlNode portDefNode = wsdl.SelectSingleNode("/wsdl:definitions/wsdl:portType", nsmgr);
        return ReadPortType(wsdl, portDefNode, converter, nsmgr);
      }
      catch (Exception e)
      {
        throw new WsdlImportException("An error occured reading the wsdl", e);
      }
    }
  }

  public class WsdlReader : AbstractWsdlReader
  {
    //portType -> operationS -> bindingS
    private IDictionary<string, IDictionary<string, IList<Operation>>> portTypes = new Dictionary<string, IDictionary<string, IList<Operation>>>() ;

    public ServiceSchema Compile(Stream wsdl, string wsdlLocation)
    {
      XsdToSchema foo;
      return Compile(wsdl, wsdlLocation, out foo);
    }

    public ServiceSchema Compile(Stream wsdl, string wsdlLocation, out XsdToSchema converter) 
    {
      XmlDocument doc = new XmlDocument();
      doc.Load(wsdl);
      return Compile(doc, wsdlLocation, out converter);
    }

    public ServiceSchema Compile(string wsdl, string wsdlLocation, out XsdToSchema converter)
    {
      XmlDocument doc = new XmlDocument();
      doc.Load(new StringReader(wsdl));
      return Compile(doc, wsdlLocation, out converter);
    }

    public ServiceSchema Compile(string wsdl, string wsdlLocation)
    {
      XsdToSchema foo;
      return Compile(wsdl, wsdlLocation, out foo);
    }

    public ServiceSchema Compile(XmlDocument wsdl, string wsdlLocation, out XsdToSchema converter)
    {
      try
      {
        XmlNamespaceManager nsmgr = WebNamespace.MakeDefaultXmlNamespaceManager(wsdl.NameTable);
        nsmgr.AddNamespace("tns", wsdl.SelectSingleNode("/wsdl:definitions/@targetNamespace", nsmgr).Value);
        XmlElement schemaNode = (XmlElement)wsdl.SelectSingleNode("/wsdl:definitions/wsdl:types/xsd:schema", nsmgr);
        string schemaTargetNamespace = wsdl.SelectSingleNode("wsdl:definitions/wsdl:types/xsd:schema/@targetNamespace", nsmgr).Value;
        converter = new XsdToSchema(new XmlNodeReader(schemaNode));
        try
        { converter.Compile(); }
        catch (Exception e)
        { throw new WsdlImportException(converter.Output.ToString(), e); }
        XmlNodeList serviceNodeList = wsdl.SelectNodes("/wsdl:definitions/wsdl:service", nsmgr);

        foreach (XmlNode serviceNode in serviceNodeList)
        {
          WSDLSTYLE operationInStyle = WSDLSTYLE.DOCUMENT;
          WSDLSTYLE operationOutStyle = WSDLSTYLE.DOCUMENT;
          WSDLUSE operationInUse = WSDLUSE.LITERAL;
          WSDLUSE operationOutUse = WSDLUSE.LITERAL;
          string portName = serviceNode.SelectSingleNode("wsdl:port", nsmgr).Attributes["name"].Value;
          portTypes[portName] = new Dictionary<string, IList<Operation>>();
          string operationLocation = serviceNode.SelectSingleNode("wsdl:port/soap:address", nsmgr).Attributes["location"].Value;
          string bindingName = serviceNode.SelectSingleNode("wsdl:port", nsmgr).Attributes["binding"].Value;
          if (bindingName.IndexOf(':') != -1)
            bindingName = bindingName.Substring(bindingName.IndexOf(':') + 1);
          XmlNode bindingNode = wsdl.SelectSingleNode("/wsdl:definitions/wsdl:binding[@name='" + bindingName + "']", nsmgr);
          XmlNode httpBindingNode = bindingNode.SelectSingleNode("http:binding", nsmgr);
          XmlNode soapBindingNode = bindingNode.SelectSingleNode("soap:binding", nsmgr);
          if (httpBindingNode != null)
          {
            if (httpBindingNode.Attributes["verb"].Value.Equals("GET", StringComparison.OrdinalIgnoreCase))
            {
              //ParseHttpGetBinding(httpBindingNode);
              throw new WsdlImportException("Http bindings are not supported");
            }
            else if (httpBindingNode.Attributes["verb"].Value.Equals("POST", StringComparison.OrdinalIgnoreCase))
            {
              //ParseHttpPostBinding(httpBindingNode);
              throw new WsdlImportException("Http bindings are not supported");
            }
            else throw new WsdlImportException("Invalid Http binding (it must be either GET or POST)");
          }
          else if (soapBindingNode != null)
          {
            if (soapBindingNode.Attributes["transport"] == null)
            { throw new WsdlImportException("Invalid SOAP binding (transport attribute is missing)"); }
            else if (soapBindingNode.Attributes["transport"].Value != "http://schemas.xmlsoap.org/soap/http")
            { throw new WsdlImportException("Invalid transport protocol for Soap (only http is admitted)"); }

            if (soapBindingNode.Attributes["style"] != null)
            {
              if (soapBindingNode.Attributes["style"].Value == "document")
              { operationInStyle = operationOutStyle = WSDLSTYLE.DOCUMENT; }
              else if (soapBindingNode.Attributes["style"].Value == "rpc")
              { operationInStyle = operationOutStyle = WSDLSTYLE.RPC; }
              else { throw new WsdlImportException("Invalid style (only document or rpc are admitted)"); }
            }
            if (soapBindingNode.Attributes["use"] != null)
            {
              if (soapBindingNode.Attributes["use"].Value == "literal")
              { operationInUse = operationOutUse = WSDLUSE.LITERAL; }
              else if (soapBindingNode.Attributes["use"].Value == "encoded")
              { operationInUse = operationOutUse = WSDLUSE.ENCODED; }
              else { throw new WsdlImportException("Invalid use (only literal or encoded are admitted)"); }
            }
            XmlNode portDefNode = wsdl.SelectSingleNode("/wsdl:definitions/wsdl:portType[@name='" + portName + "']", nsmgr);
            //patch only for microsoft MSN WS
            if (portDefNode == null)
            { portDefNode = wsdl.SelectSingleNode("/wsdl:definitions/wsdl:portType[@name='" + portName + "Type']", nsmgr); }
            ServiceSchema portTypeSchema = ReadPortType(wsdl, portDefNode, converter, nsmgr);
            XmlNodeList operationList = bindingNode.SelectNodes("wsdl:operation", nsmgr);
            foreach (XmlNode operationNode in operationList)
            {
              string operationName = operationNode.Attributes["name"].Value;
              //if the operation has not been imported (it is either solicit-response or notification)
              //the concrete part is also skipped
              if (!portTypeSchema.Operations.ContainsKey(operationName))
                continue;

              string operationSoapAction = null;
              foreach (XmlNode node in operationNode.ChildNodes)
              {
                if (node.LocalName == "operation" && node.NamespaceURI == WebNamespace.WsdlSoapNamespace)
                {
                  operationSoapAction = node.Attributes["soapAction"].Value;
                  if (node.Attributes["style"] != null)
                  {
                    if (node.Attributes["style"].Value == "document")
                    { operationInStyle = operationOutStyle = WSDLSTYLE.DOCUMENT; }
                    if (node.Attributes["style"].Value == "rpc")
                    { operationInStyle = operationOutStyle = WSDLSTYLE.RPC; }
                  }
                  if (node.Attributes["use"] != null)
                  {
                    if (node.Attributes["use"].Value == "literal")
                    { operationInUse = operationOutUse = WSDLUSE.LITERAL; }
                    if (node.Attributes["use"].Value == "encoded")
                    { operationInUse = operationOutUse = WSDLUSE.ENCODED; }
                  }
                }
                else if ((node.LocalName == "input") && (node.NamespaceURI == WebNamespace.WsdlNamespace))
                {
                  if (node.ChildNodes[0].Attributes["style"] != null)
                  {
                    if (node.ChildNodes[0].Attributes["style"].Value == "document")
                    { operationInStyle = WSDLSTYLE.DOCUMENT; }
                    else if (node.ChildNodes[0].Attributes["style"].Value == "rpc")
                    { operationInStyle = WSDLSTYLE.RPC; }
                    else { throw new WsdlImportException("Invalid style (only document or rpc are admitted)"); }
                  }
                  if (node.ChildNodes[0].Attributes["use"] != null)
                  { 
                    if (node.ChildNodes[0].Attributes["use"].Value == "literal")
                    { operationInUse = WSDLUSE.LITERAL; }
                    else if (node.ChildNodes[0].Attributes["use"].Value == "encoded")
                    { operationInUse = WSDLUSE.ENCODED; }
                    else { throw new WsdlImportException("Invalid use (only literal or encoded are admitted)"); }
                  }
                }
                else if ((node.LocalName == "output") && (node.NamespaceURI == WebNamespace.WsdlNamespace))
                {
                  if (node.ChildNodes[0].Attributes["style"] != null)
                  {
                    if (node.ChildNodes[0].Attributes["style"].Value == "document")
                    { operationOutStyle = WSDLSTYLE.DOCUMENT; }
                    else if (node.ChildNodes[0].Attributes["style"].Value == "rpc")
                    { operationOutStyle = WSDLSTYLE.RPC; }
                    else { throw new WsdlImportException("Invalid style (only document or rpc are admitted)"); }
                  }
                  if (node.ChildNodes[0].Attributes["use"] != null)
                  {
                    if (node.ChildNodes[0].Attributes["use"].Value == "literal")
                    { operationOutUse = WSDLUSE.LITERAL; }
                    else if (node.ChildNodes[0].Attributes["use"].Value == "encoded")
                    { operationOutUse = WSDLUSE.ENCODED; }
                    else { throw new WsdlImportException("Invalid use (only literal or encoded are admitted)"); }
                  }
                }
              }
              portTypes[portName][operationName] = new List<Operation>();
              ISchema operationSchema = portTypeSchema.Operations[operationName];
              IWsdlBinding shBinding = new SoapOverHttpBinding(operationSoapAction, operationInStyle, operationInUse, operationOutStyle, operationOutUse);
              Operation operation = new Operation(operationName, wsdlLocation, operationLocation, schemaTargetNamespace, operationSchema, shBinding);
              portTypes[portName][operationName].Add(operation);
            }
          }
        }
        return this.ServiceSchema;
      }
      catch (Exception e)
      {
        throw new WsdlImportException("An error occured reading the wsdl", e);
      }
    }

    public Operation GetOperation(string operationName)
    {
      foreach (IDictionary<string, IList<Operation>> operations in portTypes.Values)
      {
          foreach (Operation operation in operations[operationName])
            return operation;
      }
      Debug.Assert(false, "the specified operation does not exist");
      return null;
    }

    public IDictionary<string, Operation> Operations
    {
      get
      {
        IDictionary<string, Operation> operations = new Dictionary<string, Operation>();
        foreach (IDictionary<string, IList<Operation>> operation in portTypes.Values)
        {
          foreach (string name in operation.Keys) 
            operations[name] = GetOperation(name);
        }
        return operations;
      }
    }

    public ServiceSchema ServiceSchema
    {
      get
      {
        IDictionary<string, ISchema> operations = new Dictionary<string, ISchema>();
        foreach (Operation operation in Operations.Values)
        {
          operations[operation.Name] = operation.Schema;
        }
        return new ServiceSchema(operations);
      }
    }

  }
}
