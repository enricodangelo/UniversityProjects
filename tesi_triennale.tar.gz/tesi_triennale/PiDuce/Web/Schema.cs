using System;
using System.Collections.Generic;
using System.Text;
using PiDuce.Common;
using System.Xml;
using System.Diagnostics;

namespace PiDuce.Web
{
  public class AllSchema : SequenceSchema 
  {
    public AllSchema(ISchema head, ISchema tail)
      : base(head, tail)
    { }

    public IList<string> GetElementLabelSet()
    {
      List<string> labels = new List<string>();
      GetElementLabelSetAux(this, labels);
      return labels;
    }

    private void GetElementLabelSetAux(ISchema schema, List<string> labels) 
    {
      if (schema is LabelledSchema)
      {
        WithLabels s = (WithLabels)((LabelledSchema)schema).Labels;
        string label = "";
        foreach (string l in s.Labels)
        {
          label = l;
        }
        labels.Add(label);
      }
      else if (schema is SequenceSchema)
      {
        GetElementLabelSetAux(((SequenceSchema)schema).Head, labels);
        GetElementLabelSetAux(((SequenceSchema)schema).Tail, labels);
      }
      else if (schema is RepetitionSchema)
      {
        GetElementLabelSetAux(((RepetitionSchema)schema).Content, labels);
      }
      else Debug.Assert(false, "only labelled elements are admitted in xsd:all");
    }
  }
 
  public interface IArraySchema
  {
    XmlQualifiedName Name { get; }
    ISchema Content { get; }
  }

  public class ArraySchemaUtil
  {
    public static bool IsArraySchema(ISchema schema)
    {
      if (schema is IArraySchema) return true;
      else if (schema is ConstantSchema)
        return IsArraySchema(((ConstantSchema)schema).Entry.Schema);
      else if (schema is LabelledSchema)
        return IsArraySchema(((LabelledSchema)schema).Content);
      else return false;
    }
    private static string BoundariesAux(ISchema schema)
    {
      StringBuilder s = new StringBuilder();
      if (schema is BasicSchema)
      {
        BasicSchema basic = (BasicSchema)schema;
        switch (basic.Type.Kind)
        {
          case BasicTypeKind.BOOL:
            s.Append(WebNamespace.XmlSchemaNamespacePrefix + ":bool");
            break;
          case BasicTypeKind.INT:
            s.Append(WebNamespace.XmlSchemaNamespacePrefix + ":int");
            break;
          case BasicTypeKind.FLOAT:
            s.Append(WebNamespace.XmlSchemaNamespacePrefix + ":float");
            break;
          case BasicTypeKind.STRING:
            s.Append(WebNamespace.XmlSchemaNamespacePrefix + ":string");
            break;
          default: Debug.Assert(false);
            break;
        }
      }
      else if (schema is ConstantSchema && ((ConstantSchema)schema).Entry.Schema is IArraySchema)
      { s.Append(BoundariesAux(((ConstantSchema)schema).Entry.Schema)); }
      else if (schema is ConstantSchema)
      { s.Append(((ConstantSchema)schema).Name); }
      else if (schema is LabelledSchema)
      { s.Append(BoundariesAux(((LabelledSchema)schema).Content)); }
      else if (schema is IArraySchema)
      { s.Append(Boundaries((IArraySchema)schema)); }
      else Debug.Assert(false);
      return s.ToString();
    }

    public static string Boundaries(IArraySchema schema)
    {
      StringBuilder s = new StringBuilder();
      if (schema.Content is IArraySchema)
        s.Append(Boundaries((IArraySchema)schema.Content));
      else s.Append(BoundariesAux(schema.Content));
      if (schema is ArrayStarSchema)
        s.Append("[]");
      else if (schema is ArrayRepetitionSchema)
        s.Append("["+ ((ArrayRepetitionSchema)schema).MinOccurs + "]");
      return s.ToString();
    }
  }

  public class ArrayStarSchema : StarSchema, IArraySchema
  {
    private XmlQualifiedName name;
    public XmlQualifiedName Name { 
      get { return name; } 
    }

    public ArrayStarSchema(XmlQualifiedName name, ISchema content) : base(content) 
    { this.name = name; }

    public ISchema Content { get { return base.Content; } }
    }

  public class ArrayRepetitionSchema : RepetitionSchema, IArraySchema 
  {
    private XmlQualifiedName name;
    public XmlQualifiedName Name { get { return name; } }

    public ArrayRepetitionSchema(XmlQualifiedName name, ISchema content, uint occurs) 
      : base(content, occurs, occurs)
    { this.name = name; }

    public ISchema Content { get { return base.Content; } }
  }
}
