using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Xml;
using PiDuce.Common;
using PiDuce.Web;
using PiDuce.Compiler;

namespace PiDuce.Wsdl2PiDuce
{
  /// <summary>
  /// This utility allows to read remote WSDL files producing a PiDuce prototype file.
  /// Such a prototype is just a sequence of "import" directives.
  /// </summary>
  public class Wsdl2PiDuce
  {
    private static string usage =
@"Wsdl2PiDuce - Usage: Wsdl2PiDuce [WSDLFILE]s -o [OUTPUTFILE]
  WSDLFILE are generic URI http://..., https://..., file://..., ftp://..., ecc.";
    /// <summary>
    /// Allows to import a list of WSDL files producing the correspondent PiDuce prototype.
    /// The resulting code is written to a file.
    /// </summary>
    /// <param name="args">Usage: Wsdl2PiDuce [WSDLFILE]s -o [OUTPUTFILE]</param>
    public static void Main(string[] args)
    {
      if (args.Length < 2)
      {
        Console.WriteLine(Wsdl2PiDuce.usage);
        return;
      }
      else if (args[args.Length - 2] != "-o")
      {
        Console.WriteLine(Wsdl2PiDuce.usage);
        return;
      }
      else
      {
        string outFileName = args[args.Length - 1];
        if (File.Exists(outFileName))
        {
          string answer = "n";
          Console.WriteLine(outFileName + " already exists. Do you want to overwrite it? (y/n) - Default is [N]");
          answer = Console.In.ReadLine().Trim();
          if ("n".Equals(answer, StringComparison.OrdinalIgnoreCase))
            return;
        }
        WebClient wc = new WebClient();
        StringBuilder s = new StringBuilder();
        s.AppendLine("//Automatically generated code");
        for (int i = 0; i < args.Length - 2; i++)
        {
          string wsdl = args[i];
          try
          {
            XsdToSchema xsd = null;
            ServiceSchema schema = null;
            string name = null;
            if (File.Exists(wsdl))
            {
              schema = AbstractWsdlReader.CompileAbstractWsdl(File.OpenRead(wsdl), out xsd);
              char[] separators = { '.', '?' };
              name = Path.GetFileName(wsdl).Split(separators)[0];
            }
            else
            {
              Uri u = new Uri(wsdl);
              if (u.IsFile)
                schema = AbstractWsdlReader.CompileAbstractWsdl(File.OpenRead(u.AbsolutePath), out xsd);
              else
              {
                wc.DownloadData(wsdl);
                schema = AbstractWsdlReader.CompileAbstractWsdl(wc.OpenRead(wsdl), out xsd);
              }
              char[] separators = { '.', '?' };
              name = Path.GetFileName(u.LocalPath).Split(separators)[0];
            }
            Console.WriteLine(xsd.Output);
            if (xsd.SchemaDefs.Count > 0)
              s.Append("schema ");
            //complex type definitions
            foreach (KeyValuePair<XmlQualifiedName, ConstantSchema> kv in xsd.SchemaDefs)
            {
              ToStringSchemaVisitor visitor = new ToStringSchemaVisitor();
              kv.Value.Entry.Schema.Accept(visitor);
              s.AppendLine(kv.Key.Name + "=" + visitor + " ");
              s.Append("and ");
            }
            if (xsd.SchemaDefs.Count > 0)
              s.Replace("and ", "", s.Length - 4, 4);
            if (xsd.SchemaDefs.Count > 0)
              s.Append("in ");
            if (schema.Operations.Count > 0)
            {
              s.Append("import ");
              s.Append(name + " ");
              s.Append(schema);
            }
            s.AppendLine(System.Environment.NewLine + " location=\"" + wsdl + "\"");
            s.AppendLine("in");
            Console.WriteLine(wsdl + " imported");
          }
          catch (WebException)
          {
            Console.WriteLine(wsdl + " - cannot be downloaded");
          }
          catch (XmlException)
          {
            Console.WriteLine(wsdl + " - errors reading the wsdl description");
          }
          catch (Exception e)
          {
            Console.WriteLine(wsdl + " - cannot be read " + e);
          }
        }
        s.AppendLine(@" nil //replace - nil - with your code!");
        FileStream f;
        if (!File.Exists(outFileName))
          f = File.Create(outFileName);
        else f = File.Open(outFileName, FileMode.Truncate);
        StreamWriter sw = new StreamWriter(f);
        sw.Write(s.ToString());
        sw.Close();
      }
    }
  }
}