,ppc8540_retire")

;; Stores.
(define_insn_reservation "ppc8540_store" 3
  (and (eq_attr "type" "store,store_ux,store_u")
       (eq_attr "cpu" "ppc8540"))
  "ppc8540_decode,ppc8540_issue+ppc8540_lsu,nothing,ppc8540_retire")

;; Simple FP
(define_insn_reservation "ppc8540_simple_float" 1
  (and (eq_attr "type" "fpsimple")
       (eq_attr "cpu" "ppc8540"))
  "ppc8540_decode,ppc8540_issue+ppc8540_su_stage0+ppc8540_retire")

;; FP
(define_insn_reservatio