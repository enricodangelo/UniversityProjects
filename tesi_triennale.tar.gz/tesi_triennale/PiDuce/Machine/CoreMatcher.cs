// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using PiDuce.Types;
using PiDuce.Common; 

using IPatternType = PiDuce.Common.IType;
using IPatternSchema = PiDuce.Common.ISchema;

namespace PiDuce.Machine
{
	public interface IMatcher
	{
		int Match(IValue v, Env env);
	}

	public class NoMatch : Exception
	{ public NoMatch(String message) : base("No match: " + message) { } }

	public class MatcherFactory
	{
		public static int REPEAT = 1;

		public static void PrintElapsed(DateTime t0, DateTime t1)
		{
#if false
			Console.WriteLine("start = {0} end = {1}", t0, t1);
			Console.WriteLine("elapsed for {0} matches: {1}", MatcherFactory.REPEAT, new TimeSpan(t1.Ticks - t0.Ticks).TotalSeconds);

#endif
		}

		public static IMatcher Make(IPatternSchema pattern)
		{
			IList<IPatternSchema> patterns = new List<IPatternSchema>();
			patterns.Add(pattern);
			return Make(patterns);
		}

		public static IMatcher Make(IList<IPatternSchema> patterns)
		{
			SchemaToTypeVisitor converter = new MachineSchemaToTypeVisitor();
			IList<IPatternType> p = new List<IPatternType>();
			foreach (IPatternSchema pattern in patterns)
				p.Add(converter.SchemaToType(pattern));
#if NAIVE_CORE_MATCHER
			return new NaiveCoreMatcher(p);
#elif SMART_CORE_MATCHER
			return new SmartCoreMatcher(p);
#elif NAIVE_FULL_MATCHER
			return new NaiveFullMatcher(p);
#elif SMART_FULL_MATCHER
			return new SmartFullMatcher(p);
#else
#error "no matcher defined, check Makefile.common"
#endif
		}
	}

	public class NaiveCoreMatcher : IMatcher
	{
		private readonly IList<IPatternType> patterns;
		private static ITypeChecker typeChecker = new TypeChecker();

		public NaiveCoreMatcher(IList<IPatternType> patterns)
		{ this.patterns = patterns; }

		public static bool Match(IPatternType pattern, IValue v, Env env)
		{
			// the Bind case must come before LabelledType because Bind extends
			// LabelledType (see Type.cs)
			if (pattern is Bind) {
				Bind path = (Bind) pattern;
				if (Match(path.Content, v, env)) {
					Debug.Assert(path.Entry is ValueEntry);
					env.Set(((ValueEntry) path.Entry).Index, v);
					return true;
				} else
					return false;
			} else if (pattern is LabelledType) {
				if (v is LabelValue) {
          LabelledType pat = (LabelledType)pattern; 
					LabelValue val = (LabelValue) v;
					if (pat.Labels.Has(val.Label))
						return Match(pat.Content, val.Content, env);
					else
						return false;
				} else
					return false;
			} else if (pattern is SequenceType) {
        SequenceType pat = (SequenceType) pattern;
				if (v is SequenceValue) {
					SequenceValue val = (SequenceValue) v;
					if (Match(pat.Top, val.Top, env) && Match(pat.Tail, val.Tail, env))
						return true;
				}
				if (Match(pat.Top, new VoidValue(), env) && Match(pat.Tail, v, env))
					return true;
				if (Match(pat.Top, v, env) && Match(pat.Tail, new VoidValue(), env))
					return true;
				return false;
			} else { // Schema
				return typeChecker.IsSubtype(v.TypeOf(), pattern);
			}
		}

		public int Match(IValue v, Env env)
		{
			int res = -1;
			for (int i = 0; i < patterns.Count; i++)
				if (Match(patterns[i], v, env)) {
					res = i;
					break;
				}
			return res;
		}
	}

	public class SmartCoreMatcher : IMatcher
	{
		private IBasicMatcher matcher;

		private enum MatchClass { DONE, BIND, LABEL, SEQ, SCHEMA, MIX }

		public SmartCoreMatcher(IList<IPatternType> patterns)
		{
			matcher = new Matrix(patterns).Compile();
		}

		private interface IBasicMatcher
		{
			int Match(Env env, Cell<IValue> vm, Cell<IValue> v);
			void Dump();
		}

		private class DoneMatch : IBasicMatcher
		{
			private int row;
			private Cell<int> indexes;

			public DoneMatch(int row, Cell<int> indexes)
			{
				this.row = row;
				this.indexes = indexes;
			}

			public void Dump()
			{ Console.WriteLine("<done row=\"{0}\"/>", row); }

			public int Match(Env env, Cell<IValue> vm, Cell<IValue> v)
			{
				Debug.Assert(v == null, "pattern matching ended?");

				Cell<int> p = indexes;
				Cell<IValue> q = vm;
				while (p != null) {
					Debug.Assert(q != null);
					env.Set(p.Content, q.Content);
					p = p.Next;
					q = q.Next;
				}

				return row;
			}
		}

		private class BindMatch : IBasicMatcher
		{
			private IBasicMatcher cont;

			public BindMatch(IBasicMatcher cont)
			{ this.cont = cont; }

			public void Dump()
			{
				Console.WriteLine("<bind>");
				cont.Dump();
				Console.WriteLine("</bind>");
			}

			public int Match(Env env, Cell<IValue> vm, Cell<IValue> v)
			{
				Debug.Assert(v != null);
				return cont.Match(env, new Cell<IValue>(v.Content, vm), v);
			}
		}

		private class SequenceMatch : IBasicMatcher
		{
			private IBasicMatcher cont;

			public SequenceMatch(IBasicMatcher cont)
			{ this.cont = cont; }

			public void Dump()
			{
				Console.WriteLine("<sequence>");
				cont.Dump();
				Console.WriteLine("</sequence>");
			}

			public int Match(Env env, Cell<IValue> vm, Cell<IValue> v)
			{
				if (v.Content is SequenceValue) {
        	SequenceValue vSeq = (SequenceValue) v.Content;
        	return cont.Match(env, vm, new Cell<IValue>(vSeq.Top, new Cell<IValue>(vSeq.Tail, v.Next)));
				} else if (v.Content is LabelValue) {
					return cont.Match(env, vm, new Cell<IValue>(v.Content, new Cell<IValue>(new VoidValue(), v.Next)));
				}

				throw new NoMatch("seq");
			}
		}

		private class BacktrackMatch : IBasicMatcher
		{
			private IBasicMatcher tryBranch;
			private IBasicMatcher catchBranch;

			public BacktrackMatch(IBasicMatcher tryBranch, IBasicMatcher catchBranch)
			{
				this.tryBranch = tryBranch;
				this.catchBranch = catchBranch;
			}

			public void Dump()
			{
				Console.WriteLine("<try>");
				tryBranch.Dump();
				catchBranch.Dump();
				Console.WriteLine("</try>");
			}

			public int Match(Env env, Cell<IValue> vm, Cell<IValue> v)
			{
				try {
					return tryBranch.Match(env, vm, v);
				} catch (NoMatch) {
					return catchBranch.Match(env, vm, v);
				}
			}
		}

		private class LabelMatch : IBasicMatcher
		{
			private ILabelSet labels;
			private IBasicMatcher cont;

			public LabelMatch(ILabelSet labels, IBasicMatcher cont)
			{
				this.labels = labels;
				this.cont = cont;
			}

			public void Dump()
			{
				Console.WriteLine("<label labels=\"{0}\">", labels);
				cont.Dump();
				Console.WriteLine("</label>");
			}

			public int Match(Env env, Cell<IValue> vm, Cell<IValue> v)
			{
				if (v.Content is LabelValue) {
					LabelValue lab = (LabelValue) v.Content;

					if (labels.Includes(new WithLabels(lab.Label)))
						return cont.Match(env, vm, new Cell<IValue>(lab.Content, v.Next));
				}
				throw new NoMatch("label");
			}
		}

		private class SchemaMatch : IBasicMatcher
		{
			private IType schema;
			private IBasicMatcher cont;

			private static ITypeChecker typeChecker = new TypeChecker();

			public SchemaMatch(IType schema, IBasicMatcher cont)
			{
				this.schema = schema;
				this.cont = cont;
			}

			public void Dump()
			{
				Console.WriteLine("<schema type=\"{0}\">", schema);
				cont.Dump();
				Console.WriteLine("</schema>");
			}

			public int Match(Env env, Cell<IValue> vm, Cell<IValue> v)
			{
				Debug.Assert(v != null);
				//Console.WriteLine("checking schema subtype {0} <: {1}", v.Content.TypeOf(), schema);
				if (typeChecker.IsSubtype(v.Content.TypeOf(), schema))
					return cont.Match(env, vm, v.Next);
				else
					throw new NoMatch("schema");
			}
		}

		private class Matrix
		{
			private List<Stack<IPatternType>> content;
			private List<int> rows;
			private List<Cell<int>> envs;

			public Matrix(IList<IPatternType> patterns)
			{
				content = new List<Stack<IPatternType>>();
				rows = new List<int>();
				envs = new List<Cell<int>>();

				for (int i = 0; i < patterns.Count; i++)
					rows.Add(i);

				foreach (IPatternType pat in patterns) {
					Stack<IPatternType> row = new Stack<IPatternType>();
					row.Push(pat);
					content.Add(row);
					envs.Add(null);
				}
			}

			private Matrix(List<Stack<IPatternType>> content, List<int> rows, List<Cell<int>> envs, int first, int last)
			{
				this.content = content.GetRange(first, last - first + 1);
				this.rows = rows.GetRange(first, last - first + 1);
				this.envs = envs.GetRange(first, last - first + 1);
			}

			private void Expand()
			{
				int i = 0;
				while (i < content.Count) {
					Stack<IPatternType> row = content[i];
					if (row.Count == 0)
						break;
	
			  	IPatternType pat = row.Peek();
          if (pat is UnionType)
          {
            UnionType u = (UnionType)pat;
						row.Pop();
						Stack<IPatternType> newRow = new Stack<IPatternType>(row);
						row.Push(u.Fst);
						newRow.Push(u.Snd);
						content.Insert(i, newRow);
						rows.Insert(i, rows[i]);
						envs.Insert(i, envs[i]);
					} else
						i++;
				}
			}

			private void Split(int n, out Matrix prefix, out Matrix rest)
			{
				if (n < content.Count) {
					prefix = new Matrix(content, rows, envs, 0, n - 1);
					rest = new Matrix(content, rows, envs, n, content.Count - 1);
				} else {
					Debug.Assert(n == content.Count);
					prefix = this;
					rest = null;
				}
			}

			public MatchClass Classify(out Matrix prefix, out Matrix rest)
			{
				Expand();

				if (content[0].Count == 0) {
					prefix = this;
					rest = null;
					return MatchClass.DONE;
				}

				MatchClass state = MatchClass.DONE;
				int n = 0;
				bool done = false;
				while (!done && n < content.Count) {
			  	IPatternType pat = content[n].Peek();
			  	switch (state) {
				  	case MatchClass.DONE:
							if (pat is Bind) // BEWARE: Bind before LabelledType
								state = MatchClass.BIND;
              else if (pat is LabelledType)
								state = MatchClass.LABEL;
              else if (pat is SequenceType)
								state = MatchClass.SEQ;
							else
								state = MatchClass.SCHEMA;
							break;
						case MatchClass.SCHEMA:
              if ((pat is LabelledType || pat is SequenceType || pat is Bind))
								done = true;
							else {
								IType t1 = pat;
								IType t2 = content[0].Peek();
								ITypeChecker typeChecker = new TypeChecker();
								done = !(typeChecker.IsSubtype(t1, t2) && typeChecker.IsSubtype(t2, t1));
							}
					  	break;
						case MatchClass.LABEL:
              if (pat is LabelledType)
              {
                ILabelSet set1 = ((LabelledType)pat).Labels;
                ILabelSet set2 = ((LabelledType)(content[0]).Peek()).Labels;
								done = !set1.Includes(set2) || !set2.Includes(set1);
							} else
								done = true;
							break;
						case MatchClass.SEQ:
              done = !(pat is SequenceType);
					  	break;
						case MatchClass.BIND:
							done = !(pat is Bind);
							break;
						default:
							Debug.Assert(false);
							break;
					}

					if (!done) n++;
				}

				Debug.Assert(n > 0, "n > 0");
				Split(n, out prefix, out rest);
				return state;
			}

			private IBasicMatcher CompileBind()
			{
				for (int i = 0; i < content.Count; i++) {
					Stack<IPatternType> row = content[i];
					Debug.Assert(row.Peek() is Bind);
					Bind var = (Bind) row.Pop();
					Debug.Assert(var.Entry is ValueEntry);
					envs[i] = new Cell<int>(((ValueEntry) var.Entry).Index, (Cell<int>) envs[i]);
					row.Push(var.Content);
				}
				return new BindMatch(Compile());
			}

			private IBasicMatcher CompileSeq()
			{
				for (int i = 0; i < content.Count; i++) {
					Stack<IPatternType> row = content[i];
          Debug.Assert(row.Peek() is SequenceType);
          SequenceType seq = (SequenceType)row.Pop();
					row.Push(seq.Tail);
					row.Push(seq.Top);
				}
				return new SequenceMatch(Compile());
			}

			private IBasicMatcher CompileLabel()
			{
        Debug.Assert(content[0].Peek() is LabelledType);
        LabelledType pat = (LabelledType)content[0].Peek();
				for (int i = 0; i < content.Count; i++) {
					Stack<IPatternType> row = content[i];
          Debug.Assert(row.Peek() is LabelledType);
          LabelledType  end;


       {---------------------------------------------------------------}
       { AND Top of Stack with Primary }

       procedure PopAnd;
       begin
          EmitLn('AND (SP)+,D0');
       end;


       {---------------------------------------------------------------}
       { OR Top of Stack with Primary }

       procedure PopOr;
       beginA*2A*
                                    - 53 -
PA2A





          EmitLn('OR (SP)+,D0');
       end;


       {---------------------------------------------------------------}
       { XOR Top of Stack with Primary }

       procedure PopXor;
       begin
          EmitLn('EOR (SP)+,D0');
       end;


       {---------------------------------------------------------------}
       { Compare Top of Stack with Primary }

       procedure PopCompare;
       begin
          EmitLn('CMP (SP)+,D0');
       end;


       {---------------------------------------------------------------}
       { Set D0 If Compare was = }

       procedure SetEqual;
       begin
          EmitLn('SEQ D0');
          EmitLn('EXT D0');
       end;


       {---------------------------------------------------------------}
       { Set D0 If Compare was != }

       procedure SetNEqual;
       begin
     