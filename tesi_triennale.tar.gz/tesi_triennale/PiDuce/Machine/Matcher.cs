// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using PiDuce.Common;
using PiDuce.Types;

using IPattern = PiDuce.Common.ISchema;

namespace PiDuce.Machine
{
	public interface IMatcher
	{
		int Match(IValue v, Env env);
	}

	public class NoMatch : Exception
	{ public NoMatch(String message) : base("No match: " + message) { } }

	public class MatcherFactory : IMatcher
	{
		public static int REPEAT = 1;
		private readonly IList<MatcherAutomaton> matchers;

		public static void PrintElapsed(DateTime t0, DateTime t1)
		{
#if false
			Console.WriteLine("start = {0} end = {1}", t0, t1);
			Console.WriteLine("elapsed for {0} matches: {1}", MatcherFactory.REPEAT, new TimeSpan(t1.Ticks - t0.Ticks).TotalSeconds);

#endif
		}

		private static MatcherAutomaton GetAutomaton(IPattern f)
		{
			MatcherAutomaton nda = MatcherAutomaton.Make(f);
			//Console.WriteLine("NDA\n===");
			nda.Dump();
			MatcherAutomaton da = nda.RemoveVoidTransitions();
			//Console.WriteLine("DA\n==");
			da.Dump();
			return da;
		}

		public static IMatcher Make(IPattern pattern)
		{
			IList<IPattern> patterns = new List<IPattern>();
			patterns.Add(pattern);
			return Make(patterns);
		}

		public static IMatcher Make(IList<IPattern> patterns)
		{
//Console.WriteLine("making matcher for {0} patterns", patterns.Count);
			IList<MatcherAutomaton> matchers = new List<MatcherAutomaton>();
			foreach (IPattern pattern in patterns)
				matchers.Add(GetAutomaton(pattern));
//Console.WriteLine("OK");
			return new MatcherFactory(matchers);
		}

		public MatcherFactory(IList<MatcherAutomaton> matchers)
		{ this.matchers = matchers; }

		public int Match(IValue v, Env env)
		{
			//Console.WriteLine("pattern matching for {0} initiated", v);
			int index = 0;
			SchemaChecker sc = new SchemaChecker();
			ValueCollector vc = new ValueCollector(env);
			foreach (MatcherAutomaton a in matchers) {
				if (a.Match(sc, vc, v)) {
					return index;
				}
				index++;
			}

			return -1;
		}
	}

	// VALUE COLLECTOR
	public class ValueCollector
	{
		private readonly Env env;
		private readonly IDictionary<int, IFlatValue> map;

		public ValueCollector(Env env)
		{ 
			this.env = env;
			this.map = new Dictionary<int, IFlatValue>(); 
		}

		private static IValue Collect(IValue acc, IFlatValue v, IFlatValue end)
		{
			if (Object.ReferenceEquals(v, end))
				return acc;
			else
				return SequenceValue.Make(v.Head, Collect(acc, v.Tail, end));
		}

		public void Begin(int i, IFlatValue v)
		{
			Debug.Assert(map.ContainsKey(i));
			env.Set(i, Collect(new VoidValue(), v, map[i]));
		}

		public void End(int i, IFlatValue v)
		{ map[i] = v; }
	}

	// FLAT VALUES
	public interface IFlatValue
	{
		IValue Head { get; }
		IFlatValue Tail { get; }
	}

	public class FlatValue : IFlatValue
	{
		private readonly IValue head;
		private readonly IFlatValue tail;

		public IValue Head { get { return head; } }
		public IFlatValue Tail { get { return tail; } }

		public FlatValue(IValue head, IFlatValue tail)
		{
			Debug.Assert(!(head is SequenceValue));
			this.head = head;
			this.tail = tail;
		}

		public static string ToString(IFlatValue p)
		{
			StringBuilder builder = new StringBuilder();
			if (p == null)
				return "()";
			while (p != null) {
				builder.Append(p.Head.ToString());
				if (p.Tail != null) builder.Append(",");
				p = p.Tail;
			}
			return builder.ToString();
		}
	}

	// MATCHER AUTOMATON
	public class MatcherAutomaton
	{
		private readonly State initial = new State();
		private readonly State final = new State();

		public State Initial { get { return initial; } }
		public State Final { get { return final; } }

		public MatcherAutomaton(State initial, State final)
		{
			this.initial = initial;
			this.final = final;
		}

		public MatcherAutomaton() : this(new State(), new State())
		{ }

		private ISet<State> Closure(State s)
		{
			ISet<State> res = new ArraySet<State>();
			ISet<State> newSets = new ArraySet<State>();
			newSets.Add(s);
			while (!newSets.IsEmpty()) {
				ISet<State> newReachable = new ArraySet<State>();
				foreach (State state in newSets) {
					res.Add(state);
					foreach (Transition t in state.Moves)
						if (t is VoidTransition && !res.Contains(t.Next))
							newReachable.Add(t.Next);
				}
				newSets = newReachable;
			}
			return res;
		}

		private static IList<ITransition> CollectMoves(ISet<State> ss)
		{
			IList<ITransition> moves = new List<ITransition>();
			foreach (State s in ss)
				s.CollectMoves(moves);
			return moves;
		}

		protected static IFlatValue UnfoldValue(IValue v, IFlatValue continuation)
		{
			Debug.Assert(v != null, "v != null");
			if (v is VoidValue)
				return continuation;
			else if (v is SequenceValue)
				return UnfoldValue(((SequenceValue) v).Top, UnfoldValue(((SequenceValue) v).Tail, continuation));
			else
				return new FlatValue(v, continuation);
		}

		protected static IFlatValue UnfoldValue(IValue v)
		{ return UnfoldValue(v, null); }

		public void Dump()
		{ new AutomatonDumper(this).Dump(); }

		public static MatcherAutomaton Make(IPattern f)
		{
			MatcherAutomaton a = new MatcherAutomaton(new State(), new State(true));
			//Console.WriteLine("IN FOR {0}", f);
			MatcherAutomaton result = new MatcherSchemaVisitor().GetAutomaton(f, a);
			//Console.WriteLine("OUT");
			return result;
		}

		public bool Match(SchemaChecker sc, ValueCollector vc, IValue v)
		{
#if false
Console.WriteLine("=== trying to match {0} against:", v);
Dump();
Console.WriteLine("===");
#endif
			return this.initial.Match(sc, vc, UnfoldValue(v));
		}

		// AUTOMATON DUMPER (FOR DEBUGGING ONLY)
		protected class AutomatonDumper
		{
			private readonly MatcherAutomaton a;
			private int nextIndex;
			private readonly IDictionary<State, int> stateIndex;
			private readonly ISet<State> reached;

			public AutomatonDumper(MatcherAutomaton a)
			{
				this.a = a;
				this.nextIndex = 0;
				this.stateIndex = new Dictionary<State, int>();
				this.reached = new ArraySet<State>();
			}

			public int GetStateIndex(State s)
			{
				int result;
				if (stateIndex.TryGetValue(s, out result))
					return result;
				else {
					result = stateIndex[s] = nextIndex++;
					return result;
				}
			}

			private void DumpTransition(ITransition t)
			{
				int index = GetStateIndex(t.Next);
				if (t is VoidTransition) {
					//Console.WriteLine("  void --> {0}", index);
				} else if (t is AtomicTransition) {
					AtomicTransition at = (AtomicTransition) t;
					//Console.WriteLine("  {0} --> {1}", at.Schema, index);
				} else if (t is LabelledTransition) {
					LabelledTransition lt = (LabelledTransition) t;
					//Console.WriteLine("  {0} --> {1}", lt.Labels, index);
				} else
					Debug.Assert(false);
			}

			private void DumpState(State s)
			{
				int index = GetStateIndex(s);
				//Console.WriteLine("STATE {0} FINAL {1}:", index, s.Final);

				ISet<State> newReachable = new ArraySet<State>();
				foreach (ITransition t in s.Moves) {
					if (!reached.Contains(t.Next)) {
						newReachable.Add(t.Next);
						reached.Add(t.Next);
					}
					DumpTransition(t);
				}

				foreach (State r in newReachable)
					DumpState(r);
			}

			public void Dump()
			{
				reached.Add(a.Initial);
				DumpState(a.Initial);
			}
		}

		protected class MatcherSchemaVisitor : ExpanderSchemaVisitor
		{
			private MatcherAutomaton result;
			private static IDictionary<IEntry, MatcherAutomaton> entryMatcher = new Dictionary<IEntry, MatcherAutomaton>();

			public MatcherAutomaton GetAutomaton(ISchema s, MatcherAutomaton a)
			{
				result = a;
				s.Accept(this);
				return result;
			}

			private MatcherAutomaton GetAutomaton(ISchema s)
			{ return GetAutomaton(s, new MatcherAutomaton()); }

			public override void VisitVoidSchema(VoidSchema s)
			{ result.Initial.AddMove(new VoidTransition(result.Final)); }

			private void AtomicSchema(ISchema s)
			{ result.Initial.AddMove(new AtomicTransition(s, result.Final)); }

			public override void VisitBasicSchema(BasicSchema s)
			{ AtomicSchema(s); }

			public override void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
			{ AtomicSchema(s); }

			public override void VisitLabelledSchema(LabelledSchema s)
			{
				MatcherAutomaton a = result;
				a.Initial.AddMove(new LabelledTransition(s.Labels, MatcherAutomaton.Make(s.Content), a.Final));
				result = a;
			}

			public override void VisitSequenceSchema(SequenceSchema s)
			{
				MatcherAutomaton a = result;
				MatcherAutomaton head = GetAutomaton(s.Head);
				MatcherAutomaton tail = GetAutomaton(s.Tail);
				a.Initial.AddMove(head.Initial);
				head.Final.AddMove(tail.Initial);
				tail.Final.AddMove(a.Final);
				result = a;
			}

			public override void VisitUnionSchema(UnionSchema s)
			{
				MatcherAutomaton a = result;
				MatcherAutomaton left = GetAutomaton(s.Left);
				MatcherAutomaton right = GetAutomaton(s.Right);
				a.Initial.AddMove(left.Initial);
				a.Initial.AddMove(right.Initial);
				left.Final.AddMove(a.Final);
				right.Final.AddMove(a.Final);
				result = a;
			}

			public override void VisitStarSchema(StarSchema s)
			{
				MatcherAutomaton a = result;
				MatcherAutomaton content = GetAutomaton(s.Content);
				a.Initial.AddMove(content.Initial);
				a.Initial.AddMove(a.Final);
				content.Final.AddMove(content.Initial);
				content.Final.AddMove(a.Final);
				result = a;
			}

			public override void VisitConstantSchema(ConstantSchema s)
			{
				if (entryMatcher.ContainsKey(s.Entry))
					result = entryMatcher[s.Entry];
				else {
					Debug.Assert(s.Entry != null);
					Debug.Assert(s.Entry.Schema != null);
					MatcherAutomaton a = result;
					entryMatcher.Add(s.Entry, a);
					s.Entry.Schema.Accept(this);
					Debug.Assert(Object.ReferenceEquals(a, result));
				}
			}

			public override void VisitChannelSchema(ChannelSchema s)
			{ AtomicSchema(s); }

			public override void VisitErrorSchema(ErrorSchema s)
			{ Debug.Assert(false); }

			public override void VisitBindSchema(BindSchema s)
			{
				Debug.Assert(s.Entry is ValueEntry);
				s.Content.Accept(this);
				result.Initial.AddBegin(((ValueEntry) s.Entry).Index);
				result.Final.AddEnd(((ValueEntry) s.Entry).Index);
			}

			public override void VisitServiceSchema(ServiceSchema s)
			{ AtomicSchema(s); }
		}

		private class VoidTransitionRemover
		{
			private readonly IDictionary<MatcherAutomaton, MatcherAutomaton> processed = new Dictionary<MatcherAutomaton, MatcherAutomaton>();
			private readonly IDictionary<ISet<State>, State> newStates = new Dictionary<ISet<State>, State>();
			private readonly IDictionary<State, ISet<State>> closure = new Dictionary<State, ISet<State>>();

			private State GetState(ISet<State> ss, out bool isNew)
			{
				State result;
				if (newStates.TryGetValue(ss, out result)) {
					isNew = false;
					return result;
				} else {
					isNew = true;
					bool final = false;
					foreach (State s in ss)
						if (s.Final) {
							final = true;
							break;
						}
					result = new State(final);
					foreach (State s in ss) {
						result.AddBegin(s.Begin);
						result.AddEnd(s.End);
					}
					newStates.Add(ss, result);
					closure.Add(result, ss);
					return result;
				}
			}

			private ISet<State> GetClosure(State s)
			{
				Debug.Assert(closure.ContainsKey(s));
				return closure[s];
			}

			public MatcherAutomaton Do(MatcherAutomaton a)
			{
// Console.WriteLine("IN ");
				if (processed.ContainsKey(a)) {
// Console.WriteLine("OUT IN CACHE");
					return processed[a];
				}
 //Console.WriteLine("IN NOT IN CACHE");

				bool isNew;
				ISet<State> states = new ArraySet<State>();
				State newInitial = GetState(a.Closure(a.Initial), out isNew);
				Debug.Assert(isNew);

				MatcherAutomaton result = new MatcherAutomaton(newInitial, null);
				processed.Add(a, result);

#if false
				AutomatonDumper nd = new AutomatonDumper(result);
 				AutomatonDumper od = new AutomatonDumper(a);
				//Console.Write("{0} = {", nd.GetStateIndex(newInitial));
				Console.Write("{");
				foreach (State s in a.Closure(a.Initial))
					Console.Write("{0} ", od.GetStateIndex(s));
				Console.WriteLine("}");
#endif

				states.Add(newInitial);
				while (states.Count > 0) {
					ISet<State> newReachable = new ArraySet<State>();
					foreach (State s in states) {
						IList<ITransition> moves = CollectMoves(GetClosure(s));
// Console.WriteLine("COLLECTED {0} moves from closure with {1} states", moves.Count, GetClosure(s).Count);
						foreach (ITransition t in moves) {
							if (t is AtomicTransition) {
								AtomicTransition at = (AtomicTransition) t;
								State next = GetState(a.Closure(t.Next), out isNew);
								s.AddMove(new AtomicTransition(at.Schema, next));
								if (isNew)
									newReachable.Add(next);
							} else if (t is LabelledTransition) {
								LabelledTransition lt = (LabelledTransition) t;
								State next = GetState(a.Closure(t.Next), out isNew);
								s.AddMove(new LabelledTransition(lt.Labels, Do(lt.ContentMatcher), next));
								if (isNew)
									newReachable.Add(next);
							}
						}
					}
					states = newReachable;
				}
 //Console.WriteLine("OUT ");
				return result;
			}
		}

		public MatcherAutomaton RemoveVoidTransitions()
		{ return new VoidTransitionRemover().Do(this); }

		public class State
		{
			private readonly bool final;
			private readonly IList<ITransition> moves;
			private readonly ISet<int> begin;
			private readonly ISet<int> end;

			public bool Final { get { return final; } }
			public ISet<int> Begin { get { return begin; } }
			public ISet<int> End { get { return end; } }
			public IList<ITransition> Moves { get { return moves; } }

			public State(bool final)
			{
				this.final = final;
				this.moves = new List<ITransition>();
				this.begin = new ArraySet<int>();
				this.end = new ArraySet<int>();
			}

			public State() : this(false)
			{ }

			public void AddMove(ITransition t)
			{ moves.Add(t); }

			public void AddMove(State s)
			{ AddMove(new VoidTransition(s)); }

			public void AddBegin(ISet<int> xs)
			{
				foreach (int x in xs)
					AddBegin(x);
			}

			public void AddBegin(int x)
			{ begin.Add(x); }

			public void AddEnd(ISet<int> xs)
			{
				foreach (int x in xs)
					AddEnd(x);
			}

			public void AddEnd(int x)
			{ end.Add(x); }

			public void CollectMoves(IList<ITransition> moves)
			{
				foreach (ITransition t in this.moves)
					moves.Add(t);
			}

			public bool Match(SchemaChecker sc, ValueCollector vc, IFlatValue value)
			{
//Console.WriteLine("state match {0} state is final? {1}", value.Head.SchemaOf(), final);
				foreach (int index in end)
					vc.End(index, value);
				if (value == null) {
					if (final) {
						foreach (int index in begin)
							vc.Begin(index, value);
						return true;
					} else
						return false;
				} else {
//Console.WriteLine("trying {0} moves", moves.Count);
					foreach (ITransition t in moves)
						if (t.Match(sc, vc, value.Head, value.Tail)) {
							foreach (int index in begin)
								vc.Begin(index, value);
							return true;
						}
					return false;
				}
			}
		}

		public interface ITransition
		{
			State Next { get; }
			bool Match(SchemaChecker sc, ValueCollector vc, IValue head, IFlatValue tail);
		}

		private abstract class Transition : ITransition
		{
			private readonly State next;

			public State Next { get { return next; } }

			public abstract bool Match(SchemaChecker sc, ValueCollector vc, IValue head, IFlatValue tail);

			public Transition(State next)
			{ this.next = next; }
		}

		private class VoidTransition : Transition
		{
			public VoidTransition(State next) : base(next)
			{ }

			public override bool Match(SchemaChecker sc, ValueCollector vc, IValue head, IFlatValue tail)
			{
				Debug.Assert(false, "void transition in matching automaton"); /* IMPOSSIBLE */
				return false;
			}
	 	}

		private class AtomicTransition : Transition
		{
			private readonly ISchema schema;

			public ISchema Schema { get { return schema; } }

			public AtomicTransition(ISchema schema, State next) : base(next)
			{ this.schema`CartId[string]?,`HMAC[string]?,`Items[AddItemArray],`locale[string]? 
and RemoveShoppingCartItemsRequest=`tag[string],`devtag[string],`CartId[string],`HMAC[string],`Items[ItemIdArray],`locale[string]? 
and ModifyShoppingCartItemsRequest=`tag[string],`devtag[string],`CartId[string],`HMAC[string],`Items[ItemQuantityArray],`locale[string]? 

and GoogleSearchResult=`documentFiltering[bool],`searchComments[string],`estimatedTotalResultsCount[int],`estimateIsExact[bool],`resultElements[ResultElementArray],`searchQuery[string],`startIndex[int],`endIndex[int],`searchTips[string],`directoryCategories[DirectoryCategoryArray],`searchTime[string] 
and ResultElement=`summary[string],`URL[string],`snippet[string],`title[string],`cachedSize[string],`relatedInformationPresent[bool],`hostName[string],`directoryCategory[DirectoryCategory],`directoryTitle[string] 
and ResultElementArray=`Item[ResultElement]* 
and DirectoryCategoryArray=`Item[DirectoryCategory]* 
and DirectoryCategory=`fullViewableName[string],`specialEncoding[string]

in import AmazonWebServices{ 
	KeywordSearchRequest: `KeywordSearchRequest[KeywordRequest]->`return[ProductInfo]
} location="http://s