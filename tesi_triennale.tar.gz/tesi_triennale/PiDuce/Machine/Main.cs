tion using subtraction
	from zero.

2004-05-16  John David Anglin  <dave.anglin@nrc-cnrc.gc.ca>

	* pa.md:  Fix typo from last change.  Remove DFmode move to and from
	SAR register.

2004-05-16  Richard Earnshaw  <rearnsha@arm.com>

	PR target/10982
	* arm.md (ne_zeroextractsi): Convert to insn-and-split.
	(ne_zeroextractsi_shifted): New pattern.
	(ite_ne_zeroextractsi): New pattern.
	(ite_ne_zeroextractsi_shifted): New pattern.

2004-05-15  Steven Bosscher  <stevenb@suse.de>

	* c-gimplify.c (c_genericize):
	Replace calls via (*lang_hooks.foo) with lang_hooks.foo.
	* c-parse.in <expr_no_commas>: Likewise.
	<if_prefix>: Likewise.
	<select_or_iter_stmt>: Likewise.
	* expr.c (expand_var, expand_expr_real_1): Likewise.
	* expr.h (expand_expr): Make it a static inline function.
	Move prototype for expand_expr_real up before this.
	* fold-const.c (fold_relational_hi_lo, fold_relational_const):
	Likewise.
	* gimplify.c (gimple_boolify, gimplify_addr_expr,
	gimplify_asm_expr, gimplify_expr): Likewise.
	* tree-cfg.c (dump_tree_cfg, dump_cfg_stats, tree_cfg2vcg,
	dump_function_to_file): Likewise.
	* tree-dfa.c (dump_immediate_uses, dump_dfa_stats): Likewise.
	* tree-inline.c (remap_block, save_body, walk_tree): Likewise.
	* tree-into-ssa.c (dump_tree_ssa): Likewise.
	* tree-mudflap.c (mf_varname_tree, mf_file_function_line_tree):
	Likewise.
	* tree-optimize.c (execute_one_pass): Likewise.
	* tree-pretty-print.c (dump_generic_bb_buff): Likewise.
	* tree-ssa-alias.c (dump_alias_stats, dump_alias_info): Likewise.

	* objc/objc-act.c (objc_build_try_enter_fragment,
	objc_build_try_epilogue, objc_build_catch_stmt,
	objc_build_finally_prologue): Replace calls via (*lang_hooks.foo)
	with lang_hooks.foo ().

2004-05-15  Roger Sayle  <roger@eyesopen.com>

	* builtins.c (simplify_builtin_strcpy): Avoid use of chainon, so
	that simplify_builtin doesn't destructively modify its argument.

2004-05-15  Richard Earnshaw  <reanrsha@arm.com>

	* arm/lib1funcs.asm (_lshrdi3, _ashrdi3, _ashldi3): Add ASM
	implementations for ARM and Thumb.
	* arm/t-arm-elf (LIB1ASMFUNCS): Use them.

2004-05-15  Thomas Quinot  <quinot@act-europe.fr>

	* prefix.c (update_path): Replace PREFIX with KEY only
	when it matches a full directory name in PATH.

2004-05-15  Richard Earnshaw  <reanrsha@arm.com>

	* arm.h (TARGET_APCS_32): Delete.
	(TARGET_MMU_TRAPS): Delete.
	(TARGET_CPU_CPP_BUILTINS): Unconditionally define __APCS_32__.  Never
	define __APCS_26__.
	(CPP_SPEC): Remove checking of -mapcs-{26,32}.
	(ARM_FLAG_APCS_32, ARM_FLAG_MMU_TRAPS): Delete.
	(TARGET_SWITCHES): Remove alignment_traps and apcs-{26,32} switches.
	(prog_mode_type): Delete.
	(PROMOTE_MODE): Always promote unsigned for HImode.
	(SECONDARY_INPUT_RELOAD_CLASS): Simplify.
	(MASK_RETURN_ADDR): Simplify.
	* arm.c (arm_prgmode): Delete.
	(arm_override_options, arm_gen_rotated_half_load): Simplify.
	(print_multi_reg, output_return_instruction): Simplify.
	(arm_output_epilogue, arm_final_prescan_insn): Simplify.
	(arm_return_addr): Simplify.
	* arm.md (prog_mode): Delete.
	(conds): Simplify.
	(zero_extendhisi2, extendhisi2, movhi, movhi_bytes): Simplify.
	(rotated_loadsi, movhi_insn_littleend, movhi_insn_bigend): Delete.
	(loadhi_si_bigend, loadhi_preinc, loadhi_shiftpreinc): Delete.
	(loadhi_shiftpredec): Delete.
	(peephole for post-increment on HImode load): Delete.
	* arm/crtn.asm: (FUNC_END): Simplify.
	* arm/lib1funcs.asm: Remove APCS-26 return macros.
	* arm/aof.h, arm/coff.h arm/elf.h arm/linux-elf.h arm/netbsd-elf.h
	* arm/netbsd.h arm/pe.h arm/semi.h arm/semiaof.h arm/unknown-elf.h
	* arm/vxworks.h arm/wince-pe.h: Tidy TARGET_DEFAULTS and
	MULTILIB_DEFAULTS as required.
	* arm/t-arm-elf arm/t-linux arm/