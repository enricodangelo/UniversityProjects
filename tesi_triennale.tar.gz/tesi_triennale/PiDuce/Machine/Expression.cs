// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Diagnostics;
using PiDuce.Common;

namespace PiDuce.Machine
{
#if false
	public class EvaluateExpressionVisitor : IExpressionVisitor
	{
		private readonly Env env;
		private IValue result;

		public IValue Evaluate(IExpression expr)
		{
			expr.Accept(this);
			return result;
		}

		public void VisitVoidExpr(VoidExpr expr)
		{ result = new VoidValue(); }

		public void VisitLiteralExpr(LiteralExpr expr)
		{
			switch (expr.Content.TypeOf().Kind) {
				case BasicTypeKind.INT:
					result = new IntValue(((IntLiteral) expr.Content).Value);
					break;
				case BasicTypeKind.STRING:
					result = new StringValue(((StringLiteral) expr.Content).Value);
					break;
				default:
					Debug.Assert(false);
					break;
			}
		}

		public void VisitVariableExpr(VariableExpr expr)
		{
			Debug.Assert(expr.Entry is ValueEntry);
			result = env.Get(((ValueEntry) expr.Entry).Index);
		}
    
		public void VisitSelectExpr(SelectExpr expr)
		{
			// TODO: implement me
			Debug.Assert(false);
		}

		public void VisitRecordExpr(RecordExpr expr)
		{
			// TODO: implement me
			Debug.Assert(false);
		}

		public void VisitLabelledExpr(LabelledExpr expr)
		{ result = new LabelValue(expr.Label, Evaluate(expr.Content)); }

		public void VisitSequenceExpr(SequenceExpr expr)
		{ result = SequenceValue.Make(Evaluate(expr.Head), Evaluate(expr.Tail)); }
		
		public void VisitBinaryOpExpr(BinaryOpExpr expr)
		{
			IValue v1 = Evaluate(expr.Left);
			IValue v2 = Evaluate(expr.Right);
			switch (expr.Op) {
				case BinaryOp.PLUS:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 + (IntValue) v2;
					else if ((v1 is StringValue) && (v2 is StringValue))
						result = (StringValue) v1 + (StringValue) v2;
					else
						throw new ApplicationException("invalid operands for PLUS");
					break;
				case BinaryOp.MINUS:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 - (IntValue) v2;
					else
						throw new ApplicationException("invalid operands for MINUS");
					break;
				case BinaryOp.TIMES:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 * (IntValue) v2;
					else
						throw new ApplicationException("invalid operands for TIMES");
					break;
				case BinaryOp.DIVIDE:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 / (IntValue) v2;
					else
						throw new ApplicationException("invalid operands for DIVIDE");
					break;
				case BinaryOp.EQ:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 == (IntValue) v2;
					else if ((v1 is StringValue) && (v2 is StringValue))
						result = (StringValue) v1 == (StringValue) v2;
					else 
						throw new ApplicationException("invalid operands for EQ");
					break;
				case BinaryOp.NE:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 == (IntValue) v2;
					else if ((v1 is StringValue) && (v2 is StringValue))
						result = (StringValue) v1 != (StringValue) v2;
					else
						throw new ApplicationException("invalid operands for NE");
					break;
				case BinaryOp.GT:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 > (IntValue) v2;
					else
						throw new ApplicationException("invalid operands for GT");
					break;
				case BinaryOp.GE:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 >= (IntValue) v2;
					else
						throw new ApplicationException("invalid operands for GE");
					break;
				case BinaryOp.LT:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 < (IntValue) v2;
					else
						throw new ApplicationException("invalid operands for LT");
					break;
				case BinaryOp.LE:
					if ((v1 is IntValue) && (v2 is IntValue))
						result = (IntValue) v1 <= (IntValue) v2;
					kage Ada.Strings.Fixed.
--      
--       
-- CHANGE HISTORY:
--      06 Dec 94   SAIC    ACVC 2.0
--
--!

with Ada.Strings.Fixed;
with Ada.Strings.Maps;
with Report;

procedure CXA4003 is

begin

   Report.Test ("CXA4003", "Check that the subprograms defined in package "  &
                           "Ada.Strings.Fixed are available, and that they " &
                           "produce correct results");

   Test_Block:
   declare

      Number_Of_Info_Strings : constant Natural := 3;
      DB_Size                : constant Natural := Number_Of_Info_Strings;
      Count                  : Natural          := 0;
      Finished_Processing    : Boolean          := False;
      Blank_String           : constant String  := " ";

      subtype Info_String_Type         is String (1..50);
      type    Info_String_Storage_Type is 
        array (1..Number_Of_Info_Strings) of Info_String_Type;


      subtype Name_Type                is String (1..10);
      subtype Street_Number_Type       is String (1..5);
      subtype Street_Name_Type         is String (1..10);
      subtype City_Type                is String (1..10);
      subtype State_Type               is String (1..2);
      subtype Zip_Code_Typ