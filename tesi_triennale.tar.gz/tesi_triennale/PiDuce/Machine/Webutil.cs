// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Xml;
using PiDuce.Common;
using PiDuce.Machine;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace PiDuce.Web
{
  public class Webclient
  {	
    public const string USER_AGENT = "PiDuce";

    public delegate String DownloadDelegate (string url);

    public static String Download(String url)
    {
      WebClient wc = new WebClient();
      wc.Headers.Add("User-Agent", USER_AGENT);
      return System.Text.Encoding.UTF8.GetString(wc.DownloadData(url));
    }

    public delegate XmlNodeList UploadDelegate (String url, String data, String soapAction);

    public XmlNodeList Upload(String url, String data, String soapAction)
    {
      System.Net.WebClient wc = new WebClient();
      byte[] request = new byte[data.Length];
      request = new System.Text.UTF8Encoding().GetBytes(data);
      wc.Headers.Add("SOAPAction", soapAction);
      wc.Headers.Add("Content-Type", "text/xml; charset=utf-8");
      wc.Headers.Add("User-Agent", USER_AGENT);
      try
      {
        byte[] response = wc.UploadData(url, "POST", request);
        string xml = System.Text.Encoding.UTF8.GetString(response, 0, response.Length);
        return SoapHandler.RemoveSoap(xml);
      }
      catch (WebException e)
      {
        Machine.MachineOutput.Print(e.Message + " " + e.Response.GetResponseStream().ToString());
        throw e;
      }
    }
  }

  public class WebServer
  {
    public const string LINEARFWD = "http://www.cs.unibo.it/PiDuce/LinearForwarder";
    public const string LOADCODE = "http://www.cs.unibo.it/PiDuce/LoadCode";
    public const string ADDCHANNEL = "http://www.cs.unibo.it/PiDuce/AddChannel";

    private static IManageOutputRequest channelManager;
    private static IScheduler scheduler;
    private static string localMachine;
    private static int port;
    private static string machineAbstractWsdl;
    private static bool keepAlive;
    private static ManualResetEvent allDone;

    public static int Port { get { return port;} }
    public static string LocalMachine
    { get { return "http://" + localMachine + ":" + port.ToString() + "/"; } }

    static WebServer()
    {
      WebServer.port = 1811;
      WebServer.keepAlive = true;
      WebServer.allDone = new ManualResetEvent(false);
      WebServer.machineAbstractWsdl = "machineAbstract.wsdl";
    }

    public static void Init(IManageOutputRequest channelManager, IScheduler scheduler, string host, int port)
    {
      WebServer.channelManager = channelManager;
      WebServer.scheduler = scheduler;
			WebServer.localMachine = Dns.GetHostByName(host).AddressList[0].ToString();;
      WebServer.port = port;
    }

    public static void Stop()
    {
      keepAlive = false;
      allDone.Set();
    }
    
    public static void StartListening() 
    {
      HttpListener listener = new HttpListener();
      listener.Prefixes.Add(WebServer.LocalMachine);
      try 
      {
        Console.WriteLine("The machine is waiting on " + WebServer.LocalMachine);
        listener.Start();
        while (keepAlive)
        {
          allDone.Reset();
          listener.BeginGetContext(new AsyncCallback(AcceptCallback), listener);
          allDone.WaitOne();
        }
        listener.Stop();
      } 
      catch (Exception e) 
      {
        Console.WriteLine(e.ToString());
      }
    }

    private static void AcceptCallback(IAsyncResult ar) 
    {
      allDone.Set();
      HttpListener listener = (HttpListener)ar.AsyncState;
      HttpListenerContext context = listener.EndGetContext(ar);
      try
      {
        ProcessRequest(context);
      } 
      catch (Exception e) {
        context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
        context.Response.StatusDescription = e.Message;
        context.Response.Close();
      }
    }
    
    private static string BodyAsString(HttpListenerRequest request)
    {
      StringBuilder builder = new StringBuilder();
      Stream stream = request.InputStream;
      if (stream.CanSeek)
      {
        for (int read = 0; read < request.ContentLength64; )
        {
          int length = (int)stream.Length;
          byte[] received = new byte[length];
          stream.Read(received, 0, length);
          read += length;
          builder.Append(received);
        }
      }
      else {
        for (int read = 0; read < request.ContentLength64; read++)
        {
          byte[] b = new byte[1];
          stream.Read(b, 0, 1);
          builder.Append(System.Text.Encoding.UTF8.GetChars(b));
        }
      }
      return builder.ToString();
    }

    private static void ProcessLinearForwarder(HttpListenerRequest request, HttpListenerResponse response)
    {
      try
      {
        string body = BodyAsString(request);
        XmlNode req = XmlUtil.RemoveSoap(body)[0];
        //MachineOutput.Print("Have received a linearforwarder's request:" + lfreq.OuterXml);
        string source = req.ChildNodes[0].InnerText;
        string destination = req.ChildNodes[1].InnerText;
        if (channelManager.LinearForwarder(source, destination))
        {
          response.StatusCode = (int)HttpStatusCode.OK;
          response.ContentLength64 = 0;
        }
        else
        {
          response.StatusCode = (int)HttpStatusCode.NotFound;
          response.ContentLength64 = 0;
        }
      } 
      catch(Exception e)
      {
        response.StatusCode = (int)HttpStatusCode.BadRequest;
        response.ContentLength64 = 0;
        response.StatusDescription = e.Message;
      }
      response.Close();
    }

    private static void ProcessLoadCode(HttpListenerRequest request, HttpListenerResponse response)
    {
      try
      {
        MachineOutput.Print("Have received remote code i start loading it");
        scheduler.AddProgram(XmlUtil.RemoveSoap(BodyAsString(request))[0].InnerXml);
        response.StatusCode = (int)HttpStatusCode.OK;
        response.ContentLength64 = 0;
      }
      catch (Exception e) 
      {
        response.StatusCode = (int)HttpStatusCode.BadRequest;
        response.ContentLength64 = 0;
        response.StatusDescription = "The bytecode may be not correct. " + e.Message;
      }
      response.Close();
    }

    private static void ProcessAddService(HttpListenerRequest request, HttpListenerResponse response)
    {
      MachineOutput.Print("Have received request to add channel  ");
      try
      {
        XmlNode addChannelNode = XmlUtil.RemoveSoap(BodyAsString(request))[0];
        string location;
        if (addChannelNode.ChildNodes[0].LocalName == "location")
        {
          string suggestedLocation = addChannelNode.ChildNodes[0].InnerText;
          string wsdl = addChannelNode.ChildNodes[1].InnerXml;
          ServiceSchema serviceSchema = AbstractWsdlReader.CompileAbstractWsdl(wsdl);
          location = channelManager.AddService(suggestedLocation, serviceSchema);
        }
        else 
        {
          string wsdl = addChannelNode.ChildNodes[0].InnerXml;
          ServiceSchema serviceSchema = AbstractWsdlReader.CompileAbstractWsdl(wsdl);
          location = channelManager.AddService(serviceSchema);
        }
        string message = XmlUtil.AddSoap("<Service xmlns=\"http://www.cs.unibo.it/PiDuce/Default\">" + location + "?wsdl</Service>");
        response.StatusCode = (int)HttpStatusCode.OK;
        response.ContentLength64 = message.Length;
        response.ContentEncoding = System.Text.Encoding.UTF8;
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(message);
        response.OutputStream.Write(bytes, 0, bytes.Length);
      }
      catch (Exception e)
      {
        response.StatusCode = (int)HttpStatusCode.BadRequest;
        response.ContentLength64 = 0;
        response.StatusDescription = "The Wsdl may be not correct. " + e.Message;
      }
      response.Close();
    }

    private static void ProcessServiceInvocation(HttpListenerRequest request, HttpListenerResponse response) 
    {
      try
      {
        //Post on a local channel
        string location = request.Headers["SOAPAction"];
        if (location.StartsWith("\""))
          location = location.Remove(0, 1);
        if (location.EndsWith("\""))
          location = location.Remove(location.Length - 1, 1);
        ArrayList responsecontainer = new ArrayList();

        LiteralValueUtil valueUtil = new LiteralValueUtil();
        ISchema opSchema = channelManager.GetSchemaOfChannel(location);
        ISchema valueSchema;
        if (opSchema is FunctionSchema)
          valueSchema = ((FunctionSchema)opSchema).Input;
        else
          valueSchema = ((ChannelSchema)opSchema).Content;
        XmlNodeList nodes = SoapHandler.RemoveSoap(BodyAsString(request));
        if (request.UserAgent != Webclient.USER_AGENT && !(valueSchema is LabelledSchema) && !(valueSchema is VoidSchema))
          nodes = nodes.Item(0).ChildNodes;
        IValue val = valueUtil.XmlToIValue(nodes, valueSchema);
        if (channelManager.ForeignRequest(location, val, responsecontainer))
        {
          lock (responsecontainer)
          {
            //to prevent deadlock
            if (responsecontainer.Count == 0)
              System.Threading.Monitor.Wait(responsecontainer);
            XmlDocument doc = new XmlDocument();
            IValue v = (IValue)responsecontainer[0];
            //add the wrapper
            ISchema outSchema = ((FunctionSchema)opSchema).Output;
            if (request.UserAgent != Webclient.USER_AGENT && !(outSchema is LabelledSchema) && !(outSchema is VoidSchema))
              v = new LabelValue(channelManager.GetOperationName(location) + "Out", v);
            string message = ValueUtil.MakeDocumentLiteralEncoding(
              channelManager.GetSchemaOfChannel(location), 
              WebNamespace.PiDuceDefaultNamespace)(v);
            response.StatusCode = (int)HttpStatusCode.OK;
            response.ContentType = "text/xml";
            response.ContentEncoding = System.Text.Encoding.UTF8;
            response.ContentLength64 = message.Length;
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(message);
            response.OutputStream.Write(bytes, 0, bytes.Length);
          }
        }
        else if (channelManager.LocalOutput(location, val))
        {
          response.StatusCode = (int)HttpStatusCode.OK;
          response.ContentLength64 = 0;
        }
        else
        {
          response.StatusCode = (int)HttpStatusCode.NotFound;
          response.ContentLength64 = 0;
        }
      }
      catch (Exception e) 
      {
        response.StatusCode = (int)HttpStatusCode.BadRequest;
        response.ContentLength64 = 0;
        response.StatusDescription = e.Message;
      } 
      response.Close();
    }

    private static void ProcessGetServiceInterface(HttpListenerRequest request, HttpListenerResponse response)
    {
      try
      {
        if (request.RawUrl == "?wsdl" || request.RawUrl == "/?wsdl")
        {
          string service = "  <wsdl:service name=\"PiDuceMachineService\">";
          service += System.Environment.NewLine + "    <wsdl:port name=\"PiDuceMachine\" binding=\"tns:PiDuceMachine\">";
          service += System.Environment.NewLine + "      <soap:address location=\"" + WebServer.LocalMachine + "\" />";
          service += System.Environment.NewLine + "    </wsdl:port>";
          service += System.Environment.NewLine + "  </wsdl:service>";
          service += System.Environment.NewLine + "</wsdl:definitions>";
          FileStream stream = new FileStream(machineAbstractWsdl, FileMode.Open, FileAccess.Read);
          byte[] wsdl = new byte[stream.Length];
          stream.Read(wsdl, 0, (int)stream.Length);
          stream.Close();
          string message = System.Text.Encoding.UTF8.GetString(wsdl, 0, wsdl.Length);
          message = mes32, vec_splat_u8, vec_splat_u16, vec_splat_u32):
	Change C++ definitions to accept a 'const int' argument;
	the prototypes already do.
	* config/rs6000/rs6000.c (rs6000_common_init_builtins):
	Rename v4si_ftype_char, v8hi_ftype_char, v16qi_ftype_char,
	v4sf_ftype_v4si_char, v4si_ftype_v4sf_char, v4si_ftype_v4si_char,
	v8hi_ftype_v8hi_char, v16qi_ftype_v16qi_char,
	v16qi_ftype_v16qi_v16qi_char, v8hi_ftype_v8hi_v8hi_char,
	v4si_ftype_v4si_v4si_char and v4sf_ftype_v4sf_v4sf_char to
	end in ..._int; change them to accept an int instead of a char
	as the last parameter.

2004-03-04  Phil Edwards  <phil@codesourcery.com>

	* genmultilib:  Change '=' to '-' when translating option names
	to directory names.

2004-03-04  Richard Kenner  <kenner@vlsi1.ultra.nyu.edu>

	* expr.c (expand_expr_real, case COMPONENT_REF): Get proper type of
	stack slot for temp used for result of BLKmode but in integral mode.

2004-03-04  Jan Hubicka  <jh@suse.cz>

	* reload.c (find_reloads): Reorganize if seqeunce to switch.

	* cfgrtl.c (rtl_redirect_edge_and_branch):  Set the source BB as dirty.
	(cfglayout_redirect_edge_and_branch):  Set the source BB as dirty.

2004-03-04  Steve Ellcey  <sje@cup.hp.com>

	* config/ia64/ia64.md (divdf3_internal_thr): Fix algorithm.
	* testsuite/gcc.dg/20040303-1.c: New test.

2004-03-04  Steven Bosscher  <stevenb@suse.de>

	* ppro.md: Rewrite as a DFA pipeline description.
	* i386.md: Remove all uses of the ppro_uops attribute.
	* i386.c: (ix86_safe_ppro_uops, ix86_dump_ppro_packet,
	ix86_reorder_insn, ix86_sched_reorder_ppro, ix86_sched_init,
	ix86_sched_reorder, ix86_variable_issue,
	struct ix86_sched_data, TARGET_SCHED_VARIABLE_ISSUE,
	TARGET_SCHED_INIT, TARGET_SCHED_REORDER): Remove.
	(ia32_use_dfa_pipeline_interface): Add TARGET_PENTIUMPRO.
	(ia32_multipass_dfa_lookahead): Add TARGET_PENTIUMPRO.
	* athlon.md (athlon_ssecmp_load): Fix comment

2004-03-04  Stuart Hastings  <stuart@apple.com>

	* gcc/doc/invoke.texi: Document -mlongcall for Darwin/PPC.

2004-03-04  Stuart Hastings  <stuart@apple.com>

	* gcc/config/i386/darwin.h: Darwin/x86 doesn't support CPUs before
	686, tell Darwin assembler to allow prefetch insns, non-empty def
	of SUBTARGET_OPTION_TRANSLATE_TABLE.

2004-03-04  DJ Delorie  <dj@redhat.com>

	PR optimization/14282
	* sched-deps.c (sched_analyze_insn): Allow a stack adjustment
	between a call and the assignment of its return value.

2004-03-04  Kazu Hirata  <kazu@cs.umass.edu>

	* config/h8300/h8300.c: Put a comment for every function.

2004-03-04  Kazu Hirata  <kazu@cs.umass.edu>

	* config/h8300/h8300.md: Add comments about peephole2's.

2004-03-04  Steven Bosscher  <stevenb@suse.de>

	* i386.h (TARGET_CPU_DEFAULT_nocona): Fix value.

2004-03-04  Jan Hubicka  <jh@suse.cz>

	* cfgcleanup.c (thread_jump): Update call of cselib_init.
	* cselib.c (cselib_record_memory): New static variable.
	(cselib_lookup_mem, cselib_record_set, cselib_record_sets):
	Give up on memories when asked for.
	(cselib_init): Accept new argument.
	* cselib.h (cselib_init): Update