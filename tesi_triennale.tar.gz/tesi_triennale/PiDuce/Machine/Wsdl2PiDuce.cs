using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Xml;
using PiDuce.Common;
using PiDuce.Web;
using PiDuce.Compiler;

namespace PiDuce.Wsdl2PiDuce
{
  /// <summary>
  /// This utility allows to read remote WSDL files producing a PiDuce prototype file.
  /// Such a prototype is just a sequence of "import" directives.
  /// </summary>
  public class Wsdl2PiDuce
  {
    private static string usage = 
@"Wsdl2PiDuce - Usage: Wsdl2PiDuce [WSDLFILE]s -o [OUTPUTFILE]
  WSDLFILE are generic URI http://..., https://..., file://..., ftp://..., ecc.";
    /// <summary>
    /// Allows to import a list of WSDL files producing the correspondent PiDuce prototype.
    /// The resulting code is written to a file.
    /// </summary>
    /// <param name="args">Usage: Wsdl2PiDuce [WSDLFILE]s -o [OUTPUTFILE]</param>
    public static void Main(string[] args)
    {
      if (args.Length < 2)
      {
        Console.WriteLine(Wsdl2PiDuce.usage);
        return;
      }
      else if (args[args.Length - 2] != "-o")
      {
        Console.WriteLine(Wsdl2PiDuce.usage);
        return;
      }
      else
      {
        string outFileName = args[args.Length - 1];
        if (File.Exists(outFileName))
        {
          string answer = "n";
          Console.WriteLine(outFileName + " already exists. Do you want to overwrite it? (y/n) - Default is [N]");
          answer = Console.In.ReadLine().Trim();
          if ("n".Equals(answer, StringComparison.OrdinalIgnoreCase))
            return;
        }
        WebClient wc = new WebClient();
        StringBuilder s = new StringBuilder();
        s.AppendLine("//Automatically generated code");
        for (int i = 0; i < args.Length - 2; i++)
        {
          string wsdl = args[i];
          try
          {
            WsdlReader decoder = null;
            string name = null;
            if (File.Exists(wsdl))
            {
              decoder = new WsdlReader(File.OpenRead(wsdl), wsdl);
              char[] separators = { '.', '?' };
              name = Path.GetFileName(wsdl).Split(separators)[0];
            }
            else
            {
              Uri u = new Uri(wsdl);
              if (u.IsFile)
                decoder = new WsdlReader(File.OpenRead(u.AbsolutePath), wsdl);
              else
              {
                wc.DownloadData(wsdl);
                decoder = new WsdlReader(wc.OpenRead(wsdl), wsdl);
              }
              char[] separators = {'.','?'};
              name = Path.GetFileName(u.LocalPath).Split(separators)[0];
            }
            XsdToSchema xsd = decoder.Compile();
            Console.WriteLine(xsd.Output);
            if (xsd.SchemaDefs.Count > 0)
              s.Append("schema ");
            foreach (KeyValuePair<XmlQualifiedName, ConstantSchema> kv in xsd.SchemaDefs)
            {
              CompilerSchemaToStringVisitor visitor = new CompilerSchemaToStringVisitor();
              kv.Value.Entry.Schema.Accept(visitor);
              s.AppendLine(kv.Key.Name + "=" + visitor + " ");
              s.Append("and ");
            }
            if (xsd.SchemaDefs.Count > 0)
              s.Replace("and ", "", s.Length - 4, 4);
            if (xsd.SchemaDefs.Count > 0)
              s.Append("in ");
            if (decoder.Operations.Count > 0)
            {
              s.Append("import ");
              s.Append(name);
            }
            s.Append("{ ");
            ServiceSchema schema = decoder.ServiceSchema;
            foreach (KeyValuePair<string, ISchema> operation in schema.Fields)
            {
              s.Append(System.Environment.NewLine + "\t" + operation.Key + ": ");
              if (operation.Value is FunctionSchema)
              {
                FunctionSchema operationSchema = (FunctionSchema)operation.Value;
                if (!(operationSchema.Input is LabelledSchema))
                  s.Append("(");
                s.Append(operationSchema.Input);
                if (!(operationSchema.Input is LabelledSchema))
           ��  s  �l�C�l�C�l�C                  �{ �{ �{ �{                                             ��h                        ��  �  �l�C�l�C�l�C                  �{                                                         ��h                        ��  �  �l�C�l�C�l�C                  �{ �{                                                     ��h                        ��  �  �l�C�l�C�l�C                  �{ �{                                                     ��h                        ��  �  �l�C�l�C�l�C                  �{                                                         ��h                        ��    �l�C�l�C�l�C                  �{                                                         ��h                        ��  �   �l�C�l�C�l�C                  �{                                                         ��h                        ��  �  �l�C�l�C�l�C                  �{ �{                                                     ��h                        ��  
  �l�C�l�C�l�C                  �{                                                         ��h                        ��  I  �l�C�l�C�l�C                  �{                                                         ��h                        ��  �  �l�C�l�C�l�C                  �{                                                         ��h                        ��  �   �l�C�l�C�l�C                  �{                                                         ��h                        ��  ��  �l�C�l�C�l�C       z           �{ �{ �{ �{ �{ �{ �{ �{ �{ �{ �{ �{ �{         ��h                        ��  .  �l�C�l�C�l�C                  |                                                         ��h                        ��  �  �l�C�l�C�l�C                  | |                                                     ��h              