﻿<?xml version="1.0" encoding="utf-8"?>
<PiDuce xmlns="http://cs.unibo.it/PiDuce/opcode" xmlns:pdcv="http://www.cs.unibo.it/PiDuce/Values">
  <schemadecl>
    <schemadec name="any">
      <union>
        <void />
        <union>
          <bool />
          <union>
            <int />
            <union>
              <float />
              <union>
                <string />
                <union>
                  <sequence>
                    <labelled>
                      <without />
                      <ref name="any" />
                    <