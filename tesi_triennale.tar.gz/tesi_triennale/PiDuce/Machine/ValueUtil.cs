using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using PiDuce.Common;
using PiDuce.Machine;
using PiDuce.Web;

namespace PiDuce.Machine
{
  public abstract class ValueToXmlVisitor : IValueVisitor
  {
    private string operation;
    private bool isFirstValue;
    private StringWriter writer;
    private XmlTextWriter xml;
    private string namespaceURI;

    protected string Operation { get { return operation; } }
    protected bool IsFirstValue { get { return isFirstValue; } set { isFirstValue = value; } }
    public XmlWriter Xml { get { return xml; } }
    public string NamespaceURI { get { return namespaceURI; } }
    public string Text { get { return writer.ToString(); } }

    public ValueToXmlVisitor(string namespaceUri)
    {
      this.operation = null;
      this.isFirstValue = true;
      this.writer = new StringWriter();
      this.xml = new XmlTextWriter(writer);
      this.xml.Formatting = Formatting.Indented;
      this.xml.Indentation = 2;
      this.namespaceURI = namespaceUri;
    }

    public ValueToXmlVisitor(string namespaceUri, string operation) : this(namespaceUri)
    { this.operation = operation; }

    public void VisitVoidValue(VoidValue v)
    { }

    public virtual void VisitIntValue(IntValue v)
    { this.Xml.WriteString(v.ToString()); }

    public virtual void VisitFloatValue(FloatValue v)
    { this.Xml.WriteString(v.ToString()); }

    public virtual void VisitBoolValue(BoolValue v)
    { this.Xml.WriteString(v.ToString()); }

    public virtual void VisitStringValue(StringValue v)
    { this.Xml.WriteString(v.ToString()); }

    public virtual void VisitChannelValue(ChannelValue v)
    {
      this.Xml.WriteStartElement(WebNamespace.PiDuceValueNamespacePrefix, "chan", WebNamespace.PiDuceValueNamespace);
      this.Xml.WriteAttributeString("wsdl", v.WsdlLocation);
      this.Xml.WriteAttributeString("operation", v.OperationName);
      this.Xml.WriteEndElement();
    }

    public virtual void VisitServiceValue(ServiceValue v)
    {
      this.Xml.WriteStartElement(WebNamespace.PiDuceValueNamespacePrefix, "service", WebNamespace.PiDuceValueNamespace);
      this.Xml.WriteAttributeString("wsdl", v.WsdlLocation);
      this.Xml.WriteEndElement();
    }
    public abstract void VisitLabelValue(LabelValue v);
    public abstract void VisitSequenceValue(SequenceValue v);
  }

  public class LiteralValueVisitor : ValueToXmlVisitor
  {
    public LiteralValueVisitor(string namespaceUri) : base(namespaceUri) { }

    public LiteralValueVisitor(string namespaceUri, string operation)
      : base(namespaceUri, operation)
    { }

    public override void VisitLabelValue(LabelValue v)
    {
      bool isFirstValue = base.IsFirstValue;
      if (isFirstValue && base.Operation != null)
      {
        this.Xml.WriteStartElement("tns:" + base.Operation);
        base.IsFirstValue = false;
      }

      this.Xml.WriteStartElement(v.Label, this.NamespaceURI);
      v.Content.Accept(this);
      this.Xml.WriteEndElement();

      if (isFirstValue && base.Operation != null)
      { this.Xml.WriteEndElement(); }
    }

    public override void VisitSequenceValue(SequenceValue v)
    {
      bool isFirstValue = base.IsFirstValue;
      if (isFirstValue && base.Operation != null)
      {
        this.Xml.WriteStartElement("tns:" + base.Operation);
        base.IsFirstValue = false;
      }

      v.Top.Accept(this);
      v.Tail.Accept(this);

      if (isFirstValue && base.Operation != null)
      { this.Xml.WriteEndElement(); }
    }
  }

  public class EncodedValueVisitor : ValueToXmlVisitor
  {
    private int nestedLabel = 0;
    private string id;
    private uint typeReferenceNumber = 1;
    private static string typeReferenceSuffix = "id";
    private Queue<Pair<string, Pair<IValue, ISchema>>> typesDefinition = new Queue<Pair<string, Pair<IValue, ISchema>>>();
    private ISchema currentSchema;

    public Queue<Pair<string, Pair<IValue, ISchema>>> TypesDefinition { get { return typesDefinition; } }
    public string Id { get { return id; } set { id = value; } }

    public EncodedValueVisitor(string namespaceUri, ISchema schema)
      : base (namespaceUri)
    { this.currentSchema = schema; }

    public EncodedValueVisitor(string namespaceUri, string operation, ISchema schema)
      : base(namespaceUri, operation)
    { this.currentSchema = schema; }

    public override void VisitLabelValue(LabelValue v)
    {
      this.nestedLabel++;

      bool isFirstValue = base.IsFirstValue;
      if (isFirstValue && base.Operation != null)
      {
        this.Xml.WriteStartElement("tns:" + base.Operation);
        base.IsFirstValue = false;
      }

      ISchema labelSchema = currentSchema;
      if (!((currentSchema is LabelledSchema) || (currentSchema is ConstantSchema)))
      {
        //search for the proper schema of this value
        SchemaFromLabelVisitor visitor = new SchemaFromLabelVisitor(v.Label);
        labelSchema.Accept(visitor);
        labelSchema = visitor.Schema;
      }
      if (labelSchema is ConstantSchema)
      {
        bool isArraySchema = ((ConstantSchema)labelSchema).Entry.Schema is IArraySchema;
        if (!isArraySchema)
        {
          string name = ((ConstantSchema)labelSchema).Name;
          this.Xml.WriteStartElement("q1:" + name);
          this.Xml.WriteAttributeString("id", this.Id);
          this.Xml.WriteAttributeString(WebNamespace.XmlSchemaInstancePrefix + ":type", "q1:" + name);
          this.Xml.WriteAttributeString("xmlns:q1", this.NamespaceURI);
          currentSchema = ((ConstantSchema)labelSchema).Entry.Schema;
          v.Content.Accept(this);
          this.Xml.WriteEndElement();
        }
        else
        {
          IArraySchema arraySchema = (IArraySchema)((ConstantSchema)labelSchema).Entry.Schema;
          this.Xml.WriteStartElement(WebNamespace.SoapEncodingStylePrefix, "Array", WebNamespace.SoapEncNamespace);
          this.Xml.WriteAttributeString("id", this.Id);
          int contentLength = 1;
          if (v.Content is SequenceValue)
            contentLength = ((SequenceValue)v.Content).Length;
          string boundaries = ArraySchemaUtil.Boundaries(arraySchema);
          boundaries = boundaries.Substring(0, boundaries.LastIndexOf('['));
          boundaries += "[" + contentLength + "]";
          if (boundaries.IndexOf(':') < 0)
            boundaries = "tns:" + boundaries;
          this.Xml.WriteAttributeString("arrayType", WebNamespace.SoapEncNamespace, boundaries);
          currentSchema = arraySchema.Content;
          v.Content.Accept(this);
          this.Xml.WriteEndElement();
        }
      }
      else if (labelSchema is LabelledSchema)
      {
        ISchema contentSchema = ((LabelledSchema)labelSchema).Content;
        string namespaceUri = "tns:";
        if (v.Label == "Item")
          namespaceUri = "";
        if (contentSchema is VoidSchema)
        {
          this.Xml.WriteStartElement(namespaceUri + v.Label);
          Debug.Assert(v.Content is VoidValue);
          v.Content.Accept(this);
          this.Xml.WriteEndElement();
        }
        else if (contentSchema is BasicSchema)
        {
          this.Xml.WriteStartElement(namespaceUri + v.Label);
          switch (((BasicSchema)contentSchema).Type.Kind)
          {
            case BasicTypeKind.BOOL:
              this.Xml.WriteAttributeString(WebNamespace.XmlSchemaInstancePrefix + ":type",
              WebNamespace.XmlSchemaNamespacePrefix + ":boolean");
              break;
            case BasicTypeKind.INT:
              this.Xml.WriteAttributeString(WebNamespace.XmlSchemaInstancePrefix + ":type",
              WebNamespace.XmlSchemaNamespacePrefix + ":int");
              break;
            case BasicTypeKind.FLOAT:
              this.Xml.WriteAttributeString(WebNamespace.XmlSchemaInstancePrefix + ":type",
              WebNamespace.XmlSchemaNamespacePrefix + ":float");
              break;
            case BasicTypeKind.STRING:
              this.Xml.WriteAttributeString(WebNamespace.XmlSchemaInstancePrefix + ":type",
              WebNamespace.XmlSchemaNamespacePrefix + ":string");
              break;
            default: Debug.Assert(false, "Unhandled basic type");
              break;
          }
          currentSchema = contentSchema;
          v.Content.Accept(this);
          this.Xml.WriteEndElement();
   
        }
        else if (contentSchema is ConstantSchema)
        {
          if (v.Content is VoidValue) //nillable alement
          {
            this.Xml.WriteStartElement(namespaceUri + v.Label);
            this.Xml.WriteAttributeString(WebNamespace.XmlSchemaInstancePrefix + ":nil", "true");
            this.Xml.WriteEndElement();
          }
          else
          {
            this.Xml.WriteStartElement(namespaceUri + v.Label);
            this.Xml.WriteAttributeString("href", "#" + EncodedValueVisitor.typeReferenceSuffix + this.typeReferenceNumber);
            this.Xml.WriteEndElement();

            //Enqueue complex type definitions for later
            Pair<IValue, ISchema> valueSchema = new Pair<IValue, ISchema>(v, contentSchema);
            string idref = EncodedValueVisitor.typeReferenceSuffix + this.typeReferenceNumber;
            Pair<string, Pair<IValue, ISchema>> pair = new Pair<string, Pair<IValue, ISchema>>(idref, valueSchema);
            this.TypesDefinition.Enqueue(pair);
            this.typeReferenceNumber++;
          }
        }
        else if (contentSchema is SequenceSchema)
        {
          currentSchema = contentSchema;
          v.Content.Accept(this);
        }
      }
      this.nestedLabel--;

      if (this.nestedLabel == 0)
      {
        if (isFirstValue && base.Operation != null)
        { this.Xml.WriteEndElement(); }

        while (this.TypesDefinition.Count != 0)
        {
          this.nestedLabel = 0;
          Pair<string, Pair<IValue, ISchema>> p = this.TypesDefinition.Dequeue();
          currentSchema = p.Second.Second;
          this.Id = p.First;
          p.Second.First.Accept(this);
        }
      }
    }

    public override void VisitSequenceValue(SequenceValue v)
    {
      Debug.Assert(v.Top is LabelValue && (v.Tail is LabelValue || v.Tail is SequenceValue));
      bool isFirstValue = base.IsFirstValue;
      if (isFirstValue && base.Operation != null)
      {
        this.Xml.WriteStartElement("tns:" + base.Operation);
        base.IsFirstValue = false;
      }
      ISchema oldCurrentSchema = currentSchema;
      v.Top.Accept(this);
      currentSchema = oldCurrentSchema;
      v.Tail.Accept(this);
      if (isFirstValue && base.Operation != null)
      { this.Xml.WriteEndElement(); }
    }
  }
  
  public abstract class ValueUtil
  {
    private WSDLSTYLE style = WSDLSTYLE.DOCUMENT;
    public WSDLSTYLE Style { get { return style;} }

    public ValueUtil()
    { }

    public ValueUtil(WSDLSTYLE style)
    { this.style = style; }

    public static Encode MakeDocumentLiteralEncoding(ISchema schema, string targetNamespace)
    {
      ValueToXmlVisitor visitor = new LiteralValueVisitor(targetNamespace);
      ValueUtil valueUtil = new LiteralValueUtil();
      SoapHandler s;
      ISchema mySchema = null;

      if (schema is FunctionSchema)
      { mySchema = ((FunctionSchema)schema).Input; }
      else if (schema is ChannelSchema)
      { mySchema = ((ChannelSchema)schema).Content; }
      else
      { Debug.Assert(false); }

      s = new SoapHandler(targetNamespace, mySchema, visitor, valueUtil);

      return s.AddSoapToMessage;
    }

    public static Decode ParseDocumentLiteralEncoding(ISchema schema)
    {
      ValueUtil valueUtil = new LiteralValueUtil();
      SoapHandler s;
      ISchema mySchema = null;

      if (schema is FunctionSchema)
      { mySchema = ((FunctionSchema)schema).Output; }
      else if (schema is ChannelSchema)
      { mySchema = ((ChannelSchema)schema).Content; }
      else
      { Debug.Assert(false); }

      s = new SoapHandler(valueUtil, mySchema);

      return s.ReadResponse;
    }

    public static Encode MakeEncoding(Operation operation)
    {
      ValueToXmlVisitor visitor;
      ValueUtil valueUtil;
      SoapHandler s;
      SoapOverHttpBinding binding = (SoapOverHttpBinding)operation.Binding;
      ISchema schema = null;

      if (operation.Schema is FunctionSchema)
      { schema = ((FunctionSchema)operation.Schema).Input; }
      else if (operation.Schema is ChannelSchema)
      { schema = ((ChannelSchema)operation.Schema).Content; }
      else
      { Debug.Assert(false); }

      if ((binding.InputUse == WSDLUSE.LITERAL) && (binding.InputStyle == WSDLSTYLE.DOCUMENT))
      {
        visitor = new LiteralValueVisitor(operation.NamespaceUri);
        valueUtil = new LiteralValueUtil();
      }
      else if ((binding.InputUse == WSDLUSE.LITERAL) && (binding.InputStyle == WSDLSTYLE.RPC))
      {
        visitor = new LiteralValueVisitor(operation.NamespaceUri, operation.Name);
        valueUtil = new LiteralValueUtil();
      }
      else if ((binding.InputUse == WSDLUSE.ENCODED) && (binding.InputStyle == WSDLSTYLE.DOCUMENT))
      {
        visitor = new EncodedValueVisitor(operation.NamespaceUri, schema);
        valueUtil = new EncodedValueUtil();
      }
      else if ((binding.InputUse == WSDLUSE.ENCODED) && (binding.InputStyle == WSDLSTYLE.RPC))
      {
        visitor = new EncodedValueVisitor(operation.NamespaceUri, operation.Name, schema);
        valueUtil = new EncodedValueUtil();
      }
      else
      {
        Debug.Assert(false, "unsupported encoding");
        return null;
      }
      s = new SoapHandler(operation.NamespaceUri, operation.Schema, visitor, valueUtil);
      return s.AddSoapToMessage;
    }

    public static Decode MakeDecoding(Operation operation)
    {
      ValueUtil valueUtil;
      SoapHandler s;
      SoapOverHttpBinding binding = (SoapOverHttpBinding)operation.Binding;
      ISchema schema = null;

      if (operation.Schema is FunctionSchema)
      { schema = ((FunctionSchema)operation.Schema).Output; }
      else if (operation.Schema is ChannelSchema)
      { schema = ((ChannelSchema)operation.Schema).Content; }
      else
      { Debug.Assert(false); }

      if (binding.OutputUse == WSDLUSE.LITERAL)
      {
        valueUtil = new LiteralValueUtil(binding.OutputStyle);
      }
      else if (binding.OutputUse == WSDLUSE.ENCODED)
      {
        valueUtil = new EncodedValueUtil(binding.OutputStyle);
      }
      else
      {
        Debug.Assert(false, "unsupported encoding");
        return null;
      }
      s = new SoapHandler(valueUtil, schema);
      return s.ReadResponse;
    }

    public abstract IValue XmlToIValue(XmlNodeList nodes, ISchema schema);

    public static void SplitInputOutput(IValue v, out IValue input, out ChannelValue output)
    {
      if (v is SequenceValue)
      {
        SequenceValue seq = (SequenceValue)v;
        input = seq.Top;
        while (seq.Tail is SequenceValue)
        {
          input = SequenceValue.Make(input, ((SequenceValue)seq.Tail).Top);
          seq = (SequenceValue)seq.Tail;
        }

        Debug.Assert(seq.Tail is ChannelValue);
        output = (ChannelValue)seq.Tail;
      }
      else
      {
        input = new VoidValue();
        Debug.Assert(v is ChannelValue);
        output = (ChannelValue)v;
      }
    }

    protected IValue CreateSequenceValue(XmlNodeList nodes, AllSchema schema)
    {
      IList<string> labelsList = schema.GetElementLabelSet();  //ordine corretto delle label
      IDictionary<string, IValue> valueList = new SortedList<string, IValue>();  //ordine errato dei valori

      foreach (XmlNode node in nodes)
      {
        SchemaFromLabelVisitor visitor = new SchemaFromLabelVisitor(node.LocalName);
        schema.Accept(visitor);
        valueList.Add(node.LocalName, new LabelValue(node.LocalName, XmlToIValue(node.ChildNodes, visitor.Schema.Content)));
      }

      //if (valueList.Count == 0) 
      //  return new VoidValue();

      IValue sequence = null;
      foreach (string label in labelsList)
      {
        if (valueList.ContainsKey(label))
        {
          LabelValue value = (LabelValue)valueList[label];
          if (value.Content == null) { continue; }
          if (sequence == null)
            sequence = value;
          else 
            sequence = SequenceValue.Make(sequence, value);
        }
      }
      return sequence;
    }
  }

  public class LiteralValueUtil : ValueUtil
  {
    private bool firstIteration = true;

    public LiteralValueUtil()
    { }

    public LiteralValueUtil(WSDLSTYLE style)
      : base(style)
    { }

    public override IValue XmlToIValue(XmlNodeList nodes, ISchema schema)
    {
      if ((Style == WSDLSTYLE.RPC) && (firstIteration))
      {
        firstIteration = false;
        return XmlToIValue(nodes.Item(0).ChildNodes, schema);
      }

      if (schema is ConstantSchema)
      {
        return XmlToIValue(nodes, ((ConstantSchema)schema).Entry.Schema);
      }
      else if (schema is AllSchema)
      { 
        return CreateSequenceValue(nodes, (AllSchema)schema);
      }
      else
      {
        IValue result = null;
        if (nodes.Count == 0)
          result = new VoidValue();
        else foreach (XmlNode node in nodes)
          {
            IValue value = null;
            if (node is XmlText)
            {
              BasicSchema basicSchema = (BasicSchema)schema;
              switch (basicSchema.Type.Kind)
              {
                case BasicTypeKind.INT:
                  result = new IntValue(Int32.Parse(node.InnerText));
                  break;
                case BasicTypeKind.FLOAT:
                  result = new FloatValue(float.Parse(node.InnerText));
                  break;
                case BasicTypeKind.BOOL:
                  result = new BoolValue(Boolean.Parse(node.InnerText));
                  break;
                case BasicTypeKind.STRING:
                  result = new StringValue(node.InnerText);
                  break;
                default: Debug.Assert(false);
                  break;
              }
            }
            else
            {
              if (node.NamespaceURI == WebNamespace.PiDuceValueNamespace)
              {
                if (node.LocalName == "service")
                {
                  string wsdlLocation = node.Attributes["wsdl"].Value;
                  value = new RemoteService(wsdlLocation, Webclient.Download(wsdlLocation));
                }
                else if (node.LocalName == "chan")
                {
                  string wsdlLocation = node.Attributes["wsdl"].Value;
                  string operation = node.Attributes["operation"].Value;
                  ServiceValue service = new RemoteService(wsdlLocation, Webclient.Download(wsdlLocation));
                  value = service.Operations[operation];
                }
                else
                {
                  Debug.Assert(false, "Invalid PiDuce value");
                }
              }
              else
              {
                SchemaFromLabelVisitor visitor = new SchemaFromLabelVisitor(node.LocalName);
                schema.Accept(visitor);
                value = new LabelValue(node.LocalName, XmlToIValue(node.ChildNodes, visitor.Schema.Content));
              }
              if (result == null)
                result = value;
              else
                result = SequenceValue.Make(result, value);
            }
          }
        return result;
      }
    }
  }

  public class EncodedValueUtil : ValueUtil
  {
    private bool firstIteration = true;

    public EncodedValueUtil()
    { }

    public EncodedValueUtil(WSDLSTYLE style)
      : base(style)
    { }

    public override IValue XmlToIValue(XmlNodeList nodes, ISchema schema)
    {
      if ((Style == WSDLSTYLE.RPC) && (firstIteration))
      {
        firstIteration = false;
        return XmlToIValue(nodes.Item(0).ChildNodes, schema);
      }

      if (schema is ConstantSchema)
      {
        return XmlToIValue(nodes, ((ConstantSchema)schema).Entry.Schema);
      }
      else if (schema is AllSchema)
      {
        IValue value = CreateSequenceValue(nodes, (AllSchema)schema);
        return value;
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU Classpath; see the file COPYING.  If not, write to the
Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
02111-1307 USA.

Linking this library statically or dynamically with other modules is
making a combined work based on this library.  Thus, the terms and
conditions of the GNU General Public License cover the whole
combination.

As a special exception, the copyright holders of this library give you
permission to link this library with independent modules to produce an
executable, regardless of the license terms of these independent
modules, and to copy and distribute the resulting executable under
terms of your choice, provided that you also meet, for each linked
independent module, the terms and conditions of the license of that
module.  An independent module is a module which is not derived from
or based on this library.  If you modify this library, you may extend
this exception to your version of the library, but you are not
obligated to do so.  If you do not wish to do so, delete this
exception statement from your version. */


package java.awt;

import java.awt.image.ColorModel;

/**
 * This interface is for graphics which are formed as composites of others.
 * It combines {@link Graphics2D} shapes according to defined rules to form
 * the new image. Implementations of this interface must be immutable, because
 * they are not cloned when a Graphics2D container is cloned.
 *
 * <p>Since this can expose pixels to untrusted code, there is a security
 * check on custom objects, <code>readDisplayPixels</code>, to prevent leaking
 * restricted information graphically.
 *
 * @author Eric Blake (ebb9@email.byu.edu)
 * @see AlphaComposite
 * @see CompositeContext
 * @see Graphics2D#setComposite(Composite)
 * @since 1.2
 * @status updated to 1.4
 */
public interface Composite
{
  /**
   * Create a context state for performing the compositing operation. Several
   * contexts may exist for this object, in a multi-threaded environment.
   *
   * @param srcColorModel the color model of the source
   * @param dstColorModel the color model of the destination
   * @param hints hints for choosing between rendering alternatives
   */
  CompositeContext createContext(ColorModel srcColorModel,
                                 ColorModel dstColorModel,
                                 RenderingHints hints);
} // interface Composite
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        