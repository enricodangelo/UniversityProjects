// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.IO;
using System.Xml;
using System.Diagnostics;
using System.Collections.Generic;
using PiDuce.Common;
using PiDuce.Machine;
using PiDuce.Web;

namespace PiDuce.Machine
{
  public interface IValue
  {
    void Accept(IValueVisitor visitor);
#if NEW_SCHEMAS
		ISchema SchemaOf();
#else
    IType TypeOf();
#endif
  }

  public interface IValueVisitor
  {
    void VisitVoidValue(VoidValue v);
    void VisitIntValue(IntValue v);
    void VisitFloatValue(FloatValue v);
    void VisitBoolValue(BoolValue v);
    void VisitStringValue(StringValue v);
    void VisitChannelValue(ChannelValue v);
    void VisitServiceValue(ServiceValue v);
    void VisitLabelValue(LabelValue v);
    void VisitSequenceValue(SequenceValue v);
  }

	public abstract class Value : IValue
	{
    public abstract void Accept(IValueVisitor visitor);
#if NEW_SCHEMAS
		public abstract ISchema SchemaOf();
#else
		public abstract IType TypeOf();
#endif

		public static IValue MakeValueFromLiteral(IBasicTypeLiteral literal)
		{
			switch (literal.TypeOf().Kind) {
				case BasicTypeKind.BOOL:
					return new BoolValue(((BoolLiteral) literal).Value);
				case BasicTypeKind.INT:
					return new IntValue(((IntLiteral) literal).Value);
				case BasicTypeKind.FLOAT:
					return new FloatValue(((FloatLiteral) literal).Value);
				case BasicTypeKind.STRING:
					return new StringValue(((StringLiteral) literal).Value);
				default:
					Debug.Assert(false);
					return null;
			}
		}
	}

	public class VoidValue : Value
	{
    public override void Accept(IValueVisitor visitor)
    { visitor.VisitVoidValue(this); }

		public override string ToString()
		{ return "void"; }

#if NEW_SCHEMAS
		public override ISchema SchemaOf()
		{ return new VoidSchema(); }
#else
		public override IType TypeOf()
    { return new VoidType(); }
#endif
	}

	public abstract class BasicValue<T> : Value
	{
		private readonly T value;

		public T Value { get { return this.value; } }

		public BasicValue(T value)
		{ this.value = value; }

		public override string ToString()
		{ return value.ToString(); }

		public override bool Equals(Object obj)
		{
			if (obj is BasicValue<T>)
				return Value.Equals(((BasicValue<T>) obj).Value);
			else
				return false;
		}

		public override int GetHashCode()
		{ return value.GetHashCode(); }
	}

  public class BoolValue : BasicValue<bool>
  { 
    public BoolValue(bool value) : base(value)
		{ }

		public override void Accept(IValueVisitor visitor)
    { visitor.VisitBoolValue(this); }

    public static BoolValue operator !(BoolValue op)
    { return new BoolValue(!op.Value); }

#if NEW_SCHEMAS
		public override ISchema SchemaOf()
		{ return new BasicSchemaLiteralSchema(new BoolLiteral(this.Value)); }
#else
    public override IType TypeOf()
    { return new BasicTypeLiteralType(new BoolLiteral(this.Value)); }
#endif

		public override string ToString()
		{ return Value.ToString(); }
  }

	public class IntValue : BasicValue<int>
	{
		public IntValue(int value) : base(value)
		{ }

		public override void Accept(IValueVisitor visitor)
    { visitor.VisitIntValue(this); }

		public override string ToString()
		{ return Value.ToString(); }

#if NEW_SCHEMAS
		public override ISchema SchemaOf()
		{ return new BasicSchemaLiteralSchema(new IntLiteral(Value)); }
#else
		public override IType TypeOf()
    { return new BasicTypeLiteralType(new IntLiteral(Value)); }
#endif
	}

	public class FloatValue : BasicValue<float>
	{
		public FloatValue(float value) : base(value)
		{ }

    public override void Accept(IValueVisitor visitor)
    { visitor.VisitFloatValue(this); }

		public override string ToString()
		{ return Value.ToString(); }

#if NEW_SCHEMAS
		public override ISchema SchemaOf()
		{ return new BasicSchemaLiteralSchema(new FloatLiteral(Value)); }
#else
		public override IType TypeOf()
    { return new BasicTypeLiteralType(new FloatLiteral(Value)); }
#endif
	}

	public class StringValue : BasicValue<string>
	{
		public StringValue(string value) : base(value)
		{ }

    public override void Accept(IValueVisitor visitor)
    { visitor.VisitStringValue(this); }

		public override string ToString()
		{ return Value; }

#if NEW_SCHEMAS
		public override ISchema SchemaOf()
		{ return new BasicSchemaLiteralSchema(new StringLiteral(Value)); }
#else
		public override IType TypeOf()
		{ return new BasicTypeLiteralType(new StringLiteral(Value)); }
#endif
	}

  public abstract class ChannelValue : Value
  {
    private readonly string location;
    private readonly string operationName;
    private readonly string wsdlLocation;
    private readonly ISchema schema;

    protected ChannelValue() { }

    public ChannelValue(string wsdlLocation, string operationName, string location, ISchema schema)
    {
      Debug.Assert(schema != null);
      Debug.Assert(operationName != null && operationName != String.Empty);
      Debug.Assert(schema is ChannelSchema || schema is FunctionSchema);
      this.location = location;
      this.operationName = operationName;
      this.schema = schema;
      this.wsdlLocation = wsdlLocation;
    }

    public string Location { get { return location; } }
    public string OperationName { get { return operationName; } }
    public string WsdlLocation { get { return wsdlLocation; } }
    public ISchema Schema { get { return schema; } }

#if NEW_SCHEMAS
		public override ISchema SchemaOf()
		{ return Schema; }
		// LUCA: is this the schema of the channel or the schema of the
		// values carried by the channel? I'd prefer the latter, but it seems
		// like it's the former
#else
    public override IType TypeOf() 
    { return (new MachineSchemaToTypeVisitor()).SchemaToType(Schema); }
#endif

    public override void Accept(IValueVisitor visitor)
    { visitor.VisitChannelValue(this); }

    public override string ToString()
    { return "chan(" + wsdlLocation + "," + operationName + ")"; }

    public abstract bool IsLocalChannel();
    public abstract bool IsRemoteChannel();
    public abstract LocalChannel AsLocalChannel();
    public abstract RemoteChannel AsRemoteChannel();
  }

  public class LocalChannel : ChannelValue
  {
    public LocalChannel(string wsdlLocation, string operationName, string location, ISchema schema) 
      : base(wsdlLocation, operationName, location, schema) { }
    public override bool IsLocalChannel() { return true; }
    public override bool IsRemoteChannel() { return false; }
    public override LocalChannel AsLocalChannel() { return this; }
    public override RemoteChannel AsRemoteChannel() { throw new ApplicationException("Cannot cast from LocalChannel to RemoteChannel"); }
  }

	public class RemoteChannel : ChannelValue
	{
    private Operation operation;

    public string NamespaceUri { get { return operation.NamespaceUri; } }
    public SoapOverHttpBinding Binding { get { return (SoapOverHttpBinding)operation.Binding; } }
    public Operation Operation { get { return operation; } }

    public RemoteChannel(Operation operation) : base(operation.WsdlLocation, operation.Name, operation.ChanLocation, operation.Schema)
		{
      this.operation = operation; 
		}
    public override bool IsLocalChannel() { return false; }
    public override bool IsRemoteChannel() { return true; }
    public override LocalChannel AsLocalChannel() { throw new ApplicationException("Cannot cast from RemoteChannel to LocalChannel"); }
    public override RemoteChannel AsRemoteChannel() { return this; }
	}

  public abstract class ServiceValue : Value
  {
    protected readonly IDictionary<string, ChannelValue> operations;
    public IDictionary<string, ChannelValue> Operations { get { return this.operations; } }

    protected readonly string wsdlLocation;
    public string WsdlLocation { get { return wsdlLocation; } }

    public ServiceValue(string wsdlLocation)
    { 
      this.wsdlLocation = wsdlLocation;
      this.operations = new Dictionary<string, Chmodify this library, you may extend
this exception to your version of the library, but you are not
obligated to do so.  If you do not wish to do so, delete this
exception statement from your version. */


package javax.swing.event;

import java.util.EventObject;

import javax.swing.undo.UndoableEdit;

/**
 * UndoableEditEvent
 * @author Andrew Selkirk
 * @author Ronald Veldema
 */
public class UndoableEditEvent extends EventObject {

  private static final long serialVersionUID = 4418044561759134484L;

	//-------------------------------------------------------------
	// Variables --------------------------------------------------
	//-------------------------------------------------------------

	/**
	 * edit
	 */
	private UndoableEdit edit;


	//-------------------------------------------------------------
	// Initialization ---------------------------------------------
	//-------------------------------------------------------------

	/**
	 * Constructor UndoableEditEvent
	 * @param source TODO
	 * @param edit TODO
	 */
	public UndoableEditEvent(Object source, UndoableEdit edit) {
		super(source);
		this.edit = edit;
	} // UndoableEditEvent()


	//-------------------------------------------------------------
	// Methods ----------------------------------------------------
	//-------------------------------------------------------------

	/**
	 * getEdit
	 * @returns UndoableEdit
	 */
	public UndoableEdit getEdit() {
		return edit;
	} // getEdit()


} // UndoableEditEvent
                                       /* DocumentListener.java --
   Copyright (C) 2002 Free Software Foundation, Inc.

This file is part of GNU Classpath.

GNU Classpath is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU Classpath is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU Classpath; see the file COPYING.  If not, write to the
Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
02111-1307 USA.

Linking this library statically or dynamically with other modules is
making a combined work based on this library.  Thus, the terms and
conditions of the GNU General Public License cover the whole
combination.

As a special exception, the copyright holders of this library give you
permission to link this library with independent modules to produce an
executable, regardless of the license terms of these independent
modules, and to copy and distribute the resulting executable under
terms of your choice, provided that you also meet, for each linked
independent module, the terms and conditions of the license of that
module.  An independent module is a module which is not derived from
or based on this library.  If you modify this library, you may extend
this exception to your version of the library, but you are not
obligated to do so.  If you do not wish to do so, delete this
exception statement from your version. */

package javax.swing.event;

import java.util.EventListener;

/**
 * DocumentListener public interface
 * @author Andrew Selkirk
 * @author Ronald Veldema
 */
public interface DocumentListener extends EventListener {

	/**
	 * Changed update
	 * @param event Document Event
	 */
	void changedUpdate(DocumentEvent event);

	/**
	 * Insert update
	 * @param event Document Event
	 */
	void insertUpdate(DocumentEvent event);

	/**
	 * Remove update
	 * @param event Document Event
	 */
	void removeUpdate(DocumentEvent event);


} // DocumentListener
                