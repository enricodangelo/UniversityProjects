// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using PiDuce.Types;
using PiDuce.Common;

using IPatternType = PiDuce.Common.IType;
using IPatternSchema = PiDuce.Common.ISchema;

namespace PiDuce.Machine
{
  public class FullMatcherCommon
  {
    // VALUE COLLECTOR
    protected class ValueCollector
    {
      private class Range
      {
        private IValue value;
        private IFlatValue end;

				public IValue Value { get { return value; } }

        public Range()
        {
					this.value = new VoidValue();
          this.end = null;
        }

				public void Begin(IFlatValue v)
				{ value = Collect(value, v, end); }

				public void End(IFlatValue v)
				{ end = v; }

        private static IValue Collect(IValue acc, IFlatValue v, IFlatValue end)
        {
          if (Object.ReferenceEquals(v, end))
            return acc;
          else if (v is LiteralFlatValue)
            return SequenceValue.Make(((LiteralFlatValue) v).Value, Collect(acc, v.Next, end));
          else if (v is LabelledFlatValue)
            return SequenceValue.Make(((LabelledFlatValue) v).Value, Collect(acc, v.Next, end));
          else {
            Debug.Assert(false, v.ToString());
            return null;
          }
        }
      }

      private readonly IDictionary<int, Range> map;

      public ValueCollector(ISet<int> indexes)
      {
				this.map = new Dictionary<int, Range>();
				foreach (int index in indexes)
					this.map.Add(index, new Range());
			}

      public void Begin(int index, IFlatValue v)
      {
        // Console.WriteLine("collecting BEGIN {0} {1}", index, FlatValue.ToString(v));
        map[index].Begin(v);
      }

      public void End(int index, IFlatValue v)
      {
        // Console.WriteLine("collecting END {0} {1}", index, FlatValue.ToString(v));
				map[index].End(v);
      }

      public void Store(Env env)
      {
        foreach (KeyValuePair<int, Range> pair in map)
          env.Set(pair.Key, pair.Value.Value);
      }
    }

    // FLAT VALUES
    protected interface IFlatValue
    {
      IFlatValue Next { get; }
    }

    protected abstract class FlatValue : IFlatValue
    {
      private readonly IFlatValue next;

      public IFlatValue Next { get { return next; } }

      public FlatValue(IFlatValue next)
      { this.next = next; }

      public static string ToString(IFlatValue p)
      {
        StringBuilder builder = new StringBuilder();
        if (p == null)
          return "()";
        while (p != null) {
          builder.Append(p.ToString());
          if (p.Next != null) builder.Append(",");
          p = p.Next;
        }
        return builder.ToString();
      }
    }

    protected class LiteralFlatValue : FlatValue
    {
      public readonly IValue Value;

      public LiteralFlatValue(IValue value, IFlatValue next)
        : base(next)
      { this.Value = value; }

      public override string ToString()
      { return Value.ToString(); }
    }

    protected class LabelledFlatValue : FlatValue
    {
      public readonly LabelValue Value;

      public LabelledFlatValue(LabelValue value, IFlatValue next)
        : base(next)
      { this.Value = value; }

      public override string ToString()
      { return Value.ToString(); }
    }

    protected class EndLabelledFlatValue : FlatValue
    {
      public EndLabelledFlatValue(IFlatValue next)
        : base(next)
      { }

      public override string ToString()
      { return "]"; }
    }

    // BINDINGS
    protected interface IBinding
    {
      IBinding Next { get; }
      void Collect(ValueCollector collector);
      IBinding Copy(IBinding next);
    }

    protected abstract class Binding : IBinding
    {
      protected readonly ValueEntry entry;
      protected readonly IFlatValue value;
      private readonly IBinding next;

      public IBinding Next { get { return next; } }

      public Binding(ValueEntry entry, IFlatValue value, IBinding next)
      {
        this.entry = entry;
        this.value = value;
        this.next = next;
      }

      public abstract void Collect(ValueCollector collector);
      public abstract IBinding Copy(IBinding res);

      private static IBinding Reverse(IBinding acc, IBinding p)
      {
        if (p == null)
          return acc;
        else
          return Reverse(p.Copy(acc), p.Next);
      }

      public static IBinding Reverse(IBinding p)
      { return Reverse(null, p); }

      public static string ToString(IBinding p)
      {
        if (p == null)
          return "()";
        StringBuilder builder = new StringBuilder();
        while (p != null) {
          builder.Append(p.ToString());
          if (p.Next != null) builder.Append(",");
          p = p.Next;
        }
        return builder.ToString();
      }
    }

    protected class BeginBinding : Binding
    {
      public BeginBinding(ValueEntry entry, IFlatValue value, IBinding next)
        : base(entry, value, next)
      { }

      public override void Collect(ValueCollector collector)
      { collector.Begin(entry.Index, value); }

      public override IBinding Copy(IBinding next)
      { return new BeginBinding(entry, value, next); }

      public override string ToString()
      { return "{" + entry.Index.ToString(); }
    }

    protected class EndBinding : Binding
    {
      public EndBinding(ValueEntry entry, IFlatValue value, IBinding next)
        : base(entry, value, next)
      { }

      public override void Collect(ValueCollector collector)
      { collector.End(entry.Index, value); }

      public override IBinding Copy(IBinding next)
      { return new EndBinding(entry, value, next); }

      public override string ToString()
      { return entry.Index.ToString() + "}"; }
    }

		// AUXILIARY PATTERN VISITORS
		public class BindingsOfPatternTypeVisitor : AbstractTypeVisitor
		{
			private ArraySet<int> entries = new ArraySet<int>();

			public static ISet<int> GetIndexes(IPatternType type)
			{
				BindingsOfPatternTypeVisitor visitor = new BindingsOfPatternTypeVisitor();
				type.Accept(visitor);
				return visitor.entries;
			}

			public override void VisitBind(Bind t)
			{
				Debug.Assert(t.Entry is ValueEntry);
				entries.Add(((ValueEntry) t.Entry).Index);
			}
		}

    // FLAT PATTERNS
    protected interface IFlatPattern
    {
      IFlatPattern Next { get; }
    }

    protected abstract class FlatPattern : IFlatPattern
    {
      private readonly IFlatPattern next;

      public IFlatPattern Next { get { return next; } }

      public FlatPattern(IFlatPattern next)
      { this.next = next; }

      public static string ToString(IFlatPattern p)
      {
        if (p == null)
          return "()";
        StringBuilder builder = new StringBuilder();
        while (p != null) {
          builder.Append(p.ToString());
          if (p.Next != null) builder.Append(",");
          p = p.Next;
        }
        return builder.ToString();
      }
    }

    protected class TypeFlatPattern : FlatPattern
    {
      public readonly IType Type;

      public TypeFlatPattern(IType type, IFlatPattern next)
        : base(next)
      { this.Type = type; }

      public override string ToString()
      { return Type.ToString(); }
    }

    protected class RecFlatPattern : IFlatPattern
    {
      public IFlatPattern next;

      public IFlatPattern Next
      {
        get { return next; }
        set { next = value; }
      }

      public RecFlatPattern()
      { this.next = null; }

      public override string ToString()
      { return "ref"; }
    }

    protected class LabelledFlatPattern : FlatPattern
    {
      public readonly ILabelSet Labels;
      public readonly IFlatPattern Content;

      public LabelledFlatPattern(ILabelSet labels, IFlatPattern content, IFlatPattern next)
        : base(next)
      {
        this.Labels = labels;
        this.Content = content;
      }

      public override string ToString()
      { return Labels.ToString() + "[" + Content + "]"; }
    }

    protected class BeginBindFlatPattern : FlatPattern
    {
      public readonly ValueEntry Entry;

      public BeginBindFlatPattern(ValueEntry entry, IFlatPattern next)
        : base(next)
      { this.Entry = entry; }

      public override string ToString()
      { return "{" + Entry.Index.ToString(); }
    }

    protected class EndBindFlatPattern : FlatPattern
    {
      public readonly ValueEntry Entry;

      public EndBindFlatPattern(ValueEntry entry, IFlatPattern next)
        : base(next)
      { this.Entry = entry; }

      public override string ToString()
      { return Entry.Index.ToString() + "}"; }
    }

    protected class UnionFlatPattern : IFlatPattern
    {
      public readonly IFlatPattern Left;
      public readonly IFlatPattern Right;

      public IFlatPattern Next { get { return null; } }

      public UnionFlatPattern(IFlatPattern left, IFlatPattern right)
      {
        this.Left = left;
        this.Right = right;
      }

      public override string ToString()
      { return "(" + Left + "|" + Right + ")"; }
    }

    protected class FlattenPatternVisitor : ITypeVisitor
    {
      private readonly IDictionary<TypeRef, RecFlatPattern> map = new Dictionary<TypeRef, RecFlatPattern>();
      private IFlatPattern continuation;
      private IFlatPattern result;

      public IFlatPattern Flatten(IPatternType pattern, IFlatPattern continuation)
      {
        this.continuation = continuation;
        pattern.Accept(this);
        return result;
      }

      public void VisitBottom(BottomType p)
      { result = new TypeFlatPattern(p, null); }

      public void VisitVoid(VoidType p)
      { result = continuation; }

      public void VisitUnion(UnionType p)
      {
        IFlatPattern c = continuation;
        result = new UnionFlatPattern(Flatten(p.Fst, c), Flatten(p.Snd, c));
      }

      public void VisitConstantTypeName(ConstantType p)
      {
        if (map.ContainsKey(p.Entry)) {
          result = map[p.Entry];
        }  else {
          RecFlatPattern rec = new RecFlatPattern();
          map.Add(p.Entry, rec);
          rec.Next = Flatten(p.Entry.Type, continuation);
          map.Remove(p.Entry);
          result = rec;
        }
      }

      public void VisitSequence(SequenceType p)
      { result = Flatten(p.Top, Flatten(p.Tail, continuation)); }

      public void VisitLabelled(LabelledType p)
      {
        IFlatPattern c = continuation;
        result = new LabelledFlatPattern(p.Labels, Flatten(p.Content, null), c);
      }

			public void VisitBasicType(BasicType p)
			{ result = new TypeFlatPattern(p, continuation); }

      public void VisitBasicTypeLiteralType(BasicTypeLiteralType p)
      { result = new TypeFlatPattern(p, continuation); }

      public void VisitChan(ChannelType p)
      { result = new TypeFlatPattern(p, continuation); }

      public void VisitErrorType(ErrorType p)
      { Debug.Assert(false); }

      public void VisitBind(Bind p)
      {
        Debug.Assert(p.Entry is ValueEntry);
        result = new BeginBindFlatPattern((ValueEntry) p.Entry,
          Flatten(p.Content,
            new EndBindFlatPattern((ValueEntry) p.Entry, continuation)));
      }

			public void VisitServiceType(ServiceType p)
			{
				// TODO: implement record patterns
				Debug.Assert(false);
			}
    }

    protected static IFlatPattern UnfoldPattern(IPatternType p, IFlatPattern continuation)
    { return new FlattenPatternVisitor().Flatten(p, continuation); }

    protected static IFlatValue UnfoldValue(IValue v, IFlatValue continuation)
    {
      Debug.Assert(v != null, "v != null");
      if (v is VoidValue)
        return continuation;
      else if (v is IntValue || v is StringValue || v is ChannelValue || v is BoolValue || v is FloatValue)
        return new LiteralFlatValue(v, continuation);
      else if (v is LabelValue)
        return new LabelledFlatValue((LabelValue) v, continuation);
      else if (v is SequenceValue)
        return UnfoldValue(((SequenceValue) v).Top, UnfoldValue(((SequenceValue) v).Tail, continuation));
      else {
        Debug.Assert(false, "unknown value");
        return null;
      }
    }
  }

#if false
	// NAIVE FULL MATCHER
	public class NaiveFullMatcher : FullMatcherCommon, IMatcher
	{
		private readonly IList<IPatternType> patterns;
		// TODO: FIND APPROPRIATE PLACE FOR STORING THE TYPE CHECKER
		private static ITypeChecker typeChecker = new TypeChecker();

		public NaiveFullMatcher(IList<IPatternType> patterns)
		{ this.patterns = patterns; }

		private static bool Match(IValue v, IPatternType pattern, Env env)
		{
			try {
				IFlatValue m = Match(null, UnfoldValue(v, null), UnfoldPattern(pattern, null), null);
				ValueCollector collector = new ValueCollector();
				collector.Collect(m);
				collector.Store(env);
				return true;
			} catch (NoMatch) {
				return false;
			}
		}

		private static bool Contains<T>(Cell<T> p, T element)
		{
			if (p == null)
				return false;
			else
				return p.Contains(element);
		}

		private static IFlatValue Match(IFlatValue m, IFlatValue v, IFlatPattern f, Cell<TypeRef> visited)
		{
			Console.WriteLine("UltraMatch: matched {0} value {1} pattern {2}", FlatValue.ToString(m), FlatValue.ToString(v), FlatPattern.ToString(f));

			if (f == null && v == null)
				return m;
			else if (f == null)
				throw new NoMatch("null pattern");
			else if (f is RecFlatPattern && !Contains(visited, ((RecFlatPattern) f).Entry)) {
				return Match(m, v, UnfoldPattern(((RecFlatPattern) f).Entry.Type, f.Next), visited);
			} else if (f is BeginBindFlatPattern)
				return Match(PrependBeginBind(((BeginBindFlatPattern) f).Entry, m), v, f.Next, visited);
			else if (f is EndBindFlatPattern)
				return Match(PrependEndBind(((EndBindFlatPattern) f).Entry, m), v, f.Next, visited);
			else if (f is UnionFlatPattern) {
				try {
					return Match(m, v, UnfoldPattern(((UnionFlatPattern) f).Left, f.Next), visited);
				} catch (NoMatch) {
					return Match(m, v, UnfoldPattern(((UnionFlatPattern) f).Right, f.Next), visited);
				}
			} else if (v == null)
				throw new NoMatch("null value");
			else if (f is LabelledFlatPattern && v is LabelledFlatValue && ((LabelledFlatPattern) f).Labels.Has(((LabelledFlatValue) v).Value.Label))
				return Match(PrependLabelled(((LabelledFlatValue) v).Value, Match(null, ((LabelledFlatValue) v).Content, UnfoldPattern(((LabelledFlatPattern) f).Content, null), visited), m), v.Next, f.Next, null);
			else if (f is TypeFlatPattern && v is LiteralFlatValue && typeChecker.IsSubtype(((LiteralFlatValue) v).Value.TypeOf(), ((TypeFlatPattern) f).Type))
				return Match(PrependLiteral(((LiteralFlatValue) v).Value, m), v.Next, f.Next, null);
			else
				throw new NoMatch("no match");
		}

		public int Match(IValue v, Env env)
		{
		Console.WriteLine("ULTRA MATCHER STARTED ================================ {0}", v);
			for (int i = 0; i < patterns.Count; i++) {
				if (Match(v, patterns[i], env)) {
					return i;
				}
		Console.WriteLine("ULTRA MATCHER FAILED ================================");
			}
			return -1;
		}
	}
#endif

  public class SmartFullMatcher : FullMatcherCommon, IMatcher
  {
		private readonly IList<ISet<int>> entries;
    private readonly IBasicMatcher matcher;

    private enum MatchClass { DONE, VOID, REC, TYPE, LABEL, BEGIN_BIND, END_BIND }

    public SmartFullMatcher(IList<IPatternType> patterns)
    {
			this.entries = new List<ISet<int>>();
      List<IFlatPattern> flatPatterns = new List<IFlatPattern>();
      foreach (IPatternType pattern in patterns) {
				this.entries.Add(BindingsOfPatternTypeVisitor.GetIndexes(pattern));
        flatPatterns.Add(UnfoldPattern(pattern, null));
			}
      this.matcher = new Matrix(flatPatterns).Compile();
    }

    private interface IBasicMatcher
    {
      IBinding Match(IBinding m, Cell<IFlatValue> v, out int index);
      void Dump();
    }

    private class DoneMatcher : IBasicMatcher
    {
      private int row;

      public DoneMatcher(int row)
      { this.row = row; }

      public void Dump()
      { Console.WriteLine("<done row=\"{0}\"/>", row); }

      public IBinding Match(IBinding m, Cell<IFlatValue> v, out int index)
      {
        Debug.Assert(v == null);
        index = row;
        return m;
      }
    }

    private class VoidMatcher : IBasicMatcher
    {
      private readonly IBasicMatcher continuation;

      public VoidMatcher(IBasicMatcher continuation)
      { this.continuation = continuation; }

      public void Dump()
      {
        Console.WriteLine("<void>");
        continuation.Dump();
        Console.WriteLine("</void>");
      }

      public IBinding Match(IBinding m, Cell<IFlatValue> v, out int index)
      {
        Debug.Assert(v != null);
        if (v.Content == null)
          return continuation.Match(m, v.Next, out index);
        else
          throw new NoMatch("void");
      }
    }

    private class TypeMatcher : IBasicMatcher
    {
      private IType type;
      private IBasicMatcher continuation;

      private static ITypeChecker typeChecker = new TypeChecker();

      public TypeMatcher(IType type, IBasicMatcher continuation)
      {
        this.type = type;
        this.continuation = continuation;
      }

      public void Dump()
      {
        Console.WriteLine("<schema type=\"{0}\">", type);
        continuation.Dump();
        Console.WriteLine("</schema>");
      }

      public IBinding Match(IBinding m, Cell<IFlatValue> v, out int index)
      {
        Debug.Assert(v != null);
        if (v.Content is LiteralFlatValue) {
          IValue val = ((LiteralFlatValue) v.Content).Value;
					// Console.WriteLine("matching {0} against {1} result {2}", val, type, typeChecker.IsSubtype(val.TypeOf(), type));
          if (typeChecker.IsSubtype(val.TypeOf(), type))
            return continuation.Match(m, new Cell<IFlatValue>(v.Content.Next, v.Next), out index);
        }
        throw new NoMatch("schema");
      }
    }

    private abstract class BindMatcher : IBasicMatcher
    {
      protected ValueEntry entry;
      protected IBasicMatcher continuation;

      public BindMatcher(ValueEntry entry, IBasicMatcher continuation)
      {
        this.entry = entry;
        this.continuation = continuation;
      }

      public abstract void Dump();
      public abstract IBinding Match(IBinding m, Cell<IFlatValue> v, out int index);
    }

    private class BeginBindMatcher : BindMatcher
    {
      public BeginBindMatcher(ValueEntry entry, IBasicMatcher continuation)
        : base(entry, continuation)
      { }

      public override void Dump()
      {
        Console.WriteLine("<begin-bind index=\"{0}\">", entry.Index);
        continuation.Dump();
        Console.WriteLine("</begin-bind>");
      }

      public override IBinding Match(IBinding m, Cell<IFlatValue> v, out int index)
      {
        Debug.Assert(v != null);
        return continuation.Match(new BeginBinding(entry, v.Content, m), v, out index);
      }
    }

    private class EndBindMatcher : BindMatcher
    {
      public EndBindMatcher(ValueEntry entry, IBasicMatcher continuation)
        : base(entry, continuation)
      { }

      public override void Dump()
      {
        Console.WriteLine("<end-bind index=\"{0}\">", entry.Index);
        continuation.Dump();
        Console.WriteLine("</end-bind>");
      }

      public override IBinding Match(IBinding m, Cell<IFlatValue> v, out int index)
      {
        Debug.Assert(v != null);
        return continuation.Match(new EndBinding(entry, v.Content, m), v, out index);
      }
    }

    private class BacktrackMatcher : IBasicMatcher
    {
      private IBasicMatcher tryBranch;
      private IBasicMatcher catchBranch;

      public BacktrackMatcher(IBasicMatcher tryBranch, IBasicMatcher catchBranch)
      {
        this.tryBranch = tryBranch;
        this.catchBranch = catchBranch;
      }

      public void Dump()
      {
        Console.WriteLine("<try>");
        tryBranch.Dump();
        catchBranch.Dump();
        Console.WriteLine("</try>");
      }

      public IBinding Match(IBinding m, Cell<IFlatValue> v, out int index)
      {
        try {
          return tryBranch.Match(m, v, out index);
        } catch (NoMatch) {
          return catchBranch.Match(m, v, out index);
        }
      }
    }

    private class LabelledMatcher : IBasicMatcher
    {
      private ILabelSet labels;
      private IBasicMatcher continuation;

      public LabelledMatcher(ILabelSet labels, IBasicMatcher continuation)
      {
        this.labels = labels;
        this.continuation = continuation;
      }

      public void Dump()
      {
        Console.WriteLine("<begin-labelled labels=\"{0}\">", labels);
        continuation.Dump();
        Console.WriteLine("</begin-labelled>");
      }

      public IBinding Match(IBinding m, Cell<IFlatValue> v, out int index)
      {
        Debug.Assert(v != null);
        if (v.Content is LabelledFlatValue) {
          LabelledFlatValue lab = (LabelledFlatValue) v.Content;
          if (labels.Has(lab.Value.Label))
            return continuation.Match(m, new Cell<IFlatValue>(UnfoldValue(lab.Value.Content, null), new Cell<IFlatValue>(v.Content.Next, v.Next)), out index);
        }

        throw new NoMatch("label");
      }
    }

    private class RecMatcher : IBasicMatcher
    {
      private IBasicMatcher continuation;
      private bool visited = false;

      public IBasicMatcher Continuation { set { continuation = value; } }

      public RecMatcher()
      { this.continuation = null; }

      public void Dump()
      {
        if (visited)
          Console.WriteLine("<recurse/>");
        else {
          visited = true;
          Console.WriteLine("<rec>");
          continuation.Dump();
          Console.WriteLine("</rec>");
          visited = false;
        }
      }

      public IBinding Match(IBinding m, Cell<IFlatValue> v, out int index)
      { return continuation.Match(m, v, out index); }
    }

    private class Matrix
    {
      private List<Stack<IFlatPattern>> content;
      private List<int> rows;

      public Matrix(List<IFlatPattern> patterns)
      {
        this.content = new List<Stack<IFlatPattern>>();
        this.rows = new List<int>();
        for (int i = 0; i < patterns.Count; i++)
          rows.Add(i);

        foreach (IFlatPattern pat in patterns) {
          Stack<IFlatPattern> row = new Stack<IFlatPattern>();
          row.Push(pat);
          content.Add(row);
        }
      }

      private Matrix(List<Stack<IFlatPattern>> content, List<int> rows, int first, int last)
      {
        this.content = content.GetRange(first, last - first + 1);
        this.rows = rows.GetRange(first, last - first + 1);
      }

      private void Expand()
      {
        int i = 0;
        while (i < content.Count) {
          Stack<IFlatPattern> row = content[i];
          if (row.Count == 0)
            break;

          IFlatPattern pat = row.Peek();
          if (pat is UnionFlatPattern) {
            UnionFlatPattern u = (UnionFlatPattern) row.Pop();
            Stack<IFlatPattern> newRow = new Stack<IFlatPattern>(row);
            row.Push(u.Left);
            newRow.Push(u.Right);
            content.Insert(i + 1, newRow);
            rows.Insert(i, rows[i]);
          } else
            i++;
        }
      }

      private void Split(int n, out Matrix prefix, out Matrix rest)
      {
        //Console.WriteLine("splitting {0} {1}", n, content.Count);
        if (n < content.Count) {
          prefix = new Matrix(content, rows, 0, n - 1);
          rest = new Matrix(content, rows, n, content.Count - 1);
        } else {
          Debug.Assert(n == content.Count);
          prefix = this;
          rest = null;
        }
      }

      public MatchClass Classify(out Matrix prefix, out Matrix rest)
      {
        Expand();

        if (content[0].Count == 0) {
          prefix = this;
          rest = null;
          return MatchClass.DONE;
        }

        MatchClass state = MatchClass.DONE;
        int n = 0;
        bool done = false;
        while (!done && n < content.Count) {
          IFlatPattern pat = content[n].Peek();
          switch (state) {
            case MatchClass.DONE:
              if (pat == null)
                state = MatchClass.VOID;
              else if (pat is RecFlatPattern)
                state = MatchClass.REC;
              else if (pat is TypeFlatPattern)
                state = MatchClass.TYPE;
              else if (pat is LabelledFlatPattern)
                state = MatchClass.LABEL;
              else if (pat is BeginBindFlatPattern)
                state = MatchClass.BEGIN_BIND;
              else if (pat is EndBindFlatPattern)
                state = MatchClass.END_BIND;
              else {
                Debug.Assert(false, "impossible");
                state = MatchClass.DONE;
              }
              break;
            case MatchClass.VOID:
              done = !(pat == null);
              break;
            case MatchClass.REC:
              if (pat is RecFlatPattern)
                done = !Object.ReferenceEquals(pat, content[0].Peek());
              else
                done = true;
              break;
            case MatchClass.TYPE:
              if (pat is TypeFlatPattern) {
                IType t1 = ((TypeFlatPattern) pat).Type;
                IType t2 = ((TypeFlatPattern) content[0].Peek()).Type;
                ITypeChecker typeChecker = new TypeChecker();
                done = !(typeChecker.IsSubtype(t1, t2) && typeChecker.IsSubtype(t2, t1));
              } else
                done = true;
              break;
            case MatchClass.LABEL:
              if (pat is LabelledFlatPattern) {
                ILabelSet set1 = ((LabelledFlatPattern) pat).Labels;
                ILabelSet set2 = ((LabelledFlatPattern) content[0].Peek()).Labels;
                done = !set1.Includes(set2) || !set2.Includes(set1);
              } else
                done = true;
              break;
            case MatchClass.BEGIN_BIND:
              if (pat is BeginBindFlatPattern) {
                ValueEntry entry1 = ((BeginBindFlatPattern) pat).Entry;
                ValueEntry entry2 = ((BeginBindFlatPattern) content[0].Peek()).Entry;
                done = !Object.ReferenceEquals(entry1, entry2);
              } else
                done = true;
              break;
            case MatchClass.END_BIND:
              if (pat is EndBindFlatPattern) {
                ValueEntry entry1 = ((EndBindFlatPattern) pat).Entry;
                ValueEntry entry2 = ((EndBindFlatPattern) content[0].Peek()).Entry;
                done = !Object.ReferenceEquals(entry1, entry2);
              } else
                done = true;
              break;
            default:
              Debug.Assert(false);
              break;
          }

          if (!done) n++;
        }

        Debug.Assert(n > 0, "n > 0");
        Split(n, out prefix, out rest);
        //Console.WriteLine("classify discovered {0} {1}", state, FlatPattern.ToString(content[0]));
        return state;
      }

      private IFlatPattern ChopPattern()
      {
        IFlatPattern result = content[0].Peek();
        foreach (Stack<IFlatPattern> row in content)
          row.Push(row.Pop().Next);
        return result;
      }

      private void ChopColumn()
      {
        foreach (Stack<IFlatPattern> row in content) {
          //Debug.Assert(row.Peek() == null);
          row.Pop();
        }
      }

      private void Prepend(IFlatPattern pat)
      {
        foreach (Stack<IFlatPattern> row in content)
          row.Push(pat);
      }

      private class RecInfo
      {
        public readonly IBasicMatcher Matcher;
        public readonly int Depth;

        public RecInfo(IBasicMatcher matcher, int depth)
        {
          this.Matcher = matcher;
          this.Depth = depth;
        }
      }

      public IBasicMatcher Compile()
      { return Compile(null); }

      private IBasicMatcher Compile(Cell<RecFlatPattern> unguarded)
      { return Compile(new Dictionary<RecFlatPattern, RecInfo>(), unguarded); }

      private IBasicMatcher Compile(IDictionary<RecFlatPattern, RecInfo> rec, Cell<RecFlatPattern> unguarded)
      {
        Matrix prefix;
        Matrix rest;
        MatchClass cls = Classify(out e
  gnu_char_type(const unsigned long& __l) : character(__l) { } 

  // to_int_type
  operator unsigned long() const { return character; }
};

// char_traits specialization
struct gnu_char_traits
{
  typedef gnu_char_type	char_type;
  typedef long  		int_type;
  typedef std::streamoff 	off_type;
  typedef long   		state_type;
  typedef std::fpos<state_type>	pos_type;
  
  static void 
  assign(char_type& __c1, const char_type& __c2) { }
  
  static bool 
  eq(const char_type& __c1, const char_type& __c2) { return true; }
  
  static bool 
  lt(const char_type& __c1, const char_type& __c2) { return true; }
  
  static int 
  compare(const char_type* __s1, const char_type* __s2, size_t __n)
  { return 0; }
  
  static size_t
  length(const char_type* __s) { return 0; }
  
  static const char_type* 
  find(const char_type* __s, size_t __n, const char_type& __a)
  { return __s; }
  
  static char_type* 
  move(char_type* __s1, const char_type* __s2, size_t __n)
  { return __s1; }
  
  static char_type* 
  copy(char_type* __s1, const char_type* __s2, size_t __n)
  { return __s1; }
  
  static char_type* 
  assign(char_type* __s, size_t __n, char_type __a)
  { return __s; }
  
  static char_type 
  to_char_type(const int_type& __c)
  { return char_type(); }
  
  static int_type 
  to_int_type(const char_type& __c)
  { return int_type(); }
  
  static bool 
  eq_int_type(const int_type& __c1, const int_type& __c2)
  { return true; }
  
  static int_type 
  eof()
  { return int_type(); }
  
  static int_type 
  not_eof(const int_type& __c)
  { return int_type(); }
};

void test07()
{
  bool test __attribute__((unused)) = true;
  typedef std::basic_ifstream<gnu_char_type, gnu_char_traits> gnu_ifstr;

  try
    { 
      gnu_ifstr obj;
    }
  catch(std::exception& obj)
    { 
      test = false; 
      VERIFY( test );
    }
}

int main() 
{
  test07();
  return 0;
}



// more surf!!!
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            // 2003-03-26 B enjamin Kosnik  <bkoz@redhat.com>

// Copyright (C) 2003 Free Software Foundation, Inc.
//
// This file is part of the GNU ISO C++ Library.  This library is free
// software; you can redistribute it and/or modify it under the
// terms of the GNU General Public License as published by the
// Free Software Foundation; either version 2, or (at your option)
// any later version.

// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along
// with this library; see the file COPYING.  If not, write to the Free
// Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307,
// USA.

// 27.8.1.1 - Template class basic_filebuf 

#include <istream>
#include <fstream>

void test01()
{
  // Check for required base class.
  typedef std::ifstream test_type;
  typedef std::istream base_type;
  const test_type& obj = *new test_type();
  const base_type* base __attribute__((unused)) = &obj;
}

int main()
{
  test01();
  return 0;
}

// more surf!!!









                                                                                                                                                                                           