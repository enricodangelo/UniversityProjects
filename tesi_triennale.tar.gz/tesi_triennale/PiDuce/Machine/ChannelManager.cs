// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Net;
using System.Xml;
using System.IO;
using System.Runtime.Remoting.Messaging;
using PiDuce.Machine;
using PiDuce.Common;
using PiDuce.Web;
using PiDuce.Types;
using System.Diagnostics;

using IPattern = PiDuce.Common.ISchema;

namespace PiDuce.Machine
{
  public interface IInputRequest
  {
    bool Send(IValue value);
    void Empty();
  }

  public class Channel
  {
    private readonly string operationName;
    private readonly string location;
		private readonly ISchema schema;
    private readonly IList<IValue> valueQueue;
    private readonly IList<IInputRequest> inputQueue;

    public Channel(string operationName, string location, ISchema schema)
    {
      this.operationName = operationName;
      this.location = location;
      Debug.Assert(schema is ChannelSchema || schema is FunctionSchema);
      this.schema = schema;
      this.valueQueue = new List<IValue>();
      this.inputQueue = new List<IInputRequest>();
    }
		
    public void EnqueueRequest(IInputRequest request)
    { inputQueue.Add(request); }

    public void RemoveRequest(IInputRequest request)
    {
      Debug.Assert(inputQueue.Contains(request));
      inputQueue.Remove(request);
    }

    public IValue DequeueValue()
    {
      Debug.Assert(!Empty());
      IValue res = (IValue) valueQueue[0];
      valueQueue.Remove(res);

      if (Empty())
        foreach (IInputRequest request in inputQueue)
          request.Empty();

      return res;
    }

    public void Send(IValue v)
    {
      foreach (IInputRequest request in inputQueue)
        if (request.Send(v))
          return;

      valueQueue.Add(v);
    }

    public bool Empty()
    { return valueQueue.Count == 0; }

    public string OperationName { get { return operationName; } }
    public string Location { get { return location; } }
		public ISchema Schema { get { return schema; } }
  }

  public interface IManageOutputRequest
  {
    /// <summary>
    /// An asynchrnous output on a location channel
    /// </summary>
    /// <param name="location">the name of the channel</param>
    /// <param name="v">the value to send</param>
    /// <returns></returns>
    bool LocalOutput(string location, IValue v);
    /// <summary>
    /// Add to a local channel a linear forwarder to a remote channel
    /// </summary>
    /// <param name="source">the local channel</param>
    /// <param name="destination">the remote channel</param>
    /// <returns>true if the channel il local, false otherwise</returns>
    bool LinearForwarder(string source, string destination);
    /// <summary>
    /// A synchronous request on a local channel
    /// </summary>
    /// <param name="location">the name of the channel</param>
    /// <param name="v">the value to send</param>
    /// <param name="responsecontainer">the value container</param>
    /// <param name="outName">the name to use for labelling the response</param>
    /// <returns>true if the request have been processed</returns>
    bool ForeignRequest(string location, IValue v, ArrayList responsecontainer);
    /// <summary>
    /// Return the schema of a local service
    /// </summary>
    /// <param name="location">the name of the channel</param>
    /// <returns>the schema of the service</returns>
    ServiceSchema GetSchemaOfService(string location);
    /// <summary>
    /// Return the schema of a local channel
    /// </summary>
    /// <param name="location">the name of the channel</param>
    /// <returns>the schema of the channel</returns>
    ISchema GetSchemaOfChannel(string location);
    /// <summary>
    /// Return the operation name corresponding to a specific channel location
    /// </summary>
    /// <param name="location">the name of the channel</param>
    /// <returns>the operation name</returns>
    string GetOperationName(string location);
    /// <summary>
    /// Check if the channel is defined
    /// </summary>
    /// <param name="location">the name of the channel</param>
    /// <returns>true if the channel exists, false otherwise</returns>
    bool ContainsChannel(string location);
    /// <summary>
    /// Check if the service is defined
    /// </summary>
    /// <param name="location">the name of the service</param>
    /// <returns>true if the service exists, false otherwise</returns>
    bool ContainsService(string location);
    /// <summary>
    /// Add a service to a specific location
    /// </summary>
    /// <param name="location">the location where the service is added
    /// (a fresh location is used if the suggested one is already in use)
    /// </param>
    /// <param name="schema">the schema of the service</param>
    /// <returns>the location of the service</returns>
    string AddService(string location, ServiceSchema schema);
    /// <summary>
    /// Add a service in a fresh location
    /// </summary>
    /// <param name="location">the location where the service is added</param>
    /// <param name="schema">the schema of the service</param>
    /// <return>the location of the service</return>
    string AddService(ServiceSchema schema);
  }

  public abstract class AbstractInputRequest : IInputRequest
  {
    public virtual bool Send(IValue v)
    { return false; }

    public virtual void Empty()
    { }
  }

  public class DebugRequest : AbstractInputRequest
  {
    public override bool Send(IValue v)
    {
      LiteralValueVisitor visitor = new LiteralValueVisitor(PiDuce.Common.WebNamespace.PiDuceDefaultNamespace);
      v.Accept(visitor);
      Console.WriteLine(">>> " + visitor.Text);
      return true;
    }
  }

  public class ForeignRequest : AbstractInputRequest
  {
    private Channel channel;
    private ArrayList responseContainer;
    private ChannelManager chman;
            
    public ForeignRequest(Channel channel, ArrayList responseContainer, ChannelManager chman)
    {
      this.channel = channel;
      this.responseContainer = responseContainer;
      this.chman = chman;
    }

    public override bool Send(IValue v)
    {
      channel.RemoveRequest(this);
      string targetNamespace = WebNamespace.PiDuceDefaultNamespace;
      responseContainer.Add(v);
      chman.RemoveChannel(channel.Location);
      lock (responseContainer) {
        Monitor.Pulse(responseContainer);
      }
      return true;
    }
  }
          
  public class ForwardRequest : AbstractInputRequest
  {
    private Channel channel;
    private string forwardToLocation;
    private string SOAPAction;
            
    public ForwardRequest(Channel channel, string forwardToLocation, string SOAPAction)
    {
      this.channel = channel;
      this.forwardToLocation = forwardToLocation;
      this.SOAPAction = SOAPAction;
    }
		
    public override bool Send(IValue v)
    {
      channel.RemoveRequest(this);
      string targetNamespace = WebServer.LocalMachine;
      Encode e = ValueUtil.MakeDocumentLiteralEncoding(channel.Schema, targetNamespace);
      string data = e(v);
      new Webclient.UploadDelegate(new Webclient().Upload).
        BeginInvoke(forwardToLocation, data, SOAPAction, null, null);
      return true;
    }
  }
          
  public class SingleInputRequest : AbstractInputRequest
  {
    private Channel channel;
    private IPattern f;
		private Env e;
    private VmThread thread; // thread that made the request
		private XmlElement cont;

		public Channel Channel { get { return channel; } }

    public SingleInputRequest(Channel channel, IPattern f, Env e, VmThread thread, XmlElement cont)
    {
      this.channel = channel;
      this.f = f;
			this.e = e;
      this.thread = thread;	
      this.cont = cont;
    }

    public override bool Send(IValue v)
    {
      bool res = MatcherFactory.Make(f).Match(v, e) >= 0;
#if NEW_SCHEMAS
      Debug.Assert(res, f.ToString() + " does not match the value " + v.ToString() + " of schema " + v.SchemaOf());
#else
      Debug.Assert(res, f.ToString() + " does not match the value " + v.ToString() + " of schema " + v.TypeOf());
#endif
      channel.RemoveRequest(this);
			thread.Unblock(cont);
      return true;
    }
  }

  public class MultipleInputRequest : AbstractInputRequest
  {
    private Channel channel;
    private IPattern f;
		private Env e;
    private VmThread thread; // thread that made the request
    private XmlElement cont;

		public Channel Channel { get { return channel; } }

    public MultipleInputRequest(Channel channel, IPattern f, Env e, VmThread thread, XmlElement cont)
    {
      this.channel = channel;
      this.f = f;
			this.e = e;
      this.thread = thread;	
      this.cont = cont;
    }

    public override bool Send(IValue v)
    {
			Env newEnv = e.Clone();
      bool res = MatcherFactory.Make(f).Match(v, newEnv) >= 0;
#if NEW_SCHEMAS
      Debug.Assert(res, f.ToString() + " does not match the value " + v.ToString() + " of schema " + v.SchemaOf());
#else
      Debug.Assert(res, f.ToString() + " does not match the value " + v.ToString() + " of schema " + v.TypeOf());
#endif
			thread.Fork(cont, newEnv);
      return true;
    }
  }
  
  public class ChannelManager : IManageOutputRequest
  {
    private IDictionary<string, Channel> channels;
    private IDictionary<string, ServiceSchema> services;
    
    private int freshIndex = 0;
              
    public ChannelManager()
    { 
      channels = new Dictionary<string, Channel>();
      services = new Dictionary<string, ServiceSchema>();
    }

    public Channel GetChannel(string location)
    {
      lock (channels) {
        if (channels.ContainsKey(location))
          return (Channel) channels[location];
        else
          return null;
      }
    }

    public bool ContainsService(string location)
    { return services.ContainsKey(location); }

    public ServiceSchema GetSchemaOfService(string location)
    { return services[location]; }

    public bool ContainsChannel(string location)
    { return channels.ContainsKey(location); }

    public ISchema GetSchemaOfChannel(string location)
    { return channels[location].Schema; }

    public string GetOperationName(string location)
    { return channels[location].OperationName; }

    public string AddService(string location, ServiceSchema schema)
    {
      if (location.StartsWith("/"))
        location = location.Substring(1);
      if (!location.StartsWith("http://"))
        location = WebServer.LocalMachine + location;
      lock (services)
      {
        if (ContainsService(location) && location == WebServer.LocalMachine + "stdout")
          return location;
        else if (ContainsService(location))
          location = AddService(schema);  
        else
        {
          this.services[location] = schema;
          foreach (KeyValuePair<string, ISchema> operation in schema.Operations)
          {
            Channel channel = new Channel(operation.Key, location, operation.Value);
            if (location == WebServer.LocalMachine + "stdout")
              channel.EnqueueRequest(new DebugRequest());
            channels[location + "/" + operation.Key] = channel;
          }
        }
      }
      return location;
    }

    public string AddService(ServiceSchema schema)
    {
      lock (services)
      {
        string location = WebServer.LocalMachine + "service" + freshIndex;
        while (services.ContainsKey(location))
        {
          freshIndex++;
          location = WebServer.LocalMachine + "service" + freshIndex;
        }
        return AddService(location, schema);
      }
    }
                    
    public string AddChannel(string location, ISchema schema)
    {
      if (location.StartsWith("/")) location = location.Substring(1);
      lock (channels) {
        if (!channels.ContainsKey(location)) {
          Channel channel = new Channel(null, location, schema);
          channels[location] = channel;
          return location;
        } else 
					return AddChannel(schema);
      }
    }

    public string AddChannel(ISchema schema)
    {	
      lock(channels) {
        string location = WebServer.LocalMachine + "chan" + freshIndex;
        while (channels.ContainsKey(location)) {
          freshIndex++;
          location = WebServer.LocalMachine + "chan" + freshIndex.ToString();
        }
        channels[location] = new Channel(null, location, schema);
        return location;
      }                              
    }

    public void RemoveChannel(string location)		
    {
      lock(channels) {
        channels.Remove(location);
      }
    }
     
    public bool ForeignRequest(string location, IValue v, ArrayList responseContainer)
    {
      lock (channels) {
        if (!channels.ContainsKey(location))
          return false;
        if (channels[location].Schema is ChannelSchema)
          return false;

        ISchema outputSchema = ((FunctionSchema)channels[location].Schema).Output;
        //add a new channel for getting the response
        ChannelSchema reply = new ChannelSchema(outputSchema, ChannelType.CAPABILITY.OUT);
        string responseLocation = AddChannel(reply);
        LocalChannel replyChannel = new LocalChannel(
          responseLocation + "?wsdl", "default", responseLocation, reply);

        v = SequenceValue.Make(new LabelValue("arg",v), replyChannel);
        Channel ch = (Channel) channels[responseLocation];
        ch.EnqueueRequest(new ForeignRequest(ch, responseContainer, this));
        LocalOutput(location,v);
      }
      return true;
    }
              
    private void OnReceive(IAsyncResult iar)
    {
      try 
      {
        AsyncResult ar = (AsyncResult)iar;
        Webclient.UploadDelegate ud = (Webclient.UploadDelegate)ar.AsyncDelegate;
        Pair<ChannelValue, Decode> pars = (Pair<ChannelValue, Decode>)ar.AsyncState;
        ChannelValue chan = pars.First;
        XmlNodeList res = ud.EndInvoke(iar);
        if (res == null) return;
        IValue v = pars.Second(res);
        Output(chan, v);                        
      } 
      catch (Exception e)
      {
        MachineOutput.Print("An error occured getting the response from a synchronous remote serviceSchema " + e.Message);
      }
    }                                
                                
    public bool LinearForwarder(string source, string destination)
    {
      lock (channels)
      {
        if (channels.ContainsKey(source))
        {
          string soapaction = "soapAction/";
          Channel ch = (Channel) channels[source];
          ForwardRequest request = new ForwardRequest(ch, destination, soapaction);
          if (!ch.Empty())
            request.Send(ch.DequeueValue());
          else
            ch.EnqueueRequest(request);
          return true;
        } 
        else return false;
      }
    }

    public bool LocalOutput(string location, IValue v)
    {
      lock (channels) {
        if (channels.ContainsKey(location))
        {
          Channel c = channels[location];
          c.Send(v);
          return true;
        }
        else return false;
      }
    }
    
    public bool Output(ChannelValue channel, IValue v)
    {
      lock (channels) 
      {        
        if (channel.IsLocalChannel()) 
        {
          IValue inputValue = v;
          if (channel.Schema is FunctionSchema)
          {
            ChannelValue reply;
            ValueUtil.SplitInputOutput(v, out inputValue, out reply);
            inputValue = ((LabelValue)inputValue).Content; //removes arg[...]
          }
          return LocalOutput(channel.Location.ToString(), v); 
        }
        else
        {
            RemoteChannel remote = channel.AsRemoteChannel();
            if (channel.Schema is FunctionSchema) //the service is synchronous so the last parameter is the reply channel
            {
              IValue inputValue;
              ChannelValue reply;
							ValueUtil.SplitInputOutput(v, out inputValue, out reply);
              Pair<ChannelValue, Decode> pars = 
                new Pair<ChannelValue, Decode>(reply, ValueUtil.MakeDecoding(remote.Operation));
              inputValue = ((LabelValue)inputValue).Content; //removes arg[...]
              new Webclient.UploadDelegate(new Webclient().Upload).
                BeginInvoke(remote.Location, 
                  ValueUtil.MakeEncoding(remote.Operation)(inputValue), 
                  remote.Binding.SoapAction, new AsyncCallback(OnReceive), pars);
            }
            else if (channel.Schema is ChannelSchema) //the service is asynchronous
            {
              new Webclient.UploadDelegate(new Webclient().Upload).
                BeginInvoke(remote.Location,
                ValueUtil.MakeEncoding(remote.Operation)(v), 
                remote.Binding.SoapAction, null, null);
            }
        }		
        return true;
      }
    }
                    
		public void ServiceJoinSelect(IList<Channel> joinChannels,
																	IList<JoinInputDefinition.Row> rows,
																	IJoinAutomaton automaton,
																	Env env,
																	VmThread thread)
		{
			// we create the JoinInputDefinition which will attach the join input
			// requests to the joined channels. This has to be done first because
			// for the automaton to be updated correctly it is necessary that the
			// join input requets are in place. Unfortunately, it also means that
			// for a short period of time the automaton does not reflect the true
			// state of the channels, despite being attached to them.
			new JoinInputDefinition(true, joinChannels, rows, automaton, env, thread);

			//Console.WriteLine("InitAutomaton...");
			for (int i = 0; i < joinChannels.Count; i++) {
				Channel channel = (Channel) joinChannels[i];
				if (!channel.Empty()) {
					//Console.WriteLine("found nonempty channel " + i);
					automaton.Full(i);

					// the presence of an active row must be checked immediately
					// because the automaton may not be able to handle overlapping
					// patterns
					int row = automaton.ActiveRow;
					if (row >= 0) {
						Env newEnv = env.Clone();
						rows[row].Match(newEnv);
						thread.Fork(rows[row].Continuation, newEnv);
					}
				}
			}
		}

    public XmlElement JoinSelect(IList<Channel> joinChannels,
																 IList<JoinInputDefinition.Row> rows,
																 IJoinAutomaton automaton,
																 Env env,
																 VmThread sender)
    {
			//Console.WriteLine("InitAutomaton...");
			for (int i = 0; i < joinChannels.Count; i++) {
				Channel channel = (Channel) joinChannels[i];
				if (!channel.Empty()) {
					//Console.WriteLine("found nonempty channel " + i);
					automaton.Full(i);
					
					// the presence of an active row must be checked immediately
					// because the automaton may not be able to handle overlapping
					// patterns
					int row = automaton.ActiveRow;
					if (row >= 0) {
						rows[row].Match(env);
						return rows[row].Continuation;
					}
				}
			}

			//Console.WriteLine("no active row found");
			JoinInputDefinition def = new JoinInputDefinition(false, joinChannels, rows, automaton, env, sender);
			Debug.Assert(def != null);
			return null;
    }

    private delegate void RemoteInputDelegate(RemoteChannel channel, IPattern f, Env e, VmThread sender, XmlElement next);
                      
    private void RemoteInput(RemoteChannel channel, IPattern f, Env e, VmThread sender, XmlElement next)
    {
      lock (channels)
      {
        string fwdLocation = AddChannel(channel.Schema);
        Channel fwd = channels[fwdLocation];
        fwd.EnqueueRequest(new SingleInputRequest(fwd, f, e, sender, next));
        string request = "<LinearForwarder>";
        request += "<source>" + channel.Location + "</source>";
        request += "<destination>" + fwdLocation + "</destination>";
        request += "</LinearForwarder>";
        new Webclient().Upload(channel.Location, XmlUtil.AddSoap(request), WebServer.LINEARFWD);
      }
    }
                  
    public bool Input(ChannelValue channel, IPattern f, Env e, VmThread thread, XmlElement next, bool isService)
    {	
      lock (channels) {
        if (!channel.IsLoca��(*��܀���7_?G���{v.�T@(��bA���D�F� �1�
E�v�~߳�~0�jqSo{����#=�\��9�v�$���`Vo�a0�"�Pwy�k�8P��m"Svڌ�e�J\�z�y%+x��ӦR��ƬT����n����:��o2�5������Y�b;��s���x��jݣ�Z��~��[��L&�S6�7B7w��3�A:���NQ� ����������Ϛ^�I4�`c���/�7���a�dַ$��@��9\�	�\=�ˬg8d@�*�q9�:t�D�Y�w�Yvn��w�8ɲ�cb"��v	�1����2@p9��a�~�����U��q�&��9|#�J%t���PH�b{�6dQ�1���s)�K��P	E�^\Uv�o��g㦱���Y�*�'�?޷��vY�Ϡ��������Ԑq�ؼ�`yje�V��������x��C{��Ke��X��k�W�=��F2�G=����tGصP.�b�t�܏߷�	e�%���B>{�Z7���P{�J����ܥ	����;Gn��iJ�7{��F ��=���%w�vu�`;���ЉD�w�P���?��&���s\�����w�b|���"�>X{9�r4�f��tcװq��`4��;���� `=�W�R5~���~XwBf>`�G�]�u��S#?N�,Q���(���w�դ�ޞ��Mz��;Z������|rwҘyl����|]	�<?�n����CЋ-C����p��ϧ���;��o����f��|��y���#R_"�x^��|���LF��ݒ�/�M���~ f�:;v����o3�ԍ�%�!��W3�j��Ptٚ�y�I�l�X|D[��䭫s�g!~vn�)�G�eF+�x��Φ@�~>�þ��+�:��Q����s[�d?�K��<�8�/��~�d��*���zo^6�3��ç�.j���ꍔ�e)_E��[�ï��I�}�k���F�L���=e����VV�oVm�y˶�����8��?��.� <;̃�;�<�s�S7V��>����g�Gaq����o�ْ��0����0���4U�=+kǓ5�=/v�	��nm�0�����<5֚�z$+8o�;g�E�q<�8��o*����t��o������S�-Sl.�eH�}2�?������}��Bڵ���r>�~�Ђ<�#���m�x�v6%��.ۂ�F�a����� ��
���_TAAb��)����hI�M_�Oi��++�)+����e�������S��Ϛ��ݪ�AU����0
ʧ��a��aeн~V|��n���Ί����ǀ�_�|*�6Hr�K��_ڠ����R�u�KMf3�I����M�����$o��}&�d:)��f�t��eq������2c:HmJ`S���	��/�qk���lo������z��A�BˮY{�a���~�乷�v83�������?�������������*�vυx��� 0�-�NX\{�̼'�������On^H��)}���כ��d=yќS�E_���j%C^Z˵���)N��vu�6��ǀ�,86