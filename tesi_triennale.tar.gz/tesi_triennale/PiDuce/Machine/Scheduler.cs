// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using System.Diagnostics;
using System.Threading;
using System.Runtime.Remoting.Messaging;
using PiDuce.Machine;
using PiDuce.Web;
using PiDuce.Types;
using PiDuce.Common;

using IPattern = PiDuce.Common.ISchema;

namespace PiDuce.Machine
{
	public interface IScheduler
	{
		void Fork(XmlElement current, SchemaSymbolTable schemas, Env env);
		void AddProgram(String compiled);
	}
  
	public class Scheduler : IScheduler
	{
		private Queue ready;
		private ArrayList blocked;
		private ChannelManager chanman;
    private bool keepAlive;
    
		public Scheduler(ChannelManager chanman, bool keepAlive)
		{
			this.ready = new Queue();
			this.blocked = new ArrayList();
			this.chanman = chanman;
      this.keepAlive = keepAlive;
		}

		public void AddProgram(String compiled)
		{
			lock (this) {
				ready.Enqueue(new VmThread(compiled, this, chanman));
				Monitor.Pulse(this);
			}
		}

		public void Run()
		{
			bool run = true;
			do {
				VmThread thread;
        do {
          thread = null;
          lock (this) {
            if (ready.Count != 0)
              thread = (VmThread) ready.Dequeue();
          }

          if (thread != null)
						thread.Next();
        } while (thread != null);

        lock (this) {
          if (keepAlive || blocked.Count != 0) {
            Console.WriteLine("IDLE [" + WebServer.LocalMachine + "]");
            Monitor.Wait(this);
          }
					run = keepAlive || ready.Count != 0;
        }
			} while (run);

      Web.WebServer.Stop();
		}
    
    public void Fork(XmlElement current, SchemaSymbolTable schemas, Env e)
    {
      lock (this) {
        ready.Enqueue(new VmThread(current, schemas, e, this, chanman));
        Monitor.Pulse(this);
      }
    }

		public void Ready(VmThread thread)
		{
			lock (this) {
				ready.Enqueue(thread);
				Monitor.Pulse(this);
			}
		}

		public void Block(VmThread thread)
		{
			lock (this) {
				blocked.Add(thread);
			}
		}

		public void Unblock(VmThread thread)
		{
			lock (this) {
				Debug.Assert(blocked.Contains(thread));
				blocked.Remove(thread);
        Monitor.Pulse(this);
			}
		}

		public void Kill(VmThread thread)
		{
			lock (this) {
				Debug.Assert(blocked.Contains(thread));
				blocked.Remove(thread);
        Monitor.Pulse(this);
			}
		}
	}

  public class VmThread
	{
		private XmlNamespaceManager nsmgr; // FOR DOM
		private SchemaSymbolTable schemas;
		private Env e; // env of the thread
		private XmlElement current; // element to be executed
		private Scheduler scheduler;
		private ChannelManager chanman;
		private SchemaToTypeVisitor converter;
    private ISchemaChecker schemaChecker;
    
		bool CheckSchemas(XmlDocument program)
		{
      String error;
			foreach (XmlElement pattern in program.SelectNodes("//opcode:pattern", nsmgr)) {
        ISchema s = ParsePattern(pattern.FirstChild).Strip();
        if (!schemaChecker.IsCorrect(s, out error)) {
					MachineOutput.PrintError("Invalid pattern " + error);
					MachineOutput.Print(pattern.OuterXml);
					return false;
				}
			}

			foreach (XmlNode schema in program.SelectNodes("//opcode:schemadec",nsmgr)) {
        ISchema t = ParseSchema(schema.FirstChild);
				if (!schemaChecker.IsCorrect(t, out error)) {
					MachineOutput.PrintError("Invalid schema declaration " + error);
					MachineOutput.Print(schema.FirstChild.OuterXml);
					return false;
				}
			}

			foreach (XmlNode schema in program.SelectNodes("//opcode:new/operations/operation",nsmgr)) {
        ISchema t = ParseSchema(schema.FirstChild);
				if (!schemaChecker.IsCorrect(t, out error)) {
					MachineOutput.PrintError("Invalid new channel declaration " + error );
					MachineOutput.Print(schema.FirstChild.OuterXml);
					return false;
				}
			}

			foreach (XmlNode schema in program.SelectNodes("//opcode:import/operations/operation",nsmgr)) {
        ISchema t = ParseSchema(schema.FirstChild);
        if (!schemaChecker.IsCorrect(t, out error)) {
					MachineOutput.PrintError("Invalid new channel declaration");
					MachineOutput.Print(schema.FirstChild.OuterXml);
					return false;
				}

				if (schema.Attributes["wsdl"].Value == "")//TODO WSDL or LOCATION??
					program = null;
				else {
					if (schema.Attributes["location"].Value == "") {
						try {
              string wsdlLocation = schema.Attributes["wsdl"].Value;
              //we check only if the wsdl is available
              Web.Webclient.Download(wsdlLocation);
						} catch (Exception ex) {
							MachineOutput.PrintError("The channel at " + schema.Attributes["wsdl"].Value + " cannot be imported\n" + ex);
							return false;
						}
					}
				}
			}
			return true;
		}

		public VmThread(XmlElement current, SchemaSymbolTable schemas, Env e, Scheduler scheduler, ChannelManager chanman)
		{
#if NEW_SCHEMAS
			this.schemaChecker = new SchemaChecker();
#else
			// BEGIN WATCH THIS
			this.converter = new MachineSchemaToTypeVisitor();
    	this.schemaChecker = new SchemaChecker(this.converter);
			// END WATCH THIS
#endif

			this.current = current;
			this.scheduler = scheduler;
			nsmgr = new XmlNamespaceManager(current.OwnerDocument.NameTable);
			// are these needed? they should have been added by the other constructor
			nsmgr.AddNamespace("opcode", "http://cs.unibo.it/PiDuce/opcode");
			nsmgr.AddNamespace("value", "http://cs.unibo.it/PiDuce/value");
			this.schemas = schemas;
			this.e = e;
			this.chanman = chanman;
		}
		
		public VmThread(String xmlprogram, Scheduler scheduler, ChannelManager chanman)
		{
#if NEW_SCHEMAS
			this.schemaChecker = new SchemaChecker();
#else
			// BEGIN WATCH THIS
			this.converter = new MachineSchemaToTypeVisitor();
    	this.schemaChecker = new SchemaChecker(this.converter);
			// END WATCH THIS
#endif

			this.scheduler = scheduler;
			XmlDocument program = new XmlDocument();
			schemas = new SchemaSymbolTable();
			nsmgr = new XmlNamespaceManager(program.NameTable);
			nsmgr.AddNamespace("opcode", "http://cs.unibo.it/PiDuce/opcode");
			nsmgr.AddNamespace("value", "http://cs.unibo.it/PiDuce/value");
			program.LoadXml(xmlprogram);
			XmlNode schemadecl = program.SelectSingleNode("//opcode:PiDuce/opcode:schemadecl", nsmgr);
			foreach (XmlElement schema in schemadecl.ChildNodes) {
				SchemaEntry entry = schemas.New(schema.GetAttribute("name"), null);
				schemas.Add(entry);
			}

			foreach (XmlElement schema in schemadecl.ChildNodes) {
				SchemaEntry entry = schemas.Lookup(schema.GetAttribute("name"));
				entry.Schema = ParseSchema(schema.FirstChild);
        Debug.Assert(entry.Schema != null);
#if false
				ToStringSchemaVisitor v = new ToStringSchemaVisitor();
				entry.Schema.Accept(v);
				Console.WriteLine("resolving schema {0} {1}", entry.Name, v.ToString());
#endif
			}

			XmlElement process = (XmlElement) program.DocumentElement.SelectSingleNode("opcode:process", nsmgr);
			int envSize = Int32.Parse(process.GetAttribute("local-env-size"));
			e = new Env(envSize);
			current = (XmlElement) process.FirstChild;
			this.chanman = chanman;
			if (!CheckSchemas(program))
				current = null;
		}

		public void Ready(XmlElement next)
		{ 
			current = next;
			scheduler.Ready(this);
		}

		public void Block()
		{ scheduler.Block(this); }

		public void Unblock(XmlElement next)
		{
			scheduler.Unblock(this);
			Ready(next);
		}

		public void Fork(XmlElement current, Env e)
		{ scheduler.Fork(current, schemas, e); }

		public void Kill(string message)
		{
			Console.WriteLine(message);
			scheduler.Kill(this);
		}

		public void OnReceiveNewChannel(IAsyncResult result)
		{
      AsyncResult ar = (AsyncResult) result;
      Web.Webclient.UploadDelegate ud = (Web.Webclient.UploadDelegate)ar.AsyncDelegate;
      IList par = (IList) ar.AsyncState;
      int target = (int) par[1];
      try {
        XmlNode res = (ud.EndInvoke(result)).Item(0).FirstChild;
        string wsdlLocation = res.InnerText + "?wsdl";
        IValue service = new RemoteService(wsdlLocation); 
        e.Set(target, service);
        Unblock((XmlElement) par[0]);
      } catch (Exception ex) { 
        Kill("An error occured creating remote channel: " + ex.Message);
      }
		}
    
    public void OnReceiveWsdl(IAsyncResult result)
    {
      AsyncResult ar = (AsyncResult) result;
      Web.Webclient.DownloadDelegate ud = (Web.Webclient.DownloadDelegate)ar.AsyncDelegate;
      IList par = (IList) ar.AsyncState;
      int target = (int) par[1];
      string wsdlLocation = (String)par[2];
      try {
        string wsdl = ud.EndInvoke(result);
        IValue service = new RemoteService(wsdlLocation, wsdl); 
        e.Set(target, service);
        Unblock((XmlElement) par[0]);
      } catch (Exception ex) {
        Kill("An error occured importing the channel " + wsdlLocation + ": " + ex.Message);
      }
    }
    
		public void Next()		
		{
      if (current == null)
				return;

      //Console.WriteLine("Executing {0}", current.LocalName);
			switch (current.LocalName) {
				case "import":
				{
          String wsdl = current.GetAttribute("wsdl");
          IList par = new ArrayList();
          par.Add(current.ChildNodes[1]);
          par.Add(Int32.Parse(current.GetAttribute("target")));
          par.Add(wsdl);
					Block();
          new Web.Webclient.DownloadDelegate(Web.Webclient.Download).BeginInvoke(wsdl, new AsyncCallback(OnReceiveWsdl), par);
				}
				break;

				case "new":
				{
          IDictionary<string, ISchema> operations = new Dictionary<string, ISchema>();
          foreach (XmlNode operation in current.FirstChild.ChildNodes)
          {
            string operationName = operation.Attributes["name"].Value;
            operations[operationName] = ParseSchema(operation.FirstChild);
          }
          ServiceSchema schema = new ServiceSchema(operations);
					String location;
          if (current.HasAttribute("location")) 
          {
            location = current.GetAttribute("location");
            if (location.StartsWith("http://")) //remote new 
            {
              string localMachine = WebServer.LocalMachine;
              if (location.StartsWith(localMachine)) 
              { location = chanman.AddService(location.Substring(localMachine.Length), schema); } 
              else { //remote new
                string wsdl = WsdlGenerator.GenerateAbstractWsdl(schema, string.Empty, WebNamespace.PiDuceNamespace);
                string request = "<AddService><location>" + location + "</location><wsdl>" + wsdl + "</wsdl></AddService>";
                IList par = new ArrayList();
                par.Add(current.ChildNodes[1]);
                par.Add(Int32.Parse(current.GetAttribute("target")));
								Block();
                new Webclient.UploadDelegate(new Webclient().Upload).BeginInvoke(location, Common.XmlUtil.AddSoap(request), WebServer.ADDCHANNEL, new AsyncCallback(OnReceiveNewChannel), par);
								return;
              }
            } 
            else //local new
            { 
              location = chanman.AddService(location, schema); 
            }
          } 
          else // local new without location
          { location = chanman.AddService(schema); }
          int target = Int32.Parse(current.GetAttribute("target"));
          ServiceValue service = new LocalService(location + "?wsdl", schema.Operations);
          e.Set(target, service);
					Ready((XmlElement) current.ChildNodes[1]);
				}
				break;

				case "spawn":
				{
					XmlElement process = (XmlElement) current.FirstChild;
					int parentEnvSize = Int32.Parse(process.GetAttribute("parent-env-size"));
					int localEnvSize = Int32.Parse(process.GetAttribute("local-env-size"));
					scheduler.Fork((XmlElement) process.FirstChild, schemas, e.Clone(parentEnvSize, parentEnvSize + localEnvSize));
					Ready((XmlElement) current.ChildNodes[1]);
				}
				break;

 				case "join-select":
 				{
					bool isService = Boolean.Parse(current.GetAttribute("service"));

					IList<Channel> channels = new List<Channel>();
 					IList<JoinInputDefinition.Row> rows = new List<JoinInputDefinition.Row>();
 					foreach (XmlElement row in current.SelectNodes("opcode:branch", nsmgr)) {
 						IList<JoinInputDefinition.Atom> atoms = new List<JoinInputDefinition.Atom>();
 						foreach (XmlElement atom in row.SelectNodes("opcode:receive", nsmgr)) {
							int atomIndex = Int32.Parse(atom.GetAttribute("index"));
              ChannelValue chan = (ChannelValue)ParseExpression((XmlElement)atom.ChildNodes[0].FirstChild, e);
              string location = chan.Location.ToString();
              Channel ch = chanman.GetChannel(location);
 							IPattern pattern = ParsePattern(atom.ChildNodes[1].FirstChild);
							if (!channels.Contains(ch)) 
                channels.Add(ch);
 							System.Diagnostics.Debug.Assert(ch != null);
 							atoms.Add(new JoinInputDefinition.Atom(ch, atomIndex, pattern));
 						}
 						rows.Add(new JoinInputDefinition.Row(atoms, (XmlElement) row.SelectSingleNode("opcode:process", nsmgr).FirstChild));
 					}

					IJoinAutomaton automaton = new JoinAutomaton(rows);
					//IJoinAutomaton automaton = new NaiveJoinAutomaton(rows);

					if (isService) {
						chanman.ServiceJoinSelect(channels, rows, automaton, e, this);
					} else {
						Block();
						XmlElement next = chanman.JoinSelect(channels, rows, automaton, e, this);
						if (next != null) Unblock(next);
					}
 				}
				break;

				case "match":
				{
					IValue v = ParseExpression((XmlElement) current.SelectSingleNode("opcode:expression", nsmgr).FirstChild, e);
					IList<IPattern> patterns = new List<IPattern>();
					ArrayList conts = new ArrayList();
					foreach (XmlElement branch in current.SelectNodes("opcode:branch", nsmgr)) {
						patterns.Add(ParsePattern(branch.SelectSingleNode("opcode:pattern", nsmgr).FirstChild));
						conts.Add((XmlElement) branch.SelectSingleNode("opcode:process", nsmgr).FirstChild);
					}

					Ready((XmlElement) conts[MatcherFactory.Make(patterns).Match(v, e)]);
				}
				break;

				case "send":
				{
          ChannelValue chan = (ChannelValue)ParseExpression((XmlElement) current.FirstChild.FirstChild, e);
					IValue v = ParseExpression((XmlElement) current.ChildNodes[1].FirstChild, e);
					chanman.Output(chan, v);
					Ready((XmlElement) current.NextSibling);
				}
				break;

				case "receive":
				{
          ChannelValue chan = (ChannelValue)ParseExpression((XmlElement) current.FirstChild.FirstChild, e);
          IPattern f = ParsePattern(current.ChildNodes[1].FirstChild);
					Block();
					XmlElement next = (XmlElement) current.ChildNodes[2];
					if (chanman.Input(chan, f, e, this, next, false))
						Unblock(next);
				}
				break;

				case "service":
				{
          ChannelValue chan = (ChannelValue) ParseExpression((XmlElement)current.FirstChild.FirstChild, e);
          IPattern f = ParsePattern(current.ChildNodes[1].FirstChild);
					chanman.Input(chan, f, e, this, (XmlElement) current.ChildNodes[2], true);
				}
				break;
			}
		}

#if false
		private static IThreadInstruction ParseCode(XmlElement node)
		{
			Debug.Assert(node != null);
			Debug.Assert(node.NamespaceURI == "http://cs.unibo.it/PiDuce/opcode");
			switch (node.LocalName) {
				case "import":
					return new ImportThreadInstruction(
						node.GetAttribute("wsdl"),
						Int32.Parse(node.GetAttribute("target")),
						ParseCode((XmlElement) node.ChildNodes[1]));
				case "new":
					return new NewThreadInstruction(
						ParseSchema((XmlElement) node.FirstChild),
						node.GetAttribute("location"),
            Int32.Parse(node.GetAttribute("target")),
						ParseCode((XmlElement) node.ChildNodes[1]));
				case "spawn":
					return new SpawnThreadInstruction(
						Int32.Parse(process.GetAttribute("parent-env-size")),
						Int32.Parse(process.GetAttribute("local-env-size")),
						ParseCode((XmlElement) node.FirstChild),
						ParseCode((XmlElement) node.ChildNodes[1]));
 				case "join-select":
					{
						IList<Channel> channels = new List<Channel>();
						IList<JoinInputDefinition.Row> rows = new List<JoinInputDefinition.Row>();
						foreach (XmlElement row in node.SelectNodes("opcode:branch", nsmgr)) {
							IList<JoinInputDefinition.Atom> atoms = new List<JoinInputDefinition.Atom>();
							foreach (XmlElement atom in row.SelectNodes("opcode:receive", nsmgr)) {
								int atomIndex = Int32.Parse(atom.GetAttribute("index"));
								int channelIndex = Int32.Parse(atom.GetAttribute("ch-index"));
								Debug.Assert(atomIndex >= 0);
								IPattern pattern = ParsePattern(atom.SelectSingleNode("opcode:pattern", nsmgr).FirstChild);
								string location = ((ChannelValue) e.Get(channelIndex)).Location;
								Channel ch = chanman.GetChannel(location);
								if (!channels.Contains(ch)) channels.Add(ch);
								System.Diagnostics.Debug.Assert(ch != null);
								atoms.Add(new JoinInputDefinition.Atom(ch, atomIndex, pattern));
							}
							rows.Add(new JoinInputDefinition.Row(atoms, (XmlElement) row.SelectSingleNode("opcode:process", nsmgr).FirstChild));
						}
						bool isService = Boolean.Parse(node.GetAttribute("service"));
						return new JoinSelectThreadInstruction(channels, rows, isService);
					}
				case "match":
					{
						IExpression expr = ParseExpression((XmlElement) node.SelectSingleNode("opcode:expression", nsmgr).FirstChild);
						IList<IPattern> patterns = new List<IPattern>();
						IList<IThreadInstruction> conts = new List<IThreadInstruction>();
						foreach (XmlElement branch in node.SelectNodes("opcode:branch", nsmgr)) {
							patterns.Add(ParsePattern(branch.SelectSingleNode("opcode:pattern", nsmgr).FirstChild));
							conts.Add(ParseCode((XmlElement) branch.SelectSingleNode("opcode:process", nsmgr).FirstChild));
						}
						return new MatchThreadInstruction(expr, patterns, conts);
					}
				case "send":
					return new SendThreadInstruction(
						Int32.Parse(node.GetAttribute("ch")),
						ParseExpression((XmlElement) node.SelectSingleNode("opcode:expression", nsmgr).FirstChild),
						ParseCode((XmlElement) node.NextSibling));
				case "receive":
					return new ReceiveThreadInstruction(
						Int32.Parse(node.GetAttribute("ch")),
						ParsePattern(node.SelectSingleNode("opcode:pattern", nsmgr).FirstChild),
						false,
						ParseCode((XmlElement) node.ChildNodes[1]));
				case "service":
					return new ReceiveThreadInstruction(
						Int32.Parse(node.GetAttribute("ch")),
						ParsePattern(node.SelectSingleNode("opcode:pattern", nsmgr).FirstChild),
						true,
						ParseCode((XmlElement) node.ChildNodes[1]));
				default:
					Debug.Assert(false, "illegal instruction - " + node.LocalName);
					return null;
			}
		}
#endif

		private static IBasicTypeLiteral ParseLiteral(XmlElement node)
		{
			Debug.Assert(node != null);
			Debug.Assert(node.NamespaceURI == "http://cs.unibo.it/PiDuce/opcode");
			Debug.Assert(node.LocalName == "literal");
			switch (node.GetAttribute("type")) {
				case "bool":
					return new BoolLiteral(Boolean.Parse(node.InnerText));
				case "int":
					return new IntLiteral(Int32.Parse(node.InnerText));
				case "float":
					return new FloatLiteral(Single.Parse(node.InnerText));
				case "string":
					return new StringLiteral(node.InnerText);
				default:
					Debug.Assert(false);
					return null;
			}
		}

		private IValue ParseExpression(XmlElement node, Env env)
		{
			Debug.Assert(node != null);
			Debug.Assert(node.NamespaceURI == "http://cs.unibo.it/PiDuce/opcode");
			switch (node.LocalName) {
				case "void":
					return new VoidValue();
				case "load":
					{
						int index = Int32.Parse(node.GetAttribute("index"));
						return e.Get(index);
					}
        case "select":
          {
            string field = node.GetAttribute("field");
            int index = Int32.Parse(node.FirstChild.Attributes["index"].Value);
            ServiceValue s = (ServiceValue)e.Get(index);
            return s.Operations[field];
          }
				case "literal":
					return Value.MakeValueFromLiteral(ParseLiteral(node));
				case "seq":
					{
						IValue v1 = ParseExpression((XmlElement) node.ChildNodes[0], env);
						IValue v2 = ParseExpression((XmlElement) node.ChildNodes[1], env);
						return SequenceValue.Make(v1, v2);
					}
				case "binop":
					{
						IValue v1 = ParseExpression((XmlElement) node.ChildNodes[0], env);
						IValue v2 = ParseExpression((XmlElement) node.ChildNodes[1], env);

						// PROMOTION
						if (v1 is IntValue && v2 is FloatValue)
							v1 = new FloatValue(((IntValue) v1).Value);
						else if (v1 is FloatValue && v2 is IntValue)
							v2 = new FloatValue(((IntValue) v2).Value);

						string op = node.GetAttribute("op");
						if (v1 is BoolValue) {
							Debug.Assert(v2 is BoolValue);
							bool b1 = ((BoolValue) v1).Value;
							bool b2 = ((BoolValue) v2).Value;
							switch (op) {
								case "eq": return new BoolValue(b1 == b2);
								case "neq": return new BoolValue(b1 != b2);
							}
						} else if (v1 is IntValue) {
							Debug.Assert(v2 is IntValue);
							int n1 = ((IntValue) v1).Value;
							int n2 = ((IntValue) v2).Value;
							switch (op) {
								case "add": return new IntValue(n1 + n2);
								case "sub": return new IntValue(n1 - n2);
								case "mul": return new IntValue(n1 * n2);
								case "div": return new IntValue(n1 / n2);
								case "eq": return new BoolValue(n1 == n2);
								case "neq": return new BoolValue(n1 != n2);
								case "gt": return new BoolValue(n1 > n2);
								case "ge": return new BoolValue(n1 >= n2);
								case "lt": return new BoolValue(n1 < n2);
								case "le": return new BoolValue(n1 <= n2);
							}
						} else if (v1 is FloatValue) {
							Debug.Assert(v2 is FloatValue);
							float f1 = ((FloatValue) v1).Value;
							float f2 = ((FloatValue) v2).Value;
							switch (op) {
								case "add": return new FloatValue(f1 + f2);
								case "sub": return new FloatValue(f1 - f2);
								case "mul": return new FloatValue(f1 * f2);
								case "div": return new FloatValue(f1 / f2);
								case "eq": return new BoolValue(f1 == f2);
								case "neq": return new BoolValue(f1 != f2);
								case "gt": return new BoolValue(f1 > f2);
								case "ge": return new BoolValue(f1 >= f2);
								case "lt": return new BoolValue(f1 < f2);
								case "le": return new BoolValue(f1 <= f2);
							}
						} else if (v1 is StringValue) {
							Debug.Assert(v2 is StringValue);
							string s1 = ((StringValue) v1).Value;
							string s2 = ((StringValue) v2).Value;
							switch (op) {
								case "eq": return new BoolValue(s1 == s2);
								case "neq": return new BoolValue(s1 != s2);
							}
						}
						throw new ApplicationException("invalid binary operator " + op);
					}

				case "unop":
					{
						IValue v = ParseExpression((XmlElement) node.FirstChild, env);
						string op = node.GetAttribute("op");
						if (v is IntValue) {
							int n = ((IntValue) v).Value;
							switch (op) {
								case "neg": return new IntValue(-n);
							}
						} else if (v is FloatValue) {
							float f = ((FloatValue) v).Value;
							switch (op) {
								case "neg": return new FloatValue(-f);
							}
						}
						throw new ApplicationException("invalid unary operator " + op);
					}

				case "labelled":
					return new LabelValue(node.GetAttribute("label"), ParseExpression((XmlElement) node.FirstChild, env));
				default:
					throw new ApplicationException("invalid expression " + node.LocalName);
			}
		}

#if false
		private IPattern ParsePattern(XmlNode schema)
		{
			if (schema.NamespaceURI != "http://cs.unibo.it/PiDuce/opcode")
				throw new ApplicationException("Invalid schema in source");
			switch (schema.LocalName)
			{
				case "schema":				
					return SchemaToType(ParseSchema(schema.FirstChild));
				case "sequence":
					return new SequenceType(ParsePattern(schema.FirstChild).AsLabelledType(), ParsePattern(schema.ChildNodes[1]));
				case "labelled":
					return new LabelledType(LabelSet.FromXml(schema.FirstChild), ParsePattern(schema.ChildNodes[1]));
				case "bind":
					return new Bind(Int32.Parse(schema.Attributes["index", ""].Value), ParsePattern(schema.ChildNodes[0]));
				default:
					throw new ApplicationException("Invalid pattern");
			}
		}
#endif

		private IPattern ParsePattern(XmlNode pattern)
		{ return ParseSchema(pattern); }

		private ISchema ParseSchema(XmlNode schema)
		{
			ISchema s = ParseSchemaAux(schema);
			new ResolveNamesSchemaVisitor(schemas).ResolveNames(s);
			return s;
		}

		private static ISchema ParseSchemaAux(XmlNode schema)
		{
			Debug.Assert(schema != null);
			if (schema.NamespaceURI != "http://cs.unibo.it/PiDuce/opcode")
				throw new ApplicationException("Wrong namespace: " + schema.LocalName + " at " + schema.NamespaceURI);
			switch (schema.LocalName)
			{
				case "labelled":
					return new LabelledSchema(LabelSet.FromXml(schema.FirstChild), ParseSchemaAux(schema.ChildNodes[1]));
				case "sequence":
					return new SequenceSchema(ParseSchemaAux(schema.ChildNodes[0]), ParseSchemaAux(schema.ChildNodes[1]));
				case "union":
					return UnionSchema.Make(ParseSchemaAux(schema.ChildNodes[0]), ParseSchemaAux(schema.ChildNodes[1]));
				case "repeat":
					{
						string minOccurs = schema.Attributes["minOccurs", ""].Value;
						string maxOccurs = schema.Attributes["maxOccurs", ""].Value;
						if (minOccurs == "0" && maxOccurs == "unbound")
							return new StarSchema(ParseSchemaAux(schema.FirstChild));
						else if (minOccurs == "1" && maxOccurs == "unbound")
							return new PlusSchema(ParseSchemaAux(schema.FirstChild));
						else {
							Debug.Assert(maxOccurs != "unbound");
							return new RepetitionSchema(ParseSchemaAux(schema.FirstChild), UInt32.Parse(minOccurs), UInt32.Parse(maxOccurs));
						}
					}
				case "void":
					return new VoidSchema();
				case "literal":
					return new BasicSchemaLiteralSchema(ParseLiteral((XmlElement) schema));
				case "bool":
					return new BasicSchema(new BoolType());
				case "int":
					return new BasicSchema(new IntType());
				case "float":
					return new BasicSchema(new FloatType());
				case "string":
					return new BasicSchema(new StringType());
				case "ref":
					return new ConstantSchema(schema.Attributes["name", ""].Value);
				case "channel":
            return new ChannelSchema(ParseSchemaAux(schema.FirstChild), ParseCapability(schema.Attributes["capability", ""].Value));
				case "function":
					return new FunctionSchema(ParseSchemaAux(schema.ChildNodes[0]), ParseSchemaAux(schema.ChildNodes[1]));
        case "service":
          IDictionary<string, ISchema> s = new Dictionary<string, ISchema>();
          foreach (XmlNode operation in schema.ChildNodes)
          { s[operation.Attributes["name"].Value] = ParseSchemaAux(operation.FirstChild); }
          return new ServiceSchema(s);
				case "bind":
					{
						string name = schema.Attributes["name", ""].Value;
						IEntry entry = new ValueEntry(name, null, Int32.Parse(schema.Attributes["index", ""].Value));
						return new BindSchema(name, ParseSchemaAux(schema.FirstChild), entry);
					}
				default:
					throw new ApplicationException("Invalid schema - " + schema.LocalName);
			}
		}

    private static ChannelType.CAPABILITY ParseCapability(string capability)
    {
      switch (capability)
      {
        case "I":
          return ChannelType.CAPABILITY.IN;
        case "O":
          return ChannelType.CAPABILITY.OUT;
        case "IO":
          return ChannelType.CAPABILITY.INOUT;
        default:
          throw new ApplicationException("Invalid capability");
      }
    }

#if false
		private IType ParseSchemaAux(XmlNode schema)
		{
			if (schema.NamespaceURI != "http://cs.unibo.it/PiDuce/opcode")
				throw new ApplicationException("Invalid schema in source");
			switch (schema.LocalName)
			{
				case "schema":				
					return ParseSchema(schema.FirstChild);				
				case "schemaref": 
					{
						string name = schema.Attributes["name", ""].Value;
						return new XmlConstantTypeName(name, schemas.Lookup(name));
					}
				case "void":
					return new XmlVoid();					
				case "choice":
					return new XmlUnion(ParseSchema(schema.ChildNodes[0]), ParseSchema(schema.ChildNodes[1]));					
				case "sequence":
					return new XmlSequence(ParseSchema(schema.ChildNodes[0]), ParseSchema(schema8�kl�E(s�fx#��]?�ת�QPR�U)~E)J���oߧÀi�Pt�;��Q�H����Y�E��#&���>mpQ1.?�?P%�cq������F����Y^_S=k\�v�~O��[=jE�$��^,rƔ�H��6IFB��i+@�_l�E�Y����p2u�s��tq �rfCo?)~0���fb,�v��V�_��7j⏆��;�F���H�o9�N�06��ȭ��?�o��\S<���D�C�m`���y��H6� ��B�
�ݝ&h�6��/~���G���K�#=g�3��65�O7I�Ʈ�7^N�9�A���B��ד({��Ϯ��7|5GF��_N$��w����5���@�������PK    ��J3�u&u~   �   K  openclipart-0.18-full/clipart/computer/icons/hotel_icon_in_room_web__01.txtUT	 yaKCyaKCUx �d M��
�0Dw�� ޽
ih�R
�cE��*�M��7^J�x���k"'W��`F.0x2gX�ÈH�fl5���D�����#R�n�Z?�ڝ� ��i`y[D�h>E�p^c17:v�M�s��=������|PK
     ��J3ԇ&  &  K  openclipart-0.18-full/clipart/computer/icons/hotel_icon_in_room_web__01.pngUT	 yaKCyaKCUx �d �PNG

   IHDR   P   P   ��   sBIT|d�   tEXtSoftware www.inkscape.org��<  �IDATx��{p[uv�?�)�J�$۲c�!ɱoB�l�̓d		��.Ö�h;��vv��N;���ζ�N��-}mY�����&KpyB�l~��+�C�l�u��r\;�eI����O������������{~?Ǐ��������$�I��1/EI����xtt�	9����p��Ϲ���(�www����w+����A��b+v[@�$Z[[�9�JI ��SRR�i���oYCE����F����4ME��-��j�LqݨA�1Jg��$I*�V�)n&P,�+3�|�f�e���ɹ��h9��@o��{y`��C-�z3�,L&Ҝ>�OˡN�����p�U�C}:o�ى$ܻ��]{�ض+���^d�3(��Ǐ��r���Gz�FR3��섭�M>8>����o�y}=����v/��7`I	�:4��C]�������Ƣe]:?ƥ�'y��NRS�`��&�������t/8��mc���P�]˪�By����W���+gq�[��P