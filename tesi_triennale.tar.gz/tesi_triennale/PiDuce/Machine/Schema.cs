.m_line_number 
				     + " <"
				     + (new String(accept.m_action,0,
						   accept.m_action_read))
				     + ">]");
		    if (CSpec.NONE != m_spec.m_anchor_array[i])
		      {
			System.out.print(" Anchor: "
					 + ((0 != (m_spec.m_anchor_array[i] & CSpec.START)) 
					    ? "start " : "")
					 + ((0 != (m_spec.m_anchor_array[i] & CSpec.END)) 
					    ? "end " : ""));
		      }
		  }
	      }

	    last_transition = -1;
	    for (j = 0; j < m_spec.m_dtrans_ncols; ++j)
	      {
		if (CDTrans.F != dtrans.m_dtrans[j])
		  {
		    if (last_transition != dtrans.m_dtrans[j])
		      {
			System.out.print("\n *    goto " + dtrans.m_dtrans[j]
					 + " on ");
			chars_printed = 0;
		      }
		    
		    str = interp_int((int) j);
		    System.out.print(str);
				
		    chars_printed = chars_printed + str.length(); 
		    if (56 < chars_printed)
		      {
			System.out.print("\n *             ");
			chars_printed = 0;
		      }
		    
		    last_transition = dtrans.m_dtrans[j];
		  }
	      }
	    System.out.println("");
	  }
	System.out.println(" */\n");
      }
}

/*
 * @(#)BitSet.java	1.12 95/12/01  
 *
 * Revision: 10/21/96
 * Modified by Elliot Joel Berk (ejberk@princeton.edu), for the purposes
 * of fixing a bug that was causing unjustified exceptions and crashes.
 * This bug was the result of resizing the internal buffer not large enough
 * in some cases.  The name was then changed to JavaLexBitSet.
 *
 * Copyright (c) 1995 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY