m', IADD='+', ISUB='-', IBAND='&', IBOR='|', IBXOR='^',
	IBSHL='{', IBSHR='}', IEQU='=', INEQU='#', ILESS='<', IGRTR='>',
	ILTEQ='(', IGTEQ=')', IINCG='Z', IINCL='z', IBRF='b', IBRT='B',
	IJUMP='j', IUFOR='f', IDFOR='F', IHDR='r', IEND='R', IHALT='h',
	IINIT='T', IPUSH='!', INOP='.';

const	EOF=%1, NUMBER=0;

const	LID	= 0,
	LADDR	= 1,
	LCLSS	= 2,
	LLEN	= 3;
const	CTEXT	= 0,
	CDATA	= 1,
	CBSS	= 2;

var	Buffer[BUFLEN];
var	DBuf[BUFLEN], CBuf[BUFLEN];
var	Dt, Ct;
var	Labels[LSPACE];
var	Lt;
var	Bp, Ep, Pos;
var	Token;
var	Value;
var	Output;
var	Dtop, Ctop, Btop;
var	Datafile;


scan() do
	var	c, state, sign;

	state := 0;
	Value := 0;
	while (1) do
		if (Bp >= Ep) do
			Ep := reads(Buffer, BUFLEN-1);
			Bp := 0;
			if (\Ep) do
				Token := EOF;
				return EOF;
			end
		end
		c := Buffer[Bp];
		Bp := Bp+1;
		Pos := Pos+1;
		ie (\state) do
			ie ('0' <= c /\ c <= '9' \/ c = '%') do
				Value := c='%'-> 0: c-'0';
				state := 1;
				sign := c = '%';
			end
			else do
				Token := c;
				return c;
			end
		end
		else do
			ie ('0' <= c /\ c <= '9') do
				Value := Value * 10 + (c-'0');
			end
			else do
				Bp := Bp-1;
				Pos := Pos-1;
				Token := NUMBER;
				if (sign) Value := -Value;
				return NUMBER;
			end
		end
	end
end


length(s) do
	var	i;

	i := 0;
	while (s[i]) i := i+1;
	return i;
end


copy(s, d) do
	var	i;

	i := 0;
	while (s[i]) do
		d[i] := s[i];
		i := i+1;
	end
	d[i] := 0;
end


writecode(buf) do
	var	k;

	ie (\buf) do
		writes(Cbuf);
		Ct := 0;
	end
	else do
		k := length(buf);
		if (Ct + k >= BUFLEN) do
			writes(Cbuf);
			Ct := 0;
		end
		copy(buf, @Cbuf[Ct]);
		Ct := Ct+k;
	end
end


writedata(buf) do
	var	o, k;

	o := select(1, Datafile);
	ie (\buf) do
		writes(Dbuf);
		Dt := 0;
	end
	else do
		k := length(buf);
		if (Dt + k >= BUFLEN) do
			writes(Dbuf);
			Dt := 0;
		end
		copy(buf, @Dbuf[Dt]);
		Dt := Dt+k;
	end
	select(1, o);
end


report(msg) do
	var	ch[2];

	select(1, 2);
	writes("symcom: "); writes(msg);
	writes(" [P=");
	writes(ntoa(Pos, 0));
	writes(", T=");
	ch[0] := Token;
	ch[1] := 0;
	ie (Token = NUMBER)
		writes("NUMBER");
	else ie (Token = EOF)
		writes("EOF");
	else
		writes(ch);
	writes(", V=");
	writes(ntoa(Value, 0));
	writes("]");
	newline();
	erase("_DATA");
	erase("X.COM");
	halt;
end


find(l) do
	var	i;

	i := 0;
	while (i<Lt) do
		if (Labels[i+LID] = l) return Labels[i+LADDR];
		i := i+LLEN;
	end
	if (Output) report("undefined label");
	return 0;
end


mark(l, loc) do
	var	lab;

	if (Output) return 0;
	if (Lt + LLEN >= LSPACE) report("too many labels");
	lab := @Labels[Lt];
	Lt := Lt+LLEN;
	lab[LID] := l;
	lab[LADDR] := loc;
	lab[LCLSS] := CTEXT;
end


fixlabel(c) do
	var	lab;

	if (Output) return 0;
	lab := @Labels[Lt-LLEN];
	if (lab[LCLSS] \= CTEXT) return 0;
	lab[LADDR] := c=CDATA-> Dtop: Btop;
	lab[LCLSS] := c;
end


num() do
	scan();
	if (Token \= NUMBER) report("numeric parameter ex