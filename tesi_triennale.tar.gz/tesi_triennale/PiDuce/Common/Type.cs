// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using PiDuce.Common;
using System.Xml;

namespace PiDuce.Common
{
	public interface ITypeVisitor
	{
		void VisitBottom(BottomType t);
		void VisitVoid(VoidType t);
		void VisitBasicType(BasicType t);
		void VisitBasicTypeLiteralType(BasicTypeLiteralType t);
		void VisitUnion(UnionType t);
		void VisitConstantTypeName(ConstantType t);
		void VisitSequence(SequenceType t);
		void VisitLabelled(LabelledType t);
		void VisitChan(ChannelType t);
		void VisitErrorType(ErrorType t);
		void VisitBind(Bind t);
		void VisitServiceType(ServiceType t);
	}

  ///<summary>Interface of PiDuce types</summary>
  public interface IType
  {	
    bool IsLabelledType();
    bool IsSequenceType();
    bool IsUnionType();
    bool IsConstantType();
    bool IsBaseType();
    bool IsChannelType();
    bool IsVoidType();
    bool IsBottomType();
    bool IsErrorType();
    LabelledType AsLabelledType();
    SequenceType AsSequenceType();
    UnionType AsUnionType();
    ConstantType AsConstantType();
    ChannelType AsChannelType();
    VoidType AsVoidType();
    BottomType AsBottomType();
    /// <summary>
    /// A schema is equal to an object only if the object is a schema having the same structure of this schema 
    /// </summary>
    /// <param name="obj">the object to compare with</param>
    /// <returns></returns>
    String ToString();
		IType Strip();
    void Compile(XmlWriter xml);
		void Accept(ITypeVisitor visitor);
  }

#if false
	public class CompileTypeVisitor : ITypeVisitor
	{
		private XmlWriter writer;

		public CompileTypeVisitor(XmlWriter writer)
		{ this.writer = writer; }

		public void VisitBottom(BottomType t)
		{
			writer.WriteStartElement("bottom");
			writer.WriteEndElement();
		}

		public void VisitVoid(VoidType t)
		{
			writer.WriteStartElement("void");
			writer.WriteEndElement();
		}

		public void VisitUnion(UnionType t)
		{
			writer.WriteStartElement("choice");
			t.Fst.Accept(this);
			t.Snd.Accept(this);
			writer.WriteEndElement();
		}

		public void VisitConstantTypeName(ConstantType t)
    {
      writer.WriteStartElement("schemaref");
      writer.WriteAttributeString("name", t.Entry.Name);
      writer.WriteEndElement();
    }

		public void VisitSequence(SequenceType t)
    {
      writer.WriteStartElement("sequence");
			t.Top.Accept(this);
			t.Tail.Accept(this);
      writer.WriteEndElement();
    }

		public void VisitLabelled(LabelledType t)
    {
      writer.WriteStartElement("labelled");
      t.Labels.ToXml(writer);
			t.Content.Accept(this);
      writer.WriteEndElement();
    }

		public void VisitIntLiteral(IntLiteralType t)
    {
      writer.WriteStartElement("intLit");
      writer.WriteString(t.Val.ToString());
      writer.WriteEndElement();
    }

		public void VisitIntType(IntType t)
    {
      writer.WriteStartElement("int");
      writer.WriteEndElement();
    }

		public void VisitStringLiteral(StringLiteralType t)
    {
      writer.WriteStartElement("strLit");
      writer.WriteCData(t.Val);
      writer.WriteEndElement();
    }

		public void VisitStringType(StringType t)
    {
      writer.WriteStartElement("string");
      writer.WriteEndElement();
    }

		public void VisitChan(ChannelType t)
    {
      string cap = "?";
      if (t.Capability == ChannelType.CAPABILITY.OUT) cap = "O";
      if (t.Capability == ChannelType.CAPABILITY.INOUT) cap = "IO";
      if (t.Capability == ChannelType.CAPABILITY.IN) cap = "I";
      writer.WriteStartElement("chan");
      writer.WriteAttributeString("capability", cap);
      t.Content.Accept(this);
      writer.WriteEndElement();
    }

		public void VisitErrorType(ErrorType t)
    {
      writer.WriteStartElement("error");
      writer.WriteEndElement();
    }

		public void VisitBind(Bind t)
		{
			writer.WriteStartElement("bind");
     	writer.WriteAttributeString("index", t.Index.ToString());
			t.Content.Accept(this);
			writer.WriteEndElement();
		}
	}
#endif

	public abstract class AbstractTypeVisitor : ITypeVisitor
	{
		public virtual void VisitBottom(BottomType t)
		{ }

		public virtual void VisitVoid(VoidType t)
		{ }

		public virtual void VisitUnion(UnionType t)
		{
			t.Fst.Accept(this);
			t.Snd.Accept(this);
		}

		public virtual void VisitConstantTypeName(ConstantType t)
		{ }

		public virtual void VisitSequence(SequenceType t)
		{
			t.Top.Accept(this);
			t.Tail.Accept(this);
		}

		public virtual void VisitLabelled(LabelledType t)
		{ t.Content.Accept(this); }

		public virtual void VisitBasicType(BasicType t)
		{ }

		public virtual void VisitBasicTypeLiteralType(BasicTypeLiteralType t)
		{ }

		public virtual void VisitChan(ChannelType t)
		{ t.Content.Accept(this); }

		public virtual void VisitErrorType(ErrorType t)
		{ }

		public virtual void VisitBind(Bind t)
		{ t.Content.Accept(this); }

		public virtual void VisitServiceType(ServiceType t)
		{
			foreach (KeyValuePair<string, IType> pair in t.Operations)
				pair.Value.Accept(this);
		}
	}

	public class ToStringTypeVisitor : ITypeVisitor
	{
		private System.Text.StringBuilder builder = new System.Text.StringBuilder();

		public override string ToString()
		{ return builder.ToString(); }

		public void VisitBottom(BottomType t)
		{ builder.Append("empty"); }

		public void VisitVoid(VoidType t)
		{ builder.Append("void"); }

		public void VisitUnion(UnionType t)
		{
			t.Fst.Accept(this);
			builder.Append("+");
			t.Snd.Accept(this);
		}

		public void VisitConstantTypeName(ConstantType t)
		{
			builder.Append(t.Name);
			if (t.Entry == null)
				builder.Append("!null");
			else
				builder.Append("!ok");
		}

		public void VisitSequence(SequenceType t)
		{ 
			t.Top.Accept(this);
			builder.Append(",");
			t.Tail.Accept(this);
		}

		public void VisitLabelled(LabelledType t)
    { 
			builder.Append("{" + t.Labels + "}[");
			t.Content.Accept(this);
			builder.Append("]");
		}

		public void VisitBasicType(BasicType t)
		{ builder.Append(t.Type.ToString()); }

		public void VisitBasicTypeLiteralType(BasicTypeLiteralType t)
		{ builder.Append(t.Value.ToString()); }

		public void VisitChan(ChannelType t)
		{ 
      builder.Append("<");
			t.Content.Accept(this);
			builder.Append(">");
			switch (t.Capability) {
      case ChannelType.CAPABILITY.IN:
        builder.Append("^I");
				break;
      case ChannelType.CAPABILITY.OUT:
        builder.Append("^O");
				break;
      case ChannelType.CAPABILITY.INOUT:
        builder.Append("^IO");
				break;
			}
		}

		public void VisitErrorType(ErrorType t)
		{ builder.Append("error"); }

		public void VisitBind(Bind t)
		{
			builder.Append(t.Entry.Name + ":");
			t.Content.Accept(this);
		}

		public void VisitServiceType(ServiceType s)
		{
			builder.Append("{ ");
			foreach (KeyValuePair<string, IType> pair in s.Operations) {
				builder.Append(pair.Key);
				builder.Append(" : ");
				pair.Value.Accept(this);
				builder.Append("; ");
			}
			builder.Append("}");
		}
	}

	public class StripTypeVisitor : ITypeVisitor
	{
		private IType result = null;

		public IType Strip(IType t)
		{
			t.Accept(this);
			return result;
		}

		public void VisitBottom(BottomType t)
		{ result = t; }

		public void VisitVoid(VoidType t)
		{ result = t; }

		public void VisitUnion(UnionType t)
		{
			IType fst = Strip(t.Fst);
			IType snd = Strip(t.Snd);
			if (Object.ReferenceEquals(fst, t.Fst) && Object.ReferenceEquals(snd, t.Snd))
				result = t;
			else
				result = new UnionType(fst, snd);
		}

		public void VisitConstantTypeName(ConstantType t)
		{ result = t; }

		public void VisitSequence(SequenceType t)
		{
			IType top = Strip(t.Top);
			IType tail = Strip(t.Tail);
			if (Object.ReferenceEquals(top, t.Top) && Object.ReferenceEquals(tail, t.Tail))
				result = t;
			else {
				Debug.Assert(top is LabelledType);
				result = new SequenceType(top.AsLabelledType(), tail);
			}
		}

		public void VisitLabelled(LabelledType t)
		{
			IType content = Strip(t.Content);
			if (Object.ReferenceEquals(content, t.Content))
				result = t;
			else
				result = new LabelledType(t.Labels, content);
		}

		public void VisitBasicType(BasicType t)
		{ result = t; }

		public void VisitBasicTypeLiteralType(BasicTypeLiteralType t)
		{ result = t; }

		public void VisitChan(ChannelType t)
		{ result = t; }

		public void VisitErrorType(ErrorType t)
		{ result = t; }

		public void VisitBind(Bind t)
		{ result = Strip(t.Content); }

		public void VisitServiceType(ServiceType t)
		{
			IDictionary<string, IType> fields = new Dictionary<string, IType>();
			foreach (KeyValuePair<string, IType> pair in t.Operations)
				fields.Add(pair.Key, Strip(pair.Value));
			// optimize this if none of the stripped types has changed
			result = new ServiceType(fields);
		}
	}

  public abstract class Type: IType 
  {	
    public virtual LabelledType AsLabelledType()
    { 
      throw new ApplicationException(this + " is not LabelledType");
    }
    public virtual SequenceType AsSequenceType()
    { 
      throw new ApplicationException(this + " is not SequenceType");
    }
    public virtual UnionType AsUnionType()
    { 
      throw new ApplicationException(this + " is not UnionType");
    }
    public virtual ConstantType AsConstantType()
    { 
      throw new ApplicationException(this + " is not ConstantType");
    }
    public virtual ChannelType AsChannelType()
    { 
      throw new ApplicationException(this + " is not ChannelType");
    }
    public virtual VoidType AsVoidType()
    { 
      throw new ApplicationException(this + " is not VoidType");
    }
    public virtual BottomType AsBottomType()
    { 
      throw new ApplicationException(this + " is not BottomType");
    }
    public virtual bool IsIntType()
    { 
      return false;
    }
    public virtual bool IsStringType()
    { 
      return false;
    }
    public virtual bool IsIntLiteralType()
    { 
      return false;
    }
    public virtual bool IsStringLiteralType()
    { 
      return false;
    }
    public virtual bool IsLabelledType()
    { 
      return false;
    }
    public virtual bool IsSequenceType()
    { 
      return false;
    }
    public virtual bool IsUnionType()
    { 
      return false;
    }
    public virtual bool IsConstantType()
    { 
      return false;
    }
    public virtual bool IsBaseType()
    { 
      return false;
    }
    public virtual bool IsChannelType()
    { 
      return false;
    }
    public virtual bool IsVoidType()
    { 
      return false;
    }
    public virtual bool IsBottomType()
    { 
      return false;
    }
    public virtual bool IsErrorType()
    { 
      return false;
    }

		private static bool EqualsAux(IType s, IType t)
		{
			if (Object.ReferenceEquals(s, t)) {
				return true;
			} else if (s is Bind && t is Bind) {
				Debug.Assert(false, "binding within a schema!");
				return (Equals(((Bind) s).Content, ((Bind) t).Content));
			} else if (s is BottomType && t is BottomType) {
				return true;
			} else if (s is UnionType && t is UnionType) {
				UnionType s1 = (UnionType) s;
				UnionType t1 = (UnionType) t;
				return Equals(s1.Fst, t1.Fst) && Equals(s1.Snd, t1.Snd);
			} else if (s is VoidType && t is VoidType) {
				return true;
			} else if (s is ConstantType && t is ConstantType) {
				ConstantType s1 = (ConstantType) s;
				ConstantType t1 = (ConstantType) t;
				return (Object.ReferenceEquals(s1.Entry, t1.Entry));
			} else if (s is SequenceType && t is SequenceType) {
				SequenceType s1 = (SequenceType) s;
				SequenceType t1 = (SequenceType) t;
				return Equals(s1.Top, t1.Top) && Equals(s1.Tail, t1.Tail);
			} else if (s is LabelledType && t is LabelledType) {
				LabelledType s1 = (LabelledType) s;
				LabelledType t1 = (LabelledType) t;
				return s1.Labels.Includes(t1.Labels) && t1.Labels.Includes(s1.Labels) && Equals(s1.Content, t1.Content);
			} else if (s is BasicType && t is BasicType) {
				return (((BasicType) s).Type.Equals(((BasicType) t).Type));
			} else if (s is BasicTypeLiteralType && t is BasicTypeLiteralType) {
				return (((BasicTypeLiteralType) s).Value.Equals(((BasicTypeLiteralType) t).Value));
			} else if (s is ChannelType && t is ChannelType) {
				ChannelType s1 = (ChannelType) s;
				ChannelType t1 = (ChannelType) t;
				return s1.Capability == t1.Capability && Equals(s1.Content, t1.Content);
			} else if (s is ErrorType && t is ErrorType) {
				return true;
			} else
				return false;
		}

    public override bool Equals(Object obj)
    {
      if (obj is IType)
        return EqualsAux(this, (IType) obj);
      else
        return false;
    }

		private static int GetHashCodeAux(IType t)
		{
			Debug.Assert(t != null);
			if (t is Bind) {
				Debug.Assert(false);
				return GetHashCodeAux(((Bind) t).Content);
			} else if (t is BottomType) {
				return 0;
			} else if (t is UnionType) {
				UnionType t1 = (UnionType) t;
				return GetHashCodeAux(t1.Fst) ^ GetHashCodeAux(t1.Snd);
			} else if (t is VoidType) {
				return 1;
			} else if (t is ConstantType) {
				return ((ConstantType) t).Name.GetHashCode();
			} else if (t is SequenceType) {
				SequenceType t1 = (SequenceType) t;
				return GetHashCodeAux(t1.Top) ^ GetHashCodeAux(t1.Tail);
			} else if (t is LabelledType) {
				LabelledType t1 = (LabelledType) t;
				return t1.Labels.GetHashCode() ^ GetHashCodeAux(t1.Content);
			} else if (t is BasicType) {
				return ((BasicType) t).Type.GetHashCode();
			} else if (t is BasicTypeLiteralType) {
				return ((BasicTypeLiteralType) t).Value.GetHashCode();
			} else if (t is ChannelType) {
				ChannelType t1 = (ChannelType) t;
				return t1.Capability.GetHashCode() ^ GetHashCodeAux(t1.Content);
			} else if (t is ServiceType) {
				ServiceType t1 = (ServiceType) t;
				int result = 0;
				foreach (KeyValuePair<string, IType> pair in t1.Operations)
					result ^= pair.Key.GetHashCode() ^ GetHashCodeAux(pair.Value);
				return result;
			} else if (t is ErrorType) {
				return 1;
			} else {
				Debug.Assert(false);
				return -1;
			}
		}

    public override int GetHashCode()
    { return GetHashCodeAux(this); }

		public IType Strip()
		{ return new StripTypeVisitor().Strip(this); }

    public override String ToString()
		{
			ToStringTypeVisitor visitor = new ToStringTypeVisitor();
			Accept(visitor);
			return visitor.ToString();
		}

    public void Compile(XmlWriter writer)
		{
#if false
			CompileTypeVisitor visitor = new CompileTypeVisitor(writer);
			Accept(visitor);
#endif
			Debug.Assert(false);
		}

		public abstract void Accept(ITypeVisitor visitor);
  }

	public class TypeRef
	{
		private readonly string name;
		private IType type;

		public string Name { get { return name; } }

		public IType Type {
			get { return type; }
			set { type = value; }
		}

		public TypeRef(string name) : this(name, null)
		{ }

		public TypeRef(string name, IType type)
		{
			this.name = name;
			this.type = type;
		}
	}

	// WARNING: Bind extends LabelledType because in the IType hierarchy a
	// sequence value must have its head labelled, but this prevents one from
	// creating patterns of the form x:a[], int where the binder concerns the
	// very head. This hack is harmless as long as the types used for subtyping
	// are stripped (i.e. no binding is present) and whenever the type of an
	// IType value is inspected with "is" the Bind case is checked before the
	// LabelledType case. The use of the visitor over types poses no problems.
	public class Bind : LabelledType
	{
		private readonly string name;
		private IEntry entry;

		public string Name { get { return name; } }
		public IEntry Entry {
			get { return entry; }
			set { entry = value; }
		}

		public Bind(string name, IType content) : this(name, content, null)
		{ }

		public Bind(string name, IType content, IEntry entry)
			: base(LabelSet.Singleton("#bind"), content)
		{
			this.name = name;
			this.entry = entry;
		}

		public override void Accept(ITypeVisitor visitor)
		{ visitor.VisitBind(this); }
	}

  /// <summary>
  /// Class that represent the bottom schema
  /// </summary>
  public class BottomType: Type 
  {
    public override bool IsBottomType()
    { return true; }

    public override BottomType AsBottomType()
    { return this; }

		public override void Accept(ITypeVisitor visitor)
		{ visitor.VisitBottom(this); }
  }
  /// <summary>
  /// Class that represent the union schema
  /// </summary>
  public class UnionType: Type 
  {
    private IType fst;
    private IType snd;

    public UnionType(IType fst, IType snd) 
    {
      this.fst = fst;
      this.snd = snd;
    }
    public IType Fst { get { return fst; } }
    public IType Snd { get { return snd; } }

    public override bool IsUnionType()
    { return true; }

    public override UnionType AsUnionType()
    { return this; }

		public override void Accept(ITypeVisitor visitor)
		{ visitor.VisitUnion(this); }
  }

  /// <summary>
  /// Denotes the empty schema (it recognizes the empty string)
  /// </summary>
  public class VoidType : Type 
  {	
    public override bool IsVoidType()
    { return true; }

    public override VoidType AsVoidType()
    { return this; }

		public override void Accept(ITypeVisitor visitor)
		{ visitor.VisitVoid(this); }
  }
  
  public class ConstantType : Type 
  {
    private readonly String name;
		private TypeRef entry;
    
		public ConstantType(String name) : this(name, null)
		{ }

    public ConstantType(String name, TypeRef entry) 
    {
      this.name = name;
			this.entry = entry;
    }
    
    public String Name { get { return name; } }

		public TypeRef Entry {
			get { return entry; }
			set { entry = value; }
		}

    public override bool IsConstantType()
    { return true; }

    public override ConstantType AsConstantType()
    { return this; }

		public override void Accept(ITypeVisitor visitor)
		{ visitor.VisitConstantTypeName(this); }
  }

  /// <summary>
  /// Denotes sequences.
  /// </summary>
  public class SequenceType :Type 
  {
    private LabelledType top;
    private IType tail;

    public SequenceType(LabelledType top, IType tail) 
    {
      this.top = top;
      this.tail = tail;
    }
    public LabelledType Top { get { return top; } }

    public IType Tail { get { return tail; } }

    public override bool IsSequenceType()
    { return true; }

    public override SequenceType AsSequenceType()
    { return this; }

		public override void Accept(ITypeVisitor visitor)
		{ visitor.VisitSequence(this); }
  }
    
  public class LabelledType: Type 
  {
    private ILabelSet matchedLabels;
    private IType content;
		
    public LabelledType(ILabelSet labels, IType content) 
    {
      this.matchedLabels = labels;
      this.content = content;
    }

    public ILabelSet Labels 
    { get { return matchedLabels; } }

    public IType Content { get { return content; } }

    public override bool IsLabelledType()
    { return true; }

    public override LabelledType AsLabelledType()
    { return this; }

		public override void Accept(ITypeVisitor visitor)
		{ visitor.VisitLabelled(this); }
  }
  
  public abstract class BaseType: Type
  {
    public override bool IsBaseType()
    { return true; }
  }

	public class BasicType : BaseType
	{
		private readonly IBasicType type;

		public IBasicType Type { get { return type; } }

		public BasicType(IBasicType type)
		{ this.type = type; }

		public override void Accept(ITypeVisitor visitor)
		{ visitor.VisitBasicType(this); }
	}

	public class BasicTypeLiteralType : BaseType
	{
		private readonly IBasicTypeLiteral value;

		public IBasicTypeLiteral Value { get { return value; } }

		public BasicTypeLiteralType(IBasicTypeLiteral value)
		{ this.value = value; }

		public override void Accept(ITypeVisitor visitor)
		{ visitor.VisitBasicTypeLiteralType(this); }
	}

  /**
   * Denotes the channel schema. In particular a channel can have one of the following capabilities: 
   * input capability, output capability, both. 
   */
  public class ChannelType:Type 
  {
    public enum CAPABILITY { OUT = +1, IN = -1, INOUT = +2 }
    private IType content;
    private CAPABILITY capability;

    public ChannelType(IType carried, int capability)
    {
      thi#{t�q�����ZU0����
o��`�ͤ��T�j����#���c���V�ڄ�*c���������W1dF�������(��,���#�(��Lqc���h]g�Iʜ�)2Ũ�� �����+����[j�ŋҳРt���(y�&��c�uz�e�	����t���J|�Y8Df��J�Ta{ �e@a���.ѴD�ۮ��3�����M/_ϤxD)l�y��U����HPZԧ�~3��bDK w�p8@\��cM��x�:#��5�r��n���@�x�1_�Oz��z�5l�r�����!��<�B0B�(�J��oȾB��
yJ��go��N��� l�m:u�$��D�n#��_^�;�))+Ӆ������i�Q�s���`���a����ϕ���N�?]���&�z9G���P\M��|�P2�|jS���;�x�gT�(�+�Pzi�M���_��OuG��TD��!	'�d��I�������\���N�Q�g,�����/�u	�j�p�zJ{�F��B��p���U��q��^9��8�1	�|8�A��
a�W��9����e����j]�#c �j	��j��#�1�>.�x���O����r�wܻ"�p�b��>� ��~�8���WNq���{�L��:�^ ��,w�����7�O�L�ħ_���8W}	��4I��ҿ�ל*#�x+hm�W1o����1�N��c{��#^e˃a�8gل ��0�@a�H%�e��0r��#�{��ᖃ�G)�F�<)&�F:纁P��� \sP��Q�H!0�WB�w�G����;���=�s4%b�#��A����\hO��$]������d֟x�0Y��	�4�w~U.Forhh����#�^A1$U�)"�S7G��(R�j��n��� 椞��_�C�aC�"���ɢ��A��d�LM�d�a��,�X�oo��^�ڣ��({�ܬ=FӡBYLq�e��+D���=�3�5���,@��D�	�Ȧ�����~	��q85E6�GGj�7�f]C2�S���������P/q�^��#FD�bl �8|�th�j����KͦY��+3Xǐ}���Բ�7!�2�ՠZ�f�M[tl�ɉB�@�ii����J��[w�v�"�j#���Q���Y4�v�NN��V�����,{���C`�:��ɬ&
�]�O4���rJ\�5���t� ���+]�J��Q����N��4�~-Q����1g�4�/�Wt�Ρ�3:�����Se�r�F-r܎�ƾ���y�ڎ5@!�Pj�Mj�Rbaڲ\�-h�n�_��h@�"E
��լ���*��N�PZ�1�Ҁ�f��(@�ڐE���h㿶%W�X?�����N{>�X:�����`j1z�Vu�j��S8��,���٢�I�`��,yL�=�0�P�#�O�&�����d+R�x���/��o�6�ي_�t��6I�5�-�*ˣ�K4cK�u��%S���%�x� �ZQ`�1�}��2��	���ۨ�P�B������(q��A������8b�VL��kJd-�@��eTU�}i@*Ut�F�`��Ѡ��y��W�i&]3i�#�a�rֺ��3#����h�.���콝�v܊�ea��%��V}{џ��W�����* �~���4ͱ����Vᦾ~�0�����6��Z��ނU�	���}��3����0�*�@rp�Z��b��R�[>�eF�9�b|;Y���Z~�>N}ĢR�N$�\L��5q[`�݆P����X�{o��&yoCl��U�