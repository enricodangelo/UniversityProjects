// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Text;
using System.Xml;
using System.Collections.Generic;
using PiDuce.Common; // remove me!
using System.Diagnostics;

namespace PiDuce.Common
{
	public interface ILabelSet
	{
		ISet<string> Labels { get; }
		bool Has(string label);
		bool IsEmpty();
		bool IsSubsetOf(ILabelSet labels);
		bool Includes(ILabelSet labels);
		bool Intersects(ILabelSet labels);
		void ToXml(XmlWriter writer);
	}

	public abstract class LabelSet : ILabelSet
	{
    protected ISet<string> labels;

    public ISet<string> Labels { get { return labels; } }

		protected LabelSet()
		{ this.labels = new ArraySet<string>(); }

    protected LabelSet(ISet<string> labels)
    { this.labels = new ArraySet<string>(labels); }

		protected LabelSet(string label)
		{
      this.labels = new ArraySet<string>();
			this.labels.Add(label);
		}

		public abstract bool Has(string labeld);
		public abstract bool IsEmpty();
		public abstract void ToXml(XmlWriter writer);

    private static ISet<string> Union(ISet<string> s1, ISet<string> s2)
		{
      ISet<string> res = new ArraySet<string>(s1);
			foreach (string s in s2)
				if (!res.Contains(s))
					res.Add(s);
			return res;
		}

    private static ISet<string> Difference(ISet<string> s1, ISet<string> s2)
		{
      ISet<string> res = new ArraySet<string>();
			foreach (string s in s1)
				if (!s2.Contains(s))
					res.Add(s);
			return res;
		}

    private static ISet<string> Intersection(ISet<string> s1, ISet<string> s2)
		{
      ISet<string> res = new ArraySet<string>();
			foreach (string s in s1)
				if (s2.Contains(s))
					res.Add(s);
			return res;
		}

		public static ILabelSet Union(ILabelSet s1, ILabelSet s2)
		{
			if (s1 is WithLabels && s2 is WithLabels)
				return new WithLabels(Union(s1.Labels, s2.Labels));
			else if (s1 is WithLabels && s2 is WithoutLabels)
				return new WithoutLabels(Difference(s2.Labels, s1.Labels));
			else if (s1 is WithLabels && s2 is WithLabels)
				return new WithoutLabels(Difference(s1.Labels, s2.Labels));
			else
				return new WithoutLabels(Intersection(s1.Labels, s2.Labels));
		}

		public static ILabelSet Difference(ILabelSet s1, ILabelSet s2)
		{
			if (s1 is WithLabels && s2 is WithLabels)
				return new WithLabels(Difference(s1.Labels, s2.Labels));
			else if (s1 is WithoutLabels && s2 is WithLabels)
        return new WithoutLabels(Union(s1.Labels, s2.Labels));
			else if (s1 is WithLabels && s2 is WithoutLabels)
				return new WithLabels(Intersection(s1.Labels, s2.Labels));
			else
				return new WithLabels(Difference(s2.Labels, s1.Labels));
		}

		public static ILabelSet Intersection(ILabelSet s1, ILabelSet s2)
		{
			if (s1 is WithLabels && s2 is WithLabels)
				return new WithLabels(Intersection(s1.Labels, s2.Labels));
			else if (s1 is WithoutLabels && s2 is WithLabels)
				return new WithLabels(Difference(s2.Labels, s1.Labels));
			else if (s1 is WithLabels && s2 is WithoutLabels)
				return new WithLabels(Difference(s1.Labels, s2.Labels));
			else
				return new WithoutLabels(Union(s1.Labels, s2.Labels));
		}

		public static ILabelSet Complement(ILabelSet s)
		{
			if (s is WithLabels)
				return new WithoutLabels(s.Labels);
			else
				return new WithLabels(s.Labels);
		}

		public static ILabelSet Singleton(string s)
		{ return new WithLabels(s); }

		public static ILabelSet Empty()
		{ return new WithLabels(); }

		public static ILabelSet Any()
		{ return new WithoutLabels(); }

    public static ILabelSet With(ISet<string> labels)
		{ return new WithLabels(labels); }

    public static ILabelSet Without(ISet<string> labels)
		{ return new WithoutLabels(labels); }

		public bool IsSubsetOf(ILabelSet s)
		{ return Difference(this, s).IsEmpty(); }

		public bool Includes(ILabelSet s)
		{ return s.IsSubsetOf(this); }

		public bool Intersects(ILabelSet s/* correct if */
if (10 > 20) then 30 else 40	
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 tiger/testcases/test9.tig                                                                           000644  000163  047074  00000000106 06222563050 017065  0                                                                                                    ustar 00appel                           appelbook                       000000  000000                                                                                                                                                                         /* error : types of then - else differ */

if (5>4) then 13 else  " "
                                                                                                                                                                                                                                                                                                                                                                                                                                                          tiger/testcases/merge.tig                                                                           000644  000163  047074  00000002524 06224500024 017114  0                                                                                                    ustar 00appel                           appelbook                       000000  000000                                                                                                                                                                         let 

 type any = {any : int}
 var buffer := getchar()

function readint(any: any) : int =
 let var i := 0
     function isdigit(s : string) : int = 
		  ord(buffer)>=ord("0") & ord(buffer)<=ord("9")
     function skipto() =
       while buffer=" " | buffer="\n"
         do buffer := getchar()
  in skipto();
     any.any := isdigit(buffer);
     while isdigit(buffer)
       do (i := i*10+ord