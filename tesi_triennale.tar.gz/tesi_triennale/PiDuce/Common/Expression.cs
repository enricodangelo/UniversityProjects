// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System.Collections.Generic;

namespace PiDuce.Common
{
	public enum BinaryOp {
		PLUS, MINUS, TIMES, DIVIDE,
		EQ, NE, GT, GE, LT, LE,
		LOR, LAND
	}

	public enum UnaryOp { LNOT, UMINUS }

	public interface IExpressionVisitor
	{
		void VisitVoidExpr(VoidExpr expr);
		void VisitLiteralExpr(LiteralExpr expr);
		void VisitVariableExpr(VariableExpr expr);
		void VisitSelectExpr(SelectExpr expr);
		void VisitRecordExpr(RecordExpr expr);
		void VisitLabelledExpr(LabelledExpr expr);
		void VisitSequenceExpr(SequenceExpr expr);
		void VisitBinaryOpExpr(BinaryOpExpr expr);
		void VisitUnaryOpExpr(UnaryOpExpr expr);
	}

	public interface IExpression
	{
		void Accept(IExpressionVisitor visitor);
	}

	public class VoidExpr : IExpression
	{
		public void Accept(IExpressionVisitor visitor)
		{ visitor.VisitVoidExpr(this); }
	}

	public class LiteralExpr : IExpression
	{
		private readonly IBasicTypeLiteral content;

		public IBasicTypeLiteral Content { get { return content; } }

		public LiteralExpr(IBasicTypeLiteral content)
		{ this.content = content; }

		public void Accept(IExpressionVisitor visitor)
		{ visitor.VisitLiteralExpr(this); }
	}

	public class VariableExpr : IExpression
	{
		private readonly string name;
		private IEntry entry;

		public string Name { get { return name; } }
		public IEntry Entry {
			get { return entry; }
			set { entry = value; }
		}

		public VariableExpr(string name) : this(name, null)
		{ }

		public VariableExpr(string name, IEntry entry)
		{
			this.name = name;
			this.entry = entry;
		}

		public void Accept(IExpressionVisitor visitor)
		{ visitor.VisitVariableExpr(this); }
	}

	public class SelectExpr : IExpression
	{
		private readonly IExpression content;
		private readonly string field;

		public IExpression Content { get { return content; } }
		public string Field { get { return field; } }

		public SelectExpr(IExpression content, string field)
		{
			this.content = content;
			this.field = field;
		}

		public void Accept(IExpressionVisitor visitor)
		{ visitor.VisitSelectExpr(this); }
	}

	public class RecordExpr : IExpression
	{
		private readonly IDictionary<string, IExpression> fields;

		public IDictionary<string, IExpression> Fields { get { return fields; } }

		public RecordExpr(IDictionary<string, IExpression> fields)
		{ this.fields = fields; }

		public void Accept(IExpressionVisitor visitor)
		{ visitor.VisitRecordExpr(this); }
	}

	public class LabelledExpr : IExpression
	{
		private readonly string label;
		private readonly IExpression content;

		public string Label { get { return label; } }
		public IExpression Content { get { return content; } }

		public LabelledExpr(string label, IExpression content)
		{
			this.label = label;
			this.content = content;
		}

		public void Accept(IExpressionVisitor visitor)
		{ visitor.VisitLabelledExpr(this); }
	}

	public class SequenceExpr : IExpression
	{
		private readonly IExpression head;
		private readonly IExpression tail;

		public IExpression Head { get { return head; } }
		public IExpression Tail { get { return tail; } }

		public SequenceExpr(IExpression head, IExpression tail)
		{
			this.head = head;
			this.tail = tail;
		}

		public void Accept(IExpressionVisitor visitor)
		{ visitor.VisitSequenceExpr(this); }
	}

	public class BinaryOpExpr : IExpression
	{
		private readonly BinaryOp op;
		private readonly IExpression left;
		private readonly IExpression right;

		public BinaryOp Op { get { return op; } }
		public IExpression Left { get { return left; } }
		public IExpression Right { get { return right; } }

		public BinaryOpExpr(BinaryOp op, IExpression left, IExpression right)
		{
			this.op = op;
			this.left = left;
			this.right = right;
		}

		public void Accept(IExpressionVisitor visitor)
		{ visitor.VisitBinaryOpExpr(this); }
	}

	public cl��>6K��(?�o�V�_:b���c��oOɋZ=!��Q�E���"�m��I�d�N��	7���7p�����񭉤,��	+����������5��Hu�.~6��z�Gջ�76��j�����?����լ�g��{#x6�%?0�G������t�S`.�A���ZVO��=���ժ�#��c�G�s����d*G? �Qz�̪��6�
'�Wd~ ��m�ݡon�Q�b�^�Z|F/ohCY>#�;��'�M��Pi�1l��[Y�B^�1B��i�`�S���T_�݅�����ރ�L9����Xy�6��,e,��>�K�	�n����i�s,,Fc���.7��;������4���h�xȸ���������T僠?�g�l>ի����F��[��ώbC�iN�I�5�