// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Diagnostics;
using PiDuce.Common;

namespace PiDuce.Common
{
  public interface ISchema
  {
		void Accept(ISchemaVisitor visitor);
		ISchema Strip();
		bool StructureEquals(ISchema s);
		int Hash();
	}

	public interface ISchemaVisitor
	{
		void VisitVoidSchema(VoidSchema s);
		void VisitBasicSchema(BasicSchema s);
		void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s);
		void VisitLabelledSchema(LabelledSchema s);
		void VisitSequenceSchema(SequenceSchema s);
		void VisitUnionSchema(UnionSchema s);
		void VisitStarSchema(StarSchema s);
		void VisitPlusSchema(PlusSchema s);
		void VisitRepetitionSchema(RepetitionSchema s);
		void VisitConstantSchema(ConstantSchema s);
		void VisitChannelSchema(ChannelSchema s);
		void VisitFunctionSchema(FunctionSchema s);
		void VisitErrorSchema(ErrorSchema s);
		void VisitBindSchema(BindSchema s);
		void VisitServiceSchema(ServiceSchema s);
	}

	public abstract class AbstractSchemaVisitor : ISchemaVisitor
	{
		public virtual void VisitLabelledSchema(LabelledSchema s)
		{ s.Content.Accept(this); }

		public virtual void VisitSequenceSchema(SequenceSchema s)
		{
			s.Head.Accept(this);
			s.Tail.Accept(this);
		}

		public virtual void VisitUnionSchema(UnionSchema s)
		{
			s.Left.Accept(this);
			s.Right.Accept(this);
		}

		public virtual void VisitStarSchema(StarSchema s)
		{ s.Content.Accept(this); }

		public virtual void VisitPlusSchema(PlusSchema s)
		{ s.Content.Accept(this); }

		public virtual void VisitRepetitionSchema(RepetitionSchema s)
		{ s.Content.Accept(this); }

		public virtual void VisitVoidSchema(VoidSchema s)
		{ }

		public virtual void VisitBasicSchema(BasicSchema s)
		{ }

		public virtual void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
		{ }

		public virtual void VisitConstantSchema(ConstantSchema s)
		{ }

		public virtual void VisitChannelSchema(ChannelSchema s)
		{ s.Content.Accept(this); }

		public virtual void VisitFunctionSchema(FunctionSchema s)
		{
			s.Input.Accept(this);
			s.Output.Accept(this);
		}

		public virtual void VisitErrorSchema(ErrorSchema s)
		{ }

		public virtual void VisitBindSchema(BindSchema s)
		{ s.Content.Accept(this); }

		public virtual void VisitServiceSchema(ServiceSchema s)
		{
			foreach (KeyValuePair<string, ISchema> pair in s.Operations)
				pair.Value.Accept(this);
		}
	}

	public abstract class ExpanderSchemaVisitor : AbstractSchemaVisitor
	{
		public override void VisitPlusSchema(PlusSchema s)
		{ new SequenceSchema(s.Content, new StarSchema(s.Content)).Accept(this); }

		public override void VisitRepetitionSchema(RepetitionSchema s)
		{
			if (s.MinOccurs == 0) {
				if (s.MaxOccurs == 0)
					new VoidSchema().Accept(this);
				else {
					Debug.Assert(s.MaxOccurs > 0);
					UnionSchema.Make(new VoidSchema(), new SequenceSchema(s.Content, new RepetitionSchema(s.Content, 0, s.MaxOccurs - 1))).Accept(this);
				}
			} else {
				Debug.Assert(s.MinOccurs > 0);
				Debug.Assert(s.MaxOccurs >= s.MinOccurs);
				new SequenceSchema(s.Content, new RepetitionSchema(s.Content, s.MinOccurs - 1, s.MaxOccurs - 1)).Accept(this);
			}	
		}

		public override void VisitFunctionSchema(FunctionSchema s)
		{ new ChannelSchema(new SequenceSchema(new LabelledSchema(LabelSet.Singleton("arg"), s.Input), new ChannelSchema(s.Output, ChannelType.CAPABILITY.OUT)), s.Capability).Accept(this); }
	}

	public class ResolveNamesSchemaVisitor : AbstractSchemaVisitor
	{
		private IResolver resolver;

		public ResolveNamesSchemaVisitor(IResolver resolver)
		{ this.resolver = resolver; }

		public virtual void ResolveNames(ISchema s)
		{ s.Accept(this); }

		public override void VisitConstantSchema(ConstantSchema s)
		{
			if (s.Entry == null)
				s.Entry = resolver.GetEntry(s.Name);
		}
	}

	public class ValueEntriesOfSchemaVisitor : AbstractSchemaVisitor
	{
		private readonly ArraySet<IEntry> entries = new ArraySet<IEntry>();

		public static ISet<IEntry> GetEntries(ISchema schema)
		{
			ValueEntriesOfSchemaVisitor visitor = new ValueEntriesOfSchemaVisitor();
			schema.Accept(visitor);
			return visitor.entries;
		}

		public override void VisitBindSchema(BindSchema s)
		{
			Debug.Assert(s.Entry != null);
			entries.Add(s.Entry);
		}
	}

  public class ToStringSchemaVisitor : ISchemaVisitor
  {
    protected System.Text.StringBuilder builder = new System.Text.StringBuilder();

    public override string ToString()
    { return builder.ToString(); }

    public virtual void VisitLabelledSchema(LabelledSchema s)
    {
      builder.Append(s.Labels.ToString() + "[");
      if (!(s.Content is VoidSchema))
        s.Content.Accept(this);
      builder.Append("]");
    }

    public virtual void VisitSequenceSchema(SequenceSchema s)
    {
      if (s.Head is UnionSchema)
      {
        builder.Append('(');
        s.Head.Accept(this);
        builder.Append(')');
      }
      else
        s.Head.Accept(this);
      builder.Append(',');
      if (s.Tail is UnionSchema)
      {
        builder.Append('(');
        s.Tail.Accept(this);
        builder.Append(')');
      }
      else 
        s.Tail.Accept(this);
    }

    public virtual void VisitUnionSchema(UnionSchema s)
    {
      s.Left.Accept(this);
      builder.Append('|');
      s.Right.Accept(this);
    }

    public virtual void VisitStarSchema(StarSchema s)
    {
      if (s.Content is UnionSchema || s.Content is SequenceSchema)
      {
        builder.Append('(');
        s.Content.Accept(this);
        builder.Append(")*");
      }
      else 
      {
        s.Content.Accept(this);
        builder.Append('*');
      }
    }

    public virtual void VisitPlusSchema(PlusSchema s)
    {
      if (s.Content is UnionSchema || s.Content is SequenceSchema)
      {
        builder.Append('(');
        s.Content.Accept(this);
        builder.Append(")+");
      }
      else
      {
        s.Content.Accept(this);
        builder.Append('+');
      }
    }

    public virtual void VisitRepetitionSchema(RepetitionSchema s)
    {
      if (s.Content is UnionSchema || s.Content is SequenceSchema)
      {
        builder.Append('(');
        s.Content.Accept(this);
        builder.Append(')');
      }
      else
        s.Content.Accept(this);
      if (s.MinOccurs == 0 && s.MaxOccurs == 1)
        builder.Append('?');
      else 
        builder.Append("{" + s.MinOccurs + "," + s.MaxOccurs + "}");
    }

    public virtual void VisitVoidSchema(VoidSchema s)
    { builder.Append("()"); }

    public virtual void VisitBasicSchema(BasicSchema s)
		{ builder.Append(s.Type.ToString()); }

    public virtual void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
    { 
      if (s.Value.TypeOf() is StringType)
        builder.Append("\"" + s.Value.ToString() + "\""); 
      else  
        builder.Append(s.Value.ToString()); 
    }

    public virtual void VisitErrorSchema(ErrorSchema s)
		{ builder.Append("error"); }

    public virtual void VisitConstantSchema(ConstantSchema s)
    { builder.Append(s.Name); }

    public virtual void VisitChannelSchema(ChannelSchema s)
    {
      builder.Append("<");
      s.Content.Accept(this);
      builder.Append(">");
      switch (s.Capability)
      {
        case ChannelType.CAPABILITY.IN:
          builder.Append("^I");
          break;
        case ChannelType.CAPABILITY.OUT:
          builder.Append("^O");
          break;
        case ChannelType.CAPABILITY.INOUT:
          builder.Append("^IO");
          break;
      }
    }

    public virtual void VisitFunctionSchema(FunctionSchema s)
    {
      if (!(s.Input is LabelledSchema || s.Input is BaseType))
      { builder.Append("("); }
      s.Input.Accept(this);
      if (!(s.Input is LabelledSchema || s.Input is BaseType))
      { builder.Append(")"); }

      builder.Append("->");

      if (!(s.Output is LabelledSchema || s.Input is BaseType))
      { builder.Append("("); }
      s.Output.Accept(this);
      if (!(s.Output is LabelledSchema || s.Input is BaseType))
      { builder.Append(")"); }
    }

    public virtual void VisitBindSchema(BindSchema s)
		{
			builder.Append(s.Name);
			builder.Append(" : ");
			s.Content.Accept(this);
		}

    public virtual void VisitServiceSchema(ServiceSchema s)
		{
			builder.Append("{ ");
			foreach (KeyValuePair<string, ISchema> pair in s.Operations) {
        builder.AppendLine();
				builder.Append(" " + pair.Key);
				builder.Append(": ");
				pair.Value.Accept(this);
				builder.Append(";");
			}
      if (s.Operations.Count > 0)
      {
        builder.Remove(builder.Length - 1, 1);
        builder.AppendLine();
      }
			builder.Append(" }");
		}
  }

	public class SchemaToXmlVisitor : AbstractSchemaVisitor
	{
		protected readonly XmlWriter writer;

		public SchemaToXmlVisitor(XmlWriter writer)
		{ this.writer = writer; }

		public void ToXml(ISchema s)
		{ s.Accept(this); }

		public override void VisitLabelledSchema(LabelledSchema s)
		{
			writer.WriteStartElement("labelled");
			s.Labels.ToXml(writer);
			s.Content.Accept(this);
			writer.WriteEndElement(); // </labelled>
		}

		public override void VisitSequenceSchema(SequenceSchema s)
		{
			writer.WriteStartElement("sequence");
			s.Head.Accept(this);
			s.Tail.Accept(this);
			writer.WriteEndElement(); // </sequence>
		}

		public override void VisitUnionSchema(UnionSchema s)
		{
			writer.WriteStartElement("union");
			s.Left.Accept(this);
			s.Right.Accept(this);
			writer.WriteEndElement(); // </union>
		}

		public override void VisitStarSchema(StarSchema s)
		{
			writer.WriteStartElement("repeat");
			writer.WriteAttributeString("minOccurs", "0");
			writer.WriteAttributeString("maxOccurs", "unbound");
			s.Content.Accept(this);
			writer.WriteEndElement(); // </repeat>
		}

		public override void VisitPlusSchema(PlusSchema s)
		{
			writer.WriteStartElement("repeat");
			writer.WriteAttributeString("minOccurs", "1");
			writer.WriteAttributeString("maxOccurs", "unbound");
			s.Content.Accept(this);
			writer.WriteEndElement(); // </repeat>
		}

		public override void VisitRepetitionSchema(RepetitionSchema s)
		{
			writer.WriteStartElement("repeat");
			writer.WriteAttributeString("minOccurs", s.MinOccurs.ToString());
			writer.WriteAttributeString("maxOccurs", s.MaxOccurs.ToString());
			s.Content.Accept(this);
			writer.WriteEndElement(); // </repeat>
		}
		
		public override void VisitVoidSchema(VoidSchema s)
		{
			writer.WriteStartElement("void");
			writer.WriteEndElement(); // </void>
		}

		public override void VisitBasicSchema(BasicSchema s)
		{ s.Type.ToXml(writer); }

		public override void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
		{ s.Value.ToXml(writer); }

		public override void VisitErrorSchema(ErrorSchema s)
		{
			writer.WriteStartElement("error");
			writer.WriteEndElement(); // </error>
		}

		public override void VisitConstantSchema(ConstantSchema s)
		{
			writer.WriteStartElement("ref");
			writer.WriteAttributeString("name", s.Name);
			writer.WriteEndElement(); // </ref>
		}

		public override void VisitChannelSchema(ChannelSchema s)
		{
			writer.WriteStartElement("channel");
			string cap;
      switch (s.Capability)
      {
        case ChannelType.CAPABILITY.IN:
					cap = "I";
          break;
        case ChannelType.CAPABILITY.OUT:
					cap = "O";
          break;
        case ChannelType.CAPABILITY.INOUT:
					cap = "IO";
          break;
				default:
				  cap = "???";
					Debug.Assert(false);
					break;
      }
			writer.WriteAttributeString("capability", cap);
			s.Content.Accept(this);
			writer.WriteEndElement(); // </channel>
		}

		public override void VisitFunctionSchema(FunctionSchema s)
		{
			writer.WriteStartElement("function");
			s.Input.Accept(this);
			s.Output.Accept(this);
			writer.WriteEndElement(); // </function>
		}

		public override void VisitBindSchema(BindSchema s)
		{
			writer.WriteStartElement("bind");
			writer.WriteAttributeString("name", s.Name);
			s.Content.Accept(this);
			writer.WriteEndElement(); // </bind>
		}

    public override void VisitServiceSchema(ServiceSchema s)
    {
      writer.WriteStartElement("service");
      foreach (KeyValuePair<string, ISchema> operation in s.Operations)
      {
        writer.WriteStartElement("operation");
        writer.WriteAttributeString("name", operation.Key);
        operation.Value.Accept(this);
        writer.WriteEndElement();
      }
      writer.WriteEndElement(); // </service>
    }
	}

	public abstract class SchemaToTypeVisitor : ISchemaVisitor
	{
		private readonly IDictionary<IEntry, TypeRef> refMap = new Dictionary<IEntry, TypeRef>();
		private IType continuation;
		private IType result;
		
		public IType SchemaToType(ISchema s)
		{ return SchemaToType(s, new VoidType()); }

		public virtual IType SchemaToType(ISchema s, IType continuation)
		{
			this.continuation = continuation;
			s.Accept(this);
			return result;
		}

		private IType Repeat(ISchema s, IType continuation)
		{
			Debug.Assert(continuation != null);
			TypeRef entry = new TypeRef("U", null);
			IType u = new ConstantType("U", entry);
			entry.Type = new UnionType(continuation, SchemaToType(s, u));
			return u;
		}

		private IType Repeat(ISchema s, uint minOccurs, IType continuation)
		{
			if (minOccurs == 0)
				return Repeat(s, continuation);
			else
				return SchemaToType(s, Repeat(s, minOccurs - 1, continuation));
		}

		private IType Repeat(ISchema s, uint minOccurs, uint maxOccurs, IType continuation)
		{
			if (minOccurs == 0 && maxOccurs == 0)
				return continuation;
			else if (minOccurs == 0)
				return new UnionType(continuation, SchemaToType(s, Repeat(s, minOccurs, maxOccurs - 1, continuation)));
			else
				return SchemaToType(s, Repeat(s, minOccurs - 1, maxOccurs - 1, continuation));
		}

		protected abstract void IllegalSchema(ISchema s, string msg);

		// the only purpose of the first parameter is to give an appropriate error
		// message and possibly the location of s in the source code
		private IType ComposeWith(ISchema s, IType t, IType continuation)
		{
			if (continuation is VoidType)
				return t;
			else if (t is VoidType)
				return continuation;
			else if (t is LabelledType)
				return new SequenceType((LabelledType) t, continuation);
			else {
				IllegalSchema(s, "schema " + s + " cannot be followed by " + continuation);
				return new ErrorType();
			}
		}

		public void VisitLabelledSchema(LabelledSchema s)
		{
			IType c = continuation;
			result = ComposeWith(s, new LabelledType(s.Labels, SchemaToType(s.Content)), c);
		}

		public void VisitUnionSchema(UnionSchema s)
		{
			IType c = continuation;
			result = new UnionType(SchemaToType(s.Left, c), SchemaToType(s.Right, c));
		}

		public void VisitSequenceSchema(SequenceSchema s)
		{ result = SchemaToType(s.Head, SchemaToType(s.Tail, continuation)); }

		public void VisitStarSchema(StarSchema s)
		{ result = Repeat(s.Content, continuation); }

		public void VisitPlusSchema(PlusSchema s)
		{ result = Repeat(s.Content, 1, continuation); }

		public void VisitRepetitionSchema(RepetitionSchema s)
		{ result = Repeat(s.Content, s.MinOccurs, s.MaxOccurs, continuation); }

		public void VisitVoidSchema(VoidSchema s)
		{ result = continuation; }

		public void VisitBasicSchema(BasicSchema s)
		{ result = ComposeWith(s, new BasicType(s.Type), continuation); }

		public void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
		{ result = ComposeWith(s, new BasicTypeLiteralType(s.Value), continuation); }

		public void VisitErrorSchema(ErrorSchema s)
		{ result = new ErrorType(); }

		public void VisitChannelSchema(ChannelSchema s)
		{
			IType c = continuation;
			result = ComposeWith(s, new ChannelType(SchemaToType(s.Content), s.Capability), c);
		}

		public void VisitFunctionSchema(FunctionSchema s)
		{
			IType c = continuation;
			result = ComposeWith(s, new ChannelType(new SequenceType(new LabelledType(LabelSet.Singleton("arg"), SchemaToType(s.Input)), new ChannelType(SchemaToType(s.Output), ChannelType.CAPABILITY.OUT)), s.Capability), c);
		}

		public void VisitConstantSchema(ConstantSchema s)
		{
			IType c = continuation;
			Debug.Assert(s.Entry != null, "entry for " + s.Name + " not resolved");
			if (refMap.ContainsKey(s.Entry))
				result = ComposeWith(s, new ConstantType(s.Name, refMap[s.Entry]), c);
			else {
				TypeRef r = new TypeRef(s.Name);
				refMap.Add(s.Entry, r);
				Debug.Assert(s.Entry.Schema != null);
				r.Type = SchemaToType(s.Entry.Schema);
				result = ComposeWith(s, new ConstantType(s.Name, r), c);
			}
		}

		public void VisitBindSchema(BindSchema s)
		{
			IType c = continuation;
			result = ComposeWith(s, new Bind(s.Name, SchemaToType(s.Content), s.Entry), c);
		}

		public void VisitServiceSchema(ServiceSchema s)
		{
			IType c = continuation;
			IDictionary<string, IType> fields = new Dictionary<string, IType>();
			foreach (KeyValuePair<string, ISchema> pair in s.Operations)
				fields.Add(pair.Key, SchemaToType(pair.Value));
			result = ComposeWith(s, new ServiceType(fields), c);
		}
	}

	public class StripSchemaVisitor : AbstractSchemaVisitor
	{
		protected ISchema result;

		public StripSchemaVisitor()
		{ this.result = null; }

		public ISchema Strip(ISchema s)
		{
			s.Accept(this);
			return result;
		}

		public override void VisitLabelledSchema(LabelledSchema s)
		{
			ISchema content = Strip(s.Content);
			if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new LabelledSchema(s.Labels, content);
		}

		public override void VisitSequenceSchema(SequenceSchema s)
		{
			ISchema head = Strip(s.Head);
			ISchema tail = Strip(s.Tail);
			if (Object.ReferenceEquals(head, s.Head) && Object.ReferenceEquals(tail, s.Tail))
				result = s;
			else
				result = new SequenceSchema(head, tail);
		}

		public override void VisitUnionSchema(UnionSchema s)
		{
			ISchema left = Strip(s.Left);
			ISchema right = Strip(s.Right);
			result = UnionSchema.Make(left, right);
		}

		public override void VisitStarSchema(StarSchema s)
		{
			ISchema content = Strip(s.Content);
			if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new StarSchema(content);
		}

		public override void VisitPlusSchema(PlusSchema s)
		{
			ISchema content = Strip(s.Content);
			if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new PlusSchema(content);
		}

		public override void VisitRepetitionSchema(RepetitionSchema s)
		{
			ISchema content = Strip(s.Content);
			if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new RepetitionSchema(content, s.MinOccurs, s.MaxOccurs);
		}

		public override void VisitVoidSchema(VoidSchema s)
		{ result = s; }

		public override void VisitBasicSchema(BasicSchema s)
		{ result = s; }

		public override void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
		{ result = s; }

		public override void VisitConstantSchema(ConstantSchema s)
		{ result = s; }

		public override void VisitChannelSchema(ChannelSchema s)
		{
			ISchema content = Strip(s.Content);
			if (Object.ReferenceEquals(content, s.Content))
				result = s;
			else
				result = new ChannelSchema(content, s.Capability);
		}

		public override void VisitFunctionSchema(FunctionSchema s)
		{
			ISchema input = Strip(s.Input);
			ISchema output = Strip(s.Output);
			if (Object.ReferenceEquals(input, s.Input) && Object.ReferenceEquals(output, s.Output))
				result = s;
			else
				result = new FunctionSchema(input, output);
		}

		public override void VisitErrorSchema(ErrorSchema s)
		{ result = s; }

		public override void VisitBindSchema(BindSchema s)
		{ result = Strip(s.Content); }
	}

  public class FakeEntry : AbstractEntry 
  { 
    public FakeEntry(string name, ISchema schema): base(name, schema){}
  }

	public class GetHashCodeSchemaVisitor : ISchemaVisitor
	{
		private int result;
   
		public int Hash(ISchema s)
		{
			result = 0;
			s.Accept(this);
			return result;
		}

		public void VisitVoidSchema(VoidSchema s)
		{ result += 1; }

		public void VisitBasicSchema(BasicSchema s)
		{
      long tmp = result + 2;
      tmp += s.Type.GetHashCode();
      result = (int)tmp % Int32.MaxValue;
    }

    public void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
    {
      long tmp = result + 3;
      tmp += s.Value.GetHashCode();
      result = (int)tmp % Int32.MaxValue;
    }

		public void VisitLabelledSchema(LabelledSchema s)
		{
      long tmp = result + 4;
      foreach (string l in s.Labels.Labels)
        tmp += l.GetHashCode();
      result = (int)tmp % Int32.MaxValue;
		}

		public void VisitSequenceSchema(SequenceSchema s)
		{
      result += 5;
			s.Head.Accept(this);
			s.Tail.Accept(this);
		}

		public void VisitUnionSchema(UnionSchema s)
		{
      result += 6;
			s.Left.Accept(this);
			s.Right.Accept(this);
		}

		public void VisitStarSchema(StarSchema s)
		{
      result += 7;
			s.Content.Accept(this);
		}

		public void VisitPlusSchema(PlusSchema s)
		{
      result += 8;
			s.Content.Accept(this);
		}

		public void VisitRepetitionSchema(RepetitionSchema s)
		{
      long tmp = result + 9;
      tmp += s.MinOccurs.GetHashCode() + s.MaxOccurs.GetHashCode();
      result = (int)tmp % Int32.MaxValue;
			s.Content.Accept(this);
		}

		public void VisitConstantSchema(ConstantSchema s)
		{
      long tmp = result + 10;
      tmp += s.Name.GetHashCode();
      result = (int)(tmp % Int32.MaxValue);
    }

		public void VisitChannelSchema(ChannelSchema s)
		{
      long tmp = result + 11;
      tmp += s.Capability.GetHashCode();
      result = (int)tmp % Int32.MaxValue;
			s.Content.Accept(this);
		}

		public void VisitFunctionSchema(FunctionSchema s)
		{
      long tmp = result + 12;
      tmp += s.Capability.GetHashCode();
      result = (int)tmp % Int32.MaxValue;
			s.Input.Accept(this);
			s.Output.Accept(this);
		}

		public void VisitErrorSchema(ErrorSchema s)
    { result += 13; }

		public void VisitBindSchema(BindSchema s)
		{
      long tmp = result + 14;
      tmp += s.Name.GetHashCode();
      result = (int)tmp % Int32.MaxValue;
			s.Content.Accept(this);
		}

		public void VisitServiceSchema(ServiceSchema s)
		{
      long tmp = result + 15;
      result += 15;
			foreach (KeyValuePair<string, ISchema> op in s.Operations) {
        tmp += op.Key.GetHashCode();
				op.Value.Accept(this);
			}
      result = (int)tmp % Int32.MaxValue;
		}
	}

	public abstract class Schema : ISchema
	{
		public abstract void Accept(ISchemaVisitor visitor);

    private static ISchema any;
    public static ISchema Any 
    { get { return any; } }

    private static ISchema empty;
    public static ISchema Empty 
    { get { return empty; } }

    static Schema()
    {
      IEntry anyEntry = new FakeEntry("any", null);
      IEntry emptyEntry = new FakeEntry("empty", null);
      anyEntry.Schema = new StarSchema(
        UnionSchema.Make(new BasicSchema(new BoolType()),
          UnionSchema.Make(new BasicSchema(new IntType()),
            UnionSchema.Make(new BasicSchema(new FloatType()),
              UnionSchema.Make(new BasicSchema(new StringType()),
                UnionSchema.Make(new LabelledSchema(LabelSet.Any(), new ConstantSchema("any", anyEntry)),
                  UnionSchema.Make(new ChannelSchema(new ConstantSchema("empty", emptyEntry), ChannelType.CAPABILITY.OUT),
                    UnionSchema.Make(new ChannelSchema(new ConstantSchema("any", anyEntry), ChannelType.CAPABILITY.IN),
                      new ServiceSchema(new Dictionary<string, ISchema>())))))))));
      emptyEntry.Schema = new LabelledSchema(LabelSet.Empty(), new ConstantSchema("empty", emptyEntry));
      any = anyEntry.Schema;
      empty = emptyEntry.Schema;
    }

		public bool StructureEquals(ISchema obj)
		{
			if (Object.ReferenceEquals(this, obj))
				return true;
			else if (this is VoidSchema && obj is VoidSchema) {
				return true;
			} else if (this is BasicSchema && obj is BasicSchema) {
				BasicSchema s = (BasicSchema) this;
				BasicSchema t = (BasicSchema) obj;
				return s.Type.Kind == t.Type.Kind;
			} else if (this is BasicSchemaLiteralSchema && obj is BasicSchemaLiteralSchema) {
				BasicSchemaLiteralSchema s = (BasicSchemaLiteralSchema) this;
				BasicSchemaLiteralSchema t = (BasicSchemaLiteralSchema) obj;
				return s.Value == t.Value;
			} else if (this is LabelledSchema && obj is LabelledSchema) {
				LabelledSchema s = (LabelledSchema) this;
				LabelledSchema t = (LabelledSchema) obj;
				return s.Labels.Includes(t.Labels) && t.Labels.Includes(s.Labels) && s.Content.StructureEquals(t.Content);
			} else if (this is SequenceSchema && obj is SequenceSchema) {
				SequenceSchema s = (SequenceSchema) this;
				SequenceSchema t = (SequenceSchema) obj;
				return s.Head.StructureEquals(t.Head) && s.Tail.StructureEquals(t.Tail);
			} else if (this is UnionSchema && obj is UnionSchema) {
				UnionSchema s = (UnionSchema) this;
				UnionSchema t = (UnionSchema) obj;
				return s.Left.StructureEquals(t.Left) && s.Right.StructureEquals(t.Right);
			} else if (this is StarSchema && obj is StarSchema) {
				StarSchema s = (StarSchema) this;
				StarSchema t = (StarSchema) obj;
				return s.Content.StructureEquals(t.Content);
			} else if (this is PlusSchema && obj is PlusSchema) {
				PlusSchema s = (PlusSchema) this;
				PlusSchema t = (PlusSchema) obj;
				return s.Content.StructureEquals(t.Content);
			} else if (this is RepetitionSchema && obj is RepetitionSchema) {
				RepetitionSchema s = (RepetitionSchema) this;
				RepetitionSchema t = (RepetitionSchema) obj;
				return s.MinOccurs == t.MinOccurs && s.MaxOccurs == t.MaxOccurs && s.Content.StructureEquals(t.Content);
			} else if (this is ChannelSchema && obj is ChannelSchema) {
				ChannelSchema s = (ChannelSchema) this;
				ChannelSchema t = (ChannelSchema) obj;
				return s.Capability == t.Capability && s.Content.StructureEquals(t.Content);
			} else if (this is ConstantSchema && obj is ConstantSchema) {
				ConstantSchema s = (ConstantSchema) this;
				ConstantSchema t = (ConstantSchema) obj;
				return s.Name == t.Name && s.Entry == t.Entry;
			} else if (this is ServiceSchema && obj is ServiceSchema) {
				ServiceSchema s = (ServiceSchema) this;
				ServiceSchema t = (ServiceSchema) obj;
				foreach (KeyValuePair<string, ISchema> op in s.Operations) {
					if (!t.Operations.ContainsKey(op.Key))
						return false;
					if (!op.Value.StructureEquals(t.Operations[op.Key]))
						return false;
				}
				return s.Operations.Count == t.Operations.Count;
			} else if (this is ErrorSchema && obj is ErrorSchema) {
				return true;
			} else {
				return false;
			}
		}

		public int Hash()
		{ return new GetHashCodeSchemaVisitor().Hash(this); }

    public override string ToString()
		{
			ToStringSchemaVisitor visitor = new ToStringSchemaVisitor();
			Accept(visitor);
			return visitor.ToString();
		}

		public ISchema Strip()
		{ return new StripSchemaVisitor().Strip(this); }
	}

  public class LabelledSchema : Schema
  {
    private readonly ILabelSet labels;
    private readonly ISchema content;

    public ILabelSet Labels { get { return labels; } }
    public ISchema Content { get { return content; } }

    public LabelledSchema(ILabelSet labels, ISchema content)
    {
      this.labels = labels;
      this.content = content;
    }

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitLabelledSchema(this); }
  }

  public class SequenceSchema : Schema
  {
    private readonly ISchema head;
    private readonly ISchema tail;

    public ISchema Head { get { return head; } }
    public ISchema Tail { get { return tail; } }

    public SequenceSchema(ISchema head, ISchema tail)
    {
      this.head = head;
      this.tail = tail;
    }

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitSequenceSchema(this); }
  }

  public class UnionSchema : Schema
  {
    private readonly ISchema left;
    private readonly ISchema right;

    public ISchema Left { get { return left; } }
    public ISchema Right { get { return right; } }

    protected UnionSchema(ISchema left, ISchema right)
    {
      this.left = left;
      this.right = right;
    }

		public static ISchema MakeNew(ISchema left, ISchema right)
		{ return new UnionSchema(left, right); }

		public static ISchema Make(ISchema left, ISchema right)
		{
			if (left.StructureEquals(Schema.Empty))
				return right;
			else if (left.StructureEquals(Schema.Any))
				return left;
			else if (left.StructureEquals(right))
				return left;
			else
				return MakeNew(left, right);
		}

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitUnionSchema(this); }
  }

  public class StarSchema : Schema
  {
    private readonly ISchema content;

    public ISchema Content { get { return content; } }

    public StarSchema(ISchema content)
    { this.content = content; }

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitStarSchema(this); }
  }

  public class PlusSchema : Schema
  {
    private readonly ISchema content;

    public ISchema Content { get { return content; } }

    public PlusSchema(ISchema content)
    { this.content = content; }

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitPlusSchema(this); }
  }

  public class RepetitionSchema : Schema
  {
    private readonly ISchema content;
    private readonly uint minOccurs;
    private readonly uint maxOccurs;

    public ISchema Content { get { return content; } }
    public uint MinOccurs { get { return minOccurs; } }
    public uint MaxOccurs { get { return maxOccurs; } }

    public RepetitionSchema(ISchema content, uint minOccurs, uint maxOccurs)
    {
      this.content = content;
      this.minOccurs = minOccurs;
      this.maxOccurs = maxOccurs;
    }

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitRepetitionSchema(this); }
  }

  public class VoidSchema : Schema
  {
		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitVoidSchema(this); }
	}

	public class BasicSchema : Schema
	{
		private readonly IBasicType type;

		public IBasicType Type { get { return type; } }

		public BasicSchema(IBasicType type)
		{ this.type = type; }

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitBasicSchema(this); }
	}

	public class BasicSchemaLiteralSchema : Schema
	{
		private readonly IBasicTypeLiteral value;

		public IBasicTypeLiteral Value { get { return value; } }

		public BasicSchemaLiteralSchema(IBasicTypeLiteral value)
		{ this.value = value; }

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitBasicSchemaLiteralSchema(this); }
	}

  public class ErrorSchema : Schema
  {
		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitErrorSchema(this); }
	}

  public class ConstantSchema : Schema
  {
    private readonly string name;
		private IEntry entry;

    public string Name { get { return name; } }
		public IEntry Entry {
			get { return entry; }
			set { entry = value; }
		}

    public ConstantSchema(string name) : this(name, null)
    { }

		public ConstantSchema(string name, IEntry entry)
		{
			this.name = name;
			this.entry = entry;
		}

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitConstantSchema(this); }
  }

  public class ChannelSchema : Schema
  {
    private ChannelType.CAPABILITY capability;
    private readonly ISchema content;

    public ISchema Content { get { return content; } }
    public ChannelType.CAPABILITY Capability { get { return capability; } }

    public ChannelSchema(ISchema content, ChannelType.CAPABILITY capability)
    {
      this.content = content;
      this.capability = capability;
    }

		public override void Accept(ISchemaVisitor visitor)
		{ visitor.VisitChannelSchema(this); }
  }

  public class FunctionSchema : Schema
  {
    private readonly ChannelType.CAPABILITY capability;
    private readonly ISchema input;
    private readonly ISchema output;

    public ISchema Input { get { return input; } }
    public ISchema Output { get { return output; } }
    public ChannelType.CAPABILITY Capability { get { return capability; } }

    public FunctionSchema(ISchema input, ISchema output) : this(input, output, ChannelType.CAPABILITY.OUT)�d7�7�so�iH�끤������9�Vխ�[/�[ֺ�6��n[�i[�i[�i[�i[�i[�i�6 @Ji'0����
p�����m�5�lf�7��,mF ���E���,"�f�p !��u�~oݯ[n#..�
�Rڃ� ��@x
8��Z �HP��y�	{�t7����.��͍a�A}`Ji,�t 8����&�'=|�Bbu!�����5_�=u/c���M)H)��?�u���R��.�ȋf��TPEv	=I~�u$�%$�pus����y/sPΛYu�8���)���q�W%r7�����Џ��
6�,�}��x����L��E���������Q8��5�$����H�E4(���:�ߖ�`�H���b��8�w."�^�]�g�^G�Xu#)�C���]�(�Nz`J�i`p5�� "���-!��H���o��.V�1��&y9w��!$Ԣ���ụx��8�4�o;ƹS��j.e�)�da��`�i=�n�����E��C����t�&<�D��p�v`y\@5��C�������!�0�t�Cb�����ϩ��a4(�xQe�y](�n�kH�I$H��H�(3<y	������� =�e3;�.������qDz=�2]E"�!A������ _��QS��u����K����`
�UG�uٹUW�?�BV���R��.�ſ]L)v@C����ʨ)W��%���9�afM������O��n��Pӝg��_Cm�3�+�1w�
�mc�QCQAͥ�WC�h8����̾i|�c���o�[���F"�P��C�ڍD� A����-	�R��'�#�Y��8�0z���x��w��߭�-��'��(�P���� ����P���(�l�!Ůj�N�F��w����e.���mO8���K< /�u���=B�B��ٹ��Rg���v��	/��A���!��?>7�3f���͘�=0�3��^�09h����sXv.��[S��(<�b�è�Α "�����������z�23{'�t�-9��"&KdA�Q3xxi���<�g#䰠���� �>��¼�[,�ŒY�v�8���l�E��i1��hD�2���ٻM��qs����{���4���L���Pa
�^5�������� 
�G�7����&´a܎0G?\0�\Y38�櫃h��n�,����7b�(j��m�-2a/��٢e0�4��֐��!/,9�����}\�F�c��0 �K�Cq�AK�yM+�