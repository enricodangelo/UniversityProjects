==========
PIDUCE 1.0
==========

PiDuce is a distributed implementation of pi-like process calculi with
native XML datatypes developed at the Department of Computer Science of
Bologna.

PiDuce relies on a new model for the distributed implementation of
pi-like calculi, which permits strong correctness results that are
simple to prove -- the PiDuce Distributed Machine. This machine, as the
Join Calculus Machine, groups processes at their channels (or
locations), in contrast with the more common approach of incorporating
additional location information within processes. In contrast with the
Join Calculus Machine that does not support messages carrying channels
with input capability, the PiDuce Distributed Machine allows such
feature and implements it by means of linear forwarders.

PiDuce is interoperable with standard Web services. In particular PiDuce
uses WSDL as language for describing channel interfaces, SOAP as
protocol for sending XML messages over channels and HTTP as transport
protocol. In PiDuce services with only one operation can be imported.

PiDuce provides for the PiDuce Compiler and the PiDuce Distributed
Machine. In particular this distribution includes the following
directories:

- "Common" containing some utility files
- "Types" containing PiDuce data types
- "Compiler" containing the PiDuce compiler
- "Machine" containing the Piduce Distributed Machine
- "Examples" containing some simple examples
- "Binaries" containing executables and dynamic link libraries (this 
  directory is not present if you have downloaded source files 
  without executables but it will be created during the installation)

============
INSTALLATION
============

PiDuce requires a C# compiler and an implementation of the CLI Common
Language Infrastructure (CLI). This distribution has been tested with
the Microsoft C# compiler (csc) and the mono compiler (mcs). Run "make"
to compile (make COMPILER="csc" if you are going to use the Microsoft C#
compiler). The installation creates the directory "Binaries" containing
the following files:

- Binaries/common.dll 
- Binaries/types.dll 
- Binaries/PiDuceCompiler.exe
- Binaries/PiDuceMachine.exe

The PiDuceCompiler compiles programs generating an XML bytecode 
that can be executed by a PiDuceMachine.

==================
EXECUTING PROGRAMS
==================

Once you have written a PiDuce program you can compile and run it.
Compilation typechecks and generates the XML bytecode. When the filename
is followed by "@URI" the bytecode is uploaded and executed by the
PiDuce machine located at the specified address. For instance:

	PiDuceCompiler fact.bopi@http://localhost:1811/

compiles the program "fact.bopi" and loads the bytecode to a machine
that is waiting for code (in this case the machine is located in the
local host). The PiDuce machine can be started as deamon waiting for
bytecodes to be uploaded on a given port (the default port number is
1811):

	PiDuceMachine /port:1811 /d 

or it can execute a single XML bytecode:

	PiDuceMachine fact.bopi.xml

==============
PiDuce Grammar
==============

- Programs

D ::=
      P
      schemadef U = S and ... and U = S in D

- Patterns

F ::= 
      ()
      bool
      int
      float
      string
      n
      f
      true
      false
      "s"
      <S?>K
      F ->K F
      F | F
      U
      x : F
      (F)
      L[F?]
      F, F
      F*
      F+
      F{n}
      F{m,n}
      F?
      { x : F; ...; x : F }

K ::= 
	  (empty, default = ^O)
      ^I
      ^O
      ^IO

L ::=
      a
      ~
      {a, ..., a}
      {~ \ a, ..., a}

S ::= F (no bindings)

- Expressions

E ::=
      x
      `x
      false
      true
      n
      f
      "s"
      a[E?]
      E, E
      E op E
      op E
      (E)
      E.x
      { x = E; ...; x = E }

where op in { +, -, *, /, ==, >, <, <=, >=, != }   

- Processes

P ::= 
      nil
      new x O in P
      import x O wsdl="..." in P
      E!E
      [*] E?F => P
      spawn { P } P
      match E with { F => P | ... | F => P }
      [*] join { J => P | ... | J => P }
      let F = E in P
      if E then P [else P]
      { P }

O ::=
      : <S>
      { x : <S>; ...; x : <S> } [location="..."]

J ::=
      E?F
      J & J


