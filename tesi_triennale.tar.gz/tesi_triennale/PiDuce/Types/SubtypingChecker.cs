// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using PiDuce.Common;

//using Assumption = PiDuce.Common.Pair<PiDuce.Common.ISchema, PiDuce.Common.ISchema>;

namespace PiDuce.Types
{ 
#if NEW_SCHEMAS
	public class SubtypingChecker
	{
    private readonly EmptynessChecker ec;
    private readonly DeterminednessChecker dc;
		private readonly HandlesOfSchemaVisitor handlesOf;
		private readonly IDictionary<Assumption, bool> assumptions;

		private class Assumption
		{
			private readonly Pair<ISchema, ISchema> pair;

			public Assumption(ISchema s, ISchema t)
			{ this.pair = new Pair<ISchema, ISchema>(s, t); }

			public override bool Equals(Object obj)
			{
				if (obj is Assumption) {
					Assumption a = (Assumption) obj;
					bool res = pair.First.StructureEquals(a.pair.First) && pair.Second.StructureEquals(a.pair.Second);
					//if (!res && pair.First.Hash() == a.pair.First.Hash())
					 //Console.WriteLine("===> comparing {0} and {1} = {2}", pair, a.pair, res);
					return res;
				} else
					return false;
			}

			public override int GetHashCode()
			{ return pair.First.Hash() ^ pair.Second.Hash(); }
			//{ return pair.GetHashCode(); }
		}

		public SubtypingChecker(EmptynessChecker ec, DeterminednessChecker dc)
		{
			this.ec = ec;
			this.dc = dc;
			this.handlesOf = new HandlesOfSchemaVisitor(ec);
			this.assumptions = new Dictionary<Assumption, bool>();
		}

		public bool IsSubschema(ISchema s, ISchema t)
		{
// Console.WriteLine("IN CHECK SUBSCHEMA: {0} <: {1}", s, t);
			Assumption pair = new Assumption(s, t);
			bool res;
			if (assumptions.TryGetValue(pair, out res)) {
// Console.WriteLine("OUT CHECK SUBSCHEMA: {0} <: {1} = {2} (in assumptions)", s, t, res);
				return res;
			}

			assumptions[pair] = true;
			res = assumptions[pair] = SubSchemaAux(s, t);
// Console.WriteLine("OUT CHECK SUBSCHEMA: {0} <: {1} = {2}", s, t, res);
			return res;
		}

		private IList<IHandle> GetHandles(ISchema s)
		{ return handlesOf.GetHandles(s); }

		private bool SubSchemaPowerSet(ISchema s1, ISchema s2, IList<ISchema> u1, IList<ISchema> u2, int n, ISchema t1, ISchema t2)
		{
			if (n == 0)
				return IsSubschema(s1, t1) || IsSubschema(s2, t2);
			else
				return SubSchemaPowerSet(s1, s2, u1, u2, n - 1, AddSchema(t1, u1[n - 1]), t2)
					&& SubSchemaPowerSet(s1, s2, u1, u2, n - 1, t1, AddSchema(t2, u2[n - 1]));
		}

		private static bool CapabilityLe(ChannelType.CAPABILITY a, ChannelType.CAPABILITY b)
		{
			return (a == ChannelType.CAPABILITY.INOUT) || (a == b);
		}

		private ISchema AddSchema(ISchema s, ISchema t)
		{ return UnionSchema.Make(s, t); }

		private bool IsSubschema(IHandle hs, IList<IHandle> tHandles)
		{
			if (hs is VoidHandle) {
				foreach (IHandle ht in tHandles)
					if (ht is VoidHandle)
						return true;
				return false;	
			} else if (hs is Handle<BasicSchema>) {
				Handle<BasicSchema> bs = (Handle<BasicSchema>) hs;
				ISchema u = Schema.Empty;
				foreach (IHandle ht in tHandles)
					if (ht is Handle<BasicSchema>) {
						Handle<BasicSchema> bt = (Handle<BasicSchema>) ht;
						if (bs.Head.Type.Kind == bt.Head.Type.Kind)
							u = AddSchema(u, bt.Tail);
					}		
				return IsSubschema(bs.Tail, u);
			} else if (hs is Handle<BasicSchemaLiteralSchema>) {
				Handle<BasicSchemaLiteralSchema> bs = (Handle<BasicSchemaLiteralSchema>) hs;
				ISchema u = Schema.Empty;
				foreach (IHandle ht in tHandles)
					if (ht is Handle<BasicSchema>) {
						Handle<BasicSchema> bt = (Handle<BasicSchema>) ht;
						if (bs.Head.Value.TypeOf().Kind == bt.Head.Type.Kind)
							u = AddSchema(u, bt.Tail);
					} else if (ht is Handle<BasicSchemaLiteralSchema>) {
						Handle<BasicSchemaLiteralSchema> bt = (Handle<BasicSchemaLiteralSchema>) ht;
						if (bs.Head.Value.Equals(bt.Head.Value))
							u = AddSchema(u, bt.Tail);
					}
				return IsSubschema(bs.Tail, u);	
			} else if (hs is Handle<ChannelSchema>) {
				Handle<ChannelSchema> cs = (Handle<ChannelSchema>) hs;
				ISchema u = Schema.Empty;
				foreach (IHandle ht in tHandles)
					if (ht is Handle<ChannelSchema>) {
						Handle<ChannelSchema> ct = (Handle<ChannelSchema>) ht;
						if (CapabilityLe(cs.Head.Capability, ct.Head.Capability)
								// to understand the following conditions just read them
								// as implications:
								// (ct.Head.Capability <= IN) => S <: T (covariance)
								// (ct.Head.Capability <= OUT) => T <: S (contravariance)
							&& (!CapabilityLe(ct.Head.Capability, ChannelType.CAPABILITY.IN) || IsSubschema(cs.Head.Content, ct.Head.Content)
							&& (!CapabilityLe(ct.Head.Capability, ChannelType.CAPABILITY.OUT) || IsSubschema(ct.Head.Content, cs.Head.Content))))
								u = AddSchema(u, ct.Tail);
					}			
				return IsSubschema(cs.Tail, u);
			} else if (hs is Handle<LabelledSchema>) {
				Handle<LabelledSchema> ls = (Handle<LabelledSchema>) hs;
				Queue<ILabelSet> labelsQueue = new Queue<ILabelSet>();
				labelsQueue.Enqueue(ls.Head.Labels);
				while (labelsQueue.Count > 0) {
					ILabelSet labels = labelsQueue.Dequeue();
					IList<ISchema> u1 = new List<ISchema>();
					IList<ISchema> u2 = new List<ISchema>();
					foreach (IHandle ht in tHandles)
						if (ht is Handle<LabelledSchema>) {
							Handle<LabelledSchema> lt = (Handle<LabelledSchema>) ht;
							if (labels.Intersects(lt.Head.Labels)) {
								if (!lt.Head.Labels.Includes(labels)) {
									labelsQueue.Enqueue(LabelSet.Difference(labels, lt.Head.Labels));
									labels = LabelSet.Intersection(labels, lt.Head.Labels);
								}
								u1.Add(lt.Head.Content);
								u2.Add(lt.Tail);
							}
						}	
					if (!SubSchemaPowerSet(ls.Head.Content, ls.Tail, u1, u2, u1.Count, Schema.Empty, Schema.Empty))
						return false;
				}

				return true;
			} else if (hs is Handle<ServiceSchema>) {
				Handle<ServiceSchema> ss = (Handle<ServiceSchema>) hs;
				ISchema u = Schema.Empty;
				foreach (IHandle ht in tHandles)
					if (ht is Handle<ServiceSchema>) {
						Handle<ServiceSchema> st = (Handle<ServiceSchema>) ht;
						bool widthRes = true;
						foreach (KeyValuePair<string, ISchema> op in ss.Head.Operations)
							if (!st.Head.Operations.ContainsKey(op.Key)
								|| !IsSubschema(op.Value, st.Head.Operations[op.Key])) {
								widthRes = false;
								break;
							}
						if (widthRes)
							u = AddSchema(u, st.Tail);
					}
				return IsSubschema(ss.Tail, u);
			} else {
				Debug.Assert(false); // IMPOSSIBLE
				return false;
			}
		}

		private bool SubSchemaAux(ISchema s, ISchema t)
		{
			IList<IHandle> sHandles = GetHandles(s);
			IList<IHandle> tHandles = GetHandles(t);
#if false
			Console.WriteLine(">>>>>>>>>");
			Console.WriteLine("HANDLES OF {0}:", s);
			foreach (IHandle h in sHandles)
				Console.WriteLine("  {0}", h.AsSchema());
			Console.WriteLine("HANDLES OF {0}:", t);
			foreach (IHandle h in tHandles)
				Console.WriteLine("  {0}", h.AsSchema());
			Console.WriteLine("<<<<<<<<<");
#endif
			if (sHandles.Count == 0)
				return true;
			else if (tHandles.Count == 0)
				return false;
			else {
				foreach (IHandle hs in sHandles) {
					if (!IsSubschema(hs, tHandles))
						return false;
				}
			}

			return true;
		}
	}
#else
  public class SubtypingChecker
  {
    private EmptynessChecker ec = new EmptynessChecker();
    private DeterminednessChecker dc = new DeterminednessChecker();
    private ICollection<Assumption> aF = new List<Assumption>();
    private ICollection<Assumption> aT = new List<Assumption>();
    public SubtypingChecker(EmptynessChecker ec, DeterminednessChecker dc)
    {
      this.ec = ec;
      this.dc = dc;
    }
    
    public SubtypingChecker(): this(new EmptynessChecker(), new DeterminednessChecker())
    {}
    
    public SubtypingChecker(EmptynessChecker ec): this(ec, new DeterminednessChecker())
    {}
    
    public SubtypingChecker(DeterminednessChecker dc): this(new EmptynessChecker(), dc)
    {}

    public bool IsSubtype(IType s, IType t)
    {
      bool res = IsSubtype(s, t, aT, aF, ec, dc);
      // Console.WriteLine("{0} <: {1}={2}", s, t, res);
      return res;
    }

    private static bool IsSubtype(IType s, IType t, ICollection<Assumption> aT,
      ICollection<Assumption> aF, EmptynessChecker ec, DeterminednessChecker dc)
    {       
      if (ec.IsEmpty(s)) return true;
      if (s.IsVoidType() && t.IsVoidType()) return true;
      else if (s.IsVoidType() && (t.IsBaseType() || t.IsChannelType() || t.IsLabelledType())) return false;
      else if (s.IsErrorType() || t.IsErrorType()) return true;
      else if (s.IsBaseType() && t.IsBaseType()) {
			// Console.WriteLine("{0} {1} {2} {3} ========", s is BasicType, s, t is BasicType, t);
				if (s is BasicType && t is BasicType && ((BasicType) s).Type.Equals(((BasicType) t).Type)) {
					return true;
				} else if (s is BasicTypeLiteralType && t is BasicType && ((BasicTypeLiteralType) s).Value.TypeOf().Equals(((BasicType) t).Type))
					return true;
				else if (s is BasicTypeLiteralType && t is BasicTypeLiteralType && ((BasicTypeLiteralType) s).Value.Equals(((BasicTypeLiteralType) t).Value))
					return true;
				else
					return false;
      } else if (s.IsLabelledType() && t.IsLabelledType()) { 
        LabelledType l1 = s.AsLabelledType();
        LabelledType l2 = t.AsLabelledType();
        return l2.Labels.Includes(l1.Labels) && IsSubtype(l1.Content, l2.Content, aT, aF, ec, dc);
      } else if (s.IsLabelledType() && (t.IsBaseType() || t.IsChannelType() || t is ServiceType))
        return false;
      else if (s.IsLabelledType())
        return IsSubtype(new SequenceType(s.AsLabelledType(), new VoidType()), t, aT, aF, ec, dc);
      else if (t.IsLabelledType())
        return IsSubtype(s, new SequenceType(t.AsLabelledType(), new VoidType()), aT, aF, ec, dc);
      else if (s.IsBaseType() && (t.IsLabelledType() || t.IsChannelType() || t is ServiceType))
        return false;
      else if (s.IsChannelType() && (t.IsLabelledType() || t.IsBaseType() || t is ServiceType))
        return false;
      else if (s is ServiceType && (t.IsLabelledType() || t.IsBaseType() || t.IsChannelType()))
        return false;
        /* TypesAlgorithms for channels works as follow &ltS1&gt^K1 &lt: &ltS2&gt^K2 :
        * if K2 is included in or is equal to K1 then 
        * if K2={Input Capability} then S1&lt:S2 (covariance)
        * if K2={Output Capability} then S2&lt:S1 (contravariance)
        * if K2={Output Capability, InputCapability} then S2&lt:S1 &&  S1&lt:S2 (invariance)
        * else return false; */
      else if (s.IsChannelType() && t.IsChannelType()) 
      {
        ChannelType chan1 = s.AsChannelType();
        ChannelType chan2 = t.AsChannelType();
        if (ChannelType.HasMoreEqCapability(chan1.Capability, chan2.Capability))
        {	  
          bool isSubtype = true;
          if (chan2.HasInputCapability())
            isSubtype &= IsSubtype(chan1.Content, chan2.Content, aT, aF, ec, dc);
          if (chan2.HasOutputCapability())
            isSubtype &= IsSubtype(chan2.Content, chan1.Content, aT, aF, ec, dc);
          return isSubtype;
        }
        return false;
      }
			else if (s is ServiceType && t is ServiceType) {
				ServiceType r = (ServiceType) t;
				foreach (KeyValuePair<string, IType> pair in ((ServiceType) s).Operations) {
					if (!r.Operations.ContainsKey(pair.Key) || !IsSubtype(pair.Value, r.Operations[pair.Key], aT, aF, ec, dc))
						return false;
				}
				return true;
      } else { 
				// TODO: handle case with record types
        Assumption ass = new Assumption(s, t);
        if (aT.Contains(ass))
          return true;
        else if (aF.Contains(ass))
          return false;
        else
        {
          bool res = false;
          aT.Add(ass);
          if (s.IsSequenceType() && (t.IsSequenceType() || t.IsUnionType() || t.IsConstantType()))
            res = AuxSubtype(s.AsSequenceType(), t, aT, aF, ec, dc);
          else if (s.IsSequenceType()) res = false;
          else if (s.IsConstantType())
            res = IsSubtype(s.AsConstantType().Entry.Type, t, aT, aF, ec, dc);
          else if (s.IsUnionType())
            res = IsSubtype(s.AsUnionType().Fst, t, aT, aF, ec, dc) && 
              IsSubtype(s.AsUnionType().Snd, t, aT, aF, ec, dc);
          else if (s.IsVoidType())
          {
            if (t.IsUnionType())
              res = IsSubtype(s, t.AsUnionType().Fst, aT, aF, ec, dc) ||
                IsSubtype(s, t.AsUnionType().Snd, aT, aF, ec, dc);
            else if (t.IsSequenceType())
              res = IsSubtype(s, t.AsSequenceType().Top, aT, aF, ec, dc) &&
                IsSubtype(s, t.AsSequenceType().Tail, aT, aF, ec, dc);
            else if (t.IsConstantType())
              res = IsSubtype(s, t.AsConstantType().Entry.Type, aT, aF, ec, dc);
          }
          else if (s.IsBaseType() || s.IsChannelType() || s is ServiceType)
          {
            if (t.IsUnionType())
              res = IsSubtype(s, t.AsUnionType().Fst, aT, aF, ec, dc) ||
                IsSubtype(s, t.AsUnionType().Snd, aT, aF, ec, dc);
            else if (t.IsConstantType())
              res = IsSubtype(s, t.AsConstantType().Entry.Type, aT, aF, ec, dc);
          }
          else if (s.IsVoidType() && t.IsSequenceType())
            res = IsSubtype(s, t.AsSequenceType().Top, aT, aF, ec, dc) &&
              IsSubtype(s, t.AsSequenceType().Tail, aT, aF, ec, dc);
          else if (t.IsUnionType())
            res = IsSubtype(s, t.AsUnionType().Fst, aT, aF, ec, dc) ||
              IsSubtype(s, t.AsUnionType().Snd, aT, aF, ec, dc);
          else if (t.IsConstantType())
            res = IsSubtype(s, t.AsConstantType().Entry.Type, aT, aF, ec, dc);
          else throw new ApplicationException("IsSubtype: Unhandled case " + s.GetType() + "?<:?" + t.GetType());
          if (!res)
          {
            aT.Remove(ass);
            aF.Add(ass);
          }
          return res;
        }
      }
    }
    
    private static bool AuxSubtype(SequenceType s, IType t, 
      ICollection<Assumption> aT, ICollection<Assumption> aF, 
      EmptynessChecker ec, DeterminednessChecker dc)
    {
      if (t.IsConstantType())
        return IsSubtype(s, t.AsConstantType().Entry.Type, aT, aF, ec, dc);
      else if (t.IsSequenceType())
        return IsSubtype(s.Top, t.AsSequenceType().Top, aT, aF, ec, dc) &&
          IsSubtype(s.Tail, t.AsSequenceType().Tail, aT, aF, ec, dc);
      else if (t.IsUnionType())
      {
        if (IsValueType(s, new List<IType>()))
          return IsSubtype(s, t.AsUnionType().Fst, aT, aF, ec, dc) || IsSubtype(s, t.AsUnionType().Snd, aT, aF, ec, dc);
        //this simplified version of the algorithm can be applied only if t is determined 
        else if (dc.IsDetermined(t))
        {
          return IsSubtype(s, t.AsUnionType().Fst, aT, aF, ec, dc) || 
            IsSubtype(s, t.AsUnionType().Snd, aT, aF, ec, dc);
        }
        else if (dc.IsDetermined(t))
          return AuxDetSubTyping(s, t.AsUnionType(), aT, aF, ec, dc);
        else //if (!dc.IsDetermined(t))
          return AuxNDetSubtyping(s, t.AsUnionType(), aT, aF, ec, dc);
      }
      else Debug.Assert(false);
      return false;
    }

    private static bool AuxDetSubTyping(SequenceType s, UnionType u, 
      ICollection<Assumption> aT, ICollection<Assumption> aF,
      EmptynessChecker ec, DeterminednessChecker dc) 
    {
      LabelledType top = s.Top.AsLabelledType();
      ILabelSet l = top.Labels;
      HandleSet first = dc.GetFirst(u.Fst);
      ILabelSet inters = LabelSet.Intersection(l, first.Labels);
      ILabelSet diff = LabelSet.Difference(l, first.Labels);
      bool isSubtype = true;
      SequenceType seq1 = new SequenceType(new LabelledType(inters, top.Content), s.Tail);
      SequenceType seq2 = new SequenceType(new LabelledType(diff, top.Content), s.Tail);
      if (!inters.IsEmpty())
        isSubtype &= IsSubtype(seq1, u.Fst, aT, aF, ec, dc);
      if (!diff.IsEmpty())
        isSubtype &= IsSubtype(seq2, u.Snd, aT, aF, ec, dc);
      return isSubtype;
    }

    private static bool AuxNDetSubtyping(SequenceType s, UnionType u, 
      ICollection<Assumption> aT, ICollection<Assumption> aF,
      EmptynessChecker ec, DeterminednessChecker dc)
    {
      IList<SequenceType> expansion = TypesOperations.Expand(u);
      expansion = Filter(s, expansion);
      List<HandleSet> first = new List<HandleSet>();
      foreach (SequenceType seq in expansion)
      {
        HandleSet handle = new HandleSet();
        handle.AddLabelHandle(seq.Top.Labels);
        first.Add(handle);
      }
      //normalize the schema with respect to "first". 
      //A label of exptop is either included or disjoint from each label of first
      IType normalizedType = Normalize(s.Top.AsLabelledType(), s.Tail, first);
      if (normalizedType.IsUnionType())
      {
        IType tmp = normalizedType.AsUnionType().Fst;
        while (normalizedType.IsUnionType())
        {
          tmp = new UnionType(tmp, normalizedType.AsUnionType().Snd);
          normalizedType = normalizedType.AsUnionType().Snd;
        }
        return IsSubtype(tmp, u, aT, aF, ec, dc);
      }
      else
      {
        Debug.Assert(normalizedType.IsSequenceType());
        ulong subsetNum = ((ulong)1) << expansion.Count;
        bool isSub = true;
        //only for debugging purposes
        if (expansion.Count > 10)
          Console.WriteLine("Expensive subtyping: Things to prove = {0}", subsetNum);
        for (ulong c = 0; c < subsetNum && isSub; c++)
        {
          IList<IType> inter1 = new List<IType>();
          IList<IType> inter2 = new List<IType>();
          for (int i = 0; i < expansion.Count; i++)
          {
            SequenceType seq = (SequenceType)expansion[i];
            ulong bitmask = ((ulong)1) << i;
            if ((c & bitmask) != 0)
              inter1.Add(normalizedType.AsSequenceType().Top.Content);
            else inter2.Add(seq.Tail);
          }
          isSub = false;
          if (inter1.Count != 0)
          {
            IType t1 = TypesOperations.Unify(inter1);
            isSub |= IsSubtype(normalizedType.AsSequenceType().Top.Content, t1, aT, aF, ec, dc);
          }
          if (!isSub && inter2.Count != 0)
          {
            IType t2 = TypesOperations.Unify(inter2);
            isSub = IsSubtype(s.Tail, t2, aT, aF, ec, dc);
          }
        }
        return isSub;
      }
    }

    /// <summary>
    /// Given a labelled schema <c>L[S]</c> and a set of first 
    /// <c>{L0, L1, ...., Ln}</c> splits <c>L[S]</c> is an equivalent union of
    /// schemas <c>L0'[S] + L1'[S] + ... + Ln[S]</c> such that the Intersection 
    /// between <c>Li'</c> and <c>Li</c> is either empty or included in Li' 
    /// and the union of <c>Li</c> is equal to <c>L</c>.  
    /// </summary>
    /// <param name="s">the labelled schema <c>L[S]</c></param>
    /// <param name="first">a set containing AbstractLabelsSet 
    /// <c>{L0, L1, ...., Ln}</c></param>
    /// <returns>a schema <c>L0'[S] + L1'[S] + ... + Ln[S]</c> such that 
    /// Intersection between <c>Li'</c> and <c>Li</c> is either empty or included
    /// in Li' and the union of <c>Li</c> is equal to <c>L</c>.
    /// </returns>
    private static IType Normalize(LabelledType s, IType tail, IList<HandleSet> first)
    {
      //The algorithm works as follows:
      //the set "labels" contains the set of labels to normalize. Initially it
      //contains the labels of "s". Then, for each label "Li" in "first"
      //each label "L" in labels it is rewritten as "L\Li" and "L^Li" (^ is the
      //Intersection). 
      IList<ILabelSet> labels = new List<ILabelSet>();
      labels.Add(s.Labels);
      for (int j = 0; j < first.Count; j++)
      {
        IList<ILabelSet> normalizedLabels = new List<ILabelSet>();
        ILabelSet fl = first[j].Labels;
        for (int i = 0; i < labels.Count; i++)
        {
          ILabelSet diff = LabelSet.Difference(labels[i], fl);
          if (!diff.IsEmpty()) normalizedLabels.Add(diff);
          ILabelSet inter = LabelSet.Intersection(labels[i], fl);
          if (!inter.IsEmpty()) normalizedLabels.Add(inter);
        }
        labels = normalizedLabels;
      }
      //A new schema is built
      IList<IType> types = new List<IType>(labels.Count);
      for (int i = 0; i < labels.Count; i++)
        types.Add(new SequenceType(new LabelledType(labels[i], s.Content), tail));
      return TypesOperations.Unify(types);
    }
    /// <summary>
    /// Returns true if T is generated from the following grammar:
    /// S ::= a[S],S | Int | String | <S>^K | U | n | s
    /// </summary>
    private static bool IsValueType(IType t, ICollection<IType> visited)
    {
      if (t.IsUnionType()) return false;
      else if (t.IsConstantType())
      {
        if (visited.Contains(t)) return true;
        else
        {
          visited.Add(t);
          return IsValueType(t.AsConstantType().Entry.Type, visited);
        }
      }
      else if (t.IsSequenceType()) 
        return IsValueType(t.AsSequenceType().Top, visited) && IsValueType(t.AsSequenceType().Tail, visited);
      else if (t.IsLabelledType())
      {
        return t.AsLabelledType().Labels is WithLabels &&
          t.AsLabelledType().Labels.Labels.Count == 1 &&
          IsValueType(t.AsLabelledType().Content, visited);
      }
      else return true;
    }
 
    private static IList<SequenceType> Filter(SequenceType s, IList<SequenceType> types)
    {
      IList<SequenceType> exp= new List<SequenceType>();
      foreach (SequenceType seq in types)
        if (s.Top.Labels.Intersects(seq.Top.Labels)) exp.Add(seq);
      return exp;
    }
  }
#endif // !NEW_SCHEMAS
}
