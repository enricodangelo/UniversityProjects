// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System.Collections.Generic;
using PiDuce.Common;

namespace PiDuce.Types
{
#if NEW_SCHEMAS
	public interface ISchemaChecker
	{
		bool IsSubschema(ISchema s, ISchema t);
		bool IsEmpty(ISchema s);
		bool IsDetermined(ISchema s);
		bool IsCorrect(ISchema s, out string error);
	}

	public class SchemaChecker : ISchemaChecker
	{
    private readonly SubtypingChecker sc;
    private readonly EmptynessChecker ec;
    private readonly CorrectnessChecker cc;
    private readonly DeterminednessChecker dc;

    public SchemaChecker()
    {
      ec = new EmptynessChecker();
      dc = new DeterminednessChecker();
      sc = new SubtypingChecker(ec, dc);
      cc = new CorrectnessChecker(dc);
    }

    public bool IsSubschema(ISchema s, ISchema t)
    { return sc.IsSubschema(s, t); }

    public bool IsEmpty(ISchema s)
    { return ec.IsEmpty(s); }

    public bool IsDetermined(ISchema s)
    { return dc.IsDetermined(s); }

    public bool IsCorrect(ISchema s, out string error)
    { return cc.IsCorrect(s, out error); }
	}
#else
	public interface ISchemaChecker
	{
		ITypeChecker TypeChecker { get; }
		IType SchemaToType(ISchema s);
		bool IsSubschema(ISchema s, ISchema t);
		bool IsEmpty(ISchema s);
		bool IsDetermined(ISchema s);
		bool IsCorrect(ISchema s, out string error);
	}

	public class SchemaChecker : ISchemaChecker
	{
		private readonly ITypeChecker typeChecker;
		private readonly SchemaToTypeVisitor converter;
		private readonly IDictionary<ISchema, IType> types;

		public SchemaChecker(SchemaToTypeVisitor converter)
		{
			typeChecker = new TypeChecker();
			this.converter = converter;
			types = new Dictionary<ISchema, IType>();
		}

		public ITypeChecker TypeChecker { get { return typeChecker; } }

		public IType SchemaToType(ISchema s)
		{
			if (types.ContainsKey(s))
				return types[s];
			else {
				IType t = converter.SchemaToType(s);
				types.Add(s, t);
				return t;
			}
		}

		public bool IsSubschema(ISchema s, ISchema t)
		{ return typeChecker.IsSubtype(SchemaToType(s), SchemaToType(t)); }

		public bool IsEmpty(ISchema s)
		{ return typeChecker.IsEmpty(SchemaToType(s)); }

		public bool IsDetermined(ISchema s)
		{ return typeChecker.IsDetermined(SchemaToType(s)); }

		public bool IsCorrect(ISchema s, out string error)
		{ return typeChecker.IsCorrect(SchemaToType(s), out error); }
	}
#endif // !NEW_SCHEMAS	
}

