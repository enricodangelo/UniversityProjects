// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections.Generic;
using System.Collections;
using PiDuce.Common;
using System.Diagnostics;

namespace PiDuce.Types
{
#if NEW_SCHEMAS
	public class DeterminednessChecker
	{
		private readonly HandlesOfSchemaVisitor handlesOf;

		private IList<IHandle> GetHandles(ISchema s)
		{ return handlesOf.GetHandles(s); }

		public bool IsDetermined(ISchema s)
		{
			IList<IHandle> handles = GetHandles(s);
			ILabelSet labels = LabelSet.Empty();
			foreach (IHandle handle in handles)
				if (handle is Handle<LabelledSchema>) {
					Handle<LabelledSchema> lh = (Handle<LabelledSchema>) handle;
					if (lh.Head.Labels.Intersects(labels) || !IsDetermined(lh.Head.Content) || !IsDetermined(lh.Tail))
						return false;
					labels = LabelSet.Union(lh.Head.Labels, labels);
				} else if (handle is NonVoidHandle) {
					if (!IsDetermined(((NonVoidHandle) handle).Tail))
						return false;
				}
			return true;
		}	
	}
#else	
  public class FirstTypeVisitor : ITypeVisitor
  {
    private IList<IType> visited = new List<IType>();
    private HandleSet first = new HandleSet();

    public HandleSet First { get { return first; } }

    public void VisitBottom(BottomType t)
    {  }
    
    public void VisitVoid(VoidType t)
    { first.AddVoidHandle(); }

    public void VisitUnion(UnionType t)
    {
      t.Fst.Accept(this);
      t.Snd.Accept(this);
    }

    public void VisitConstantTypeName(ConstantType t)
    {
      if (!visited.Contains(t))
      {
        visited.Add(t);
        t.Entry.Type.Accept(this);
      }
    }

    public void VisitSequence(SequenceType t)
    { t.Top.Accept(this); }

    public void VisitLabelled(LabelledType t)
    { first.AddLabelHandle(t.Labels); }

		public void VisitBasicType(BasicType t)
		{ first.AddBasicTypeHandle(t.Type); }

		public void VisitBasicTypeLiteralType(BasicTypeLiteralType t)
		{ first.AddBasicTypeLiteralHandle(t.Value); }

    public void VisitChan(ChannelType t)
    { first.AddChannelHandle(); }

    public void VisitErrorType(ErrorType t)
    { }

    public void VisitBind(Bind t)
    { t.Content.Accept(this); }

		public void VisitServiceType(ServiceType t)
		{
			// a service type is treated as an element labelled "#service" 
			first.AddLabelHandle(LabelSet.Singleton("#service"));
		}
  }
    
  public class DeterminednessChecker
  {
    private ICollection<IType> ndet = new List<IType>();
    private ICollection<IType> cdet = new List<IType>();
    private IDictionary<IType, HandleSet> dict = new Dictionary<IType, HandleSet>();
    private EmptynessChecker ec = new EmptynessChecker();

    public HandleSet GetFirst(IType t)
    {
      HandleSet first;
      if (!dict.TryGetValue(t, out first))
      {	      
        FirstTypeVisitor visitor = new FirstTypeVisitor();
        t.Accept(visitor);
	      first = visitor.First;
      }
      return first;
    }

    /// <summary>
    /// Check if the schema is determined. A schema is determined if every union
    /// starts with a different label. <c>a[int]+a[string]</c> is not
    /// determined.
    /// </summary>
    /// <param name="s">the schema</param>
    /// <returns>true if the schema is determined, false otherwise</returns>
    public bool IsDetermined(IType s)
    {
      if (cdet.Contains(s)) return true;
      else if (ndet.Contains(s)) return false;
      bool res = IsDetermined(s, new ArraySet<IType>()); 
      if (res) cdet.Add(s);
      else ndet.Add(s);
      return res;
    }

    private bool IsDetermined(IType s, ISet<IType> det)
    {
      if (s.IsBottomType() || s.IsBaseType() || s.IsVoidType() || s.IsErrorType())
        return true;
      else  if (s.IsChannelType())  
        return IsDetermined(s.AsChannelType().Content, det);
      else if (s.IsLabelledType())
        return IsDetermined(s.AsLabelledType().Content, det);
      else if (s.IsSequenceType()) 
        return IsDetermined(s.AsSequenceType().Top, det) && IsDetermined(s.AsSequenceType().Tail, det);
      else if (s.IsUnionType())
      {
        UnionType u = s.AsUnionType();
        if (ec.IsEmpty(u.Fst) || ec.IsEmpty(u.Snd))
          return true;
        else
          return !GetFirst(u.Fst).Labels.Intersects(GetFirst(u.Snd).Labels) && 
            IsDetermined(u.Fst, det) && IsDetermined(u.Snd, det);
      }
      else if (s.IsConstantType()) 
      {
        if (det.Contains(s)) return true;      
        det.Add(s);
        return IsDetermined(s.AsConstantType().Entry.Type, det);
      }
      else throw new ApplicationException("IsDetermined: Unhandled case " + s);
    }  
  }
#endif // !NEW_SCHEMAS	
}
