// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Diagnostics;
using PiDuce.Common;

namespace PiDuce.Types 
{
#if NEW_SCHEMAS
	public class TopLevelEntriesVisitor : AbstractSchemaVisitor 
	{
		private	ArraySet<IEntry> head;

		public ArraySet<IEntry> GetEntries(ISchema s)
		{
			head = new ArraySet<IEntry>();
			s.Accept(this);
			return head;
		}

		public override void VisitConstantSchema(ConstantSchema s)
		{
			if (!head.Contains(s.Entry)) {
				head.Add(s.Entry);
				Debug.Assert(s.Entry != null && s.Entry.Schema != null);
				s.Entry.Schema.Accept(this);
			}
		}

		public override void VisitChannelSchema(ChannelSchema s)
		{ }

		public override void VisitFunctionSchema(FunctionSchema s)
		{ }

		public override void VisitServiceSchema(ServiceSchema s)
		{ }
	}

	public class CorrectnessChecker
	{
    private readonly DeterminednessChecker dc;
		private readonly TopLevelEntriesVisitor ev = new TopLevelEntriesVisitor();

    public CorrectnessChecker(DeterminednessChecker dc)
    { this.dc = dc; }
    
    public bool IsGuarded(ConstantSchema s)
    {
			Debug.Assert(s.Entry != null && s.Entry.Schema != null);
			ArraySet<IEntry> head = ev.GetEntries(s.Entry.Schema);
			return !head.Contains(s.Entry); 
    }
    
		public bool IsCorrect(ISchema s, out string error)
		{
			// TO BE IMPLEMENTED
			error = "yeah, right";
			return true;
		}	
	}
#else	
  public class CorrectnessChecker
  {
    private DeterminednessChecker dc;
    public const string UNGUARDED_RECURSION = "Recursion must be guarded";    
    public const string NON_DETERMINED_CHANNEL = "Channel content must be determined";      
    public const string NON_TAIL_RECURSION = "The schema is not tail recursive";
	 	public const string FOUND_ERRORTYPE = "Error in schema"; 	

    public CorrectnessChecker()
    { dc = new DeterminednessChecker(); }
    
    public CorrectnessChecker(DeterminednessChecker dc)
    { this.dc = dc; }
    
    private bool IsGuarded(ConstantType t)
    {
			ArraySet<TypeRef> head = new ArraySet<TypeRef>();
      GetTopLevelHeadEntries(t.Entry.Type, head);
			return !head.Contains(t.Entry); 
    }
    
    private bool IsTopLevelRecursive(ConstantType t) {
      ArraySet<TypeRef> tle = new ArraySet<TypeRef>();
      GetTopLevelEntries(t.Entry.Type, tle);
			return tle.Contains(t.Entry); 
    }
    
    private bool IsTailRecursive(ConstantType t)
    {
      ArraySet<TypeRef> tail = new ArraySet<TypeRef>();
      GetTailEntries(t.Entry.Type, tail);
      return tail.Contains(t.Entry);
    }
    
    private void GetTopLevelHeadEntries(IType s, ISet<TypeRef> head)
    {
      if (s.IsUnionType()) {
        GetTopLevelHeadEntries(s.AsUnionType().Fst, head); 
        GetTopLevelHeadEntries(s.AsUnionType().Snd, head); 
      }
      else if (s.IsSequenceType()) {
        if (IsNullable(s.AsSequenceType().Top)) 
          GetTopLevelHeadEntries(s.AsSequenceType().Tail, head); 
        GetTopLevelHeadEntries(s.AsSequenceType().Top, head); 
      }
      else if (s.IsConstantType()) {
        if (!head.Contains(s.AsConstantType().Entry)) {
          head.Add(s.AsConstantType().Entry);
          GetTopLevelHeadEntries(s.AsConstantType().Entry.Type, head);
        }
      }
    }

    private void GetTailEntries(IType s, ISet<TypeRef> tail)
    {
      if (s.IsUnionType()) {
        GetTailEntries(s.AsUnionType().Fst, tail); 
        GetTailEntries(s.AsUnionType().Snd, tail); 
      }
      else if (s.IsSequenceType()) {
        if (IsNullable(s.AsSequenceType().Tail)) 
          GetTailEntries(s.AsSequenceType().Top, tail); 
        GetTailEntries(s.AsSequenceType().Tail, tail); 
      }
      else if (s.IsConstantType()) {
        if (!tail.Contains(s.AsConstantType().Entry)) {
          tail.Add(s.AsConstantType().Entry);
          GetTailEntries(s.AsConstantType().Entry.Type, tail);
        }
      }
    }
    
		private static bool IsNullableAux(IType s, ArraySet<TypeRef> visited)
		{
			if (s.IsVoidType())
				return true;
			else if (s.IsConstantType()) {
				ConstantType t = s.AsConstantType();
				if (visited.Contains(t.Entry))
					return false;
				else {
					visited.Add(t.Entry);
					return IsNullableAux(t.Entry.Type, visited);
				}
			} else if (s.IsUnionType())
				return IsNullableAux(s.AsUnionType().Fst, visited) || IsNullableAux(s.AsUnionType().Snd, visited);
			else if (s.IsSequenceType())
				return IsNullableAux(s.AsSequenceType().Top, visited) && IsNullableAux(s.AsSequenceType().Tail, visited);
			else
				return false;
		}

		private static bool IsNullable(IType s)
		{ return IsNullableAux(s, new ArraySet<TypeRef>()); }

    private static void GetTopLevelEntries(IType s, ISet<TypeRef> visited) 
    {
      if (s.IsConstantType()) {
				ConstantType t = s.AsConstantType();
				if (!visited.Contains(t.Entry)){
					visited.Add(t.Entry);
					GetTopLevelEntries(t.Entry.Type, visited);
				}
      } else if (s.IsUnionType()) {
        GetTopLevelEntries(s.AsUnionType().Fst, visited);
        GetTopLevelEntries(s.AsUnionType().Snd, visited);
      } else if (s.IsSequenceType()) {
				GetTopLevelEntries(s.AsSequenceType().Tail, visited);
				GetTopLevelEntries(s.AsSequenceType().Top, visited);
      }
    }
    /// <summary>
    /// A schema is correct if and only if both the following conditions hold: 
    /// 1. every recursion is guarded (e.g. A = A and A = B when B = A are not correct)
    /// 2. the content of every channel schema is determined
    /// </summary>
    /// <param name="s">the schema to check for correctness</param>
    /// <param name="error">if the method returns false error message contains either 
    /// UNGUARDED_RECURSION or NON_DETERMINED_CHANNEL dependig on the error found.</param>
    /// <returns>true if the schema is correct, false otherwise</returns>
    public bool IsCorrect(IType s,  out String error)
    { return IsCorrect(s, new ArraySet<IType>(), out error); }

    private bool IsCorrect(IType s, ISet<IType> cor, out String error)
    {
      error = "";
      if (cor.Contains(s)) return true;
      else 
      {
        bool res = true;
        cor.Add(s);
        if (s.IsChannelType())
        {
          res = dc.IsDetermined(s.AsChannelType().Content);
          if (!res) error = NON_DETERMINED_CHANNEL;
          else res = IsCorrect(s.AsChannelType().Content, cor, out error);
        }
        else if (s is ServiceType) 
        { 
          ServiceType service = (ServiceType) s;
          foreach (IType t in service.Operations.Values) 
          { res &= IsCorrect(t, out error); }
        }
        else if (s.IsLabelledType())
          res = IsCorrect(s.AsLabelledType().Content, cor, out error);
        else if (s.IsSequenceType())
          res = IsCorrect(s.AsSequenceType().Top, cor, out error) &&
            IsCorrect(s.AsSequenceType().Tail, cor, out error);
        else if (s.IsUnionType())
          res = IsCorrect(s.AsUnionType().Fst, cor, out error) &&
            IsCorrect(s.AsUnionType().Snd, cor, out error);
        else if (s.IsConstantType())
        {
          res = IsGuarded(s.AsConstantType());
          if (!res)
            error = UNGUARDED_RECURSION;
          else
          {
            res = !(IsTopLevelRecursive(s.AsConstantType()) && !IsTailRecursive(s.AsConstantType()));
            if (!res) error = NON_TAIL_RECURSION;
            else res = IsCorrect(s.AsConstantType().Entry.Type, cor, out error);
          }
        }
        else if (s.IsVoidType() || s.IsBottomType() || s.IsBaseType())
          res = true;
        else if (s.IsErrorType())
        {
          error = FOUND_ERRORTYPE;
          res = false;
        }
        if (!res) cor.Remove(s);
        return res;
      }
    }
  }
#endif // !NEW_SCHEMAS	
}
