// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using PiDuce.Common;

namespace PiDuce.Types
{
#if NEW_SCHEMAS
	public class EmptynessChecker : ISchemaVisitor
	{
		private IList<ConstantSchema> visited;
		private bool result;

		public EmptynessChecker()
		{
			visited = new List<ConstantSchema>();
		}

		public bool IsEmpty(ISchema s)
		{
			s.Accept(this);
			return result;
		}

		public void VisitVoidSchema(VoidSchema s)
		{ result = false; }

		public void VisitBasicSchema(BasicSchema s)
		{ result = false; }

		public void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
		{ result = false; }

		public void VisitLabelledSchema(LabelledSchema s)
		{ result = s.Labels.IsEmpty() || IsEmpty(s.Content); }

		public void VisitSequenceSchema(SequenceSchema s)
		{ result = IsEmpty(s.Head) || IsEmpty(s.Tail); }

		public void VisitUnionSchema(UnionSchema s)
		{ result = IsEmpty(s.Left) && IsEmpty(s.Right); }

		public void VisitStarSchema(StarSchema s)
		{ result = false; }

		public void VisitPlusSchema(PlusSchema s)
		{ result = IsEmpty(s.Content); }

		public void VisitRepetitionSchema(RepetitionSchema s)
		{ result = s.MinOccurs > 0 && IsEmpty(s.Content); }

		public void VisitConstantSchema(ConstantSchema s)
		{
			if (visited.Contains(s))
				result = true;
			else {
				Debug.Assert(s.Entry != null);
				Debug.Assert(s.Entry.Schema != null);
				visited.Add(s);
				result = IsEmpty(s.Entry.Schema);
				visited.Remove(s);
			}	
		}

		public void VisitChannelSchema(ChannelSchema s)
		{ result = false; }

		public void VisitFunctionSchema(FunctionSchema s)
		{ result = false; }

		public void VisitErrorSchema(ErrorSchema s)
		{ result = false; }

		public void VisitBindSchema(BindSchema s)
		{ result = IsEmpty(s.Content); }

		public void VisitServiceSchema(ServiceSchema s)
		{ result = false; } // WATCH ME
	}
#else
  public class EmptynessChecker
  {
    private IList<IType> eF = new List<IType>();
    private IList<IType> eT = new List<IType>();
    /// <summary>
    /// Checks if a given schema is empty. (ErrorType is not empty by definition)
    /// </summary>
    /// <param name="s">the schema to check for emptiness</param>
    /// <returns>true if <c>s</c> is empty, false otherwise</returns>
    public bool IsEmpty(IType s)
    { 
      bool res = IsEmpty(s, new List<IType>());
      if (res) eT.Add(s);
      else eF.Add(s);
      return res;
    }
    
    private bool IsEmpty(IType s, IList<IType> visited)
    {
      if (s.IsBaseType()) return false;
      else if (s.IsVoidType()) return false;
      else if (s.IsChannelType()) return false;
      else if (s.IsBottomType()) return true;
      else if (s.IsErrorType()) return false;
      else if (eT.Contains(s)) return true;
      else if (eF.Contains(s)) return false;
      else
      {
        bool res = false;  
        if (s.IsLabelledType()) 
          res = s.AsLabelledType().Labels.IsEmpty() || 
            IsEmpty(s.AsLabelledType().Content, visited);
        else if (s.IsSequenceType()) 
          res = IsEmpty(s.AsSequenceType().Top, visited) || 
            IsEmpty(s.AsSequenceType().Tail, visited);
        else if (s.IsUnionType()) 
          res = IsEmpty(s.AsUnionType().Fst, visited) && 
            IsEmpty(s.AsUnionType().Snd, visited);
        else if (s.IsConstantType())
        {
          if (visited.Contains(s)) return true;
          else
          {
            visited.Add(s);
            res = IsEmpty(s.AsConstantType().Entry.Type, visited);
          }
        } else if (s is ServiceType) {
					// TODO: understand this
					return false;
				}
        else throw new ApplicationException("public static bool IsEmpty: This code should be unreacheable");
        return res;
      }
    }
  }
#endif	// !NEW_SCHEMAS
}
