// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using PiDuce.Common;

namespace PiDuce.Types
{
	public class HandleSet
	{
		private bool voidHandle;
		private bool channelHandle;
		private ILabelSet labels;
		private ArraySet<IBasicType> types;
		private ArraySet<IBasicTypeLiteral> literals;

		public HandleSet()
		{
			this.voidHandle = false;
			this.channelHandle = false;
			this.labels = LabelSet.Empty();
			this.types = new ArraySet<IBasicType>();
			this.literals = new ArraySet<IBasicTypeLiteral>();
		}

		public ILabelSet Labels { get { return labels; } }

		private HandleSet(bool voidHandle, bool channelHandle,
			ILabelSet labels, ArraySet<IBasicType> types,
			ArraySet<IBasicTypeLiteral> literals)
		{
			this.voidHandle = voidHandle;
			this.channelHandle = channelHandle;
			this.labels = labels;
			this.types = types;
			this.literals = literals;
		}

		public void AddVoidHandle()
		{ voidHandle = true; }

		public void AddChannelHandle()
		{ channelHandle = true; }

		public void AddLabelHandle(ILabelSet labels)
		{ this.labels = LabelSet.Union(this.labels, labels); }

		public void AddBasicTypeHandle(IBasicType t)
		{ this.types.Add(t); }

		public void AddBasicTypeLiteralHandle(IBasicTypeLiteral t)
		{ this.literals.Add(t); }

		public bool IsEmpty()
		{
			return !voidHandle && !channelHandle
				&& labels.IsEmpty() && types.IsEmpty() && literals.IsEmpty();
		}

		public bool IsSubsetOf(HandleSet s)
		{
			return (!voidHandle || s.voidHandle)
				&& (!channelHandle || s.channelHandle)
				&& labels.IsSubsetOf(s.labels)
				&& types.IsSubsetOf(s.types)
				&& literals.IsSubsetOf(s.literals);
		}

		public static HandleSet Intersection(HandleSet s1, HandleSet s2)
		{
			return new HandleSet(
				s1.voidHandle && s2.voidHandle,
				s1.channelHandle && s2.channelHandle,
				LabelSet.Intersection(s1.labels, s2.labels),
				ArraySet<IBasicType>.Intersection(s1.types, s2.types),
				ArraySet<IBasicTypeLiteral>.Intersection(s1.literals, s2.literals));
		}

		public static HandleSet Union(HandleSet s1, HandleSet s2)
		{
			return new HandleSet(
				s1.voidHandle || s2.voidHandle,
				s1.channelHandle || s2.channelHandle,
				LabelSet.Union(s1.labels, s2.labels),
				ArraySet<IBasicType>.Union(s1.types, s2.types),
				ArraySet<IBasicTypeLiteral>.Union(s1.literals, s2.literals));
		}
	}
}
