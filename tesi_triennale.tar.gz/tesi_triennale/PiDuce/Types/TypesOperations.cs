// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections.Generic;
using PiDuce.Common;
using System.Diagnostics;

namespace PiDuce.Types
{
#if !NEW_SCHEMAS
  public class TypesOperations
  {
    public static IType Union(IType s, IType t)
    { return new UnionType(s, t); }

    /// <summary>
    /// Computes the Intersection between two types.
    /// </summary>
    /// <param name="s">the fist schema</param>
    /// <param name="t">the second schema</param>
    /// <returns>the inters schema</returns>
    public static bool EmptyIntersection(IType s, IType t)
    {
      IType intersection = Intersect(s, t, new Dictionary<string, TypeRef>());
      if (intersection.IsErrorType()) 
        return false;
      else if ((new EmptynessChecker()).IsEmpty(intersection)) 
        return true;
      else return false;
    }

    /// <summary>
    /// Computes the Intersection between two types.
    /// </summary>
    /// <param name="s">the fist schema</param>
    /// <param name="t">the second schema</param>
    /// <returns>the inters schema</returns>
    /// <remarks>the method is internal because it is not precise: ErrorType is used when the intersection 
    /// cannot be expressed as schema.
    /// </remarks>
    internal static IType Intersect(IType s, IType t)
    { return Intersect(s, t, new Dictionary<string, TypeRef>()); }

    /// <summary>
    /// Computes the Intersection between two types.
    /// </summary>
    /// <param name="s">the fist schema</param>
    /// <param name="t">the second schema</param>
    /// <param name="computing">pairs of schema names the algorithm is calculating</param>
    /// <returns>the intersect schema</returns>
    private static IType Intersect(IType s, IType t, IDictionary<string, TypeRef> inC)
    {
      SubtypingChecker sc = new SubtypingChecker();
      if (s.IsBottomType() || t.IsBottomType())				
        return s;
      if (s.IsErrorType() || t.IsErrorType())
        return s;
      if (s.IsUnionType()) 
      { 
        IType int1 = Intersect(s.AsUnionType().Fst, t, inC);
        IType int2 = Intersect(s.AsUnionType().Snd, t, inC);
        if (int1.IsBottomType() && int2.IsBottomType()) return new BottomType();
        else if (int1.IsBottomType()) return int2;
        else if (int2.IsBottomType()) return int1;
        else return new UnionType(int1,int2);
      }
      if (t.IsUnionType()) return Intersect(t, s, inC);
      if (s.IsConstantType() && t.IsConstantType()) 
      {
        //these names are unique because of "#". 
        string name1 = s.AsConstantType() + "#" + t.AsConstantType();
        string name2 = t.AsConstantType() + "#" + s.AsConstantType();
        if (!inC.ContainsKey(name1) && !inC.ContainsKey(name2)) //we start to compute the Intersection
        {
          IType defofs = s.AsConstantType().Entry.Type;
          IType defoft = t.AsConstantType().Entry.Type;
          if (defofs.IsErrorType() || defoft.IsErrorType()) return new ErrorType();
					TypeRef entry1 = new TypeRef(name1, null);
					inC.Add(name1, entry1);
					TypeRef entry2 = null;
					// LUCA: if name1 == name2 then one entry is enough (the hash table would complain otherwise)
					if (name1 != name2) {
						entry2 = new TypeRef(name2, null);
						inC.Add(name2, entry2);
					}
          IType int1= Intersect(defofs, defoft, inC);
					entry1.Type = int1;
					if (name1 != name2)
						entry2.Type = int1;
          return new ConstantType(name1, entry1);
        }
        //we already have the Intersection
        else if (inC.ContainsKey(name1)) return new ConstantType(name1, inC[name1]);
        else return new ConstantType(name2, inC[name2]);
      }
      else if (s.IsConstantType()) 
        return Intersect(s.AsConstantType().Entry.Type, t, inC);
      else if (t.IsConstantType()) 
        return Intersect(s, t.AsConstantType().Entry.Type, inC);
      else if (s.IsBaseType() || s.IsVoidType()) 
      {
        if (sc.IsSubtype(s, t)) return s;
        else if (sc.IsSubtype(t, s)) return t; 
        else return new BottomType();
      }
      else if (s.IsSequenceType())
      {
        if (t.IsSequenceType())
        {
          IType top = Intersect(s.AsSequenceType().Top, t.AsSequenceType().Top, inC);
          if (top.IsBottomType()) return new BottomType();
          IType tail = Intersect(s.AsSequenceType().Tail, t.AsSequenceType().Tail, inC);
          if (tail.IsBottomType()) return new BottomType();
          return new SequenceType(top.AsLabelledType(), tail);
        }
        else if (t.IsLabelledType())
          return Intersect(t, s, inC);
        else return new BottomType();
      }
      else if (s.IsChannelType()) 
      {
        if (t.IsChannelType())
        {
          IType cs = s.AsChannelType().Content;
          IType ct = t.AsChannelType().Content;
          // i && i = i, i && io = i, o && o = o, o && io = o, io && io = io, i && o = io
          if (s.AsChannelType().Capability == ChannelType.CAPABILITY.IN && t.AsChannelType().Capability != ChannelType.CAPABILITY.OUT)
            return new ChannelType(Intersect(cs, ct, inC), ChannelType.CAPABILITY.IN);
          else if (s.AsChannelType().Capability == ChannelType.CAPABILITY.INOUT && t.AsChannelType().Capability == ChannelType.CAPABILITY.IN) 
            return new ChannelType(Intersect(cs, ct, inC), ChannelType.CAPABILITY.IN);
          else if (s.AsChannelType().Capability == ChannelType.CAPABILITY.OUT && t.AsChannelType().Capability != ChannelType.CAPABILITY.IN)
            return new ChannelType(new UnionType(s.AsChannelType().Content, t.AsChannelType().Content), ChannelType.CAPABILITY.OUT);
            //return new ChannelType(DeterminedUnion(new UnionType(cs, ct)), ChannelType.CAPABILITY.OUT);
          else if (s.AsChannelType().Capability == ChannelType.CAPABILITY.INOUT && t.AsChannelType().Capability == ChannelType.CAPABILITY.OUT)
            return new ChannelType(new UnionType(s.AsChannelType().Content, t.AsChannelType().Content), ChannelType.CAPABILITY.OUT);
            //return new ChannelType(DeterminedUnion(new UnionType(cs, ct)), ChannelType.CAPABILITY.OUT);
          else if (s.AsChannelType().Capability == ChannelType.CAPABILITY.INOUT && t.AsChannelType().Capability == ChannelType.CAPABILITY.INOUT) 
          { 
            if (sc.IsSubtype(cs, ct) && sc.IsSubtype(ct, cs))
              return s;
            else return new BottomType();
          }
          if (s.AsChannelType().Capability == ChannelType.CAPABILITY.OUT && t.AsChannelType().Capability == ChannelType.CAPABILITY.IN)
            return Intersect(t, s, inC);
          else if (s.AsChannelType().Capability == ChannelType.CAPABILITY.IN && t.AsChannelType().Capability == ChannelType.CAPABILITY.OUT)
          {
            if (sc.IsSubtype(cs, ct) && sc.IsSubtype(ct,cs))
              return new ChannelType(cs, ChannelType.CAPABILITY.INOUT);
            else if (!sc.IsSubtype(ct, cs))
              return new BottomType();
            else if (sc.IsSubtype(ct, cs))
              return new ErrorType(); //the intersection is not empty but for the moment i'm not able to compute it! SAMUELE:TODO
          }
        }
        else return new BottomType();
      }
      else if (s.IsLabelledType()) 
      {
        if (t.IsLabelledType())
        {
          ILabelSet labels = LabelSet.Intersection(s.AsLabelledType().Labels, t.AsLabelledType().Labels);
          if (!labels.IsEmpty())
          {
            IType content = Intersect(s.AsLabelledType().Content, t.AsLabelledType().Content, inC);
            return new LabelledType(labels, content);
          }
          else return new BottomType();
        } 
        else if (t.IsSequenceType()) 
        {
          if (sc.IsSubtype(new VoidType(), t.AsSequenceType().Tail)) 
            return TypesOperations.Intersect(s,t.AsSequenceType().Top, inC);
        }
        else return new BottomType();
      }
      throw new ApplicationException("private static Type inters: Unhandled case " + s + " x " + t);
    }

    internal static IList<SequenceType> Expand(IType t) 
    {
      IList<SequenceType> exp = new List<SequenceType>();
      Expand(t, exp, new List<IType>());
      return exp;
    }
    /// <summary>
    /// Given a schema <c>t</c> returns the sequences it contains
    /// </summary>
    /// <param name="s">the sequence</param>
    /// <param name="t">the schema to Expand</param>
    /// <returns>a set containing either guarded sequences or void obtained by Expanding <c>t</c></returns>	
    /// <remarks>constant schema name must be guarded</remarks>
    private static IList<SequenceType> Expand(IType t, IList<SequenceType> exp, ICollection<IType> visited)
    {	
      if (t.IsUnionType())
      {
        Expand(t.AsUnionType().Fst, exp, visited);
        Expand(t.AsUnionType().Snd, exp, visited);
      }
      else if (t.IsConstantType() && !visited.Contains(t))
      {
        visited.Add(t);
        Expand(t.AsConstantType().Entry.Type, exp, visited);
      }
      else if (t.IsSequenceType())
      {
        if (!exp.Contains(t.AsSequenceType())) exp.Add(t.AsSequenceType());
      }
      else if (t.IsLabelledType())
      { 
        SequenceType s = new SequenceType(t.AsLabelledType(), new VoidType());
        if (!exp.Contains(s)) exp.Add(s);
      }
      return exp;
    }

    internal static IType Unify(IList<IType> types)
    {
      if (types.Count == 0) return new BottomType();
      else if (types.Count == 1) return types[0];
      else 
      {
        IList<IType> inTypes = new List<IType>();
        IType u = types[0];
        inTypes.Add(types[0]);
        for (int i = 1; i < types.Count; i++)
        {
          if (!inTypes.Contains(types[i]))
          {
            inTypes.Add(types[i]);
            u = new UnionType(u, types[i]);
          }
        }
        return u;
      }
    }
  }
#endif	
}
