// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using PiDuce.Common;
using PiDuce.Types;

namespace PiDuce.Types
{
#if NEW_SCHEMAS
	public interface IHandle
	{
		ISchema AsSchema();
	}

	public class VoidHandle : IHandle
	{
		public ISchema AsSchema()
		{ return new VoidSchema(); }
	}

	public abstract class NonVoidHandle : IHandle
	{
		private readonly ISchema tail;

		public ISchema Tail { get { return tail; } }

		public NonVoidHandle(ISchema tail)
		{ this.tail = tail; }

		public abstract ISchema AsSchema();
	}

	public class Handle<T> : NonVoidHandle where T : ISchema
	{
		private readonly T head;

		public T Head { get { return head; } }

		public Handle(T head, ISchema tail) : base(tail)
		{ this.head = head; }

		public override ISchema AsSchema()
		{ return new SequenceSchema(head, Tail); }
	}

	public class HandlesOfSchemaVisitor : ExpanderSchemaVisitor 
	{
		private readonly EmptynessChecker ec;
		private IDictionary<ISchema, IList<IHandle>> cache;
		private IList<ConstantSchema> visited;
		private ISchema tail;
		private IList<IHandle> handles;

		public HandlesOfSchemaVisitor(EmptynessChecker ec)
		{
			this.ec = ec;
			this.cache = new Dictionary<ISchema, IList<IHandle>>();
		}

		public IList<IHandle> GetHandles(ISchema s)
		{
			if (cache.TryGetValue(s, out handles)) {
				return handles;
			}
			visited = new List<ConstantSchema>();
			tail = new VoidSchema();
			handles = new List<IHandle>();
			s.Accept(this);
			cache.Add(s, handles);
			return handles;
		}

		public override void VisitVoidSchema(VoidSchema s)
		{
			if (tail is VoidSchema)
				handles.Add(new VoidHandle());
			else {
				ISchema oldTail = tail;
				tail = new VoidSchema();
				oldTail.Accept(this);
			}	
		}

		public override void VisitBasicSchema(BasicSchema s)
		{ handles.Add(new Handle<BasicSchema>(s, tail)); }

		public override void VisitBasicSchemaLiteralSchema(BasicSchemaLiteralSchema s)
		{ handles.Add(new Handle<BasicSchemaLiteralSchema>(s, tail)); }

		public override void VisitLabelledSchema(LabelledSchema s)
		{
			if (!s.Labels.IsEmpty())
				handles.Add(new Handle<LabelledSchema>(s, tail));
		}

		public override void VisitSequenceSchema(SequenceSchema s)
		{
			if (!ec.IsEmpty(s.Tail)) {
				if (tail is VoidSchema)
					tail = s.Tail;
				else
					tail = new SequenceSchema(s.Tail, tail);
				s.Head.Accept(this);
			}
		}

		public override void VisitUnionSchema(UnionSchema s)
		{
			ISchema oldTail = tail;
			s.Left.Accept(this);
			tail = oldTail;
			s.Right.Accept(this);
		}

		public override void VisitStarSchema(StarSchema s)
		{ UnionSchema.Make(new SequenceSchema(s.Content, s), new VoidSchema()).Accept(this); }

		public override void VisitConstantSchema(ConstantSchema s)
		{
			if (!visited.Contains(s)) {
				Debug.Assert(s.Entry != null);
				Debug.Assert(s.Entry.Schema != null);
				visited.Add(s);
				s.Entry.Schema.Accept(this);
				visited.Remove(s);
			}
		}

		public override void VisitChannelSchema(ChannelSchema s)
		{ handles.Add(new Handle<ChannelSchema>(s, tail)); }

		public override void VisitErrorSchema(ErrorSchema s)
		{ Debug.Assert(false); }

		public override void VisitBindSchema(BindSchema s)
		{ s.Content.Accept(this); }

		public override void VisitServiceSchema(ServiceSchema s)
		{ handles.Add(new Handle<ServiceSchema>(s, tail)); }
	}
#endif	// NEW_SCHEMAS
}

