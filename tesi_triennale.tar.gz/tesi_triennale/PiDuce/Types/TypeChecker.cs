// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using PiDuce.Common;

namespace PiDuce.Types
{
#if !NEW_SCHEMAS
  public interface ITypeChecker 
  {
    bool IsSubtype(IType s, IType t);
    bool IsEmpty(IType s);
    bool IsDetermined(IType s);
    bool IsCorrect(IType s, out string error);
  }

  public class TypeChecker: ITypeChecker
  { 
    private SubtypingChecker sc;
    private EmptynessChecker ec;
    private CorrectnessChecker cc;
    private DeterminednessChecker dc;

    public TypeChecker()
    {
      ec = new EmptynessChecker();
      dc = new DeterminednessChecker();
      sc = new SubtypingChecker(ec, dc);
      cc = new CorrectnessChecker(dc);
    }

    public bool IsSubtype(IType s, IType t)
    { return sc.IsSubtype(s, t); }

    public bool IsEmpty(IType s)
    { return ec.IsEmpty(s); }

    public bool IsDetermined(IType s)
    { return dc.IsDetermined(s); }

    public bool IsCorrect(IType s, out string error)
    { return cc.IsCorrect(s, out error); }
  }
#endif	
}
