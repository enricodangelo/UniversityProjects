 if (e->flags & EDGE_ABNORMAL)
    break;
  
  get_stmt_operands (stmt);

  FOR_EACH_SSA_MAYDEF_OPERAND (def_p, use_p, stmt, iter)
    {
      tree v_may_def = DEF_FROM_PTR (def_p);
      tree v_may_use = USE_FROM_PTR (use_p);

      /* Find any uses in the PHI which match V_MAY_DEF and replace
	 them with the appropriate V_MAY_DEF_OP.  */
      for (i = 0; i < PHI_NUM_ARGS (phi); i++)
	if (v_may_def == PHI_ARG_DEF (phi, i))
	  {
	    SET_PHI_ARG_DEF (phi, i, v_may_use);
	    /* Update if the new phi argument is an abnormal phi.  */
	    if (e != NULL)
	      SSA_NAME_OCCURS_IN_ABNORMAL_PHI (v_may_use) = 1;
	  }
    }
}

/* Replace the V_MAY_DEF_OPs in STMT1 which match V_MAY_DEF_RESULTs 
   in STMT2 with the appropriate V_MAY_DEF_OPs from STMT2.  */

static void
fix_stmt_v_may_defs (tree stmt1, tree stmt2)
{
  bool found = false;
  ssa_op_iter iter1;
  ssa_op_iter iter2;
  use_operand_p use1_p, use2_p;
  def_operand_p def1_p, def2_p;

  get_stmt_operands (stmt1);
  get_stmt_operands (stmt2);

  /* Walk each V_MAY_DEF_OP in stmt1.  */
  FOR_EACH_SSA_MAYDEF_OPERAND (def1_p, use1_p, stmt1, iter1)
    {
      tree use = USE_FROM_PTR (use1_p);

      /* Find the appropriate V_MAY_DEF_RESULT in STMT2.  */
      FOR_EA