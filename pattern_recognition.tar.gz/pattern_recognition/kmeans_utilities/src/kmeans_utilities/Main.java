/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author enrico
 */
public class Main {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		String rscriptOption = Constants.RSCRIPTS_OPTION;
		String kmeansOption = Constants.KMEANS_OPTION;
		String kmeansPropertiesOption = Constants.KMEANSPROPERTIES_OPTION;
		String kmeansParserOption = Constants.PARSE_OPTION;
		if ((args.length < 2) ||
				((!args[0].equals(rscriptOption)) &&
				(!args[0].equals(kmeansOption)) &&
				(!args[0].equals(kmeansPropertiesOption)) &&
				(!args[0].equals(kmeansParserOption)))
			) {
			System.out.println(args.length + " " + args[0] + " " + args[1]);
			System.err.println("kmeans_utilities OPTION PROPERTY_FILE");
			System.err.println("OPTION:");
			System.err.println("\t" + Constants.RSCRIPTS_OPTION);
			System.err.println("\t" + Constants.KMEANS_OPTION);
			System.err.println("\t" + Constants.KMEANSPROPERTIES_OPTION);
			System.err.println("\t" + Constants.PARSE_OPTION);

			System.exit(-1);
		}

		if (args[0].equals(Constants.RSCRIPTS_OPTION)) {
			rscripts(args[1]);
		} else if (args[0].equals(Constants.KMEANS_OPTION)) {
			kmeans(args[1]);
		} else if (args[0].equals(Constants.KMEANSPROPERTIES_OPTION)) {
			kmeansProperties(args[1]);
		} else if (args[0].equals(Constants.PARSE_OPTION)) {
			parse(args[1]);
		}
	}

	private static void rscripts(String propertiesFilename) {
		RScriptProperties properties = RScriptProperties.parse(propertiesFilename);

		RScriptGenerator rscriptGenerator = new RScriptGenerator(properties);

		ArrayList<String> result = rscriptGenerator.generateAllRScripts();

		int i = 1;
		for (String string : result) {
			try {
				PrintStream stream;
				String filename;
				if (i < 10) {
					filename = "Rscript_" + "0" + i;
				} else {
					filename = "Rscript_" + i;
				}
				stream = new PrintStream(filename);
				stream.print(string);
				stream.close();
				i++;
			} catch (FileNotFoundException ex) {
				Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	private static void kmeans(String propertiesFilename) {
		KMeansProperties properties = KMeansProperties.parse(propertiesFilename);

		KMeansGenerator kmeansGenerator = new KMeansGenerator(properties);

		Map<String, String> result = kmeansGenerator.generateAllKMeans();
		int i = 1;
		for (Map.Entry<String, String> entry : result.entrySet()) {
			try {
				PrintStream stream;
				String filename = "KMeans-" + entry.getKey() + ".properties";
				stream = new PrintStream(filename);
				stream.print(entry.getValue());
				stream.close();
				i++;
			} catch (FileNotFoundException ex) {
				Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	private static void kmeansProperties(String propertiesFilename) {
		KMeansPropertiesProperties properties = KMeansPropertiesProperties.parse(propertiesFilename);

		KMeansPropertiesGenerator kmeansPropertiesGenerator = new KMeansPropertiesGenerator(properties);

		String result = kmeansPropertiesGenerator.generateKMeansProperties();

		try {
			PrintStream stream;
			stream = new PrintStream(properties.kmeansPropertiesFilename);
			stream.print(result);
			stream.close();
		} catch (FileNotFoundException ex) {
			Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	private static void parse(String propertiesFilename) {
		ParserProperties properties = ParserProperties.parse(propertiesFilename);

		ParsedResultsGenerator kmeansParsedResultsGenerator = new ParsedResultsGenerator(properties);

		ParsedResults parsedResults = kmeansParsedResultsGenerator.generateParsedResults();

		try {
			PrintStream stream;
			stream = new PrintStream(properties.kmeansOutputFilename);
			String header = parsedResults.getHeader();
			stream.print(header);
			stream.print(parsedResults);
			stream.close();
		} catch (FileNotFoundException ex) {
			Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
