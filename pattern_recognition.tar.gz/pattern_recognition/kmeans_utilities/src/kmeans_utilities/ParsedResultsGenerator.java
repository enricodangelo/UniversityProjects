/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 *
 * @author enrico
 */
class ParsedResultsGenerator {

	private String logsDirname;

	//la chiave e' l'ID del dataset, l'arraylist contiene i log di tutti gli algoritmi applicati a quel dataset
	private HashMap<String, ArrayList<ParsedLog>> parsedLogs = new HashMap<String, ArrayList<ParsedLog>>();

	public ParsedResultsGenerator(ParserProperties properties) {
		this.logsDirname = properties.logsDirname;
	}

	public ParsedResults generateParsedResults() {
		ParsedResults parsedResults;
		
		parseLogs();

		parsedResults = new ParsedResults(parsedLogs);
		parsedResults.computeResults();

		return parsedResults;
	}

	public void parseLogs() {
		File logsDir = new File(logsDirname);

		for (String logFilename : logsDir.list()) {
			if (logFilename.startsWith("KMeans")) {
				String key = logFilename.substring(logFilename.indexOf("_") + 1, logFilename.indexOf("-R"));
				BufferedReader logBufferedReader = null;
				int datasetSize = 0;
				int features = 0;
				String centroidUpdateAlgorithm = null;
				String centroidSelectionAlgoritm = null;
				String line = "";
				try {
					logBufferedReader = new BufferedReader(new FileReader(logsDirname + File.separator + logFilename));
					line = logBufferedReader.readLine();

					while (line != null) {

						if (line.startsWith("Dimensione del dataset")) {
							datasetSize = Integer.parseInt(line.substring(line.indexOf(":") + 1, line.length()).trim());
						} else if (line.startsWith("Numero di features")) {
							features = Integer.parseInt(line.substring(line.indexOf(":") + 1, line.length()).trim());
						} else if (line.startsWith("Metodo di aggiornamento dei centroidi")) {
							centroidUpdateAlgorithm = line.substring(line.indexOf(":") + 1, line.length()).trim();
						} else if (line.startsWith("Metodo per la selezione iniziale dei centroidi")) {
							centroidSelectionAlgoritm = line.substring(line.indexOf(":") + 1, line.length()).trim();
						} else if (line.isEmpty()) {
							while ((line.isEmpty()) ||
									(line.startsWith("cluster size"))) {
								line = logBufferedReader.readLine();
							}
							//while (line != null) {
							while (!line.isEmpty()) {
								int index = 0;
								Pattern separator = Pattern.compile(",");
								String[] result = separator.split(line);
								//cluster size, error, iterations, number of comparisons, run time, wall clock time, [centroid, points in cluster]+
								int k = Integer.parseInt(result[index++]);
								double error = Double.parseDouble(result[index++]);
								int iterations = Integer.parseInt(result[index++]);
								int numberOfComparisons = Integer.parseInt(result[index++]);
								long runTime = Long.parseLong(result[index++]);
								long wallClockTime = Long.parseLong(result[index++]);
								double[] values = new double[features];
								ArrayList<double[]> mean = new ArrayList<double[]>();
								ArrayList<Integer> pointsInCluster = new ArrayList<Integer>();

								for (int i = 0; i < k; i++) {
									for (int j = 0; j < features; j++) {
										values[j] = Double.parseDouble(result[index++]);
									}
									mean.add(values);
									pointsInCluster.add(Integer.parseInt(result[index++]));
								}

								String algorithmString = centroidUpdateAlgorithm + centroidSelectionAlgoritm;
								int algorithm = -1;
								if (algorithmString.equals("Implementazione naive dell'algoritmo di K-Means (Lloyd's Algorithm)Selezione casuale di k punti come centroidi iniziali")) {
									algorithm = AlgorithmType.NAIVE_RANDOM;
								} else if (algorithmString.equals("Implementazione naive dell'algoritmo di K-Means (Lloyd's Algorithm)Selezione dei centroidi iniziali tramite l'algoritmo k-means su subsamples del dataset")) {
									algorithm = AlgorithmType.NAIVE_REFINED;
								} else if (algorithmString.equals("Implementazione efficiente dell'algoritmo K-Means tramite l'uso di kd-treeSelezione casuale di k punti come centroidi iniziali")) {
									algorithm = AlgorithmType.EFFICIENT_RANDOM;
								} else if (algorithmString.equals("Implementazione efficiente dell'algoritmo K-Means tramite l'uso di kd-treeSelezione dei centroidi iniziali tramite l'algoritmo k-means su subsamples del dataset")) {
									algorithm = AlgorithmType.EFFICIENT_REFINED;
								}

								ParsedLog log = new ParsedLog(key, datasetSize, features, algorithm, k, error, iterations, numberOfComparisons, runTime, wallClockTime, mean, pointsInCluster);

								if (parsedLogs.get(key) == null){
									parsedLogs.put(key, new ArrayList<ParsedLog>());
								}
								parsedLogs.get(key).add(log);

								line = logBufferedReader.readLine();
							}
						}
						line = logBufferedReader.readLine();
					}

				} catch (IOException ex) {
					Logger.getLogger(ParsedResultsGenerator.class.getName()).log(Level.SEVERE, null, ex);
				} finally {
					try {
						logBufferedReader.close();
					} catch (IOException ex) {
						Logger.getLogger(ParsedResultsGenerator.class.getName()).log(Level.SEVERE, null, ex);
					}
				}
			}
		}
	}
}
