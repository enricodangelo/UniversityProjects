/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 *
 * @author enrico
 */
public class RScriptProperties{

	ArrayList<Integer> datasetSizes;
	ArrayList<Integer> clusters;
	ArrayList<Integer> features;
	int maxCoord;
	int maxDev;

	private RScriptProperties(ArrayList<Integer> datasetSize, ArrayList<Integer> clusters, ArrayList<Integer> features, int maxCoord, int maxDev) {
		this.datasetSizes = datasetSize;
		this.clusters = clusters;
		this.features = features;
		this.maxCoord = maxCoord;
		this.maxDev = maxDev;
	}

	public static RScriptProperties parse(String propertiesFilename) {
		RScriptProperties rScriptProperties = null;

		try {
			FileInputStream propertiesInputStream = null;
			String datasetSizeString;
			String clustersString;
			String featuresString;
			String maxCoordString;
			String maxDevString;

			propertiesInputStream = new FileInputStream(propertiesFilename);
			Properties properties = new Properties();

			properties.load(propertiesInputStream);

			datasetSizeString = properties.getProperty(Constants.DATASET_SIZE_KEY, "");
			clustersString = properties.getProperty(Constants.CLUSTERS_KEY, "");
			featuresString = properties.getProperty(Constants.FEATURES_KEY, "");
			maxCoordString = properties.getProperty(Constants.MAX_COORD_KEY, "");
			maxDevString = properties.getProperty(Constants.MAX_DEV_KEY, "");

			ArrayList<Integer> datasetSize = parseArrayList(datasetSizeString);
			ArrayList<Integer> clusters = parseArrayList(clustersString);
			ArrayList<Integer> features = parseArrayList(featuresString);
			int maxCoord = parseInteger(maxCoordString);
			int maxDev = parseInteger(maxDevString);

			if ((datasetSize == null) ||
					(clusters == null) ||
					(features == null) ||
					(maxCoord < 0) ||
					(maxDev < 0)) {
				rScriptProperties = null;
			} else {
				rScriptProperties = new RScriptProperties(datasetSize, clusters, features, maxCoord, maxDev);
			}
		} catch (IOException ex) {
			Logger.getLogger(RScriptProperties.class.getName()).log(Level.SEVERE, null, ex);
		}

		return rScriptProperties;
	}

	private static int parseInteger(String string) {
		int result = 0;

		try {
			if (string.equals("")) {
				result = -1;
			} else {
				result = Integer.parseInt(string.trim());
			}
		} catch (NumberFormatException ex) {
			result = -1;
		} finally {
			return result;
		}
	}

	private static ArrayList<Integer> parseArrayList(String string) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		Pattern separator = Pattern.compile(",");

		if (string.equals("")) {
			result = null;
		} else {
			String[] strings = separator.split(string);
			for (String str : strings) {
				try {
					result.add(Integer.parseInt(str.trim()));
				} catch (NumberFormatException ex) {
					result = null;
					break;
				}
			}
		}

		return result;
	}
}
