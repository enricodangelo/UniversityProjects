/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kmeans_utilities;

/**
 *
 * @author enrico
 */
public class AlgorithmType {
	public final static int NAIVE_RANDOM = 0;
	public final static int NAIVE_REFINED = 1;
	public final static int EFFICIENT_RANDOM = 2;
	public final static int EFFICIENT_REFINED = 3;
}
