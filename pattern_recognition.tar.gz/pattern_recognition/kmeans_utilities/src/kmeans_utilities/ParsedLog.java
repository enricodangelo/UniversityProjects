/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public class ParsedLog {

	public final String datasetIndex;
	public final int datasetSize;
	public final int features;
	public final int algorithm;
	public final int k;
	public final double error;
	public final int iterations;
	public final int numberOfComparisons;
	public final long runTime;
	public final long wallClockTime;
	public final ArrayList<double[]> mean;
	public final ArrayList<Integer> pointsInCluster;

	public ParsedLog(String datasetIndex, int datasetSize, int features, int algorithm, int k, double error, int iterations, int numberOfComparisons, long runTime, long wallClockTime, ArrayList<double[]> mean, ArrayList<Integer> pointsInCluster) {
		if ((mean.size() == k) && (pointsInCluster.size() == k)) {
			this.datasetIndex = datasetIndex;
			this.datasetSize = datasetSize;
			this.features = features;
			this.algorithm = algorithm;
			this.k = k;
			this.error = error;
			this.iterations = iterations;
			this.numberOfComparisons = numberOfComparisons;
			this.runTime = runTime;
			this.wallClockTime = wallClockTime;
			this.mean = mean;
			this.pointsInCluster = pointsInCluster;
		} else {
			this.datasetIndex = null;
			this.datasetSize = -1;
			this.features = -1;
			this.algorithm = -1;
			this.k = -1;
			this.error = -1;
			this.iterations = -1;
			this.numberOfComparisons = -1;
			this.runTime = -1;
			this.wallClockTime = -1;
			this.mean = null;
			this.pointsInCluster = null;
		}
	}

	@Override
	public String toString() {
		String string = "";

		string += "datasetIndex: " + datasetIndex + "\n";
		string += "datasetSize: " + datasetSize + "\n";
		string += "feature: " + features + "\n";
		string += "algorithm: " + algorithm + "\n";
		string += "k: " + k + "\n";
		string += "error: " + error + "\n";
		string += "iterations: " + iterations + "\n";
		string += "numberOfComparisons: " + numberOfComparisons + "\n";
		string += "runTime: " + runTime + "\n";
		string += "wallClockTime: " + wallClockTime + "\n";
		string += "mean: ";
		for (int i = 0; i < mean.size(); i++) {
			for (int j = 0; j < mean.get(i).length; j++) {
				if (j != mean.get(i).length - 1) {
					string += mean.get(i)[j] + ",";
				} else {
					string += mean.get(i)[j] + " ";
				}
			}
			if (i == mean.size() - 1) {
				string += "\n";
			}
		}
		string += "pointsInCluster: ";
		for (int i = 0; i < pointsInCluster.size(); i++) {
			if (i != pointsInCluster.size() - 1) {
				string += pointsInCluster.get(i) + ",";
			} else {
				string += pointsInCluster.get(i) + "\n";
			}

		}
		
		return string;
	}
}
