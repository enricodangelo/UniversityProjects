/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.io.File;

/**
 *
 * @author enrico
 */
public class KMeansPropertiesGenerator {

	private String datasetsDirname;
	private String centroidsSelectionAlgorithms;
	private String centroidsUpdaterAlgorithms;
	private String metrics;
	private String criteria;
	private String subsamples;
	private String subsamplesSize;
	private String clusterFrom;
	private String clusterTo;
	private String run;

	public KMeansPropertiesGenerator(KMeansPropertiesProperties properties) {
		this.datasetsDirname = properties.datasetsDirname;
		this.centroidsSelectionAlgorithms = properties.centroidsSelectionAlgorithms;
		this.centroidsUpdaterAlgorithms = properties.centroidsUpdaterAlgorithms;
		this.metrics = properties.metrics;
		this.criteria = properties.criteria;
		this.subsamples = properties.subsamples;
		this.subsamplesSize = properties.subsamplesSize;
		this.clusterFrom = properties.clusterFrom;
		this.clusterTo = properties.clusterTo;
		this.run = properties.run;
	}

	public String generateKMeansProperties() {
		String string = "";

		File datasetDir = new File(datasetsDirname);

		String datasetValue = "";
		for (String datasetFIle : datasetDir.list()) {
			datasetValue += datasetsDirname + datasetFIle + ",";
		}

		string += "DatasetsFilename=" + datasetValue + "\n";
		string += "CentroidsSelectionAlgorithms=" + centroidsSelectionAlgorithms + "\n";
		string += "CentroidsUpdaterAlgorithms=" + centroidsUpdaterAlgorithms + "\n";
		string += "Metrics=" + metrics + "\n";
		string += "Criteria=" + criteria + "\n";
		string += "Subsamples=" + subsamples + "\n";
		string += "SubsamplesSize=" + subsamplesSize + "\n";
		string += "ClusterFrom=" + clusterFrom + "\n";
		string += "ClusterTo=" + clusterTo + "\n";
		string += "Run=" + run + "\n";

		return string;
	}
}
