/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kmeans_utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author enrico
 */
class ParserProperties {

	String logsDirname;
	String kmeansOutputFilename;

	private ParserProperties(String logsDirname, String kmeansOutputFilename) {
		this.logsDirname = logsDirname;
		this.kmeansOutputFilename = kmeansOutputFilename;
	}

	public static ParserProperties parse(String propertiesFilename) {
		ParserProperties kmeansParserProperties = null;

		try {
			FileInputStream propertiesInputStream = null;
			String logsDirnameString;
			String outputFilenameString;

			propertiesInputStream = new FileInputStream(propertiesFilename);
			Properties properties = new Properties();

			properties.load(propertiesInputStream);

			logsDirnameString = properties.getProperty(Constants.LOGSDIRNAME_KEY, "");
			outputFilenameString = properties.getProperty(Constants.OUTPUTFILENAME_KEY, "");

			if ((logsDirnameString.equals("")) || (outputFilenameString.equals(""))) {
				kmeansParserProperties = null;
			} else {
				kmeansParserProperties = new ParserProperties(logsDirnameString, outputFilenameString);
			}
		} catch (IOException ex) {
			Logger.getLogger(RScriptProperties.class.getName()).log(Level.SEVERE, null, ex);
		}

		return kmeansParserProperties;
	}
}
