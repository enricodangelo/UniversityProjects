/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author enrico
 */
public class KMeansGenerator {

	private ArrayList<String> datasetsFilename;
	private ArrayList<String> centroidsSelectionAlgorithms;
	private ArrayList<String> centroidsUpdaterAlgorithms;
	private ArrayList<String> metrics;
	private ArrayList<String> criteria;
	private int subsamples;
	private int subsamplesSize;
	private int clusterFrom;
	private int clusterTo;
	private int run;

	public KMeansGenerator(KMeansProperties properties) {
		this.datasetsFilename = properties.datasetsFilename;
		this.centroidsSelectionAlgorithms = properties.centroidsSelectionAlgorithms;
		this.centroidsUpdaterAlgorithms = properties.centroidsUpdaterAlgorithms;
		this.metrics = properties.metrics;
		this.criteria = properties.criteria;
		this.subsamples = properties.subsamples;
		this.subsamplesSize = properties.subsamplesSize;
		this.clusterFrom = properties.clusterFrom;
		this.clusterTo = properties.clusterTo;
		this.run = properties.run;
	}

	public Map<String, String> generateAllKMeans() {
		Map<String, String> result = new HashMap<String, String>();

		for (String datasetFilename : datasetsFilename) {
			for (String centroidsSelectionAlgorithm : centroidsSelectionAlgorithms) {
				for (String centroidsUpdaterAlgorithm : centroidsUpdaterAlgorithms) {
					for (String metric : metrics) {
						for (String criterion : criteria) {
							String configName = datasetFilename.substring(datasetFilename.indexOf("dataset_"), datasetFilename.length()) + "-" +
									centroidsSelectionAlgorithm.substring(centroidsSelectionAlgorithm.indexOf(".") + 1, centroidsSelectionAlgorithm.length()) + "-" +
									centroidsUpdaterAlgorithm.substring(centroidsUpdaterAlgorithm.indexOf(".") + 1, centroidsUpdaterAlgorithm.length());
							result.put(configName,
									generateKMeans(datasetFilename,
									centroidsSelectionAlgorithm,
									centroidsUpdaterAlgorithm,
									metric,
									criterion,
									subsamples,
									subsamplesSize,
									clusterFrom,
									clusterTo,
									run));
						}
					}
				}
			}
		}

		return result;
	}

	private String generateKMeans(String datasetFilename, String centroidsSelectionAlgorithm, String centroidsUpdaterAlgorithm, String metric, String criterion, int subsamples, int subsamplesSize, int clusterFrom, int clusterTo, int run) {
		String string = "";

		string += "DatasetFilename=" + datasetFilename + "\n";
		string += "Algorithm=algorithm.KMeansAlgorithm\n";
		string += "CentroidUpdater=" + centroidsUpdaterAlgorithm + "\n";
		string += "Metric=" + metric + "\n";
		string += "Criterion=" + criterion + "\n";
		string += "CentroidSelection=" + centroidsSelectionAlgorithm + "\n";
		string += "Subsamples=" + subsamples + "\n";
		string += "SubsamplesSize=" + subsamplesSize + "\n";
		string += "GivenCentroids=" + "\n";
		string += "ClusterFrom=" + clusterFrom + "\n";
		string += "ClusterTo=" + clusterTo + "\n";
		string += "Run=" + run + "\n";

		return string;
	}
}
