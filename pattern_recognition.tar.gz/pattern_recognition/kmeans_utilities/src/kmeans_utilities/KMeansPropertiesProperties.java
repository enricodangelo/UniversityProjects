/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author enrico
 */
public class KMeansPropertiesProperties {

	String datasetsDirname;
	String centroidsSelectionAlgorithms;
	String centroidsUpdaterAlgorithms;
	String metrics;
	String criteria;
	String subsamples;
	String subsamplesSize;
	String clusterFrom;
	String clusterTo;
	String run;
	String kmeansPropertiesFilename;

	private KMeansPropertiesProperties(String datasetsDirname, String centroidsSelectionAlgorithms, String centroidsUpdaterAlgorithms, String metrics, String criteria, String subsamples, String subsamplesSize, String clusterFrom, String clusterTo, String run, String kmeansPropertiesFilename) {
		this.datasetsDirname = datasetsDirname;
		this.centroidsSelectionAlgorithms = centroidsSelectionAlgorithms;
		this.centroidsUpdaterAlgorithms = centroidsUpdaterAlgorithms;
		this.metrics = metrics;
		this.criteria = criteria;
		this.subsamples = subsamples;
		this.subsamplesSize = subsamplesSize;
		this.clusterFrom = clusterFrom;
		this.clusterTo = clusterTo;
		this.run = run;
		this.kmeansPropertiesFilename = kmeansPropertiesFilename;
	}

	public static KMeansPropertiesProperties parse(String propertiesFilename) {
		KMeansPropertiesProperties kmeansPropertiesProperties = null;

		try {
			FileInputStream propertiesInputStream = null;
			String datasetsDirnameString;
			String centroidsSelectionAlgorithmsString;
			String centroidsUpdaterAlgorithmsString;
			String metricsString;
			String criteriaString;
			String subsamplesString;
			String subsamplesSizeString;
			String clusterFromString;
			String clusterToString;
			String runString;
			String kmeansPropertiesFilenameString;

			propertiesInputStream = new FileInputStream(propertiesFilename);
			Properties properties = new Properties();

			properties.load(propertiesInputStream);

			datasetsDirnameString = properties.getProperty(Constants.DATASETSDIRNAME_KEY, "");
			centroidsSelectionAlgorithmsString = properties.getProperty(Constants.CENTROIDSSELECTIONALGORITHMS_KEY, "");
			centroidsUpdaterAlgorithmsString = properties.getProperty(Constants.CENTROIDSUPDATERALGORITHMS_KEY, "");
			metricsString = properties.getProperty(Constants.METRICS_KEY, "");
			criteriaString = properties.getProperty(Constants.CRITERIA_KEY, "");
			subsamplesString = properties.getProperty(Constants.SUBSAMPLES_KEY, "");
			subsamplesSizeString = properties.getProperty(Constants.SUBSAMPLESSIZE_KEY, "");
			clusterFromString = properties.getProperty(Constants.CLUSTERFROM_KEY, "");
			clusterToString = properties.getProperty(Constants.CLUSTERTO_KEY, "");
			runString = properties.getProperty(Constants.RUN_KEY, "");
			kmeansPropertiesFilenameString = properties.getProperty(Constants.KMEANSPROPERTIESFILENAME_KEY, "");

			if ((datasetsDirnameString.equals("")) ||
					(centroidsSelectionAlgorithmsString.equals("")) ||
					(centroidsUpdaterAlgorithmsString.equals("")) ||
					(metricsString.equals("")) ||
					(criteriaString.equals("")) ||
					(subsamplesString.equals("")) ||
					(subsamplesSizeString.equals("")) ||
					(clusterFromString.equals("")) ||
					(clusterToString.equals("")) ||
					(runString.equals("")) ||
					(kmeansPropertiesFilenameString.equals(""))) {
				kmeansPropertiesProperties = null;
			} else {
				kmeansPropertiesProperties = new KMeansPropertiesProperties(
						datasetsDirnameString,
						centroidsSelectionAlgorithmsString,
						centroidsUpdaterAlgorithmsString,
						metricsString,
						criteriaString,
						subsamplesString,
						subsamplesSizeString,
						clusterFromString,
						clusterToString,
						runString,
						kmeansPropertiesFilenameString);
			}
		} catch (IOException ex) {
			Logger.getLogger(RScriptProperties.class.getName()).log(Level.SEVERE, null, ex);
		}

		return kmeansPropertiesProperties;
	}
}
