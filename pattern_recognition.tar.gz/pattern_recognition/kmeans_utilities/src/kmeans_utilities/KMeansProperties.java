/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 *
 * @author enrico
 */
public class KMeansProperties {

	ArrayList<String> datasetsFilename;
	ArrayList<String> centroidsSelectionAlgorithms;
	ArrayList<String> centroidsUpdaterAlgorithms;
	ArrayList<String> metrics;
	ArrayList<String> criteria;
	int subsamples;
	int subsamplesSize;
	int clusterFrom;
	int clusterTo;
	int run;

	private KMeansProperties(ArrayList<String> datasetsFilename, ArrayList<String> centroidSelectionAlgorithms, ArrayList<String> centroidUpdaterAlgorithms, ArrayList<String> metrics, ArrayList<String> criteria, int subsamples, int subsamplesSize, int clusterFrom, int clusterTo, int run) {
		this.datasetsFilename = datasetsFilename;
		this.centroidsSelectionAlgorithms = centroidSelectionAlgorithms;
		this.centroidsUpdaterAlgorithms = centroidUpdaterAlgorithms;
		this.metrics = metrics;
		this.criteria = criteria;
		this.subsamples = subsamples;
		this.subsamplesSize = subsamplesSize;
		this.clusterFrom = clusterFrom;
		this.clusterTo = clusterTo;
		this.run = run;
	}

	public static KMeansProperties parse(String propertiesFilename) {
		KMeansProperties kmeansProperties = null;

		try {
			FileInputStream propertiesInputStream = null;

			String datasetsFilenameString;
			String centroidSelectionAlgorithmsString;
			String centroidUpdaterAlgorithmsString;
			String metricsString;
			String criteriaString;
			String clusterFromString;
			String clusterToString;
			String subsamplesString;
			String subsamplesSizeString;
			String runString;

			propertiesInputStream = new FileInputStream(propertiesFilename);
			Properties properties = new Properties();

			properties.load(propertiesInputStream);

			datasetsFilenameString = properties.getProperty(Constants.DATASETSFILENAME_KEY, "");
			centroidSelectionAlgorithmsString = properties.getProperty(Constants.CENTROIDSSELECTIONALGORITHMS_KEY, "");
			centroidUpdaterAlgorithmsString = properties.getProperty(Constants.CENTROIDSUPDATERALGORITHMS_KEY, "");
			metricsString = properties.getProperty(Constants.METRICS_KEY, "");
			criteriaString = properties.getProperty(Constants.CRITERIA_KEY, "");
			subsamplesString = properties.getProperty(Constants.SUBSAMPLES_KEY, "");
			subsamplesSizeString = properties.getProperty(Constants.SUBSAMPLESSIZE_KEY, "");
			clusterFromString = properties.getProperty(Constants.CLUSTERFROM_KEY, "");
			clusterToString = properties.getProperty(Constants.CLUSTERTO_KEY, "");
			runString = properties.getProperty(Constants.RUN_KEY, "");
			
			ArrayList<String> datasetsFilename = parseArrayList(datasetsFilenameString);
			ArrayList<String> centroidSelectionAlgorithms = parseArrayList(centroidSelectionAlgorithmsString);
			ArrayList<String> centroidUpdaterAlgorithms = parseArrayList(centroidUpdaterAlgorithmsString);
			ArrayList<String> metrics = parseArrayList(metricsString);
			ArrayList<String> criteria = parseArrayList(criteriaString);
			int clusterFrom = parseInteger(clusterFromString);
			int clusterTo = parseInteger(clusterToString);
			int subsamples = parseInteger(subsamplesString);
			int subsamplesSize = parseInteger(subsamplesSizeString);
			int run = parseInteger(runString);

			if ((datasetsFilename == null) ||
					(centroidSelectionAlgorithms == null) ||
					(centroidUpdaterAlgorithms == null) ||
					(metrics == null) ||
					(criteria == null) ||
					(subsamples == -1) ||
					(subsamplesSize == -1) ||
					(clusterFrom == -1) ||
					(clusterTo == -1) ||
					(run == -1)) {
				kmeansProperties = null;
			} else {
				kmeansProperties = new KMeansProperties(
						datasetsFilename,
						centroidSelectionAlgorithms,
						centroidUpdaterAlgorithms,
						metrics,
						criteria,
						subsamples,
						subsamplesSize,
						clusterFrom,
						clusterTo,
						run);
			}
		} catch (IOException ex) {
			Logger.getLogger(RScriptProperties.class.getName()).log(Level.SEVERE, null, ex);
		}

		return kmeansProperties;
	}

	private static int parseInteger(String string) {
		int result = 0;

		try {
			if (string.equals("")) {
				result = -1;
			} else {
				result = Integer.parseInt(string.trim());
			}
		} catch (NumberFormatException ex) {
			result = -1;
		} finally {
			return result;
		}
	}

	private static ArrayList<String> parseArrayList(String string) {
		ArrayList<String> result = new ArrayList<String>();
		Pattern separator = Pattern.compile(",");

		if (string.equals("")) {
			result = null;
		} else {
			String[] strings = separator.split(string);
			for (String str : strings) {
				result.add(str.trim());
			}
		}

		return result;
	}
}
