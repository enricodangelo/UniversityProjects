/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author enrico
 */
public class RScriptGenerator {

	private Random generator;
	private ArrayList<Integer> clusters;
	private ArrayList<Integer> features;
	private ArrayList<Integer> datasetSizes;
	private int max_coord;
	private int max_dev;
	private double[][] means;
	private int[] std_dev;
	private int[] size;

	public RScriptGenerator(RScriptProperties properties) {
		this.clusters = properties.clusters;
		this.features = properties.features;
		this.datasetSizes = properties.datasetSizes;
		this.max_coord = properties.maxCoord;
		this.max_dev = properties.maxDev;
		generator = new Random();
	}

	public ArrayList<String> generateAllRScripts() {
		ArrayList<String> result = new ArrayList<String>();

		int i = 1;
		for (Integer datasetSize : datasetSizes) {
			for (Integer nClusters : clusters) {
				for (Integer nFeatures : features) {
					means = new double[nClusters][nFeatures];
					std_dev = new int[nClusters];
					size = new int[nClusters];

					init(datasetSize, nClusters, nFeatures);

					result.add(generate_R_script(nClusters, nFeatures, i));
					i++;
				}
			}
		}

		return result;
	}

	private void init(int datasetSize, int clusters, int features) {
		for (int i = 0; i < clusters; i++) {
			for (int j = 0; j < features; j++) {
				means[i][j] = generator.nextInt(max_coord);
			}
			std_dev[i] = generator.nextInt(max_dev - 1) + 1;
		}
		int localSize = datasetSize;
//		System.out.println(localSize);
		do {
			int selected = generator.nextInt(clusters);
			size[selected] = size[selected] + 500;
			localSize = localSize - 500;
		} while (localSize > 0);
	}

	private String generate_R_script(int nClusters, int nFeatures, int count) {
		String datasetFilename;

		if (count < 10) {
			datasetFilename = "dataset_" + "0" + count;
		} else {
			datasetFilename = "dataset_" + count;
		}
		
		String string = "";

		string += "library = library(MASS)" + "\n";

		for (int centroid = 1; centroid <= nClusters; centroid++) {
			string += "S" + centroid + " <- matrix(c(";

			for (int i = 1; i <= nFeatures; i++) {
				for (int j = 1; j <= nFeatures; j++) {
					if (i == j) {
						string += std_dev[centroid - 1];
					} else {
						string += 0;
					}
					if (j != nFeatures) {
						string += ",";
					}
				}
				if (i != nFeatures) {
					string += ",";
				}
			}
			string += "),nrow=" + nFeatures + ",byrow=TRUE)" + "\n";

			string += "mu" + centroid + " <- c(";
			for (int i = 0; i < nFeatures; i++) {
				string += means[centroid - 1][i];
				if (i != nFeatures - 1) {
					string += ",";
				}
			}
			string += ")" + "\n";
		}

		int total = 0;
		for (int centroid = 1; centroid <= nClusters; centroid++) {
			string += "n" + centroid + " <- " + size[centroid - 1] + "\n";
			total += size[centroid - 1];
		}
		string += "n <- " + total + "\n";

		for (int centroid = 1; centroid <= nClusters; centroid++) {
			string += "val" + centroid + " <- mvrnorm(n" + centroid + ",mu=mu" + centroid + ",Sigma=S" + centroid + ")" + "\n";
		}


		string += "tmp0 <- rbind(val1,val2)" + "\n";
		for (int centroid = 3; centroid <= nClusters; centroid++) {
			if (centroid != nClusters) {
				string += "tmp" + centroid % 2 + " <- rbind(tmp" + (centroid - 1) % 2 + ",val" + centroid + ")";
			} else {
				string += "allval <- rbind(tmp" + (centroid - 1) % 2 + ",val" + centroid + ")";
			}
			string += "\n";
		}

		string += "allval <- allval[sample(n,n),]" + "\n";

		//string += "write.csv(allval,\"" + datasetFilename + "\",quote=FALSE,row.names=FALSE,col.names=FALSE)" + "\n";
		string += "write.table(allval, file=\"" + datasetFilename + "\", quote=FALSE, sep=\",\", row.names=FALSE, col.names=FALSE)" + "\n";
		return string;
	}
}
