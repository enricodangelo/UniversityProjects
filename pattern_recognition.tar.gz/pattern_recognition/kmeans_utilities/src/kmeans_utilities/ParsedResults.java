/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author enrico
 */
public class ParsedResults {

	HashMap<String, ArrayList<ParsedLog>> parsedLogs;
	HashMap<String, ResultData> allResultData;
	private int realK = 15;

	public ParsedResults(HashMap<String, ArrayList<ParsedLog>> parsedLogs) {
		this.parsedLogs = parsedLogs;
		allResultData = new HashMap<String, ResultData>();
	}

	public void computeResults() {
		for (String key : parsedLogs.keySet()) {
			//System.out.println(parsedLogs.get(key).size());
			ResultData resultData = computeOneResult(parsedLogs.get(key));
			allResultData.put(key, resultData);
		}
	}

	private ResultData computeOneResult(ArrayList<ParsedLog> logs) {
		ParsedLog standardLog = null;
		ResultData resultData = null;
		double[] errors = new double[4];
		double[] speedups = new double[4];
		double[] iterations = new double[4];
		double[] numberOfComparisons = new double[4];
		double[] runTimes = new double[4];
		double[] wallClockTimes = new double[4];


		for (ParsedLog log : logs) {
			if ((log.algorithm == AlgorithmType.NAIVE_RANDOM) &&
					(log.k == realK)) {
				standardLog = log;
			}
		}


		for (ParsedLog log : logs) {
			if (log.k == realK) {
				if ((standardLog.datasetSize != log.datasetSize) ||
						(standardLog.features != log.features) ||
						(!standardLog.datasetIndex.equals(log.datasetIndex)) ||
						(standardLog.k != log.k)) {
					System.err.println("ParsedResults.computeOneResult(): errore");
					System.exit(-1);
				}

				errors[log.algorithm] = log.error;
				speedups[log.algorithm] = (double) standardLog.wallClockTime / (double) log.wallClockTime;
				iterations[log.algorithm] = log.iterations;
				numberOfComparisons[log.algorithm] = log.numberOfComparisons;
				runTimes[log.algorithm] = log.runTime;
				wallClockTimes[log.algorithm] = log.wallClockTime;
			}
		}

		resultData = new ResultData(
				standardLog.datasetSize,
				standardLog.features,
				standardLog.k,
				errors,
				speedups,
				iterations,
				numberOfComparisons,
				runTimes,
				wallClockTimes);

		return resultData;
	}

	public String getHeader() {
		return ResultData.getHeader();
	}

	@Override
	public String toString() {
		String string = "";

		for (String key : allResultData.keySet()) {
			string += allResultData.get(key) + "\n";
		}

		return string;
	}
}
