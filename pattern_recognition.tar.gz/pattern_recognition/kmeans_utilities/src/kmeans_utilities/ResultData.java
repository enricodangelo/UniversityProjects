/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kmeans_utilities;

/**
 *
 * @author enrico
 */
class ResultData {

	public static String getHeader() {
		String string = "";

		string += "# algorithms order: naive-random, naive-refined, efficient-random, efficient-refined\n";
		string += "# datasetSize, features, k, errors, speedups, iterations, numberOfComparisons, runTimes, wallClockTimes\n";

		return string;
	}

	int datasetSize;
	int features;
	int k;
	double[] errors;
	double[] speedups;
	double[] iterations;
	double[] numberOfComparisons;
	double[] runTimes;
	double[] wallClockTimes;

	public ResultData(int datasetSize, int features, int k, double[] errors, double[] speedups, double[] iterations, double[] numberOfComparisons, double[] runTimes, double[] wallClockTimes) {
		this.datasetSize = datasetSize;
		this.features = features;
		this.k = k;
		this.errors = errors;
		this.speedups = speedups;
		this.iterations = iterations;
		this.numberOfComparisons = numberOfComparisons;
		this.runTimes = runTimes;
		this.wallClockTimes = wallClockTimes;
	}

	@Override
	public String toString() {
		String tmpString = "";

		tmpString += datasetSize + ", ";
		tmpString += features + ", ";
		tmpString += k + ", ";
		for (double error : errors) {
			tmpString += error + ", ";
		}
		for (double speedup : speedups) {
			tmpString += speedup + ", ";
		}
		for (double iteration : iterations) {
			tmpString += iteration + ", ";
		}
		for (double numberOfComparison : numberOfComparisons) {
			tmpString += numberOfComparison + ", ";
		}
		for (double runTime : runTimes) {
			tmpString += runTime + ", ";
		}
		for (double wallClockTime : wallClockTimes) {
			tmpString += wallClockTime + ", ";
		}

		String string = tmpString.substring(0, tmpString.length() - 2);

		return string;
	}
}
