/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kmeans_utilities;

/**
 *
 * @author enrico
 */
public class Constants {

	public static final String DATASET_SIZE_KEY = "DatasetSize";
	public static final String CLUSTERS_KEY = "Clusters";
	public static final String FEATURES_KEY = "Features";
	public static final String MAX_COORD_KEY = "MaxCoord";
	public static final String MAX_DEV_KEY = "MaxDev";

	public static final String RSCRIPTS_OPTION = "--R-Scripts";
	public static final String KMEANS_OPTION = "--K-Means";
	public static final String KMEANSPROPERTIES_OPTION = "--K-Means-Properties";
	public static final String PARSE_OPTION = "--Parse";

	public static final String DATASETSFILENAME_KEY = "DatasetsFilename";
	public static final String DATASETSDIRNAME_KEY = "DatasetsDirname";
	public static final String CENTROIDSSELECTIONALGORITHMS_KEY = "CentroidsSelectionAlgorithms";
	public static final String CENTROIDSUPDATERALGORITHMS_KEY = "CentroidsUpdaterAlgorithms";
	public static final String METRICS_KEY = "Metrics";
	public static final String CRITERIA_KEY = "Criteria";
	public static final String SUBSAMPLES_KEY = "Subsamples";
	public static final String SUBSAMPLESSIZE_KEY = "SubsamplesSize";
	public static final String CLUSTERFROM_KEY = "ClusterFrom";
	public static final String CLUSTERTO_KEY = "ClusterTo";
	public static final String RUN_KEY = "Run";
	public static final String LOGSDIRNAME_KEY = "LogsDirName";
	public static final String OUTPUTFILENAME_KEY = "OutputFilename";
	public static final String DATAFILENAME_KEY = "DataFilename";
	public static final String OUTPUTDIRNAME_KEY = "OutputDirname";

	public static final String KMEANSPROPERTIESFILENAME_KEY = "KMeansPropertiesFilename";



}
