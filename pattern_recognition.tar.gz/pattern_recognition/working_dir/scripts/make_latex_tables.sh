#!/bin/bash --

datafile=${HOME}/Projects/pattern_recognition/working_dir/output/kmeans-output.csv
sorted_datafile=${HOME}/Projects/pattern_recognition/working_dir/output/kmeans-output.sorted.csv
datafiles_destination_dir=${HOME}/Projects/pattern_recognition/working_dir/output
scripts_destination_dir=${HOME}/Projects/pattern_recognition/working_dir/scripts/gnuplot
graphs_destination_dir=${scripts_destination_dir}

SPEEDUP="speedup"
ERROR="error"
NUM_OF_ITERATIONS="number_of_iterations"
NUM_OF_COMPARISONS="number_of_comparisons"

get_algorithm_name() {
	if [[ $1 == 4 || $1 == 8 || $1 == 12 || $1 == 16 ]]
	then
		algorithm_name="Lloyd-Random"
	elif [[ $1 == 5 || $1 == 9 || $1 == 13 || $1 == 17 ]]
	then
		algorithm_name="Lloyd-Refined"
	elif [[ $1  == 6 || $1 == 10 || $1 == 14 || $1 == 18 ]]
	then
		algorithm_name="Efficient-Random"
	elif [[ $1 == 7 || $1 == 11 || $1 == 15 || $1 == 19 ]]
	then
		algorithm_name="Efficient-Refined"
	fi
}

make_datafiles() {
	features_size=$1
	column=$2
	graph_type=$3
	
	get_algorithm_name ${column}

	grep ", ${features_size}, " ${sorted_datafile} | cut -d"," -f1,${column} > ${datafiles_destination_dir}/${graph_type}_${features_size}_${algorithm_name}.table
}

make_table_body() {
	columns=$1
	first_row=$2
	last_row=$3

	for (( i=${first_row}; i<=${last_row}; i=${i}+3 ))
	do
		`cut ${sorted_datafile} -d"," -f"1 & ${columns}"`
	done
}

make_gnuplot_script() {
	table_type=$1
	features_size=$2

	if [[ ${table_type} == ${SPEEDUP} ]]
	then
		title="Speed-up"
	elif [[ ${graph_type} == ${ERROR} ]]
	then
		title="Errore"
	elif [[ ${graph_type} == ${NUM_OF_ITERATIONS} ]]
	then
		title="Numero di iterazioni"
	elif [[ ${graph_type} == ${NUM_OF_COMPARISONS} ]]
	then
		title="Numero di confronti"
	fi

	table+="\begin{center}"
	table+="\begin{tabular}{| l | l |}"
	table+=" \hline"
	table+=" Dimensione del dataset & ${column_name}"
	table+=" 1 & 2\\"
	table+=" 4 & 5\\"
	table+=" 7 & 8\\"
	table+=" \hline"
	table+="\end{tabular}"
	table+="\end{center}"

	if [[ ${table_type} == ${SPEEDUP} ]]
	then
		title_line="Dimensione del dataset & Lloyd-Refined & Efficient-Random & Efficient-Refined\\"
	else
		algorithms="Dimensione del dataset & Lloyd-Random & Lloyd-Refined & Efficient-Random & Efficient-Refined\\"
	fi

	for algorithm_name in ${algorithms}
	do
		datafile=${graph_type}_${features_size}_${algorithm_name}.data
		plot_command="${plot_command}\"${datafiles_destination_dir}/${datafile}\" using 1:2 title \"${algorithm_name}\" with linespoints"

		if [[ ${algorithm_name} != "Efficient-Refined" ]]
		then
			plot_command="${plot_command}, "
		else
			plot_command="${plot_command}\n"
		fi
	done

	script+="${plot_command}"

	echo -e "${script}" > ${scripts_destination_dir}/${graph_type}_${features_size}.gnuplot
}

generate_scripts() {
	first_column=$1
	last_column=$2
	graph_type=$3

	for features_size in 2 5 10
	do
		get_algorithm_name ${column}

		for ((column=${first_column}; column <= ${last_column} ; column++))	
		do
			make_datafiles ${features_size} ${column} ${graph_type} ${algorithm_name}	
		done

		make_gnuplot_script ${graph_type} ${features_size}
	done
}


generate_graphs() {
	for gnuplot_script in `ls -1  ${scripts_destination_dir}/*.gnuplot`
	do
		echo "gnuplot ${gnuplot_script}"
		gnuplot ${gnuplot_script}
	done
}

#sort_datafile
#generate_scripts 4 7 ${ERROR}
#generate_scripts 8 11 ${SPEEDUP}
#generate_graphs
make_table_body "4 & 5 & 6 & 7" 0 44

#12 15 iterazioni
#16 19 confronti
