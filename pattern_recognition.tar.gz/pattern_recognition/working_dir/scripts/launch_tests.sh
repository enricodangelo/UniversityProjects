#!/bin/bash

base_dir=/home/enrico/Projects/pattern_recognition/working_dir/
jar_dir=${base_dir}jars/
properties_dir=${base_dir}properties/
logs_dir=${base_dir}logs/
jar_file=K-Means.jar
tests_log_file=${logs_dir}Alltests.log

for property_file in `ls -1 ${properties_dir}KMeans-*`
do
  string=`grep "${property_file} FINISHED" $tests_log_file`
  if [ -z "${string}" ]
  then
    starting_date=`date`
    echo "${starting_date}: ${property_file} STARTED" >> $tests_log_file

    log_file=`basename ${property_file%.properties}.log`
    #cat ${property_file} > ${logs_dir}${log_file}
    echo ""  >> ${logs_dir}${log_file}

    current_date=`date`
    echo "${current_date}: ${property_file}"

    java -Xmx2048M -cp ${jar_dir}${jar_file} cli.KMeansCLI ${property_file} &> ${logs_dir}${log_file}

    finishing_date=`date`
    echo "${finishing_date}: ${property_file} FINISHED" >> $tests_log_file
  fi
done
