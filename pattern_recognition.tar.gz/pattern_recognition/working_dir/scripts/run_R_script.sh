#!/bin/bash --

dirname=/home/enrico/Projects/pattern_recognition/working_dir/scripts/R

for scriptname in `ls -1 $dirname`
do
  echo "R --min-vsize=1G CMD BATCH $dirname/$scriptname"
  R --min-vsize=1G CMD BATCH $dirname/$scriptname
done