#!/bin/bash --

datafile=${HOME}/Projects/pattern_recognition/working_dir/output/kmeans-output.csv
sorted_datafile=${HOME}/Projects/pattern_recognition/working_dir/output/kmeans-output.sorted.csv
datafiles_destination_dir=${HOME}/Projects/pattern_recognition/working_dir/output
scripts_destination_dir=${HOME}/Projects/pattern_recognition/working_dir/scripts/gnuplot
graphs_destination_dir=${scripts_destination_dir}

SPEEDUP="speedup"
ERROR="error"

get_algorithm_name() {
	if [[ $1 == 4 || $1 == 8 ]]
	then
		algorithm_name="Lloyd-Random"
	elif [[ $1 == 5 || $1 == 9 ]]
	then
		algorithm_name="Lloyd-Refined"
	elif [[ $1  == 6 || $1 == 10 ]]
	then
		algorithm_name="Efficient-Random"
	elif [[ $1 == 7 || $1 == 11 ]]
	then
		algorithm_name="Efficient-Refined"
	fi
}

sort_datafile() {
	sort -n ${datafile} > ${sorted_datafile}
}

make_datafiles() {
	features_size=$1
	column=$2
	graph_type=$3
	
	get_algorithm_name ${column}

	grep ", ${features_size}, " ${sorted_datafile} | cut -d"," -f1,${column} > ${datafiles_destination_dir}/${graph_type}_${features_size}_${algorithm_name}.data
}

make_gnuplot_script() {
	graph_type=$1
	features_size=$2

	if [[ ${graph_type} == ${SPEEDUP} ]]
	then
		ylabel="Speed-up"
	elif [[ ${graph_type} == ${ERROR} ]]
	then
		ylabel="Errore"
	fi

	script=""
	#script+="set terminal svg enhanced\n"
	script+="set terminal postscript enhanced color\n"
	#script+="set output \"${graphs_destination_dir}/graph_${graph_type}_${features_size}.svg\"\n"
	script+="set output \"${graphs_destination_dir}/graph_${graph_type}_${features_size}.ps\"\n"
	script+="set grid \n"
	scrpit+="set xtics 1, 1\n"
	script+="set key left box\n"
	#script+="set title \"Numero di features: ${features_size}\"\n"
	script+="set xlabel \"Dimensione del dataset\"\n"
	script+="set ylabel \"${ylabel}\"\n"
	#script+="set pointsize 10\n"

	plot_command="plot "

	if [[ ${graph_type} == ${SPEEDUP} ]]
	then
		algorithms="Lloyd-Refined Efficient-Random Efficient-Refined"
	else
		algorithms="Lloyd-Random Lloyd-Refined Efficient-Random Efficient-Refined"
	fi

	for algorithm_name in ${algorithms}
	do
		datafile=${graph_type}_${features_size}_${algorithm_name}.data
		plot_command="${plot_command}\"${datafiles_destination_dir}/${datafile}\" using 1:2 title \"${algorithm_name}\" with linespoints"

		if [[ ${algorithm_name} != "Efficient-Refined" ]]
		then
			plot_command="${plot_command}, "
		else
			plot_command="${plot_command}\n"
		fi
	done

	script+="${plot_command}"

	echo -e "${script}" > ${scripts_destination_dir}/${graph_type}_${features_size}.gnuplot
}

generate_scripts() {
	first_column=$1
	last_column=$2
	graph_type=$3

	for features_size in 2 5 10
	do
		get_algorithm_name ${column}

		for ((column=${first_column}; column <= ${last_column} ; column++))	
		do
			make_datafiles ${features_size} ${column} ${graph_type} ${algorithm_name}	
		done

		make_gnuplot_script ${graph_type} ${features_size}
	done
}


generate_graphs() {
	for gnuplot_script in `ls -1  ${scripts_destination_dir}/*.gnuplot`
	do
		echo "gnuplot ${gnuplot_script}"
		gnuplot ${gnuplot_script}
	done
}

sort_datafile
generate_scripts 4 7 ${ERROR}
generate_scripts 8 11 ${SPEEDUP}
generate_graphs
