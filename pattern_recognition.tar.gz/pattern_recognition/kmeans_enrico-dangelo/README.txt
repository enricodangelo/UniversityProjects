Per eseguire il progetto occorre:
1) avviare il prompt dei comandi di windows o una shell unix
2) accedere alla directory "kmeans" che contiene il file "K-Means.jar"
3) lanciare il comando: java -jar K-Means.jar 

la directory "lib" con il suo contenuto deve essere nella stessa directory in cui e' presente il file "K-Means.jar"

Nella directory "datasets" sono presenti alcuni datasets per provare l'algoritmo.

La directory "datasets/scripts" contiene gli script di R utilizzati per la creazione dei dataset

La directory "netbeans_project" contiene i file sorgenti del progetto.
