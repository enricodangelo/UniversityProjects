/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cli;

import data.KMeansData;
import utils.DataReporter;
import data.ResultData;
import java.util.ArrayList;
import utils.KMeansPropertiesParser;

/**
 *
 * @author enrico
 */
public class KMeansCLI {

	/*
	 * Main del metodo che lancia l'esecuzione dell'algoritmo da linea di comando
	 *
	 * L'input deve essere un file di property ben formattato
	 */
	public static void main(String[] args) {
		KMeansData kmeansData;
		ArrayList<ResultData> results;

		if (args.length != 1) {
			System.err.println("Kmeans <properties file>");
			System.exit(-1);
		}

		kmeansData = KMeansPropertiesParser.parse(args[0]);

		if (kmeansData == null) {
			System.err.println("KmeansData e' null");
			System.exit(-1);
		}

		// Lancio l'algoritmo
		results = kmeansData.getAlgorithm().calculate(kmeansData.getInputData());

		// Report dell'analisi (input)
		String inputReport = DataReporter.reportInput(kmeansData.getInputData().getOutputFormat(), kmeansData);
		System.out.println(inputReport);

		// Report dell'analisi (output)
		String outputReport = DataReporter.reportOutput(kmeansData.getInputData().getOutputFormat(), results);
		System.out.println(outputReport);
	}
}
