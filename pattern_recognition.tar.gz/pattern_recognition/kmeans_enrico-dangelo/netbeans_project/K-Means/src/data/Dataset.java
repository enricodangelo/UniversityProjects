/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import data.kdtree.KDTree;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author enrico
 */
public class Dataset {

	private final String name;
	private final List<Point> points;
	private KDTree kdTree;
	private final int features;

	/*
	 *
	 */
	public Dataset(String name, List<Point> points, int features) {
		if (name != null) {
			this.name = name;
		} else {
			this.name = "";
		}
		this.points = points;
		this.features = features;
	}

	/*
	 *
	 */
	public String getName() {
		return name;
	}

	/*
	 *
	 */
	public List<Point> getPoints() {
		return points;
	}

	/*
	 *
	 */
	public int getSize() {
		return points.size();
	}

	/*
	 *
	 */
	public int getFeatures() {
		return features;
	}

	/*
	 *
	 */
	public KDTree getKDTree() {
		return kdTree;
	}

	/*
	 *
	 */
	public void generateKDTree() {
		this.kdTree = new KDTree(points.toArray(new Point[0]));
	}

	/*
	 * Genera un subsambple del dataset senza ripetizioni
	 * Il parametro subsampleSize viene interpretato come un valore percentuale
	 */
	public ArrayList<Point> subsample(int subsampleSize) {
		ArrayList<Integer> choosenIndexes = new ArrayList<Integer>();
		ArrayList<Point> subsample = new ArrayList<Point>();
		Random generator = new Random(System.currentTimeMillis());

		int stopSize = (int) Math.floor((double) points.size() * ((double) subsampleSize / 100.0));

		for (int i = 0; i < stopSize; i++) {
			int choosenIndex;
			do {
				choosenIndex = generator.nextInt(points.size());
			} while (choosenIndexes.contains(choosenIndex));

			choosenIndexes.add(choosenIndex);
			Point choosenPoint = (Point) points.get(choosenIndex).clone();
			subsample.add(choosenPoint);
		}

		return subsample;
	}

	/*
	 *
	 */
	@Override
	public Object clone() {
		ArrayList<Point> clonedPoints = new ArrayList<Point>();
		for (Point point : points) {
			clonedPoints.add((Point) point.clone());
		}
		Dataset clonedDataset = new Dataset(name, clonedPoints, features);

		return clonedDataset;
	}
}
