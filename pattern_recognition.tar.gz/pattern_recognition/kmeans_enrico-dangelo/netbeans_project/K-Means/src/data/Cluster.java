/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author enrico
 */
public class Cluster {

	private static int lastID = 0;
	private int clusterID;
	private ArrayList<Point> points = new ArrayList<Point>();
	private Centroid centroid = null;
	private boolean changed = false;

	/*
	 *
	 */
	public int getClusterID() {
		return clusterID;
	}

	/*
	 *
	 */
	public Centroid getCentroid() {
		return centroid;
	}

	/*
	 *
	 */
	public Collection<Point> getPoints() {
		return points;
	}

	/*
	 *
	 */
	public void setChanged() {
		this.changed = true;
	}

	/*
	 *
	 */
	public void setUnChanged() {
		this.changed = false;
	}

	/*
	 *
	 */
	public boolean isChanged() {
		return this.changed;
	}

	/*
	 *
	 */
	public Cluster(Centroid centroid) {
		clusterID = ++lastID;
		this.centroid = centroid;
		centroid.setCluster(this);
	}

	/*
	 *
	 */
	public boolean add(Point point) {
		Cluster oldBelongingCluster = point.getBelongingCluster();
		boolean added = false;

		//se il punto apparteneva ad un cluster diverso da questo
		if ((oldBelongingCluster == null) ||
				((oldBelongingCluster != null) &&
				(!oldBelongingCluster.equals(this)))) {

			//tolgo il punto dal vecchio cluster, se esiste
			if (oldBelongingCluster != null) {
				oldBelongingCluster.remove(point);
			}

			//aggiungo il punto a questo cluster
			points.add(point);
			setChanged();
			point.setBelongingCluster(this);

			added = true;
		} else if (oldBelongingCluster.equals(this)) {

			//se il punto gia' apparteneva a questo cluster ritorno false
			added = false;
		}
		
		return added;
	}

	/*
	 *
	 */
	public boolean remove(Point point) {
		setChanged();
		return points.remove(point);
	}

	/*
	 *
	 */
	public void updateMean() {
		centroid.toZero();

		for (Point point : points) {
			centroid.addToThis(point);
		}

		centroid.divide(points.size());

		setUnChanged();
	}

	/*
	 *
	 */
	@Override
	public Object clone() {
		Cluster clonedCluster = new Cluster((Centroid) centroid.clone());
		lastID--;
		clonedCluster.clusterID = this.clusterID;
		clonedCluster.points = (ArrayList<Point>) this.points.clone();

		return clonedCluster;
	}

	/*
	 *
	 */
	@Override
	public String toString() {
		return "clusterID: " + clusterID + ", mean: " + centroid + ", points: " + points;
	}
}
