/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import centroidSelection.GivenCentroidSelection;
import centroidSelection.ICentroidSelection;
import centroidSelection.RandomCentroidSelection;
import centroidSelection.RefinedCentroidSelection;
import criterion.ICriterion;
import java.util.ArrayList;
import java.util.Map;
import metric.IMetric;

/**
 *
 * @author enrico
 */
public class InputData {

	private final Dataset dataset;
	private final IMetric metric;
	private final ICriterion criterion;
	private final ICentroidSelection centroidSelection;
	private final int subsamples;
	private final int subsampleSize;
	private final Map<Integer, ArrayList<Centroid>> givenCentroids;
	private final int clusterFrom;
	private final int clusterTo;
	private final int run;
	private final boolean outputFormat;

	/*
	 *
	 */
	public InputData(Dataset dataset,
			IMetric metric,
			ICriterion criterion,
			ICentroidSelection centroidSelection,
			int subsamples,
			int subsampleSize,
			Map<Integer, ArrayList<Centroid>> givenCentroids,
			int clusterFrom,
			int clusterTo,
			int run,
			boolean readable) {
		if (dataset == null) {
			System.err.println("Dataset e' null");
			System.exit(-1);
		}
		this.dataset = dataset;
		this.metric = metric;
		this.criterion = criterion;
		this.centroidSelection = centroidSelection;
		this.subsamples = subsamples;
		this.subsampleSize = subsampleSize;
		this.givenCentroids = givenCentroids;
		this.clusterFrom = clusterFrom;
		this.clusterTo = clusterTo;
		this.run = run;
		this.outputFormat = readable;
	}

	/*
	 *
	 */
	public InputData(
			Dataset dataset,
			IMetric metric,
			ICriterion criterion,
			GivenCentroidSelection centroidSelection,
			Map<Integer, ArrayList<Centroid>> givenCentroids,
			int clusterFrom,
			int clusterTo,
			int run,
			boolean outputFormat) {
		this(dataset, metric, criterion, centroidSelection, 0, 0, givenCentroids, clusterFrom, clusterTo, run, outputFormat);
	}

	/*
	 *
	 */
	public InputData(
			Dataset dataset,
			IMetric metric,
			ICriterion criterion,
			RandomCentroidSelection centroidSelection,
			int clusterFrom,
			int clusterTo,
			int run,
			boolean outputFormat) {
		this(dataset, metric, criterion, centroidSelection, 0, 0, null, clusterFrom, clusterTo, run, outputFormat);
	}

	/*
	 *
	 */
	public InputData(
			Dataset dataset,
			IMetric metric,
			ICriterion criterion,
			RefinedCentroidSelection centroidSelection,
			int subsamples,
			int subsampleSize,
			int clusterFrom,
			int clusterTo,
			int run,
			boolean outputFormat) {
		this(dataset, metric, criterion, centroidSelection, subsamples, subsampleSize, null, clusterFrom, clusterTo, run, outputFormat);
	}

	/**
	 * @return the dataset
	 */
	public Dataset getDataset() {
		return dataset;
	}

	/**
	 * @return the metric
	 */
	public IMetric getMetric() {
		return metric;
	}

	/**
	 * @return the criterion
	 */
	public ICriterion getCriterion() {
		return criterion;
	}

	/**
	 * @return the centroidSelection
	 */
	public ICentroidSelection getCentroidSelection() {
		return centroidSelection;
	}

	/**
	 * @return the subsamples
	 */
	public int getSubsamples() {
		return subsamples;
	}

	/**
	 * @return the subsampleSize
	 */
	public int getSubsampleSize() {
		return subsampleSize;
	}

	/**
	 * @return the givenCentroids
	 */
	public Map<Integer, ArrayList<Centroid>> getGivenCentroids() {
		return givenCentroids;
	}

	/**
	 * @return the clusterFrom
	 */
	public int getClusterFrom() {
		return clusterFrom;
	}

	/**
	 * @return the clusterTo
	 */
	public int getClusterTo() {
		return clusterTo;
	}

	/**
	 * @return the run
	 */
	public int getRun() {
		return run;
	}

	/**
	 * @return
	 */
	public boolean getOutputFormat() {
		return outputFormat;
	}

	/*
	 *
	 */
	@Override
	public Object clone() {
		return new InputData(
				(Dataset)dataset.clone(),
				metric,
				criterion,
				centroidSelection,
				subsamples,
				subsampleSize,
				givenCentroids,
				clusterFrom,
				clusterTo,
				run,
				outputFormat);
	}

	/*
	 *
	 */
	@Override
	public String toString() {
		String string = "";

		string += "" + getDataset().getName() + " [" + getDataset().getSize() + "]" + "\n";
		string += "" + getMetric().getDescription() + "\n";
		string += "" + getCriterion().getDescription() + "\n";
		string += "" + getCentroidSelection().getDescription() + "\n";
		if (getSubsamples() != 0) {
			string += "" + getSubsamples() + "\n";
		}
		if (getSubsampleSize() != 0) {
			string += "" + getSubsampleSize() + "\n";
		}
		if (getGivenCentroids() != null) {
			string += "" + getGivenCentroids() + "\n";
		}
		string += "clusterFrom: " + getClusterFrom() + "\n";
		string += "clusterTo: " + getClusterTo() + "\n";
		string += "run: " + getRun();
		string += "outputFormat: " + (outputFormat ? "readable" : "non-readable");

		return string;
	}
}
