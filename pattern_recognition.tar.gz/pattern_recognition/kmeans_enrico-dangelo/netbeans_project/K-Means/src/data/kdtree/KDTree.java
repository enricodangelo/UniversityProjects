/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data.kdtree;

import data.*;
import java.util.Stack;
import metric.IMetric;
import utils.KMeansConstants;

/**
 *
 * @author enrico
 */
public class KDTree {

	/*
	 * enumeration per distinguere i figli destri e i figli sinistri
	 */
	private enum Side {

		LEFT, RIGHT
	}
	private KDNode node;
	private final int depth;
	private final KDTree parent;
	private final Side childSide;
	private KDTree leftChild = null;
	private KDTree rightChild = null;
	private final int id;
	private static int counter = 0;

	/*
	 * Costruttore
	 * Costruisce un KD-Tree per i punti passatigli
	 *
	 * @param points i punti da inserire nel KD-Tree
	 */
	public KDTree(Point[] points) {
		this(points, 0, null, null, counter);
	}

	/*
	 * Costruttore privato
	 * Viene utilizzato dal costruttore pubblico
	 */
	private KDTree(Point[] points, int depth, KDTree parent, Side side, int id) {
		this.depth = depth;
		this.parent = parent;
		this.childSide = side;
		this.id = counter;

		// Creo il nodo
		node = new KDNode(points);

		if (points.length > 1) {
			// Ordino la lista di punti
			quicksort(points, node.splittingDimension, 0, points.length);

			// Divido i punti tra minori o uguali al mediano e maggiori del mediano
			Point[] leftPoints = new Point[node.medianIndex + 1];
			Point[] rightPoints = new Point[points.length - (node.medianIndex + 1)];
			for (int i = 0; i < leftPoints.length; i++) {
				leftPoints[i] = points[i];
			}
			for (int i = 0; i < rightPoints.length; i++) {
				rightPoints[i] = points[leftPoints.length + i];
			}

			// Costruisco i sottoalberi sinitro e destro
			if (leftPoints.length == 0) {
				leftChild = null;
			} else {
				leftChild = new KDTree(leftPoints, depth + 1, this, Side.LEFT, counter++);
			}
			if (rightPoints.length == 0) {
				rightChild = null;
			} else {
				rightChild = new KDTree(rightPoints, depth + 1, this, Side.RIGHT, counter++);
			}
		}
	}

	/*
	 * Ritorna il nodo associato alla radice di questo albero
	 *
	 * @return il nodo associato alla radice di questo albero
	 */
	public KDNode getNode() {
		return node;
	}

	/*
	 * Ritorna il figlio sinistro di questo albero
	 *
	 * @return il figlio sinistro di questo albero
	 */
	public KDTree getLeftChild() {
		return leftChild;
	}

	/*
	 * Ritorna il figlio destro di questo albero
	 *
	 * @return il figlio sinistro di questo albero
	 */
	public KDTree getRightChild() {
		return rightChild;
	}

	/*
	 * Restituisce il fratello di questo albero
	 *
	 * @return il fratello di questo albero
	 */
	private KDTree getSibling() {
		KDTree sibling = null;

		if (childSide == Side.LEFT) {
			if (parent != null) {
				if (parent.rightChild != null) {
					sibling = parent.rightChild;
				}
			}
		} else if (childSide == Side.RIGHT) {
			if (parent != null) {
				if (parent.leftChild != null) {
					sibling = parent.leftChild;
				}
			}
		}
		// Tutti i nodi hanno il campo child definito, ad eccezione della radice dell'albero

		return sibling;
	}

	/*
	 * Implementazione iterativa di quicksort
	 *
	 * @param points tutti i punti
	 * @param dimension la dimensione secondo la quale ordinare i punti
	 * @param startIndex indice che indica il primo dei punti da ordinare
	 * @param endIndex indice che indica la posizione dopo l'ultimo dei punti da ordinare
	 */
	public void quicksort(Point[] points, int dimension, int startIndex, int endIndex) {

		Stack<Integer> stack = new Stack<Integer>();

		stack.push(startIndex);
		stack.push(endIndex - 1);

		while (!stack.empty()) {
			int right = stack.pop();
			int left = stack.pop();

			do {
				int pivotIndex = left;
				int currentLeft = left;
				int currentRight = right;

				do {
					// scorro la parte sinistra
					while (points[currentLeft].values[dimension] < points[pivotIndex].values[dimension]) {
						currentLeft++;
					}
					// scorro la parte destra
					while (points[currentRight].values[dimension] > points[pivotIndex].values[dimension]) {
						currentRight--;
					}
					if (currentLeft <= currentRight) {
						if (currentLeft != currentRight) {
							// swap dei valori
							Point tmp = points[currentLeft];
							points[currentLeft] = points[currentRight];
							points[currentRight] = tmp;
						}
						currentLeft++;
						currentRight--;
					}
				} while (currentLeft < currentRight);

				if (currentRight - left > right - currentLeft) {	// se la parte sinistra e' piu' grande
					if (left < currentRight) {
						stack.push(left);
						stack.push(currentRight);
						left = currentLeft;
					}
				} else {
					if (currentLeft < right) { // se la parte destra e' piu' grande
						stack.push(currentLeft);
						stack.push(right);
						right = currentRight;
					}
				}

			} while (left < right - 1);
		}
	}

	/*
	 * Algoritmo di nearest neighbor
	 *
	 * @param target il target della ricerca
	 * @param metric la metrica da utilizzare
	 * @return il punto piu' vicino al target
	 */
	public Point nearestNeighbour(Point target, IMetric metric) {
		Point currentBestPoint = null;
		Point temporaryBestPoint = null;
		double distanceFromCurrentBest;
		KDTree tree = this;

		while (tree.node.type == KDNode.Type.INTERNAL) {
			if (target.values[tree.node.splittingDimension] <= tree.node.splittingValue) {
				// Scendo nella parte sinistra dell'albero
				tree = tree.leftChild;
			} else {
				// Scendo nella parte destra dell'albero
				tree = tree.rightChild;
			}
		}

		currentBestPoint = tree.node.points.get(0);
		distanceFromCurrentBest = metric.distance(target, currentBestPoint, KMeansConstants.COLLECT_STATISTICS);

		// Finche' non risale l'albero fino alla radice, cioe' l'albero su cui e' stato chiamato il metodo
		while (tree != this) {
			KDTree sibling = tree.getSibling();

			if (sibling != null) {
				// La distanza tra il punto target e il punto piu' vicino corrente
				// rappresenta il raggio di un ipersfera centrata proprio nel punto target.
				Point nearestPointInSibling = sibling.node.getNearestPoint(target);

				double distanceFromNearestPointInSibling = metric.distance(target, nearestPointInSibling, KMeansConstants.COLLECT_STATISTICS);
				//boolean siblingIntersect = sibling.node.intersect(target, distanceFromCurrentBest, metric);

				if (distanceFromNearestPointInSibling < distanceFromCurrentBest) {
					// devo controllare il nodo fratello
					temporaryBestPoint = sibling.nearestNeighbour(target, metric);

					double distanceFromTemporaryBest = metric.distance(target, temporaryBestPoint, KMeansConstants.COLLECT_STATISTICS);

					if (distanceFromTemporaryBest < distanceFromCurrentBest) {
						currentBestPoint = temporaryBestPoint;
						distanceFromCurrentBest = distanceFromTemporaryBest;
					}
				}
			}
			tree = tree.parent;
		}

		return currentBestPoint;
	}

//	/*
//	 *
//	 */
//	@Override
//	public String toString() {
//		String string = "";
//		//String indent = "";
//
//		//for (int i = 0; i <= depth; i++) {
//		//	indent += "\t";
//		//}
//
//		//string += indent;
//
//		string += "[";
//		string += "id: " + id;
//		string += ", ";
//		string += "depth: " + depth;
//		string += ", ";
//		if (parent != null) {
//			string += "parent: " + parent.id;
//			string += ", ";
//		}
//		//if (childSide == Side.LEFT) {
//		//	string += "LEFT: ";
//		//} else if (childSide == Side.RIGHT) {
//		//	string += "RIGHT: ";
//		//}
//
//		//string += "\n";
//		//string += indent;
//		//string += node.toString();
//
//		//string += "\n";
//		//string += indent;
//
//		if (leftChild != null) {
//			//string += "\n" + leftChild.toString();
//			string += leftChild.toString();
//		}
//		if (rightChild != null) {
//			//string += "\n" + rightChild.toString();
//			string += rightChild.toString();
//		}
//		string += "]";
//
//		return string;
//	}
}
