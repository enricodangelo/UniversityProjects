/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data.kdtree;

import data.*;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public class KDNode {

	public enum Type {

		INTERNAL, LEAF
	};
	public ArrayList<Point> points;
	/*
	 * hyperRectCoordinates rappresenta le coordinate minime e massime
	 * dell'iper-rettangolo che racchiude tutti i punti presenti nell'albero.
	 *
	 * hyperRectMinCoordinates[] contiene le coordinate minime
	 * hyperRectMaxCoordinates[] contiene le coordinate massime
	 */
	public final double[] hyperRectMinCoordinates;
	public final double[] hyperRectMaxCoordinates;
	public final int splittingDimension;
	public final double splittingValue;
	public final int medianIndex;
	public final Type type;
	private Centroid ownerPoint = null;

	/*
	 * Costruttore
	 * Genera un nodo del KD-Tree per i punti passati.
	 * La dimensione separatrice viene scelta come la dimensione con il range maggiore
	 * Il valore separatore viene scelto come il mediano della dimensione separatrice
	 * I punti con valore della dimensione indicata dalla dimensione separatrice uguale
	 * al valore separatore vanno nel figlio sinistro
	 * I nodi foglia contengono un solo punto
	 *
	 * @param points i punti che saranno contenuti nel nodo
	 */
	public KDNode(Point[] points) {
		hyperRectMinCoordinates = new double[points[0].getNDimensions()];
		hyperRectMaxCoordinates = new double[points[0].getNDimensions()];

		double currentMaxRange = 0;
		int maxRangeDimension = 0;

		// per ogni dimensione
		for (int i = 0; i < points[0].getNDimensions(); i++) {
			double currentMin = Double.MAX_VALUE;
			double currentMax = Double.MIN_VALUE;

			//per ogni punti
			for (int j = 0; j < points.length; j++) {
				if (points[j].values[i] < currentMin) {
					currentMin = points[j].values[i];
				}
				if (points[j].values[i] > currentMax) {
					currentMax = points[j].values[i];
				}
			}
			hyperRectMinCoordinates[i] = currentMin;
			hyperRectMaxCoordinates[i] = currentMax;

			double currentRange = currentMax - currentMin;
			if (currentRange > currentMaxRange) {
				currentMaxRange = currentRange;
				maxRangeDimension = i;
			}
		}

		splittingDimension = maxRangeDimension;

		// Prendo il mediano della lista
		int tmpMedianIndex;
		boolean rightMedian = false;

		if ((points.length % 2) != 0) {
			tmpMedianIndex = (int) Math.ceil(points.length / 2.0) - 1;
		} else {
			tmpMedianIndex = (int) (points.length / 2.0) - 1;
		}

		// Se l'elemento mediano e' duplicato prende l'ultima occorrenza
		do {
			if ((points.length > 1) && (points[tmpMedianIndex] == points[tmpMedianIndex + 1])) {
				tmpMedianIndex++;
			} else {
				rightMedian = true;
			}
		} while (!rightMedian);
		medianIndex = tmpMedianIndex;

		// Il valore del mediano
		splittingValue = points[medianIndex].values[splittingDimension];

		if (points.length == 1) {
			type = Type.LEAF;
		} else {
			type = Type.INTERNAL;
		}

		this.points = new ArrayList<Point>();
		for (Point point : points) {
			this.points.add(point);
		}
	}

	/*
	 * Ritorna il punto in h piu' vicino al punto c
	 *
	 * @param c il punto target
	 * @return il punto in h piu' vicino al punto c
	 */
	public Point getNearestPoint(Point c) {
		double[] nearestValues = new double[hyperRectMinCoordinates.length];

		for(int i = 0; i < nearestValues.length; i++) {
			if (c.values[i] < hyperRectMinCoordinates[i]) {
				nearestValues[i] = hyperRectMinCoordinates[i];
			} else if (c.values[i] > hyperRectMaxCoordinates[i]) {
				nearestValues[i] = hyperRectMaxCoordinates[i];
			} else {
				nearestValues[i] = c.values[i];
			}
		}
		return new Point(nearestValues);
	}

	/*
	 * Dati due centroidi, ritorna il punto in h piu' estremo nella direzone del secondo centroide
	 *
	 * @param centroid1 il primo centroide
	 * @param centroid2 il secondo centroide
	 * @return il punto in h piu' estremo nella direzone del secondo centroide
	 */
	public Point getExtremePoint(Point centroid1, Point centroid2) {
		Point extreme;
		double[] values = new double[centroid1.features];
		for (int i = 0; i < values.length; i++) {
			if (centroid2.values[i] > centroid1.values[i]) {
				// assegno a p[i] il valore massimo dell'iperrettangolo alla coordinata i
				values[i] = hyperRectMaxCoordinates[i];
			} else {
				// assegno a p[i] il valore minimo dell'iperrettangolo alla coordinata i
				values[i] = hyperRectMinCoordinates[i];
			}
		}
		extreme = new Point(values);

		return extreme;
	}

	/*
	 * Setta il centroide passato come owner(h)
	 *
	 * @param centroid il centroide owner di h
	 */
	public void setOwnerPoint(Centroid centroid) {
		if ((ownerPoint == null) || (!ownerPoint.equals(centroid))) {
			ownerPoint = centroid;
			for (Point point : points) {
				ownerPoint.getCluster().add(point);
			}
		}
	}

	/*
	 * Restituisce il centroide owner(h)
	 *
	 * @return il centroide owner(h)
	 */
	public Centroid getOwnerPoint() {
		return ownerPoint;
	}
}
