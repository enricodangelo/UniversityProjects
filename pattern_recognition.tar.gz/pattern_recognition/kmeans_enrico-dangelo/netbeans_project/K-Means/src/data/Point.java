package data;

/**
 * A Point implementation supporting k dimensions.
 */
public class Point {

	public final double[] values;
	public final int features;
	private Cluster belongingCluster = null;

	/*
	 *
	 */
    public int getNDimensions() {
        return values.length;
    }

	/*
	 *
	 */
	public double[] getValues() {
		return values;
	}

	/*
	 *
	 */
	public void setBelongingCluster(Cluster belongingCluster) {
		this.belongingCluster = belongingCluster;
	}

	/*
	 *
	 */
	public Cluster getBelongingCluster() {
		return belongingCluster;
	}

	/*
	 *
	 */
    public Point(double[] values) {
        this.values = values;
		this.features = this.values.length;
    }

	/*
	 *
	 */
	public void toZero() {
		for (int i = 0; i < values.length; i++) {
			values[i] = 0;
		}
	}

	/*
	 *
	 */
	public void addToThis(Point b) {
		for (int i = 0; i < values.length; i++) {
			values[i] += b.values[i];
		}
	}

	/*
	 *
	 */
	public void divide(int n) {
		for (int i = 0; i < values.length; i++) {
			values[i] /= n;

		}
	}

	/*
	 *
	 */
	public int compare(Object o1, Object o2) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

    /**
     * Returns the hash code value for this point.
     *
     * @return The hash code value for this point.
     */
    @Override
    public int hashCode() {
        int hash = 0;

        for (int i = 0; i < values.length; i++) {
            long v = Double.doubleToLongBits(values[i]);
            hash += (int) (v ^ (v >>> 32));
        }

        return hash;
    }

    /**
     * Returns true if the specified object is equal to the GenericPoint.
     *
     * @param obj The object to test for equality.
     * @return true if the specified object is equal to the
     * GenericPoint, false if not.
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Point)) {
            return false;
        }

        Point point = (Point) obj;

        for (int i = 0; i < values.length; i++) {
            if (values[i] != point.values[i]) {
                return false;
            }
        }

        return true;
    }

	/*
	 *
	 */
	public boolean shallowEquals(Point other) {
		for (int i = 0; i < values.length; i++) {
			if (this.values[i] != other.values[i]) {
				return false;
			}
		}
		return true;
	}

    /**
     * Returns a copy of the point.
     *
     * @return A copy of the point.
     */
    @Override
    public Object clone() {
        return new Point(this.values.clone());
    }

    /**
     * Returns a string representation of the point, listing its
     * coordinate values in order.
     *
     * @return A string representation of the point.
     */
    @Override
    public String toString() {
		String stringValues = "";

        for (int i = 0; i < values.length; ++i) {
            stringValues += values[i];
            if (i != values.length - 1) {
                stringValues += ", ";
            }
        }

        return stringValues;
    }

}