/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import algorithm.IClusteringAlgorithm;

/**
 *
 * @author enrico
 */
public class KMeansData {

	private final IClusteringAlgorithm algorithm;
	private final InputData inputData;

	/*
	 *
	 */
	public KMeansData(IClusteringAlgorithm algorithm, InputData inputData) {
		this.algorithm = algorithm;
		this.inputData = inputData;
	}

	/**
	 * @return the algorithm
	 */
	public IClusteringAlgorithm getAlgorithm() {
		return algorithm;
	}

	/**
	 * @return the inputData
	 */
	public InputData getInputData() {
		return inputData;
	}

	/*
	 *
	 */
	@Override
	public String toString() {
		String string = "";

		string += "" + getAlgorithm().getDescription() + "\n";
		string += getInputData().toString();

		return string;
	}
}
