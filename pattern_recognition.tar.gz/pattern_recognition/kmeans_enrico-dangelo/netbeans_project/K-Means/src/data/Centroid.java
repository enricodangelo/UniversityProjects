/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data;

/**
 *
 * @author enrico
 */
public class Centroid extends Point {
	private Cluster cluster;

	/*
	 *
	 */
	public Centroid(double[] values) {
        super(values.clone());
    }

	/*
	 *
	 */
	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}

	/*
	 *
	 */
	public Cluster getCluster() {
		return cluster;
	}

	/**
     * Returns a copy of the centroid.
     *
     * @return A copy of the centroid.
     */
    @Override
    public Object clone() {
        Centroid clonedCentroid = new Centroid(this.values.clone());
		clonedCentroid.setCluster(this.cluster);

		return clonedCentroid;
	}
}
