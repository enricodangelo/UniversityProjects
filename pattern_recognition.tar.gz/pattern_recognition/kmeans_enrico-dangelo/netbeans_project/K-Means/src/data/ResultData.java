/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public class ResultData {

	private double error;
	private int iterations;
	private long runTime;
	private long wallClockTime;
	private long numberOfComparisons;
	private ArrayList<Cluster> clusters;
	private ArrayList<Centroid> centroids;

	/*
	 *
	 */
	public ResultData(double error, int iterations, long numberOfComparisons, ArrayList<Cluster> clusters, ArrayList<Centroid> centroids) {
		this.error = error;
		this.iterations = iterations;
		this.numberOfComparisons = numberOfComparisons;
		this.clusters = new ArrayList<Cluster>();
		for (Cluster cluster : clusters) {
			this.clusters.add((Cluster) cluster.clone());
		}
		this.centroids = new ArrayList<Centroid>();
		for (Centroid centroid : centroids) {
			this.centroids.add((Centroid) centroid.clone());
		}
	}

	/**
	 * @return the error
	 */
	public double getError() {
		return error;
	}

	/**
	 * @return the clusters
	 */
	public ArrayList<Cluster> getClusters() {
		return clusters;
	}

	/**
	 * @return the centroids
	 */
	public ArrayList<Centroid> getCentroids() {
		return centroids;
	}

	/**
	 * @return the iterations
	 */
	public int getIterations() {
		return iterations;
	}

	/**
	 * @return il tempo impiegato dal miglior run
	 */
	public long getRunTime() {
		return runTime;
	}

	/**
	 * @return il tempo totale impiegato
	 */
	public long getWallclockTime() {
		return wallClockTime;
	}

	/**
	 * @param bestRunTime il tempo impiegato dal miglior run
	 */
	public void setBestRunTime(long bestRunTime) {
		this.runTime = bestRunTime;
	}

	/**
	 * @param bestRunTime il tempo impiegato dal miglior run
	 */
	public void setWallClockTime(long wallCloclTime) {
		this.wallClockTime = wallCloclTime;
	}

	/**
	 * @return the numberOfComparisons
	 */
	public long getNumberOfComparisons() {
		return numberOfComparisons;
	}

	/*
	 *
	 */
	@Override
	public String toString() {
		String string = "";

		string += error + "\n";
		string += iterations + "\n";
		string += runTime + "\n";
		string += numberOfComparisons + "\n";

		return string;
	}
}
