/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author enrico
 */
public class KMeansConstants {

	public static final String DATASET_KEY = "DatasetFilename";
	public static final String ALGORITHM_KEY = "Algorithm";
	public static final String CENTROIDUPDATER_KEY = "CentroidUpdater";
	public static final String METRIC_KEY = "Metric";
	public static final String CRITERION_KEY = "Criterion";
	public static final String CENTROIDSELECTION_KEY = "CentroidSelection";
	public static final String SUBSAMPLES_KEY = "Subsamples";
	public static final String SUBSAMPLESSIZE_KEY = "SubsamplesSize";
	public static final String GIVENCENTROIDS_KEY = "GivenCentroids";
	public static final String CLUSTERFROM_KEY = "ClusterFrom";
	public static final String CLUSTERTO_KEY = "ClusterTo";
	public static final String RUN_KEY = "Run";
	public static final String OUTPUTFORMAT_KEY = "OutputFormat";

	public static final String ALGORITHMS_LIST = "algorithmsList";
	public static final String CENTROIDSUPDATER_LIST = "centroidsUpdaterList";
	public static final String CRITERIA_LIST = "criteriaList";
	public static final String METRICS_LIST = "metricList";
	public static final String CENTROID_LIST = "centroidList";

	public static final String ALGORITHM_PACKAGE = "algorithm";
	public static final String CENTROIDUPDATER_PACKAGE = ALGORITHM_PACKAGE;
	public static final String CENTROIDSELECTION_PACKAGE = "centroidSelection";
	public static final String CRITERIA_PACKAGE = "criterion";
	public static final String METRIC_PACKAGE = "metric";
	public static final String ALGORITHM_INTERFACE = "algorithm.IClusteringAlgorithm";
	public static final String CENTROIDUPDATER_INTERFACE = "algorithm.ICentroidsUpdaterAlgorithm";
	public static final String METRICS_INTERFACE = "metric.IMetric";
	public static final String CRITERIA_INTERFACE = "criterion.ICriterion";
	public static final String CENTROIDSELECTION_INTERFACE = "centroidSelection.ICentroidSelection";
	public static final String DESCRIPTION_METHOD_NAME = "getDescription";
	public static final String AVAILABLE_METHOD_NAME = "availableToGUI";

	public static final boolean READABLE = true;
	public static final boolean NONREADABLE = false;

	public static final boolean COLLECT_STATISTICS = true;
	public static final boolean DONT_COLLECT_STATISTICS = false;

	public static final String PROPERTIES_PANEL_TITLE = "Proprietà";
	public static final String RESULTS_PANEL_TITLE = "Risultati";
	public static final String REPORT_PANEL_TITLE = "Report";

	public static final String CHART_TITLE = "Errore";
	public static final String CHART_X_AXIS_LABEL = "Numero di Cluster";
	public static final String CHART_Y_AXIS_LABEL = "Errore";

	public static final String GUI_NAME = "K-Means GUI";

	public static final String PROPERTIES_CHANGED_GUI_NAME = "Vuoi salvare la nuova configurazione?";
	public static final String PROPERTIES_CHANGED_MESSAGE = "Le proprietà sono cambiate.\nVuoi salvare le nuove proprietà?";

	public static final String CHOOSE_DATASET_BUTTON_LABEL = "Scegli dataset";
	public static final String SAVE_BUTTON_LABEL = "Salva impostazioni su file";
	public static final String LOAD_BUTTON_LABEL = "Carica impostazioni da file";
	public static final String OK_BUTTON_LABEL = "Ok, esegui";
	public static final String PC_SAVE_LABEL = "Salva";
	public static final String PC_CANCEL_LABEL = "Ignora";

	public static final String CHOOSE_DATASET_BUTTON_ACTION = CHOOSE_DATASET_BUTTON_LABEL;
	public static final String SAVE_BUTTON_ACTION = SAVE_BUTTON_LABEL;
	public static final String LOAD_BUTTON_ACTION = LOAD_BUTTON_LABEL;
	public static final String OK_BUTTON_ACTION = OK_BUTTON_LABEL;
	public static final String CENTROIDSELECTION_ACTION = "comboBoxChanged";
	public static final String PC_SAVE_ACTION = PC_SAVE_LABEL;
	public static final String PC_CANCEL_ACTION = PC_CANCEL_LABEL;
}
