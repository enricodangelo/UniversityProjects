/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author enrico
 */
public class ClassDiscover {

	private Map<String, String> algorithmsList;
	private Map<String, String> centroidsUpdaterList;
	private Map<String, String> criteriaList;
	private Map<String, String> metricList;
	private Map<String, String> centroidList;

	public ClassDiscover() {
		algorithmsList = new HashMap<String, String>();
		centroidsUpdaterList = new HashMap<String, String>();
		criteriaList = new HashMap<String, String>();
		metricList = new HashMap<String, String>();
		centroidList = new HashMap<String, String>();

		algorithmsList.put("Algoritmo K-Means.", "algorithm.KMeansAlgorithm");

		centroidsUpdaterList.put("Implementazione naive dell'algoritmo di K-Means (Lloyd's Algorithm)", "algorithm.LloydNaiveAlgorithm");
		centroidsUpdaterList.put("Implementazione efficiente dell'algoritmo K-Means tramite l'uso di kd-tree", "algorithm.EfficientAlgorithm");

		criteriaList.put("Somma delle Distanze Intraclasse al quadrato", "criterion.SumOfSquareError");

		metricList.put("Distanza Euclidea", "metric.Euclidean");
		metricList.put("Distanza Manhattan (Block Distance)", "metric.Manhattan");
		metricList.put("Distanza di Chebyshev", "metric.Chebyshev");

		centroidList.put("Selezione casuale di k punti come centroidi iniziali", "centroidSelection.RandomCentroidSelection");
		centroidList.put("Selezione dei centroidi iniziali tramite l'algoritmo k-means su subsamples del dataset", "centroidSelection.RefinedCentroidSelection");
	}

	public Map<String, String> getMap(String mapName) {
		Map map = null;

		if (mapName.equals(KMeansConstants.ALGORITHMS_LIST)) {
			map = algorithmsList;
		} else if (mapName.equals(KMeansConstants.CENTROIDSUPDATER_LIST)) {
			map = centroidsUpdaterList;
		} else if (mapName.equals(KMeansConstants.CRITERIA_LIST)) {
			map = criteriaList;
		} else if (mapName.equals(KMeansConstants.METRICS_LIST)) {
			map = metricList;
		} else if (mapName.equals(KMeansConstants.CENTROID_LIST)) {
			map = centroidList;
		}

		return map;
	}

	public Collection<String> getList(String mapName) {
		Map<String, String> classesMap = getMap(mapName);

		return classesMap.values();
	}

	/*
	 * Genera una mappa della forma <Descrizione, ClassName> di tutte le classi
	 * che implementano l'interfaccia interfaceName nel package packageName
	 *
	 * @param interfaceName l'interfaccia che deve essere implementata
	 * @param packageName il package che contiene le classi
	 * @return la mappa <descrizoine, className>
	 *
	 * interfaceName e' composta da package.interface
	 * L'interfaccia deve avere il metodo getDescription() (KMeansConstants.DESCRIPTION_METHOD_NAME)
	 *
	 * Le interfaccie che rispettano tali criteri sono:
	 *  - ICriterion
	 *  - IMetric
	 *  - IClusteringAlgorithm
	 *  - ICentroidsUpdaterAlgorithm
	 *
	 * La mappa usa come chiave la descrizione della classe e come valore il nome della classe
	 */
//	public static Map<String, String> discover(String interfaceName, String packageName) {
//		HashMap<String, String> list = new HashMap<String, String>();
//
//		try {
//			ArrayList<String> classes = getClasses(packageName);
//
//			for (String currentClass : classes) {
//				Class c = Class.forName(currentClass);
//				Class[] implementedInterfaces = c.getInterfaces();
//				boolean implementsInterface = false;
//
//				for (Class implementedInterface : implementedInterfaces) {
//					if (implementedInterface.getName().equals(interfaceName)) {
//						implementsInterface = true;
//					}
//				}
//
//				if ((!c.isInterface()) && (implementsInterface) && (!Modifier.isAbstract(c.getModifiers()))) {
//					Method availableToGUI = c.getMethod(KMeansConstants.AVAILABLE_METHOD_NAME, new Class[0]);
//					Method getDescription = c.getMethod(KMeansConstants.DESCRIPTION_METHOD_NAME, new Class[0]);
//					Object discoveredClass = c.newInstance();
//
//					boolean available = (Boolean) availableToGUI.invoke(discoveredClass, new Object[0]);
//
//					if (available) {
//						String classDescription = (String) getDescription.invoke(discoveredClass, new Object[0]);
//						list.put(classDescription, c.getName());
//					}
//				}
//			}
//
//		} catch (ClassNotFoundException ex) {
//			Logger.getLogger(ClassDiscover.class.getName()).log(Level.SEVERE, null, ex);
//		} catch (NoSuchMethodException ex) {
//			Logger.getLogger(ClassDiscover.class.getName()).log(Level.SEVERE, null, ex);
//		} catch (IllegalAccessException ex) {
//			Logger.getLogger(ClassDiscover.class.getName()).log(Level.SEVERE, null, ex);
//		} catch (IllegalArgumentException ex) {
//			Logger.getLogger(ClassDiscover.class.getName()).log(Level.SEVERE, null, ex);
//		} catch (InvocationTargetException ex) {
//			Logger.getLogger(ClassDiscover.class.getName()).log(Level.SEVERE, null, ex);
//		} catch (InstantiationException ex) {
//			Logger.getLogger(ClassDiscover.class.getName()).log(Level.SEVERE, null, ex);
//		}
//
//		return list;
//	}

	/*
	 * Ritorna la lista di classi presenti nel package packageName
	 *
	 * @param il nome del package
	 * @return la lista delle classi in packageName
	 *
	 * Le classi sono nel formato packagename.classname
	 */
	private static ArrayList<String> getClasses(String packageName) {
		ArrayList<String> classes = new ArrayList<String>();

		try {
			// ottiene il classpath (cioe' solo il jar del programma)
			String classPath = System.getProperty("java.class.path", null);

			// scorre tutti gli elementi presenti nel jar
			JarFile jarFile = new JarFile(classPath);
			Enumeration resources = jarFile.entries();

			while (resources.hasMoreElements()) {
				JarEntry je = (JarEntry) resources.nextElement();
				if (je.getName().matches(packageName + File.separator + ".+")) {
					String currentClass = je.getName();

					// sostisuisco il separatore di path con il separatore di package
					currentClass = currentClass.replace(File.separator, ".");
					// elimino l'estensione dal nome
					currentClass = currentClass.substring(0, currentClass.indexOf(".class"));

					// ora currentClass e' nel formato packagename.classname
					classes.add(currentClass);
				}
			}


		} catch (IOException ex) {
			Logger.getLogger(ClassDiscover.class.getName()).log(Level.SEVERE, null, ex);
		}

		return classes;
	}

	/* 
	 * Genera una lista di tutte classi che implementano l'interfaccia interfaceName nel package packageName
	 *
	 * @param interfaceName l'interfaccia che deve essere implementata
	 * @param packageName il package che contiene le classi
	 * @return la lista di classi
	 *
	 * Questa funzione non fa altro che chiamare discover e filtrare solo i valori della mappa che restituisce,
	 * per i dettagli guardare la descrizione di discover
	 */
//	public static Collection<String> getClassesList(String interfaceName, String packageName) {
//		Map<String, String> classesMap = discover(interfaceName, packageName);
//
//		return classesMap.values();
//	}
}
