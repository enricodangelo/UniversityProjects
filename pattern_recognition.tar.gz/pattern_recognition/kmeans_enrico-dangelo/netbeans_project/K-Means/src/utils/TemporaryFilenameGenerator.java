/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils;

import java.io.File;
import java.util.Calendar;

/**
 *
 * @author enrico
 */
public class TemporaryFilenameGenerator {

	/*
	 * Genera un nome di file temporaneo nella directory temporanea del sistema (OS dependant)
	 * Il nome generato inizia per "kmeans_"
	 */
	public static String getTemporaryFilename() {
		String filename = System.getProperty("java.io.tmpdir") + File.separator + "kmeans_" + Calendar.getInstance().getTimeInMillis();
		
		return filename;
	}
}
