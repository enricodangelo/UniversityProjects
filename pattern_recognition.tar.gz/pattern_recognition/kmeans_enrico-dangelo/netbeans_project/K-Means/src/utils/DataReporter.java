/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import algorithm.IClusteringAlgorithm;
import data.*;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public class DataReporter {

	/*
	 * Genera il report dell'input
	 *
	 * @param readable indica se il formato del report debba essere o meno leggibile (non adatto per il parsing)
	 * @param kmeansData l'input
	 * @return il report dell'input
	 */
	public static String reportInput(boolean readable, KMeansData kmeansData) {
		if (readable) {
			return reportInputReadable(kmeansData);
		} else {
			return reportInputNonReadable(kmeansData);
		}
	}

	/*
	 * Genera il report dell'output
	 *
	 * @param readable indica se il formato del report debba essere o meno leggibile (non adatto per il parsing)
	 * @param results l'output
	 * @return il report dell'output
	 */
	public static String reportOutput(boolean readable, ArrayList<ResultData> results) {
		if (readable) {
			return reportOutputReadable(results);
		} else {
			return reportOutputNonReadable(results);
		}
	}

	/*
	 * Genera il report dell'input in formato leggibile (non adatto per il parsing)
	 *
	 * @param kmeansData l'input
	 * @return il report dell'input
	 */
	private static String reportInputReadable(KMeansData kmeansData) {
		IClusteringAlgorithm algorithm = kmeansData.getAlgorithm();
		InputData inputData = kmeansData.getInputData();

		String datasetString = "Dataset: " + inputData.getDataset().getName() + "\n" +
				"Dimensione del dataset: " + inputData.getDataset().getSize() + "\n" +
				"Numero di features: " + inputData.getDataset().getFeatures() + "\n";
		String algorithmString = "Algoritmo: " + algorithm.getDescription() + "\n";
		String centroidsUpdaterString = "Metodo di aggiornamento dei centroidi: " + algorithm.getCentroidsUpdaterAlgorithm().getDescription() + "\n";
		String metricString = "Metrica: " + inputData.getMetric().getDescription() + "\n";
		String criterionString = "Criterio: " + inputData.getCriterion().getDescription() + "\n";
		String centroidSelectionString = "Metodo per la selezione iniziale dei centroidi: " + inputData.getCentroidSelection().getDescription() + "\n";
		if (inputData.getSubsamples() != 0) {
			centroidSelectionString += "Numero di subsamples: " + inputData.getSubsamples() + "\n";
			centroidSelectionString += "Dimensione di un subsamples: " + inputData.getSubsampleSize() + "\n";
		}
		if (inputData.getGivenCentroids() != null) {
			for (Integer key : inputData.getGivenCentroids().keySet()) {
				ArrayList<Centroid> centroids = inputData.getGivenCentroids().get(key);
				centroidSelectionString += "Centroidi dati:\n";
				for (Point point : centroids) {
					centroidSelectionString += "\t" + point + "\n";
				}
			}
		}
		String clusterString = "Range di k: " + inputData.getClusterFrom() + " - " + inputData.getClusterTo() + "\n";
		String runString = "Run: " + inputData.getRun() + "\n";

		return datasetString +
				algorithmString +
				centroidsUpdaterString +
				metricString +
				criterionString +
				centroidSelectionString +
				clusterString +
				runString;
	}

	/*
	 * Genera il report dell'output in formato leggibile (non adatto per il parsing)
	 *
	 * @param results l'output
	 * @return il report dell'output
	 */
	private static String reportOutputReadable(ArrayList<ResultData> results) {
		String resultString = "";

		for (ResultData result : results) {
			String clustersString = "Numero di cluster: " + result.getClusters().size() + "\n";
			String errorString = "Errore: " + result.getError() + "\n";
			String iterationsString = "Numero di iterazione: " + result.getIterations() + "\n";
			String comparisonsString = "Confronti effettuati: " + result.getNumberOfComparisons() + "\n";
			String bestRunTimeString = "Tempo impiegato dal miglior run (ms): " + result.getRunTime() + "\n";
			String wallclockTimeString = "Tempo totale impiegato (ms): " + result.getWallclockTime() + "\n";
			String clustersDescriptionString = "";
			for (Cluster cluster : result.getClusters()) {
				clustersDescriptionString += "\tCluster: " + cluster.getClusterID() + "\n";
				clustersDescriptionString += "\tMedia: " + cluster.getCentroid() + "\n";
				clustersDescriptionString += "\tNumero di punti: " + cluster.getPoints().size() + "\n";
				clustersDescriptionString += "\n";
			}

			resultString += clustersString + errorString + iterationsString + comparisonsString + bestRunTimeString + wallclockTimeString + clustersDescriptionString;
		}
		return resultString;
	}

	/*
	 * Genera il report dell'input in formato non leggibile (adatto per il parsing)
	 *
	 * @param kmeansData l'input
	 * @return il report dell'input
	 */
	private static String reportInputNonReadable(KMeansData kmeansData) {
		IClusteringAlgorithm algorithm = kmeansData.getAlgorithm();
		InputData inputData = kmeansData.getInputData();
		String resultString = "";

		resultString += inputData.getDataset().getName() + "," + inputData.getDataset().getSize() + "," + inputData.getDataset().getFeatures() + "\n";
		
		resultString += algorithm.getDescription() + "\n";
		resultString += algorithm.getCentroidsUpdaterAlgorithm().getDescription() + "\n";
		resultString += inputData.getMetric().getDescription() + "\n";
		resultString += inputData.getCriterion().getDescription() + "\n";
		resultString += inputData.getCentroidSelection().getDescription() + "\n";
		if (inputData.getSubsamples() != 0) {
			resultString += inputData.getSubsamples() + ",";
			resultString += inputData.getSubsampleSize() + "\n";
		} else {
			resultString += "0,0\n";
		}
		resultString += inputData.getClusterFrom() + "-" + inputData.getClusterTo() + "\n";
		resultString += inputData.getRun() + "\n";

		return resultString;
	}

	/*
	 * Genera il report dell'output in formato non leggibile (adatto per il parsing)
	 *
	 * @param results l'output
	 * @return il report dell'output
	 */
	private static String reportOutputNonReadable(ArrayList<ResultData> results) {
		String resultString = "";

		resultString += "#cluster size, error, iterations, number of comparisons, run time, wall clock time, [centroid, points in cluster]+" + "\n";
		resultString += "#DATA";
		for (ResultData result : results) {
			String clustersString = result.getClusters().size() + ",";
			String errorString = result.getError() + ",";
			String iterationsString = result.getIterations() + ",";
			String comparisonsString = result.getNumberOfComparisons() + ",";
			String bestRunTimeString = result.getRunTime() + ",";
			String wallClockTimeString = result.getWallclockTime() + ",";
			String clustersDescriptionString = "";
			for (Cluster cluster : result.getClusters()) {
				clustersDescriptionString += cluster.getCentroid() + ",";
				clustersDescriptionString += cluster.getPoints().size() + ",";
			}

			resultString += clustersString + errorString + iterationsString + comparisonsString + bestRunTimeString + wallClockTimeString + clustersDescriptionString + "\n";
		}
		return resultString;
	}
}
