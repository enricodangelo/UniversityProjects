/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import algorithm.ICentroidsUpdaterAlgorithm;
import centroidSelection.ICentroidSelection;
import criterion.ICriterion;
import data.Centroid;
import data.KMeansData;
import data.Dataset;
import data.Point;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import algorithm.IClusteringAlgorithm;
import data.InputData;
import java.lang.reflect.Constructor;
import metric.IMetric;

/**
 *
 * @author enrico
 */
public class KMeansPropertiesParser extends Properties {

	private static Dataset dataset;
	private static IClusteringAlgorithm algorithm;
	private static IMetric metric;
	private static ICriterion criterion;
	private static ICentroidSelection centroidSelection;
	private static int subsamples;
	private static int subsampleSize;
	private static Map<Integer, ArrayList<Centroid>> givenCentroids;
	private static int clusterFrom;
	private static int clusterTo;
	private static int run;
	private static boolean outputFormat;

	/*
	 * Fa il parsing delm file di properties
	 *
	 * @param propertiesFilename il nome del file di properties
	 * @return l'oggetto che rappresenta le proprieta'
	 */
	public static KMeansData parse(String propertiesFilename) {
		FileInputStream propertiesInputStream = null;
		String datasetFilename;
		String algorithmString;
		String centrouidUpdaterString;
		String metricString;
		String criterionString;
		String centroidSelectionString;
		String subsamplesString;
		String subsamplesSizeString;
		String givenCentroidsString;
		String clusterFromString;
		String clusterToString;
		String runString;
		String outputFormatString;

		boolean ok = true;

		try {
			propertiesInputStream = new FileInputStream(propertiesFilename);
			Properties properties = new Properties();
			properties.load(propertiesInputStream);

			datasetFilename = properties.getProperty(KMeansConstants.DATASET_KEY, "");
			algorithmString = properties.getProperty(KMeansConstants.ALGORITHM_KEY, "");
			centrouidUpdaterString = properties.getProperty(KMeansConstants.CENTROIDUPDATER_KEY, "");
			metricString = properties.getProperty(KMeansConstants.METRIC_KEY, "");
			criterionString = properties.getProperty(KMeansConstants.CRITERION_KEY, "");
			centroidSelectionString = properties.getProperty(KMeansConstants.CENTROIDSELECTION_KEY, "");
			subsamplesString = properties.getProperty(KMeansConstants.SUBSAMPLES_KEY, "");
			subsamplesSizeString = properties.getProperty(KMeansConstants.SUBSAMPLESSIZE_KEY, "");
			givenCentroidsString = properties.getProperty(KMeansConstants.GIVENCENTROIDS_KEY, "");
			clusterFromString = properties.getProperty(KMeansConstants.CLUSTERFROM_KEY, "");
			clusterToString = properties.getProperty(KMeansConstants.CLUSTERTO_KEY, "");
			runString = properties.getProperty(KMeansConstants.RUN_KEY, "");
			outputFormatString = properties.getProperty(KMeansConstants.OUTPUTFORMAT_KEY, "True");

			boolean tmpResult;

			tmpResult = checkDataset(datasetFilename);
			ok = ok && tmpResult;
			if (!tmpResult) {
				System.err.println("dataset errato");
			}

			tmpResult = checkAlgorithm(algorithmString, centrouidUpdaterString);
			ok = ok && tmpResult;
			if (!tmpResult) {
				System.err.println("algoritmo errato");
			}

			tmpResult = checkMetric(metricString);
			ok = ok && tmpResult;
			if (!tmpResult) {
				System.err.println("metrica errata");
			}

			tmpResult = checkCriterion(criterionString);
			ok = ok && tmpResult;
			if (!tmpResult) {
				System.err.println("criterio errato");
			}

			tmpResult = checkClusterFromTo(clusterFromString, clusterToString);
			ok = ok && tmpResult;
			if (!tmpResult) {
				System.err.println("cluster range errato");
			}

			tmpResult = checkCentroidSelection(centroidSelectionString, subsamplesString, subsamplesSizeString, givenCentroidsString);
			ok = ok && tmpResult;
			if (!tmpResult) {
				System.err.println("selezione dei centroidi errata");
			}

			tmpResult = checkRun(runString);
			ok = ok && tmpResult;
			if (!tmpResult) {
				System.err.println("run errato");
			}

			tmpResult = checkOutputFormat(outputFormatString);
			ok = ok && tmpResult;
			if (!tmpResult) {
				System.err.println("formato di output errato");
			}

		} catch (IOException ex) {
			Logger.getLogger(KMeansPropertiesParser.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				propertiesInputStream.close();
			} catch (IOException ex) {
				Logger.getLogger(KMeansPropertiesParser.class.getName()).log(Level.SEVERE, null, ex);
			}
		}

		if (ok) {
			KMeansData kmeansData = new KMeansData(algorithm,
					new InputData(dataset,
					metric,
					criterion,
					centroidSelection,
					subsamples,
					subsampleSize,
					givenCentroids,
					clusterFrom,
					clusterTo,
					run,
					outputFormat));

			return kmeansData;
		} else {
			return null;
		}
	}

	/*
	 * Controlla il formato delle proprieta' dataset
	 *
	 * @param datasetString il valore della proprieta' dataset
	 * @return true se il valore della proprieta' e' corretto, false altrimenti
	 *
	 * Il valore della proprieta' deve essere un nome di file esistente, ed il file deve contenere il dataset in formato csv
	 * (character separated values). Tutti i valori del dataset devono avere le stesse features e ogni valore deve essere
	 * separato da una virgola.
	 * Le righe che iniziano con il carattere "#" vengono ignorate dal parsing
	 */
	private static boolean checkDataset(String datasetFilename) {
		BufferedReader datasetBufferedReader = null;
		Pattern separator = Pattern.compile(",");
		String line;
		int lastLineLength = -1;
		int features = 0;
		double[] pointValues;
		Point point;
		ArrayList<Point> points = new ArrayList<Point>();
		boolean result = true;

		try {
			if (datasetFilename.equals("")) {
				result = false;
			} else {
				datasetBufferedReader = new BufferedReader(new FileReader(datasetFilename));

				while ((line = datasetBufferedReader.readLine()) != null) {
					if (!((line.startsWith("#")) ||
							(line.isEmpty()))) { //ignoro tutti i commenti e le righe vuote nel file del dataset

						String[] str = separator.split(line);
						features = str.length;

						if ((features != lastLineLength) && (lastLineLength != -1)) {
							System.err.println("checkDataset: missing values in dataset");
							result = false;
							break;
						}
						lastLineLength = features;

						pointValues = new double[features];
						for (int i = 0; i < features; i++) {
							pointValues[i] = Double.parseDouble(str[i]);

						}
						point = new Point(pointValues);

						points.add(point);
					}
				}

				if (result) {
					dataset = new Dataset(datasetFilename, points, features);
				}
			}
		} catch (IOException ex) {
			result = false;
		} finally {
			return result;
		}
	}

	/*
	 * Controlla il formato delle proprieta' algorithm e centroidUpdater
	 *
	 * @param algorithmString il valore della proprieta' algorithm
	 * @param centroidUpdaterString il valore della proprieta' centroidUpdater
	 * @return true se il valore delle proprieta' e' tra quelli ammessi, false aaltrimenti
	 *
	 * I valori di algorithm e centroidUpdater deveno essere tra quelli accettabili (cioe' deve esistere una classe con quel nome
	 * che implementa l'interfaccia IClusteringAlgorithm e ICentroidUpdaterAlgorithm, per le rispettive proprieta').
	 */
	private static boolean checkAlgorithm(String algorithmString, String centrouidUpdaterString) {
		ClassDiscover classDiscover = new ClassDiscover();
		boolean result = false;

		if ((!algorithmString.equals("")) && (!centrouidUpdaterString.equals(""))) {
//			Collection<String> centroidUpdaterAlgorithms = ClassDiscover.getClassesList(KMeansConstants.CENTROIDUPDATER_INTERFACE, KMeansConstants.CENTROIDUPDATER_PACKAGE);
//			Collection<String> clusteringAlgoritms = ClassDiscover.getClassesList(KMeansConstants.ALGORITHM_INTERFACE, KMeansConstants.ALGORITHM_PACKAGE);
			Collection<String> centroidUpdaterAlgorithms = classDiscover.getList(KMeansConstants.CENTROIDSUPDATER_LIST);
			Collection<String> clusteringAlgoritms = classDiscover.getList(KMeansConstants.ALGORITHMS_LIST);

			for (String centroidUpdaterKey : centroidUpdaterAlgorithms) {
				if (centrouidUpdaterString.equals(centroidUpdaterKey)) {
					for (String algorithmKey : clusteringAlgoritms) {
						if (algorithmString.equals(algorithmKey)) {
							try {
								ICentroidsUpdaterAlgorithm centroidUpdater = (ICentroidsUpdaterAlgorithm) Class.forName(centroidUpdaterKey).newInstance();
								Class[] contructorArgumentsClasses = new Class[]{ICentroidsUpdaterAlgorithm.class};
								Constructor clusteringAlgorithmConstructor = Class.forName(algorithmKey).getConstructor(contructorArgumentsClasses);
								algorithm = (IClusteringAlgorithm) clusteringAlgorithmConstructor.newInstance(centroidUpdater);

								result = true;
							} catch (Exception ex) {
							}
						}
					}
				}
			}
		}

		return result;
	}

	/*
	 * Controlla il formato delle proprieta' metric
	 *
	 * @param metricString il valore della proprieta' metric
	 * @return true se il valore della proprieta' e' tra quelli ammessi, false aaltrimenti
	 *
	 * Il valore di metric deve essere uno dei valori accettabili (cioe' deve esistere una classe con quel nome
	 * che implementa l'interfaccia IMetric).
	 */
	private static boolean checkMetric(String metricString) {
		ClassDiscover classDiscover = new ClassDiscover();
		boolean result = false;

		if (!metricString.equals("")) {
			Collection<String> metrics = classDiscover.getList(KMeansConstants.METRICS_LIST);

			for (String key : metrics) {
				if (metricString.equals(key)) {
					try {
						metric = (IMetric) Class.forName(key).newInstance();
						result = true;
					} catch (Exception ex) {
					}
				}
			}
		}

		return result;
	}

	/*
	 * Controlla il formato delle proprieta' criterion
	 *
	 * @param criterionString il valore della proprieta' criterion
	 * @return true se il valore della proprieta' e' tra quelli ammessi, false aaltrimenti
	 *
	 * Il valore di criterion deve essere uno dei valori accettabili (cioe' deve esistere una classe con quel nome
	 * che implementa l'interfaccia ICriterion).
	 */
	private static boolean checkCriterion(String criterionString) {
		ClassDiscover classDiscover = new ClassDiscover();
		boolean result = false;

		if (!criterionString.equals("")) {
			Collection<String> criteria = classDiscover.getList(KMeansConstants.CRITERIA_LIST);

			for (String key : criteria) {
				if (criterionString.equals(key)) {
					try {
						criterion = (ICriterion) Class.forName(key).newInstance();
						result = true;
					} catch (Exception ex) {
					}
				}
			}
		}

		return result;
	}

	/*
	 * Controlla il formato delle proprieta' centroidSelection
	 *
	 * @param centroidSelectionString il valore della proprieta' centroidSelection
	 * @param subsamplesString il valore della proprieta' subsamples
	 * @param subsamplesSizeString il valore della proprieta' subsampleSize
	 * @param givenCentroidsString il valore della proprieta' givenCentroids
	 * @return true se tutti i valori sono corretti, false altrimenti
	 *
	 * Il valore di centroidSelection deve essere uno dei valori accettabili (cioe' deve esistere una classe con quel nome
	 * che implementa l'interfaccia ICentroidSelection).
	 * Gli altri valori vengono controllati con le rispettive funzioni
	 */
	private static boolean checkCentroidSelection(String centroidSelectionString, String subsamplesString, String subsamplesSizeString, String givenCentroidsString) {
		ClassDiscover classDiscover = new ClassDiscover();
		boolean result = true;

		if (centroidSelectionString.equals("")) {
			result = false;
		} else {
			Collection<String> centroidSelectionMethods = classDiscover.getList(KMeansConstants.CENTROID_LIST);

			for (String key : centroidSelectionMethods) {
				if (centroidSelectionString.equals(key)) {
					try {
						centroidSelection = (ICentroidSelection) Class.forName(key).newInstance();

						if (centroidSelection.needSubsampling()) {
							result = checkSubsamples(subsamplesString) & checkSubsampleSize(subsamplesSizeString);
						} else {
							if (!givenCentroidsString.equals("")) {
								result = checkGivenCentroids(givenCentroidsString);
								if (!result) {
									givenCentroids = null;
								}
							} else {
								givenCentroids = null;
							}
						}
					} catch (Exception ex) {
					}
				}
			}
		}

		return result;
	}

	/*
	 * Controlla il formato delle proprieta' subsamples
	 *
	 * @param subsamplesString il valore della proprieta' subsamples
	 * @return true se il valore della proprieta' e' un numero, false altrimenti
	 */
	private static boolean checkSubsamples(String subsamplesString) {
		boolean result = true;

		try {
			if (subsamplesString.equals("")) {
				result = false;
			} else {
				int subsampleInt = Integer.parseInt(subsamplesString);

				subsamples = subsampleInt;
			}
		} catch (NumberFormatException ex) {
			result = false;
		}

		return result;
	}

	/*
	 * Controlla il formato delle proprieta' subsampleSize
	 *
	 * @param subsampleSizeString il valore della proprieta' subsampleSize
	 * @return true se il valore della proprieta' e' un numero, false altrimenti
	 */
	private static boolean checkSubsampleSize(String subsampleSizeString) {
		boolean result = true;

		try {
			if (subsampleSizeString.equals("")) {
				result = false;
			} else {
				int subsampleSizeInt = Integer.parseInt(subsampleSizeString);

				subsampleSize = subsampleSizeInt;
				
				if ((subsampleSize < 0) || (subsampleSize > 100)) {
					result = false;
				}
			}
		} catch (NumberFormatException ex) {
			result = false;
		}

		return result;
	}

	/*
	 * Controlla il formato della proprieta' givenCentroids
	 *
	 * @param givenCentroidsString il valore della proprieta' givenCentroids. Deve seguire il formato specificato sotto
	 * @return true se il parsing e' andato a buon fine, false altrimenti
	 *
	 * formato della stringa che contiene i punti:
	 * per ogni numero di cluster da testare serve un elenco di punti delimitati da ";"come centroidi iniziali,
	 * scritto tra parentesi quadre.
	 *
	 * es, per clusterFrom=2 e clusterTo=4, e numero di feature = 2:
	 * [1.0,2.0;3.0,4.0][5.0,6.0;7.0,8.0;9.0,10.0][11.0,12.0;13.0,14.0;15.0,16.0;17.0,18.0]
	 *
	 * Se compare piu' di una volta un elenco di punti per un dato numero di cluster allora viene preso
	 * l'ultimo elenco per quel dato numero di cluster.
	 *
	 * Se compare un elenco di punti per un numero di cluster che non viene testato questo viene ignorato
	 * (ma il parsing viene fatto ugualmente, percio' deve comunque essere ben formattato)
	 */
	private static boolean checkGivenCentroids(String givenCentroidsString) {
		String startingToken = "[";
		String endingToken = "]";
		boolean done = false;
		boolean result = true;

		try {
			if (givenCentroidsString.equals("")) {
				result = false;
			} else {
				givenCentroids = new HashMap<Integer, ArrayList<Centroid>>();

				//scompongo la stringa nell'elenco dei centroidi iniziali
				while (!done) {

					int beginIndex = givenCentroidsString.indexOf(startingToken);
					int endIndex = givenCentroidsString.indexOf(endingToken) + 1;

					//Separa la stringa in gruppi di centroidi,
					//dovrebbe esistere un gruppo per ogni numero di cluster da testare
					String centroidsGroupString = givenCentroidsString.substring(beginIndex, endIndex);

					checkCentroids(centroidsGroupString);

					givenCentroidsString = givenCentroidsString.substring(endIndex, givenCentroidsString.length());

					if (givenCentroidsString.equals("")) {
						done = true;

					}
				}
				//Nel file di properties ci devono essere i centroidi per ogni numero di cluster da testare
				//Se ce ne sono di piu' non e' un problema, semplicemente non vengono usati
				for (int i = clusterFrom; i <= clusterTo; i++) {
					if (!givenCentroids.containsKey(i)) {
						result = false;
					} else {
						ArrayList<Centroid> centroids = givenCentroids.get(i);

						//controllo che ogni punto abbia il giusto numero di features
						for (Centroid centroid : centroids) {
							if (centroid.getNDimensions() != dataset.getFeatures()) {
								result = false;
							}
						}
					}
				}
			}
		} catch (IndexOutOfBoundsException e) {
			result = false;
		}

		return result;
	}

	/*
	 *
	 */
	private static void checkCentroids(String centroidsGroupString) {
		Pattern centroidSeparator = Pattern.compile(";");
		Pattern featureSeparator = Pattern.compile(",");
		ArrayList<Centroid> centroids = new ArrayList<Centroid>();
		int k = 0;

		try {
			//elimino le parentesi quadre
			centroidsGroupString = centroidsGroupString.substring(1, centroidsGroupString.length() - 1);

			String[] centroidString = centroidSeparator.split(centroidsGroupString);
			k = centroidString.length;

			for (int i = 0; i < k; i++) {
				String[] featureString = featureSeparator.split(centroidString[i]);

				double[] values = new double[featureString.length];

				for (int j = 0; j < featureString.length; j++) {
					double d = Double.parseDouble(featureString[j]);

					values[j] = d;
				}

				centroids.add(new Centroid(values));
			}
		} catch (NumberFormatException e) {
		}
		givenCentroids.put(k, centroids);
	}

	/*
	 * Controlla il formato delle proprieta' clusterTo e clusterFrom
	 *
	 * @param clusterFromString il valore della proprieta' clusterFrom
	 * @param clusterToString il valore dall proprieta' clusterTo
	 * @return true se il valore di entrambe le proprieta' e' un numero, false altrimenti
	 */
	private static boolean checkClusterFromTo(String clusterFromString, String clusterToString) {
		boolean result = true;

		try {
			if ((clusterFromString.equals("")) || (clusterToString.equals(""))) {
				result = false;
			} else {
				int fromInt = Integer.parseInt(clusterFromString);
				int toInt = Integer.parseInt(clusterToString);

				if ((fromInt <= toInt) && (fromInt >= 0) && (toInt >= 0)) {
					clusterFrom = fromInt;
					clusterTo = toInt;
				} else {
					result = false;
				}
			}
		} catch (NumberFormatException ex) {
			result = false;
		}

		return result;
	}

	/*
	 * Controlla il formato della proprieta' run
	 *
	 * @param runString il valore della proprieta'
	 * @return true se il valore della proprieta' e' un numero, false altrimenti
	 */
	private static boolean checkRun(String runString) {
		boolean result = true;

		try {
			if (runString.equals("")) {
				result = false;
			} else {
				int runInt = Integer.parseInt(runString);

				if (runInt > 0) {
					run = runInt;
				} else {
					result = false;
				}
			}
		} catch (NumberFormatException ex) {
			result = false;
		}

		return result;
	}

	/*
	 * Controlla il formato della proprieta' outputFormat
	 *
	 * @param outputFormatString il valore della proprieta'
	 * @return true
	 */
	private static boolean checkOutputFormat(String outputFormatString) {
		outputFormat = Boolean.parseBoolean(outputFormatString);

		return true;
	}
}
