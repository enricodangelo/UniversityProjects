/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package centroidSelection;

import data.Centroid;
import data.InputData;
import data.KMeansData;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public class GivenCentroidSelection implements ICentroidSelection {

	private final String description = "Utilizza i k punti specificati come centroidi iniziali";

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	@Override
	public boolean availableToGUI() {
		return false;
	}

	/*
	 * Indica se il metodo utilizza il subsampling. Viene utilizzato dall'interfaccia grafica
	 * per attivare o meno i controlli che permettono di indicare il numero e la dimensione
	 * dei subsampling
	 *
	 * @return true se la classe utilizza il subsampling, false altrimenti
	 */
	@Override
	public boolean needSubsampling() {
		return false;
	}

	/*
	 * Metodo di selezione dei centroidi iniziali che utilizza i centroidi che gli vengono
	 * forniti come input (in kmeansData)
	 *
	 * @param kmeansData l'input dell'algoritmo di clustering.
	 * @param k il numero di centroidi da scegliere
	 * @return la lista dei centroidi scelti
	 */
	@Override
	public ArrayList<Centroid> select(KMeansData kmeansData, int k) {
		InputData inputData = kmeansData.getInputData();
		return inputData.getGivenCentroids().get(k);
	}

}
