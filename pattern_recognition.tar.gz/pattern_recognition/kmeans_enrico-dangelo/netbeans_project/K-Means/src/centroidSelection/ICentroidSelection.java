/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package centroidSelection;

import data.Centroid;
import data.KMeansData;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public interface ICentroidSelection {

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	public String getDescription();

	/*
	 * Indica se il metodo utilizza il subsampling. Viene utilizzato dall'interfaccia grafica
	 * per attivare o meno i controlli che permettono di indicare il numero e la dimensione
	 * dei subsampling
	 *
	 * @return true se la classe utilizza il subsampling, false altrimenti
	 */
	public boolean needSubsampling();

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	public boolean availableToGUI();

	/*
	 * Metodo di selezione dei centroidi iniziali
	 *
	 * @param kmeansData l'input dell'algoritmo di clustering.
	 * @param k il numero di centroidi da scegliere
	 * @return la lista dei centroidi scelti
	 */
	public ArrayList<Centroid> select(KMeansData kmeansData, int k);
}
