/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package centroidSelection;

import algorithm.KMeansAlgorithm;
import algorithm.LloydNaiveAlgorithm;
import data.Centroid;
import data.Cluster;
import data.Dataset;
import data.InputData;
import data.KMeansData;
import data.ResultData;
import data.Point;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import metric.IMetric;

/**
 *
 * @author enrico
 */
public class RefinedCentroidSelection implements ICentroidSelection {

	private final String description = "Selezione dei centroidi iniziali tramite l'algoritmo k-means su subsamples del dataset";

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	@Override
	public boolean availableToGUI() {
		return true;
	}

	/*
	 * Indica se il metodo utilizza il subsampling. Viene utilizzato dall'interfaccia grafica
	 * per attivare o meno i controlli che permettono di indicare il numero e la dimensione
	 * dei subsampling
	 *
	 * @return true se la classe utilizza il subsampling, false altrimenti
	 */
	@Override
	public boolean needSubsampling() {
		return true;
	}

	/*
	 * Metodo di selezione dei centroidi iniziali secondo:
	 * "Refining Initial Points for K-Means Clustering"
	 * P. S. Bradley (Computer Sciences Department, University of Wisconsin)
	 * Usama M. Fayyad (Microsoft Research)
	 *
	 * @param kmeansData l'input dell'algoritmo di clustering.
	 * @param k il numero di centroidi da scegliere
	 * @return la lista dei centroidi scelti
	 */
	@Override
	public ArrayList<Centroid> select(KMeansData kmeansData, int k) {
		InputData inputData = kmeansData.getInputData();
		//IClusteringAlgorithm algorithm = kmeansData.getAlgorithm();
		ArrayList<Point> smoothSet = new ArrayList<Point>();
		ArrayList<ResultData> pt1Results = new ArrayList<ResultData>();
		ResultData bestResult = null;

		//per ogni subsample specificato
		for (int i = 0; i < inputData.getSubsamples(); i++) {
			ArrayList<ResultData> results;
			boolean goodResult = true;

			do {
				goodResult = true;

				ArrayList<Point> subsamplePoints = inputData.getDataset().subsample(inputData.getSubsampleSize());

				InputData subsampleData = new InputData(
						new Dataset("subsample-" + i, subsamplePoints, inputData.getDataset().getFeatures()),
						(IMetric) inputData.getMetric().clone(),
						inputData.getCriterion(),
						new RandomCentroidSelection(),
						k,
						k,
						1,
						inputData.getOutputFormat());

				//K-Means applicato al subsample
				results = new KMeansAlgorithm(new LloydNaiveAlgorithm()).calculate(subsampleData);


				// Controllo che nessun cluster sia vuoto, in caso eseguo nuovamente l'algoritmo
				for (Cluster cluster : results.get(0).getClusters()) {
					if (cluster.getPoints().size() == 0) {
						goodResult = false;
						break;	//in questo modo appena trova un cluster senza punti esegue subito l'algoritmo senza controlalre anche gli altri cluster
					}
				}
			} while (!goodResult);

			//result.size() deve essere 1 perche' l'algoritmo k-means viene eseguito con i parametri
			//clusterFrom e clusterTo uguali (cioe' il range e' 1)
			pt1Results.add(results.get(0));

			for (Cluster cluster : results.get(0).getClusters()) {
				smoothSet.add(cluster.getCentroid());
			}
		}

		//per ogni subsample specificato
		for (int i = 0; i < inputData.getSubsamples(); i++) {
			ResultData result = pt1Results.get(i);

			Map<Integer, ArrayList<Centroid>> givenCentroids = new Hashtable<Integer, ArrayList<Centroid>>();
			givenCentroids.put(k, result.getCentroids());

			InputData refinedSubsampleData = new InputData(
					new Dataset("smoothSet", smoothSet, k),
					(IMetric) inputData.getMetric().clone(),
					inputData.getCriterion(),
					new GivenCentroidSelection(),
					givenCentroids,
					k,
					k,
					1,
					inputData.getOutputFormat());

			//K-Means applicato al subsample "raffinato"
			ArrayList<ResultData> smoothResult = new KMeansAlgorithm(new LloydNaiveAlgorithm()).calculate(refinedSubsampleData);

			//smoothResult.size() deve essere 1 perche' l'algoritmo k-means viene eseguito con i parametri
			//clusterFrom e clusterTo uguali (cioe' il range e' 1)
			if (bestResult == null) {
				bestResult = smoothResult.get(0);
			} else {
				int resultIndex = inputData.getCriterion().getBest(smoothResult.get(0).getError(), bestResult.getError());
				if (resultIndex < 0) {
					bestResult = smoothResult.get(0);
				}
			}
		}

		return bestResult.getCentroids();
	}
}
