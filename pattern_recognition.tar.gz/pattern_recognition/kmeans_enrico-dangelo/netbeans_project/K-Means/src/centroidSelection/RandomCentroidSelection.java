/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package centroidSelection;

import data.Centroid;
import data.Dataset;
import data.InputData;
import data.KMeansData;
import data.Point;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;

/**
 *
 * @author enrico
 */
public class RandomCentroidSelection implements ICentroidSelection {

	private static final String description = "Selezione casuale di k punti come centroidi iniziali";

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	@Override
	public boolean availableToGUI() {
		return true;
	}

	/*
	 * Indica se il metodo utilizza il subsampling. Viene utilizzato dall'interfaccia grafica
	 * per attivare o meno i controlli che permettono di indicare il numero e la dimensione
	 * dei subsampling
	 *
	 * @return true se la classe utilizza il subsampling, false altrimenti
	 */
	@Override
	public boolean needSubsampling() {
		return false;
	}

	/*
	 * Metodo di selezione dei centroidi iniziali casuale secondo una disribuzione uniforme senza ripetizioni
	 *
	 * @param kmeansData l'input dell'algoritmo di clustering.
	 * @param k il numero di centroidi da scegliere
	 * @return la lista dei centroidi scelti
	 */
	@Override
	public ArrayList<Centroid> select(KMeansData kmeansData, int k) {
		InputData inputData = kmeansData.getInputData();
		Random generator = new Random();
		Collection<Integer> selectedIndexes = new ArrayList<Integer>();
		ArrayList<Centroid> selectedCentroids = new ArrayList<Centroid>();
		Dataset dataset = inputData.getDataset();
		int selectedIndex;
		Centroid centroid;

		if (k <= inputData.getDataset().getSize()) {
			for (int i = 0; i < k; i++) {

				do {
					selectedIndex = generator.nextInt(dataset.getSize());
					centroid = new Centroid(((Point) dataset.getPoints().get(selectedIndex).clone()).values);
				} while (selectedIndexes.contains(selectedIndex) || selectedCentroids.contains(centroid));

				selectedIndexes.add(selectedIndex);
				selectedCentroids.add(centroid);
			}
		} else {
			System.err.println("Impossibile selezionare i cenroidi iniziali. Dataset troppo piccolo.");
			System.exit(-1);
		}

		return selectedCentroids;
	}
}
