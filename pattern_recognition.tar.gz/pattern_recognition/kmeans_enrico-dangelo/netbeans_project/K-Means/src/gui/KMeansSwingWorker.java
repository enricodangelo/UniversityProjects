/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import data.KMeansData;
import data.ResultData;
import java.util.ArrayList;
import javax.swing.SwingWorker;

/**
 * Classe wrapper per poter invocare KMeans.calculate() all'interno di un thread
 * Serve per non bloccare l'interfaccia grafica mentre l'algoritmo viene eseguito,
 * in questo modo e' possibile vedere il grafico dell'errore aggiornarsi in tempo reale.
 * @author enrico
 */
public class KMeansSwingWorker extends SwingWorker<ArrayList<ResultData>, ResultData> {

	private KMeansData kmeansData;

	public void setKMeansData(KMeansData kmeansData) {
		this.kmeansData = kmeansData;
	}

	@Override
	public ArrayList<ResultData> doInBackground() throws Exception {
		//Eseguo l'algoritmo
		ArrayList<ResultData> results = kmeansData.getAlgorithm().calculate(kmeansData.getInputData());

		return results;
	}
}
