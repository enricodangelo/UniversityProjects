/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * NewKMeansGUI.java
 *
 * Created on May 11, 2009, 5:28:22 PM
 */
package gui;

import javax.swing.GroupLayout;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.WindowConstants;
import utils.KMeansConstants;

/**
 *
 * @author enrico
 */
public class KMeansGUI extends JFrame {

	private KMeansModel model;
	private JTabbedPane kmeansTabbedPane;
	private PropertiesPanel propertiesPanel;
	private ResultPanel resultPanel;
	private ReportPanel reportPanel;
	private KMeansActionListener actionListener;

	public KMeansGUI(KMeansModel model) {
		this.model = model;
		this.model.register(this);
		initComponents();
	}

	private void initComponents() {
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setTitle(KMeansConstants.GUI_NAME);

		actionListener = new KMeansActionListener(model);

		kmeansTabbedPane = new JTabbedPane();

		propertiesPanel = new PropertiesPanel(this);
		resultPanel = new ResultPanel(this);
		reportPanel = new ReportPanel(this);

		kmeansTabbedPane.addTab(KMeansConstants.PROPERTIES_PANEL_TITLE, propertiesPanel);
		kmeansTabbedPane.addTab(KMeansConstants.RESULTS_PANEL_TITLE, resultPanel);
		kmeansTabbedPane.addTab(KMeansConstants.REPORT_PANEL_TITLE, reportPanel);

		GroupLayout layout = new GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(kmeansTabbedPane, GroupLayout.DEFAULT_SIZE, 994, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(kmeansTabbedPane, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}

	public boolean needSubsampleOptionsVisibility() {
		return propertiesPanel.needSubsampleOptionsVisibility();
	}

	public KMeansActionListener getActionListener() {
		return actionListener;
	}

	public String getProperties() {
		return propertiesPanel.getProperties();
	}

	public void update() {
		propertiesPanel.update();
		resultPanel.update();
		reportPanel.update();
	}

	/**
	 * @return the model
	 */
	public KMeansModel getModel() {
		return model;
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				KMeansModel model = new KMeansModel();
				KMeansGUI gui = new KMeansGUI(model);
				gui.setVisible(true);
			}
		});
	}
}
