/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import data.KMeansData;
import data.ResultData;
import java.io.File;
import java.util.ArrayList;
import utils.TemporaryFilenameGenerator;

/**
 *
 * @author enrico
 */
public class KMeansModel {

	private KMeansGUI gui = null;
	private KMeansData kmeansData = null;
	private ArrayList<ResultData> results = null;
	private String datasetFilename = "";
	private File propertiesFile = new File(TemporaryFilenameGenerator.getTemporaryFilename());
	private boolean subsampleVisibility;

	public void register(KMeansGUI gui) {
		this.gui = gui;
	}

	/**
	 * @return the kmeansData
	 */
	public KMeansData getKmeansData() {
		return kmeansData;
	}

	/**
	 * @param kmeansData the kmeansData to set
	 */
	public void setKmeansData(KMeansData kmeansData) {
		this.kmeansData = kmeansData;
		datasetFilename = this.kmeansData.getInputData().getDataset().getName();

		gui.update();
	}

	/**
	 * @return the datasetFile
	 */
	public String getDatasetFilename() {
		return datasetFilename;
	}

	/**
	 * @param datasetFile the datasetFile to set
	 */
	public void setDatasetFilename(String datasetFilename) {
		this.datasetFilename = datasetFilename;

		gui.update();
	}

	/**
	 * @return the propertiesFile
	 */
	public File getPropertiesFile() {
		return propertiesFile;
	}

	/**
	 * @param propertiesFile the propertiesFile to set
	 */
	public void setPropertiesFile(File propertiesFile) {
		this.propertiesFile = propertiesFile;

		gui.update();
	}

	public boolean getSubsampleVisibility() {
		return subsampleVisibility;
	}

	public void setSubsampleVisibility() {
		this.subsampleVisibility = gui.needSubsampleOptionsVisibility();

		gui.update();
	}

	public void setSubsampleVisibility(boolean subsampleVisibility) {
		this.subsampleVisibility = subsampleVisibility;
	}

	public void setResults(ArrayList<ResultData> results) {
		this.results = results;

		gui.update();
	}

	public ArrayList<ResultData> getResults() {
		return results;
	}

	public String getProperties() {
		return gui.getProperties();
	}
}
