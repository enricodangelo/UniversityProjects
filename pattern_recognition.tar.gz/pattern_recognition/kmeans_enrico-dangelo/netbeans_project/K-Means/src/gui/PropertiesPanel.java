/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import algorithm.IClusteringAlgorithm;
import centroidSelection.ICentroidSelection;
import data.InputData;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.GroupLayout;
import javax.swing.JComboBox;
import javax.swing.LayoutStyle;
import javax.swing.SpinnerNumberModel;
import utils.ClassDiscover;
import utils.KMeansConstants;

/**
 *
 * @author enrico
 */
public class PropertiesPanel extends JPanel {
	private ClassDiscover classDiscover = new ClassDiscover();

	private KMeansGUI parent;
	private JComboBox algorithmComboBox;
	private JLabel algorithmLabel;
	private JComboBox centroidsUpdaterComboBox;
	private JLabel centroidsUpdaterLabel;
	private JComboBox centroidComboBox;
	private JLabel centroidLabel;
	private JComboBox criterionComboBox;
	private JLabel criterionLabel;
	private JButton datasetButton;
	private JLabel datasetLabel;
	private JLabel datasetDimensionLabel;
	private JLabel datasetFeaturesLabel;
	private JTextField datasetTextField;
	private JTextField datasetDimensionTextField;
	private JTextField datasetFeaturesTextField;
	private JButton loadButton;
	private JComboBox metricComboBox;
	private JLabel metricLabel;
	private JButton okButton;
	private JTextField rangeFromTextField;
	private JLabel rangeLabel1;
	private JLabel rangeLabel2;
	private JTextField rangeToTextField;
	private JLabel runLabel;
	private JTextField runTextField;
	private JButton saveButton;
	private JLabel subsampleLabel;
	private JLabel subsampleSizeLabel1;
	private JLabel subsampleSizeLabel2;
	private JSpinner subsampleSizeSpinner;
	private JTextField subsampleTextField;
//	private Map<String, String> algorithmsList = ClassDiscover.discover(KMeansConstants.ALGORITHM_INTERFACE, KMeansConstants.ALGORITHM_PACKAGE);
//	private Map<String, String> centroidsUpdaterList = ClassDiscover.discover(KMeansConstants.CENTROIDUPDATER_INTERFACE, KMeansConstants.CENTROIDUPDATER_PACKAGE);
//	private Map<String, String> criteriaList = ClassDiscover.discover(KMeansConstants.CRITERIA_INTERFACE, KMeansConstants.CRITERIA_PACKAGE);
//	private Map<String, String> metricList = ClassDiscover.discover(KMeansConstants.METRICS_INTERFACE, KMeansConstants.METRIC_PACKAGE);
//	private Map<String, String> centroidList = ClassDiscover.discover(KMeansConstants.CENTROIDSELECTION_INTERFACE, KMeansConstants.CENTROIDSELECTION_PACKAGE);
	private Map<String, String> algorithmsList = classDiscover.getMap(KMeansConstants.ALGORITHMS_LIST);
	private Map<String, String> centroidsUpdaterList = classDiscover.getMap(KMeansConstants.CENTROIDSUPDATER_LIST);
	private Map<String, String> criteriaList = classDiscover.getMap(KMeansConstants.CRITERIA_LIST);
	private Map<String, String> metricList = classDiscover.getMap(KMeansConstants.METRICS_LIST);
	private Map<String, String> centroidList = classDiscover.getMap(KMeansConstants.CENTROID_LIST);
	private boolean updating = false;

    public PropertiesPanel(KMeansGUI parent) {
        this.parent = parent;
        initComponents();
    }

    public void initComponents() {
        datasetLabel = new JLabel();
        datasetTextField = new JTextField();
        datasetDimensionTextField = new JTextField();
        datasetFeaturesTextField = new JTextField();
        datasetButton = new JButton();
        datasetDimensionLabel = new JLabel();
        datasetFeaturesLabel = new JLabel();
        algorithmLabel = new JLabel();
        centroidsUpdaterLabel = new JLabel();
        metricLabel = new JLabel();
        criterionLabel = new JLabel();
        centroidLabel = new JLabel();
        algorithmComboBox = new JComboBox();
        centroidsUpdaterComboBox = new JComboBox();
        criterionComboBox = new JComboBox();
        metricComboBox = new JComboBox();
        centroidComboBox = new JComboBox();
        rangeLabel1 = new JLabel();
        rangeFromTextField = new JTextField();
        rangeLabel2 = new JLabel();
        rangeToTextField = new JTextField();
        runLabel = new JLabel();
        runTextField = new JTextField();
        subsampleSizeLabel1 = new JLabel();
        subsampleSizeSpinner = new JSpinner();
        subsampleSizeLabel2 = new JLabel();
        loadButton = new JButton();
        saveButton = new JButton();
        okButton = new JButton();
        subsampleLabel = new JLabel();
        subsampleTextField = new JTextField();
        datasetLabel.setText("Dataset: ");
        datasetDimensionLabel.setText("Dimensione del dataset: ");
        datasetFeaturesLabel.setText("Numero di features: ");
        datasetTextField.setColumns(40);
        datasetTextField.setEditable(false);
        datasetDimensionTextField.setColumns(15);
        datasetDimensionTextField.setEditable(false);
        datasetFeaturesTextField.setColumns(5);
        datasetFeaturesTextField.setEditable(false);
        datasetButton.setText(KMeansConstants.CHOOSE_DATASET_BUTTON_LABEL);
        datasetButton.addActionListener(parent.getActionListener());
        algorithmLabel.setText("Algoritmo di clustering: ");
        centroidsUpdaterLabel.setText("Algoritmo per l'aggiornamento dei centroidi");
        metricLabel.setText("Metrica: ");
        criterionLabel.setText("Criterio: ");
        centroidLabel.setText("Scelta dei primi centroidi: ");
        algorithmComboBox.setModel(new DefaultComboBoxModel(algorithmsList.keySet().toArray()));
        centroidsUpdaterComboBox.setModel(new DefaultComboBoxModel(centroidsUpdaterList.keySet().toArray()));
        criterionComboBox.setModel(new DefaultComboBoxModel(criteriaList.keySet().toArray()));
        metricComboBox.setModel(new DefaultComboBoxModel(metricList.keySet().toArray()));
        centroidComboBox.setModel(new DefaultComboBoxModel(centroidList.keySet().toArray()));
        centroidComboBox.addActionListener(parent.getActionListener());
        rangeLabel1.setText("Range di cluster da testare: ");
        rangeFromTextField.setColumns(4);
        rangeFromTextField.setPreferredSize(new java.awt.Dimension(48, 19));
        rangeLabel2.setText("-");
        rangeToTextField.setPreferredSize(new java.awt.Dimension(48, 19));
        runLabel.setText("Run: ");
        runTextField.setPreferredSize(new java.awt.Dimension(48, 19));
        subsampleSizeLabel1.setText("Dimensione del Subsample: ");
        subsampleSizeSpinner.setModel(new SpinnerNumberModel(10, 0, 100, 1));
        subsampleSizeLabel2.setText("%");
        loadButton.setText(KMeansConstants.LOAD_BUTTON_LABEL);
        loadButton.addActionListener(parent.getActionListener());
        saveButton.setText(KMeansConstants.SAVE_BUTTON_LABEL);
        saveButton.setMaximumSize(new java.awt.Dimension(214, 1));
        saveButton.setMinimumSize(new java.awt.Dimension(214, 1));
        saveButton.addActionListener(parent.getActionListener());
        okButton.setText(KMeansConstants.OK_BUTTON_LABEL);
        okButton.addActionListener(parent.getActionListener());
        subsampleLabel.setText("Numero di Subsamples:");
        parent.getModel().setSubsampleVisibility(needSubsampleOptionsVisibility());

        GroupLayout propertiesPanelLayout = new GroupLayout(this);
        setLayout(propertiesPanelLayout);

        propertiesPanelLayout.setHorizontalGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(propertiesPanelLayout.createSequentialGroup().addContainerGap().addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(saveButton, GroupLayout.PREFERRED_SIZE, 235, GroupLayout.PREFERRED_SIZE).addGap(18, 18, 18).addComponent(loadButton, GroupLayout.PREFERRED_SIZE, 244, GroupLayout.PREFERRED_SIZE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(datasetLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(datasetTextField, GroupLayout.DEFAULT_SIZE, 745, Short.MAX_VALUE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(datasetButton)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(datasetDimensionLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(datasetDimensionTextField, GroupLayout.DEFAULT_SIZE, 745, Short.MAX_VALUE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(datasetFeaturesLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(datasetFeaturesTextField, GroupLayout.DEFAULT_SIZE, 745, Short.MAX_VALUE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(algorithmLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(algorithmComboBox, 0, 891, Short.MAX_VALUE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(centroidsUpdaterLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(centroidsUpdaterComboBox, 0, 891, Short.MAX_VALUE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(criterionLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(criterionComboBox, 0, 891, Short.MAX_VALUE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(centroidLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(centroidComboBox, 0, 891, Short.MAX_VALUE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(metricLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(metricComboBox, 0, 891, Short.MAX_VALUE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(subsampleLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(subsampleTextField, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(subsampleSizeLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(subsampleSizeSpinner, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(subsampleSizeLabel2)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(rangeLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(rangeFromTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(rangeLabel2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(rangeToTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)).addGroup(propertiesPanelLayout.createSequentialGroup().addComponent(runLabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(runTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))).addContainerGap()).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, propertiesPanelLayout.createSequentialGroup().addContainerGap(855, Short.MAX_VALUE).addComponent(okButton, GroupLayout.PREFERRED_SIZE, 122, GroupLayout.PREFERRED_SIZE).addContainerGap())));
        propertiesPanelLayout.setVerticalGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, propertiesPanelLayout.createSequentialGroup().addContainerGap().addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(datasetLabel).addComponent(datasetTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addComponent(datasetButton)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(datasetDimensionLabel).addComponent(datasetDimensionTextField)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(datasetFeaturesLabel).addComponent(datasetFeaturesTextField)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(algorithmComboBox).addComponent(algorithmLabel)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(centroidsUpdaterComboBox).addComponent(centroidsUpdaterLabel)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(criterionComboBox).addComponent(criterionLabel)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(metricLabel).addComponent(metricComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(centroidComboBox).addComponent(centroidLabel)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(subsampleLabel).addComponent(subsampleTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(subsampleSizeLabel1).addComponent(subsampleSizeSpinner, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addComponent(subsampleSizeLabel2)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(rangeFromTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addComponent(rangeLabel2).addComponent(rangeToTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addComponent(rangeLabel1)).addGap(18, 18, 18).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(runLabel).addComponent(runTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 264, Short.MAX_VALUE).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(loadButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE).addComponent(saveButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)).addContainerGap()).addGroup(propertiesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, propertiesPanelLayout.createSequentialGroup().addContainerGap(569, Short.MAX_VALUE).addComponent(okButton).addContainerGap())));
    }

    protected String getProperties() {
        String propertiesDatasetFileName = parent.getModel().getDatasetFilename();
        String propertiesAlgorithm = (String) algorithmsList.get(algorithmComboBox.getSelectedItem());
        String propertiesCentroidsUpdater = (String) centroidsUpdaterList.get(centroidsUpdaterComboBox.getSelectedItem());
        String propertiesMetric = (String) metricList.get(metricComboBox.getSelectedItem());
        String propertiesCriterion = (String) criteriaList.get(criterionComboBox.getSelectedItem());
        String propertiesCentroidSelection = (String) centroidList.get(centroidComboBox.getSelectedItem());
        String propertiesSubsamples = (String) subsampleTextField.getText();
        String propertiesSubsampleSize = (String) subsampleSizeSpinner.getValue().toString();
        String clusterFrom = rangeFromTextField.getText();
        String clusterTo = rangeToTextField.getText();
        String run = runTextField.getText();

        String properties =
                KMeansConstants.DATASET_KEY + "=" + propertiesDatasetFileName.replace("\\", "/") + "\n" +
                KMeansConstants.ALGORITHM_KEY + "=" + propertiesAlgorithm + "\n" +
                KMeansConstants.CENTROIDUPDATER_KEY + "=" + propertiesCentroidsUpdater + "\n" +
                KMeansConstants.METRIC_KEY + "=" + propertiesMetric + "\n" +
                KMeansConstants.CRITERION_KEY + "=" + propertiesCriterion + "\n" +
                KMeansConstants.CENTROIDSELECTION_KEY + "=" + propertiesCentroidSelection + "\n" +
                KMeansConstants.SUBSAMPLES_KEY + "=" + propertiesSubsamples + "\n" +
                KMeansConstants.SUBSAMPLESSIZE_KEY + "=" + propertiesSubsampleSize + "\n" +
                KMeansConstants.CLUSTERFROM_KEY + "=" + clusterFrom + "\n" +
                KMeansConstants.CLUSTERTO_KEY + "=" + clusterTo + "\n" +
                KMeansConstants.RUN_KEY + "=" + run + "\n";

        return properties;
    }

    public boolean needSubsampleOptionsVisibility() {
        String selectedClass = (String) centroidList.get((String) centroidComboBox.getSelectedItem());
        ICentroidSelection centroidSelectionclass = null;
        
        try {
            try {
                centroidSelectionclass = (ICentroidSelection) Class.forName(selectedClass).newInstance();
            } catch (InstantiationException ex) {
                Logger.getLogger(PropertiesPanel.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(PropertiesPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PropertiesPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return centroidSelectionclass.needSubsampling();
    }

    public void update() {
        if (!updating) {
            updating = true;

            if (parent.getModel().getKmeansData() != null) {
                IClusteringAlgorithm algorithm = parent.getModel().getKmeansData().getAlgorithm();
                InputData inputData = parent.getModel().getKmeansData().getInputData();

                //il nome del dataset lo prende da datasetFilename in KMeansModel
                datasetTextField.setText(parent.getModel().getDatasetFilename());
                //se il dataset in kmeansData e quello in datasetFilename non coincidono significa che e' stato scelto un
                //dataset diverso dal menu. Quello attualmente scelto e' quello indicato da datasetFilename percio'
                //bisogna resettare i valori visualizzati della dimensione del dataset e delle features perche'
                //si rifetiscono al dataset indicato in kmeansData
                if (parent.getModel().getDatasetFilename().equals(inputData.getDataset().getName())) {
                    datasetDimensionTextField.setText(inputData.getDataset().getSize() + "");
                    datasetFeaturesTextField.setText(inputData.getDataset().getFeatures() + "");
                } else {
                    datasetDimensionTextField.setText("");
                    datasetFeaturesTextField.setText("");
                }
                parent.getModel().setDatasetFilename(datasetTextField.getText());
                for (Entry<String, String> algorithmEntry : algorithmsList.entrySet()) {
                    if (algorithmEntry.getValue().contains(algorithm.getClass().getSimpleName())) {
                        algorithmComboBox.setSelectedItem(algorithmEntry.getKey());
                    }
                }
                for (Entry<String, String> centroidsUpdaterEntry : centroidsUpdaterList.entrySet()) {
                    if (centroidsUpdaterEntry.getValue().contains(algorithm.getCentroidsUpdaterAlgorithm().getClass().getSimpleName())) {
                        centroidsUpdaterComboBox.setSelectedItem(centroidsUpdaterEntry.getKey());
                    }
                }
                for (Entry<String, String> criterionEntry : criteriaList.entrySet()) {
                    if (criterionEntry.getValue().contains(inputData.getCriterion().getClass().getSimpleName())) {
                        criterionComboBox.setSelectedItem(criterionEntry.getKey());
                    }
                }
                for (Entry<String, String> metricEntry : metricList.entrySet()) {
                    if (metricEntry.getValue().contains(inputData.getMetric().getClass().getSimpleName())) {
                        metricComboBox.setSelectedItem(metricEntry.getKey());
                    }
                }
                for (Entry<String, String> centroidEntry : centroidList.entrySet()) {
                    if (centroidEntry.getValue().contains(inputData.getCentroidSelection().getClass().getSimpleName())) {
                        centroidComboBox.setSelectedItem(centroidEntry.getKey());
                    }
                }
                subsampleTextField.setText(Integer.toString(inputData.getSubsamples()));
                subsampleSizeSpinner.setValue(inputData.getSubsampleSize());
                rangeFromTextField.setText(Integer.toString(inputData.getClusterFrom()));
                rangeToTextField.setText(Integer.toString(inputData.getClusterTo()));
                runTextField.setText(Integer.toString(inputData.getRun()));
            } else {
                if (parent.getModel().getDatasetFilename() != null) {
                    datasetTextField.setText(parent.getModel().getDatasetFilename());
                }
            }

            if (parent.getModel().getSubsampleVisibility()) {
                subsampleLabel.setEnabled(true);
                subsampleTextField.setEnabled(true);
                subsampleSizeLabel1.setEnabled(true);
                subsampleSizeSpinner.setEnabled(true);
                subsampleSizeLabel2.setEnabled(true);
            } else {
                subsampleLabel.setEnabled(false);
                subsampleTextField.setEnabled(false);
                subsampleSizeLabel1.setEnabled(false);
                subsampleSizeSpinner.setEnabled(false);
                subsampleSizeLabel2.setEnabled(false);
            }

            updating = false;
        }
    }
}
