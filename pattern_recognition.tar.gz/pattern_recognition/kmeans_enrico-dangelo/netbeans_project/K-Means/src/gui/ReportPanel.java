/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import utils.DataReporter;
import data.KMeansData;
import data.ResultData;
import java.awt.BorderLayout;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import utils.KMeansConstants;

/**
 *
 * @author enrico
 */
public class ReportPanel extends JPanel {

	private KMeansGUI parent;
	private String inputInfo;
	private String outputInfo;
	private JTextArea reportTextArea;
	private JScrollPane reportScrollPane;

	public ReportPanel(KMeansGUI parent) {
		this.parent = parent;
		initComponents();
	}

	public void initComponents() {
		reportTextArea = new JTextArea();
		reportScrollPane = new JScrollPane(reportTextArea);

		reportTextArea.setEditable(false);

		BorderLayout reportPanelLayout = new BorderLayout();
		reportPanelLayout.addLayoutComponent(reportScrollPane, BorderLayout.CENTER);
		setLayout(reportPanelLayout);

		add(reportScrollPane);
	}

	public void update() {
		KMeansData kmeansData = parent.getModel().getKmeansData();
		ArrayList<ResultData> results = parent.getModel().getResults();

		if (kmeansData != null) {
			inputInfo = DataReporter.reportInput(KMeansConstants.READABLE, kmeansData);
		} else {
			inputInfo = "";
		}

		if (results != null) {
			outputInfo = DataReporter.reportOutput(KMeansConstants.READABLE, results);
		} else {
			outputInfo = "";
		}

		reportTextArea.setText(inputInfo + "\n" + outputInfo);
	}
}
