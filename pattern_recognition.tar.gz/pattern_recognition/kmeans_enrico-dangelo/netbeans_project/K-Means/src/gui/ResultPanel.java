/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import data.ResultData;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.GroupLayout;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataItem;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import utils.KMeansConstants;

/**
 *
 * @author enrico
 */
public class ResultPanel extends JSplitPane {

	KMeansGUI parent;
	XYSeries chartDataset = new XYSeries(new Double(0));
	JFreeChart errorChart;
	ChartPanel errorChartPanel;
	JScrollPane resultScrollPane;
	DefaultTableModel tableModel;
	JTable resultTable;

	public ResultPanel(KMeansGUI parent) {
		this.parent = parent;
		initComponents();
	}

	public void initComponents() {
		errorChart = ChartFactory.createXYLineChart(
				KMeansConstants.CHART_TITLE,
				KMeansConstants.CHART_X_AXIS_LABEL,
				KMeansConstants.CHART_Y_AXIS_LABEL,
				new XYSeriesCollection(chartDataset),
				PlotOrientation.VERTICAL,
				false,
				true,
				false);

		errorChart.setAntiAlias(true);
		errorChart.setTextAntiAlias(true);

		errorChartPanel = new ChartPanel(errorChart);

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		renderer.setSeriesLinesVisible(0, true);
		renderer.setSeriesShapesVisible(0, true);

		XYPlot plot = (XYPlot) errorChart.getPlot();
		plot.setRenderer(renderer);

		tableModel = new DefaultTableModel(
				new Object[][]{},
				new String[]{
					"Numero di cluster", "Errore", "Numero di iterazioni", "Numero di confronti", "Tempo di un run (ms)", "Wallclock time (ms)"
				}) {

			Class[] types = new Class[]{
				java.lang.Integer.class,
				java.lang.Double.class,
				java.lang.Integer.class,
				java.lang.Long.class,
				java.lang.Long.class,
				java.lang.Long.class
			};
			boolean[] canEdit = new boolean[]{
				false, false, false, false, false, false
			};

			@Override
			public Class getColumnClass(int columnIndex) {
				return types[columnIndex];
			}

			@Override
			public boolean isCellEditable(int rowIndex, int columnIndex) {
				return canEdit[columnIndex];
			}
		};

		resultTable = new JTable(tableModel);

		resultScrollPane = new JScrollPane(resultTable);

		GroupLayout resultPanelLayout = new GroupLayout(this);
		setLayout(resultPanelLayout);

		setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
		//setDividerLocation((1/4) * 3);
		setDividerLocation(600);
		setTopComponent(errorChartPanel);
		setBottomComponent(resultScrollPane);
	}

	public void update() {
		ArrayList<ResultData> results = parent.getModel().getResults();

		if (results != null) {
			//Azzera il grafico e la tabella
			chartDataset.clear();
			while (tableModel.getRowCount() != 0) {
				tableModel.removeRow(0);
			}

			//Aggiorno il grafico dell'errore e la tabella di output
			for (ResultData result : results) {
				chartDataset.add(new XYDataItem(result.getClusters().size(),result.getError()));

				Vector row = new Vector();
				row.add(result.getClusters().size());
				row.add(result.getError());
				row.add(result.getIterations());
				row.add(result.getNumberOfComparisons());
				row.add(result.getRunTime());
				row.add(result.getWallclockTime());
				tableModel.addRow(row);
			}
		}
	}
}
