/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import data.Centroid;
import data.Dataset;
import data.InputData;
import data.Point;
import java.util.ArrayList;
import utils.KMeansConstants;

/**
 *
 * @author enrico
 */
public class LloydNaiveAlgorithm implements ICentroidsUpdaterAlgorithm {

	private String description = "Implementazione naive dell'algoritmo di K-Means (Lloyd's Algorithm)";

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	@Override
	public boolean availableToGUI() {
		return true;
	}

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/*
	 * Algoritmo per l'aggiornamento dei centroidi
	 *
	 * @param inputData l'input dell'algoritmo di clustering
	 * @param centroids i centroidi attuali
	 *
	 * Questo metodo implementa l'algoritmo naive. Confronta la distanza tra ogni punto e ogni centroidi,
	 * poi sceglie il centroide a distanza minore
	 */
	@Override
	public void update(InputData inputData, ArrayList<Centroid> centroids) {
		Dataset dataset = inputData.getDataset();
		int datasetSize = dataset.getPoints().size();

		//per ogni elemento del dataset
		for (int i = 0; i < datasetSize; i++) {
			Point point = dataset.getPoints().get(i);
			double minDistance = Double.MAX_VALUE;
			Centroid nearestCentroid = null;

			//confronta la distanza dal centroide di ogni cluster
			for (Centroid centroid : centroids) {
				double distance = inputData.getMetric().distance(centroid, point, KMeansConstants.COLLECT_STATISTICS);

				//ricorda la distanza minima trovata fin'ora
				if (distance < minDistance) {
					minDistance = distance;
					nearestCentroid = centroid;
				}
			}

			//assegna l'elemento al cluster a lui piu' vicino
			//Automaticamente modifica la variabile changed del vecchio cluster cui il punto apparteneva e di quello nuovo (solo se diverso)
			nearestCentroid.getCluster().add(dataset.getPoints().get(i));
		}
	}
}
