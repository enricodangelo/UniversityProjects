/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import data.InputData;
import data.ResultData;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public interface IClusteringAlgorithm {

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	public String getDescription();

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	public boolean availableToGUI();

	/*
	 * Ritorna l'algoritmo utilizzato per l'aggiornamento dei centroidi
	 *
	 * @return l'algoritmo utilizzato per l'aggiornamento dei centroidi
	 */
	public ICentroidsUpdaterAlgorithm getCentroidsUpdaterAlgorithm();

	/*
	 * Esegue l'algoritmo di clustering
	 *
	 * @param inputData l'input dell'algoritmo
	 * @return il risultato della classificazione
	 */
	public ArrayList<ResultData> calculate(InputData inputData);
}
