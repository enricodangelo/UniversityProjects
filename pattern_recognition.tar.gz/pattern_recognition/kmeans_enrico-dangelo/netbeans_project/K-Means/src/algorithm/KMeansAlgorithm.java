/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import centroidSelection.ICentroidSelection;
import criterion.ICriterion;
import data.Centroid;
import data.Cluster;
import data.InputData;
import data.KMeansData;
import data.ResultData;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public class KMeansAlgorithm implements IClusteringAlgorithm {

	private ICentroidsUpdaterAlgorithm centroidUpdater;
	private final String description = "Algoritmo K-Means.";

	/*
	 *
	 */
	public KMeansAlgorithm() {
	}

	/*
	 *
	 */
	public KMeansAlgorithm(ICentroidsUpdaterAlgorithm centroidUpdater) {
		this.centroidUpdater = centroidUpdater;
	}

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	@Override
	public boolean availableToGUI() {
		return true;
	}

	/*
	 * Ritorna l'algoritmo utilizzato per l'aggiornamento dei centroidi
	 *
	 * @return l'algoritmo utilizzato per l'aggiornamento dei centroidi
	 */
	@Override
	public ICentroidsUpdaterAlgorithm getCentroidsUpdaterAlgorithm() {
		return centroidUpdater;
	}

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/*
	 * Esegue l'algoritmo di clustering
	 *
	 * @param inputData l'input dell'algoritmo
	 * @return il risultato della classificazione
	 */
	@Override
	public ArrayList<ResultData> calculate(InputData inputData) {
		ArrayList<Cluster> clusters;
		ArrayList<Centroid> centroids;
		int clusterFrom = inputData.getClusterFrom();
		int clusterTo = inputData.getClusterTo();
		int run = inputData.getRun();
		ICentroidSelection centroidSeection = inputData.getCentroidSelection();
		ICriterion criterion = inputData.getCriterion();

		ArrayList<ResultData> results = new ArrayList<ResultData>();

		//Per ogni numero di cluster da provare
		for (int k = clusterFrom; k <= clusterTo; k++) {
			//Prendo il tempo all'inizio dell'algoritmo
			long wallClockStartTime = System.currentTimeMillis();

			ResultData bestResult = null;

			//Per ogni run da fare
			for (int i = 1; i <= run; i++) {
				//Prendo il tempo all'inizio del run
				long runStartTime = System.currentTimeMillis();

				//Scelgo i centroidi per questo run
				centroids = centroidSeection.select(new KMeansData(this, inputData), k);

				clusters = new ArrayList<Cluster>();
				for (Centroid centroid : centroids) {
					clusters.add(new Cluster(centroid));
				}

				//Lancio l'algoritmo kmeans
				ResultData currentResult = algorithm(inputData, centroids, clusters);

				//Prendo il tempo alla fine del run
				long runStopTime = System.currentTimeMillis();

				//Memorizzo il tempo impiegato per il run
				currentResult.setBestRunTime(runStopTime - runStartTime);

				//Tengo traccia dell'errore minore
				if (bestResult == null) {
					bestResult = currentResult;
				} else {
					int resultIndex = criterion.getBest(currentResult.getError(), bestResult.getError());
					if (resultIndex < 0) {
						bestResult = currentResult;
					}
				}
			}
			//Prendo il tempo alla fine dell'algoritmo
			long wallClockStopTime = System.currentTimeMillis();

			//Memorizzo il tempo impiegato per l'algoritmo
			bestResult.setWallClockTime(wallClockStopTime - wallClockStartTime);

			results.add(bestResult);
		}

		return results;
	}

	/*
	 *
	 */
	private ResultData algorithm(InputData inputData, ArrayList<Centroid> centroids, ArrayList<Cluster> clusters) {
		boolean converged = true;
		int iterations = 0;	//numero di iterazioni eseguite

		//azzero il contatore del numero di confronti effettuati
		inputData.getMetric().resetNumberOfComparisons();

		//finche' gli elementi del dataset cambiano il cluster di appartenenza
		do {
			iterations++;
			converged = true;

			// il metodo update() e' implementato dai 2 algoritmi
			centroidUpdater.update(inputData, centroids);

			//Aggiorna la media dei cluster modificati durante l'ultima iretazione
			for (Cluster cluster : clusters) {
				if (cluster.isChanged()) {
					cluster.updateMean();
					converged = false;
				}
			}
		} while (!converged);	//Cicla finch'e' l'algoritmo non converge

		double error = inputData.getCriterion().computeError(clusters, inputData.getMetric());

		return new ResultData(error, iterations, inputData.getMetric().getNumberOfComparisons(), clusters, centroids);
	}
}
