/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import data.Centroid;
import data.InputData;
import data.kdtree.KDNode;
import data.kdtree.KDTree;
import data.Point;
import java.util.ArrayList;
import metric.IMetric;
import utils.KMeansConstants;

/**
 *
 * @author enrico
 */
public class EfficientAlgorithm implements ICentroidsUpdaterAlgorithm {

	private String description = "Implementazione efficiente dell'algoritmo K-Means tramite l'uso di kd-tree";

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	@Override
	public boolean availableToGUI() {
		return true;
	}

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/*
	 * Algoritmo per l'aggiornamento dei centroidi
	 *
	 * @param inputData l'input dell'algoritmo di clustering
	 * @param centroids i centroidi attuali
	 *
	 * questo metodo implementa l'algoritmo per aggiornare i centroidi con blacklist presentato in:
	 * "Accelerating Exact k-means Algorithms with Geometric Reasoning"
	 * Dan Pelleg and Andrew Moore
	 * School of Computer Science, Carnegie Mellon University
	 */
	@Override
	public void update(InputData inputData, ArrayList<Centroid> centroids) {
		if (inputData.getDataset().getKDTree() == null) {
			inputData.getDataset().generateKDTree();
		}
		update(inputData.getDataset().getKDTree(), centroids, inputData.getMetric());
	}

	/*
	 * Esattamente il metodo descritto sopra
	 */
	private void update(KDTree tree, ArrayList<Centroid> centroids, IMetric metric) {
		KDNode node = tree.getNode();
		ArrayList<Centroid> validCentroids = new ArrayList<Centroid>();

		if (node.type == KDNode.Type.LEAF) {
			// genero un kd-tree per i centroidi
			KDTree centroidsTree = new KDTree(centroids.toArray(new Point[0]));

			// calcolo il centroide piu' vicino al punto contenuto nella foglia del kd-tree
			Centroid nearestCentroid = (Centroid) centroidsTree.nearestNeighbour(node.points.get(0), metric);

			// assegno il punto al centroide piu' vicino
			node.setOwnerPoint(nearestCentroid);

			return;
		} else {
			Centroid nearestCentroid = null;
			double shortestDistance = Double.MAX_VALUE;
			boolean nearestCentroidExists = true;
			for (int i = 0; i < centroids.size(); i++) {
				Centroid currentCentroid = centroids.get(i);
				Point nearestPointInH = node.getNearestPoint(currentCentroid);
				double currentDistance = metric.distance(currentCentroid, nearestPointInH, KMeansConstants.COLLECT_STATISTICS);

				if (currentDistance < shortestDistance) {
					nearestCentroid = currentCentroid;
					shortestDistance = currentDistance;
					nearestCentroidExists = true;
				} else if (currentDistance == shortestDistance) {
					nearestCentroidExists = false;
				}
			}
			if (nearestCentroidExists) {
				validCentroids.add(nearestCentroid);

				for (int j = 0; j < centroids.size(); j++) {
					if (!nearestCentroid.equals(centroids.get(j))) {
						Centroid centroidJ = centroids.get(j);

						Point p = node.getExtremePoint(nearestCentroid, centroidJ);

						double distanceFromNearestCentroid = metric.distance(p, nearestCentroid, KMeansConstants.COLLECT_STATISTICS);
						double distanceFromCentroidJ = metric.distance(p, centroidJ, KMeansConstants.COLLECT_STATISTICS);

						if (distanceFromCentroidJ < distanceFromNearestCentroid) {
							// aggiungo il centroide alla lista dei centroidi da passare alla chiamata ricorsiva
							validCentroids.add(centroidJ);
						}
					}
				}

				if (validCentroids.size() == 1) {
					node.setOwnerPoint(nearestCentroid);
					return;
				}
			} else {
				// se non esiste un centroid con distanza minima da h devo passare tutti i centroidi alle chiamate ricorsive
				for (Centroid centroid : centroids) {
					validCentroids.add(centroid);
				}
			}

			// chiamata ricorsiva con blacklist dei centroidi (sono stati eliminati i centroidi che sicuramente non domineranno i sottonodi)
			if (tree.getLeftChild() != null) {
				update(tree.getLeftChild(), validCentroids, metric);
			}
			if (tree.getRightChild() != null) {
				update(tree.getRightChild(), validCentroids, metric);
			}
		}
	}
}
