/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import data.Centroid;
import data.InputData;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public interface ICentroidsUpdaterAlgorithm {

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	public boolean availableToGUI();

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	public String getDescription();

	/*
	 * Algoritmo per l'aggiornamento dei centroidi
	 *
	 * @param inputData l'input dell'algoritmo di clustering
	 * @param centroids i centroidi attuali
	 */
	public void update(InputData inputData, ArrayList<Centroid> centroids);
}
