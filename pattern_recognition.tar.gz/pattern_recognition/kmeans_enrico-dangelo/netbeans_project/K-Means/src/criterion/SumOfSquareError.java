/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package criterion;

import data.Cluster;
import data.Point;
import data.ResultData;
import java.util.Collection;
import metric.IMetric;
import utils.KMeansConstants;

/**
 *
 * @author enrico
 */
public class SumOfSquareError implements ICriterion {

	private final String description = "Somma delle Distanze Intraclasse al quadrato";

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	@Override
	public boolean availableToGUI() {
		return true;
	}

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/*
	 * Calcola l'errore
	 *
	 * @param clusters i cluster, con i loro centroidi e i punti assegnatigli
	 * @param metric la metrica da utilizzare
	 * @return l'errore
	 */
	@Override
	public double computeError(Collection<Cluster> clusters, IMetric metric) {
		double tmp = 0;

		for (Cluster cluster : clusters) {
			for (Point point : cluster.getPoints()) {
				
				tmp += metric.distance(point, cluster.getCentroid(), KMeansConstants.DONT_COLLECT_STATISTICS);
			}
		}
		
		return tmp;
	}

	/*
	 * Restituisce il risultato con l'errore minore assumendo che l'errore
	 * sia stato calcolato in entrambi con la stessa funzione criterio
	 *
	 * @param error1 il primo errore
	 * @param error2 il secondo errore
	 * @return 0 se sono uguali, un numero < 0 se error1 e' migliore di error2, un numero > 0 altrimenti
	 */
	@Override
	public int getBest(double error1, double error2) {
		if (error1 < error2) {
			return -1;
		} else if (error2 < error1) {
			return 1;
		} else {
			return 0;
		}
	}
}
