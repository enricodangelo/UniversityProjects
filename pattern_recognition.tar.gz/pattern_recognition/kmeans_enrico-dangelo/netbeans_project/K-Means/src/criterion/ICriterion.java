/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package criterion;

import data.Cluster;
import java.util.Collection;
import metric.IMetric;

/**
 *
 * @author enrico
 */
public interface ICriterion {

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	public boolean availableToGUI();

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	public String getDescription();

	/*
	 * Calcola l'errore
	 *
	 * @param clusters i cluster, con i loro centroidi e i punti assegnatigli
	 * @param metric la metrica da utilizzare
	 * @return l'errore
	 */
	public double computeError(Collection<Cluster> clusters, IMetric metric);

	/*
	 * Restituisce il risultato con l'errore minore assumendo che l'errore
	 * sia stato calcolato in entrambi con la stessa funzione criterio
	 *
	 * @param error1 il primo errore
	 * @param error2 il secondo errore
	 * @return 0 se sono uguali, un numero < 0 se error1 e' migliore di error2, un numero > 0 altrimenti
	 */
	public int getBest(double error1, double error2);
}
