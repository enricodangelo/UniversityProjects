/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package metric;

import data.Point;

/**
 * Chebyshev Distance
 * @author enrico
 */
public class Chebyshev implements IMetric {

	private final String description = "Distanza di Chebyshev";
	private long comparisons;

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	@Override
	public boolean availableToGUI() {
		return true;
	}

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/*
	 * Calcola la distanza tra due punti secondo la formula:
	 * max_{1 \leq i \leq D} | x_{i} - y_{i} |
	 *
	 * @param a il primo punto
	 * @param b il secondo punto
	 * @param collectStatistics true se la classe deve inserire questa chiamata a funzione nel conteggio
	 * @return la distanza tra i due punti
	 */
	@Override
	public double distance(Point a, Point b, boolean collectStatistics) {
		double tmp = 0;

		for (int dimension = 0; dimension < a.getNDimensions(); dimension++) {
			tmp += Math.abs(a.values[dimension] - b.values[dimension]);
		}

		if (collectStatistics) {
			comparisons++;
		}

		return tmp;
	}

	/*
	 * Resetta il numero di confronti (chiamate al metodo distance) effettuati a 0
	 */
	@Override
	public void resetNumberOfComparisons() {
		comparisons = 0;
	}

	/*
	 * Ritorna il numero di confronti (chiamate al metodo distance) effettuati
	 *
	 * @return il numero di confronti effettuati
	 */
	@Override
	public long getNumberOfComparisons() {
		return comparisons;
	}

	/*
	 * Clona l'oggetto
	 *
	 * @return un clone dell'oggetti
	 */
	@Override
	public Object clone() {
		return new Chebyshev();
	}
}
