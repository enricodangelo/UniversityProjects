/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package metric;

import data.Point;

/**
 *
 * @author enrico
 */
public interface IMetric {

	/*
	 * Metodo utilizzato dall'interfaccia grafica.
	 * Indica se la classe deve essere mostrata tra le scelte
	 *
	 * @return true se la classe deve essere mostrata tra le scelte, false altrimenti
	 */
	public boolean availableToGUI();

	/*
	 * Ritorna la descrizione della classe
	 *
	 * @return la descrizione della classe
	 */
	public String getDescription();

	/*
	 * Calcola la distanza tra due punti
	 *
	 * @param a il primo punto
	 * @param b il secondo punto
	 * @param collectStatistics true se la classe deve inserire questa chiamata a funzione nel conteggio
	 * @return la distanza tra i due punti
	 */
	public double distance(Point a, Point b, boolean collectStatistics);

	/*
	 * Resetta il numero di confronti (chiamate al metodo distance) effettuati a 0
	 */
	public void resetNumberOfComparisons();

	/*
	 * Ritorna il numero di confronti (chiamate al metodo distance) effettuati
	 *
	 * @return il numero di confronti effettuati
	 */
	public long getNumberOfComparisons();

	/*
	 * Clona l'oggetto
	 *
	 * @return un clone dell'oggetti
	 */
	public Object clone();
}
