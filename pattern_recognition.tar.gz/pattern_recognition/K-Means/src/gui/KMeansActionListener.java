/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import algorithm.ICentroidsUpdaterAlgorithm;
import algorithm.IClusteringAlgorithm;
import data.Dataset;
import data.InputData;
import data.KMeansData;
import data.ResultData;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import utils.KMeansConstants;
import utils.KMeansPropertiesParser;
import utils.TemporaryFilenameGenerator;

/**
 *
 * @author enrico
 */
public class KMeansActionListener implements ActionListener {

	private KMeansModel model;

	public KMeansActionListener(KMeansModel model) {
		this.model = model;
	}

	public void actionPerformed(ActionEvent e) {
		String actionString = e.getActionCommand();

		if (actionString.equals(KMeansConstants.CHOOSE_DATASET_BUTTON_ACTION)) {
			chooseDatasetActionPerformed();
		} else if (actionString.equals(KMeansConstants.SAVE_BUTTON_ACTION)) {
			savePropertiesActionPerformed();
		} else if (actionString.equals(KMeansConstants.LOAD_BUTTON_ACTION)) {
			loadPropertiesActionPerformed();
		} else if (actionString.equals(KMeansConstants.OK_BUTTON_ACTION)) {
			okActionPerformed();
		} else if (actionString.equals(KMeansConstants.CENTROIDSELECTION_ACTION)) {
			centroidSelectionActionPerformed();
		} else if (actionString.equals(KMeansConstants.PC_SAVE_ACTION)) {
			savePropertiesActionPerformed();
		} else if (actionString.equals(KMeansConstants.PC_CANCEL_ACTION)) {
			cancelActionPerformed((JButton) e.getSource());
		}
	}

	private void chooseDatasetActionPerformed() {
		JFileChooser chooser = new JFileChooser();

		chooser.showOpenDialog(null);

		model.setDatasetFilename(chooser.getSelectedFile().getPath());
	}

	private void savePropertiesActionPerformed() {
		try {
			JFileChooser chooser = new JFileChooser();
			FileWriter propertiesWriter = null;
			File selectedFile;

			chooser.showSaveDialog(null);

			selectedFile = chooser.getSelectedFile();

			if (selectedFile != null) {
				String properties = model.getProperties();

				propertiesWriter = new FileWriter(selectedFile);
				propertiesWriter.write(properties, 0, properties.length());
				propertiesWriter.close();

				model.setPropertiesFile(selectedFile);
			}


		} catch (IOException ex) {
			Logger.getLogger(KMeansGUI.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	private void loadPropertiesActionPerformed() {
		JFileChooser chooser = new JFileChooser();
		File selectedFile;

		chooser.showOpenDialog(null);

		selectedFile = chooser.getSelectedFile();

		if (selectedFile != null) {
			boolean correctlyParsed = setKMeansData(selectedFile, false);

			if (correctlyParsed) {
				model.setPropertiesFile(selectedFile);
			}
		}
	}

	private void okActionPerformed() {
		try {
			File tmpFile = new File(TemporaryFilenameGenerator.getTemporaryFilename());
			FileWriter tempPropertiesWriter = new FileWriter(tmpFile);

			String properties = model.getProperties();

			tempPropertiesWriter.write(properties, 0, properties.length());
			tempPropertiesWriter.close();

			boolean dataOK = setKMeansData(tmpFile, true);

			if (dataOK) {
				startWorker();
			}

		} catch (IOException ex) {
			Logger.getLogger(KMeansGUI.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	private void centroidSelectionActionPerformed() {
		model.setSubsampleVisibility();
	}

	private void cancelActionPerformed(JButton button) {
		Container frame = button.getParent();
		while (frame.getParent() != null) {
			frame = frame.getParent();
		}

		((JFrame) frame).setVisible(false);
	}

	private boolean setKMeansData(File propertiesFile, boolean askForChanges) {
		KMeansData kmeansData = KMeansPropertiesParser.parse(propertiesFile.getAbsolutePath());

		if (kmeansData != null) {

			if (askForChanges) {
				if (model.getKmeansData() != null) {
					if (!arePropertiesTheSame(kmeansData, model.getKmeansData())) {
						int reply = JOptionPane.showConfirmDialog(null,
								KMeansConstants.PROPERTIES_CHANGED_MESSAGE,
								KMeansConstants.PROPERTIES_CHANGED_GUI_NAME,
								JOptionPane.YES_NO_OPTION);


						if (reply == JOptionPane.YES_OPTION) {
							savePropertiesActionPerformed();
						} else {
						}
					}
				}
			}

			model.setKmeansData(kmeansData);
			return true;
		}

		return false;
	}

	private void startWorker() {
		final KMeansSwingWorker kmeansWorker = new KMeansSwingWorker();

		kmeansWorker.setKMeansData(model.getKmeansData());

		kmeansWorker.addPropertyChangeListener(new PropertyChangeListener() {

			public void propertyChange(PropertyChangeEvent evt) {
				try {
					ArrayList<ResultData> results = kmeansWorker.get();
					model.setResults(results);
				} catch (InterruptedException ex) {
					Logger.getLogger(PropertiesPanel.class.getName()).log(Level.SEVERE, null, ex);
				} catch (ExecutionException ex) {
					Logger.getLogger(PropertiesPanel.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		});

		kmeansWorker.execute();
	}

	private boolean arePropertiesTheSame(KMeansData data1, KMeansData data2) {
		boolean algorithmResult = false;
		boolean centroidsUpdaterAlgorithmResult = false;
		boolean datasetResult = false;
		boolean metricResult = false;
		boolean criterionResult = false;
		boolean centroidSelectionResult = false;
		boolean subsampleResult = false;
		boolean subsampleSizeResult = false;
		boolean givenCentroidsResult = true;
		boolean clusterFromResult = false;
		boolean clusterToResult = false;
		boolean runResult = false;
		IClusteringAlgorithm algorithm1 = data1.getAlgorithm();
		ICentroidsUpdaterAlgorithm centroidsUpdaterAlgorithm1 = algorithm1.getCentroidsUpdaterAlgorithm();
		InputData input1 = data1.getInputData();
		IClusteringAlgorithm algorithm2 = data2.getAlgorithm();
		ICentroidsUpdaterAlgorithm centroidsUpdaterAlgorithm2 = algorithm2.getCentroidsUpdaterAlgorithm();
		InputData input2 = data2.getInputData();

		if (algorithm1.getClass().getName().equals(algorithm2.getClass().getName())) {
			algorithmResult = true;
		} else {
			algorithmResult = false;
		}

		if (centroidsUpdaterAlgorithm1.getClass().getName().equals(centroidsUpdaterAlgorithm2.getClass().getName())) {
			centroidsUpdaterAlgorithmResult = true;
		} else {
			centroidsUpdaterAlgorithmResult = false;
		}

		if ((input1.getDataset() != null) && (input2.getDataset() != null)) {
			Dataset dataset1 = input1.getDataset();
			Dataset dataset2 = input2.getDataset();

			if (dataset1.getName().equals(dataset2.getName())) {
				datasetResult = true;
			} else {
				datasetResult = false;
			}
		}

		if ((input1.getMetric() != null) && (input2.getMetric() != null)) {
			if (input1.getMetric().getClass().getName().equals(input2.getMetric().getClass().getName())) {
				metricResult = true;
			}
		} else {
			metricResult = false;
		}

		if ((input1.getCriterion() != null) && (input2.getCriterion() != null)) {
			if (input1.getCriterion().getClass().getName().equals(input2.getCriterion().getClass().getName())) {
				criterionResult = true;
			}
		} else {
			criterionResult = false;
		}

		if ((input1.getCentroidSelection() != null) && (input2.getCentroidSelection() != null)) {
			if (input1.getCentroidSelection().getClass().getName().equals(input2.getCentroidSelection().getClass().getName())) {
				centroidSelectionResult = true;
			}
		} else {
			centroidSelectionResult = false;
		}

		if (input1.getSubsamples() == input2.getSubsamples()) {
			subsampleResult = true;
		} else {
			subsampleResult = false;
		}

		if (input1.getSubsampleSize() == input2.getSubsampleSize()) {
			subsampleSizeResult = true;
		} else {
			subsampleSizeResult = false;
		}

		if (input1.getClusterFrom() == input2.getClusterFrom()) {
			clusterFromResult = true;
		} else {
			clusterFromResult = false;
		}

		if (input1.getClusterTo() == input2.getClusterTo()) {
			clusterToResult = true;
		} else {
			clusterToResult = false;
		}

		if (input1.getRun() == input2.getRun()) {
			runResult = true;
		} else {
			runResult = false;
		}

		return algorithmResult &&
				centroidsUpdaterAlgorithmResult &&
				datasetResult &&
				metricResult &&
				criterionResult &&
				centroidSelectionResult &&
				subsampleResult &&
				subsampleSizeResult &&
				givenCentroidsResult &&
				clusterFromResult &&
				clusterToResult &&
				runResult;
	}
}
