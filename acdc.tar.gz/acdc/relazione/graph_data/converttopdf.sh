#!/bin/bash --

for img in `ls *.eps`
do
	epstopdf $img
done
