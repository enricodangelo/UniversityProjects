/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sequential;

import utils.DataFormatter;

/**
 *
 * @author enrico
 */
public class FourStep extends ISequentialFFT {

	ISequentialFFT sequential;

	public FourStep(ISequentialFFT sequential) {
		this.sequential = sequential;
	}

	@Override
	public void fft(String filenameReal, String filenameImg, int n, boolean forward) {
		int radN = (int) Math.sqrt(n);
		String[] rowsReal = DataFormatter.toMatrix(filenameReal, radN);
		String[] rowsImg = DataFormatter.toMatrix(filenameImg, radN);

		//Input iniziale in column-major order
		
		//STEP 1
		for (int i = 0; i < radN; i++) {
			sequential.fft(rowsReal[i], rowsImg[i], radN, forward);
		}

		//STEP 2
		for (int i = 0; i < radN; i++) {
			twiddle(rowsReal[i], rowsImg[i], i, radN, forward);
		}
		
		//STEP 3
		transpose(rowsReal, rowsImg);
		
		//STEP 4
		for (int i = 0; i < radN; i++) {
			sequential.fft(rowsReal[i], rowsImg[i], radN, forward);
		}
		
		DataFormatter.toArray(rowsReal, filenameReal, radN);
		DataFormatter.toArray(rowsImg, filenameImg, radN);
	}
}
