/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sequential;

import utils.DataReader;
import utils.DataWriter;

/**
 * Cooley-Tukey Framework
 * radix-4 in-place FFT
 *
 * @author enrico
 */
public class Radix4 extends ISequentialFFT {

	//Trasformata (inversa) veloce di fourier
	//(algoritmo 2.4.1)
	@Override
	public void fft(String filenameDataReal, String filenameDataImg, int n, boolean forward) {
		DataReader dataReal = new DataReader(filenameDataReal);
		DataReader dataImg = new DataReader(filenameDataImg);
		DataWriter dataRealOutput = null;
		DataWriter dataImgOutput = null;
		Double[] xReal = new Double[n];
		Double[] xImg = new Double[n];
		dataReal.read(xReal);
		dataImg.read(xImg);

		int radix = 4;
		int t = (int) Math.ceil(Math.log10(n) / Math.log10(radix));
		int guess = 4;

		//check that length is a power of 4
		while (guess < n) {
			guess *= 4;
		}
		if (guess != n) {
			throw new RuntimeException("N is not a power of 4");
		}

		if (!forward) {
			//take conjugate
			for (int i = 0; i < n; i++) {
				xImg[i] = -xImg[i];
			}
		}

		//bit reversal permutation
		//(algoritmo 2.2.2)
		for (int k = 0; k < n; k++) {
			int j = 0;
			int m = k;
			for (int q = t; q >= 1; q--) {
				int s = (int) Math.floor(m / radix);
				int alpha = m - s * radix;
				j = radix * j + alpha;
				m = s;
			}
			if (j > k) {
				double tmpReal = xReal[j];
				double tmpImg = xImg[j];

				xReal[j] = xReal[k];
				xImg[j] = xImg[k];

				xReal[k] = tmpReal;
				xImg[k] = tmpImg;
			}
		}

		//butterfly updates
		//(algoritmo 2.4.4 + jk version of 2.4.7)
		for (int q = 1; q <= t; q++) {
			int L = (int) Math.pow(radix, q);
			int r = n / L;
			int Lstar = L / radix;
			for (int j = 0; j < Lstar; j++) {
				double wReal = Math.cos(2.0 * Math.PI * j / L);
				double wImg = -Math.sin(2.0 * Math.PI * j / L);
				double wSquareReal = Math.cos(4.0 * Math.PI * j / L);
				double wSquareImg = -Math.sin(4.0 * Math.PI * j / L);
				double wCubeReal = Math.cos(6.0 * Math.PI * j / L);
				double wCubeImg = -Math.sin(6.0 * Math.PI * j / L);

				for (int k = 0; k < r; k++) {
					int alphaIndex = k * L + j;
					int betaIndex = k * L + Lstar + j;
					int gammaIndex = k * L + 2 * Lstar + j;
					int deltaIndex = k * L + 3 * Lstar + j;

					double alphaReal = xReal[alphaIndex];
					double alphaImg = xImg[alphaIndex];
					double betaReal = wReal * xReal[betaIndex] - wImg * xImg[betaIndex];
					double betaImg = wReal * xImg[betaIndex] + wImg * xReal[betaIndex];
					double gammaReal = wSquareReal * xReal[gammaIndex] - wSquareImg * xImg[gammaIndex];
					double gammaImg = wSquareReal * xImg[gammaIndex] + wSquareImg * xReal[gammaIndex];
					double deltaReal = wCubeReal * xReal[deltaIndex] - wCubeImg * xImg[deltaIndex];
					double deltaImg = wCubeReal * xImg[deltaIndex] + wCubeImg * xReal[deltaIndex];

					double tao0Real = alphaReal + gammaReal;
					double tao0Img = alphaImg + gammaImg;
					double tao1Real = alphaReal - gammaReal;
					double tao1Img = alphaImg - gammaImg;
					double tao2Real = betaReal + deltaReal;
					double tao2Img = betaImg + deltaImg;
					double tao3Real = betaReal - deltaReal;
					double tao3Img = betaImg - deltaImg;

					double tao3iReal = -tao3Img;
					double tao3iImg = tao3Real;

					xReal[alphaIndex] = tao0Real + tao2Real;
					xImg[alphaIndex] = tao0Img + tao2Img;
					xReal[betaIndex] = tao1Real - tao3iReal;
					xImg[betaIndex] = tao1Img - tao3iImg;
					xReal[gammaIndex] = tao0Real - tao2Real;
					xImg[gammaIndex] = tao0Img - tao2Img;
					xReal[deltaIndex] = tao1Real + tao3iReal;
					xImg[deltaIndex] = tao1Img + tao3iImg;
				}
			}
		}

		if (!forward) {
			//take conjugate again
			for (int i = 0; i < n; i++) {
				xImg[i] = -xImg[i];
			}

			//divide by n
			for (int i = 0; i < n; i++) {
				xReal[i] /= (double) n;
				xImg[i] /= (double) n;
			}
		}

		dataRealOutput = new DataWriter(filenameDataReal);
		dataImgOutput = new DataWriter(filenameDataImg);
		
		dataRealOutput.write(xReal);
		dataImgOutput.write(xImg);
	}
}
