/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sequential;

import java.io.File;
import utils.DataReader;
import utils.DataWriter;

/**
 *
 * @author edangelo
 */
public abstract class ISequentialFFT {

	public abstract void fft(String filenameDataReal, String filenameDataImg, int n, boolean forward);

	public void transpose(String[] rowsReal, String[] rowsImg) {
		int n = rowsReal.length;
		String[] newRowsReal = new String[n];
		String[] newRowsImg = new String[n];
		DataReader rowRealReader;
		DataReader rowImgReader;
		DataWriter newRowsRealWriter[] = new DataWriter[n];
		DataWriter newRowsImgWriter[] = new DataWriter[n];
		Double[] doubleArrayReal = new Double[n];
		Double[] doubleArrayImg = new Double[n];
		boolean success;

		for (int i = 0; i < n; i++) {
			newRowsReal[i] = rowsReal[i] + "new";
			newRowsImg[i] = rowsImg[i] + "new";
		}

		for (int i = 0; i < n; i++) {
			newRowsRealWriter[i] = new DataWriter(newRowsReal[i]);
			newRowsImgWriter[i] = new DataWriter(newRowsImg[i]);

			for (int j = 0; j < n; j++) {
				rowRealReader = new DataReader(rowsReal[j]);
				rowImgReader = new DataReader(rowsImg[j]);

				rowRealReader.skip(i);
				rowImgReader.skip(i);

				double real = rowRealReader.read();
				double img = rowImgReader.read();

				doubleArrayReal[j] = real;
				doubleArrayImg[j] = img;

				rowRealReader.finalize();
				rowImgReader.finalize();
			}
			newRowsRealWriter[i].write(doubleArrayReal);
			newRowsImgWriter[i].write(doubleArrayImg);

			newRowsRealWriter[i].finalize();
			newRowsImgWriter[i].finalize();
		}

		for (int i = 0; i < n; i++) {
			File oldRealFile = new File(rowsReal[i]);
			File oldImgFile = new File(rowsImg[i]);
			File newRealFile = new File(newRowsReal[i]);
			File newImgFile = new File(newRowsImg[i]);

			success = newRealFile.renameTo(oldRealFile);

			if (!success) {
				System.out.println("Impossibile rinominare il file " +
						newRealFile.getName() + " in " + oldRealFile.getName());
				System.exit(1);
			}

			success = newImgFile.renameTo(oldImgFile);

			if (!success) {
				System.out.println("Impossibile rinominare il file " +
						newImgFile.getName() + " in " + oldImgFile.getName());
				System.exit(1);
			}
		}
	}

	public void twiddle(String filenameReal, String filenameImg, int J, int columns, boolean forward) {
		int n = columns * columns;
		Double[] arrayReal = new Double[columns];
		Double[] arrayImg = new Double[columns];
		double wReal, wImg, tmpReal, tmpImg = 0;
		DataReader[] reader = new DataReader[2];
		DataWriter[] writer = new DataWriter[2];

		reader[0] = new DataReader(filenameReal);
		reader[1] = new DataReader(filenameImg);

		reader[0].read(arrayReal);
		reader[1].read(arrayImg);

		reader[0].finalize();
		reader[1].finalize();

		for (int K = 0; K < columns; K++) {
			if (forward) {
				wReal = Math.cos((2.0 * Math.PI * K * J) / n);
				wImg = -Math.sin((2.0 * Math.PI * K * J) / n);
			} else {
				wReal = Math.cos((2.0 * Math.PI * K * J) / n);
				wImg = Math.sin((2.0 * Math.PI * K * J) / n);
			}

			tmpReal = arrayReal[K];
			tmpImg = arrayImg[K];

			arrayReal[K] = tmpReal * wReal - tmpImg * wImg;
			arrayImg[K] = tmpReal * wImg + tmpImg * wReal;
		}

		writer[0] = new DataWriter(filenameReal);
		writer[1] = new DataWriter(filenameImg);

		writer[0].write(arrayReal);
		writer[1].write(arrayImg);

		writer[0].finalize();
		writer[1].finalize();
	}
}
