/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sequential;

import utils.DataReader;
import utils.DataWriter;

/**
 * Cooley-Tukey Framework
 * radix-2 in-place FFT
 *
 * @author enrico
 */
public class Radix2 extends ISequentialFFT {

	//Trasformata (inversa) veloce di fourier
	//(algoritmo 1.6.1)
	@Override
	public void fft(String filenameDataReal, String filenameDataImg, int n, boolean forward) {
		DataReader dataReal = new DataReader(filenameDataReal);
		DataReader dataImg = new DataReader(filenameDataImg);
		DataWriter dataRealOutput = null;
		DataWriter dataImgOutput = null;
		Double[] xReal = new Double[n];
		Double[] xImg = new Double[n];
		dataReal.read(xReal);
		dataImg.read(xImg);
		
		int radix = 2;
		int t = (int) Math.ceil(Math.log10(n) / Math.log10(radix));

		//check that length is a power of 2
		if (Integer.highestOneBit(n) != n) {
			throw new RuntimeException("N is not a power of 2");
		}
		
		if (!forward) {
			//take conjugate
			for (int i = 0; i < n; i++) {
				xImg[i] = -xImg[i];
			}
		}

		//bit reversal permutation
		//(algoritmo 1.5.2)
		for (int k = 0; k < n; k++) {
			int j = 0;
			int m = k;
			for (int q = 0; q < t; q++) {
				int s = (int) Math.floor(m / radix);
				int b = m - s * radix;
				j = radix * j + b;
				m = s;
			}
			if (j > k) {
				double tmpReal = xReal[j];
				double tmpImg = xImg[j];

				xReal[j] = xReal[k];
				xImg[j] = xImg[k];

				xReal[k] = tmpReal;
				xImg[k] = tmpImg;
			}

		}

		//butterfly updates
		//nonunit stride jk update (algoritmo 1.4.9)
		for (int q = 1; q <= t; q++) {
			int L = (int) Math.pow(radix, q);
			int r = n / L;
			int Lstar = L / radix;
			for (int j = 0; j < Lstar; j++) {
				double wReal = Math.cos(2.0 * Math.PI * j / L);
				double wImg = -Math.sin(2.0 * Math.PI * j / L);

				for (int k = 0; k < r; k++) {
					double taoReal = wReal * xReal[k * L + j + Lstar] - wImg * xImg[k * L + j + Lstar];
					double taoImg = wReal * xImg[k * L + j + Lstar] + wImg * xReal[k * L + j + Lstar];

					xReal[k * L + j + Lstar] = xReal[k * L + j] - taoReal;
					xImg[k * L + j + Lstar] = xImg[k * L + j] - taoImg;
					xReal[k * L + j] = xReal[k * L + j] + taoReal;
					xImg[k * L + j] = xImg[k * L + j] + taoImg;
				}
			}
		}

		if (!forward) {
			//take conjugate again
			for (int i = 0; i < n; i++) {
				xImg[i] = -xImg[i];
			}

			//divide by n
			for (int i = 0; i < n; i++) {
				xReal[i] /= (double) n;
				xImg[i] /= (double) n;
			}
		}

		dataRealOutput = new DataWriter(filenameDataReal);
		dataImgOutput = new DataWriter(filenameDataImg);

		dataRealOutput.write(xReal);
		dataImgOutput.write(xImg);
		
		dataRealOutput.finalize();
		dataImgOutput.finalize();
	}
}
