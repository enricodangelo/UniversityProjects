/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sequential;

import utils.DataFormatter;

/**
 *
 * @author enrico
 */
public class SixStep extends ISequentialFFT {

	ISequentialFFT sequential;

	public SixStep(ISequentialFFT sequential) {
		this.sequential = sequential;
	}

	@Override
	public void fft(String filenameReal, String filenameImg, int n, boolean forward) {
		int radN = (int) Math.sqrt(n);
		String[] rowsReal = DataFormatter.toMatrix(filenameReal, radN);
		String[] rowsImg = DataFormatter.toMatrix(filenameImg, radN);
		
		//Input iniziale in row-major order

		//STEP 1
		transpose(rowsReal, rowsImg);

		//STEP 2
		for (int i = 0; i < radN; i++) {
			sequential.fft(rowsReal[i], rowsImg[i], radN, forward);
		}

		//STEP 3
        for (int i = 0; i < radN; i++) {
			twiddle(rowsReal[i], rowsImg[i], i, radN, forward);
		}

		//STEP 4
		transpose(rowsReal, rowsImg);

		//STEP 5
		for (int i = 0; i < radN; i++) {
			sequential.fft(rowsReal[i], rowsImg[i], radN, forward);
		}

		//STEP 6
		transpose(rowsReal, rowsImg);

		DataFormatter.toArray(rowsReal, filenameReal, radN);
		DataFormatter.toArray(rowsImg, filenameImg, radN);
	}
}
