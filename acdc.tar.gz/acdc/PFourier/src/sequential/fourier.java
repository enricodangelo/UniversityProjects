/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sequential;

import utils.FFTUtils;
import utils.Constants;
import utils.fourierProperties;

/**
 *
 * @author enrico
 */
public class fourier {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println("fourier <properties file>");
			System.exit(0);
		}

		Long startTime = System.currentTimeMillis();
		Long wallClockTime;

		fourierProperties.parse(args[0]);

		int type = fourierProperties.getFourierType();
		String filenameDataReal = fourierProperties.getFilenameDataReal();
		String filenameDataImg = fourierProperties.getFilenameDataImg();
		int n = fourierProperties.getProblemSize();
		FFTUtils fftUtils = new FFTUtils();
		ISequentialFFT fft = null;

		switch (type) {
			case Constants.RADIX2:
				fft = new Radix2();
				break;
			case Constants.RADIX4:
				fft = new Radix4();
				break;
			case Constants.FOURSTEPRADIX2:
				fft = new FourStep(new Radix2());
				break;
			case Constants.FOURSTEPRADIX4:
				fft = new FourStep(new Radix4());
				break;
			case Constants.SIXSTEPRADIX2:
				fft = new SixStep(new Radix2());
				break;
			case Constants.SIXSTEPRADIX4:
				fft = new SixStep(new Radix4());
				break;
			default:
				System.out.println("Tipo di fourier non valido");
				System.exit(0);
		}

		//show initial data
		fftUtils.show(filenameDataReal, filenameDataImg, n, "x");

		//forward fourier
		fft.fft(filenameDataReal, filenameDataImg, n, Constants.FORWARD);

		//show transformed data
		fftUtils.show(filenameDataReal, filenameDataImg, n, "fft(x)");

		//backward fourier
		fft.fft(filenameDataReal, filenameDataImg, n, Constants.BACKWARD);

		//show (backward) transformed data
		fftUtils.show(filenameDataReal, filenameDataImg, n, "ifft(x)");

		wallClockTime = System.currentTimeMillis() - startTime;
		System.out.println("WCT: " + wallClockTime);
	}
}
