/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parallel;

import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sts.SimpleTupleSpace;
import utils.Constants;
import utils.DataFormatter;

/**
 *
 * @author enrico
 */
public abstract class FFTFramework {

	protected String[] rowsReal;
	protected String[] rowsImg;
	protected int radN;
	protected int maxTuple;
    protected SimpleTupleSpace ts;

	public void setRadN(int radN) {
		this.radN = radN;
	}

	public void setMaxTuple(int maxTuple) {
		if (radN < maxTuple) {
			this.maxTuple = (int) radN;
		} else {
			this.maxTuple = maxTuple;
		}
	}

    public void setTs(SimpleTupleSpace ts) {
		this.ts = ts;
	}

	public abstract void fft(String filenameReal, String filenameImg, Boolean forward);

	protected void formatInput(String filenameReal, String filenameImg) {
		rowsReal = DataFormatter.toMatrix(filenameReal, radN);
		rowsImg = DataFormatter.toMatrix(filenameImg, radN);
	}

	protected void formatOutput(String filenameReal, String filenameImg) {
		DataFormatter.toArray(rowsReal, filenameReal, radN);
		DataFormatter.toArray(rowsImg, filenameImg, radN);
	}

	/*
	 *Crea le tuple che contengono l'operazione da far eseguire agli slaves e i dati necessari
	 *I dati sono gli stessi per tutte le operazioni 
	 */
	protected void order(int operation, String filenameReal, String filenameImg, Boolean forward) {
		int leftToRead = radN;
		int leftToWrite = radN;
		int lastRowIndex = -1;

		try {
            //crea solo maxTuple alla volta.
            //mano a mano che queste vengono completate ne crea altre
			for (int i = 0; i < maxTuple; i++) {
				Data data = new Data(filenameReal, filenameImg, lastRowIndex + 1, radN, forward);
				PFourierTask task = new PFourierTask(operation, data);
				ts.write(task, null);
				lastRowIndex++;
				leftToWrite--;
			}
			while (leftToRead > 0) {
				ts.take(new WorkDone(), null);
				leftToRead--;
				if (leftToWrite > 0) {
					Data data = new Data(filenameReal, filenameImg, lastRowIndex + 1, radN, forward);
					PFourierTask task = new PFourierTask(operation, data);
					ts.write(task, null);
					lastRowIndex++;
					leftToWrite--;
				}
			}
		} catch (RemoteException ex) {
			Logger.getLogger(FFTFramework.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
	
	protected void endOfWork(Integer slaves) {
		try {
			for (int i = 0; i < slaves; i++) {
				PFourierTask task = new PFourierTask(Constants.ENDOFWORK, null);
				ts.write(task, null);
			}

			waitAll(slaves);

		} catch (RemoteException ex) {
			Logger.getLogger(FFTFramework.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	private void waitAll(Integer slaves) {
		try {
			for (int i = 0; i < slaves; i++) {
				WorkDone wd = (WorkDone) ts.take(new WorkDone(), null);

                /* l'unico punto in cui gli slave creano la tupla WorkDone con hostname vuoto
                 * e' in Slave.doTransposePt1 ed e' dovuto a problemi di I/O
                 */
				if (wd.hostname.equals("")) {
					System.out.println("FALLITO");
					System.exit(1);
				}
			}
		} catch (RemoteException ex) {
			Logger.getLogger(FFTFramework.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
