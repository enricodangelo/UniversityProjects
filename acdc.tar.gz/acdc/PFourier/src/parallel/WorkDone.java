/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package parallel;

import java.io.Serializable;

/**
 *
 * @author enrico
 */

//tupla inviata dagli slave dopo il completamento di ogni task
public class WorkDone implements Serializable {
	public String hostname;
	
	public WorkDone() {	
	}
	
	public WorkDone(String hostname) {
		this.hostname = hostname;
	}
}
