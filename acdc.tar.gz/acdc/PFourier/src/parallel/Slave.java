/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parallel;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import sequential.ISequentialFFT;
import sts.SimpleTupleSpace;
import utils.Constants;
import utils.DataReader;
import utils.DataWriter;
import utils.FFTUtils;
import utils.PFourierProperties;

/**
 *
 * @author enrico
 */
public abstract class Slave {

	public static String slaveName;
	public static ISequentialFFT fft = null;
	public static FFTUtils fftUtils = new FFTUtils();
	protected static SimpleTupleSpace ts;
	protected static String tupleSpaceHost;
	protected static int tupleSpacePort;

	protected static void getTask(String[] args) {
		try {
			slaveName = InetAddress.getLocalHost().getHostName();

			PFourierProperties.slaveParse(args[0]);

			tupleSpaceHost = PFourierProperties.getTupleSpaceHost();
			tupleSpacePort = PFourierProperties.getTupleSpacePort();

			//Inizializzazione di SimpleTupleSpace
			Registry registry = LocateRegistry.getRegistry(tupleSpaceHost, tupleSpacePort);
			ts = (SimpleTupleSpace) registry.lookup("TupleSpace");

			while (true) {
				PFourierTask task = (PFourierTask) ts.take(new PFourierTask(), null);

				switch (task.action) {
					case Constants.FFT:
						doFFT(task.data);
						break;
					case Constants.TRANSPOSEPT1:
						doTransposePt1(task.data);
						break;
					case Constants.TRANSPOSEPT2:
						doTransposePt2(task.data);
						break;
					case Constants.TWIDDLE:
						doTwiddle(task.data);
						break;
					case Constants.ENDOFWORK:
						ts.write(new WorkDone(slaveName), null);
						System.out.println("Termino.");
						System.exit(0);
						break;
					default:
						System.err.println("Errore, task non definito.");
						System.err.println(task.action);
						System.exit(1);
				}

				ts.write(new WorkDone(slaveName), null);
			}
		} catch (Exception ex) {
			Logger.getLogger(Slave.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	protected static void doFFT(Data data) {
		fft.fft(data.filenameReal + Constants.ROW + data.i,
				data.filenameImg + Constants.ROW + data.i,
				data.n,
				data.forward);
	}

	protected static void doTransposePt1(Data data) {
		Double[][] newRows = new Double[2][data.n];
		DataWriter newRowReal = new DataWriter(data.filenameReal + Constants.NEWROW + data.i);
		DataWriter newRowImg = new DataWriter(data.filenameImg + Constants.NEWROW + data.i);

		try {
			for (int i = 0; i < data.n; i++) {
				newRows[0][i] = DataReader.read(data.filenameReal + Constants.ROW + i, data.i);
				newRows[1][i] = DataReader.read(data.filenameImg + Constants.ROW + i, data.i);
			}
		} catch (IOException ex) {
			try {
				Logger.getLogger(Slave.class.getName()).log(Level.SEVERE, null, ex);
				ts.write(new WorkDone(""), null);
			} catch (RemoteException ex1) {
				Logger.getLogger(Slave.class.getName()).log(Level.SEVERE, null, ex1);
			}
		}

		newRowReal.write(newRows[0]);
		newRowImg.write(newRows[1]);

		newRowReal.finalize();
		newRowImg.finalize();

	}

	protected static void doTransposePt2(Data data) {
		boolean successReal, successImg = false;

		File oldRealFile = new File(data.filenameReal + Constants.ROW + data.i);
		File oldImgFile = new File(data.filenameImg + Constants.ROW + data.i);
		File newRealFile = new File(data.filenameReal + Constants.NEWROW + data.i);
		File newImgFile = new File(data.filenameImg + Constants.NEWROW + data.i);

		successReal = newRealFile.renameTo(oldRealFile);

		if (!successReal) {
			System.out.println("Impossibile rinominare il file " +
					newRealFile.getName() + " in " + oldRealFile.getName());
			System.exit(1);
		}

		successImg = newImgFile.renameTo(oldImgFile);

		if (!successImg) {
			System.out.println("Impossibile rinominare il file " +
					newImgFile.getName() + " in " + oldImgFile.getName());
			System.exit(1);
		}
	}

	protected static void doTwiddle(Data data) {
		int columns = data.n;
		int n = columns * columns;
		int J = data.i;
		Double[] arrayReal = new Double[columns];
		Double[] arrayImg = new Double[columns];
		double wReal, wImg, tmpReal, tmpImg = 0;
		DataReader[] reader = new DataReader[2];
		DataWriter[] writer = new DataWriter[2];

		reader[0] = new DataReader(data.filenameReal + Constants.ROW + J);
		reader[1] = new DataReader(data.filenameImg + Constants.ROW + J);

		reader[0].read(arrayReal);
		reader[1].read(arrayImg);

		reader[0].finalize();
		reader[1].finalize();

		for (int K = 0; K < columns; K++) {
			if (data.forward) {
				wReal = Math.cos((2.0 * Math.PI * K * J) / n);
				wImg = -Math.sin((2.0 * Math.PI * K * J) / n);
			} else {
				wReal = Math.cos((2.0 * Math.PI * K * J) / n);
				wImg = Math.sin((2.0 * Math.PI * K * J) / n);
			}

			tmpReal = arrayReal[K];
			tmpImg = arrayImg[K];

			arrayReal[K] = tmpReal * wReal - tmpImg * wImg;
			arrayImg[K] = tmpReal * wImg + tmpImg * wReal;
		}

		writer[0] = new DataWriter(data.filenameReal + Constants.ROW + J);
		writer[1] = new DataWriter(data.filenameImg + Constants.ROW + J);

		writer[0].write(arrayReal);
		writer[1].write(arrayImg);

		writer[0].finalize();
		writer[1].finalize();
	}
}
