/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package parallel;

import java.io.Serializable;

/**
 *
 * @author enrico
 */
//classe inviata con la tupla che definisce il task. Contiene tutte le informazioni necessarie per compiere ognuno dei task
public class Data implements Serializable {
	public String filenameReal;
	public String filenameImg;
	public Boolean forward;
	public Integer i;
	public Integer n;
	
	public Data() {
	}
	
	public Data(String filenameReal, String filenameImg, Integer i, Integer n, Boolean forward) {
		this.filenameReal = filenameReal;
		this.filenameImg = filenameImg;
		this.i = i;
		this.n = n;
		this.forward = forward;
	}
	
	@Override
	public String toString() {
		return "[" + filenameReal + ", " + filenameImg + ", " + i + ", " + n + ", " + forward + "]";
	}
}
