/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parallel;

import sequential.Radix2;

/**
 *
 * @author enrico
 */
public class Radix2Slave extends Slave {

	public static void main(String[] args) {
		
		fft = new Radix2();

		getTask(args);
	}
}
