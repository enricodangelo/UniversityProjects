/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parallel;

import utils.Constants;

/**
 *
 * @author edangelo
 */
public class FourStep extends FFTFramework {

	@Override
	public void fft(String filenameReal, String filenameImg, Boolean forward) {

		//Input iniziale in row-major order

		//STEP 1
		order(Constants.FFT, filenameReal, filenameImg, forward);

		//STEP 2
		order(Constants.TWIDDLE, filenameReal, filenameImg, forward);

		//STEP 3
		order(Constants.TRANSPOSEPT1, filenameReal, filenameImg, forward);
		order(Constants.TRANSPOSEPT2, filenameReal, filenameImg, forward);

		//STEP 4
		order(Constants.FFT, filenameReal, filenameImg, forward);
	}
}
