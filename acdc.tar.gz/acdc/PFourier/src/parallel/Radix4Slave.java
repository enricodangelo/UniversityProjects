/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parallel;

import sequential.Radix4;

/**
 *
 * @author enrico
 */
public class Radix4Slave extends Slave {

	public static void main(String[] args) {
		
		fft = new Radix4();

		getTask(args);
	}
}
