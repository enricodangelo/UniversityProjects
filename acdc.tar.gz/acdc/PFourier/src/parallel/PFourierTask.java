/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package parallel;

import java.io.Serializable;

/**
 *
 * @author edangelo
 */
//tupla che rappresenta un task. Il campo action definisce quale azione compiere (i valori sono definiti in utils.Constants)
public class PFourierTask implements Serializable {
	public Integer action;
	public Data data;
	
	public PFourierTask(){	
	}
	
	public PFourierTask(Integer action, Data data) {
		this.action = action;
		this.data = data;
	}
}
