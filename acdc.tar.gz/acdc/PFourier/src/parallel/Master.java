/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parallel;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import sts.SimpleTupleSpace;
import utils.Constants;
import utils.FFTUtils;
import utils.PFourierProperties;

/**
 *
 * @author edangelo
 */
public class Master {

	public static void main(String[] args) {
		Long startTime = System.currentTimeMillis();
		Long wallClockTime;
		Integer proposedMaxTuple = 500;
		FFTFramework framework = null;
		String tupleSpaceHost;
		int tupleSpacePort;
		FFTUtils fftUtils = new FFTUtils();

		if (args.length != 1) {
			System.err.println("PFourier <properties file>");
			System.exit(-1);
		}

		PFourierProperties.masterParse(args[0]);

		if (PFourierProperties.getFFTFramework() == Constants.FOURSTEPFRAMEWORK) {
			framework = new FourStep();
		} else if (PFourierProperties.getFFTFramework() == Constants.SIXSTEPFRAMEWORK) {
			framework = new SixStep();
		}
		tupleSpaceHost = PFourierProperties.getTupleSpaceHost();
		tupleSpacePort = PFourierProperties.getTupleSpacePort();

		try {
			//Inizializzazione di SimpleTupleSpace
			Registry registry = LocateRegistry.getRegistry(tupleSpaceHost, tupleSpacePort);
			SimpleTupleSpace ts = (SimpleTupleSpace) registry.lookup("TupleSpace");

			framework.setRadN((int) Math.sqrt(PFourierProperties.getN()));
			framework.setMaxTuple(proposedMaxTuple);
			framework.setTs(ts);

			framework.formatInput(PFourierProperties.getFilenameReal(),
					PFourierProperties.getFilenameImg());

//			fftUtils.showRowMajor(PFourierProperties.getFilenameReal(),
//				PFourierProperties.getFilenameImg(),
//				PFourierProperties.getN(),
//				"x");

			framework.fft(PFourierProperties.getFilenameReal(),
					PFourierProperties.getFilenameImg(),
					PFourierProperties.getForward());

			framework.endOfWork(PFourierProperties.getSlaves());

			framework.formatOutput(PFourierProperties.getFilenameReal(),
					PFourierProperties.getFilenameImg());

//			fftUtils.showRowMajor(PFourierProperties.getFilenameReal(),
//				PFourierProperties.getFilenameImg(),
//				(int)PFourierProperties.getN(),
//				"fft(x)");
		} catch (Exception ex) {
			Logger.getLogger(Master.class.getName()).log(Level.SEVERE, null, ex);
		}
		wallClockTime = System.currentTimeMillis() - startTime;
		System.out.println("WCT: " + wallClockTime);
	}
}
