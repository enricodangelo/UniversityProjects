/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author enrico
 */
public class DataReader {
	/* Ordine delle chiamate:
	 *	DataReader()
	 *	read() | read(double[]) | skip(int)
	 *	finalize()
	 * 
	 * per read(String, int) non occorre chiamare il costruttore o finalize()
	 * 
	 */

	private String filename;
	private DataInputStream inputStream = null;

	public String getFilename() {
		return filename;
	}

	//Inizializza il DataReader aprendo il file passatogli.
	public DataReader(String filename) {
		try {
			this.filename = filename;
			File file = new File(filename);
			while (!file.canRead()) {
				Thread.sleep(100);
			}
			inputStream = new DataInputStream(new FileInputStream(file));
		} catch (FileNotFoundException ex) {
			Logger.getLogger(DataReader.class.getName()).log(Level.SEVERE, null, ex);
		} catch (InterruptedException ex) {
			Logger.getLogger(DataReader.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	//Chiude il file aperto in lettura (azzera la posizione all'interno del file)
	@Override
	public void finalize() {
		try {
			inputStream.close();
		} catch (IOException ex) {
			Logger.getLogger(DataReader.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	//Salta "n" double (avanza di "n" double la posizione all'interno del file)
	public void skip(long n) {
		if (n != 0) {
			try {
				while (n > 0) {
					n -= inputStream.skip(n * 8);
				}
			} catch (IOException ex) {
				Logger.getLogger(DataReader.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	//Legge un double (avanza di 8 bytes la posizione all'interno del file)
	public Double read() {
		double doubleValue = 0;
		try {
            doubleValue = inputStream.readDouble();
		} catch (IOException ex) {
			Logger.getLogger(DataReader.class.getName()).log(Level.SEVERE, null, ex);
		}
		return doubleValue;
	}

	//Legge un array di double (avanza di "array.length" * 8 bytes la posizione all'interno del file)
	public void read(Double[] array) {
		try {
			for (int i = 0; i < array.length; i++) {
				array[i] = inputStream.readDouble();
			}
		} catch (IOException ex) {
			Logger.getLogger(DataReader.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	//Legge da "filename" il double in posizione "n * 8"
	public static Double read(String filename, int n) throws FileNotFoundException {
		DataInputStream inputStream = null;
		double doubleValue = 0.0;

		try {
			File file = new File(filename);
			inputStream = new DataInputStream(new FileInputStream(file));

			if (n != 0) {
				try {
					while (n > 0) {
						n -= inputStream.skip(n * 8);
					}
				} catch (IOException ex) {
					Logger.getLogger(DataReader.class.getName()).log(Level.SEVERE, null, ex);
				}
			}

			doubleValue = inputStream.readDouble();
		} catch (IOException ex) {
			if (ex instanceof FileNotFoundException) {
				throw (FileNotFoundException)ex;
			} else {
				Logger.getLogger(DataReader.class.getName()).log(Level.SEVERE, null, ex);
			}
		} finally {
			try {
				inputStream.close();
			} catch (IOException ex) {
				Logger.getLogger(DataReader.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
		return doubleValue;
	}
}
