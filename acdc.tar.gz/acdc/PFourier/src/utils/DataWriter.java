/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author enrico
 */
public class DataWriter {
	/* Ordine delle chiamate:
	 *	DataWriter()
	 *	write(double) | write(double[])
	 *	finalize()
	 * 
	 */
	
	private String filename;
	private DataOutputStream outputStream = null;

	public String getFilename() {
		return filename;
	}

	//Inizializza il DataWriter aprendo/creando il file passatogli.
	public DataWriter(String filename) {
		try {
			this.filename = filename;
			outputStream = new DataOutputStream(new FileOutputStream(filename));
		} catch (FileNotFoundException ex) {
			Logger.getLogger(DataWriter.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	//Chiude il file aperto in scrittura (azzera la posizione all'interno del file)
	@Override
	public void finalize() {
		try {
			outputStream.flush();
			outputStream.close();
		} catch (IOException ex) {
			Logger.getLogger(DataWriter.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	//Scrive un double (avanza di 8 bytes la posizione all'interno del file)
	public void write(Double doubleValue) {
		try {
			outputStream.writeDouble(doubleValue);
			outputStream.flush();
		} catch (IOException ex) {
			Logger.getLogger(DataWriter.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	//Scrive un array di double (avanza di "array.length" * 8 bytes la posizione all'interno del file)
	public void write(Double[] array) {
		try {
			ByteArrayOutputStream byte_out = new ByteArrayOutputStream ();
			DataOutputStream data_out = new DataOutputStream (byte_out);

			for (int i = 0; i < array.length; i++) {
				data_out.writeDouble(array[i]);
			}
			
			outputStream.write(byte_out.toByteArray());
			outputStream.flush();
		} catch (IOException ex) {
			Logger.getLogger(DataWriter.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
