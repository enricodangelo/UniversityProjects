/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 * Questa classe genera i file di input da utilizzare nei test.
 * 
 */
public class DataInitializer {

	static private String real = "Real";
	static private String img = "Img";
	static private String part;

	static public void main(String[] args) {
		if (args.length != 4) {
			System.out.println("DataInitializer <problemSize> <RowMajor | ColumnMajor> <output filename prefix> <Real | Img>");
			System.exit(0);
		}

		long n = Long.parseLong(args[0]);
		String filenamePrefix = args[2];
		if ((args[3].compareTo(real) != 0) && (args[3].compareTo(img) != 0)) {
			System.err.println("DataInitializer <problemSize> <RowMajor | ColumnMajor> <output filename prefix> <Real | Img>");
			System.exit(1);
		}
		part = args[3];

		if (args[1].compareTo("RowMajor") == 0) {
			createDataRowMajor(n, filenamePrefix);
		} else if (args[1].compareTo("ColumnMajor") == 0) {
			createDataColumnMajor(n, filenamePrefix);
		} else {
			System.out.println("Formato non conosciuto.");
			System.exit(0);
		}
	}

	static private void createDataRowMajor(long n, String filenamePrefix) {
		String filename = filenamePrefix + "-RowMajor-" + part;
		System.out.println("Writing to " + filename);
		DataWriter writer = new DataWriter(filename);

		if (part.compareTo(real) == 0) {
			for (long i = 0; i < n; i++) {
				double d = i;

				writer.write(d);
			}
		} else {
			for (long i = 0; i < n; i++) {
				double d = 0.0;

				writer.write(d);
			}
		}

		writer.finalize();
	}

	static private void createDataColumnMajor(long n, String filenamePrefix) {
		String filename = filenamePrefix + "-ColumnMajor-" + part;
		System.out.println("Writing to " + filename);
		int radN = (int) Math.sqrt(n);
		DataWriter writer = new DataWriter(filename);

		if (part.compareTo(real) == 0) {
			for (int i = 0; i < radN; i++) {
				for (int j = 0; j < radN; j++) {
					double d = j * radN + i;

					writer.write(d);
				}
			}
		} else {
			for (int i = 0; i < radN; i++) {
				for (int j = 0; j < radN; j++) {
					double d = 0.0;

					writer.write(d);
				}
			}
		}

		writer.finalize();
	}
}
