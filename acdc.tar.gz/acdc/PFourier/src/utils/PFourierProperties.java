/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 *
 * @author enrico
 */
public class PFourierProperties {

	private static String filenameReal;
	private static String filenameImg;
	private static boolean forward;
	private static int slaves;
	private static int FFTFramework;
	private static long n;
	private static String tupleSpaceHost;
	private static int tupleSpacePort;

	public static String getFilenameImg() {
		return filenameImg;
	}

	public static String getFilenameReal() {
		return filenameReal;
	}
	
	public static boolean getForward() {
		return forward;
	}
	
	public static int getSlaves() {
		return slaves;
	}
	
	public static int getFFTFramework() {
		return FFTFramework;
	}

	public static long getN() {
		return n;
	}

	public static String getTupleSpaceHost() {
		return tupleSpaceHost;
	}

	public static int getTupleSpacePort() {
		return tupleSpacePort;
	}

	public static void masterParse(String propertiesFile) {
		try {
			String propertiesFilename = propertiesFile;
			FileInputStream in = null;
			Properties properties = new Properties();

			in = new FileInputStream(propertiesFilename);
			properties.load(in);

			filenameReal = properties.getProperty("filenameReal");
			filenameImg = properties.getProperty("filenameImg");
			forward = Boolean.parseBoolean(properties.getProperty("forward"));
			slaves = Integer.parseInt(properties.getProperty("slaves"));
			FFTFramework = Integer.parseInt(properties.getProperty("FFTFramework"));
			n = Long.parseLong(properties.getProperty("n"));
			//n = Integer.parseInt(properties.getProperty("n"));
			tupleSpaceHost = properties.getProperty("tupleSpaceHost");
			tupleSpacePort = Integer.parseInt(properties.getProperty("tupleSpacePort"));

			in.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static void slaveParse(String propertiesFile) {
		try {
			String propertiesFilename = propertiesFile;
			FileInputStream in = null;
			Properties properties = new Properties();

			in = new FileInputStream(propertiesFilename);
			properties.load(in);

			tupleSpaceHost = properties.getProperty("tupleSpaceHost");
			tupleSpacePort = Integer.parseInt(properties.getProperty("tupleSpacePort"));

			in.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}