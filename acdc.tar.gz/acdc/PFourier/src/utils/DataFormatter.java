/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author enrico
 */
public class DataFormatter {

	public static String[] toMatrix(String filename, int n) {
		Double[] data = new Double[n];
		String[] rowsFilename = new String[n];
		DataReader reader = new DataReader(filename);

		for (int i = 0; i < n; i++) {
			String currentFilename = filename + Constants.ROW + i;
			DataWriter writer = new DataWriter(currentFilename);

			reader.read(data);
			writer.write(data);
			writer.finalize();

			rowsFilename[i] = currentFilename;
		}

		reader.finalize();
		return rowsFilename;
	}

	public static void toArray(String[] rowsFilename, String filename, int n) {
		Double[] data = new Double[n];
		DataWriter writer = new DataWriter(filename);

		for (int i = 0; i < n; i++) {
			DataReader reader = new DataReader(rowsFilename[i]);
			reader.read(data);

			writer.write(data);
			reader.finalize();
		}

		writer.finalize();
	}
}
