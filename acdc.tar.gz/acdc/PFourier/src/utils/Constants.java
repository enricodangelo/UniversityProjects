/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils;

/**
 *
 * @author enrico
 */
public class Constants {
    public static final int RADIX2 = 1;
    public static final int RADIX4 = 2;
	public static final int FOURSTEPRADIX2 = 3;
	public static final int FOURSTEPRADIX4 = 4;
	public static final int SIXSTEPRADIX2 = 5;
	public static final int SIXSTEPRADIX4 = 6;

    public static final int FFT = 1;
    public static final int TRANSPOSEPT1 = 2;
	public static final int TRANSPOSEPT2 = 3;
    public static final int TWIDDLE = 4;
	public static final int ENDOFWORK = 5;
    
    public static final boolean FORWARD = true;
    public static final boolean BACKWARD = false;
	
	public static final int RADIX2FFT = 1;
	public static final int RADIX4FFT = 2;
	public static final int FOURSTEPFRAMEWORK = 3;
	public static final int SIXSTEPFRAMEWORK = 4;
	
	public static final String ROW = "-row-";
	public static final String NEWROW = "-newrow-";
}
