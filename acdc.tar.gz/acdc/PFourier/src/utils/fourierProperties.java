/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author enrico
 */
public class fourierProperties {
    private static int fourierType = 0;
    private static String filenameDataReal = "";
    private static String filenameDataImg = "";
    private static int problemSize = 0;
    
    public static int getFourierType() {
	return fourierType;
    }
    
    public static String getFilenameDataReal() {
	return filenameDataReal;
    }
    
    public static String getFilenameDataImg() {
	return filenameDataImg;
    }
    
    public static int getProblemSize() {
	return problemSize;
    }

    public static void parse(String propertiesFile) {
	try {
	    String propertiesFilename = propertiesFile;
	    FileInputStream in = null;
	    Properties properties = new Properties();

	    in = new FileInputStream(propertiesFilename);
	    properties.load(in);

	    fourierType = Integer.parseInt(properties.getProperty("fourierType"));
	    filenameDataReal = properties.getProperty("filenameDataReal");
	    filenameDataImg = properties.getProperty("filenameDataImg");
	    problemSize = Integer.parseInt(properties.getProperty("problemSize"));

	    in.close();
	} catch (IOException ex) {
	    Logger.getLogger(fourierProperties.class.getName()).log(Level.SEVERE, null, ex);
	}
    }
}