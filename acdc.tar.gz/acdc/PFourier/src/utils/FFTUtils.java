/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author edangelo
 */
public class FFTUtils {

	//Stampa i due array di input come un unico array di numeri complessi
	public void show(String filenameReal, String filenameImg, int n, String title) {
		DataReader dataReal = new DataReader(filenameReal);
		DataReader dataImg = new DataReader(filenameImg);
		Double[] xReal = new Double[n];
		Double[] xImg = new Double[n];
		dataReal.read(xReal);
		dataImg.read(xImg);

		System.out.println(title);
		for (int i = 0; i < xReal.length; i++) {
			if (xImg[i] == 0) {
				System.out.println(xReal[i] + " 0.0");
			} else if (xReal[i] == 0) {
				System.out.println("0.0 " + xImg[i]);
			} else {
				System.out.println(xReal[i] + " " + xImg[i]);
			}
		}
		System.out.println();

		dataReal.finalize();
		dataImg.finalize();
	}

    //Stampa i due array di input come un unico array di numeri complessi
	public void show(String[] rowsReal, String[] rowsImg, int n, String title) {
		DataReader[] dataReal = new DataReader[n];
		DataReader[] dataImg = new DataReader[n];
		Double[] xReal = new Double[n];
		Double[] xImg = new Double[n];

		for (int i = 0; i < n; i++) {
			dataReal[i] = new DataReader(rowsReal[i]);
			dataImg[i] = new DataReader(rowsImg[i]);
		}

		System.out.println(title);
		for (int j = 0; j < n; j++) {
			dataReal[j].read(xReal);
			dataImg[j].read(xImg);

			for (int i = 0; i < n; i++) {
				if (xImg[i] == 0) {
					System.out.println(xReal[i] + " 0.0");
				} else if (xReal[i] == 0) {
					System.out.println("0.0 " + xImg[i]);
				} else {
					System.out.println(xReal[i] + " " + xImg[i]);
				}
			}
		}
		System.out.println();

		for (int i = 0; i < n; i++) {
			dataReal[i].finalize();
			dataImg[i].finalize();
		}
	}
}
