/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sts.example;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import sts.SimpleTupleSpace;

/**
 *
 * @author benve
 */
public class SimpleSlave {

    public static void main(String[] args) {

        if (args.length != 2) {
            System.err.println("SimpleSlave <host> <port>");
            System.exit(-1);
        }

	try {
	    Registry registry = LocateRegistry.getRegistry(args[0], Integer.parseInt(args[1]));
	    SimpleTupleSpace ts = (SimpleTupleSpace) registry.lookup("TupleSpace");

        while (true) {
            Data d = (Data) ts.take((new Data()), null);
            System.out.println(d.value);
            ts.write((new Result(d.value)), null);
        }     

	} catch (Exception e) {
	    System.err.println("Master exception: " + e.toString());
	    e.printStackTrace();
	}


    }

}
