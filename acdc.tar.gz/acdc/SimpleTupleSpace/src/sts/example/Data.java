/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sts.example;

import java.io.Serializable;

/**
 *
 * @author benve
 */
public class Data implements Serializable {

    public Integer value;

    public Data() {

    }

    public Data(Integer i) {
        this.value=i;
    }

}
