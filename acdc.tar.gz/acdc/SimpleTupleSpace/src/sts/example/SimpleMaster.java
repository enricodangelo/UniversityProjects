/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sts.example;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import sts.SimpleTupleSpace;

/**
 *
 * @author benve
 */
public class SimpleMaster {

    public static void main(String[] args) {

        if (args.length != 3) {
            System.err.println("SimpleMaster <host> <port> <tuple>");
            System.exit(-1);
        }
        
	try {
	    Registry registry = LocateRegistry.getRegistry(args[0], Integer.parseInt(args[1]));
	    SimpleTupleSpace ts = (SimpleTupleSpace) registry.lookup("TupleSpace");

        int tuple = Integer.parseInt(args[2]);

        for (int i = 0; i < tuple; i++) {
            ts.write((new Data(i)), null);

        }

        for (int i = 0; i < tuple; i++) {
            Result r = (Result) ts.take((new Result()), null);
            System.out.println(r.value);
        }
        
	    
	} catch (Exception e) {
	    System.err.println("Master exception: " + e.toString());
	    e.printStackTrace();
	}


    }



}
