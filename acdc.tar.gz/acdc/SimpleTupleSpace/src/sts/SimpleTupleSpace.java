/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sts;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author benve
 */
public interface SimpleTupleSpace extends Remote {

    public void write(Object myobject, Object i) throws RemoteException;
    public Object take(Object myobject, Object i) throws RemoteException;

}
