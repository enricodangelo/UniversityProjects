/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sts;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author benve
 */
public class TupleSpaceServer implements SimpleTupleSpace {

    HashMap<String, LinkedBlockingQueue<Object>> queue;

    public TupleSpaceServer() {
        queue = new HashMap<String, LinkedBlockingQueue<Object>>(2);
    }

    private synchronized LinkedBlockingQueue<Object> getQueue(String classe) {
        LinkedBlockingQueue<Object> coda = queue.get(classe);
        if (coda == null) {
                System.out.println("Creo coda per " + classe);
                coda = new LinkedBlockingQueue<Object>();
                queue.put(classe, coda);
            }
        return coda;
    }

    public void write(Object myobject, Object i) throws RemoteException {
        try {
            String classe = myobject.getClass().getName();
            LinkedBlockingQueue<Object> coda = getQueue(classe);
            coda.put(myobject);
        } catch (InterruptedException ex) {
            Logger.getLogger(TupleSpaceServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Object take(Object myobject, Object i) throws RemoteException {
        Object ret = null;
        try {
            String classe = myobject.getClass().getName();
            LinkedBlockingQueue<Object> coda = getQueue(classe);
            ret = coda.take();
        } catch (InterruptedException ex) {
            Logger.getLogger(TupleSpaceServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret;
    }

    public static void main(String args[]) {

        if (args.length != 1) {
            System.err.println("TupleSpaceServer <port>");
            System.exit(-1);
        }

        try {
            TupleSpaceServer tsServer = new TupleSpaceServer();
            SimpleTupleSpace stub = (SimpleTupleSpace) UnicastRemoteObject.exportObject(tsServer, 0);
            int port = Integer.parseInt(args[0]);
            Registry registry = LocateRegistry.createRegistry(port);
            registry.bind("TupleSpace", stub);
            System.err.println("Server ready");

        } catch (Exception ex) {
            Logger.getLogger(TupleSpaceServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
