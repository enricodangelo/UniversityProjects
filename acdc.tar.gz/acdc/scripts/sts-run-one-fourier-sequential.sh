#!/bin/bash --

#constants
ORIGINAL=Original-
INPUTPREFIX=
REAL=-Real
IMG=-Img
MAJOR=
FRAMEWORK=
SALG=
SIZE=
SLAVES=
RUN=

#directory
PUBLIC=/public/edangelo
ACDCHOME=${PUBLIC}/acdc/sts
ACDCINPUT=${PUBLIC}/acdc-input
ACDCOUTPUT=${ACDCHOME}/output
ACDCDATA=${PUBLIC}/acdc-data

#files
LOG=${ACDCHOME}/sts-fourier-tests.log
PROPERTIES=


## Funciotns

check_parameters() {
	if [ $# -ne 5 ]
	then
		echo -e ""
		echo -e "$0 <framework> <algorithm> <input size> <run>"
		echo -e ""
		echo -e "<framework> puo' essere:"
		echo -e "\t FourStep"
		echo -e "\t SixStep"
		echo -e ""
		echo -e "<algorithm> puo' essere:"
		echo -e "\t Radix2"
		echo -e "\t Radix4"
		echo -e ""
		exit 1
	fi

	FRAMEWORK=$1
	SALG=$2
	SIZE=$3
	SLAVES=$4
	RUN=$5

	INPUTPREFIX=inc${SIZE}
	PROPERTIES=fourier.${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}.properties

	if [ ${FRAMEWORK} = FourStep ]
		then
		MAJOR=-ColumnMajor
	elif [ ${FRAMEWORK} = SixStep ]
		then
		MAJOR=-RowMajor
	fi
}

copy_input() {
	#echo "[`date`] Copy input files"
	#echo "[`date`] Copy input files" >> ${LOG}

	#echo "cp ${ACDCINPUT}/${ORIGINAL}${INPUTPREFIX}${MAJOR}${REAL} ${ACDCDATA}/${INPUTPREFIX}${MAJOR}${REAL}"
	cp ${ACDCINPUT}/${ORIGINAL}${INPUTPREFIX}${MAJOR}${REAL} ${ACDCDATA}/${INPUTPREFIX}${MAJOR}${REAL}
	#echo "cp ${ACDCINPUT}/${ORIGINAL}${INPUTPREFIX}${MAJOR}${IMG} ${ACDCDATA}/${INPUTPREFIX}${MAJOR}${IMG}"
	cp ${ACDCINPUT}/${ORIGINAL}${INPUTPREFIX}${MAJOR}${IMG} ${ACDCDATA}/${INPUTPREFIX}${MAJOR}${IMG}
	#echo "cp ${ACDCINPUT}/${PROPERTIES} ${ACDCDATA}/${PROPERTIES}"
	cp ${ACDCINPUT}/${PROPERTIES} ${ACDCDATA}/${PROPERTIES}

	#echo "[`date`] Copy input files. DONE"
	#echo "[`date`] Copy input files. DONE" >> ${LOG}
}

run() {
	#echo "[`date`] Run"
	#echo "[`date`] Run" >> ${LOG}

	RUNLOG=sts-${HOSTNAME}-${SLAVES}.log

	echo "pkill java"
	pkill java

	echo "java -Xmx1024M sequential.fourier ${ACDCDATA}/${PROPERTIES} &> ~/${RUNLOG}"
	java -Xmx1024M -cp /public/edangelo/Dropbox/acdc/PFourier.jar:/public/edangelo/Dropbox/acdc/grinda-client.jar:/public/edangelo/Dropbox/acdc/SimpleTupleSpace.jar sequential.fourier ${ACDCDATA}/${PROPERTIES} &> ~/${RUNLOG}

	#echo "[`date`] Run. DONE"
	#echo "[`date`] Run. DONE" >> ${LOG}./scripts/grinda/sts-start-sequential.sh ${ACDCDATA}/${PROPERTIES}
}

copy_output() {
	#echo "[`date`] Copy output files"
	#echo "[`date`] Copy output files" >> ${LOG}

	OUTPUT=${ACDCOUTPUT}/sts.${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}.output.${RUN}

	if [ -e ${OUTPUT} ]
		then
		#echo "[`date`] Delete old copy of ${OUTPUT}"
		#echo "[`date`] Delete old copy of ${OUTPUT}" >> ${LOG}
		rm ${OUTPUT}
	fi

	for RUNLOG in `ls ${HOME}/sts-${HOSTNAME}-${SLAVES}.log`
	do
		echo "[`date`] ${RUNLOG}" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		cat ${RUNLOG} >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		echo "================================================================================" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
	done

	#echo "[`date`] Copy output files. DONE"
	#echo "[`date`] Copy output files. DONE" >> ${LOG}
}

clean() {
	#echo "[`date`] Clean old files"
	#echo "[`date`] Clean old files" >> ${LOG}

	rm ${ACDCDATA}/*
	rm ${HOME}/sts*.log

	#echo "[`date`] Clean old files. DONE"
	#echo "[`date`] Clean old files. DONE" >> ${LOG}
}


## Start execution

check_parameters $@

copy_input

run

copy_output

clean
