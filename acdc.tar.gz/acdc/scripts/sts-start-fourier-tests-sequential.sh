#!/bin/bash --

#constants
ORIGINAL=Original-
REAL=-Real
IMG=-Img
STARTED=STARTED
FINISHED=FINISHED

#directory
PUBLIC=/public/edangelo
ACDCHOME=${PUBLIC}/acdc/sts
ACDCINPUT=${PUBLIC}/acdc-input
ACDCDATA=${PUBLIC}/acdc-data

#files
LOG=${ACDCHOME}/sts-fourier-tests.log
LOCK=/public/edangelo.running


## Start execution
echo ${HOSTNAME} > ${LOCK}

for SIZE in 16777216 1048576 65536
	do
	for SLAVES in sequential
		do
		for FRAMEWORK in FourStep SixStep
			do
			for SALG in Radix2 Radix4
				do
				for RUN in 01 02 03 04 05 06 07 08 09 10
					do
					RUNNAME=${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}.${RUN}
					RESULT=`grep "${RUNNAME} ${FINISHED}" ${LOG}`
					if [ -z "${RESULT}" ]
						then
						echo "[`date`] ${RUNNAME} ${STARTED}"
						echo "[`date`] ${RUNNAME} ${STARTED}" >> ${LOG}

						${HOME}/scripts/grinda/./sts-run-one-fourier-sequential.sh ${FRAMEWORK} ${SALG} ${SIZE} ${SLAVES} ${RUN}

						echo "[`date`] ${RUNNAME} ${FINISHED}"
						echo "[`date`] ${RUNNAME} ${FINISHED}" >> ${LOG}
					fi
				done
			done
		done
	done
done

rm ${LOCK}
