#!/bin/bash --

#constants
TUPLESPACEPORT=4321
MASTERCLASS=parallel.Master
SLAVECLASS=

ORIGINAL=Original-
INPUTPREFIX=
REAL=-Real
IMG=-Img
MAJOR=
FRAMEWORK=
SALG=
SIZE=
SLAVES=
RUN=

#directory
PUBLIC=/public/edangelo
ACDCHOME=${PUBLIC}/acdc/sts
ACDCINPUT=${PUBLIC}/acdc-input
ACDCOUTPUT=${ACDCHOME}/output
ACDCDATA=${PUBLIC}/acdc-data

#files
LOG=${ACDCHOME}/sts-fourier-tests.log
SLAVEPROPERTIES=
MASTERPROPERTIES=


## Funciotns

check_parameters() {
	if [ $# -ne 5 ]
	then
		echo -e ""
		echo -e "$0 <framework> <sequential algorithm> <input size> <slaves> <run>"
		echo -e ""
		echo -e "<framework> puo' essere:"
		echo -e "\t FourStep"
		echo -e "\t SixStep"
		echo -e ""
		echo -e "<sequential algorithm> puo' essere:"
		echo -e "\t Radix2"
		echo -e "\t Radix4"
		echo -e ""
		exit 1
	fi

	FRAMEWORK=$1
	SALG=$2
	SIZE=$3
	SLAVES=$4
	RUN=$5

	INPUTPREFIX=inc${SIZE}
	MASTERPROPERTIES=master.${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}.properties
	SLAVEPROPERTIES=slave.${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}.properties
	if [ ${SALG} = Radix2 ]
		then
		SLAVECLASS=parallel.Radix2Slave
	elif [ ${SALG} = Radix4 ]
		then
		#SLAVECLASS=parallel.Radix4Slave
		SLAVECLASS=parallel.Radix4Slave
	fi

	if [ ${FRAMEWORK} = FourStep ]
		then
		MAJOR=-ColumnMajor
	elif [ ${FRAMEWORK} = SixStep ]
		then
		MAJOR=-RowMajor
	fi
}

copy_input() {
	#echo "[`date`] Copy input files"
	#echo "[`date`] Copy input files" >> ${LOG}

	cp ${ACDCINPUT}/${ORIGINAL}${INPUTPREFIX}${MAJOR}${REAL} ${ACDCDATA}/${INPUTPREFIX}${MAJOR}${REAL}
	cp ${ACDCINPUT}/${ORIGINAL}${INPUTPREFIX}${MAJOR}${IMG} ${ACDCDATA}/${INPUTPREFIX}${MAJOR}${IMG}
	cp ${ACDCINPUT}/${MASTERPROPERTIES} ${ACDCDATA}/${MASTERPROPERTIES}
	cp ${ACDCINPUT}/${SLAVEPROPERTIES} ${ACDCDATA}/${SLAVEPROPERTIES}

	#echo "[`date`] Copy input files. DONE"
	#echo "[`date`] Copy input files. DONE" >> ${LOG}
}

run() {
	#echo "[`date`] Run"
	#echo "[`date`] Run" >> ${LOG}

	./scripts/grinda/sts-start.sh -t ${TUPLESPACEPORT} -m ${MASTERCLASS} ${ACDCDATA}/${MASTERPROPERTIES} -s ${SLAVECLASS} ${ACDCDATA}/${SLAVEPROPERTIES}

	#echo "[`date`] Run. DONE"
	#echo "[`date`] Run. DONE" >> ${LOG}
}

copy_output() {
	#echo "[`date`] Copy output files"
	#echo "[`date`] Copy output files" >> ${LOG}

	OUTPUT=${ACDCOUTPUT}/sts.${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}.output.${RUN}

	if [ -e ${OUTPUT} ]
		then
		#echo "[`date`] Delete old copy of ${OUTPUT}"
		#echo "[`date`] Delete old copy of ${OUTPUT}" >> ${LOG}
		rm ${OUTPUT}
	fi

	for SERVEROUTPUT in `ls ${HOME}/sts*server.log`
	do
		echo "[`date`] ${SERVEROUTPUT}" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		cat ${SERVEROUTPUT} >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		echo "================================================================================" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
	done

	for MASTEROUTPUT in `ls ${HOME}/sts*master.log`
	do
		echo "[`date`] ${MASTEROUTPUT}" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		cat ${MASTEROUTPUT} >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		echo "================================================================================" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
	done

	for SLAVEOUTPUT in `ls ${HOME}/sts*slave.log`
	do
		echo "[`date`] ${SLAVEOUTPUT}" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		cat ${SLAVEOUTPUT} >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		echo "================================================================================" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
		echo "" >> ${OUTPUT}
	done

	#echo "[`date`] Copy output files. DONE"
	#echo "[`date`] Copy output files. DONE" >> ${LOG}
}

clean() {
	#echo "[`date`] Clean old files"
	#echo "[`date`] Clean old files" >> ${LOG}

	rm ${ACDCDATA}/*
	rm ${HOME}/sts*server.log
	rm ${HOME}/sts*master.log
	rm ${HOME}/sts*slave.log

	#echo "[`date`] Clean old files. DONE"
	#echo "[`date`] Clean old files. DONE" >> ${LOG}
}


## Start execution

clean

check_parameters $@

copy_input

run

copy_output

clean
