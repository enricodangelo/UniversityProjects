#!/bin/bash --

FILELIST=`dirname $0`/macchine_ercolani
REQUESTED=
FOUND=0
AVAILABLE=
AVAILABLELIST=${HOME}/sts.hosts
RETVAL=
TEMP=/tmp/tmp-sts.hosts

if [ $# -ne 1 ]
then
	echo "$0 <n slaves>"
	exit 1
fi

REQUESTED=$1

for HOST in `cat ${FILELIST}`
do
	if [ ${HOST} != ${HOSTNAME} ]
	then
		ssh ${HOST} touch /public/edangelo &> /dev/null
		RETVAL=$?
		if [ "${RETVAL}" -eq 0 ]
		then
			let FOUND=${FOUND}+1
			AVAILABLE="${AVAILABLE} ${HOST}"
		fi
		if [ ${FOUND} -eq ${REQUESTED} ]
		then
			RETVAL=0
			break
		fi
	fi
done

if [ ${FOUND} -ne ${REQUESTED} ]
then
	RETVAL=1
fi

echo "${AVAILABLE}" > ${AVAILABLELIST}

sed 's/ /\n/g' ${AVAILABLELIST} | sed '/^$/d' > ${TEMP}
mv ${TEMP} ${AVAILABLELIST}

echo "${FOUND}/${REQUESTED} slaves available"
exit ${RETVAL}