#!/bin/bash --

for SIZE in 65536 1048576 16777216 #268435456 #4294967296
        do
	for ORDER in ColumnMajor RowMajor
		do
		for PART in Real Img
			do
			java -cp ~/Projects/acdc/PFourier/dist/PFourier.jar utils.DataInitializer ${SIZE} ${ORDER} Original-inc${SIZE} ${PART}
		done
	done
done
