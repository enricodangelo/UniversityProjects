#!/bin/bash --

#directory
PUBLIC=/public/edangelo
ACDCHOME=${PUBLIC}/acdc/sts

#files
LOG=${ACDCHOME}/sts-fourier-tests.log
LOCK=/public/edangelo.running

echo "[`date`] rm ${LOCK}"
echo "[`date`] rm ${LOCK}" >> ${LOG}
rm ${LOCK}
echo "[`date`] kill -9 -1"
echo "[`date`] kill -9 -1" >> ${LOG}
kill -9 -1
