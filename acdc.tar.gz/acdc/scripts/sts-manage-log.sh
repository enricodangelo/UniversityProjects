#!/bin/bash --

#directory
ACDCHOME=~/Dropbox
ACDCOUTPUT=${ACDCHOME}/acdc/sts/output
GLOBALOUTPUT=${ACDCHOME}/acdc/sts/results

## Start execution
for SLAVES in sequential.old sequential 2 4 8 12
	do
	for FRAMEWORK in FourStep SixStep
		do
		for SALG in Radix2 Radix4
			do
			for SIZE in 65536 1048576 16777216 #268435456 #4294967296
				do
				CONFIG=${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}
				echo -e "${CONFIG} \c"
				for RUN in 01 02 03 04 05 06 07 08 09 10
					do
					RUNLOG=${ACDCOUTPUT}/sts.${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}.output.${RUN}
					if [ ! -e ${RUNLOG} ]
					then
						echo -e "X \c"
					else
						RUNWCT=`grep WCT ${RUNLOG} | cut -d" " -f2`
						echo -e "${RUNWCT} \c"
						#echo ${RUNWCT} >> ${GLOBALLOG}
					fi
				done
				echo
			done
		done
	done
done
