#!/bin/bash --

#constants
ORIGINAL=Original-
REAL=-Real
IMG=-Img
STARTED=STARTED
FINISHED=FINISHED
TUPLESPACEHOST=${HOSTNAME}
TUPLESPACEPORT=4321

#directory
PUBLIC=/public/edangelo
DROPBOX=${HOME}/Dropbox
ACDCHOME=${DROPBOX}/acdc/sts
ACDCINPUT=${DROPBOX}/acdc-input
ACDCDATA=${DROPBOX}/acdc-data

#files
LOG=${ACDCHOME}/sts-fourier-tests.log


## Funciotns

create_properties() {
	MASTERPROPERTIES=master.${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}.properties
	SLAVEPROPERTIES=slave.${FRAMEWORK}.${SALG}.${SIZE}.${SLAVES}.properties
	INPUTPREFIX=inc${SIZE}

	case ${FRAMEWORK} in
		FourStep)
			FW=3
			MAJOR=-ColumnMajor ;;
		SixStep)
			FW=4
			MAJOR=-RowMajor ;;
	esac

	#master
	echo "filenameReal=${ACDCDATA}/${INPUTPREFIX}${MAJOR}${REAL}" >> ${ACDCINPUT}/${MASTERPROPERTIES}
	echo "filenameImg=${ACDCDATA}/${INPUTPREFIX}${MAJOR}${IMG}" >> ${ACDCINPUT}/${MASTERPROPERTIES}
	echo "forward=true" >> ${ACDCINPUT}/${MASTERPROPERTIES}
	echo "slaves=${SLAVES}" >> ${ACDCINPUT}/${MASTERPROPERTIES}
	echo "FFTFramework=${FW}" >> ${ACDCINPUT}/${MASTERPROPERTIES}
	echo "n=${SIZE}" >> ${ACDCINPUT}/${MASTERPROPERTIES}
	echo "tupleSpaceHost=${TUPLESPACEHOST}" >> ${ACDCINPUT}/${MASTERPROPERTIES}
	echo "tupleSpacePort=${TUPLESPACEPORT}" >> ${ACDCINPUT}/${MASTERPROPERTIES}

	#slave
	echo "tupleSpaceHost=${TUPLESPACEHOST}" >> ${ACDCINPUT}/${SLAVEPROPERTIES}
	echo "tupleSpacePort=${TUPLESPACEPORT}" >> ${ACDCINPUT}/${SLAVEPROPERTIES}
}


## Start execution

#for SIZE in 65536 1048576 16777216 268435456 4294967296
#	do
#	for SLAVES in 2 4 6 8 10 12 14 16
#		do
#		for FRAMEWORK in FourStep SixStep
#			do
#			for SALG in Radix2 Radix4
#				do
#				create_properties
#			done
#		done
#	done
#done

for SIZE in 65536 1048576 16777216
	do
	for SLAVES in 1
		do
		for FRAMEWORK in FourStep SixStep
			do
			for SALG in Radix2 Radix4
				do
				create_properties
			done
		done
	done
done
