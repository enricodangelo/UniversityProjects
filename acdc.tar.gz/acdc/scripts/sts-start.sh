#!/bin/bash --

HOSTS=~/sts.hosts

SERVER=sts.TupleSpaceServer
MASTER=
SLAVE=

SERVERLOG=sts-${HOSTNAME}-server.log
MASTERLOG=sts-${HOSTNAME}-master.log
SLAVELOG=sts-${HOSTNAME}-slave.log

OPTS=`getopt -q -n $0 -o t:s:m: -- "$@"`
RETVAL=$?

if [ ${RETVAL} -ne 0 ]
then
	echo "`basename $0` invalid options"
	exit 1
fi

if [ $# -ne 8 ]
then
	echo "`basename $0` invalid options"
	exit 1
fi

while [ $# -ne 0 ] ; do
	case "$1" in
		-t)
			SERVER="${SERVER} $2" ;
			shift 2 ;
			echo "${SERVER}" ;
			;;
		-s)
			SLAVE="$2 $3" ;
			shift 3 ;
			echo "${SLAVE}" ;
			;;
		-m)
			MASTER="$2 $3"
			shift 3 ;
			echo "${MASTER}" ;
			;;
	esac
done

echo "pkill java su ${HOSTNAME}"
ssh ${HOSTNAME} "pkill java"
ssh ${HOSTNAME} "java -Xmx1024M ${SERVER} &> ~/${SERVERLOG}" &

sleep 3	

for HOST in `cat ${HOSTS}`
do
	SLAVELOG=sts-${HOST}-slave.log
	echo "pkill java su ${HOST}"
	ssh ${HOST} "pkill java"
	ssh ${HOST} "java -Xmx1024M ${SLAVE} &> ~/${SLAVELOG}" &
done

sleep 2

#non ci va & cosi' lo script termina quando anche la computazione termina
ssh ${HOSTNAME} "java -Xmx1024M ${MASTER} &> ~/${MASTERLOG}"
