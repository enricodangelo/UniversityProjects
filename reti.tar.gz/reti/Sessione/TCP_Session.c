/**
\mainpage

<h2> Progetto di Laboratorio di Programmazione di Rete a.a. 2004/05</h2>
\authors <a href="mailto:cbalducc\@cs.unibo.it">Cristiano Balducci</a> <code>[0000138420]</code>\n
<a href="mailto:edangelo\@cs.unibo.it">Enrico D'Angelo</a> <code>[0000139089]</code>\n
<a href="mailto:gmarzocc\@cs.unibo.it">Gino Marzocchi</a> <code>[0000142013]</code>\n
<a href="mailto:pescarin\@cs.unibo.it">Matteo Pescarin</a> <code>[0900023453]</code>


\section obiettivo Obiettivo: Connessione "TCP" Affidabile a Livello Sessione
Si vuole realizzare una libreria di funzioni che implementi uno strato di sessione sopra al livello trasporto del TCP. Questo strato di sessione deve estendere le funzionalit&agrave; delle connessioni TCP permettendo di continuare, in modo nascosto all'applicazione, la trasmissione dei dati a partire dal punto in cui questa si era interrotta. Lo strato di sessione dovr&agrave; essere implementato utilizzando il livello trasporto fornito da TCP.

\section impl Implementazione
\subsection abst Astrazione
L'astrazione della ``connessione con sessione'' <em>(CCS)</em> &egrave; stata rappresentata con una coppia di file descriptor, uno nascosto ed uno pubblico. Il file descriptor pubblico &egrave; quello usato dall'applicazione per comunicare, come un normale socket non cambia durante l'esecuzione del programma, il file descriptor nascosto invece &egrave; il vero socket usato dal nostro livello di sessione per comunicare, il suo valore pu&ograve; cambiare durante l'esecuzione del programma (in maniera trasparente all'applicazione) a causa di crash della connessione.\n
L'insieme di coppie di file descriptor viene mantenuto in una lista globalmente raggiungibili all'interno del livello di sessione. Ogni nodo della lista mantiene, oltre alla coppia di file descriptor, altre informazioni necessarie per l'esecuzione.

\subsection comm Communicazione
Per la gestione della comunicazione lo strato CCS aggiunge un header in testa ad ogni pacchetto e risponde con un ack alla lettura di un pacchetto, vengono inviati anche pacchetti speciali (tipicamente composti da un solo header) per la gestione di alcune fasi particolari della connessione, come la chiusura di un socket, l'instaurazione di una nuova connessione e la ristabilizzazione di una vecchia connessione.

\subsection rw_buffer Buffer di lettura/scrittura
Per ogni socket CCS vengono mantenuti due buffer, implementati con delle liste a politica FIFO, uno per i pacchetti in attesa di ack <em>(wait_ack_buf)</em> ed uno per i pacchetti letti dal livello sessione ma non ancora letti dall'applicazione tramite una read() <em>(not_read_buf)</em>.
\n\n
I nodi della lista wait_ack_buf vengono inseriti in coda ad ogni invio di un pacchetto, prima della chiamata alla send(), e vengono eliminati dalla testa ad ogni ricezione di un ack, la politica FIFO della lista e la garanzia di invio ordinato di TCP garantiscono la corretta gestione degli ack.
\n\n
I nodi della lista not_read_buf vengono inseriti in coda ogni volta che viene letto un pacchetto. La lettura viene fatta da un thread (<em>Read_Loop_Accept</em> dal lato server e <em>Read_Loop_Connect</em> dal lato client) che controlla costantemente lo stato del socket tramite una select(). Ad ogni chiamata della Read() i dati vengono copiati dal buffer, passati al livello soprastante ed eliminati dalla testa della lista, la politica FIFO della lista ne garantisce una corretta gestione.

\subsection comm_rules Ruoli nella comunicazione
Lo strato CCS deve distinguere tra client (chi effettua la connect()) e server (chi effettua la accept()) per la gestione di alcune fasi particolari della connessione, quali la chiusura di un socket e la riconnessione, dal lato server &eacute; inoltre necessario distinguere tra socket listening (socket su cui si &eacute; chiamata la listen()) e socket connessi (socket generati da una accept()).\n
\n
La distinzione viene fatta tramite il campo <em>fd_accept</em> della struttura che rappresenta un socket CCS, il campo viene inizializzato a 0 al momento della creazione di una CCS, successivamente la <em>Accept()</em> setta il campo della CCS su cui &eacute; stata chiamata al valore del suo file descriptor pubblico e la <em>Manage_Accept()</em> setta il campo della CCS appena generata da una accept() al valore del file descriptor pubblico del socket listening da cui &eacute; stata generata. Quando la connessione &eacute; stabilita, i campi sono stati settati correttamente e ci possono essere solo 3 diverse configurazioni:
<ul>
<li><c>fd_pub = fd_accept</c>: file descriptor listening</li>
<li><c>fd_pub = ``n'', fd_accept = ``m''</c>: file descriptor connesso lato server</li>
<li><c>fd_pub = ``n'', fd_accept = 0</c>: file descriptor connesso lato client</li>
</ul>

\subsection new_conn Instaurazione di una nuova connessione
L'instaurazione di una "nuova" connessione avviene tramite l'invio di una richiesta da parte del client ed una risposta da parte del server. Viene prima instaurata una connessione a livello TCP/IP (tramite la chiamata ad accept() e connect()) dopodich&egrave; il client invia un header speciale seguito da file descriptor pubblico della CCS che ha fatto la richiesta <em>(fd_peer)</em>. Il server riceve la richista e acconsente alla connessione solo se &egrave; gi&agrave; stata chiamata l'Accept() sul socket CCS listening corrispondente. In ogni caso il server risponde con un altro header speciale opportunamente creato, sia per confermare la connessione che per negarla.\n
L'fd_peer che il client invia, viene utilizzato dal server al momento della reinstaurazione di una connessione per capire a quale socket CCS si riferisce la richiesta di riconnessione.

\subsection conn_crash Crash della connessione
Come da specifiche ci sono due condizioni che danno luogo ad un crash della connessione:
<ol>
<li>quando una system call (read, write, send, recv, etc.) applicata al socket di quella connessione restituisce un errore ``grave'' che rende non pi&ugrave; utilizzabile quel socket.
<li>quando lo strato di sessione attende un ack per dei dati inviati e tale ack non arriva entro INACTIVITY_TIMEOUT_SECONDS secondi e durante questo periodo di tempo la connessione non riceve altri dati.
</ol>
Per errore ``grave'' si intende:
<ul>
<li>la send() ritorna -1, errno settato a EPIPE o ECONNRESET
<li>la read() ritorna -1, errno settato a ECONNRESET
</ul>
Per come &eacute; stato impostato il progetto il timeout viene considerato solo sulla ricezione dei dati, inoltre dal lato client viene considerato sulla comunicazione di un singolo socket, mentre dal lato server sulla comunicazione di tutti i socket generati dallo stesso socket listening. Per cui non viene individuato un timeout dal lato server se un socket non riceve dati da pi&ugrave; di INACTIVITY_TIMEOUT_SECONDS ma un altro socket generato dallo stesso socket listening sta ricevendo dati o li ha ricevuti da meno di INACTIVITY_TIMEOUT_SECONDS.

\subsection reconn Riconnessione
Una volta riscontrato un crash nella connessione viene chiamata, sia dal lato server che dal lato client, la funzione <em>Manage_CRASH()</em>. Questa funzione chiama a sua volta la <em>Reconnect()</em> che cerca di ristabilire una connessione ad intervalli regolari (RETRY_INTERVAL_SECONDS) per un massimo di RETRY_TIMEOUT_SECONDS secondi, dopodich&eacute; se la comunicazione non &eacute; stata ristabilita il controllo ritorna alla Manage_CRASH e l'applicazione viene terminata.\n
\n
La Reconnect() si comporta diversamente in base al ruolo dell'applicazione, il client tenter&agrave; di effettuare una connect() e di mandare una richiesta di riconnessione e aspetter&agrave; la risposta, mentre il server tenter&agrave; di effettuare una accept(), di leggere una richiesta di riconnessione e di mandare la risposta. Quando la connessione &eacute; avvenuta viene cambiato il file descriptor nascosto di entrambe le parti e la funzione ritorna il controllo alla Manage_CRASH().\n
La Manage_CRASH() a connessione avvenuta controlla se il socket CCS &eacute; stato configurato con l'opzione <em>SO_REUSEADDR</em> e in caso positivo setta la stessa opzione al nuovo file descriptor nascosto, dopodich&eacute; procede alla spedizione di tutti i pacchetti presenti nel buffer wait_ack_buf. In questo modo si &eacute; sicuri che nessun pacchetto venga perso a causa di un crash, anche se l'altro end-system riceve dei pacchetti che in realt&agrave; ha gi&agrave; ricevuto questi vengono riconosciuti grazie al numero di sequenza e scartati.

\subsection ccs_close Chiusura di una CCS
La chiusura di una CCS &eacute; un po' delicata in quanto bisogna essere certi che l'altro end-system sappia della chiusura volontaria della comunicazione e che non tenti quindi di ripristinarla inutilmente, inoltre i socket listening devono essere chiusi solo quando tutti i socket da loro generati sono stati chiusi o non si sar&agrave; pi&ugrave; in grado di ristabilire le connessioni dopo eventuali crash.\n
\n
Quando viene chiamata la <em>Close()</em> quello che viene fatto &eacute; spedire un messaggio di chiusura connessione (header CCS opportunamente settato) e cambiare lo stato del socket in ``CLOSED'', l'altro end-system quando riceve il messaggio cambia lo stato del socket in ``PEER_CLOSED'' e spedisce un ack di chiusura. Solo alla ricezione dell'ack di chiusura lo strato di sessione chiude effettivamente il socket (chiamando la close() sia il file descriptor pubblico che quello nascosto).\n
Caso particolare sono i socket listening, quando la Close() viene chiamata su uno di questi socket lo strato di sessione controlla se i socket generati da questo sono ancora attivi (cio&eacute; se sono in uno stato diverso da CLOSED), se anche uno solo di questi &eacute; ancora attivo allora l'unico effetto della chiamata &eacute; mettere il socket in stato ``ZOMBIE'', che significa appunto che il socket sarebbe chiuso ma potrebbe essere necessario per ristabilirire delle connessioni ancora attive, se invece nessuno di questi &eacute; ancora attivo allora il file descriptor pubblico e nascosto vengono chiusi. In ogni caso non viene spedito nessun pacchetto in quanto il socket non &eacute; in comunicazione con nessun altro socket.\n
A questo punto nasce il problema della gestione dei socket listening in stato ZOMBIE, se il socket in fase di chiusura &eacute; un socket lato server questo controlla se il suo socket listening &eacute; in stato ZOMBIE e se era l'ultimo socket a lui associato ancora attivo, se questo &eacute; il caso allora il socket listening viene chiuso.

\subsection header Formato dei pacchetti
L'Header (di dimensione 12 Byte) dei pacchetti CCS &egrave; composto dai seguenti campi:\n
\li TYPE rappresentato da un \c int , indica il tipo di pacchetto
\li SEQNUM rappresentato da un <c>unsigned int</c>, indica il numero di sequenza del pacchetto
\li SIZE rappresentato da un \c size_t , indica la grandezza del payload che segue l'header, se &egrave; a 0 significa che non c'&egrave; payload.

Lo strato di sessione si avvale dei seguenti tipi di pacchetto:\n
\image latex messaggio_dati.eps "Pacchetto per l'invio dati"
\image latex messaggio_ACK.eps "Pacchetto per l'invio di un ack"
\image latex messaggio_END.eps "Pacchetto per notificare la chiusura volontaria della connessione"
\image latex messaggio_ACK_END.eps "Pacchetto di risposta alla chiusura volontaria della connessione"
\image latex messaggio_CON.eps "Pacchetto per la richiesta di una nuova connessione"
\image latex messaggio_RECON.eps "Pacchetto per la richiesta di riconnessione"
\image latex messaggio_CON_EST.eps "Pacchetto di notifica di avvenuta connessione"
\image latex messaggio_CON_NOT_EST.eps "Pacchetto di notifica di NON avvenuta connessione"

\section tcp_h Codice sorgente per TCP_Session.h
\include TCP_Session.h

\section tcp_c Codice sorgente per TCP_Session.c
\include TCP_Session.c

\section fdl_h Codice sorgente per fd_list.h
\include fd_list.h

\section fdl_c Codice sorgente per fd_list.c
\include fd_list.c

\section utils_h Codice sorgente per CCS_Utils.h
\include CCS_Utils.h
*/

#define __TCP_SESSION_C__

#include "TCP_Session.h"

#include<netinet/in.h>
#include<arpa/inet.h>

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <sys/ioctl.h>
#include <pthread.h>

#include "CCS_Utils.h"
#include "fd_list.h"


pthread_mutex_t *fd_list_lock;			/* mutex per fd_list */
FD_LIST *fd_list;		 		/* inizializzo la lista dei file descriptor pubblici e privati */

int Init_TCP_Session_Module(void *ptr) {
	pthread_mutexattr_t fast;	/* attributo per le mutex */

	#ifdef VERBOSE
	printf("[Init_TCP_Session_Module]\n");
	fflush(stdout);
	#endif

	if ((fd_list = (FD_LIST *)malloc(sizeof(FD_LIST))) == NULL) {
		fprintf(stderr, "Init_TCP_Session_Module(), \
				impossibile allocare memoria per fd_list\n");
		return(0);
	}

	fd_list->first = NULL;
	fd_list->last = NULL;

	if ((fd_list_lock = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t))) == NULL) {
		fprintf(stderr, "Init_TCP_Session_Module(), \
				impossibile allocare memoria per fd_list\n");
		return(0);
	}

	pthread_mutexattr_init(&fast);

	if (pthread_mutex_init(fd_list_lock, &fast) != 0) {
		fprintf(stderr, "Init_TCP_Session_Module() Err: %d \"%s\"\n", \
				errno, strerror(errno));
		return(0);
	}

	pthread_mutexattr_destroy(&fast);
		
	return (1);
}

int Socket(int domain, int type, int protocol) {
	#ifdef VERBOSE
	printf("[Socket]\n");
	fflush(stdout);
	#endif

	return(socket(domain, type, protocol));
}

int TCP_Session_IPv4_Socket(void) {
	int fd_pub, fd_hide;	

	#ifdef VERBOSE
	printf("[TCP_Session_IPv4_Socket]\n");
	fflush(stdout);
	#endif

	ReserveFileDescriptor(&fd_pub);	
	if ((fd_hide = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stderr, "TCP_Session_IPv4_Socket() Err: %d \"%s\"\n", \
				errno, strerror(errno));
		return (fd_hide);
	}
	
	/* aggiungo i file descriptor alla lista */
	fd_insert_item(fd_list, fd_pub, fd_hide, fd_list_lock);

	#ifdef VVERBOSE
	printf("[TCP_Session_IPv4_socket] Creata coppia di fd: pub = %d, hide = %d\n", \
			fd_pub, fd_hide);
	fflush(stdout);
	#endif

	return (fd_pub);
}

int SetsockoptReuseAddr(int s) {
	int OptVal, ris;
	int fd_hide;

	if (fd_member(fd_list, s, fd_list_lock)) {
		fd_hide = fd_extract_fd_hide(fd_list, s, fd_list_lock);

		#ifdef VERBOSE
		printf("[SetsockoptReuseAddr] CCS\n");
		fflush(stdout);
		#endif

		#ifdef VVERBOSE
		printf("[SetsockoptReuseAddr] pub = %d, hide = %d\n", s, fd_hide);
		fflush(stdout);
		#endif

		/* avoid EADDRINUSE error on bind() */
		OptVal = 1;
		ris = setsockopt(fd_hide, SOL_SOCKET, SO_REUSEADDR, (char *)&OptVal, sizeof(OptVal));
		if (ris != 0 ) {
			fprintf (stderr, "setsockopt(), SO_REUSEADDR failed, Err: %d \"%s\"\n", errno,\
					strerror(errno));
			return(0);
		}
		else {
			/* salvo le opzioni del socket */
			fd_insert_reuseaddr(fd_list, s, OptVal, fd_list_lock);
			return(1);
		}
	}
	else {
		#ifdef VERBOSE
		printf("[SetsockoptReuseAddr] non CCS\n");
		fflush(stdout);
		#endif

		/* avoid EADDRINUSE error on bind() */
		OptVal = 1;
		ris = setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *)&OptVal, sizeof(OptVal));
		if (ris != 0 ) {
			fprintf (stderr, "setsockopt(), SO_REUSEADDR failed, Err: %d \"%s\"\n", \
					errno,strerror(errno));
			return(0);
		}
		else {
			return(1);
		}
	}
}

int GetsockoptReuseAddr(int s, int *pFlag) {
	int OptVal, ris;
	socklen_t OptLen;
	int fd_hide;

	if (fd_member(fd_list, s, fd_list_lock)) {
		fd_hide = fd_extract_fd_hide(fd_list, s, fd_list_lock);

		#ifdef VERBOSE
		printf("[GetsockoptReuseAddr] CCS\n");
		fflush(stdout);
		#endif

		#ifdef VVERBOSE
		printf("[GetsockoptReuseAddr] pub = %d, hide = %d\n", s, fd_hide);
		fflush(stdout);
		#endif

		ris = getsockopt(fd_hide, SOL_SOCKET, SO_REUSEADDR, (char *)&OptVal, &OptLen );
		if (ris != 0 ) {
			fprintf (stderr, "getsockopt(), SO_REUSEADDR failed, Err: %d \"%s\"\n", \
					errno,strerror(errno));
			fflush(stdout);
			return(0);
		}
		else {
			*pFlag=OptVal;
			/* controllo di coerenza */
			if (fd_extract_reuseaddr(fd_list, s, fd_list_lock) != *pFlag) {
				fprintf(stderr, "GetsockoptReuseAddr() \
					Err: Incoerenza di opzioni sul fd %d (%d)\n", s, fd_hide);
				exit(-1);
			}
			return(1);
		}
	}
	else {
		#ifdef VERBOSE
		printf("[GetsockoptReuseAddr] non CCS\n");
		fflush(stdout);
		#endif

		ris = getsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *)&OptVal, &OptLen );
		if (ris != 0 ) {
			fprintf (stderr, "getsockopt(), SO_REUSEADDR failed, Err: %d \"%s\"\n", \
					errno,strerror(errno));
			fflush(stdout);
			return(0);
		}
		else {
			*pFlag=OptVal;
			return(1);
		}
	}
}

int SetNoBlocking(int s) {
	int flags;
	
	#ifdef VERBOSE
	printf("[SetNoBlocking]\n");
	fflush(stdout);
	#endif

	if ( (flags=fcntl(s,F_GETFL,0)) <0 ) {
		fprintf (stderr, "fcntl(F_GETFL) failed, Err: %d \"%s\"\n", errno,strerror(errno));
		return(0);
	}
	flags |= O_NONBLOCK; 
	if ( fcntl(s,F_SETFL,flags) <0 ) {
		fprintf (stderr, "fcntl(F_SETFL) failed, Err: %d \"%s\"\n", errno,strerror(errno));
		return(0);
	}
	return(1);
}

int SetBlocking(int s) {
	int flags;
	
	#ifdef VERBOSE
	printf("[SetBlocking]\n");
	fflush(stdout);
	#endif

	if ( (flags=fcntl(s,F_GETFL,0)) <0 ) {
		fprintf (stderr, "fcntl(F_GETFL) failed, Err: %d \"%s\"\n", errno,strerror(errno));
		return(0);
	}
	flags &= (~O_NONBLOCK);
	if ( fcntl(s,F_SETFL,flags) <0 ) {
		fprintf (stderr, "fcntl(F_SETFL) failed, Err: %d \"%s\"\n", errno,strerror(errno));
		return(0);
	}
	return(1);
}

int IsBlocking(int s, int *pIsBlocking) {
	int flags;
	
	#ifdef VERBOSE
	printf("[IsBlocking]\n");
	fflush(stdout);
	#endif

	if ( (flags=fcntl(s,F_GETFL,0)) <0 ) {
		fprintf (stderr, "fcntl(F_GETFL) failed, Err: %d \"%s\"\n", errno,strerror(errno));
		return(0);
	}
	flags &= O_NONBLOCK;
	/* ora flags e' diverso da zero se il socket e' NON bloccante */ 
	if(flags)	*pIsBlocking=0;
	else		*pIsBlocking=1;
	return(1);
}

int Bind(int sockfd, struct sockaddr *my_addr, socklen_t addrlen) {
	int sockfd_hide, returnvalue;

	if (fd_member(fd_list, sockfd, fd_list_lock)) {
		sockfd_hide = fd_extract_fd_hide(fd_list, sockfd, fd_list_lock);

		#ifdef VERBOSE
		printf("[Bind] CCS\n");
		fflush(stdout);
		#endif

		#ifdef VVERBOSE
		printf("[Bind] pub = %d, hide = %d\n", sockfd, sockfd_hide);
		fflush(stdout);
		#endif

		/* inserisco addr e addrlen nella lista */
		fd_insert_addr(fd_list, sockfd, *my_addr, addrlen, fd_list_lock);

		if ((returnvalue = bind(sockfd_hide, my_addr, addrlen)) < 0) {
			fprintf(stderr, "Bind() Err: %d \"%s\"\n", errno, strerror(errno));
			return (returnvalue);
		}
	}
	else {
		#ifdef VERBOSE
		printf("[Bind] non CCS\n");
		fflush(stdout);
		#endif

		returnvalue = bind(sockfd, my_addr, addrlen);
	}
	return (returnvalue);
}

int Listen(int s, int backlog) { 
	int fd_hide, returnvalue;

	if (fd_member(fd_list, s, fd_list_lock)) {
		fd_hide = fd_extract_fd_hide(fd_list, s, fd_list_lock);

		#ifdef VERBOSE
		printf("[Listen] CCS\n");
		fflush(stdout);
		#endif
	
		#ifdef VVERBOSE
		printf("[Listen] pub = %d, hide = %d\n", s, fd_hide);
		fflush(stdout);
		#endif
		
		if ((returnvalue = listen (fd_hide, backlog)) < 0 ) {
			fprintf(stderr, "Listen() Err: %d \"%s\"\n", errno, strerror(errno));
			return (returnvalue);
		}
	}
	else {
		#ifdef VERBOSE
		printf("[Listen] non CCS\n");
		fflush(stdout);
		#endif

		returnvalue = listen (s, backlog);
	}
	return (returnvalue);
}

int Accept(int s, struct sockaddr *addr, socklen_t *addrlen) {
	int fd_hide, returnvalue, new_fd_pub;

	if (fd_member(fd_list, s, fd_list_lock)) {	/* connessione con sessione */
		fd_hide = fd_extract_fd_hide(fd_list, s, fd_list_lock);
		pthread_attr_t joinable;
		int state;
		int *par;
		pthread_t thread;

		state = fd_extract_state(fd_list, s, fd_list_lock);
		if ((state == CLOSED) || (state == ZOMBIE)) {
			errno = 9;	/* EBADF */
			return(-1);
		}

		#ifdef VERBOSE
		printf("[Accept] CCS\n");
		fflush(stdout);
		#endif
		
		#ifdef VVERBOSE
		printf("[Accept] pub = %d, hide = %d\n", s, fd_hide);
		fflush(stdout);
		#endif

		fd_insert_fd_accept(fd_list, s, s, fd_list_lock);

		/* lancio il thread se gia' non attivo per questo socket */
		if ((thread = fd_extract_thread(fd_list, s, fd_list_lock)) == 0) {
			/* inizializzo l'attributo del thread */
			if (pthread_attr_init(&joinable) != 0) {
				fprintf(stderr, "Init_TCP_Session_Module() Err: %d \"%s\"\n", \
						errno, strerror(errno));
				exit(-1);
			}
			/* setto lo stato dell'attributo del thread */
			if (pthread_attr_setdetachstate(&joinable, PTHREAD_CREATE_JOINABLE) != 0) {
				fprintf(stderr, "Init_TCP_Session_Module() Err: %d \"%s\"\n", \
						errno, strerror(errno));
				exit(-1);
			}

			/* creo il thread che eseguira' Read_Loop_Accept */
			if ((par = (int *)malloc(sizeof(int))) == NULL) {
				fprintf(stderr, "Accept(), impossibile allocare memoria \
						per il parametro di Read_Loop_Accept");
				exit(-1);
			}
			*par = s;
			pthread_create(&thread, &joinable, Read_Loop_Accept, (void *)par);

			fd_insert_thread(fd_list, s, thread, fd_list_lock);

			/* libero le risorse usate da joinable */
			if (pthread_attr_destroy(&joinable) != 0) {
				fprintf(stderr, "Init_TCP_Session_Module() Err: %d \"%s\"\n", \
						errno, strerror(errno));
				exit(-1);
			}
		}
		
		/* incremento il numero delle richieste */
		fd_inc_naccept(fd_list, s, fd_list_lock);

		/* attendo cha la accept vada a buon fine */
		fd_cond_accept_wait(fd_list, s, fd_list_lock);

		/* estraggo il nuovo fd pubblico e risetto fd_accept al valore giusto */
		new_fd_pub = fd_extract_fd_accept(fd_list, s, fd_list_lock);
		
		fd_insert_fd_accept(fd_list, s, s, fd_list_lock);
		
		fd_insert_thread(fd_list, new_fd_pub, thread, fd_list_lock);

		#ifdef VVERBOSE
		printf("[Accept] fd_pub = %d, new_fd_pub = %d\n", s, new_fd_pub);
		fflush(stdout);
		#endif

		returnvalue = new_fd_pub;
	}
	else {
		#ifdef VERBOSE
		printf("[Accept] non CCS\n");
		fflush(stdout);
		#endif

		returnvalue = accept(s, addr, addrlen);
	}
	return (returnvalue);
}

int Connect(int sockfd, const struct sockaddr *serv_addr, socklen_t addrlen) {
	int sockfd_hide, returnvalue;

	if (fd_member(fd_list, sockfd, fd_list_lock)) {
		sockfd_hide = fd_extract_fd_hide(fd_list, sockfd, fd_list_lock);
		pthread_t thread;
		/* attributi per la creazione di thread */
		pthread_attr_t joinable;	
		int *par;
		char *msg;
		int type;
		int fd_peer;
		size_t msg_size;
		short int ok = 0;

		#ifdef VERBOSE
		printf("[Connect] pub = %d, hide = %d\n", sockfd, sockfd_hide);
		fflush(stdout);
		#endif
		
		if ((returnvalue = connect(sockfd_hide, serv_addr, addrlen)) < 0) {
			fprintf(stderr, "Connect() Err: %d \"%s\"\n", errno, strerror(errno));
			return (returnvalue);
		}

		/* manda richiesta di connessione */
		if ((msg = (char *)malloc(CCS_HEADER_SIZE + sizeof(int))) == NULL) {
			fprintf(stderr, "Connect(), impossibile allocare memoria per msg");
			exit(-1);
		}
		Pkt_Craft(CONNECTION, 0, sizeof(int), &sockfd, msg);

		CCS_Sendn(sockfd_hide, msg, CCS_HEADER_SIZE + sizeof(int), 0);
		
		do {
			struct timeval timeout;
			fd_set read_set;

			timeout.tv_sec = WAIT_TIME;
			timeout.tv_usec = 0;
			FD_ZERO(&read_set);
			FD_SET(sockfd_hide, &read_set);
			
			if (select(sockfd_hide + 1, &read_set, NULL, NULL, &timeout) < 0) {
				fprintf(stderr, "Connect, select() Err: %d \"%s\"\n", errno, \
						strerror(errno));
				exit(-1);
			}
			if (FD_ISSET(sockfd_hide, &read_set)) {
				CCS_Readn(sockfd_hide, msg, CCS_HEADER_SIZE);
				ok = 1;
			}
		} while (!ok);

		memcpy(&type, msg, sizeof(int));

		free(msg);
		
		if (type != CONNECTION_ESTABLISHED) {
			errno = ECONNREFUSED; /* 111 */
			return(-1);
		}

		/* inserisco addr e addrlen nella lista */
		fd_insert_addr(fd_list, sockfd, *serv_addr, addrlen, fd_list_lock);

		/* setto lo stato del socket */
		fd_insert_state(fd_list, sockfd, CONNECTED, fd_list_lock);

		/* inizializzo l'attributo del thread */
		if (pthread_attr_init(&joinable) != 0) {
			fprintf(stderr, "Init_TCP_Session_Module() Err: %d \"%s\"\n", \
					errno, strerror(errno));
			exit(-1);
		}
		/* setto lo stato dell'attributo del thread */
		if (pthread_attr_setdetachstate(&joinable, PTHREAD_CREATE_JOINABLE) != 0) {
			fprintf(stderr, "Init_TCP_Session_Module() Err: %d \"%s\"\n", \
					errno, strerror(errno));
			exit(-1);
		}

		/* creo il thread che eseguirà Read_Loop_Connect */
		if ((par = (int *)malloc(sizeof(int))) == NULL) {
			fprintf(stderr, "Connect(), impossibile allocare memoria \
					per il parametro di Read_Loop_Connect");
			exit(-1);
		}
		*par = sockfd;
		pthread_create(&thread, &joinable, Read_Loop_Connect, (void *)par);

		fd_insert_thread(fd_list, sockfd, thread, fd_list_lock);

		/* libero le risorse usate da joinable */
		if (pthread_attr_destroy(&joinable) != 0) {
			fprintf(stderr, "Init_TCP_Session_Module() Err: %d \"%s\"\n", \
					errno, strerror(errno));
			exit(-1);
		}
	}
	else {
		#ifdef VERBOSE
		printf("[Connect] non CCS\n");
		fflush(stdout);
		#endif

		returnvalue = connect(sockfd, serv_addr, addrlen);
	}
	return(returnvalue);
}

ssize_t	Read(int fd, void *buf, size_t count) {
	int fd_hide;
	ssize_t returnvalue;

	if (fd_member(fd_list, fd, fd_list_lock)) {
		fd_hide = fd_extract_fd_hide(fd_list, fd, fd_list_lock);

		#ifdef VERBOSE
		printf("[Read] CCS\n");
		fflush(stdout);
		#endif

		#ifdef VVERBOSE
		printf("[Read] pub = %d, hide = %d\n", fd, fd_hide);
		fflush(stdout);
		#endif

		returnvalue = Read_From_Buffer(fd, fd_hide, buf, count);
	}
	else {
		#ifdef VERBOSE
		printf("[Read] non CCS\n");
		fflush(stdout);
		#endif

		returnvalue = read(fd, buf, count);
	}
	return(returnvalue);
}

ssize_t	Write(int fd, const void *buf, size_t count) {
	int fd_hide;
	ssize_t returnvalue;	

	if (fd_member(fd_list, fd, fd_list_lock)) {	/* CCS SOCKET */
		fd_hide = fd_extract_fd_hide(fd_list, fd, fd_list_lock);

		#ifdef VERBOSE
		printf("[Write] CCS\n");
		fflush(stdout);
		#endif

		#ifdef VVERBOSE
		printf("[Write] pub = %d, hide = %d\n", fd, fd_hide);
		fflush(stdout);
		#endif

		if ((returnvalue = Real_Send(fd, fd_hide, buf, count, 0)) < 0) {
			fprintf(stderr, "Write() Err: %d \"%s\"\n", errno, strerror(errno));
			return (returnvalue);
		}
		#ifdef VVERBOSE
		printf("[Write] fd_pub = %d, count = %d, returnvalue = %d\n", fd, count, returnvalue);
		#endif
	}
	else {	/* NON CCS SOCKET */
		#ifdef VERBOSE
		printf("[Write] non CCS\n");
		fflush(stdout);
		#endif

		#ifdef VVERBOSE
		printf("[Write] fd = %d\n", fd);
		#endif
		returnvalue = write(fd, buf, count);
	}
	return(returnvalue);
}

int Send(int fd, const void *buf, size_t count, int flags) {
	int fd_hide;
	ssize_t returnvalue;

	if (fd_member(fd_list, fd, fd_list_lock)) {
		fd_hide = fd_extract_fd_hide(fd_list, fd, fd_list_lock);

		#ifdef VERBOSE
		printf("[Send] CCS\n");
		fflush(stdout);
		#endif

		#ifdef VVERBOSE
		printf("[Send] pub = %d, hide = %d\n", fd, fd_hide);
		fflush(stdout);
		#endif

		printf("[Send] fd = %d, count = %d\n", fd, count);
		if ((returnvalue = Real_Send(fd, fd_hide, buf, count, flags)) < 0) {
			fprintf(stderr, "Send() Err: %d \"%s\"\n", errno, strerror(errno));
			return (returnvalue);
		}
	}
	else {
		#ifdef VERBOSE
		printf("[Send] non CCS\n");
		fflush(stdout);
		#endif

		#ifdef VVERBOSE
		printf("[Send] fd = %d\n", fd);
		#endif
		returnvalue = send(fd, buf, count, flags);
	}
	return(returnvalue);
}

int AvailableBytes(int s, int *pnum) {
	int bytes;
	
	#ifdef VERBOSE
	printf("[AvailableBytes]\n");
	fflush(stdout);
	#endif
	if (fd_member(fd_list, s, fd_list_lock)) {
		*pnum = fd_available_bytes(fd_list, s, fd_list_lock);
		return (0);
	}
	else {
		if (ioctl (s,FIONREAD,pnum)==0) {
			return(1);
		}
		else {
			return(0);
		}
	}
}

int Select(int n, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, struct timeval *timeout) {
	#ifdef VERBOSE
	printf("[Select]\n");
	fflush(stdout);
	#endif
	
	return(select(n,readfds,writefds,exceptfds,timeout));
}

int Close(int fd) {
	int returnvalue, fd_hide, fd_accept;
	char *msg;
	pthread_t thread;
	ssize_t sendnreturn;	/* DEBUG */

	if (fd_member(fd_list, fd, fd_list_lock)) {
		fd_hide = fd_extract_fd_hide(fd_list, fd, fd_list_lock);

		#ifdef VERBOSE
		printf("[Close] pub = %d, hide = %d\n", fd, fd_hide);
		fflush(stdout);
		#endif
		
		fd_accept = fd_extract_fd_accept(fd_list, fd, fd_list_lock);
		#ifdef VVERBOSE
		printf("[Close] fd_pub = %d, fd_accept = %d\n", fd, fd_accept);
		#endif
		if (fd_accept != fd) {	/* socket non listening */
			if (fd_extract_state(fd_list, fd, fd_list_lock) != PEER_CLOSED) {
				if ((msg = (char *)malloc(CCS_HEADER_SIZE)) == NULL) {
					fprintf(stderr, "Close() Impossibile allocare memoria per msg");
					exit(-1);
				}
				
				Pkt_Craft(END, 0, 0, NULL, msg);

				sendnreturn = CCS_Sendn(fd_hide, msg, CCS_HEADER_SIZE, 0);
				while (sendnreturn == RW_CRASH) {
					Manage_CRASH(fd);
					fd_hide = fd_extract_fd_hide(fd_list, fd, fd_list_lock);
					sendnreturn = CCS_Sendn(fd_hide, msg, CCS_HEADER_SIZE, 0);
				}

				free(msg);
			}
			else {
				if ((returnvalue = close(fd_hide)) < 0) {
					fprintf(stderr, "Close() Err: %d \"%s\"\n", errno, \
							strerror(errno));
					return (returnvalue);
				}
				if ((returnvalue = close(fd)) < 0) {
					fprintf(stderr, "Close() Err: %d \"%s\"\n", errno, \
							strerror(errno));
					return (returnvalue);
				}
			}
			
			/* modifico lo stato del socket */
			fd_insert_state(fd_list, fd, CLOSED, fd_list_lock);

			/* se questo e' l'ultimo socket connesso associato 
				e fd_accept e questo e' in stato ZOMBIE lo chiudo */
			if ((fd_accept != 0) && \
					fd_no_more_connections(fd_list, fd_accept, fd_list_lock) && 
					(fd_extract_state(fd_list, fd_accept, fd_list_lock) == ZOMBIE)) {
				int fd_accept_hide = fd_extract_fd_hide(fd_list, fd_accept, \
							fd_list_lock);
				
				if ((returnvalue = close(fd_accept_hide)) < 0) {
					fprintf(stderr, "Close() Err: %d \"%s\"\n", errno, \
							strerror(errno));
					return (returnvalue);
				}
				if ((returnvalue = close(fd_accept)) < 0) {
					fprintf(stderr, "Close() Err: %d \"%s\"\n", errno, \
							strerror(errno));
					return (returnvalue);
				}
			}
		}
		else {	/* socket listening */
			if (fd_no_more_connections(fd_list, fd, fd_list_lock)) {	
				/* non ci sono piu' socket connessi relativi a questo socket listening
				   modifico lo stato del socket */
				fd_insert_state(fd_list, fd, CLOSED, fd_list_lock);
				
				if ((returnvalue = close(fd_hide)) < 0) {
					fprintf(stderr, "Close() Err: %d \"%s\"\n", errno, \
							strerror(errno));
					return (returnvalue);
				}
				if ((returnvalue = close(fd)) < 0) {
					fprintf(stderr, "Close() Err: %d \"%s\"\n", errno, \
							strerror(errno));
					return (returnvalue);
				}
			}
			else {	/* ci sono ancora socket connessi 
					relativi a questo socket listening */
				fd_insert_state(fd_list, fd, ZOMBIE, fd_list_lock);
			}
		}
	}
	else {
		#ifdef VERBOSE
		printf("[Close] non CCS\n");
		fflush(stdout);
		#endif

		returnvalue = close(fd);
	}
	return(returnvalue);
}

int CloseWait(int fd, int seconds) {
	int ris, myerrno;
	struct linger lin;
	
	#ifdef VERBOSE
	printf("CloseWait(%d) ... \n",fd);
	fflush(stdout);
	#endif
	lin.l_onoff=1;
	lin.l_linger=seconds;
	ris = setsockopt(fd, SOL_SOCKET, SO_LINGER, (char *)&lin, sizeof(lin));
	myerrno=errno;
	if (ris != 0 )  
	{
		fprintf (stderr, "setsockopt() SO_LINGER failed, Err: %d \"%s\"\n", \
				errno,strerror(errno));
		errno=myerrno;
		return(-1);
	}
	ris=close(fd);
	myerrno=errno;
	#ifdef VERBOSE
	printf("fine CloseWait(%d)\n",fd);
	if(ris==0) printf("connessione chiusa correttamente: dati spediti\n");
	else printf("timeout scaduto, connessione non chiusa correttamente\n");
	fflush(stdout);
	#endif
	errno=myerrno;
	return(ris);
}

int CloseWait_TCP_Session_Module(void *ptr, struct timeval *timeout) { 
	return(1);
}

int Close_TCP_Session_Module(void *ptr) { 
	struct custom_fd_set custom_fds;
	fd_set fds;
	pthread_t thread;
	int max, fd, fd_hide, cancelreturn=0;

	#ifdef VERBOSE
	printf("[Close_TCP_Session_Module]\n");
	fflush(stdout);
	#endif

	if (fd_list == NULL) {	/* Close_TCP_Session_Module o CloseWait_TCP_Session_Module 
					e' gia' stata chiamata una volta */
		return(0);
	}
	
	custom_fds = fd_extract_all_fd_pub(fd_list, fd_list_lock);
	fds = custom_fds.set;
	max = custom_fds.max;

	for (fd = 0; fd < max; fd++) {
		if (FD_ISSET(fd, &fds)) {
			fd_hide = fd_extract_fd_hide(fd_list, fd, fd_list_lock);
			
			thread = fd_extract_thread(fd_list, fd, fd_list_lock);
			cancelreturn = pthread_cancel(thread);
			if ((cancelreturn != 0) && (cancelreturn != ESRCH)) {
				fprintf(stderr, "pthread_cancel() Err: %d \"%s\"\n", \
					cancelreturn, strerror(cancelreturn));
				exit(-1);
			}
			
			#ifdef VVERBOSE
			printf("[Close_TCP_Session_Module] Removing item %d (%d)...\n", fd, fd_hide);
			#endif

			fd_remove_item(fd_list, fd, fd_list_lock);
			
			#ifdef VVERBOSE
			printf("[Close_TCP_Session_Module] Rimosso item %d (%d)\n", fd, fd_hide);
			#endif
		}
	}
	
	if (pthread_mutex_destroy(fd_list_lock) != 0) {
		fprintf(stderr, "Close_TCP_Session_Module(): Err: pthread_mutex_destroy failed\n");
		return(0);
	}
	free(fd_list_lock);
	fd_list_lock = NULL;
	free(fd_list);
	fd_list = NULL;

	return(1);
}

int ReserveFileDescriptor(int *pfd) {
	int fd;
	
	#ifdef VERBOSE
	printf("[ReserveFileDescriptor]\n");
	fflush(stdout);
	#endif
	
	fd=open("/dev/null", O_RDONLY);
	if(fd>=0) 
	{
		*pfd=fd;
		return(1);
	}
	else
	{
		return(0);
	}
}


/* Funzioni ausiliarie */

void *Read_Loop_Accept(void *par) {
	int *p = par;
	int fd_accept;
	int returnvalue;
	int current_timeout = 0;
	struct custom_fd_set c_read_set;
	fd_set read_set;
	int max;

	fd_accept = *p;
	free(par);

	#ifdef VERBOSE
	printf("[Read_Loop_Accept] fd_accept = %d\n", fd_accept);
	fflush(stdout);
	#endif

	while (1) {
		/* estraggo tutti i fd_hide con lo stesso fd_accept */
		FD_ZERO(&read_set);
		c_read_set = fd_extract_fd_hide_set(fd_list, fd_accept, fd_list_lock);
		read_set = c_read_set.set;
		max = c_read_set.max;

		#ifdef VVERBOSE
		int n;
		for (n = 0; n < max; n++) {
			if (FD_ISSET(n, &read_set)) {
				printf("[Read_Loop_Accept] accept = %d, hide = %d\n",fd_accept, n);
				fflush(stdout);
			}
		}
		#endif

		returnvalue = Try_To_Read(read_set, max);
		if (returnvalue == 0) {
			current_timeout += WAIT_TIME;
			if (current_timeout == INACTIVITY_TIMEOUT_SECONDS) {
				/* CRASH per timeout */
				#ifdef VVERBOSE
				printf("[Read_Loop_Accept] timeout, CRASH di connessione, \
					fd_accept = %d\n", fd_accept);
				#endif
				
				int n;
				int fd_pub;
				for (n = 0; n < max; n++) {
					if (FD_ISSET(n, &read_set)) {
						fd_pub = fd_extract_fd_pub(fd_list, n, fd_list_lock);
						if (fd_pub != fd_accept) {
							Manage_CRASH(fd_pub);
						}
					}
				}
			}
		}
		else {
			current_timeout = 0;
		}
	}
}

void *Read_Loop_Connect(void *par) {
	int *p = par;
	int fd_pub, fd_hide;
	int state;
	int returnvalue;
	int current_timeout = 0;
	fd_set read_set;

	fd_pub = *p;
	free(par);

	#ifdef VERBOSE
	printf("[Read_Loop_Connect] pub = %d\n", fd_pub);
	fflush(stdout);
	#endif

	while (1) {
		fd_extract_state(fd_list, fd_pub, fd_list_lock);
		if ((state == CLOSED) || (state == PEER_CLOSED)) {
			pthread_exit(NULL);
		}
		FD_ZERO(&read_set);
		fd_hide = fd_extract_fd_hide(fd_list, fd_pub, fd_list_lock);
		FD_SET(fd_hide, &read_set);

		#ifdef VVERBOSE
		printf("[Read_Loop_Connect] pub = %d, hide = %d\n", fd_pub, fd_hide);
		fflush(stdout);
		#endif

		returnvalue = Try_To_Read(read_set, fd_hide + 1);
		if (returnvalue == 0) {
			current_timeout += WAIT_TIME;
			if (current_timeout == INACTIVITY_TIMEOUT_SECONDS) {	
				/* CRASH per timeout */
				#ifdef VVERBOSE
				printf("[Read_Loop_Connect] timeout, CRASH di connessione, \
					fd_pub = %d\n", fd_pub);
				#endif
				Manage_CRASH(fd_pub);
			}
		}
		else {
			current_timeout = 0;
		}
	}
}

int Try_To_Read(fd_set read_set, int max) {
	struct timeval timeout;
	int available_bytes;
	int returnvalue;
	int fd;
	int fd_pub;
	int fd_accept;
	char *header = NULL;

	timeout.tv_sec = WAIT_TIME;
	timeout.tv_usec = 0;

	#ifdef VVERBOSE
	int n;
		for (n = 0; n < max; n++) {
			if (FD_ISSET(n, &read_set)) {
				printf("[Try_To_Read] controllo fd_hide = %d\n", n);
				fflush(stdout);
			}
		}
		printf("[Try_To_Read] max = %d\n", max);
	#endif

	if ((returnvalue = select(max, &read_set, NULL, NULL, &timeout)) < 0) {
		fprintf(stderr, "select() Err: %d \"%s\"\n", errno, strerror(errno));
		exit(-1);
	}
	if (returnvalue == 0) {
		return(0);
	}
	else {
		for (fd = 0; fd < max; fd++) {
			if (FD_ISSET(fd, &read_set)) {
				fd_pub = fd_extract_fd_pub(fd_list, fd, fd_list_lock);
				
				if (fd_pub == 0) {
					continue;
				}
				
				fd_accept = fd_extract_fd_accept(fd_list, fd_pub, fd_list_lock);
				
				if (fd_pub == fd_accept) {
					Manage_Accept(fd_pub);
					
					fd_cond_accept_signal(fd_list, fd_pub, fd_list_lock);
				}
				else {
					Read_Packet(fd_pub, fd);
				}
			}
		}
	}
	return(1);
}

void Manage_Accept(int fd_pub) {
	int fd_hide = fd_extract_fd_hide(fd_list, fd_pub, fd_list_lock);
	int new_fd_pub, new_fd_hide, fd_peer;
	struct sockaddr addr = fd_extract_addr(fd_list, fd_pub, fd_list_lock);
	socklen_t addrlen = fd_extract_addrlen(fd_list, fd_pub, fd_list_lock);
	pthread_t thread;
	pthread_attr_t joinable;	/* attributi per la creazione di thread */
	char *msg;
	int type, msg_size;
	int naccept;
	short int ok = 0;
	
	#ifdef VERBOSE
	printf("[Manage_Accept] fd = %d\n", fd_pub);
	fflush(stdout);
	#endif
	
	/* accept */
	if ((new_fd_hide = accept(fd_hide, &addr, &addrlen)) < 0 ) {
		fprintf(stderr, "Manage_Accept() Err: %d \"%s\"\n", errno, strerror(errno));
		exit(-1);
	}
	
	if ((msg = (char *)malloc(CCS_HEADER_SIZE)) == NULL) {
		fprintf(stderr, "Manage_Accept(), impossibile allocare memoria per msg");
		exit(-1);
	}
	
	do {
		struct timeval timeout;
		fd_set read_set;

		timeout.tv_sec = WAIT_TIME;
		timeout.tv_usec = 0;
		FD_ZERO(&read_set);
		FD_SET(new_fd_hide, &read_set);
			
		if (select(new_fd_hide + 1, &read_set, NULL, NULL, &timeout) < 0) {
			fprintf(stderr, "Connect, select() Err: %d \"%s\"\n", errno, strerror(errno));
			exit(-1);
		}
		if (FD_ISSET(new_fd_hide, &read_set)) {
			CCS_Readn(new_fd_hide, msg, CCS_HEADER_SIZE);
			ok = 1;
		}
	} while (!ok);

	naccept = fd_extract_naccept(fd_list, fd_pub, fd_list_lock);
	
	memcpy(&type, msg, sizeof(int));
	memcpy(&msg_size, &msg[sizeof(int) + sizeof(unsigned int)], sizeof(size_t));

	ok = 0;
	do {
		struct timeval timeout;
		fd_set read_set;

		timeout.tv_sec = WAIT_TIME;
		timeout.tv_usec = 0;
		FD_ZERO(&read_set);
		FD_SET(new_fd_hide, &read_set);
			
		if (select(new_fd_hide + 1, &read_set, NULL, NULL, &timeout) < 0) {
			fprintf(stderr, "Connect, select() Err: %d \"%s\"\n", errno, strerror(errno));
			exit(-1);
		}
		if (FD_ISSET(new_fd_hide, &read_set)) {
			CCS_Readn(new_fd_hide, &fd_peer, msg_size);
			ok = 1;
		}
	} while (!ok);
	
	if ((type == CONNECTION) && (naccept > 0)) {
		Pkt_Craft(CONNECTION_ESTABLISHED, 0, 0, NULL, msg);
		
		/* invia conferma di connessione */
		CCS_Sendn(new_fd_hide, msg, CCS_HEADER_SIZE, 0);
		
		free(msg);

		/* decremento il numero di connessioni attive */
		fd_dec_naccept(fd_list, fd_pub, fd_list_lock);

		ReserveFileDescriptor(&new_fd_pub);
		
		/* creo una nuova coppia fd_pub/fd_hide e la aggiungo alla lista */
		fd_insert_item(fd_list, new_fd_pub, new_fd_hide, fd_list_lock);
		
		/* inserisco fd_accept */
		fd_insert_fd_accept(fd_list, new_fd_pub, fd_pub, fd_list_lock);

		fd_insert_fd_accept(fd_list, fd_pub, new_fd_pub, fd_list_lock);

		/* inserisco fd_peer */
		fd_insert_fd_peer(fd_list, new_fd_pub, fd_peer, fd_list_lock);
		
		/* setto lo stato del socket */
		fd_insert_state(fd_list, new_fd_pub, CONNECTED, fd_list_lock);
		
		#ifdef VVERBOSE
		printf("[Manage_Accept] Creata coppia di fd: pub = %d, hide = %d, peer = %d\n", \
			new_fd_pub, new_fd_hide, fd_peer);
		fflush(stdout);
		#endif
	}
	else if (type == RECONNECTION) {
		int fd_pub_crash = fd_extract_fd_pub_from_fd_peer(fd_list, fd_peer, fd_list_lock);

		/* cambio fd_hide di fd_pub_crash */
		fd_change_fd_hide(fd_list, fd_pub_crash, new_fd_hide, fd_list_lock);

		Pkt_Craft(CONNECTION_ESTABLISHED, 0, 0, NULL, msg);
		
		/* invia conferma di connessione */
		CCS_Sendn(new_fd_hide, msg, CCS_HEADER_SIZE, 0);
		
		free(msg);

		while (Send_Old_Packets(fd_pub_crash) == RW_CRASH) {
			Manage_CRASH(fd_pub_crash);
		}
	}
	else {
		Pkt_Craft(CONNECTION_NOT_ESTABLISHED, 0, 0, NULL, msg);
		
		/* invia conferma di connessione */
		CCS_Sendn(new_fd_hide, msg, CCS_HEADER_SIZE, 0);

		free(msg);
	}
}

void Read_Packet(int fd_pub, int fd_hide) {
	char *header;
	int type;
	unsigned int seqnum;
	size_t size;
	ssize_t returnvalue;
	
	if ((header = (char *)malloc(CCS_HEADER_SIZE)) == NULL) {
		fprintf(stderr, "Read_Packet: impossibile allocare memoria per header");
		exit(-1);
	}

	if ((returnvalue = CCS_Readn(fd_hide, header, CCS_HEADER_SIZE)) == RW_CRASH) {
		Manage_CRASH(fd_pub);
		return;
	}

	memcpy(&type, &header[0], sizeof(int));
	memcpy(&seqnum, &header[sizeof(int)], sizeof(unsigned int));
	memcpy(&size, &header[sizeof(int) + sizeof(unsigned int)], sizeof(size_t));

	#ifdef VVERBOSE
	printf("[Read_Packet] type = %d, seqnum = %u, size = %u (%d)\n", type, seqnum, size, fd_hide);
	#endif
	
	switch (type) {
		case SEG:
			#ifdef VVERBOSE
			printf("[Read_Packet] letto un segmento dati da fd %d (%d)\n", fd_pub, fd_hide);
			fflush(stdout);
			#endif

			if ((returnvalue = Manage_SEG(fd_pub, fd_hide, size, seqnum)) == RW_CRASH) {
				Manage_CRASH(fd_pub);
			}
			break;
		case ACK:
			#ifdef VVERBOSE
			printf("[Read_Packet] letto un ack da fd %d (%d)\n", fd_pub, fd_hide);
			fflush(stdout);
			#endif
			Manage_ACK(fd_pub, fd_hide, seqnum);
			break;
		case END:
			#ifdef VVERBOSE
			printf("[Read_Packet] letto un pacchetto di fine connessione da fd %d (%d)\n", \
				fd_pub, fd_hide);
			fflush(stdout);
			#endif
			Manage_END(fd_pub, fd_hide);
			break;
		case ACK_END:
			#ifdef VVERBOSE
			#endif
			Manage_ACK_END(fd_pub, fd_hide);
			break;
		default:
			fprintf(stderr, "Read_Packet(), Unknown packet type %d\n", type);
			exit(-1);
	}
}

ssize_t Real_Send(int fd_pub, int fd_hide, const void *buf, size_t count, int flags) {
	char *msg;	/* [count + CCS_HEADER_SIZE]; */
	unsigned int seqnum;
	ssize_t returnvalue;

	if ((msg = (char *)malloc(count + CCS_HEADER_SIZE)) == NULL) {
		fprintf(stderr, "Real_Send(), impossibile allocare memoria per msg");
		exit(-1);
	}

	fd_inc_seqnum_snd(fd_list, fd_pub, fd_list_lock);
	seqnum = fd_extract_seqnum_snd(fd_list, fd_pub, fd_list_lock);
	Pkt_Craft(SEG, seqnum, count, buf, msg);

	fd_insert_wait_ack_buf(fd_list, fd_pub, seqnum, count, (char *)buf, fd_list_lock);

	if ((returnvalue = CCS_Sendn(fd_hide, msg, count + CCS_HEADER_SIZE, flags)) == RW_CRASH) {
		Manage_CRASH(fd_pub);
	}

	free(msg);

	return(count);
}

ssize_t CCS_Sendn(int fd_hide, char *msg, size_t count, int flags) {
	size_t nleft;
	ssize_t nwritten;
	ssize_t written = 0;

	#ifdef VERBOSE
	{
		int type;
		unsigned int seqnum;
		size_t size;
		memcpy(&type, msg, sizeof(int));
		memcpy(&seqnum, &msg[sizeof(int)], sizeof(unsigned int));
		memcpy(&size, &msg[sizeof(int) + sizeof(unsigned int)], sizeof(size_t));
		printf("[CCS_Sendn] fd_hide = %d, bytes = %u, type = %d, seqnum = %d, size = %d\n", \
			fd_hide, count, type, seqnum, size);
		fflush(stdout);
	}
	#endif

	nleft = count;
	while (nleft >= 0) {
		if ((nwritten = send(fd_hide, msg, nleft, MSG_NOSIGNAL | flags)) < 0) {
			if (errno == EINTR) {
				nwritten = 0;
			}
			else if ((errno == EPIPE) || (errno == ECONNRESET)) {
				return(RW_CRASH);
			}
			else {
				fprintf(stderr, "CCS_Sendn() Err: %d \"%s\"\n", errno, strerror(errno));
				return(nwritten);
			}
		}
		written += nwritten;
		nleft -= nwritten;
		msg += nwritten;
		if ((nleft == 0) && (nwritten == 0)) {
			/* Eseguito un ciclo in piu' per rilevare errori */
			break;
		}
	}
	msg -= (count);

	#ifdef VVERBOSE
	printf("[CCS_Sendn] vanno spediti %d bytes, ne ho spediti %d\n", count, written);
	fflush(stdout);
	#endif
	return(written);
}

void Pkt_Craft(int type, unsigned int seqnum, size_t size, const void *buf, char *msg) {
	#ifdef VERBOSE
	printf("[Pkt_Craft]\n");
	fflush(stdout);
	#endif

	#ifdef VVERBOSE
	printf("[Pkt_Craft] type %d, seqnum %u, size %u\n", type, seqnum, size);
	fflush(stdout);
	#endif

	memcpy(&msg[0], &type, sizeof(int));
	memcpy(&msg[sizeof(int)], &seqnum, sizeof(unsigned int));
	memcpy(&msg[sizeof(int) + sizeof(unsigned int)], &size, sizeof(size_t));
	if (buf != NULL) {
		memcpy(&msg[12], buf, size);
	}
}

ssize_t Manage_SEG(int fd_pub, int fd_hide, size_t size, unsigned int seqnum) {
	ssize_t returnvalue;
	int state;
	char *buf = NULL;
	unsigned int last_seqnum = fd_extract_seqnum_rcv(fd_list, fd_pub, fd_list_lock);

	#ifdef VERBOSE
	printf("[Manage_SEG] pub = %d, hide = %d, seqnum = %d\n", fd_pub, fd_hide, seqnum);
	fflush(stdout);
	#endif

	if ((buf = (char *)malloc(size)) == NULL) {
		fprintf(stderr, "Manage_SEG: impossibile allocare memoria per buf");
		exit(-1);
	}

	#ifdef VVERBOSE
	printf("[Manage_SEG] leggo %d bytes da fd %d\n", size, fd_hide);
	fflush(stdout);
	#endif

	returnvalue = CCS_Readn(fd_hide, buf, size);

	if (returnvalue == size) {
		state = fd_extract_state(fd_list, fd_pub, fd_list_lock);
		if ((state != PEER_CLOSED) || (state != CLOSED)) {
			#ifdef VVERBOSE
			printf("[Manage_SEG] spedisco ACK last_seqnum = %u, seqnum = %u\n", \
				last_seqnum, seqnum);
			fflush(stdout);
			#endif
			Send_ACK(fd_pub, seqnum);
		}

		if (last_seqnum < seqnum) {
			#ifdef VVERBOSE
			printf("[Manage_SEG] seqnum = %u, incremento seqnum_rcv (da %u a %u)\n", \
				seqnum, last_seqnum, seqnum);
			fflush(stdout);
			#endif

			fd_inc_seqnum_rcv(fd_list, fd_pub, fd_list_lock);	
			
			fd_insert_not_read_buf(fd_list, fd_pub, seqnum, size, buf, fd_list_lock);

			fd_cond_avail_signal(fd_list, fd_pub, fd_list_lock);
		}
	}

	free(buf);

	return(returnvalue);
}

void Manage_ACK(int fd_pub, int fd_hide, unsigned int seqnum) {
	#ifdef VERBOSE
	printf("[Manage_ACK] fd_pub = %d, fd_hide = %d\n", fd_pub, fd_hide);
	fflush(stdout);
	#endif

	fd_remove_from_wait_ack_buf(fd_list, fd_pub, fd_list_lock);
	
	#ifdef VVERBOSE
	printf("[Manage_ACK] Cancellato elemento fd_pub = %d, seqnum = %u\n", fd_pub, seqnum);
	fflush(stdout);
	#endif
}

void Manage_END(int fd_pub, int fd_hide) {
	char *msg;
	int returnvalue;

	#ifdef VERBOSE
	printf("[Manage_END] fd_pub = %d, fd_hide = %d\n", fd_pub, fd_hide);
	fflush(stdout);
	#endif
	
	#ifdef VVERBOSE
	printf("[Manage_END] La connessione e' stata chiusa su %d (%d).\n", fd_pub, fd_hide);
	fflush(stdout);
	#endif

	fd_insert_not_read_buf(fd_list, fd_pub, 0, 0, NULL, fd_list_lock);

	/* manda l'ack di chiusura */
	if ((msg = (char *)malloc(CCS_HEADER_SIZE)) == NULL) {
		fprintf(stderr, "Manage_END(), impossibile allocare memoria per msg");
		exit(-1);
	}
	Pkt_Craft(ACK_END, 0, 0, NULL, msg);

	returnvalue = CCS_Sendn(fd_hide, msg, CCS_HEADER_SIZE, 0);
	while(returnvalue == RW_CRASH) {
		Manage_CRASH(fd_pub);
		fd_hide = fd_extract_fd_hide(fd_list, fd_pub, fd_list_lock);
		returnvalue = CCS_Sendn(fd_hide, msg, CCS_HEADER_SIZE, 0);
	}

	fd_insert_state(fd_list, fd_pub, PEER_CLOSED, fd_list_lock);
	pthread_exit(NULL);
}

void Manage_ACK_END(int fd_pub, int fd_hide) {
	int returnvalue;

	#ifdef VERBOSE
	printf("[Manage_ACK_END] fd_pub = %d, fd_hide = %d\n", fd_pub, fd_hide);
	fflush(stdout);
	#endif

	if ((returnvalue = close(fd_hide)) < 0) {
		fprintf(stderr, "Close() Err: %d \"%s\"\n", errno, strerror(errno));
	}
	if ((returnvalue = close(fd_pub)) < 0) {
		fprintf(stderr, "Close() Err: %d \"%s\"\n", errno, strerror(errno));
	}
}

ssize_t	CCS_Readn(int fd_hide, void *buf, size_t size) {
	size_t nleft;
	ssize_t nread;
	ssize_t total_bytes = 0;
	int available_bytes;
	int timeout = 0;
	void *buf_orig = buf;
	short int finished = 0;

	#ifdef VVERBOSE
	printf("[CCS_Readn] fd_hide = %d, size = %d\n", fd_hide, size);
	fflush(stdout);
	#endif

	while (!finished) {
		do {
			ioctl(fd_hide, FIONREAD, &available_bytes);
			
			nleft = available_bytes < (size - total_bytes) ? \
				available_bytes : (size - total_bytes);
			while(nleft > 0) {
				if ((nread = read(fd_hide, buf, nleft)) < 0) {
					if (errno == EINTR) {
						nread = 0;
					}
					else if(errno == ECONNRESET) {	/* 104 */
						buf = buf_orig;
						return(RW_CRASH);
					}
					else {
						fprintf(stderr, "CCS_Readn() Err: %d \"%s\"\n", \
							errno, strerror(errno));
						fprintf(stderr, "CCS_Readn() fd_hide = %d, size = %d\n", \
							fd_hide, size);
						return(nread);
					}
				}
				timeout = 0;
				total_bytes += nread;
				nleft -= nread;
				buf += nread;
			}
		} while ((available_bytes > 0) && (total_bytes < size));

		if (available_bytes == 0) {
			int selectreturn;
			fd_set read_set;
			struct timeval timeout;

			FD_ZERO(&read_set);
			FD_SET(fd_hide, &read_set);
			timeout.tv_sec = 0;
			timeout.tv_usec = 0;
			
			if ((selectreturn = select(fd_hide + 1, &read_set, NULL, NULL, &timeout)) < 0) {
				fprintf(stderr, "CCS_Readn, fd_hdie = %d, select() Err. %d \"%s\"", \
					fd_hide, errno, strerror(errno));
				exit(-1);
			}
			if ((selectreturn != 0) && FD_ISSET(fd_hide, &read_set)) {
				read(fd_hide, NULL, 1);
				buf = buf_orig;
				return(RW_CRASH);
			}
		}
		
		if (total_bytes < size) {
			sleep(WAIT_TIME);
			timeout += WAIT_TIME;
			
			if (timeout == INACTIVITY_TIMEOUT_SECONDS) {
				buf = buf_orig;
				return(RW_CRASH);
			}
		}
		else {
			finished = 1;
		}
	}

	buf -= size;

	return(size);
}

int Send_ACK(int fd_pub, unsigned int seqnum) {
	int fd_hide = fd_extract_fd_hide(fd_list, fd_pub, fd_list_lock);
	char *msg = NULL;
	ssize_t sendnreturn;	/* DEBUG */

	#ifdef VERBOSE
	printf("[Send_ACK] fd_pub = %d, fd_hide = %d, seqnum = %u\n", fd_pub, fd_hide, seqnum);
	fflush(stdout);
	#endif
	
	if ((msg = (char *)malloc(CCS_HEADER_SIZE)) == NULL) {
		fprintf(stderr, "Send_ACK() Impossibile allocare memoria per msg");
		exit(-1);
	}
	Pkt_Craft(ACK, seqnum, 0, NULL, msg);
	
	sendnreturn = CCS_Sendn(fd_hide, msg, CCS_HEADER_SIZE, 0);
	while (sendnreturn == RW_CRASH) {
		Manage_CRASH(fd_pub);
		fd_hide = fd_extract_fd_hide(fd_list, fd_pub, fd_list_lock);
		sendnreturn = CCS_Sendn(fd_hide, msg, CCS_HEADER_SIZE, 0);
	}

	free(msg);
}

ssize_t Read_From_Buffer(int fd_pub, int fd_hide, void *buf, size_t count) {
	size_t current = 0;
	size_t left = 0;
	char *char_buf = buf;
	char *msg_tmp;
	MSG_ITEM *msg_nodo = NULL;
	ssize_t returnvalue = 0;

	#ifdef VERBOSE
	printf("[Read_From_Buffer] pub = %d\n", fd_pub);
	fflush(stdout);
	#endif

	while (current < count) {
		left = count - current;
		if (!fd_is_empty_not_read_buf(fd_list, fd_pub, fd_list_lock)) {
			msg_nodo = fd_extract_from_buf(fd_list, fd_pub, fd_list_lock);

			if (msg_nodo->seqnum == 0) {	/* Connection closed */
				#ifdef VVERBOSE
				printf("[Read_From_Buffer] Nessun altro pacchetto disponibile \
					in lettura sul fd %d (%d)\n", fd_pub, fd_hide);
				fflush(stdout);
				#endif
				return(returnvalue);
			}
			
			if (msg_nodo->size <= left) {
				memcpy(char_buf, msg_nodo->msg, msg_nodo->size);
				left -= msg_nodo->size;
				returnvalue += msg_nodo->size;
				char_buf += msg_nodo->size;
				current += msg_nodo->size;
				fd_remove_from_not_read_buf(fd_list, fd_pub, fd_list_lock);
			}
			else {
				msg_tmp = fd_change_not_read_buf(fd_list, fd_pub, left, fd_list_lock);
				memcpy(char_buf, msg_tmp, left);
				free(msg_tmp);
				char_buf += left;
				returnvalue += left;
				current += left;
				left = 0;
			}
		}
		else {
			#ifdef VVERBOSE
			printf("[Read_From_Buffer] fd_pub = %d, fd_hide = %d, prima di avail_wait\n", \
				fd_pub, fd_hide);
			#endif
			fd_cond_avail_wait(fd_list, fd_pub, fd_list_lock);
			#ifdef VVERBOSE
			printf("[Read_From_Buffer] fd_pub = %d, fd_hide = %d, dopo avail_wait\n", \
				fd_pub, fd_hide);
			#endif
		}
	}
	char_buf -= count;
	#ifdef VVERBOSE
	printf("[Read_From_Buffer] fd_pub = %d, letti %d bytes\n", fd_pub, returnvalue);
	#endif
	return(returnvalue);
}

int Reconnect(int fd_pub) {
	int fd_accept, new_fd_hide;
	int returnvalue;
	int conn_timeout = 0;
	int connected = 0;
	struct sockaddr serv_addr = fd_extract_addr(fd_list, fd_pub, fd_list_lock);
	socklen_t addrlen = fd_extract_addrlen(fd_list, fd_pub, fd_list_lock);

	fd_accept = fd_extract_fd_accept(fd_list, fd_pub, fd_list_lock);

	#ifdef VERBOSE
	printf("[Reconnect] fd_pub = %d, fd_accept = %d\n", fd_pub, fd_accept);
	fflush(stdout);
	#endif

	if (fd_accept == 0) {	/* client */
		char *msg;
		int type;
		short int ok = 0;

		if ((new_fd_hide = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
			fprintf(stderr, "Reconnect() socket() Err: %d \"%s\"\n", \
				errno, strerror(errno));
			return (new_fd_hide);
		}

		while ((conn_timeout < RETRY_TIMEOUT_SECONDS) && !connected) {
			if ((returnvalue = connect(new_fd_hide, &serv_addr, addrlen)) < 0) {
				fprintf(stderr, "Reconnect() connect() Err: %d \"%s\"\n", \
					errno, strerror(errno));
				sleep(RETRY_INTERVAL_SECONDS);
				conn_timeout += RETRY_INTERVAL_SECONDS;
			}
			else {
				/* manda richiesta di connessione */
				if ((msg = (char *)malloc(CCS_HEADER_SIZE + sizeof(int))) == NULL) {
					fprintf(stderr, \
						"Reconnect(), impossibile allocare memoria per msg");
					exit(-1);
				}
				Pkt_Craft(RECONNECTION, 0, sizeof(int), &fd_pub, msg);
				
				CCS_Sendn(new_fd_hide, msg, CCS_HEADER_SIZE + sizeof(int), 0);

				do {
					struct timeval timeout;
					fd_set read_set;
					
					timeout.tv_sec = WAIT_TIME;
					timeout.tv_usec = 0;
					FD_ZERO(&read_set);
					FD_SET(new_fd_hide, &read_set);
					
					if (select(new_fd_hide + 1, &read_set, NULL, NULL, &timeout) \
							< 0) {
						fprintf(stderr, "Reconnect, select() \
							Err: %d \"%s\"\n", errno, strerror(errno));
						exit(-1);
					}
					if (FD_ISSET(new_fd_hide, &read_set)) {
						CCS_Readn(new_fd_hide, msg, CCS_HEADER_SIZE);
						ok = 1;
					}
				} while (!ok);
				
				memcpy(&type, msg, sizeof(int));

				if (type != CONNECTION_ESTABLISHED) {
					exit(-1);
				}

				free(msg);
				
				fd_change_fd_hide(fd_list, fd_pub, new_fd_hide, fd_list_lock);
				connected = 1;

				#ifdef VVERBOSE
				printf("[Reconnect] fd_pub = %d, new_fd_hide %d\n", \
					fd_pub, new_fd_hide);
				fflush(stdout);
				#endif
			}
		}
	}
	else if (fd_accept != fd_pub) {	/* server */
		int fd_accept_hide = fd_extract_fd_hide(fd_list, fd_accept, fd_list_lock);
		struct timeval timeout;
		fd_set read_set;
			
		while ((conn_timeout < RETRY_TIMEOUT_SECONDS) && !connected) {
			
			timeout.tv_sec = RETRY_INTERVAL_SECONDS;
			timeout.tv_usec = 0;
			FD_ZERO(&read_set);
			FD_SET(fd_accept_hide, &read_set);
			
			returnvalue = select(fd_accept_hide + 1, &read_set, NULL, NULL, &timeout);
			if (FD_ISSET(fd_accept_hide, &read_set)) {
				Manage_Accept(fd_accept);
				connected = 1;
			}
			else {
				conn_timeout += RETRY_INTERVAL_SECONDS;
			}
		}
	}
	if (connected) {
		#ifdef VVERBOSE
		printf("[Reconnect] fd_pub = %d, new_fd_hide = %d: riconnessione riuscita\n", \
			fd_pub, new_fd_hide);
		fflush(stdout);
		#endif
		return(0);
	}
	else {
		#ifdef VVERBOSE
		printf("[Reconnect] fd_pub = %d, new_fd_hide = %d: riconnessione non riuscita\n", \
			fd_pub, new_fd_hide);
		fflush(stdout);
		#endif
		return(-1);
	}
}

int Send_Old_Packets(int fd_pub) {
	int fd_hide = fd_extract_fd_hide(fd_list, fd_pub, fd_list_lock);
	int returnvalue;
	MSG_ITEM *wait_ack_buf = fd_extract_wait_ack_buf(fd_list, fd_pub, fd_list_lock);

	#ifdef VERBOSE
	printf("[Send_Old_Packets], fd_pub = %d\n", fd_pub);
	fflush(stdout);
	#endif
	
	pthread_mutex_lock(fd_list_lock);
	while(wait_ack_buf != NULL) {
		char *msg;
		
		#ifdef VVERBOSE
		printf("[Send_Old_Packets] fd_pub = %d, seqnum = %d, size = %d, msg = %d, next = %d\n", \
			fd_pub, wait_ack_buf->seqnum, wait_ack_buf->size, \
			wait_ack_buf->msg, wait_ack_buf->next);
		#endif
		
		if ((msg = (char *)malloc(wait_ack_buf->size + CCS_HEADER_SIZE)) == NULL) {
			fprintf(stderr, "Send_Old_Packets() Impossibile allocare memoria per msg");
			exit(-1);
		}
		
		Pkt_Craft(SEG, wait_ack_buf->seqnum, wait_ack_buf->size, wait_ack_buf->msg, msg);

		#ifdef VVERBOSE
		{
			int type;
			unsigned int seqnum;
			size_t size;
			memcpy(&type, msg, sizeof(int));
			memcpy(&seqnum, &msg[sizeof(int)], sizeof(unsigned int));
			memcpy(&size, &msg[sizeof(int) + sizeof(unsigned int)], sizeof(size_t));
			printf("[Send_Old_Packets] fd_pub %d, spedisco: type = %d, seqnum = %d, \
				size = %d\n", fd_pub, type, seqnum, size);
		}
		#endif
		
		returnvalue = CCS_Sendn(fd_hide, msg, wait_ack_buf->size + CCS_HEADER_SIZE, 0);
		free(msg);
		msg = NULL;

		if (returnvalue == RW_CRASH) {
			pthread_mutex_unlock(fd_list_lock);
			return(returnvalue);
		}
		
		wait_ack_buf = wait_ack_buf->next;
	}
	pthread_mutex_unlock(fd_list_lock);
	return(1);
}

ssize_t Manage_CRASH(int fd_pub) {
	ssize_t returnvalue;
	int fd_hide;
	int state;

	#ifdef VERBOSE
	printf("[Manage_CRASH] fd_pub = %d\n", fd_pub);
	#endif
	state = fd_extract_state(fd_list, fd_pub, fd_list_lock);
	if (state == CRASH) {
		#ifdef VVERBOSE
		printf("[Manage_CRASH] fd_pub = %d, prima di crash_wait\n", fd_pub);
		#endif
		fd_cond_crash_wait(fd_list, fd_pub, fd_list_lock);
		#ifdef VVERBOSE
		printf("[Manage_CRASH] fd_pub = %d, dopo crash_wait\n", fd_pub);
		#endif
	}
	else {
		fd_insert_state(fd_list, fd_pub, CRASH, fd_list_lock);
		do {
			if (Reconnect(fd_pub) < 0) {
				fprintf(stderr, "RICONNESSIONE NON RIUSCITA\n");
				exit(-1);
			}
			else {
				fd_hide = fd_extract_fd_hide(fd_list, fd_pub, fd_list_lock);
				
				/* risettare reuseaddr se c'era */
				if (fd_extract_reuseaddr(fd_list, fd_pub, fd_list_lock)) {
					if (SetsockoptReuseAddr(fd_pub) == 0) {
						exit(-1);
					}
				}
				
				/* rispedire tutto */
				returnvalue = Send_Old_Packets(fd_pub);
			}
		} while (returnvalue == RW_CRASH);
		fd_insert_state(fd_list, fd_pub, CONNECTED, fd_list_lock);
	}
	fd_cond_crash_signal(fd_list, fd_pub, fd_list_lock);
	return(0);
}
