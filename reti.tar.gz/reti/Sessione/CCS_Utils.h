#include<sys/types.h>

/**
Possibili tipi di pacchetti CCS:\n
\li \c SEG pacchetto dati
\li \c ACK ack per avvenuta ricezione di un pacchetto dati
\li \c END pacchetto di chiusura volontaria della connessione
\li \c ACK_END ack per chiusura volontaria della connessione
\li \c CONNECTION richiesta di prima connessione
\li \c RECONNECTION richiesta di riconnessione in seguito ad un crash
\li \c CONNECTION_ESTABLISHED connessione stabilita
\li \c CONNECTION_NOT_ESTABLISHED connessione non stabilita
*/
enum types {
	SEG = 1, 
	ACK, 
	END, 
	ACK_END, 
	CONNECTION, 
	RECONNECTION, 
	CONNECTION_ESTABLISHED, 
	CONNECTION_NOT_ESTABLISHED
	};

/**
Possibili stati di una connessione CCS:\n
\li \c NOT_CONNECTED indica che la connessione non &egrave; ancora stata stabilita
\li \c CONNECTED indica che la connessione &egrave; stata stabilita
\li \c CLOSED indica che il socket &egrave; stato chiuso, cio&egrave; &egrave; stata chiamata la Close()
\li \c PEER_CLOSED indica che l'altro end-system ha chiuso la connessione chiamando la Close()
\li \c ZOMBIE si riferisce solo ai socket listening, indica che &egrave; stata chiamata la Close() ma che ci sono ancora dei socket attivi generati da questo
\li \c CRASH indica che &egrave; stato rilevato un crash di connessione sul socket
*/
enum states {
	NOT_CONNECTED, 
	CONNECTED, 
	CLOSED, 
	PEER_CLOSED, 
	ZOMBIE, 
	CRASH
	};

/** Dimensione di un header CCS */
#define CCS_HEADER_SIZE (sizeof(int) + sizeof(unsigned int) + sizeof(size_t))

/** Valore ritornato di CCS_Readn e CCS_Sendn per indicare un crash della connessione */
#define RW_CRASH -5

/** Tempo di attesa per le chiamate a select()*/
#define WAIT_TIME 10
