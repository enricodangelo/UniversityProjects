#include <errno.h>
#include "CCS_Utils.h"
#include"fd_list.h"

int fd_insert_item(FD_LIST *list, int fd_pub, int fd_hide, pthread_mutex_t *mutex) {
	FD_ITEM *new = NULL;

	/* allocazione della memoria per il nuovo oggetto FD_ITEM */
	if ((new = (FD_ITEM *)malloc(sizeof(FD_ITEM))) == NULL ) {
		fprintf(stderr, "fd_insert_item(), impossibile allocare altra memoria.\n");
		return(0);
	}

	/* assegno i valori del nuovo elemento  */
	new->fd_pub = fd_pub;
	new->fd_hide = fd_hide;
	new->fd_peer = 0;
	new->state = NOT_CONNECTED;
	new->seqnum_snd = 0;
	new->seqnum_rcv = 0;
	new->reuseaddr = 0;
	new->fd_accept = 0;
	new->thread = 0;
	new->naccept = 0;
	pthread_cond_init(&new->accept, NULL);
	pthread_cond_init(&new->avail, NULL);
	pthread_cond_init(&new->crash, NULL);
	(new->wait_ack_buf).first = NULL;
	(new->wait_ack_buf).last = NULL;
	(new->not_read_buf).first = NULL;
	(new->not_read_buf).last = NULL;
	new->next = NULL;
	
	pthread_mutex_lock(mutex);
	if (list->first == NULL) {	/* la lista � vuota, inserisco il nuovo elemento */
		list->first = new;
		list->last = new;
	}
	else {	/* la lista contiene gi� elementi, inserisco in coda */
		/* il successivo dell'ultimo della coda � il nuovo elemento */
		(list->last)->next = new;	
		/* l'ultimo della coda � il nuovo elemento */
		list->last = new;		
	}
	pthread_mutex_unlock(mutex);
	return(1);
}

int fd_insert_addr(FD_LIST *list, int fd_pub, struct sockaddr addr, \
		socklen_t addrlen, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->addr = addr;
			nodo->addrlen = addrlen;
			pthread_mutex_unlock(mutex);
			return(1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_insert_addr(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

struct sockaddr fd_extract_addr(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	struct sockaddr returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->addr;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_addr(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

socklen_t fd_extract_addrlen(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	socklen_t returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->addrlen;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_addrlen(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_extract_fd_hide(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->fd_hide;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_fd_hide(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_member(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			pthread_mutex_unlock(mutex);
			return (1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	return (0);	/* il nodo cercato non e' presente nella lista */
}

int fd_inc_seqnum_rcv(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->seqnum_rcv++;
			pthread_mutex_unlock(mutex);
			return (1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_inc_seqnum_rcv(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_inc_seqnum_snd(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->seqnum_snd++;
			pthread_mutex_unlock(mutex);
			return (1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_inc_seqnum_snd(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_extract_seqnum_rcv(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	unsigned int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->seqnum_rcv;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_seqnum_rcv(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_extract_seqnum_snd(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	unsigned int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->seqnum_snd;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_seqnum_snd(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_insert_wait_ack_buf(FD_LIST *list, int fd_pub, \
		unsigned int seqnum, size_t size, char *msg, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	MSG_ITEM *new_msg_nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			#ifdef VVERBOSE
			pthread_mutex_unlock(mutex);
			fd_scorri_lista_wait_ack(list, fd_pub, mutex);
			pthread_mutex_lock(mutex);
			#endif
			if ((new_msg_nodo = (MSG_ITEM *)malloc(sizeof(MSG_ITEM))) == NULL) {
				fprintf(stderr, "fd_insert_wait_ack_buf(), \
						can't allocate enough memory.\n");
				exit(-1);
			}
			if ((new_msg_nodo->msg = (char *)malloc(size)) == NULL) {
				fprintf(stderr, "fd_insert_wait_ack_buf(), \
						can't allocate enough memory.\n");
				exit(-1);
			}
			
			new_msg_nodo->seqnum = seqnum;
			new_msg_nodo->size = size;
			memcpy(new_msg_nodo->msg, msg, size);
			new_msg_nodo->next = NULL;
			/* la lista � vuota, inserisco il nuovo elemento */
			if ((nodo->wait_ack_buf).first == NULL) { 
				(nodo->wait_ack_buf).first = new_msg_nodo;
				(nodo->wait_ack_buf).last = new_msg_nodo;
			}
			else {	/* la lista contiene gi� elementi, inserisco in coda */
				/* il successivo dell'ultimo della coda � il nuovo elemento */
				((nodo->wait_ack_buf).last)->next = new_msg_nodo;	
				/* l'ultimo della coda � il nuovo elemento */
				(nodo->wait_ack_buf).last = new_msg_nodo;		
			}

			#ifdef VVERBOSE
			pthread_mutex_unlock(mutex);
			fd_scorri_lista_wait_ack(list, fd_pub, mutex);
			pthread_mutex_lock(mutex);
			#endif
			pthread_mutex_unlock(mutex);
			return(1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_insert_wait_ack_buf(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_insert_not_read_buf(FD_LIST *list, int fd_pub, unsigned int seqnum, \
				size_t size, char *msg, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	MSG_ITEM *new_msg_nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			#ifdef VVERBOSE
			pthread_mutex_unlock(mutex);
			fd_scorri_lista_not_read(list, fd_pub, mutex);
			pthread_mutex_lock(mutex);
			#endif
			if ((new_msg_nodo = (MSG_ITEM *)malloc(sizeof(MSG_ITEM))) == NULL) {
				fprintf(stderr, "fd_insert_not_read_buf(), \
						can't allocate enough memory.\n");
				exit(-1);
			}
			new_msg_nodo->msg = NULL;
			if (size != 0) {
				if ((new_msg_nodo->msg = (char *)malloc(size)) == NULL) {
					fprintf(stderr, "fd_insert_not_read_buf(), can't \
							allocate enough memory.\n");
					exit(-1);
				}
			}

			new_msg_nodo->seqnum = seqnum;
			new_msg_nodo->size = size;
			if (msg != NULL) {
				memcpy(new_msg_nodo->msg, msg, size);
			}
			new_msg_nodo->next = NULL;

			/* la lista � vuota, inserisco il nuovo elemento */
			if ((nodo->not_read_buf).first == NULL) {	
				(nodo->not_read_buf).first = new_msg_nodo;
				(nodo->not_read_buf).last = new_msg_nodo;
			}
			else {	/* la lista contiene gi� elementi, inserisco in coda */
				/* il successivo dell'ultimo della coda � il nuovo elemento */
				((nodo->not_read_buf).last)->next = new_msg_nodo;	
				/* l'ultimo della coda � il nuovo elemento */
				(nodo->not_read_buf).last = new_msg_nodo;		
			}

			#ifdef VVERBOSE
			pthread_mutex_unlock(mutex);
			fd_scorri_lista_not_read(list, fd_pub, mutex);
			pthread_mutex_lock(mutex);
			#endif
			pthread_mutex_unlock(mutex);
			return(1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "[fd_insert_not_read_buf] can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_cond_avail_signal(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			pthread_cond_signal(&nodo->avail);
			pthread_mutex_unlock(mutex);
			return (0);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_cond_avail_signal(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_cond_avail_wait(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			pthread_cond_wait(&nodo->avail, mutex);
			pthread_mutex_unlock(mutex);
			return (0);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_cond_avail_wait(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_cond_accept_signal(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			pthread_cond_signal(&nodo->accept);
			pthread_mutex_unlock(mutex);
			return (0);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_cond_accept_signal(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_cond_accept_wait(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			pthread_cond_wait(&nodo->accept, mutex);
			pthread_mutex_unlock(mutex);
			return (0);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_cond_accept_wait(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_cond_crash_signal(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			pthread_cond_signal(&nodo->crash);
			pthread_mutex_unlock(mutex);
			return (0);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_cond_crash_signal(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_cond_crash_wait(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			pthread_cond_wait(&nodo->crash, mutex);
			pthread_mutex_unlock(mutex);
			return (0);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_cond_crash_wait(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_inc_naccept(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->naccept++;
			pthread_mutex_unlock(mutex);
			return (1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_inc_naccept(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_dec_naccept(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			if (nodo->naccept == 0) {
				fprintf(stderr, "fd_dec_naccept(), \
						Err. naccept e' gia' settato a 0\n");
				exit(-1);
			}
			nodo->naccept--;
			pthread_mutex_unlock(mutex);
			return (1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_dec_naccept(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_extract_naccept(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->naccept;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_naccept(), can't find fd_pub associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_is_empty_wait_ack_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			if ((nodo->wait_ack_buf).first == NULL) {
				#ifdef VVERBOSE
				pthread_mutex_unlock(mutex);
				fd_scorri_lista_wait_ack(list, fd_pub, mutex);
				pthread_mutex_lock(mutex);
				#endif
				returnvalue = 1;
			}
			else {
				#ifdef VVERBOSE
				pthread_mutex_unlock(mutex);
				fd_scorri_lista_wait_ack(list, fd_pub, mutex);
				pthread_mutex_lock(mutex);
				#endif
				returnvalue = 0;
			}
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_is_empty_wait_ack_buf(), \
			can't find fd_pub associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_is_empty_not_read_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			if ((nodo->not_read_buf).first == NULL) {
				#ifdef VVERBOSE
				pthread_mutex_unlock(mutex);
				fd_scorri_lista_not_read(list, fd_pub, mutex);
				pthread_mutex_lock(mutex);
				#endif
				returnvalue = 1;
			}
			else {
				#ifdef VVERBOSE
				pthread_mutex_unlock(mutex);
				fd_scorri_lista_not_read(list, fd_pub, mutex);
				pthread_mutex_lock(mutex);
				#endif
				returnvalue = 0;
			}
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_is_empty_not_read_buf(), can't \
			find fd_pub associated with %d.\n", fd_pub);
	exit(-1);
}

MSG_ITEM *fd_extract_from_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	MSG_ITEM *msg_nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			msg_nodo = (nodo->not_read_buf).first;
			pthread_mutex_unlock(mutex);
			return(msg_nodo);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_from_buf(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_remove_from_not_read_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	MSG_ITEM *msg_nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			if ((nodo->not_read_buf).first == NULL) {
				#ifdef VVERBOSE
				pthread_mutex_unlock(mutex);
				fd_scorri_lista_not_read(list, fd_pub, mutex);
				pthread_mutex_lock(mutex);
				#endif
				pthread_mutex_unlock(mutex);
				return(0);
			}
			else {
				msg_nodo = (nodo->not_read_buf).first;
				(nodo->not_read_buf).first = ((nodo->not_read_buf).first)->next;
				free(msg_nodo->msg);
				free(msg_nodo);
				#ifdef VVERBOSE
				pthread_mutex_unlock(mutex);
				fd_scorri_lista_not_read(list, fd_pub, mutex);
				pthread_mutex_lock(mutex);
				#endif
				pthread_mutex_unlock(mutex);
				return(1);
			}
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_from_buf(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);	
}

int fd_remove_from_wait_ack_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	MSG_ITEM *msg_nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			#ifdef VVERBOSE
			pthread_mutex_unlock(mutex);
			fd_scorri_lista_wait_ack(list, fd_pub, mutex);
			pthread_mutex_lock(mutex);
			#endif
			if ((nodo->wait_ack_buf).first == NULL) {
				pthread_mutex_unlock(mutex);
				return(0);
			}
			else {
				msg_nodo = (nodo->wait_ack_buf).first;
				(nodo->wait_ack_buf).first = ((nodo->wait_ack_buf).first)->next;
				free(msg_nodo->msg);
				free(msg_nodo);
				#ifdef VVERBOSE
				pthread_mutex_unlock(mutex);
				fd_scorri_lista_wait_ack(list, fd_pub, mutex);
				pthread_mutex_lock(mutex);
				#endif
				pthread_mutex_unlock(mutex);
				return(1);
			}
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_from_buf(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

char *fd_change_not_read_buf(FD_LIST *list, int fd_pub, size_t size, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	char *new_msg = NULL;
	char *returnvalue = NULL;
	size_t diff_size;
	
	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			if ((returnvalue = (char *)malloc(size)) == NULL) {
				fprintf(stderr, "fd_change_not_read_buf(): \
						impossibile allocare memoria per new_msg\n");
				exit(0);
			}
			memcpy(returnvalue, ((nodo->not_read_buf).first)->msg, size);

			diff_size = ((nodo->not_read_buf).first)->size - size;
			if ((new_msg = (char *)malloc(diff_size)) == NULL) {
				fprintf(stderr, "fd_change_not_read_buf(): \
						impossibile allocare memoria per new_msg\n");
				exit(0);
			}
			memcpy(new_msg, ((nodo->not_read_buf).first)->msg + size, diff_size);
			free(((nodo->not_read_buf).first)->msg);
			((nodo->not_read_buf).first)->msg = new_msg;
			((nodo->not_read_buf).first)->size = diff_size;

			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_change_not_read_buf(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_remove_item(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo, *nodo_prev= NULL;
	int buf_not_empty = 1;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			pthread_mutex_unlock(mutex);
			while (fd_remove_from_not_read_buf(list, fd_pub, mutex));
			while (fd_remove_from_wait_ack_buf(list, fd_pub, mutex));
			pthread_mutex_lock(mutex);
			if (nodo_prev == NULL) {	/* sto eliminando il primo nodo della lista */
				list->first = nodo->next;
			}
			else {
				nodo_prev->next = nodo->next;
			}
			if (nodo->next == NULL) {	/* sto eliminando l'ultimo nodo della lista */
				list->last = nodo_prev;
			}
			if (pthread_cond_destroy(&nodo->accept) != 0) {
				exit(-1);
			}
			if (pthread_cond_destroy(&nodo->avail) != 0) {
				exit(-1);
			}
			
			free(nodo);
			pthread_mutex_unlock(mutex);
			return (1);
		}
		nodo_prev = nodo;
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_remove_item(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_insert_thread(FD_LIST *list, int fd_pub, pthread_t thread, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->thread = thread;
			pthread_mutex_unlock(mutex);
			return (0);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_insert_thread(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

pthread_t fd_extract_thread(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	pthread_t returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->thread;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_thread(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_insert_fd_accept(FD_LIST *list, int fd_pub, int fd_accept, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->fd_accept = fd_accept;
			pthread_mutex_unlock(mutex);
			return (0);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_insert_fd_accept(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_extract_fd_accept(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->fd_accept;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_fd_accept(), can't find fd_pub associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_insert_fd_peer(FD_LIST *list, int fd_pub, int fd_peer, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->fd_peer = fd_peer;
			pthread_mutex_unlock(mutex);
			return (0);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_insert_fd_peer(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_extract_fd_peer(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->fd_peer;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_fd_peer(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_extract_fd_pub_from_fd_peer(FD_LIST *list, int fd_peer, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_peer == fd_peer) {
			returnvalue = nodo->fd_pub;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_fd_pub_from_fd_peert(), \
			can't find fd_pub associated with %d.\n", fd_peer);
	exit(-1);
}

struct custom_fd_set fd_extract_fd_hide_set(FD_LIST *list, int fd_accept, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	struct custom_fd_set returnvalue;
	fd_set set;
	int max = 0;

	FD_ZERO(&set);
	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if ((nodo->fd_accept == fd_accept) && 
				(nodo->state != PEER_CLOSED) && 
				(nodo->state != CLOSED)){
			max = max > nodo->fd_hide ? max : nodo->fd_hide;
			FD_SET(nodo->fd_hide, &set);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	returnvalue.set = set;
	returnvalue.max = max + 1;
	return(returnvalue);
}

int fd_extract_fd_pub(FD_LIST *list, int fd_hide, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_hide == fd_hide) {
			returnvalue = nodo->fd_pub;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	return(0);
}

int fd_insert_reuseaddr(FD_LIST *list, int fd_pub, int reuseaddr, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->reuseaddr = reuseaddr;
			pthread_mutex_unlock(mutex);
			return (1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_insert_reuseaddr(), can't find fd_hide associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_extract_reuseaddr(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->reuseaddr;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_reuseaddr(), can't \
			find fd_hide associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_insert_state(FD_LIST *list, int fd_pub, int state, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->state = state;
			pthread_mutex_unlock(mutex);
			return (1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_insert_state(), can't find fd_hide associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_extract_state(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = nodo->state;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_state(), can't find fd_hide \
			associated with %d.\n", fd_pub);
	exit(-1);
}

struct custom_fd_set fd_extract_all_fd_pub(FD_LIST *list, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	struct custom_fd_set returnvalue;
	fd_set set;
	int max = 0;

	FD_ZERO(&set);
	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		max = max > nodo->fd_pub ? max : nodo->fd_pub;
		FD_SET(nodo->fd_pub, &set);
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	returnvalue.set = set;
	returnvalue.max = max + 1;
	return(returnvalue);
}

int fd_no_more_connections(FD_LIST *list, int fd_accept, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if ((nodo->fd_accept == fd_accept) && (nodo->fd_pub != fd_accept)) {
			if (nodo->state != CLOSED) {
				pthread_mutex_unlock(mutex);
				return(0);
			}
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	return(1);
}

MSG_ITEM *fd_extract_wait_ack_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	MSG_ITEM *returnvalue;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			returnvalue = (nodo->wait_ack_buf).first;
			pthread_mutex_unlock(mutex);
			return (returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_extract_wait_ack_buf(), can't \
			find fd_pub associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_change_fd_hide(FD_LIST *list, int fd_pub, int new_fd_hide, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			nodo->fd_hide = new_fd_hide;
			pthread_mutex_unlock(mutex);
			return (1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_change_fd_hide(), can't find CCS \
			associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_available_bytes(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	MSG_ITEM *msg_nodo = NULL;
	int returnvalue = 0;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while(nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			msg_nodo = (nodo->not_read_buf).first;
			while(msg_nodo != NULL) {
				returnvalue += msg_nodo->size;
				msg_nodo = msg_nodo->next;
			}
			pthread_mutex_unlock(mutex);
			return(returnvalue);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	fprintf(stderr, "fd_available_bytes(), can't find CCS associated with %d.\n", fd_pub);
	exit(-1);
}

int fd_scorri_lista(FD_LIST *list, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	printf("---------------------\t---------------------\n");
	while (nodo != NULL) {
		printf("fd_pub = %d\t<==>\tfd_hide = %d\t(fd_peer = %d)\n", \
				nodo->fd_pub, nodo->fd_hide, nodo->fd_peer);
		nodo = nodo->next;
	}
	printf("---------------------\t---------------------\n");
	pthread_mutex_unlock(mutex);
	return (0);	/* il nodo cercato non e' presente nella lista */
}


int fd_scorri_lista_not_read(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int fd_hide;
	MSG_ITEM *msg_nodo;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			fd_hide = nodo->fd_hide;
			printf("---------------------\t---------------------\n");
			printf("not_read_buf, fd_pub = %d, fd_hide = %d\n", fd_pub, fd_hide);
			msg_nodo = (nodo->not_read_buf).first;
			while (msg_nodo != NULL) {
				printf("seqnum = %d, size = %d, msg = %d\n", \
					msg_nodo->seqnum, msg_nodo->size, msg_nodo->msg);
				msg_nodo = msg_nodo->next;
			}
			printf("---------------------\t---------------------\n");
			pthread_mutex_unlock(mutex);
			return(1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	return (0);
}

int fd_scorri_lista_wait_ack(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex) {
	FD_ITEM *nodo = NULL;
	int fd_hide;
	MSG_ITEM *msg_nodo;

	pthread_mutex_lock(mutex);
	nodo = list->first;
	while (nodo != NULL) {
		if (nodo->fd_pub == fd_pub) {
			fd_hide = nodo->fd_hide;
			printf("---------------------\t---------------------\n");
			printf("wait_ack_buf, fd_pub = %d, fd_hide = %d\n", fd_pub, fd_hide);
			msg_nodo = (nodo->wait_ack_buf).first;
			while (msg_nodo != NULL) {
				printf("seqnum = %d, size = %d, msg = %d\n", \
					msg_nodo->seqnum, msg_nodo->size, msg_nodo->msg);
				msg_nodo = msg_nodo->next;
			}
			printf("---------------------\t---------------------\n");
			pthread_mutex_unlock(mutex);
			return(1);
		}
		nodo = nodo->next;
	}
	pthread_mutex_unlock(mutex);
	return (0);
}
