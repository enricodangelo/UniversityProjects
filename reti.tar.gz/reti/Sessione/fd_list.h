#ifndef __FD_LIST_H__ 
#define __FD_LIST_H__ 

#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<pthread.h>

/** Struttura che definisce un nodo della lista ::MSG_LIST. */
typedef struct msg_item {
	/** numero di sequenza del messaggio */
	unsigned int seqnum;
	/** grandezza in bytes del messaggio */
	size_t size;
	/** puntatore al messaggio */
	char *msg;
	/** puntatore nodo successivo */
	struct msg_item *next;
} MSG_ITEM;

/** Struttura che definisce una lista di messaggi di tipo ::msg_item. 
    Viene utilizzata per creare il buffer dei pacchetti in attesa di ACK e di quelli non ancora letti dall'applicazione*/
typedef struct msg_list {
	/** primo elemento della lista */
	MSG_ITEM *first;
	/** ultimo elemento della lista */
	MSG_ITEM *last;
} MSG_LIST;

/** Struttura che definisce un nodo della ::FD_LIST. */
typedef struct fd_item {
	/** file descriptor pubblico */
	int fd_pub;
	/** file descriptor nascosto */
	int fd_hide;
	/** file descriptor pubblico dell'altro end-point in comunicazione con questo socket CCS */
	int fd_peer;
	/** indica lo stato in cui si trova la connessione CCS */
	int state;
	/** sequence number dell'ultimo pacchetto inviato */
	unsigned int seqnum_snd;
	/** sequence number dell'ultimo pacchetto ricevuto */
	unsigned int seqnum_rcv;
	/** struttura contenente l'indirizzo del server/client */
	struct sockaddr addr;
	/** lunghezza di addr */
	socklen_t addrlen;
	/** booleano, indica se e' attivata o meno l'opzione reuseaddr */
	int reuseaddr;
	/** socket listening associato */
	int fd_accept;			
	/** id del thread associato */
	pthread_t thread;
	/** numero di chiamate ad accept() pendenti */
	int naccept;
	/** condizione che controlla la presenza di richieste di connessione */
	pthread_cond_t accept;
	/** condizione che controlla la presenza di messaggi in not_read_buf */
	pthread_cond_t avail;
	/** condizione che controlla la gestione del crash di connessione */
	pthread_cond_t crash;
	/** buffer dei messagi in attesa di ack */
	MSG_LIST wait_ack_buf;
	/** buffer dei messaggi non ancora letti dall'applicazione */
	MSG_LIST not_read_buf;
	/** elemento successivo */
	struct fd_item *next;
} FD_ITEM;

/** Struttura che definisce una lista disocket CCS di tipo ::fd_item 
    Ogni nodo della lista rappresenta una connessione CCS attiva*/
typedef struct fd_list {
	/** primo elemento della lista */
	FD_ITEM *first;
	/** ultimo elemento della lista */
	FD_ITEM *last;
} FD_LIST;

/** Struttura contenente un ::fd_set e il massimo file descriptor nell'insieme set piu' uno.
 */
struct custom_fd_set {
	/** insieme dei file descriptor */
	fd_set set;
	/** valore massimo del file descriptor presente nell'insieme custom_fd_set::set piu' uno */
	int max;
};

/**
\brief Inserisce un nuovo socket CCS nella lista dei socket CCS attivi

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico del nuovo socket CCS
@param fd_hide file descriptor nascosto del nuovo socket CCS
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_insert_item(FD_LIST *list, int fd_pub, int fd_hide, pthread_mutex_t *mutex);

/**
\brief Elimina un socket CCS dalla lista dei socket CCS attivi

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_remove_item(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Inserisce la struttura sockaddr usata da bind/connect e la sua lunghezza nell'elemento della lista associato a fd_pub

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param addr struttura sockaddr usata da bind/connect
@param addrlen lunghezza di addr
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
 */
int fd_insert_addr(FD_LIST *list, int fd_pub, struct sockaddr addr, \
			socklen_t addrlen, pthread_mutex_t *mutex);

/**
\brief Estrae la struttura sockaddr associata a fd_pub

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna la struttura sockaddr, termina l'applicazione in caso di errore
*/
struct sockaddr fd_extract_addr(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Estrae la lunghezza della struttura sockaddr associata a fd_pub

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna la lunghezza della struttura sockaddr, termina l'applicazione in caso di errore
*/
socklen_t fd_extract_addrlen(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Estrae il file descriptor nascosto del socket CCS associato a fd_pub

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna il file descriptor nascosto del socket CCS, termina l'applicazione in caso di errore
 */
int fd_extract_fd_hide(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Verifica se nella lista dei socket CCS attivi esiste un socket CCS associato a fd_pub.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return ritorna 0 (falso) se il nodo cercato non � presente nella lista, 1 (vero) se lo trova.
 */
int fd_member(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Incrementa di 1 il valore dell'ultimo numero si sequenza ricevuto

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_inc_seqnum_rcv(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Incrementa di 1 il valore dell'ultimo numero si sequenza inviato

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_inc_seqnum_snd(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Estrae il valore dell'ultimo numero di sequenza ricevuto

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna l'ultimo numero di sequenza ricevuto, termina l'applicazione in caso di errore
*/
int fd_extract_seqnum_rcv(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Estrae il valore dell'ultimo numero di sequenza inviato

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna l'ultimo numero di sequenza inviato, termina l'applicazione in caso di errore
*/
int fd_extract_seqnum_snd(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Inserisce un pacchetto nel buffer dei pacchetti in attesa di ACK

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param seqnum numero di sequenza del pacchetto
@param size dimensione del payload
@param msg il payload
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_insert_wait_ack_buf(FD_LIST *list, int fd_pub, unsigned int seqnum, \
			size_t size, char *msg, pthread_mutex_t *mutex);

/**
\brief Inserisce un pacchetto nel buffer dei pacchetti non ancora letti dall'applicazione

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param seqnum numero di sequenza del pacchetto
@param size dimensione del payload
@param msg il payload
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_insert_not_read_buf(FD_LIST *list, int fd_pub, unsigned int seqnum, \
			size_t size, char *msg, pthread_mutex_t *mutex);

/**
\brief Segnala il verificarsi della condition avail che controlla la presenza di pacchetti non ancora letti dall'applicazione nel buffer not_read_buf

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0, termina l'applicazione in caso di errore
*/
int fd_cond_avail_signal(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Attende il verificarsi della condition avail che controlla la presenza di pacchetti non ancora letti dall'applicazione nel buffer not_read_buf.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0, termina l'applicazione in caso di errore
*/
int fd_cond_avail_wait(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Segnala il verificarsi della condition accept che controlla l'avvenuta gestione di un'accept().

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0, termina l'applicazione in caso di errore
*/
int fd_cond_accept_signal(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Attende il verificarsi della condition accept che controlla l'avvenuta gestione di un'accept().

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0, termina l'applicazione in caso di errore
*/
int fd_cond_accept_wait(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Segnala il verificarsi della condition crash che controlla se &egrave; stato rilevato un crash della connessione sul socket CCS.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0, termina l'applicazione in caso di errore
*/
int fd_cond_crash_signal(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Attende il verificarsi della condition crash che controlla se &egrave; stato rilevato un crash della connessione sul socket CCS.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0, termina l'applicazione in caso di errore
*/
int fd_cond_crash_wait(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Incrementa di 1 il numero di accept() pendenti

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_inc_naccept(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Decrementa di 1 il numero di accept() pendenti

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_dec_naccept(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Estrae il numero di accept() pendenti

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna il numero di accept pendenti, termina l'applicazione in caso di errore
*/
int fd_extract_naccept(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Controlla se il buffer dei pacchetti in attesa di ACK � vuoto.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0 (falso) se il buffer dei pacchetti in attesa di ACK non &egrave; vuoto e 1 (vero) se lo &egrave;, termina l'applicazione in caso di errore
*/
int fd_is_empty_wait_ack_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Controlla se il buffer dei pacchetti non ancora letti dall'applicazione � vuoto.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0 (falso) se il buffer dei pacchetti non ancora letti dall'applicazione non &egrave; vuoto e 1 (vero) se lo &egrave;, termina l'applicazione in caso di errore
*/
int fd_is_empty_not_read_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Ritorna un puntatore al primo pacchetto nel buffer non ancora letto dall'applicazione.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna il puntatore al primo elemento del buffer, termina l'applicazione in caso di errore
*/
MSG_ITEM *fd_extract_from_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Rimuove il primo elemento del buffer di pacchetti non ancora letti dall'applicazione.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0 se il buffer &egrave; vuoto e 1 se &egrave; stato eliminato un elemento, termina l'applicazione in caso di errore
*/
int fd_remove_from_not_read_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Rimuove il primo elemento del buffer di pacchetti in attesa di ACK.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0 se il buffer &egrave; vuoto e 1 se &egrave; stato eliminato un elemento, termina l'applicazione in caso di errore
*/
int fd_remove_from_wait_ack_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Modifica il primo elemento del buffer di pacchetti non ancora letti dall'applicazione.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param size dimensione dei dati da leggere
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna un puntatore alla parte di dati interessata, termina l'applicazione in caso di errore
*/
char *fd_change_not_read_buf(FD_LIST *list, int fd_pub, size_t size, pthread_mutex_t *mutex);

/**
\brief Inserisce l'id del thread che gestisce il socket CCS associato a fd_pub.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param thread id del thread
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0, termina l'applicazione in caso di errore
*/
int fd_insert_thread(FD_LIST *list, int fd_pub, pthread_t thread, pthread_mutex_t *mutex);

/**
\brief Estrae l'id del thread che gestisce il socket CCS associato a fd_pub.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna l'id del thread che gestisce il socket CCS, termina l'applicazione in caso di errore
*/
pthread_t fd_extract_thread(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Inserisce il socket CCS listening che ha generato il socket CCS associato a fd_pub.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param fd_accept file descriptor pubblico del socket CCS listening
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0, termina l'applicazione in caso di errore
*/
int fd_insert_fd_accept(FD_LIST *list, int fd_pub, int fd_accept, pthread_mutex_t *mutex);

/**
\brief Estrae il socket CCS listening che ha generato il socket CCS associato a fd_pub.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna il file descriptor pubblico del socket CCS listening che ha generato questo socket CCS, termina l'applicazione in caso di errore
*/
int fd_extract_fd_accept(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Inserisce il socket CCS dell'altro end-system in comunicazione col socket CCS associato a fd_pub

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param fd_peer file descriptor pubblico del socket CCS in comunicazione con questo
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 0, termina l'applicazione in caso di errore
*/
int fd_insert_fd_peer(FD_LIST *list, int fd_pub, int fd_peer, pthread_mutex_t *mutex);

/**
\brief Estra il file descriptor pubblico del socket CCS in comunicazione col socket CCS associato a fd_peer

@param list lista dei socket CCS attivi
@param fd_peer file descriptor pubblico del socket CCS in comunicazione con questo
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna il file descriptor pubblico del socket CCS in comunicazione col socket CCS associato a fd_peer, termina l'applicazione in caso di errore
*/
int fd_extract_fd_pub_from_fd_peer(FD_LIST *list, int fd_peer, pthread_mutex_t *mutex);

/**
\brief Estrae il file descriptor privato di tutti i socket CCS generati dal socket CCS listening associato a fd_accept.

@param list lista dei socket CCS attivi
@param fd_accept file descriptor pubblico del socket CCS listening
@param mutex mutex che controlla l'accesso a list
@return ritorna una struttura contenente l'insieme dei file descriptor privati dei socket CCS generati dal socket CCS listening fd_accept
*/
struct custom_fd_set fd_extract_fd_hide_set(FD_LIST *list, int fd_accept, pthread_mutex_t *mutex);

/**
\brief Estrae il file descriptor pubblico del socket CCS associato al file descriptor privato fd_hide.

@param list lista dei socket CCS attivi
@param fd_hide file descriptor nascosto dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna il file descriptor pubblico del socket CCS, ritorna 0 in caso di errore
*/
int fd_extract_fd_pub(FD_LIST *list, int fd_hide, pthread_mutex_t *mutex);

/**
\brief Setta il campo reuseaddr che indica se &egrave; stata settata o meno l'opzione SO_REUSEADDR.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param reuseaddr indica se l'opzione &egrave; settata o meno
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_insert_reuseaddr(FD_LIST *list, int fd_pub, int reuseaddr, pthread_mutex_t *mutex);

/**
\brief Estrae il valore del campo reuseaddr che indica se &egrave; stata settata o meno l'opzione SO_REUSEADDR.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna reuseaddr, termina l'applicazione in caso di errore
*/
int fd_extract_reuseaddr(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Inserisce lo stato del socket CCS.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param state nuovo stato del socket CCS
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_insert_state(FD_LIST *list, int fd_pub, int state, pthread_mutex_t *mutex);

/**
\brief Estrae lo stato del socket CCS.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna lo stato del socket CCS, termina l'applicazione in caso di errore
*/
int fd_extract_state(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Controlla se tutti i socket CCS generati dal socket CCS listening associato a fd_accept sono instato CLOSED.

@param list lista dei socket CCS attivi
@param fd_accept file descriptor pubblico del socket CCS listening
@param mutex mutex che controlla l'accesso a list
@return ritorna 1 se tutti i socket CCS generati dal socket CCS listening fd_accept sono in stato CLOSED, 0 altrimenti.
*/
int fd_no_more_connections(FD_LIST *list, int fd_accept, pthread_mutex_t *mutex);

/**
\brief Ritorna un puntatore al primo elemento del buffer di pacchetti in attesa di ACK

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna il puntatore al primo elemento del buffer, termina l'applicazione in caso di errore
*/
MSG_ITEM *fd_extract_wait_ack_buf(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

/**
\brief Cambia il file descriptor nascosto del socket CCS.

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param new_fd_hide nuovo file descriptor nascosto
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna 1, termina l'applicazione in caso di errore
*/
int fd_change_fd_hide(FD_LIST *list, int fd_pub, int new_fd_hide, pthread_mutex_t *mutex);

/**
\brief Estrae il file descriptor pubblico di tutti i socket CCS attivi.

@param list lista dei socket CCS attivi
@param mutex mutex che controlla l'accesso a list
@return ritorna una struttura contenente l'insieme di file descriptor pubblici di tutti i socket CCS attivi e il valore massimo + 1 di questi
*/
struct custom_fd_set fd_extract_all_fd_pub(FD_LIST *list, pthread_mutex_t *mutex);

/**
\brief Serve per sapere quanti bytes sono disponibili in lettura senza bloccarsi (nel buffer not_read_buf).

@param list lista dei socket CCS attivi
@param fd_pub file descriptor pubblico dell'elemento interessato
@param mutex mutex che controlla l'accesso a list
@return in caso di successo ritorna il numero di bytes disponibili in lettura, termina l'applicazione in caso di errore
*/
int fd_available_bytes(FD_LIST *list, int fd_pub, pthread_mutex_t *mutex);

#endif // __FD_LIST_H__ 
