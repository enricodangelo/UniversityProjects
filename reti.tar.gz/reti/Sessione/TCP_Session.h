#ifndef __TCP_SESSION_H__
#define __TCP_SESSION_H__

#ifdef __TCP_SESSION_C__
/* dentro il modulo .c non sono extern */
#ifdef MY_EXTERN
#undef MY_EXTERN
#endif
#define MY_EXTERN
#else
/* fuori dal modulo .c sono extern */
#define MY_EXTERN extern
#endif

/** Espresso in secondi, &egrave; il periodo di tempo massimo durante il quale lo strato di sessione 
attende l'ACK per dei dati inviati. Se questo timeout scade senza che l'ACK sia stato ricevuto la connessione viene considerata crashata e si cominciano le procedure di riconnessione. Se per&ograve; durante questo periodo la connessione manifesta una qualche attivit&agrave; (ad es: ricezione di altri dati) allora tale timeout viene resettato, cio&eacute; viene riportato al suo valore iniziale. In altre parole, se mi accorgo che la connessione trasmette/riceve dati non considero la connessione crashata, ed interpreto la mancata ricezione di ACK solo come un ritardo dovuto alla congestione di rete. Vale 60 secondi. */
#define  INACTIVITY_TIMEOUT_SECONDS 60
/** Espresso in secondi, &egrave; il periodo di tempo, dopo un crash della CCS durante il quale lo 
strato di sessione cerca di re-instaurare la connessione. Vale 600 secondi. */
#define  RETRY_TIMEOUT_SECONDS 600
/** Espresso in secondi, &egrave; il periodo di tempo, dopo un crash della CCS e dopo il fallimento del successivo tentativo di re-instaurare la connessione, durante il quale lo strato di sessione attende prima di procedere ad un ulteriore tentativo di re-instaurare la connessione. */
#define  RETRY_INTERVAL_SECONDS 10


#ifndef SOCKET_ERROR
/** errore sul socket */
#define SOCKET_ERROR   ((int)-1)
#endif

#include <sys/types.h> 
#include <sys/socket.h>
#include <sys/time.h> 


/** 
\brief Inizializza il modulo di sessione.
 
Viene invocata una sola volta dal processo che vuole utilizzare lo strato di sessione, prima di utilizzarlo.
@param ptr puntatore ad una struttura dati, pu&ograve; essere NULL
@return Restituisce 0 in caso di errore, 1 se tutto va bene.
*/
MY_EXTERN int	Init_TCP_Session_Module(void *ptr);

/**
\brief Crea un socket "normale".

Equivale alla funzione socket() classica, svolge lo stesso compito e restituisce lo stesso risultato, settando opportunamente errno se necessario.
@param domain dominio di comunicazione
@param type semantica di comunicazione
@param protocol protocollo di comunicazione da usare
@return in caso di successo ritorna un file descriptor che rappresenta il socket appena creato, in caso di errore ritorna -1 e setta opportunamente la variabile errno.
*/
MY_EXTERN int	Socket(int domain, int type, int protocol);

/**
\brief Crea un socket per il protocollo "TCP con Sessione"

Viene utilizzata per creare un socket CCS.
@return restituisce un intero maggiore o uguale a zero che rappresenta questa CCS, restituisce -1 in caso di errore.
*/
MY_EXTERN int	TCP_Session_IPv4_Socket(void);

/**
\brief Configura il socket (normale o CCS) passato come parametro in modo che la porta locale a cui viene collegato possa essere riutilizzata.

In altre parole, equivale a configurare il socket con la chiamata alla funzione:\n
<code>
int OptVal = 1;\n
ris = setsockopt(s,SOL_SOCKET,SO_REUSEADDR,(char*)&OptVal,sizeof(OptVal));
</code>
@param s socket normale o CCS da configurare
@return restituisce 1 in caso di successo mentre restituisce 0 in caso di errore e setta errno.
*/
MY_EXTERN int	SetsockoptReuseAddr(int s);

/**
\brief Serve per sapere se il socket (normale o CCS) passato come parametro &egrave; configurato in modo tale che la porta locale a cui viene collegato possa essere riutilizzata.

In altre parole, equivale ad interrogare il socket con la chiamata alla funzione che segue:\n
<code>
int OptVal, ris;\n
int OptLen;\n
ris=getsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *)&OptVal, &OptLen );\n
*pFlag=OptVal;
</code>
@param s il socket normale o CCS che si vuole interrogare
@param *pFlag puntatore a intero in cui viene salvato il risultato dell'interrogazione
@return restituisce 1 se va tutto bene nel qual caso scrive nella variabile intera puntata dal secondo parametro pFlag il valore 1 se il socket &egrave; configurato, altrimenti scrive 0. Restituisce 0 in caso di errore
*/
MY_EXTERN int	GetsockoptReuseAddr(int s, int *pFlag);

/**
\brief Equivale alla funzione bind() classica

Svolge lo stesso compito della bind() ma pu&ograve; essere applicata sia ai socket normali sia alle CCS.
@param sockfd socket a cui applicare la Bind
@param *my_addr struttura che indica l'indirizzo locale del socket
@param addrlen lunghezza della struttura my_addr
@return ritorna 0 in caso di successo, ritorna -1 in caso di errore e setta opportunamente errno
*/
MY_EXTERN int	Bind(int  sockfd, struct sockaddr *my_addr, socklen_t addrlen);

/**
\brief Equivale alla funzione listen() classica.

Svolge lo stesso compito e restituisce lo stesso risultato. Viene applicata sia ai socket normali sia alle CCS.
@param s il file descriptor del socket
@param backlog la lunghezza massima della lungheza della coda delle connessioni pendenti.
@return 0 se tutto va bene, -1 altrimenti.
*/
MY_EXTERN int	Listen(int s, int backlog);

/**
\brief Equivale alla funzione accept() classica.

Svolge lo stesso compito (accetta una connessione su un socket) e restituisce lo stesso risultato.
Viene applicata sia ai socket normali sia alle CCS.
@param s il file descriptor del socket
@param addr puntatore ad una struttura sockaddr
@param addrlen argomento valore-risultato
@return ritorna un intero non negativo che &egrave; il file descriptor per il socket accettato. In caso di errore ritorna -1.
*/
MY_EXTERN int	Accept(int   s,  struct  sockaddr  *addr,  socklen_t *addrlen);

/**
Equivale alla funzione connect() classica.

Svolge lo stesso compito (inizializza una connessione su un socket) e restituisce lo stesso risultato.
Viene applicata sia ai socket normali sia alle CCS.
@param sockfd il file descriptor del socket
@param serv_addr puntatore ad una struttura sockaddr e contiene l'indirizzo a cui connettersi.
@param addrlen lunghezza della struttura sockaddr
@return 0 in caso di successo, -1 in caso di errore
*/
MY_EXTERN int	Connect(int sockfd, const struct sockaddr *serv_addr, socklen_t addrlen);

/**
\brief Equivale alla funzione read() classica.

Svolge lo stesso compito (legge da un file descriptor) e restituisce lo stesso risultato. 
Viene applicata sia ai socket normali sia alle CCS.
@param fd il file descriptor
@param buf il buffer da riempire
@param count la quantit&agrave; di dati da leggere (in byte)
@return ritorna il numero di byte letti (0 indica la fine del file). In caso di errore viene restituito -1.
*/
MY_EXTERN ssize_t	Read(int fd, void *buf, size_t count);

/**
\brief Equivale alla funzione write() classica.

Svolge lo stesso compito e restituisce lo stesso risultato. 
Viene applicata sia ai socket normali (e pi&ugrave; in generale a tutti i file descriptor) sia alle CCS.
@param fd il file descriptor su cui scrivere
@param buf il buffer da cui leggere
@param count il numero di byte da scrivere
@return il numero di byte scritti (0 indica che niente &egrave; stato scritto). In caso di errore viene restituito -1.
*/
MY_EXTERN ssize_t	Write(int fd, const void *buf, size_t count);

/**
\brief Equivale alla funzione send() classica.

Svolge lo stesso compito (invia un messaggio su un socket) e restituisce lo stesso risultato. 
Viene applicata sia ai socket normali sia alle CCS.
@param s il file descriptor del socket
@param msg puntatore al messaggio
@param len la lunghezza del messaggio in bytes
@param flags parametro per regolare il comportamento della send
@return ritorna il numero di caratteri spediti, altrimenti -1.
*/
MY_EXTERN int	Send(int s, const void *msg, size_t len, int flags);

/**
\brief Serve per sapere se il socket s (normale o CCS) passato come primo parametro ha ricevuto dei byte che possono essere letti. 

In altre parole, equivale ad interrogare il socket con il codice che segue:\n
<code> if (ioctl (s,FIONREAD,pnum)==0) return(1);\n
else return(0);</code>
\n
Viene applicata sia ai socket normali sia alle CCS.
@param s il file descriptor del socket
@param pnum argomento valore-risultato. Conterr&agrave; la quantit&agrave; di byte disponibili.
@return Restituisce 0 in caso di errore e setta errno; restituisce 1 se va tutto bene, 
nel qual caso scrive nella variabile intera puntata dal secondo parametro pnum il numero di byte disponibili (maggiore o uguale a zero). 
*/
MY_EXTERN int	AvailableBytes(int s, int *pnum);

/**
\brief Equivale alla funzione close() classica.

Svolge lo stesso compito (chiude un file descriptor) e restituisce lo stesso risultato. Opera in modo non bloccante. 
Viene applicata sia ai socket normali (e pi&ugrave; in generale a tutti i file descriptor) sia alle CCS. 
Nel caso delle CCS, la Close non pu&ograve; essere chiamata se prima &egrave; stata chiamata la CloseWait().
@param fd il file descriptor da chiudere
@return 0 in caso di successo, -1 altrimenti.
 */
MY_EXTERN int	Close(int fd);

/**
\brief Chiude il modulo di sessione, rilasciando le risorse allocate.

Viene invocata una sola volta dal processo quando questo non vuole pi&ugrave; usare le comunicazioni. 
Non aspetta che tutte le connessioni CCS siano state terminate correttamente e termina tutto brutalmente. 
L'applicazione pu&ograve; invocare o solo la funzione CloseWait_TCP_Session_Module() oppure solo la funzione Close_TCP_Session_Module().
@param ptr puntatore alla struttura dati, pu&ograve; essere NULL. 
@return Restituisce 1 se va tutto bene, -1 in caso di errore di un qualche tipo.
*/
MY_EXTERN int	Close_TCP_Session_Module(void *ptr);

/**
\brief Ottiene un file descriptor
@param pfd argomento di valore-ritorno dove salvare il nuovo file descriptor.
@return 1 in caso di successo, 0 altrimenti.
*/
int ReserveFileDescriptor(int *pfd);

/**
\brief Controlla se avviene comunicazione in lettura sui socket a cui &egrave; associata

Gli viene passato un socket CCS listening e ciclicamente crea l'insieme di file descriptor nascosti generati da questo e chiama la Try_To_Read() che ne gestisce la comunicazione in lettura. In base al valore di ritorno della Try_To_Read() incrementa o meno una variabile che indica il tempo di inattivit&agrave;. Quando il tempo di inattivit&agrave; raggiunge INACTIVITY_TIMEOUT_SECONDS viene chiamata la funzione Manage_CRASH() per gestire il crash della connessione.
@param *par il socket CCS listening
*/
void *Read_Loop_Accept(void *par);

/**
\brief Controlla se avviene comunicazione in lettura sul socket a cui &egrave; associata

Gli viene passato un socket CCS ciclicamente estrae il suo file descriptor nascosto, lo inserisce in un insieme e chiama la Try_To_Read() che ne gestisce la comunicazione in lettura. In base al valore di ritorno della Try_To_Read() incrementa o meno una variabile che indica il tempo di inattivit&agrave;. Quando il tempo di inattivit&agrave; raggiunge INACTIVITY_TIMEOUT_SECONDS viene chiamata la funzione Manage_CRASH() per gestire il crash della connessione.
@param *par il socket CCS da controllare
*/
void *Read_Loop_Connect(void *par);

/**
\brief Controlla quali dei socket CCS nell'insieme che gli viene passato sono pronti in lettura

Usa la select() con un timeout di WAIT_TIME (10) secondi per sapere quali socket CCS sono pronti in lettura. Se il socket CCS pronto in lettura &egrave; un socket connesso viene chiamata la Read_Packet() che gestisce la lettura. Se invece si tratta di un socket listening viene chiamata la Manage_Accept(). Al ritorno dalla Manage_Accept() viene chiamata la fd_cond_accept_signal() per svegliare l'eventuale processo che ha chiamato l'Accept() e si &egrave; bloccato chiamando la fd_cond_accept_wait() aspettando cha la Manage_Accept() gestisse il tutto.
@param read_set l'insieme di file descriptor nascosti da controllare
@param max il valore massimo dei file descriptor nell'insieme + 1
@return ritorna 0 se nessun socket era pronto in lettura, ritorna 1 se almeno uno era pronto in lettura
*/
int Try_To_Read(fd_set read_set, int max);

/**
\brief Gestisce la scrittura su socket CCS

Gestisce la scrittura su socket CCS al posto della Write() e della Send(). L'unica differenza tra queste due funzioni sta nel parametro "flags" della Send() che viene passato invariato alla Real_Send(), mentre la Write() passa il valore 0. La Real_Send() crea il pacchetto CCS, lo passa alla CCS_Sendn() insieme a tutti gli altri parametri necessari e controlla la presenza di crash chiamando eventualmente la Manage_CRASH() per gestirlo.
@param fd_pub file descriptor pubblico
@param fd_hide file descriptor nascosto
@param *buf puntatore ai dati che l'applicazione vuole spedire
@param count lunghezza di buf
@param flags flags passate dall'applicazione
@return ritorna count
*/
ssize_t Real_Send(int fd_pub, int fd_hide, const void *buf, size_t count, int flags);

/**
\brief Crea un pacchetto CCS

Crea un pacchetto CCS secondo i parametri passatigli.
@param type tipo del pacchetto
@param seqnum numero di sequenza del pacchetto
@param size dimensione del payload che segue l'header
@param *seg puntatore al payload
@param *pkt puntatore all'area di memoria che conterr&agrave; il pacchetto CCS (header + payload)
*/
void Pkt_Craft(int type, unsigned int seqnum, size_t size, const void *seg, char *pkt);

/**
\brief Scrive sul file descriptor nascosto

Usa la send() per scrivere sul file descriptor nascosto. Non ritorna finch&egrave; non ha spedito tutto, o finch&egrave; non rileva un crash sulla connessione o finch&egrave; non rileva un errore grave. Viene interpretato come crash della connessione un errore della send() di tipo EPIPE o ECONNRESET.
@param fd_hide file descriptor nascosto su cui scrivere
@param *buf pacchetto CCS da spedire
@param count lunghezza del pacchetto CCS (header + payload)
@param flags flags da passare a send()
@return in caso di successo ritorna il numero di bytes scritt, cio&egrave; count, in caso di crash di connessione ritorna RW_CRASH, in caso di errore ritorna -1 e lascia settato errno
*/
ssize_t CCS_Sendn(int fd_hide, char *buf, size_t count, int flags);

/**
\brief Legge dal file descriptor nascosto

Usa la read() per leggere dal file descriptor nascosto. Deve essere chiamata quando si &egrave; sicuri che ci sia almeno 1 byte disponibile per la lettura. Non ritorna finch&egrave; non ha letto tutto, o finch&egrave; non rileva un crash sulla connessione o finch&egrave; non rileva un errore grave. Viene interpretato come crash della connessione un errore sulla read() di tipo ECONNRESET o l'assenza di bytes disponibili per la lettura nonostante la mancata lettura di tutto il pacchetto e nonostante il socket risulti pronto per la lettura dopo una chiamata alla select().
@param fd_hide file descriptor nascosto da cui leggere
@param *buf puntatore al buffer della CCS da riempire
@param size quantit&agrave; di byte da leggere
@return il numero di byte letti, RW_CRASH in caso di errore di connessione, ritorna -1 in caso di errore grave e lascia settato errno.
*/
ssize_t	CCS_Readn(int fd_hide, void *buf, size_t size);

/**
\brief Gestisce un socket CCS listening.

Viene chiamata quando &egrave; possibile fare una chiamata ad accept() senza bloccarsi. Instaura la connessione TCP, legge il pacchetto di richiesta e l'fd_peer che segue, interpretando il tipo di richiesta in base al tipo dell'header. Se &egrave; una richiesta per una prima connessione, questa viene accettata solo se naccept (il numero di accept() pendenti) &egrave; maggiore di zero. Se invece &egrave; una richiesta di riconnessione questa viene comunque accettata. In entrambi i casi l'instaurazione della connessione viene gestita in maniera completa, inserendo il nuovo socket CCS nella lista di quelli attivi, nel primo caso, modificando il file descriptor nascosto nel secondo.\n
Nel caso di una nuova connessione il thread che ha chiamato l'Accept() resta bloccato sulla condition accept fintanto che la connessione non viene gestita; per passare il nuovo file descriptor pubblico al thread in attesa questo viene inserito nel campo fd_accept del file descriptor listening. Quando il thread verr&agrave; svegliato con una pthread_cond_signal(), questo estrae il file descriptor pubblico e setta il campo fd_accept del socket CCS listening al valore corretto.
@param fd_pub file descriptor pubblico del socket CCS listening
*/
void Manage_Accept(int fd_pub);

/**
\brief Gestisce la lettura di un pacchetto CCS

Legge un header CCS e in base al tipo, chiama la funzione per gestire il pacchetto.
@param fd_pub file descriptor pubblico del Socket CCS
@param fd_hide file descriptor nascosto del socket CCS
*/
void Read_Packet(int fd_pub, int fd_hide);

/**
\brief Gestisce la lettura di un pacchetto dati.

Legge il payload di un pacchetto dati. Manda un ack se il socket non &egrave; il stato PEER_CLOSED o CLOSED. Confrontando il numero di sequenza del pacchetto con il campo fd_item::last_seqnum_rcv scarta i pacchetti gi&agrave; ricevuti e inserisce nel buffer dei pacchetti non ancora letti dall'applicazione (not_read_buf) quelli nuovi.
@param fd_pub file descriptor pubblico del Socket CCS
@param fd_hide file descriptor nascosto del socket CCS
@param size numero di byte da leggere del payload da leggere
@param seqnum numero di sequenza del pacchetto CCS da leggere
@return il numero di byte letti, mentre in caso di errore grave -1, RW_CRASH in caso individui un errore di connessione.
*/
int Manage_SEG(int fd_pub, int fd_hide, size_t size, unsigned int seqnum);

/**
\brief Gestisce la lettura di un ack

Rimuove il primo pacchetto nel buffer di pacchetti in attesa di ack.
@param fd_pub file descriptor pubblico del Socket CCS
@param fd_hide file descriptor nascosto del socket CCS
@param seqnum numero di sequenza del pacchetto CCS a cui si riferisce l'ack
*/
void Manage_ACK(int fd_pub, int fd_hide, unsigned int seqnum);

/**
\brief Gestisce la lettura di un pacchetto di notifica di chiusura volontaria della connessione

Inserisce nel buffer dei pacchetti non ancora letti dall'applicazione un elemento speciale che non viene mai rimosso, quando la Read_From_Buffer() trova questo pacchetto sa che non legger&agrave; pi&ugrave; niente da questo socket e ritorna 0. Spedisce un pacchetto di ack (tipo ACK_END) gestendo eventuali crash della connessione e cambia lo stato del socket CCS in PEER_CLOSED.
@param fd_pub file descriptor pubblico del Socket CCS
@param fd_hide file descriptor nascosto del socket CCS
*/
void Manage_END(int fd_pub, int fd_hide);

/**
\brief Gestisce la lettura di un ack per un pacchetto di notifica di chiusura volontaria della connessione

Chiude il file descriptor pubblico e nascosto del socket CCS chiamando la close().
@param fd_pub file descriptor pubblico del Socket CCS
@param fd_hide file descriptor nascosto del socket CCS
*/
void Manage_ACK_END(int fd_pub, int fd_hide);

/**
\brief Legge i pacchetti necessari dal buffer dei pacchetti non ancora letti dall'applicazione

Legge i pacchetti necessari a completare la Read() che l'ha chiamata dal buffer not_read_buf, elimina dal buffer i pacchetti che consuma, gestisce la condizione in cui nel buffer sia presente un pacchetto pi&ugrave; grande di quanto gli serva modificandone la dimensione e prendendo solo la parte necessaria. Se il buffer &egrave; vuoto o non ci sono sufficienti pacchetti per completare la Read() si mette in attesa sulla condizione fd_item::avail.
@param fd_pub file descriptor pubblico del Socket CCS
@param fd_hide file descriptor nascosto del socket CCS
@param *buf attributo valore-ritorno
@param count numero di byte da leggere
@return il numero di byte letti o 0 in caso il socket CCS sia chiuso
*/
ssize_t Read_From_Buffer(int fd_pub, int fd_hide, void *buf, size_t count);

/**
\brief Tenta di ristabilire la connessione.

Gestisce in maniera adeguata la riconnessione sia da lato server che da lato client.\n
Da lato client crea un nuovo file descriptor privato e tenta di connetterlo chiamando la connect(). Se la connect() non va a buon fine, viene richiamata ogni RETRY_INTERVAL_SECONDS per un massimo di RETRY_TIMEOUT_SECONDS. Nel caso la connect() andasse a buon fine viene creato e spedito un pacchetto di richiesta di riconnessione. Attende una risposta (CONNECTION_ESTABLISHED) alla richiesta appena mandata, se non dovesse arrivarle l'applicazione termina con -1. A riconnessione avvenuta setta il file descriptor privato al nuovo valore.\n
Da lato server controlla che sia possibile effettuare una accept() ogni RETRY_INTERVAL_SECONDS per un massimo di RETRY_TIMEOUT_SECONDS. Nel caso sia possibile, viene chiamata la Manage_Accept() per gestirla.
@param fd_pub file descriptor pubblico del Socket CCS
@return -1 se non riescie a ristabilire la connessione, 0 altrimenti.
*/
int Reconnect(int fd_pub);

/**
\brief Spedisce tutti i pacchetti in attesa di ack.


@param fd_pub file descriptor pubblico del Socket CCS
@return 1 se tutto va bene, RW_CRASH in caso di errore di connessione. Termina l'applicazione in caso di errore grave
*/
int Send_Old_Packets(int fd_pub);

/**
\brief Gestisce il crash della connessione.

Chiama la Reconnect() per ristabilire la connessione. Se la connessione non viene ristabilita l'applicazione viene terminata, altrimenti setta nel nuovo file descriptor nascosto tutte le opzioni che erano settate nel vecchio file descriptor nascosto. Infine chiama la Send_Old_Packets() per rispedire i pacchetti in attesa di ack.
@param fd_pub file descriptor pubblico del Socket CCS
@return 0 in caso di successo, l'applicazione viene terminata con -1 in caso di errore grave.
*/
ssize_t Manage_CRASH(int fd_pub);

#endif   /* __TCP_SESSION_H__  */
