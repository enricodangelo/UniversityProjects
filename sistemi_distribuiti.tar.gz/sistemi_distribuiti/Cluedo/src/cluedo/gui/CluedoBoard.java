/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.CellType;
import cluedo.common.Constants;
import cluedo.common.ManhattanDistance;
import cluedo.gui.listener.CustomMouseListener;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 *
 * @author enrico
 */
public class CluedoBoard extends JPanel implements IGUIComponent {

	private IController rootComponent;
	private int boardRows;
	private int boardColumns;
	private int[][] leftMargin;
	private int[][] rightMargin;
	private int[][] upperMargin;
	private int[][] lowerMargin;
	FontMetrics fontMetrics;
	private CustomMouseListener customMouseListener;

	public CluedoBoard() {
		super();

		boardRows = Constants.BOARD_ROWS;
		boardColumns = Constants.BOARD_COLUMNS;

		customMouseListener = new CustomMouseListener(this);

		leftMargin = new int[boardRows][boardColumns];
		rightMargin = new int[boardRows][boardColumns];
		upperMargin = new int[boardRows][boardColumns];
		lowerMargin = new int[boardRows][boardColumns];

		fontMetrics = new FontMetrics(Constants.BOARD_FONT_BIG) {
		};
	}

	public void initComponent(IController rootComponent) {
		this.rootComponent = rootComponent;

		addMouseListener(customMouseListener);
	}

	@Override
	public void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;

		g2d.setColor(Constants.BOARD_BACKGROUND_COLOR);
		g2d.fillRect(0, 0, getSize().width, getSize().width);

		int cellWidth = (getSize().width - Constants.BOARD_GAP) / boardColumns;
		int cellHeight = (getSize().height - Constants.BOARD_GAP) / boardRows;

		for (int i = 0; i < boardRows; i++) {
			for (int j = 0; j < boardColumns; j++) {
				int row = i;
				int column = j;
				int cellX = (column * cellWidth) + Constants.BOARD_GAP;
				int cellY = (row * cellHeight) + Constants.BOARD_GAP;

				leftMargin[i][j] = cellX;
				rightMargin[i][j] = cellX + cellWidth;
				upperMargin[i][j] = cellY;
				lowerMargin[i][j] = cellY + cellHeight;

				CellType cell = rootComponent.getCellType(i, j);

				switch (cell) {
					case CORRIDOR:
					case BALLROOM_DOOR:
					case BILLIARD_ROOM_DOOR:
					case CONSERVATORY_DOOR:
					case DINING_ROOM_DOOR:
					case HALL_DOOR:
					case KITCHEN_DOOR:
					case LIBRARY_DOOR:
					case LOUNGE_DOOR:
					case STUDY_DOOR:
						/* disegno le caselle
						anche le porte vengono prima disegnate come caselle, poi gli viene disegnata la porta sopra*/
						g2d.setColor(Constants.BOARD_CELL_COLOR);
						g2d.fillRect(cellX + 1, cellY + 1, cellWidth - 2, cellHeight - 2);
						break;
					case COLONEL_MUSTARD_STARTING_POINT:
					case MISS_SCARLETT_STARTING_POINT:
					case MR_GREEN_STARTING_POINT:
					case MRS_PEACOCK_STARTING_POINT:
					case MRS_WHITE_STARTING_POINT:
					case PROFESSOR_PLUM_STARTING_POINT:
						/* disegno i punti di partenza dei personaggi */
						g2d.setColor(Constants.BOARD_STARTING_POINT_COLOR);
						g2d.fillRect(cellX + 1, cellY + 1, cellWidth - 2, cellHeight - 2);
						g2d.setColor(Color.BLACK);
						g2d.drawRect(cellX + 1, cellY + 1, cellWidth - 2, cellHeight - 2);
						break;
				}
			}
		}

		/* disegno le stanze */
		for (int k = 0; k < Constants.NUMBER_OF_ROOMS; k++) {
			int roomX = (Constants.ROOM_UPPERLEFT_CORNER[k][Constants.X] * cellWidth) + Constants.BOARD_GAP;
			int roomY = (Constants.ROOM_UPPERLEFT_CORNER[k][Constants.Y] * cellHeight) + Constants.BOARD_GAP;
			int roomWidth = ((Constants.ROOM_LOWERRIGHT_CORNER[k][Constants.X] - Constants.ROOM_UPPERLEFT_CORNER[k][Constants.X]) + 1) * cellWidth;
			int roomHeight = ((Constants.ROOM_LOWERRIGHT_CORNER[k][Constants.Y] - Constants.ROOM_UPPERLEFT_CORNER[k][Constants.Y]) + 1) * cellHeight;

			/* disegno la stanza vera e propria */
			g2d.setColor(Constants.ROOMS_COLOR);
			g2d.fillRect(roomX + 1, roomY + 1, roomWidth - 2, roomHeight - 2);
			g2d.setColor(Color.BLACK);
			g2d.drawRect(roomX + 1, roomY + 1, roomWidth - 2, roomHeight - 2);

			/* scrivo il nome della stanza */
			g2d.setColor(Color.BLACK);
			g2d.setFont(Constants.BOARD_FONT_BIG);
			int stringX = (int) (roomX + (roomWidth / 2) - (fontMetrics.getStringBounds(Constants.ROOM_NAME[k], g2d).getWidth() / 2));
			int stringY = (int) (roomY + (roomHeight / 2) + (fontMetrics.getStringBounds(Constants.ROOM_NAME[k], g2d).getHeight() / 2));

			g2d.drawString(Constants.ROOM_NAME[k], stringX, stringY);
		}

		/* disegno le porte */
		for (int k = 0; k < Constants.DOORS.length; k++) {
			int[][] roomDoors = Constants.DOORS[k];

			for (int l = 0; l < roomDoors.length; l++) {
				int[] door = roomDoors[l];


				int x = (door[0] * cellWidth) + Constants.BOARD_GAP;
				int y = (door[1] * cellHeight) + Constants.BOARD_GAP;
				int doorWidth = cellWidth;
				int doorHeight = cellHeight;
				int boardX1 = door[0];
				int boardX2 = door[2];
				int boardY1 = door[1];
				int boardY2 = door[3];

				if (boardX1 != boardX2) {
					x += cellWidth - (Constants.DOOR_SIZE / 2);
					doorWidth = Constants.DOOR_SIZE;
				} else if (boardY1 != boardY2) {
					y += cellHeight - (Constants.DOOR_SIZE / 2);
					doorHeight = Constants.DOOR_SIZE;
				}

				g2d.setColor(Constants.DOORS_COLOR);
				g2d.fillRect(x, y, doorWidth, doorHeight);
				g2d.setColor(Color.BLACK);
				g2d.drawRect(x, y, doorWidth, doorHeight);
			}
		}

		/* disegno l'area in cui e' possibile spostarsi */
		Integer[] playerInTurnCurrentPosition = rootComponent.getPlayerInTurnPosition();
		ArrayList<Integer[]> moves = rootComponent.getMoves();
		if (moves.size() > 0) {

			for (Integer[] cell : moves) {
				Integer distance = ManhattanDistance.calculate(playerInTurnCurrentPosition, cell);

				if (!distance.equals(0)) {
					int cellX = (cell[Constants.X] * cellWidth) + Constants.BOARD_GAP;
					int cellY = (cell[Constants.Y] * cellHeight) + Constants.BOARD_GAP;
					Color backgroundColor;
					Color foregroundColor;

					if (rootComponent.isMyTurn()) {
						backgroundColor = Constants.BOARD_AVAILABLE_CELL_MY_TURN_BACKGROUNG_COLOR;
						foregroundColor = Constants.BOARD_AVAILABLE_CELL_MY_TURN_FOREGROUNG_COLOR;
					} else {
						backgroundColor = Constants.BOARD_AVAILABLE_CELL_NOT_MY_TURN_BACKGROUNG_COLOR;
						foregroundColor = Constants.BOARD_AVAILABLE_CELL_NOT_MY_TURN_FOREGROUNG_COLOR;
					}

					g2d.setColor(backgroundColor);
					g2d.fillRect(cellX + 1, cellY + 1, cellWidth - 2, cellHeight - 2);
					g2d.setColor(foregroundColor);
					g2d.setFont(Constants.BOARD_FONT_SMALL);

					int stringX = (int) (cellX + (cellWidth / 2) - (fontMetrics.getStringBounds(distance.toString(), g2d).getWidth() / 2));
					int stringY = (int) (cellY + (cellHeight / 2) + (fontMetrics.getStringBounds(distance.toString(), g2d).getHeight() / 2));
					stringY -= 5;

					g2d.drawString(distance.toString(), stringX, stringY);
				}
			}
		}

		/* disegno le pedine dei personaggi attivi */
		for (Integer character : rootComponent.getCharactersInGame()) {
			Integer[] position = rootComponent.getCharacterPosition(character);

			if (position != null) {
				int cellX = (position[Constants.X] * cellWidth) + Constants.BOARD_GAP;
				int cellY = (position[Constants.Y] * cellHeight) + Constants.BOARD_GAP;

				g2d.setColor(Constants.CHARACTER_COLORS[character]);
				g2d.fillOval(cellX + 1, cellY + 1, cellWidth - 2, cellHeight - 2);
				g2d.setColor(Color.BLACK);
				g2d.drawOval(cellX + 1, cellY + 1, cellWidth - 2, cellHeight - 2);
			}
		}
	}

	public void update() {
		repaint();
	}

	public void setInput(InputEvent e) {
		Point mousePosition = ((MouseEvent) e).getPoint();
		Integer[] newPosition = new Integer[2];

		for (int i = 0; i < boardRows; i++) {
			for (int j = 0; j < boardColumns; j++) {
				if ((mousePosition.x >= leftMargin[i][j])
						&& (mousePosition.x <= rightMargin[i][j])
						&& (mousePosition.y >= upperMargin[i][j])
						&& (mousePosition.y <= lowerMargin[i][j])) {

					newPosition[Constants.X] = j;
					newPosition[Constants.Y] = i;
				}
			}
		}

		/* la pedina puo' muoversi solo secondo lo schema:
		 *
		 *                                   DESTINAZIONE
		 *                   | corridoio | porta | stanza | punto di partenza |
		 * PARTENZA          --------------------------------------------------
		 * corridoio         |   TRUE    | TRUE  |  FALSE |       FALSE       |
		 * porta             |   TRUE    | TRUE  |  TRUE  |       FALSE       |
		 * stanza            |   FALSE   | TRUE  |  TRUE  |       FALSE       |
		 * punto di partenza |   TRUE    | TRUE  |  TRUE  |       FALSE       |
		 *                   --------------------------------------------------
		 */
		if ((rootComponent.isMyTurn()) && (rootComponent.isAValidMove(newPosition))) {
			rootComponent.setLocalPlayerPosition(newPosition);
		}
	}
}
