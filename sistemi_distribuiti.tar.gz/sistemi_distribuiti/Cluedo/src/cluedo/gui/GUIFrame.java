/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.Constants;
import java.awt.Dimension;
import java.awt.event.InputEvent;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author enrico
 */
public class GUIFrame extends JFrame implements IGUIComponent {

	private ArrayList<IGUIComponent> components;
	private IController rootComponent;
	private JPanel mainPanel;
	private JPanel upperPanel;
	private GamePanel gamePanel;
	private CardsPanel cardsPanel;
	private ActionPanel actionPanel;
	private String titleString;

	public GUIFrame() {
		super();
		components = new ArrayList<IGUIComponent>();
		mainPanel = new JPanel();
		upperPanel = new JPanel();
		gamePanel = new GamePanel();
		cardsPanel = new CardsPanel();
		actionPanel = new ActionPanel();
		titleString = Constants.APP_NAME;
	}

	public void initComponent(IController rootComponent) {
		this.rootComponent = rootComponent;

		gamePanel.initComponent(rootComponent);
		cardsPanel.initComponent(rootComponent);
		actionPanel.initComponent(rootComponent);

		upperPanel.setLayout(new BoxLayout(upperPanel, BoxLayout.X_AXIS));
		upperPanel.add(gamePanel);
		upperPanel.add(cardsPanel);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		mainPanel.add(upperPanel);
		mainPanel.add(actionPanel);

		add(mainPanel);

		setMinimumSize(new Dimension(Constants.APP_WIDTH, Constants.APP_HEIGHT));
		setMaximumSize(new Dimension(Constants.APP_WIDTH * 2, Constants.APP_HEIGHT * 2));

		components.add(gamePanel);
		components.add(cardsPanel);
		components.add(actionPanel);

		pack();
		setResizable(false);
		setVisible(true);
	}

	public void update() {
		titleString = rootComponent.getTitle();
		setTitle(titleString);

		for (IGUIComponent guiComponent : components) {
			guiComponent.update();
		}
	}

	public void setInput(InputEvent e) {
		
	}
}
