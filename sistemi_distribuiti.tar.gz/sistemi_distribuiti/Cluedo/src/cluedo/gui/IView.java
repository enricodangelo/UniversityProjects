/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.gui;

import cluedo.game.IModel;
import cluedo.common.GameState;

/**
 *
 * @author enrico
 */
public interface IView {

	public void setModel(IModel model);

	public void setData(GameState gameState);

	public void init();

	public void update();

}
