/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.gui;

import cluedo.common.CardState;
import cluedo.common.CellType;
import cluedo.common.GamePhase;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public interface IController {

	public void endRegistrationPhase();
	
	public void startNewMatch();

	public boolean isCharacterAvailable(Integer i);

	public void chooseCharacter(int i);

	public Integer getNumberOfPlayers();

	public GamePhase getGamePhase();

	public String getTitle();

	public String getPlayerCharacter();

	public ArrayList<Integer> getLocalPlayerCards();

	public ArrayList<Integer> getEnvelope();

	public void initializeGame();

	public void clickCard(Integer cardID);

	public void checkCardsClicked();

	public ArrayList<Integer> getCharactersInGame();

	public Integer[] getCharacterPosition(Integer characterID);

	public void setLocalPlayerPosition(Integer[] position);

	public Integer[] getLocalPlayerPosition();

	public CardState getCardState(Integer cardIndex);

	public boolean isMyTurn();

	public boolean canMakeASuggestion();

	public boolean canMakeAnAccusation();

	public boolean canEndTurn();

	public CellType getCellType(int row, int column);

	public boolean isPlayingPhase();

	public boolean canRollTheDice();

	public void endTurn();

	public ArrayList<Integer[]> getMoves();

	public boolean isAValidMove(Integer[] move);

	public void rollTheDice();

	public Integer[] getPlayerInTurnPosition();

	public boolean canClick();

	public void suggest();

	public void accuse();

	public boolean amITheWinner();
	
	public String getWinnerName();

	public CardState getEnvelopeState();
}
