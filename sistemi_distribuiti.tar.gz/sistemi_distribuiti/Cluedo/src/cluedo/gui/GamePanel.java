/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.GamePhase;
import java.awt.event.InputEvent;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.JPanel;

/**
 *
 * @author enrico
 */
public class GamePanel extends JPanel implements IGUIComponent {

	private IController rootComponent;
	private ArrayList<IGUIComponent> components;
	private GamePhase lastGamePhase;
	private RegistrationPanel registrationPanel;
	private CharacterSelectionPanel characterSelectionPanel;
	private InitializationPanel initializationPanel;
	private BoardPanel boardPanel;
	private RestartPanel restartPanel;

	public GamePanel() {
		super();
		components = new ArrayList<IGUIComponent>();
		lastGamePhase = null;
		registrationPanel = new RegistrationPanel();
		characterSelectionPanel = new CharacterSelectionPanel();
		initializationPanel = new InitializationPanel();
		boardPanel = new BoardPanel();
		restartPanel = new RestartPanel();
	}

	public void initComponent(IController rootComponent) {
		this.rootComponent = rootComponent;

		registrationPanel.initComponent(rootComponent);
		characterSelectionPanel.initComponent(rootComponent);
		initializationPanel.initComponent(rootComponent);
		boardPanel.initComponent(rootComponent);
		restartPanel.initComponent(rootComponent);

		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));

		registrationPanel.setVisible(false);
		characterSelectionPanel.setVisible(false);
		initializationPanel.setVisible(false);
		boardPanel.setVisible(false);
		restartPanel.setVisible(false);

		components.add(registrationPanel);
		components.add(characterSelectionPanel);
		components.add(initializationPanel);
		components.add(boardPanel);
		components.add(restartPanel);

		add(registrationPanel);
		add(characterSelectionPanel);
		add(initializationPanel);
		add(boardPanel);
		add(restartPanel);
	}

	public void update() {
		GamePhase currentGamePhase = rootComponent.getGamePhase();

		/* solo se la fase di gioco e' cambiata */
		if ((lastGamePhase == null) || (lastGamePhase != currentGamePhase)) {
			registrationPanel.setVisible(false);
			characterSelectionPanel.setVisible(false);
			initializationPanel.setVisible(false);
			boardPanel.setVisible(false);
			restartPanel.setVisible(false);

			switch (currentGamePhase) {
				case REGISTRATION:
					registrationPanel.setVisible(true);
					break;
				case CHARACTER_SELECTION:
					characterSelectionPanel.setVisible(true);
					break;
				case GAME_INITIALIZATION:
					initializationPanel.setVisible(true);
					break;
				case IN_TURN:
				case NOT_IN_TURN:
					boardPanel.setVisible(true);
					break;
				case RESTART:
					restartPanel.setVisible(true);
					break;
				default:
					System.err.println("Errore: fase di gioco sconosciuta. currentGamePhase: " + currentGamePhase);
			}
		}

		for (IGUIComponent guiComponent : components) {
			guiComponent.update();
		}
	}

	public void setInput(InputEvent e) {
	}
}
