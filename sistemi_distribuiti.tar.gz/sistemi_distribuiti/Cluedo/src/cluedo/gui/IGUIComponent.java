/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.gui;

import java.awt.event.InputEvent;

/**
 *
 * @author enrico
 */
public interface IGUIComponent {

	public void initComponent(IController rootComponent);

	public void update();
	
	public void setInput(InputEvent e);
}
