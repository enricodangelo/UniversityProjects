/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.CellType;
import cluedo.common.CardState;
import cluedo.game.IModel;
import cluedo.common.Constants;
import cluedo.common.GamePhase;
import cluedo.common.GameState;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author enrico
 */
public class CluedoGUI implements IView, IController {

	private IModel model;
	private GUIFrame frame;
	private GameState gameState;
	private boolean makingASuggestion;
	private boolean makingAnAccusation;
	private Map<Integer, CardState> previousCardState;
	private ArrayList<Integer> proposedSolution;

	public CluedoGUI() {
		frame = new GUIFrame();
		makingASuggestion = false;
		makingAnAccusation = false;
		previousCardState = new Hashtable<Integer, CardState>();
		proposedSolution = new ArrayList<Integer>();
	}

	public void setData(GameState gameState) {
		this.gameState = gameState;
	}

	public void setModel(IModel model) {
		this.model = model;
	}

	public void init() {
		frame.initComponent(this);
		frame.update();
	}

	public void update() {
		Logger.getLogger(getClass().getName()).logp(
				Level.FINE,
				getClass().getName(),
				"update",
				"Ricevuto status aggiornato.");

		frame.update();
	}

	public Integer getNumberOfPlayers() {
		Integer numberOfPlayers = gameState.getNumberOfPlayers();

		return numberOfPlayers;
	}

	public GamePhase getGamePhase() {
		return gameState.getGamePhase();
	}

	public boolean isPlayingPhase() {
		boolean result;

		if ((gameState.getGamePhase() == GamePhase.IN_TURN)
				|| (gameState.getGamePhase() == GamePhase.NOT_IN_TURN)) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	public String getTitle() {
		String title = Constants.APP_NAME;
		Integer localPlayerGUID = gameState.getLocalPlayerGUID();

		String name = gameState.getPlayerName(localPlayerGUID);
		if (name != null) {
			title += " - " + gameState.getPlayerName(localPlayerGUID);
		}

		Integer localPlayerCharacter = gameState.getPlayerCharacter(localPlayerGUID);
		if (localPlayerCharacter != null) {
			title += " - " + Constants.CHARACTER_NAME[localPlayerCharacter];
		}

		return title;
	}

	public String getPlayerCharacter() {
		String result = "";

		Integer localPlayerCharacter = gameState.getPlayerCharacter(gameState.getLocalPlayerGUID());
		if (localPlayerCharacter != null) {
			result = Constants.CHARACTER_NAME[localPlayerCharacter];
		}

		return result;
	}

	public ArrayList<Integer> getCharactersInGame() {
		ArrayList<Integer> result = new ArrayList<Integer>();

		for (Integer playerGuid : gameState.getPlayersGUIDS()) {
			Integer character = gameState.getPlayerCharacter(playerGuid);

			if (character != null) {
				result.add(character);
			}
		}

		return result;
	}

	public ArrayList<Integer> getLocalPlayerCards() {
		return gameState.getPlayerCards(gameState.getLocalPlayerGUID());
	}

	public ArrayList<Integer> getEnvelope() {
		return gameState.getEnvelope();
	}

	public void startNewMatch() {
		model.startNewMatch();
	}

	public void endRegistrationPhase() {
		model.sendEndRegistrationPhase();
	}

	public boolean isCharacterAvailable(Integer i) {
		return gameState.isCharacterAvailable(i);
	}

	public void chooseCharacter(int i) {
		model.chooseCharacter(i);
	}

	public void initializeGame() {
		model.initializeMatchData();
	}

	public Integer[] getCharacterPosition(Integer characterID) {
		Integer[] result = null;

		for (Integer playerGUID : gameState.getPlayersGUIDS()) {
			if (gameState.getPlayerCharacter(playerGUID).equals(characterID)) {
				result = gameState.getPlayerPosition(playerGUID);
			}
		}

		return result;
	}

	public void setLocalPlayerPosition(Integer[] position) {
		model.sendPlayerPosition(position);
	}

	public Integer[] getLocalPlayerPosition() {
		return gameState.getPlayerPosition(gameState.getLocalPlayerGUID());
	}

	public Integer[] getPlayerInTurnPosition() {
		return gameState.getPlayerPosition(gameState.getPlayerInTurn());
	}

	public CellType getCellType(int row, int column) {
		return gameState.getCellType(row, column);
	}

	public boolean canRollTheDice() {
		boolean result;

		if ((gameState.getGamePhase() == GamePhase.IN_TURN)
				&& (!makingASuggestion)
				&& (!makingAnAccusation)) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	public boolean canMakeASuggestion() {
		boolean result;

		if (gameState.isPlayerInARoom()
				&& (!makingASuggestion)
				&& (!makingAnAccusation)) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	public boolean canMakeAnAccusation() {
		boolean result;

		if ((!makingASuggestion) && (!makingAnAccusation)) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	public boolean canEndTurn() {
		return canMakeAnAccusation();
	}

	public CardState getCardState(Integer cardIndex) {
		return gameState.getCardState(cardIndex);
	}

	public void endTurn() {
		model.sendEndTurn();
	}

	public boolean isMyTurn() {
		if (gameState.getGamePhase() == GamePhase.IN_TURN) {
			return true;
		} else {
			return false;
		}
	}

	public ArrayList<Integer[]> getMoves() {
		return gameState.getMoves();
	}

	public void rollTheDice() {
		Integer diceOutcome = model.rollTheDice();

		model.sendDiceOutcome(diceOutcome);
	}

	public boolean isAValidMove(Integer[] move) {
		boolean found = false;

		for (Integer[] validMove : gameState.getMoves()) {
			if ((validMove[0].equals(move[0])) && (validMove[1].equals(move[1]))) {
				found = true;
			}

		}

		return found;
	}

	public boolean canClick() {
		return makingASuggestion || makingAnAccusation;
	}

	public void clickCard(Integer cardID) {
		boolean canAdd = true;

		/* faccio in modo di scegliere una carta di ogni tipo:
		personaggio, stanza, arma */
		for (Integer proposedSolutionPart : proposedSolution) {
			if ((cardID.compareTo(Constants.CHARACTERS_OFFSET) >= 0)
					&& (cardID.compareTo(Constants.CHARACTERS_LIMIT) < 0)
					&& (proposedSolutionPart.compareTo(Constants.CHARACTERS_OFFSET) >= 0)
					&& (proposedSolutionPart.compareTo(Constants.CHARACTERS_LIMIT) < 0)) {
				canAdd = false;

			} else if ((cardID.compareTo(Constants.ROOMS_OFFSET) >= 0)
					&& (cardID.compareTo(Constants.ROOMS_LIMIT) < 0)
					&& (proposedSolutionPart.compareTo(Constants.ROOMS_OFFSET) >= 0)
					&& (proposedSolutionPart.compareTo(Constants.ROOMS_LIMIT) < 0)) {
				canAdd = false;
			} else if ((cardID.compareTo(Constants.WEAPONS_OFFSET) >= 0)
					&& (cardID.compareTo(Constants.WEAPONS_LIMIT) < 0)
					&& (proposedSolutionPart.compareTo(Constants.WEAPONS_OFFSET) >= 0)
					&& (proposedSolutionPart.compareTo(Constants.WEAPONS_LIMIT) < 0)) {
				canAdd = false;
			}
		}

		if (makingASuggestion) {
			/* se e' una carta "stanza" */
			if ((cardID.compareTo(Constants.ROOMS_OFFSET) >= 0)
					&& (cardID.compareTo(Constants.ROOMS_LIMIT) < 0)) {
				/* se non e' la stanza in cui sono non posso aggiungerla */
				canAdd = gameState.isTheRightRoomCard(cardID);
			}
		}

		if (canAdd) {
			proposedSolution.add(cardID);
			previousCardState.put(cardID, gameState.getCardState(cardID));
			gameState.setCardState(cardID, CardState.SELECTED);
		}
		update();
	}

	public void checkCardsClicked() {
		if (proposedSolution.size() == Constants.ENVELOPE_SIZE) {
			/* assegno alle carte il loro stato precedente */
			for (Integer currentCardID : proposedSolution) {
				gameState.setCardState(currentCardID, previousCardState.get(currentCardID));
			}

			/* invoco il giusto metodo in base all'azione che sto compiendo */
			if (makingASuggestion) {
				model.makeSuggestion(proposedSolution);
			} else if (makingAnAccusation) {
				model.makeAccusation(proposedSolution);
			}

			/* resetto tutte le variabili */
			previousCardState = new Hashtable<Integer, CardState>();
			proposedSolution = new ArrayList<Integer>();
			makingASuggestion = false;
			makingAnAccusation = false;
		}
	}

	public void suggest() {
		makingASuggestion = true;
		update();
	}

	public void accuse() {
		makingAnAccusation = true;
		update();
	}

	public boolean amITheWinner() {
		boolean result = false;
		Integer winnerGUID = gameState.getWinnerGUID();

		if (winnerGUID != null) {
			if (winnerGUID.equals(gameState.getLocalPlayerGUID())) {
				result = true;
			}
		}

		return result;
	}

	public String getWinnerName() {
		return gameState.getPlayerName(gameState.getWinnerGUID());
	}

	public CardState getEnvelopeState() {
		return gameState.getEnvelopeState();
	}
}
