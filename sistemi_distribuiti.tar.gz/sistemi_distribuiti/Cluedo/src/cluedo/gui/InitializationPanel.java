/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.gui;

import cluedo.common.Constants;
import cluedo.gui.listener.CustomKeyListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author enrico
 */
public class InitializationPanel extends JPanel implements IGUIComponent {

	private IController rootComponent;
	private KeyListener customKeyListener;
	private JTextField initializationTextField;

	public InitializationPanel() {
		super();

		customKeyListener = new CustomKeyListener(this);
		initializationTextField = new JTextField();
	}

	public void initComponent(IController rootComponent) {
		this.rootComponent = rootComponent;

		initializationTextField.setEditable(false);

		initializationTextField.setBackground(Constants.INITIALIZATION_BACKGROUND_COLOR);
		initializationTextField.setForeground(Constants.INITIALIZATION_FOREGROUND_COLOR);
		initializationTextField.setBorder(BorderFactory.createEmptyBorder());
		initializationTextField.setFont(Constants.INITIALIZATION_FONT);
		initializationTextField.setText(Constants.INITIALIZATION_LABEL);
		initializationTextField.setHorizontalAlignment(JTextField.CENTER);
		initializationTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		initializationTextField.addKeyListener(customKeyListener);

		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		add(initializationTextField);
	}

	public void update() {}

	public void setInput(InputEvent e) {
		rootComponent.initializeGame();
	}
}
