/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.Constants;
import java.awt.GridLayout;
import java.awt.event.InputEvent;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 *
 * @author enrico
 */
public class CardsPanel extends JPanel implements IGUIComponent {

	private ArrayList<IGUIComponent> components;
	private CardButton[] charactersCards;
	private CardButton[] weaponsCards;
	private CardButton[] roomsCards;

	public CardsPanel() {
		super();
		components = new ArrayList<IGUIComponent>();

		charactersCards = new CardButton[Constants.NUMBER_OF_CHARACTERS];
		roomsCards = new CardButton[Constants.NUMBER_OF_ROOMS];
		weaponsCards = new CardButton[Constants.NUMBER_OF_WEAOPONS];

		for (int i = Constants.CHARACTERS_OFFSET; i < Constants.CHARACTERS_LIMIT; i++) {
			charactersCards[i - Constants.CHARACTERS_OFFSET] = new CardButton(i);
		}

		for (int i = Constants.WEAPONS_OFFSET; i < Constants.WEAPONS_LIMIT; i++) {
			weaponsCards[i - Constants.WEAPONS_OFFSET] = new CardButton(i);
		}

		for (int i = Constants.ROOMS_OFFSET; i < Constants.ROOMS_LIMIT; i++) {
			roomsCards[i - Constants.ROOMS_OFFSET] = new CardButton(i);
		}
	}

	public void initComponent(IController rootComponent) {
		setLayout(new GridLayout(0, Constants.CARD_COLUMNS));

		for (int i = 0; i < charactersCards.length; i++) {
			charactersCards[i].initComponent(rootComponent);
			components.add(charactersCards[i]);
			add(charactersCards[i]);
		}
		for (int i = 0; i < weaponsCards.length; i++) {
			weaponsCards[i].initComponent(rootComponent);
			components.add(weaponsCards[i]);
			add(weaponsCards[i]);
		}
		for (int i = 0; i < roomsCards.length; i++) {
			roomsCards[i].initComponent(rootComponent);
			components.add(roomsCards[i]);
			add(roomsCards[i]);
		}

		update();
	}

	public void update() {
		for (IGUIComponent component : components) {
			component.update();
		}
	}

	public void setInput(InputEvent e) {
		throw new UnsupportedOperationException("Not supported yet.");
	}
}
