/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.gui;

import cluedo.common.Constants;
import java.awt.event.InputEvent;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 *
 * @author enrico
 */
public class BlockNotesPanel extends JPanel implements IGUIComponent {

	private JPanel charactersPanel;
	private JPanel weaponsPanel;
	private JPanel roomsPanel;

	public BlockNotesPanel() {
		charactersPanel = new JPanel();
		weaponsPanel = new JPanel();
		roomsPanel = new JPanel();
	}

	public void initComponent(IController rootComponent) {
		charactersPanel.setBorder(BorderFactory.createTitledBorder(Constants.BLOCKNOTES_CHARACTERS_LABEL));
		roomsPanel.setBorder(BorderFactory.createTitledBorder(Constants.BLOCKNOTES_ROOMS_LABEL));
		weaponsPanel.setBorder(BorderFactory.createTitledBorder(Constants.BLOCKNOTES_WEAPONS_LABEL));
	}

	public void update() {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	public void setInput(InputEvent e) {
		throw new UnsupportedOperationException("Not supported yet.");
	}
}
