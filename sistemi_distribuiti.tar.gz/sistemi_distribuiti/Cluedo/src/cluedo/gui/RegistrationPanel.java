/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.gui.listener.CustomKeyListener;
import cluedo.common.Constants;
import java.awt.event.InputEvent;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author enrico
 */
public class RegistrationPanel extends JPanel implements IGUIComponent {

	private IController rootComponent;
	private KeyListener customKeyListener;
	private String titleLable;
	private String playersLabel;
	private String finishLabel;
	private JTextField titleTextField;
	private JTextField playersTextField;
	private JTextField playersNumberTextField;
	private JTextField finishTextField;

	public RegistrationPanel() {
		super();

		customKeyListener = new CustomKeyListener(this);

		titleTextField = new JTextField();
		playersTextField = new JTextField();
		playersNumberTextField = new JTextField();
		finishTextField = new JTextField();
	}

	public void initComponent(IController rootComponent) {
		this.rootComponent = rootComponent;

		titleLable = Constants.REGISTRATION_TITLE_LABEL;
		playersLabel = Constants.REGISTRATION_LABEL;
		finishLabel = Constants.REGISTRATION_FINISH_LABEL;

		titleTextField.setEditable(false);
		playersTextField.setEditable(false);
		playersNumberTextField.setEditable(false);
		finishTextField.setEditable(false);

		titleTextField.setBackground(Constants.REGISTRATION_BACKGROUND_COLOR);
		titleTextField.setForeground(Constants.REGISTRATION_FOREGROUND_COLOR);
		titleTextField.setBorder(BorderFactory.createEmptyBorder());
		playersTextField.setBackground(Constants.REGISTRATION_BACKGROUND_COLOR);
		playersTextField.setForeground(Constants.REGISTRATION_FOREGROUND_COLOR);
		playersTextField.setBorder(BorderFactory.createEmptyBorder());
		playersNumberTextField.setBackground(Constants.REGISTRATION_BACKGROUND_COLOR);
		playersNumberTextField.setForeground(Constants.REGISTRATION_NUMBEROFPLAYERS_COLOR);
		playersNumberTextField.setBorder(BorderFactory.createEmptyBorder());
		finishTextField.setBackground(Constants.REGISTRATION_BACKGROUND_COLOR);
		finishTextField.setForeground(Constants.REGISTRATION_FOREGROUND_COLOR);
		finishTextField.setBorder(BorderFactory.createEmptyBorder());

		titleTextField.setFont(Constants.REGISTRATION_FONT_BIG);
		playersTextField.setFont(Constants.REGISTRATION_FONT_MEDIUM);
		playersNumberTextField.setFont(Constants.REGISTRATION_FONT_VERYBIG);
		finishTextField.setFont(Constants.REGISTRATION_FONT_SMALL);

		titleTextField.setText(titleLable);
		playersTextField.setText(playersLabel);
		playersNumberTextField.setText("");
		finishTextField.setText(finishLabel);

		titleTextField.setHorizontalAlignment(JTextField.CENTER);
		playersTextField.setHorizontalAlignment(JTextField.CENTER);
		playersNumberTextField.setHorizontalAlignment(JTextField.CENTER);
		finishTextField.setHorizontalAlignment(JTextField.CENTER);

		titleTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		playersTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		playersNumberTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		finishTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);

		titleTextField.addKeyListener(customKeyListener);
		playersTextField.addKeyListener(customKeyListener);
		playersNumberTextField.addKeyListener(customKeyListener);
		finishTextField.addKeyListener(customKeyListener);

		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		add(titleTextField);
		add(playersTextField);
		add(playersNumberTextField);
		add(finishTextField);
	}

	public void update() {
		if (isVisible()) {
			Integer numberOfPlayers = rootComponent.getNumberOfPlayers();

			if (numberOfPlayers != null) {
				playersNumberTextField.setText(Integer.toString(numberOfPlayers));
			}
		}
	}

	public void setInput(InputEvent e) {
		rootComponent.endRegistrationPhase();
	}
}
