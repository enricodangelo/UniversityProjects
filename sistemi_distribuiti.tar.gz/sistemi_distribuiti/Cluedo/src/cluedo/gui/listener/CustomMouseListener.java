/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui.listener;

import cluedo.gui.IGUIComponent;
import java.awt.event.MouseEvent;
import javax.swing.event.MouseInputAdapter;

/**
 *
 * @author enrico
 */
public class CustomMouseListener extends MouseInputAdapter {

	private IGUIComponent component;

	public CustomMouseListener(IGUIComponent component) {
		this.component = component;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		component.setInput(e);
	}
}
