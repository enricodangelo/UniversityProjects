/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui.listener;

import cluedo.gui.IGUIComponent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 *
 * @author enrico
 */
public class CustomKeyListener extends KeyAdapter {

	private IGUIComponent component;

	public CustomKeyListener(IGUIComponent component) {
		this.component = component;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			component.setInput(e);
		}
	}
}
