/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.Constants;
import cluedo.gui.listener.CustomKeyListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author enrico
 */
public class RestartPanel extends JPanel implements IGUIComponent {

	private IController rootComponent;
	private KeyListener customKeyListener;
	private JTextField winnerTextField;
	private JTextField messageTextField;
	private JTextField restartTextField;

	public RestartPanel() {
		super();

		customKeyListener = new CustomKeyListener(this);
		winnerTextField = new JTextField();
		messageTextField = new JTextField();
		restartTextField = new JTextField();
	}

	public void initComponent(IController rootComponent) {
		this.rootComponent = rootComponent;

		winnerTextField.setEditable(false);
		messageTextField.setEditable(false);
		restartTextField.setEditable(false);

		winnerTextField.setBackground(Constants.RESTART_BACKGROUND_COLOR);
		winnerTextField.setForeground(Constants.RESTART_WINNER_FOREGROUND_COLOR);
		winnerTextField.setBorder(BorderFactory.createEmptyBorder());
		winnerTextField.setFont(Constants.RESTART_FONT_VERYBIG);
		winnerTextField.setHorizontalAlignment(JTextField.CENTER);
		winnerTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		winnerTextField.addKeyListener(customKeyListener);

		messageTextField.setBackground(Constants.RESTART_BACKGROUND_COLOR);
		messageTextField.setForeground(Constants.RESTART_FOREGROUND_COLOR);
		messageTextField.setBorder(BorderFactory.createEmptyBorder());
		messageTextField.setFont(Constants.RESTART_FONT_BIG);
		messageTextField.setHorizontalAlignment(JTextField.CENTER);
		messageTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		messageTextField.addKeyListener(customKeyListener);

		restartTextField.setBackground(Constants.RESTART_BACKGROUND_COLOR);
		restartTextField.setForeground(Constants.RESTART_RESTART_FOREGROUND_COLOR);
		restartTextField.setBorder(BorderFactory.createEmptyBorder());
		restartTextField.setFont(Constants.RESTART_FONT_SMALL);
		restartTextField.setText(Constants.RESTART_RESTART_LABEL);
		restartTextField.setHorizontalAlignment(JTextField.CENTER);
		restartTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		restartTextField.addKeyListener(customKeyListener);

		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		add(winnerTextField);
		add(messageTextField);
		add(restartTextField);
	}

	public void update() {
		String winner;
		String message;

		if (isVisible()) {
			if (rootComponent.amITheWinner()) {
				winner = "";
				message = Constants.RESTART_WINNER_LABEL;
			} else {
				winner = rootComponent.getWinnerName();
				message = Constants.RESTART_NOT_WINNER_LABEL;
			}

			winnerTextField.setText(winner);
			messageTextField.setText(message);
		}
	}

	public void setInput(InputEvent e) {
		rootComponent.startNewMatch();
	}
}
