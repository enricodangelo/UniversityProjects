/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.Constants;
import cluedo.gui.listener.CustomMouseListener;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;

/**
 *
 * @author enrico
 */
public class ActionPanel extends JPanel implements IGUIComponent {

	private ArrayList<IGUIComponent> components;
	private IController rootComponent;
	private CustomMouseListener customMouseListener;
	private JPanel cardsPanel;
	private CardButton characterCard;
	private CardButton weaponCard;
	private CardButton roomCard;
	private JPanel buttonsPanel;
	private JButton diceButton;
	private JButton suspectButton;
	private JButton accuseButton;
	private JButton endTurnButton;

	public ActionPanel() {
		super();
		components = new ArrayList<IGUIComponent>();

		customMouseListener = new CustomMouseListener(this);

		cardsPanel = new JPanel();

		characterCard = new CardButton();
		weaponCard = new CardButton();
		roomCard = new CardButton();

		buttonsPanel = new JPanel();
		diceButton = new JButton(Constants.DICE_BUTTON_LABEL);
		suspectButton = new JButton(Constants.SUSPECT_BUTTON_LABEL);
		accuseButton = new JButton(Constants.ACCUSE_BUTTON_LABEL);
		endTurnButton = new JButton(Constants.ENDTURN_BUTTON_LABEL);
	}

	public void initComponent(IController rootComponent) {
		this.rootComponent = rootComponent;

		characterCard.initComponent(rootComponent);
		weaponCard.initComponent(rootComponent);
		roomCard.initComponent(rootComponent);
		characterCard.setInEnvelope(true);
		weaponCard.setInEnvelope(true);
		roomCard.setInEnvelope(true);

		cardsPanel.setLayout(new BoxLayout(cardsPanel, BoxLayout.X_AXIS));
		cardsPanel.add(characterCard);
		cardsPanel.add(weaponCard);
		cardsPanel.add(roomCard);

		diceButton.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		suspectButton.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		accuseButton.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		endTurnButton.setAlignmentX(JComponent.CENTER_ALIGNMENT);

		diceButton.addMouseListener(customMouseListener);
		suspectButton.addMouseListener(customMouseListener);
		accuseButton.addMouseListener(customMouseListener);
		endTurnButton.addMouseListener(customMouseListener);

		diceButton.setEnabled(false);
		suspectButton.setEnabled(false);
		accuseButton.setEnabled(false);
		endTurnButton.setEnabled(false);

		buttonsPanel.setLayout(new GridLayout(4, 1));

		buttonsPanel.add(diceButton);
		buttonsPanel.add(suspectButton);
		buttonsPanel.add(accuseButton);
		buttonsPanel.add(endTurnButton);

		components.add(characterCard);
		components.add(weaponCard);
		components.add(roomCard);

		setLayout(new BorderLayout());
		add(cardsPanel, BorderLayout.WEST);
		add(buttonsPanel, BorderLayout.EAST);
	}

	public void update() {
		ArrayList<Integer> envelope = rootComponent.getEnvelope();

		if (envelope != null) {
			for (Integer cardID : envelope) {
				if ((characterCard.getCardID() == null) &&
						(cardID.compareTo(Constants.CHARACTERS_OFFSET) >= 0) &&
						(cardID.compareTo(Constants.CHARACTERS_LIMIT) < 0)) {
					characterCard.setCardID(cardID);
				} else if ((roomCard.getCardID() == null) &&
						(cardID.compareTo(Constants.ROOMS_OFFSET) >= 0) &&
						(cardID.compareTo(Constants.ROOMS_LIMIT) < 0)) {
					roomCard.setCardID(cardID);
				} else if ((weaponCard.getCardID() == null) &&
						(cardID.compareTo(Constants.WEAPONS_OFFSET) >= 0) &&
						(cardID.compareTo(Constants.WEAPONS_LIMIT) < 0)) {
					weaponCard.setCardID(cardID);
				}
			}
		}

		if (rootComponent.isMyTurn()) {
			/* se sono in una stanza attivo il pulsante per lanciare il dado */
			if (rootComponent.canRollTheDice()) {
				diceButton.setEnabled(true);
			} else {
				diceButton.setEnabled(false);
			}

			/* se sono in una stanza attivo il pulsante per le accuse */
			if (rootComponent.canMakeASuggestion()) {
				suspectButton.setEnabled(true);
			} else {
				suspectButton.setEnabled(false);
			}

			if (rootComponent.canMakeAnAccusation()) {
				accuseButton.setEnabled(true);
			} else {
				accuseButton.setEnabled(false);
			}

			if (rootComponent.canEndTurn()) {
				endTurnButton.setEnabled(true);
			} else {
				endTurnButton.setEnabled(false);
			}
		} else {
			/* se non e' il mio turno disattivo tutti i pulsanti */
			diceButton.setEnabled(false);
			suspectButton.setEnabled(false);
			accuseButton.setEnabled(false);
			endTurnButton.setEnabled(false);
		}

		for (IGUIComponent component : components) {
			component.update();
		}
	}

	public void setInput(InputEvent e) {
		MouseEvent me = (MouseEvent) e;

		if (me.getComponent().equals(diceButton)) {
			if (diceButton.isEnabled()) {
				rootComponent.rollTheDice();
			}

		} else if (me.getComponent().equals(suspectButton)) {
			if (suspectButton.isEnabled()) {
				rootComponent.suggest();
			}

		} else if (me.getComponent().equals(accuseButton)) {
			if (accuseButton.isEnabled()) {
				rootComponent.accuse();
			}

		} else if (me.getComponent().equals(endTurnButton)) {
			if (endTurnButton.isEnabled()) {
				rootComponent.endTurn();
			}
		}
	}
}
