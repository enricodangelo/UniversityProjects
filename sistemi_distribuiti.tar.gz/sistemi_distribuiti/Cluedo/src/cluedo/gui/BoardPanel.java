/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.Constants;
import java.awt.BorderLayout;
import java.awt.event.InputEvent;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author enrico
 */
public class BoardPanel extends JPanel implements IGUIComponent {

	private ArrayList<IGUIComponent> components;
	private JTextField titleTextField;
	private CluedoBoard board;

	public BoardPanel() {
		super();

		components = new ArrayList<IGUIComponent>();

		titleTextField = new JTextField();
		board = new CluedoBoard();
	}

	public void initComponent(IController rootComponent) {
		board.initComponent(rootComponent);

		titleTextField.setEditable(false);

		titleTextField.setBackground(Constants.BOARD_BACKGROUND_COLOR);
		titleTextField.setForeground(Constants.BOARD_FOREGROUND_COLOR);
		titleTextField.setBorder(BorderFactory.createEmptyBorder());
		titleTextField.setFont(Constants.BOARD_FONT_BIG);
		titleTextField.setText(Constants.BOARD_LABEL);
		titleTextField.setHorizontalAlignment(JTextField.CENTER);
		titleTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);

		components.add(board);

		setLayout(new BorderLayout());

		add(titleTextField, BorderLayout.PAGE_START);
		add(board, BorderLayout.CENTER);
	}

	public void update() {
		if (isVisible()) {
			for (IGUIComponent guiComponent : components) {
				guiComponent.update();
			}
		}
	}

	public void setInput(InputEvent e) {
	}
}
