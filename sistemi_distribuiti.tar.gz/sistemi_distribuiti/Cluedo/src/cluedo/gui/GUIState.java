/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.gui;

/**
 *
 * @author enrico
 */
public enum GUIState {
	REGISTRATION,
	CHARACTER_SELECTION,
	PLAYING
}
