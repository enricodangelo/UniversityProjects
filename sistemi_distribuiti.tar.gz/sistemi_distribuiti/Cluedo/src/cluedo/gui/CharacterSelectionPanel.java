/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.Constants;
import cluedo.gui.listener.CustomMouseListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author enrico
 */
public class CharacterSelectionPanel extends JPanel implements IGUIComponent {

	private IController rootComponent;
	private String titleLabel;
	private JTextField titleTextField;
	private CustomMouseListener customMouseListener;
	private int[] leftMargin;
	private int[] rightMargin;
	private int[] upperMargin;
	private int[] lowerMargin;

	public CharacterSelectionPanel() {
		super();
		titleTextField = new JTextField();
		customMouseListener = new CustomMouseListener(this);
		/* questi array mantengono il valore in pizel gli estremi dei rettangoli che rappresentano i personaggi */
		leftMargin = new int[Constants.NUMBER_OF_CHARACTERS];
		rightMargin = new int[Constants.NUMBER_OF_CHARACTERS];
		upperMargin = new int[Constants.NUMBER_OF_CHARACTERS];
		lowerMargin = new int[Constants.NUMBER_OF_CHARACTERS];
	}

	public void initComponent(IController rootComponent) {
		this.rootComponent = rootComponent;

		titleLabel = Constants.CHARACTER_SELECTION_TITLE_LABEL;

		titleTextField.setEditable(false);
		titleTextField.setBackground(Constants.CHARACTER_SELECTION_BACKGROUND_COLOR);
		titleTextField.setForeground(Constants.CHARACTER_SELECTION_FOREGROUND_COLOR);
		titleTextField.setBorder(BorderFactory.createEmptyBorder());
		titleTextField.setFont(Constants.CHARACTER_SELECTION_FONT_BIG);
		titleTextField.setText(titleLabel);
		titleTextField.setHorizontalAlignment(JTextField.CENTER);
		titleTextField.setAlignmentX(JComponent.CENTER_ALIGNMENT);

		addMouseListener(customMouseListener);

		setLayout(new BorderLayout());

		add(titleTextField, BorderLayout.PAGE_START);
	}

	@Override
	public void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		FontMetrics fontMetrics = new FontMetrics(Constants.CHARACTER_SELECTION_FONT_SMALL) {
		};
		int rectWidth = (getSize().width - (Constants.CHARACTER_SELECTION_SPACE * 4)) / 3;
		int rectHeight = ((getSize().height - titleTextField.getSize().height) - (Constants.CHARACTER_SELECTION_SPACE * 3)) / 2;

		g2d.setFont(Constants.CHARACTER_SELECTION_FONT_SMALL);
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		g2d.setBackground(Constants.CHARACTER_SELECTION_BACKGROUND_COLOR);
		g2d.fillRect(0, 0, getSize().width, getSize().height);

		for (int i = 0; i < Constants.NUMBER_OF_CHARACTERS; i++) {
			int row = (int) (i / Constants.CHARACTER_SELECTION_COLUMNS) + 1;
			int column = (i % Constants.CHARACTER_SELECTION_COLUMNS) + 1;
			int rectX = column * Constants.CHARACTER_SELECTION_SPACE + ((column - 1) * rectWidth);
			int rectY = (row * Constants.CHARACTER_SELECTION_SPACE + ((row - 1) * rectHeight)) + titleTextField.getSize().height;

			leftMargin[i] = rectX;
			rightMargin[i] = rectX + rectWidth;
			upperMargin[i] = rectY;
			lowerMargin[i] = rectY + rectHeight;

			g2d.setColor(Constants.CHARACTER_COLORS[i]);

			if (rootComponent.isCharacterAvailable(i)) {
				g2d.fillRoundRect(
						rectX,
						rectY,
						rectWidth,
						rectHeight,
						Constants.CHARACTER_SELECTION_ARCWIDTH,
						Constants.CHARACTER_SELECTION_ARCHEIGHT);

				g2d.setColor(Color.BLACK);
				int stringX = (int) (rectX + (rectWidth / 2) - (fontMetrics.getStringBounds(Constants.CHARACTER_NAME[i], g2d).getWidth() / 2));
				int stringY = (int) (rectY + (rectHeight / 2) + (fontMetrics.getStringBounds(Constants.CHARACTER_NAME[i], g2d).getHeight() / 2));

				g2d.drawString(Constants.CHARACTER_NAME[i], stringX, stringY);
			}
		}
	}

	public void update() {
		if (isVisible()) {
			repaint();
		}
	}

	public void setInput(InputEvent e) {
		Point position = ((MouseEvent) e).getPoint();

		for (int i = 0; i < Constants.NUMBER_OF_CHARACTERS; i++) {
			if ((position.x > leftMargin[i]) && (position.x < rightMargin[i]) && (position.y > upperMargin[i]) && (position.y < lowerMargin[i])) {

				rootComponent.chooseCharacter(i);
			}
		}
	}
}
