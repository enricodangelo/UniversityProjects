/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.gui;

import cluedo.common.CardState;
import cluedo.gui.listener.CustomMouseListener;
import cluedo.common.Constants;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolTip;

/**
 *
 * @author enrico
 */
public class CardButton extends JButton implements IGUIComponent {

	private IController rootComponent;
	private CustomMouseListener customMouseListener;
	private String frontImageIconFilename;
	private String backImageIconFilename;
	private String selectedImageIconFilename;
	private String semiactiveImageIconFilename;
	private String name;
	private ImageIcon frontImageIcon;
	private ImageIcon backImageIcon;
	private ImageIcon selectedImageIcon;
	private ImageIcon semiactiveImageIcon;
	private CardState cardState;
	private Integer cardID;
	private boolean inEnvelope;

	public CardButton() {
		super();

		inEnvelope = false;
		customMouseListener = new CustomMouseListener(this);
		backImageIconFilename = Constants.RESOURCE_DIR + Constants.CARD_BACK_FILENAME;
		backImageIcon = new ImageIcon(
				new ImageIcon(getClass().getResource(backImageIconFilename)).getImage().getScaledInstance(
				Constants.CARD_WIDTH,
				Constants.CARD_HEIGHT,
				Image.SCALE_DEFAULT));
	}

	public CardButton(Integer cardID) {
		this();

		setCardID(cardID);
	}

	public void setCardID(Integer cardID) {
		this.cardID = cardID;

		if ((cardID.compareTo(Constants.CHARACTERS_OFFSET) >= 0)
				&& (cardID.compareTo(Constants.CHARACTERS_LIMIT) < 0)) {
			int index = cardID - Constants.CHARACTERS_OFFSET;
			name = Constants.CHARACTER_NAME[index];
			frontImageIconFilename = Constants.RESOURCE_DIR + Constants.CHARACTER_FILENAME[index];
			selectedImageIconFilename = Constants.RESOURCE_DIR + Constants.CHARACTER_SELECTED_FILENAME[index];
			semiactiveImageIconFilename = Constants.RESOURCE_DIR + Constants.CHARACTER_SEMIACTIVE_FILENAME[index];
		} else if ((cardID.compareTo(Constants.ROOMS_OFFSET) >= 0)
				&& (cardID.compareTo(Constants.ROOMS_LIMIT) < 0)) {
			int index = cardID - Constants.ROOMS_OFFSET;
			name = Constants.ROOM_NAME[index];
			frontImageIconFilename = Constants.RESOURCE_DIR + Constants.ROOM_FILENAME[index];
			selectedImageIconFilename = Constants.RESOURCE_DIR + Constants.ROOM_SELECTED_FILENAME[index];
			semiactiveImageIconFilename = Constants.RESOURCE_DIR + Constants.ROOM_SEMIACTIVE_FILENAME[index];
		} else if ((cardID.compareTo(Constants.WEAPONS_OFFSET) >= 0)
				&& (cardID.compareTo(Constants.WEAPONS_LIMIT) < 0)) {
			int index = cardID - Constants.WEAPONS_OFFSET;
			name = Constants.WEAPON_NAME[index];
			frontImageIconFilename = Constants.RESOURCE_DIR + Constants.WEAPON_FILENAME[index];
			selectedImageIconFilename = Constants.RESOURCE_DIR + Constants.WEAPON_SELECTED_FILENAME[index];
			semiactiveImageIconFilename = Constants.RESOURCE_DIR + Constants.WEAPON_SEMIACTIVE_FILENAME[index];
		}

		if (!inEnvelope) {
			setToolTipText(name);
		}

		frontImageIcon = new ImageIcon(
				new ImageIcon(getClass().getResource(
				frontImageIconFilename)).getImage().getScaledInstance(
				Constants.CARD_WIDTH,
				Constants.CARD_HEIGHT,
				Image.SCALE_DEFAULT));

		selectedImageIcon = new ImageIcon(
				new ImageIcon(getClass().getResource(
				selectedImageIconFilename)).getImage().getScaledInstance(
				Constants.CARD_WIDTH,
				Constants.CARD_HEIGHT,
				Image.SCALE_DEFAULT));

		semiactiveImageIcon = new ImageIcon(
				new ImageIcon(getClass().getResource(
				semiactiveImageIconFilename)).getImage().getScaledInstance(
				Constants.CARD_WIDTH,
				Constants.CARD_HEIGHT,
				Image.SCALE_DEFAULT));
	}

	public void setInEnvelope(boolean inEnvelope) {
		this.inEnvelope = inEnvelope;
	}

	public void setCardState(CardState cardState) {
		this.cardState = cardState;
	}

	public void initComponent(IController rootComponent) {
		this.rootComponent = rootComponent;

		setIcon(backImageIcon);

		setPreferredSize(new Dimension(Constants.CARD_WIDTH + 2, Constants.CARD_HEIGHT + 2));
		setMinimumSize(getPreferredSize());
		setMaximumSize(getPreferredSize());

		addMouseListener(customMouseListener);
	}

	/*
	 * Metodo chiamato da SWING per creare un tooltip
	 */
	@Override
	public JToolTip createToolTip() {
		JToolTip tooltip = super.createToolTip();

		/* setto il colore dello sfondo, il colore del testo, il bordo e il font del testo*/
		tooltip.setBackground(Constants.TOOLTIP_BACKGROUND_COLOR);
		tooltip.setBorder(BorderFactory.createEmptyBorder());
		tooltip.setForeground(Constants.TOOLTIP_FOREGROUND_COLOR);
		tooltip.setFont(Constants.TOOLTIP_FONT);

		return tooltip;
	}

	public void update() {
		if (inEnvelope) {
			setCardState(rootComponent.getEnvelopeState());
		} else {
			setCardState(rootComponent.getCardState(cardID));
		}

		switch (cardState) {
			case ACTIVE:
				setIcon(frontImageIcon);
				break;
			case INACTIVE:
				setIcon(backImageIcon);
				break;
			case SEMIACTIVE:
				setIcon(semiactiveImageIcon);
				break;
			case SELECTED:
				setIcon(selectedImageIcon);
				break;
		}

		repaint();
	}

	public void setInput(InputEvent e) {
		if (!inEnvelope) {
			if (rootComponent.canClick()) {
				rootComponent.clickCard(cardID);
				rootComponent.checkCardsClicked();
			}
		}
	}

	public Integer getCardID() {
		return cardID;
	}
}
