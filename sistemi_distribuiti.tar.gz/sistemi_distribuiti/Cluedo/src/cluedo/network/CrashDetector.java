/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.network;

import cluedo.common.Constants;
import cluedo.common.message.MessageFactory;
import cluedo.common.message.MessageType;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Questa classe si occupa di fare polling sui nodi attivi della rete per
 * controllare se sono ancora attivi o meno.
 * La classe viene eseguita in un thread che regolarmente manda un mesaggio
 * "are you alive" (messaggio di tipo POLL) ai nodi attivi, poi si mette in
 * await.
 * Per ogni nodo attivo mantiene il timestamp (in base all'oroligio locale di
 * sistema) dell'ultima comunicazione effettuata o ricevuta dal nodo.
 * Se per un dato nodo l'intervallo di tempo trascorso tra il timestamp
 * memorizzato e il momento in cui il thread si sveglia e' minore
 * dell'intervallo da attendere, allora non viene spedito il messaggio AYA
 * a tale nodo.
 *
 * questa classe serve per fondamentalmente per rilevare i crash dei nodi nei
 * momenti in cui non ci sono comunicazioni tra i nodi (le prime fasi di gioco,
 * e durante i turni), altrimenti ad ogni occasione di comunicazione tra i nodi
 * vengono rilevati eventuali crash.
 *
 * @author enrico
 */
public class CrashDetector {

	/* la rete di gioco */
	private CluedoNetwork cluedoNetwork;
	/* lo scheduler del thread */
	private Timer timer;
	/* mappa che memorizza per ogni nodo il timestamp dell'ultima comunicazione,
	serve anche per sapere quali sono i nodi da controllare */
	private Map<Integer, Long> lastMessageFromPlayerTime;
	/* intervallo tra i polling */
	private Integer checkingIntervalSeconds = Constants.POLLING_INTERVAL_SECONDS;
	/* lock per accesso in mutua esclusione alle variabili della classe */
	private Lock crashDetectorLock;

	public CrashDetector(CluedoNetwork cluedoNetwork) {
		this.cluedoNetwork = cluedoNetwork;
		timer = new Timer();
		lastMessageFromPlayerTime = new Hashtable<Integer, Long>();
		crashDetectorLock = new ReentrantLock();

		/* schedule del task ripetuto ad intervalli fissi,
		da adesso ogni checkingIntervalSeconds secondi */
		timer.scheduleAtFixedRate(
				new AreYouAlive(),
				Calendar.getInstance().getTime(),
				checkingIntervalSeconds * 1000);

		Logger.getLogger(getClass().getName()).logp(
				Level.INFO,
				getClass().getName(),
				"CrashDetector",
				"CrashDetector avviato.");
	}

	/*
	 * Aggiunge all'elenco dei nodi da controllare il nodo passato come parametro
	 */
	public void addPlayerToCheck(Integer playerGUID) {
		crashDetectorLock.lock();
		try {
			lastMessageFromPlayerTime.put(playerGUID, Long.MAX_VALUE);
		} finally {
			crashDetectorLock.unlock();
		}
	}

	/*
	 * Rimuove dall'elenco dei nodi da controllare il nodo passato come parametro
	 */
	public void removePlayerToCheck(Integer playerGUID) {
		crashDetectorLock.lock();
		try {
			lastMessageFromPlayerTime.remove(playerGUID);
		} finally {
			crashDetectorLock.unlock();
		}
	}

	/*
	 * Aggiorna il timestamp dell'ultima comunicazione con il nodo passato come
	 * parametro
	 */
	public void updateLastMessageElapsedTime(Integer playerGUID, Long localTimestamp) {
		crashDetectorLock.lock();
		try {
			if (lastMessageFromPlayerTime.containsKey(playerGUID)) {
				lastMessageFromPlayerTime.put(playerGUID, localTimestamp);
			}
		} finally {
			crashDetectorLock.unlock();
		}
	}

	/**
	 * Quasta classe e' il task che viene eseguito dallo scheduler, cioe'
	 * qui c'e' il polling vero e proprio
	 *
	 * @author enrico
	 */
	private class AreYouAlive extends TimerTask {

		public void run() {
			crashDetectorLock.lock();
			try {
				for (Integer playerGUID : lastMessageFromPlayerTime.keySet()) {
					/* questo perche' il giocatore potrebbe essere andato in crash
					mentre il detector era in sleep, evita elcune race conditions */
					if (!cluedoNetwork.isNodeCrashed(playerGUID)) {
						/* calcolo il tempo trascorso dall' ultima comunicazione
						 con il nodo in questione */
						Long lastMessageTime = lastMessageFromPlayerTime.get(playerGUID);
						Long currentTime = Calendar.getInstance().getTimeInMillis();
						Integer elapsedTimeSeconds = (int) ((currentTime - lastMessageTime) / 1000);

						/* fa polling solo se l'ultima comunicazione col nodo in
						 questione e' avvenuta da piu' tempo di quello indicato
						 dall'intervallo */
						if (elapsedTimeSeconds.compareTo(checkingIntervalSeconds) > 0) {
							cluedoNetwork.send(playerGUID, MessageFactory.createMessage(MessageType.POLL));
						}
					}
				}
			} finally {
				crashDetectorLock.unlock();
			}
		}
	}
}
