/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.network;

import cluedo.common.message.MessageType;
import cluedo.common.message.Message;
import cluedo.common.message.MessageFactory;
import cluedo.game.*;
import java.rmi.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.util.logging.*;

/**
 *
 * @author enrico
 */
public class CluedoNetwork implements ICluedoNetwork {

	/* struttura dati per la gestione dell'elenco dei nodi */
	private NodesList nodesList;
	/* stato della rete */
	private NetworkState networkState;
	/* lock per accesso in mutua esclusione alle variabili della classe */
	private Lock nodesListLock;
	/* condition per il CrashHandler */
	private Condition availableJustCrashedNodesCondition;
	/* thread che esegue il CrashHandler */
	private Executor crashHandlerThread;
	/* CrashDetector */
	private CrashDetector crashDetector;

	public CluedoNetwork() {
		/* istanzio la classe che mantiene l'elenco di nodi attivi e in crash nella rete */
		nodesList = new NodesList();
		nodesListLock = new ReentrantLock();
		availableJustCrashedNodesCondition = nodesListLock.newCondition();

		/* avvio il thread che si occupa della gestione dei nodi in crash */
		crashHandlerThread = new ThreadPoolExecutor(1, 1, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(1));
		crashHandlerThread.execute(new CrashHandler(this));

		/* avvio il thread che si occupa di rilevare i crash (in assenza di
		altre comunicazioni tra i nodi) */
		crashDetector = new CrashDetector(this);
	}

	/*
	 * Inserisce un nuovo giocatore nella rete. Il parametro "toPoll" indica se
	 * il giocatore debba essere controllato dal CrashDetector oppure no (solo
	 * il giocatore locale non deve essere controllato dal CrashDetector).
	 */
	public void insertNewNode(Integer newNodeGUID, IRemotePlayer newNodeRemoteInterface, boolean toPoll) {
		nodesListLock.lock();
		try {
			/* inserisco il nodo nella lista dei nodi attivi */
			nodesList.addActiveNode(newNodeGUID, newNodeRemoteInterface);
			/* se il CrashDetector deve controllare il nodo */
			if (toPoll) {
				/* inserisco il nodo nell'elenco dei nodi controllati dal CrashDetector */
				crashDetector.addPlayerToCheck(newNodeGUID);
			}
		} finally {
			nodesListLock.unlock();
		}
	}

	/*
	 * Restituisce la lista di GUID dei nodi in crash
	 */
	public ArrayList<Integer> getCrashedPlayersGUIDS() {
		ArrayList<Integer> result;

		nodesListLock.lock();
		try {
			result = nodesList.getCrashedNodesGUIDS();
		} finally {
			nodesListLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce la lista di GUID dei nodi attivi
	 */
	public ArrayList<Integer> getActivePlayersGUIDS() {
		ArrayList<Integer> result;

		nodesListLock.lock();
		try {
			result = nodesList.getActiveNodesGUIDS();
		} finally {
			nodesListLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce il numero di nodi attivi
	 */
	public int getNumberOfActivePlayers() {
		int result;

		nodesListLock.lock();
		try {
			result = nodesList.getNumberOfActiveNodes();
		} finally {
			nodesListLock.unlock();
		}
		return result;
	}

	/*
	 * Restituisce true se il nodo corrispondente al GUID passato come parametro
	 * e' stato rilevato in crash, anche se non e' ancora stato comunicato agli
	 * altri nodi, false altrimenti
	 */
	public boolean isNodeCrashed(Integer guid) {
		boolean result;

		nodesListLock.lock();
		try {
			if ((nodesList.getJustCrashedNodesGUIDS().contains(guid))
					|| (nodesList.getCrashedNodesGUIDS().contains(guid))) {
				result = true;
			} else {
				result = false;
			}
		} finally {
			nodesListLock.unlock();
		}
		return result;
	}

	/*
	 * Restituisce true se il guid passato appartiene ad un mittente valido,
	 * false altrimenti.
	 * Un mittente valido e' un mittente il cui GUID compare nell'elenco dei
	 * nodi attivi e non compare tra i nodi in crash o tra quelli appena
	 * rilevati in crash
	 */
	public boolean isAValidSender(Integer senderGUID) {
		boolean result = false;

		nodesListLock.lock();
		try {
			if ((nodesList.getActiveNodesGUIDS().contains(senderGUID))
					&& (!nodesList.getJustCrashedNodesGUIDS().contains(senderGUID))
					&& (!nodesList.getCrashedNodesGUIDS().contains(senderGUID))) {
				result = true;
			}
		} finally {
			nodesListLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce true se:
	 * - la rete e' aperta, cioe' se si e' nella fase di registrazione alla rete
	 * - la rete non ha ancora raggiunto il massimo della capienza
	 * - il nodo non e' gia' andato in crash
	 * - il GUID del nodo non e' gia' assegnato a nessun nodo
	 */
	public boolean canAddNode(Integer guid) {
		boolean result;

		nodesListLock.lock();
		try {
			result = ((networkState == NetworkState.OPEN)
					&& !nodesList.isFull()
					&& !nodesList.getCrashedNodesGUIDS().contains(guid)
					&& !nodesList.getActiveNodesGUIDS().contains(guid));
		} finally {
			nodesListLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce true se e' possibile chiudere la rete, cioe'
	 * se la rete non e' gia' chiusa e se ha raggiunto il numero minimo di nodi
	 */
	public boolean canCloseNetwork() {
		boolean result;

		nodesListLock.lock();
		try {
			result = nodesList.reachedMin() && (networkState != NetworkState.CLOSED);
		} finally {
			nodesListLock.unlock();
		}

		return result;
	}

	/*
	 * Chiude la rete
	 */
	public void closeNetwork() {
		nodesListLock.lock();
		try {
			networkState = NetworkState.CLOSED;
		} finally {
			nodesListLock.unlock();
		}
	}

	/*
	 * Apre la rete
	 */
	public void openNetwork() {
		nodesListLock.lock();
		try {
			networkState = NetworkState.OPEN;
		} finally {
			nodesListLock.unlock();
		}
	}

	/*
	 * Restituisce il primo elemento della coda dei GUID dei nodi appena
	 * rilevati in crash. Se la coda e' vuota il thread si sospende.
	 */
	public int getFirstJustCrashedNode() {
		int result;

		nodesListLock.lock();
		try {
			while (nodesList.getJustCrashedNodesGUIDS().isEmpty()) {
				try {
					availableJustCrashedNodesCondition.await();
				} catch (InterruptedException ex) {
				}
			}
			result = nodesList.getFirstJustCrashedNode();

		} finally {
			nodesListLock.unlock();
		}

		return result;
	}

	/*
	 * Inserisce il GUID passato come parametro nella coda dei nodi appena rilevati
	 * in crash. Questo ha l'effetto di svegliare il thread che gestisce i nodi in
	 * crash (CrashHandler) che spedisce a tutti i nodi un messaggio con il GUID appena
	 * inserito. Quando i nodi ricevono tale messaggio considerano il nodo in crash.
	 */
	public boolean setJustCrashedNodeGUIDS(Integer guid) {
		boolean result = false;

		nodesListLock.lock();
		try {
			if (nodesList.getActiveNodesGUIDS().contains(guid)) {
				nodesList.setJustCrashedNode(guid);
				result = true;

				Logger.getLogger(getClass().getName()).logp(
						Level.INFO,
						getClass().getName(),
						"setJustCrashedNodeGUIDS",
						"Rilevato crash del nodo " + guid);

				availableJustCrashedNodesCondition.signal();
			} else if (nodesList.getJustCrashedNodesGUIDS().contains(guid)) {
				result = true;
			}
		} finally {
			nodesListLock.unlock();
		}


		return result;
	}

	/*
	 * Setta il GUID passato come parametro in crash, cioe' lo rimuove dalla lista
	 * dei nodi attivi e lo inserisce in quella dei nodi in crash
	 */
	public boolean setCrashedPlayer(Integer crashedNodesGUID) {
		boolean result;

		nodesListLock.lock();
		try {
			result = nodesList.setCrashedNode(crashedNodesGUID);
			crashDetector.removePlayerToCheck(crashedNodesGUID);
		} finally {
			nodesListLock.unlock();
		}

		return result;
	}

	/*
	 * Aggiorna il timestamp dell'ultima comunicazione effettuata con il nodo
	 * corrispondente al GUID passato
	 */
	public void updateLastMessageElapsedTime(Integer guid) {
		crashDetector.updateLastMessageElapsedTime(guid, Calendar.getInstance().getTimeInMillis());
	}

	/*
	 * Ritorna true se il nodo corrispondente al GUID passato come parametro
	 * e' ancora attivo
	 */
	public boolean isNodeAlive(Integer guid) {
		boolean result = false;

		nodesListLock.lock();
		try {
			if (nodesList.getActiveNodesGUIDS().contains(guid)) {
				send(guid, MessageFactory.createMessage(MessageType.POLL));
				if ((!nodesList.getJustCrashedNodesGUIDS().contains(guid))
						&& (!nodesList.getCrashedNodesGUIDS().contains(guid))) {
					result = true;
				}
			}
		} finally {
			nodesListLock.unlock();
		}

		return result;
	}

	/*
	 * Spedisce un messaggio al nodo corrispondente al GUID passato come parametro
	 */
	public boolean send(Integer recipientGUID, Message msg) {
		boolean result = false;
		IRemotePlayer recipient;

		nodesListLock.lock();
		try {
			recipient = nodesList.getActiveNode(recipientGUID);
		} finally {
			nodesListLock.unlock();
		}

		try {
			recipient.receive(msg);
			crashDetector.updateLastMessageElapsedTime(recipientGUID, Calendar.getInstance().getTimeInMillis());
			result = true;
		} catch (RemoteException ex) {
			setJustCrashedNodeGUIDS(recipientGUID);
		}

		return result;
	}

	/*
	 * Multicast affidabile
	 */
	public void rMulticast(ArrayList<Integer> multicastGroup, Message msg) {
		Integer currentRecipient = 0;

		msg.setMulticastGroup(multicastGroup);

		for (Integer recipientGUID : multicastGroup) {
			currentRecipient = recipientGUID;
			IRemotePlayer currentRecipientNode = nodesList.getActiveNodesMap().get(currentRecipient);

			try {
				/* se currentRecipientNode e' null significa che il nodo corrispondente
				 al guid e' stato dichiarato in crash dopo che il suo guid e' stato
				 aggiunto alla lista di multicast */
				if (currentRecipientNode != null) {
					currentRecipientNode.receive(msg);
				}
				crashDetector.updateLastMessageElapsedTime(currentRecipient, Calendar.getInstance().getTimeInMillis());
			} catch (RemoteException ex) {
				setJustCrashedNodeGUIDS(currentRecipient);
			}
		}

	}

	public void printNodesList() {
		nodesListLock.lock();
		try {
			System.out.println(nodesList);
		} finally {
			nodesListLock.unlock();
		}
	}
}
