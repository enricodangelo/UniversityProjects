/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.network;

import cluedo.common.message.Message;
import cluedo.common.message.MessageFactory;
import cluedo.common.message.MessageType;
import cluedo.common.message.NotifyCrashBody;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Questa classe si prende cura di comunicare a tutti i nodi della rete i nodi
 * che il nodo remoto ha appena rilevato in crash
 *
 * Questa classe viene eseguita in un thread sempre attivo.
 * Quando non c'e' nessun nodo rilevato in crash il thread si mette in await,
 * non appena viene rilevato un nodo in crash il thread viene svegliato
 *
 * @author enrico
 */
public class CrashHandler implements Runnable {

	/* la rete di gioco */
	private final CluedoNetwork cluedoNetwork;

	public CrashHandler(CluedoNetwork overlayNetwork) {
		this.cluedoNetwork = overlayNetwork;
	}

	public void run() {
		int justCrashedGUID;

		Logger.getLogger(getClass().getName()).logp(Level.INFO, getClass().getName(), "run", "CrashHandler avviato.");

		while (true) {
			/* prendo il primo dei nodi appena rilevati in crash, se non ce ne sono
			 il thread si mette in await */
			justCrashedGUID = cluedoNetwork.getFirstJustCrashedNode();

			/* invio un messaggio a tutti i nodi per avvisarli del nodo andato
			 in crash*/
			notifyCrashedNode(justCrashedGUID);
		}
	}

	/*
	 * Spedisce a tutti i nodi presenti nella rete un messaggio in cui indica
	 * il GUID del nodo appena rilevato in crash
	 */
	private void notifyCrashedNode(Integer crashedNodeGUID) {
		ArrayList<Integer> multicastGroup;

		multicastGroup = cluedoNetwork.getActivePlayersGUIDS();

		Message msg = MessageFactory.createMessage(MessageType.NOTIFY_CRASH, new NotifyCrashBody(crashedNodeGUID));

		cluedoNetwork.rMulticast(multicastGroup, msg);
	}
}
