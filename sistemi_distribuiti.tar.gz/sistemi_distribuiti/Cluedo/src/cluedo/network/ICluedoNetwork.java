/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.network;

import cluedo.common.message.Message;
import cluedo.game.IRemotePlayer;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public interface ICluedoNetwork {

	public void insertNewNode(Integer newPlayerGUID, IRemotePlayer newPlayerRemoteInterface, boolean toPoll);
	public ArrayList<Integer> getActivePlayersGUIDS();
	public void openNetwork();
	public boolean isAValidSender(Integer senderGUID);
	public boolean canAddNode(Integer newPlayerGUID);
	public boolean isNodeCrashed(Integer playerGUID);
	public ArrayList<Integer> getCrashedPlayersGUIDS();
	public void rMulticast(ArrayList<Integer> multicastGroup, Message msg);
	public boolean setCrashedPlayer(Integer crashedNodesGUID);
	public void updateLastMessageElapsedTime(Integer playerGUID);
	public boolean canCloseNetwork();
	public boolean send(Integer recipientGUID, Message msg);
	public void closeNetwork();
	public boolean isNodeAlive(Integer playerGUID);
}
