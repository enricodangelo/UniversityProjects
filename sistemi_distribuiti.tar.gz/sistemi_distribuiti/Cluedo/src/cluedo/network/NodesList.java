/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.network;

import cluedo.game.IRemotePlayer;
import cluedo.common.Constants;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

/**
 * Questa classe mantiene la lista dei nodi attivi e di quelli andati in crash
 * Inoltre per ogni nodo attivo mantiene anche il suo riferimento remoto
 *
 * @author enrico
 */
public class NodesList {
	/* Mappa che associa ad ogni GUID di un nodo attivo il riferimento remoto
	 corrispondente */
	private Map<Integer, IRemotePlayer> activeNodes;
	/* lista dei GUID di tutti i nodi andati in crash */
	private ArrayList<Integer> crashedNodes;
	/* lista dei guid dei nodi che sono appena stati rilevati in crash */
	private Queue<Integer> justCrashedNodes;
	/* numero minimo di giocatore per iniziare */
	private final int min_size = Constants.MIN_NETWORK_SIZE;
	/* numero massimo di giocatori */
	private final int max_size = Constants.MAX_NETWORK_SIZE;

	public NodesList() {
		activeNodes = new Hashtable<Integer, IRemotePlayer>();
		crashedNodes = new ArrayList<Integer>();
		justCrashedNodes = new LinkedList<Integer>();
	}

	/*
	 * Restituisce il numero di nodi attivi presenti nella rete
	 */
	protected int getNumberOfActiveNodes() {
		int count;

		count = activeNodes.size();

		return count;
	}

	/*
	 * Restituisce true se nella rete sono presenti i giocatori necessari per
	 * giocare, false altrimenti
	 */
	protected boolean reachedMin() {
		boolean result;

		if (activeNodes.size() >= min_size) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	/*
	 * Restituisce true se la rete contiene il massimo dei nodi che puo'
	 * contenere, false altrimenti
	 */
	protected boolean isFull() {
		boolean result;

		if (activeNodes.size() == max_size) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	/*
	 * Restituisce la mappa che mantiene la corrispondenza tra i GUID dei nodi
	 * attivi e i loro riferimenti remoti
	 */
	protected Map<Integer, IRemotePlayer> getActiveNodesMap() {
		Map<Integer, IRemotePlayer> result = new HashMap<Integer, IRemotePlayer>();

		for (Integer guid : activeNodes.keySet()) {
			result.put(guid, activeNodes.get(guid));
		}

		return result;
	}

	/*
	 * Restituisce l'elenco dei GUID dei nodi andati in crash
	 */
	protected ArrayList<Integer> getCrashedNodesGUIDS() {
		ArrayList<Integer> result = new ArrayList<Integer>();

		for (Integer guid : crashedNodes) {
			result.add(new Integer(guid));
		}

		return result;
	}

	/*
	 * Restituisce l'elenco dei GUID dei nodi appena rilevati in crash
	 */
	protected ArrayList<Integer> getJustCrashedNodesGUIDS() {
		ArrayList<Integer> result = new ArrayList<Integer>();

		for (Integer guid : justCrashedNodes) {
			result.add(new Integer(guid));
		}

		return result;
	}

	/*
	 * Restituisce l'elenco dei GUID dei nodi attivi presenti nella rete
	 */
	protected ArrayList<Integer> getActiveNodesGUIDS() {
		ArrayList<Integer> result = new ArrayList<Integer>();

		for (Integer guid : activeNodes.keySet()) {
			result.add(new Integer(guid));
		}

		return result;
	}

	/*
	 * Inserisce un nuovo nodo nella lista dei nodi attivi
	 * Il nuovo nodo deve avere guid diverso da ogni altro nodo attivo o in crash
	 */
	protected boolean addActiveNode(Integer guid, IRemotePlayer overlayNode) {
		boolean result = false;

		if ((activeNodes.size() < max_size) &&
				(!activeNodes.containsKey(guid)) &&
				(!justCrashedNodes.contains(guid)) &&
				(!crashedNodes.contains(guid))) {
			activeNodes.put(guid, overlayNode);
			result = true;
		}

		return result;
	}

	/*
	 * Restituisce il riferimento remoto del nodo attivo con GUID passato come
	 * parametro
	 */
	protected IRemotePlayer getActiveNode(Integer guid) {
		IRemotePlayer result;

		result = activeNodes.get(guid);

		return result;
	}

	/*
	 * Setta il nodo passato come parametro come appena rileva in crash
	 */
	protected void setJustCrashedNode(Integer guid) {
		activeNodes.remove(guid);
		justCrashedNodes.add(guid);
	}

	/*
	 * Restituisce e rimuove il primo nodo della coda dei nodi appena rilevati
	 in crash
	 */
	protected Integer getFirstJustCrashedNode() {
		Integer result;

		result = justCrashedNodes.remove();

		return result;
	}

	/*
	 * Setta il nodo passato come parametro come in crash e lo
	 *
	 * Il nodo potrebbe gia' essere in crash.
	 */
	protected boolean setCrashedNode(Integer crashedNodeGUID) {
		boolean result = false;

		activeNodes.remove(crashedNodeGUID);

		if (!crashedNodes.contains(crashedNodeGUID)) {
			result = crashedNodes.add(crashedNodeGUID);
		}

		return result;
	}

	@Override
	public String toString() {
		String string = "";

		for (Integer key : activeNodes.keySet()) {
			string += key + ": " + "ALIVE" + "\n";
		}

		for (Integer key : crashedNodes) {
			string += key + ": " + "CRASHED" + "\n";
		}

		for (Integer key : justCrashedNodes) {
			string += key + ": " + "JUST_CRASHED" + "\n";
		}

		return string;
	}
}
