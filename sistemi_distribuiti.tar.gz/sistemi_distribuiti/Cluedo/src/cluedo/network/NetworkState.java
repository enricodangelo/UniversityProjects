/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.network;

/**
 * Questa enum rappresenta gli stati della rete
 *
 * @author enrico
 */
public enum NetworkState {
	/* la rete e' aperta ed e' possibile aggiungere nuovi nodi */
	OPEN,
	/* la rete e' chiusa, non e' possibile aggiungere nuovi nodi */
	CLOSED
}
