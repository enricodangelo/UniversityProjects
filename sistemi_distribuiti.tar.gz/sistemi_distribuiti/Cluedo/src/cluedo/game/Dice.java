/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.game;

import java.util.Calendar;
import java.util.Random;

/**
 * Classe che rappresenta il dado da lanciare per decidere la distanza
 * degli spostamenti
 *
 * @author enrico
 */
public class Dice {

	/*
	 * Restituisce un valore compreso tra 1 e 6 secondo una distribuzione uniforme
	 */
	public Integer roll() {
		Integer diceOutcome = null;

		Random generator = new Random(Calendar.getInstance().getTimeInMillis());

		diceOutcome = generator.nextInt(6);
		diceOutcome++;

		return diceOutcome;
	}
}
