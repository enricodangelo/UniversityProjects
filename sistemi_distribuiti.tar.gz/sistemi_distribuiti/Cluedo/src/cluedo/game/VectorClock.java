/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.game;

import cluedo.common.Constants;
import java.util.LinkedList;
import java.util.Queue;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Vector clock per catturare la relazione happen-before
 * Questa classe si occupa anche di assegnare gli indici ai diversi giocatori
 * nella maniera corretta
 *
 * @author enrico
 */
public class VectorClock {

	/* contiene l'insieme degli indici disponibili in ogni dato momento */
	private Queue<Integer> availableIndexes;
	/* dimensione dell'array del vector clock
	   Data le caratteristiche di Cluedo la dimensione e' limitata superiormente
	   de 6, cioe' il numero massimo di giocatori */
	private int size;
	/* ultimo timestamp usato */
	private Integer[] timestamp;
	/* indice assegnato al giocatore locale */
	private int index;

	public VectorClock() {
		/* inizializzo l'array che rappresenta il VectorClock */
		size = Constants.MAX_NETWORK_SIZE;
		timestamp = new Integer[size];
		for (int i = 0; i < size; i++) {
			timestamp[i] = 0;
		}

		/* inizializzo l'elenco di indici disponibili */
		availableIndexes = new LinkedList<Integer>();
		for (Integer i = 0; i < size; i++) {
			availableIndexes.add(i);
		}
	}

	public void setIndex(Integer index) {
		/* setto il mio indice */
		this.index = index;

		/* elimino il mio indice dalla lista degli indici disponibili */
		setIndexUnavailable(index);

		Logger.getLogger(getClass().getName()).logp(
				Level.INFO,
				getClass().getName(),
				"VectorClock",
				"VectorClock inizializzato, indice: " + index);
	}

	public Integer getIndex() {
		return index;
	}

	/*
	 * Restituisce il valore del primo indice disponibile non utilizzato dagli
	 * altri giocatori
	 */
	public Integer getFirstAvailableIndex() {
		Integer firstAvailableIndex = availableIndexes.peek();
		return firstAvailableIndex;
	}

	/*
	 * Setta l'indice passato come parametro come non piu' disponibile
	 */
	public void setIndexUnavailable(Integer vectorClockIndex) {
		availableIndexes.remove(vectorClockIndex);
	}

	/*
	 * Setta l'indice passato come parametro come disponibile
	 */
	public void setIndexAvailable(Integer vectorClockIndex) {
		availableIndexes.add(vectorClockIndex);
	}

	/*
	 * Merge tra il time stamp corrente e quello passato come parametro
	 */
	public boolean merge(Integer[] otheTimeStamp) {
		boolean result = true;

		if (size != otheTimeStamp.length) {
			result = false;
		} else {
			for (int i = 0; i < size; i++) {
				if (otheTimeStamp[i] > this.timestamp[i]) {
					this.timestamp[i] = otheTimeStamp[i];
				}
			}
		}

		return result;
	}

	/*
	 * Restiruisce un nuovo timestamp (incrementa il valore dell'orologio
	 * indicato dall'indice associato al giocatore locale)
	 */
	public Integer[] getNewTimeStamp() {
		timestamp[index]++;

		return timestamp.clone();
	}

	/*
	 * Restituisce true se l'evento marcato da firstTimestamp e' avvenuto prima
	 * dell'evento marcato da secondTimestamp, false altrimenti.
	 * Dato che l'ordinamento e' parziale, false non implica che il secondo evento
	 * sia avvenuto prima del primo.
	 */
	public static boolean happenedBefore(Integer[] firstTimestamp, Integer[] secondTimestamp) {
		if (firstTimestamp == null) {
			return false;
		}

		if (firstTimestamp.length != secondTimestamp.length) {
			Logger.getLogger(VectorClock.class.getName()).logp(Level.INFO, VectorClock.class.getName(), "isLessThan", "La dimensione dei due timestamps confrontati non e' la stessa");
			System.exit(-1);
		}

		boolean isLessereOrEqual = true;
		boolean isLesser = false;

		/* tutti gli elementi del primo timestamp sono minori o uguali agli
		   elementi del secondo timestamp */
		for (int i = 0; i < firstTimestamp.length; i++) {
			if (firstTimestamp[i].compareTo(secondTimestamp[i]) <= 0) {
				isLessereOrEqual = isLessereOrEqual && true;
			} else {
				isLessereOrEqual = false;
				break;
			}
		}
		
		/* esiste almeno un elemento nel primo timestamp che sia strettamente
		   minore del corrispondente elemento nel secondo timestamp */
		if (isLessereOrEqual) {
			for (int i = 0; i < firstTimestamp.length; i++) {
				if (firstTimestamp[i].compareTo(secondTimestamp[i]) < 0) {
					isLesser = true;
				}
			}
		}

		return isLesser;
	}
}
