/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.game;

import cluedo.common.Constants;
import java.util.ArrayList;
import java.util.Random;

/**
 * Classe che rappresenta il mazzo di carte
 *
 * @author enrico
 */
public class Deck {
	/* elenco di tutte le carte scelte da tutti i giocatori */

	private ArrayList<Integer> alreadySelectedCards;

	public Deck() {
		alreadySelectedCards = new ArrayList<Integer>();
	}

	/*
	 * Sceglie una carta di ogni tipo (personaggio, arma, stanza) per far parte
	 * della soluzione del gioco.
	 * Ogni carta viene scelta in maniera casuale con probabilita' omogenea
	 * rispetto alle altre carte dello stesso tipo
	 */
	public ArrayList<Integer> pickCardsForEnvelope() {
		ArrayList<Integer> cards = new ArrayList<Integer>();
		Integer cardIndex;
		Random characterGenerator = new Random();
		Random roomGenerator = new Random();
		Random weaponGenerator = new Random();

		do {
			cardIndex = Constants.CHARACTERS_OFFSET + characterGenerator.nextInt(Constants.NUMBER_OF_CHARACTERS);
		} while (alreadySelectedCards.contains(cardIndex + Constants.CHARACTERS_OFFSET));
		cards.add(cardIndex);
		do {
			cardIndex = Constants.ROOMS_OFFSET + roomGenerator.nextInt(Constants.NUMBER_OF_ROOMS);
		} while (alreadySelectedCards.contains(cardIndex + Constants.ROOMS_OFFSET));
		cards.add(cardIndex);
		do {
			cardIndex = Constants.WEAPONS_OFFSET + weaponGenerator.nextInt(Constants.NUMBER_OF_WEAOPONS);
		} while (alreadySelectedCards.contains(cardIndex + Constants.WEAPONS_OFFSET));
		cards.add(cardIndex);

		return cards;
	}

	/*
	 * Sceglie le carte per un giocatore.
	 * Tutte le carte hanno la stessa probabilita' di essere scelte,
	 * indipendentemente dal loro tipo
	 */
	public ArrayList<Integer> pickCardsForPlayer(Integer cardsToPick) {
		ArrayList<Integer> cards = new ArrayList<Integer>();
		Integer cardIndex;
		ArrayList<Integer> currentAlreadySelectedCards = new ArrayList<Integer>();
		Random cardsGenerator = new Random();

		while (cardsToPick > 0) {
			do {
				cardIndex = cardsGenerator.nextInt(Constants.TOTAL_NUMBER_OF_CARDS);
			} while ((alreadySelectedCards.contains(cardIndex))
					|| (currentAlreadySelectedCards.contains(cardIndex)));
			currentAlreadySelectedCards.add(cardIndex);
			cards.add(cardIndex);
			cardsToPick--;
		}

		return cards;
	}

	/*
	 * Rende non disponibili le carte passate come parametro
	 */
	public void setUnavailableCards(ArrayList<Integer> cards) {
		for (Integer cardID : cards) {
			alreadySelectedCards.add(cardID);
		}
	}

	/*
	 * Rende disponibili le carte passate come parametro
	 */
	public void setAvailableCards(ArrayList<Integer> cards) {
		if (cards != null) {
			for (Integer cardID : cards) {
				alreadySelectedCards.remove(cardID);
			}
		}
	}
}
