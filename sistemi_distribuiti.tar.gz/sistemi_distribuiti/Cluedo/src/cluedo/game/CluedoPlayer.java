/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.game;

import cluedo.common.message.CharacterSelectionBody;
import cluedo.common.*;
import cluedo.common.message.CardsBody;
import cluedo.common.message.CharacterAvailabilityBody;
import cluedo.common.message.DiceOutcomeBody;
import cluedo.common.message.EnvelopeBody;
import cluedo.common.message.InactiveCardBody;
import cluedo.common.message.Message;
import cluedo.common.message.NewNodeBody;
import cluedo.common.message.NotifyCrashBody;
import cluedo.common.message.OutOfGameBody;
import cluedo.common.message.PlayTurnBody;
import cluedo.common.message.PositionBody;
import cluedo.common.message.SemiactiveCardsBody;
import cluedo.common.message.SuggestionBody;
import cluedo.common.message.WinnerBody;
import java.rmi.AccessException;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.util.logging.*;

/**
 * Questa classe implementa l'interfaccia remota RMI
 *
 * @author enrico
 */
public class CluedoPlayer implements IRemotePlayer {

	private final Queue<String> processedMessageQueue;
	private final GameEngine gameEngine;

	public CluedoPlayer(String playerName, int rmiListeningPort, GameEngine gameEngine) {
		this.gameEngine = gameEngine;
		processedMessageQueue = new LinkedList<String>();

		if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }

		Registry rmiRegistry;
		IRemotePlayer remotePlayerStub;

		/* inizializzo JavaRMI */
		try {
			remotePlayerStub = (IRemotePlayer) UnicastRemoteObject.exportObject(this, 0);
			//remotePlayerStub = (IRemotePlayer) UnicastRemoteObject.exportObject(this, rmiListeningPort);
			rmiRegistry = LocateRegistry.createRegistry(rmiListeningPort);
			rmiRegistry.bind(Constants.REMOTEPLAYER_BINDING_NAME, remotePlayerStub);
		} catch (AlreadyBoundException ex) {
			Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
			System.exit(-1);
		} catch (AccessException ex) {
			Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
			System.exit(-1);
		} catch (RemoteException ex) {
			Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
			System.exit(-1);
		}
	}

	/*
	 * Questa funzione permette, se possibile, al giocatore remota che la invoca
	 * di unirsi alla rete del giocatore locale. Il metodo restituisce i dati
	 * necessari al giocatore remoto per fa parte della rete (elenco completo
	 * dei giocatori, giocatori in crash, indice di vectorclock da utilizzare)
	 */
	public synchronized InitializationData joinGameNetwork(
			String newPlayerName,
			Integer newPlayerGUID,
			IRemotePlayer newPlayer) {

		InitializationData initializationData = gameEngine.joinGameNetwork(
				newPlayerName,
				newPlayerGUID,
				newPlayer);

		if (initializationData != null) {
			Logger.getLogger(getClass().getName()).logp(
					Level.INFO, getClass().getName(),
					"joinNetwork",
					"Richiesta di join alla rete accettata.");
		} else {
			Logger.getLogger(getClass().getName()).logp(
					Level.INFO, getClass().getName(),
					"joinNetwork",
					"Richiesta di join alla rete rifiutata.");
		}

		return initializationData;
	}

	/*
	 * Metodo centralizzato per la ricezione dei messaggi inviati dai giocatori
	 * remoti. Mima un sistema di message-passing.
	 *
	 * Questo metodo insieme a rDeliver e CluedoNetwork.rMulticast implementano
	 * la comunicazione multicast affidabile
	 */
	public void receive(Message msg) throws RemoteException {
		/* se il mittente del messaggio e' mai andato in crash,
		allora ignoro i suoi messaggi */
		if (gameEngine.isAValidSender(msg.getSenderGUID())) {

			/* aggiorno il timestamp (orologio reale locale) dell'ultima
			comunicazione avuta con il mittente del messaggio*/
			gameEngine.updateLastMessageElapsedTime(msg.getSenderGUID());

			/* se non ho ancora ricevuto un messaggio con questo ID lo processo */
			if (!processedMessageQueue.contains(msg.getMessageID())) {
				processedMessageQueue.add(msg.getMessageID());

				/* se sono il mittente originario non rispedisco il messaggio */
				if (!gameEngine.amITheSender(msg.getOriginalSender())) {
					if ((msg.getMulticastGroup() != null) && (msg.getMulticastGroup().length != 1)) {
						gameEngine.resend(msg);
					}
				}

				/* il messaggio viene finalmente ricevuto per essere alaborato */
				rDeliver(msg);
			}
		}
	}

	/*
	 * Ricezione a livello "applicazione" del messaggio
	 * Questo metodo viene invocato una sola volta per ogni messaggio differente
	 * ricevuto, mentre receive viene invocato piu' volte.
	 */
	protected void rDeliver(Message msg) {

		Logger.getLogger(getClass().getName()).logp(
					Level.INFO, getClass().getName(),
					"rDeliver",
					"Deliver del messaggio " + msg.getMessageID() + ".");

		/* faccio il merge del mio vector clock con il timestamp del messaggio*/
		gameEngine.mergeVectorClock(msg.getTimestamp());

		/* marco la ricezione del messaggio */
		gameEngine.markEvent();

		/* eseguo l'azione giusta per il tipo di messaggio */
		switch (msg.getType()) {
			case TEST:
				System.out.println(msg);
				break;
			case POLL:
				break;
			case NEW_NODE:
				NewNodeBody newNodeBody = (NewNodeBody) msg.getBody();
				gameEngine.insertNewPlayer(
						newNodeBody.getNewNodeName(),
						newNodeBody.getNewNodeGUID(),
						newNodeBody.getVectorClockIndex(),
						newNodeBody.getNewNode());
				break;
			case NOTIFY_CRASH:
				NotifyCrashBody NotifyCrashBody = (NotifyCrashBody) msg.getBody();
				gameEngine.setCrashedPlayer(NotifyCrashBody.getCrashedNodeGUID());
				break;
			case CRITICAL_SECTION_REQUEST:
				gameEngine.requestCriticalSection(msg.getOriginalSender(), msg.getTimestamp());
				break;
			case CLOSE_NETWORK:
				gameEngine.startCharacterSelectionPhase();
				break;
			case START_NEW_MATCH:
				gameEngine.startRegistrationPhase();
				break;
			case IS_CHARACTER_AVAILABLE:
				CharacterSelectionBody characterSelectionRequestBody = (CharacterSelectionBody) msg.getBody();
				gameEngine.isCharacterAvailable(characterSelectionRequestBody.getPlayerGUID(), characterSelectionRequestBody.getCharacter());
				break;
			case CHARACTER_AVAILABILITY:
				CharacterAvailabilityBody characterAvailabilityBody = (CharacterAvailabilityBody) msg.getBody();
				gameEngine.setCharacterAvailability(characterAvailabilityBody.getAvailability());
				break;
			case SELECTED_CHARACTER:
				CharacterSelectionBody characterSelectionUpdateBody = (CharacterSelectionBody) msg.getBody();
				gameEngine.assignCharacter(characterSelectionUpdateBody.getPlayerGUID(), characterSelectionUpdateBody.getCharacter());
				break;
			case ENVELOPE:
				EnvelopeBody envelopeBody = (EnvelopeBody) msg.getBody();
				Integer[] envelopeArray = envelopeBody.getEnvelope();
				ArrayList<Integer> envelope = new ArrayList<Integer>();
				for (Integer cardID : envelopeArray) {
					envelope.add(cardID);
				}
				gameEngine.setEnvelope(envelope);
				break;
			case PLAYTURN:
				PlayTurnBody playTurnBody = (PlayTurnBody) msg.getBody();
				gameEngine.setPlayerPlayturn(playTurnBody.getPlayerGUID(), playTurnBody.getPlayTurn());
				break;
			case CARDS:
				CardsBody cardsBody = (CardsBody) msg.getBody();
				Integer[] playerCardsArray = cardsBody.getCards();
				ArrayList<Integer> playerCards = new ArrayList<Integer>();
				for (Integer cardID : playerCardsArray) {
					playerCards.add(cardID);
				}
				gameEngine.setPlayerCards(cardsBody.getPlayerGUID(), playerCards);
				gameEngine.checkInitializationState();
				break;
			case POSITION:
				PositionBody positionBody = (PositionBody) msg.getBody();
				gameEngine.setPlayerPosition(positionBody.getPlayerGUID(), positionBody.getPosition());
				break;
			case DICE_OUTCOME:
				DiceOutcomeBody diceOutcomeBody = (DiceOutcomeBody) msg.getBody();
				gameEngine.setMoves(diceOutcomeBody.getDiceOutcome());
				break;
			case END_TURN:
				gameEngine.endTurn();
				break;
			case SUGGESTION:
				SuggestionBody suggestionBody = (SuggestionBody) msg.getBody();
				gameEngine.checkSuggestion(suggestionBody.getAccuserPlayerGUID(), suggestionBody.getSuggestion());
				break;
			case INACTIVE_CARD:
				InactiveCardBody inactiveCardBosy = (InactiveCardBody) msg.getBody();
				gameEngine.setCardNotInTheSolution(inactiveCardBosy.getInactiveCard());
				break;
			case SEMIACTIVE_CARDS:
				SemiactiveCardsBody semiactiveCardsBody = (SemiactiveCardsBody) msg.getBody();
				Integer[] semiactiveCardsArray = semiactiveCardsBody.getSemiActiveCards();
				ArrayList<Integer> semiactiveCards = new ArrayList<Integer>();
				for (Integer cardID : semiactiveCardsArray) {
					semiactiveCards.add(cardID);
				}
				gameEngine.setCardsProbablyNotInTheSolution(semiactiveCards);
				break;
			case WINNER:
				WinnerBody winnerBody = (WinnerBody) msg.getBody();
				gameEngine.endTheMatch(winnerBody.getWinnerPlayerGUID());
				break;
			case OUT_OF_GAME:
				OutOfGameBody outOfGameBody = (OutOfGameBody) msg.getBody();
				gameEngine.setPlayerOutOfGame(outOfGameBody.getOutOfGamePlayerGUID());
				break;
			default:
				System.err.println("CluedoPlayer.rDeliver(): tipo di messaggio sconosciuto");
		}

		/* fa si che l'interfaccia venga notificata e si aggiorni */
		gameEngine.triggerUpdate();
	}
}
