/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.game.criticalsection;

/**
 * Questa enum rappresenta gli stati della sezione critica distribuita, rispetto
 * al giocatore locale
 *
 * @author enrico
 */
public enum CriticalSectionState {

	/* non detengo la sezione critica */
	RELEASED,
	/* in attesa di entrare nella sezione critica */
	WANTED,
	/* detengo la sezione critica */
	HELD
}
