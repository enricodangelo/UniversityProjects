/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.game.criticalsection;

/**
 *
 * @author enrico
 */
public interface ICriticalSection {

	public void enter();

	public void exit();

	public void requestCriticalSection(Integer senderGUID, Integer[] requestTimeStamp);
}
