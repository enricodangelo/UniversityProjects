/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.game.criticalsection;

import cluedo.game.VectorClock;
import cluedo.common.message.Message;
import cluedo.common.message.MessageFactory;
import cluedo.common.message.MessageType;
import cluedo.network.ICluedoNetwork;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author enrico
 */
public class CriticalSection implements ICriticalSection {

	/* stato della sezione critica */
	private CriticalSectionState criticalSectionState;
	/* lock per accesso esclusivo locale */
	private Lock criticalSectionLocalLock = new ReentrantLock();
	private Condition criticalSectionCondition = criticalSectionLocalLock.newCondition();
	/*  */
	private Queue<Integer[]> csRequestTimestampQueue;
	private ICluedoNetwork cluedoNetwork;
	private Integer localPlayerGUID;

	public CriticalSection(ICluedoNetwork cluedoNetwork, Integer localPlayerGUID) {
		this.cluedoNetwork = cluedoNetwork;
		this.localPlayerGUID = localPlayerGUID;

		/* inizializzo lo stato della sezione critica distribuita */
		criticalSectionState = CriticalSectionState.RELEASED;
		csRequestTimestampQueue = new LinkedList<Integer[]>();
	}

	public void enter() {

		criticalSectionLocalLock.lock();
		try {
			while (criticalSectionState != CriticalSectionState.RELEASED) {
				try {
					criticalSectionCondition.await();
				} catch (InterruptedException ex) {}
			}

			criticalSectionState = CriticalSectionState.WANTED;
		} finally {
			criticalSectionLocalLock.unlock();
		}

		Message msg = MessageFactory.createMessage(MessageType.CRITICAL_SECTION_REQUEST);

		/* memorizzare il timestamp della richiesta */
		csRequestTimestampQueue.add(msg.getTimestamp());

		ArrayList<Integer> multicastGroup = cluedoNetwork.getActivePlayersGUIDS();

		/* spedisco a tutti i nodi la mia richiesta di entrare nella sezione critica */
		cluedoNetwork.rMulticast(multicastGroup, msg);

		/* qua tutti mi hanno "risposto", sono nella sezione critica */
		criticalSectionLocalLock.lock();
		try {
			criticalSectionState = CriticalSectionState.HELD;
		} finally {
			criticalSectionLocalLock.unlock();
		}
	}

	public void exit() {
		criticalSectionLocalLock.lock();
		try {
			criticalSectionState = CriticalSectionState.RELEASED;
			csRequestTimestampQueue.remove();
			criticalSectionCondition.signalAll();
		} finally {
			criticalSectionLocalLock.unlock();
		}
	}

	public void requestCriticalSection(Integer senderGUID, Integer[] requestTimeStamp) {
		criticalSectionLocalLock.lock();
		try {
			boolean sameTimestamp = true;
			Integer[] currentCSRequestTimestamp = csRequestTimestampQueue.peek();

			/* se il mittente sono io e se il timestamp della richiesta ricevuta e'
			uguale a quello della sezione critica, allora posso rispondermi subito */
			if (senderGUID.equals(localPlayerGUID)) {
				if (currentCSRequestTimestamp != null) {
					for (int i = 0; i < currentCSRequestTimestamp.length; i++) {
						if (!currentCSRequestTimestamp[i].equals(requestTimeStamp[i])) {
							sameTimestamp = false;
							break;
						}
					}
				} else {
					sameTimestamp = false;
				}
			}

			/* se la richiesta non e' mia, o e' mia ma con un timestamp diverso
			 allora la processo, altrimenti*/
			if (!((senderGUID.equals(localPlayerGUID)) && (sameTimestamp))) {
				while ((criticalSectionState == CriticalSectionState.HELD)
						|| ((criticalSectionState == CriticalSectionState.WANTED)
						&& (((VectorClock.happenedBefore(currentCSRequestTimestamp, requestTimeStamp))
						|| (localPlayerGUID.compareTo(senderGUID) < 0))))) {
					try {
						/* il thread verra' svegliato quando il giocatore locale
						sara' uscito dalla sezione critica */
						criticalSectionCondition.await();

						currentCSRequestTimestamp = csRequestTimestampQueue.peek();
					} catch (InterruptedException ex) {}
				}
			}
		} finally {
			criticalSectionLocalLock.unlock();
		}
	}
}
