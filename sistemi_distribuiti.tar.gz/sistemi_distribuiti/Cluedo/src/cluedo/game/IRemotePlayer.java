/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.game;

import cluedo.common.InitializationData;
import cluedo.common.message.Message;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Interfaccia remota RMI per la comunicazione tra  i giocatori
 *
 * @author enrico
 */
public interface IRemotePlayer extends Remote {

	public InitializationData joinGameNetwork(String newNodeName, Integer newNodeGUID, IRemotePlayer newNode) throws RemoteException;

	public void receive(Message msg) throws RemoteException;
}
