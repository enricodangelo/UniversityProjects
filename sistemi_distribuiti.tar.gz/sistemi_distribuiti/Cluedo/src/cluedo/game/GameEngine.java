/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.game;

import cluedo.common.CardState;
import cluedo.common.PlayerData;
import cluedo.common.GameState;
import cluedo.common.Constants;
import cluedo.common.GamePhase;
import cluedo.common.InitializationData;
import cluedo.common.ManhattanDistance;
import cluedo.game.criticalsection.CriticalSection;
import cluedo.gui.IView;
import cluedo.network.CluedoNetwork;
import cluedo.common.message.*;
import cluedo.game.criticalsection.ICriticalSection;
import cluedo.network.ICluedoNetwork;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Questa classe contiene la logica del gioco.
 * Tutte le chiamate provenienti dalla GUI e dai giocatori remoti vengono
 * inviate qui.
 *
 * @author enrico
 */
public class GameEngine implements IModel, IGameEngine {

	private ICluedoNetwork cluedoNetwork;
	private TurnAssigner turnAssigner;
	private Dice dice;
	private Deck deck;
	private PlayerData localPlayerData;
	private GameState gameState;
	private ArrayList<IView> subscribers;
	private Lock statusChangedLock;
	private ICriticalSection distributedCriticalSection;
	private VectorClock vectorClock;
	/* variabile utilizzata nella fase di selezione del personaggio */
	private Boolean isChoosenCharacterAvailable;

	public GameEngine(String localPlayerName, int rmiListeningPort) {
		turnAssigner = new TurnAssigner();
		dice = new Dice();
		vectorClock = new VectorClock();
		subscribers = new ArrayList<IView>();
		statusChangedLock = new ReentrantLock();

		Integer localPlayerGUID = localPlayerName.hashCode();
		IRemotePlayer localPlayerRemoteInterface = new CluedoPlayer(localPlayerName, rmiListeningPort, this);

		/* inizializzazione (in parte) di MessageFactory */
		MessageFactory.setIDSeed(localPlayerGUID);
		MessageFactory.setSenderGUID(localPlayerGUID);

		cluedoNetwork = new CluedoNetwork();

		distributedCriticalSection = new CriticalSection(cluedoNetwork, localPlayerGUID);

		localPlayerData = new PlayerData(localPlayerName, localPlayerGUID, localPlayerRemoteInterface);

		gameState = new GameState(localPlayerGUID);
		gameState.initialize(new ArrayList<Integer>());

		cluedoNetwork.insertNewNode(localPlayerData.getGUID(), localPlayerData.getRemoteInterface(), false);
		gameState.insertNewPlayer(localPlayerData.getGUID(), localPlayerData);

		startRegistrationPhase();

		Logger.getLogger(getClass().getName()).logp(
				Level.INFO,
				getClass().getName(),
				"GameEngine",
				"GUID: " + localPlayerGUID);
	}

	/*
	 * Iscrive un componente di tipi IView per osservare cambiamenti di stato
	 */
	public void subscribe(IView subscriber) {
		statusChangedLock.lock();
		try {
			subscribers.add(subscriber);
		} finally {
			statusChangedLock.unlock();
		}

		/* aggiorno subito il nuovo iscritto */
		subscriber.setData(gameState);
		subscriber.init();
	}

	/*
	 * Metodo da chiamare ogni volta che e' cambiato qualcosa nello stato del gioco.
	 * A sua volta questo metodo fa aggiornare tutti i componenti iscritti.
	 */
	public void triggerUpdate() {
		statusChangedLock.lock();
		try {
			Logger.getLogger(getClass().getName()).logp(
					Level.FINE,
					getClass().getName(),
					"setStatusChanged",
					"Status cambiato.");

			for (IView subscriber : subscribers) {
				subscriber.update();
			}

		} finally {
			statusChangedLock.unlock();
		}

	}

	/*
	 * Questo metodo inizializza la classe per una nuova partita.
	 */
	private void initialize() {

		/* inizializzazione di GameState per una nuova partita */
		gameState.initialize(cluedoNetwork.getActivePlayersGUIDS());

		/* genero un nuovo mazzo di carte */
		deck = new Deck();
		isChoosenCharacterAvailable = true;

		/* apro la rete */
		cluedoNetwork.openNetwork();
	}

	/*
	 * Inizializza il vector clock del giocatore locale, il MessageFactory e
	 * setta in PlayerData l'indice del vector clock
	 */
	private void vectorClockInitialization(Integer vectorClockIndex) {
		/* inizialoizzazione del vector clock */
		vectorClock.setIndex(vectorClockIndex);
		vectorClock.setIndexUnavailable(vectorClockIndex);

		/* inizializzazione (in parte) del MessageFactory */
		MessageFactory.setVectorClock(vectorClock);

		/* aggiornamento di Playerdata con le informazioni sul vector clock */
		gameState.setPlayerVectorClockIndex(localPlayerData.getGUID(), vectorClockIndex);
	}

	/*
	 * Metodo invocato per inizializzare una nuova rete di gioco
	 */
	public boolean localNetworkInitialization() {
		/* Cosi' facendo ottengo l'indice 0, inizializzando una nuovo rete
		significa che sono l'unico che ne fa parte al momento */
		Integer vectorClockIndex = vectorClock.getFirstAvailableIndex();

		vectorClockInitialization(vectorClockIndex);
		return true;
	}

	/*
	 * Metodo invocato per unirsi ad una rete di gioco gia' esistente
	 */
	public boolean remoteNetworkInitialization(String remoteNodeHost, int remoteNodePort) {
		boolean result = false;
		Registry rmiRegistry;
		IRemotePlayer remoteNode = null;
		InitializationData initializationData = null;

		try {
			/* cerco il giocatore remoto a cui chiedere di entrare nella rete */
			rmiRegistry = LocateRegistry.getRegistry(remoteNodeHost, remoteNodePort);
			remoteNode = (IRemotePlayer) rmiRegistry.lookup(Constants.REMOTEPLAYER_BINDING_NAME);

			/* chiedo al giocatore remoto di farmi antrare nella sua rete. Il valore di ritorno
			contiene tutte le informazioni necessarie per far parte della rete, oppure e' null
			se non posso fare parte della rete */
			initializationData = remoteNode.joinGameNetwork(
					localPlayerData.getName(),
					localPlayerData.getGUID(),
					localPlayerData.getRemoteInterface());
		} catch (NotBoundException ex) {
			initializationData = null;
			System.err.println("Impossibile collegarsi all'indirizzo specificato. Non esiste nessun oggetto nel registro RMI col nome " + Constants.REMOTEPLAYER_BINDING_NAME + ".");
		} catch (AccessException ex) {
			initializationData = null;
			System.err.println("Impossibile collegarsi all'indirizzo specificato. Impossibile accedere ad una risorsa fondamentale (es. la rete).");
		} catch (RemoteException ex) {
			initializationData = null;
			System.err.println("Impossibile collegarsi all'indirizzo specificato. Il nodo remoto e' andato in crash.");
		}

		if (initializationData != null) {
			vectorClockInitialization(initializationData.getVectorClockIndex());

			/* inserisco tutti i giocatori passatimi nella rete*/
			for (PlayerData playerData : initializationData.getPlayersData()) {
				insertNewPlayer(
						playerData.getName(),
						playerData.getGUID(),
						playerData.getVectorClockIndex(),
						playerData.getRemoteInterface(),
						playerData.isInGame());
			}

			/* setto i nodi in crash */
			for (Integer crashedPlayerGUID : initializationData.getCrashedNodesGUIDS()) {
				setCrashedPlayer(crashedPlayerGUID);
			}

			/* a questo punto ho tutte le informazioni di ogni altro giocatore nella rete */
			result = true;

			/* controllo che i giocatori siano ancora attivi per evitare inconsistenze
			nei dati che invio */
			for (Integer playerGUID : cluedoNetwork.getActivePlayersGUIDS()) {
				cluedoNetwork.isNodeAlive(playerGUID);
			}
		} else {
			Logger.getLogger(getClass().getName()).logp(
					Level.INFO, getClass().getName(),
					"remoteNetworkInitialization",
					"Richiesta di unione alla rete remota rifiutata");
		}

		return result;
	}

	/*
	 * Marco un evento facendo avanzare il mio timestamp nel vector clock
	 */
	public void markEvent() {
		vectorClock.getNewTimeStamp();
	}

	/*
	 * Restituisce true se il giocatore passato come parametro e' un mittente
	 * valido, false altrimenti
	 */
	public boolean isAValidSender(Integer senderGUID) {
		return cluedoNetwork.isAValidSender(senderGUID);
	}

	/*
	 * Restituisce true se il GUID passato come parametro corrisponde al GUID
	 * del giocatore locale, false altrimenti
	 */
	public boolean amITheSender(Integer originalSenderenderGUID) {
		boolean result;

		if (originalSenderenderGUID.equals(localPlayerData.getGUID())) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	/*
	 * Metodo invocato da un giocatore remoto (non direttamente) per richiedere
	 * di unirsi alla rete di gioco di cui fa parte il giocatore locale.
	 * Se il giocatore remoto puo' unirsi il giocatore locale risponde con tutte
	 * le informazioni necessarie al giocatore remoto per far parte della rete,
	 * altrimenti risponde con null
	 */
	public InitializationData joinGameNetwork(
			String newPlayerName,
			Integer newPlayerGUID,
			IRemotePlayer newPlayer) {

		InitializationData initializationData = null;

		distributedCriticalSection.enter();
		if (cluedoNetwork.canAddNode(newPlayerGUID)) {
			/* ottengo l'indice di vector clock da assegnare al nuovo giocatore */
			Integer newVectorClockIndex = vectorClock.getFirstAvailableIndex();

			/* preparo le informazioni da inviargli */
			initializationData = new InitializationData(
					gameState.cloneAllPlayersData(),
					cluedoNetwork.getCrashedPlayersGUIDS(),
					newVectorClockIndex);

			/* faccio aggiungere il nuovo nodo a tutti i nodi della rete*/
			ArrayList<Integer> multicastGroup = cluedoNetwork.getActivePlayersGUIDS();
			Message msg = MessageFactory.createMessage(MessageType.NEW_NODE,
					new NewNodeBody(newPlayerName, newPlayerGUID, newPlayer, newVectorClockIndex));

			cluedoNetwork.rMulticast(multicastGroup, msg);
		}
		distributedCriticalSection.exit();

		return initializationData;
	}

	/*
	 * Inserisce un nuovo giocatore nella rete
	 */
	public void insertNewPlayer(String newPlayerName,
			Integer newPlayerGUID,
			Integer newPlayerVectorClockIndex,
			IRemotePlayer newPlayerRemoteInterface,
			Boolean inGame) {

		PlayerData newPlayerData = new PlayerData(
				newPlayerName,
				newPlayerGUID,
				newPlayerRemoteInterface,
				newPlayerVectorClockIndex,
				inGame);

		/* inserisco il riferimento remoto del giocatore nella rete */
		cluedoNetwork.insertNewNode(newPlayerGUID, newPlayerRemoteInterface, true);

		/* inserisco le informazioni del giocatore nello stato del gioco */
		gameState.insertNewPlayer(newPlayerGUID, newPlayerData);

		/* setto non piu' disponibile l'indice di vector clock del giocatore */
		vectorClock.setIndexUnavailable(newPlayerVectorClockIndex);

		Logger.getLogger(getClass().getName()).logp(
				Level.INFO, getClass().getName(),
				"insertNewPlayer",
				"Aggiunto nuovo giocatore " + newPlayerGUID);
	}

	public void insertNewPlayer(String newPlayerName,
			Integer newPlayerGUID,
			Integer newPlayerVectorClockIndex,
			IRemotePlayer newPlayerRemoteInterface) {

		insertNewPlayer(newPlayerName, newPlayerGUID, newPlayerVectorClockIndex, newPlayerRemoteInterface, true);
	}

	/*
	 * Setta il giocatore passato come parametro in crash
	 */
	public void setCrashedPlayer(Integer crashedNodeGUID) {

		/* tolgo il giocatore dall'elenco dei giocatori attivi */
		boolean firstTimeProcessed = cluedoNetwork.setCrashedPlayer(crashedNodeGUID);

		/* se e' la prima volta che processo questo giocatore in crash (diversi
		giocatori potrebbero accorgersi del crash, quindi e' possibile ricevere
		piu' di un messaggio differente relativo al crash dello stesso giocatore)*/
		if (firstTimeProcessed) {
			/* recupero l'indice di vector clock del nodo */
			Integer vectorClockIndex = gameState.getPlayerVectorClockIndex(crashedNodeGUID);
			if (vectorClockIndex != null) {
				vectorClock.setIndexAvailable(vectorClockIndex);
			}

			/* tolgo il giocatore dalla lista dei giocatori in gioco
			(redistribuisce le carte, controlla quanti giocatori sono rimasti, ecc) */
			setPlayerOutOfGame(crashedNodeGUID);
		}
	}

	/*
	 * Aggiorna il timestamp (orologio reale locale) dell'ultima comunicazione
	 * effettuata con il giocatore passato come parametro
	 */
	public void updateLastMessageElapsedTime(Integer playerGUID) {
		cluedoNetwork.updateLastMessageElapsedTime(playerGUID);
	}

	/*
	 * Merge del timestamp del vector clock locale con il timestamp passato come
	 * parametro
	 */
	public void mergeVectorClock(Integer[] receivedTimestamp) {
		vectorClock.merge(receivedTimestamp);
	}

	/*
	 * Metodo invocato per richiede accesso alla sezione critia distribuita.
	 * Quando il metodo ritorna significa che abbiamo l'accesso alla CS.
	 */
	public void requestCriticalSection(Integer senderGUID, Integer[] requestTimeStamp) {
		distributedCriticalSection.requestCriticalSection(senderGUID, requestTimeStamp);
	}

	/*
	 * Inizia una nuova partita
	 */
	public void startNewMatch() {
		distributedCriticalSection.enter();

		cluedoNetwork.rMulticast(
				cluedoNetwork.getActivePlayersGUIDS(),
				MessageFactory.createMessage(MessageType.START_NEW_MATCH));

		distributedCriticalSection.exit();
	}

	/*
	 * Inizia la fase di registrazione alla rete
	 */
	public void startRegistrationPhase() {
		initialize();

		gameState.setGamePhase(GamePhase.REGISTRATION);
	}

	/*
	 * Il metodo spedisce un messaggio con la richiesta di finire la fase di
	 * registrazione alla rete
	 */
	public void sendEndRegistrationPhase() {
		distributedCriticalSection.enter();

		/* il messaggio viene inviato solo se la rete puo' essere chiusa.
		Cioe' se si e' raggiunto il numero minimo di giocatori e se la rete
		non e' gia' stata chiusa (in questo modo evito di spedire dei messaggi
		inutili)*/
		if (cluedoNetwork.canCloseNetwork()) {
			cluedoNetwork.rMulticast(
					cluedoNetwork.getActivePlayersGUIDS(),
					MessageFactory.createMessage(MessageType.CLOSE_NETWORK));
		}

		distributedCriticalSection.exit();
	}

	/*
	 * Metodo utilizzato nella fase di selezione del personaggio
	 * Viene invocato in risposta alla domanda di un giocatore per sapere se il
	 * personaggio indicato e' stato scelto da qualcuno.
	 * Ogni giocatore risponde con tutte le informazioni che ha, cioe' non solo
	 * chi ha scelto il personaggio risponde negativamente, ma chiunque sappia
	 * che il personaggio e' stato scelto
	 */
	public void isCharacterAvailable(Integer requesterPlayerGUID, Integer requestedCharacter) {
		Boolean answer = gameState.isCharacterAvailable(requestedCharacter);

		cluedoNetwork.send(requesterPlayerGUID,
				MessageFactory.createMessage(
				MessageType.CHARACTER_AVAILABILITY,
				new CharacterAvailabilityBody(answer)));
	}

	/*
	 * Associa al giocatore passato come parametro il personaggio passato
	 * come parametro
	 */
	public void assignCharacter(Integer playerGUID, Integer selectedCharacter) {
		/* aggiorno i dati del giocatore */
		gameState.setPlayerCharacter(playerGUID, selectedCharacter);

		/* se tutti i giocatori hanno scelto il loro personaggio
		faccio partire la fase di inizializzazione del gioco */
		if (gameState.doesEveryoneHasACharacter()) {
			startGameInitializationPhase();
		}

	}

	/*
	 * Inizia la fase di selezione dei personaggi
	 */
	public void startCharacterSelectionPhase() {
		cluedoNetwork.closeNetwork();

		gameState.setGamePhase(GamePhase.CHARACTER_SELECTION);
	}

	/*
	 * Inizia la fase di inizializzazione del gioco
	 * In questa fase vengono scelti:
	 * - i turni di gioco
	 * - la soluzione
	 * - le carte di ogniuno
	 */
	public void startGameInitializationPhase() {
		gameState.setGamePhase(GamePhase.GAME_INITIALIZATION);
	}

	/*
	 * Metodo utilizzato per inizializzare i dati necessari a giocare una partita
	 * - i turni di gioco
	 * - la soluzione
	 * - le carte di ogniuno
	 */
	public void initializeMatchData() {
		distributedCriticalSection.enter();

		/* se ho gia' le mie carte ho anche la busta e non devo fare nulla */
		if (gameState.getPlayerCards(localPlayerData.getGUID()).size() == 0) {
			/* se ancora non c'e' una soluzione, la pesco io */
			if (gameState.getEnvelope() == null) {
				pickEnvelope();
			}

			/* prendo il mio turno */
			pickTurn();

			/* pesco le mie carte */
			assignCards(calculateCardsToPick());
		}

		distributedCriticalSection.exit();
	}

	/*
	 * Inizia la fase di gioco vera e propria
	 */
	public void startGamePhase() {
		/* setto il primo giocatore di turno */
		Integer firstPlayer = getNextPlayerAliveInTurn();
		gameState.setPlayerInTurn(firstPlayer);

		/* se il primo giocatore di turno sono io, allora cambio la fase di gioco*/
		if (localPlayerData.getGUID().equals(firstPlayer)) {
			gameState.setGamePhase(GamePhase.IN_TURN);
		} else {
			gameState.setGamePhase(GamePhase.NOT_IN_TURN);
		}

		/* controllo se ho tutte le carte che dovrei avere (nel caso fosse andato
		in crash qualche giocatore nelle fasi precedenti) */
		Integer numberOfCardsToPick = calculateCardsToPick();

		if (!numberOfCardsToPick.equals(0)) {
			distributedCriticalSection.enter();

			assignCards(numberOfCardsToPick);

			distributedCriticalSection.exit();
		}
	}

	/*
	 * Questo metodo ritorna true se il GUID del giocatore di turno corrisponde
	 * col GUID del giocatore locale, false altrimenti
	 */
	public boolean isMyTurn() {
		boolean result;

		Integer playerInTurn = gameState.getPlayerInTurn();

		if ((playerInTurn != null) && (playerInTurn.equals(localPlayerData.getGUID()))) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	/*
	 * Questo metodo assegna il primo turno di gioco disponibile al giocatore locale
	 * e lo comunica a tutti
	 */
	private void pickTurn() {
		/* prendo il primo turno disponibile */
		Integer playTurn = turnAssigner.getNextPlayTurn();

		cluedoNetwork.rMulticast(
				cluedoNetwork.getActivePlayersGUIDS(),
				MessageFactory.createMessage(
				MessageType.PLAYTURN,
				new PlayTurnBody(localPlayerData.getGUID(), playTurn)));
	}

	/*
	 * Questo metodo sceglie una soluzione per il gioco e la comunica a tutti
	 */
	private void pickEnvelope() {
		/* scelgo le carte che andranno nella busta */
		ArrayList<Integer> envelope = deck.pickCardsForEnvelope();

		cluedoNetwork.rMulticast(
				cluedoNetwork.getActivePlayersGUIDS(),
				MessageFactory.createMessage(
				MessageType.ENVELOPE,
				new EnvelopeBody(envelope.toArray(new Integer[0]))));
	}

	/*
	 * Questo metodo ritorna le carte pescate per il giocatore locale
	 */
	private ArrayList<Integer> pickCards(Integer cardsToPick) {
		return deck.pickCardsForPlayer(cardsToPick);
	}

	public void setEnvelope(ArrayList<Integer> envelope) {
		gameState.setEnvelope(envelope);

		Logger.getLogger(getClass().getName()).logp(
				Level.INFO,
				getClass().getName(),
				"setEnvelope",
				"Soluzione: " + envelope.get(0) + " " + envelope.get(1) + " " + envelope.get(2));

		/* setto le carte che fanno parte della soluzione come non disponibili */
		deck.setUnavailableCards(envelope);
	}

	/*
	 * Associa al giocatore passato come parametro il turno di gioco passato
	 * come parametro. Inoltre setta il suo turno di gioco come non disponibile
	 */
	public void setPlayerPlayturn(Integer playerGUID, Integer playTurn) {
		/* setto il turno del giocatore */
		turnAssigner.updateNextPlayTurn(playTurn);
		/* aggiorno il contatore dei turni */
		gameState.setPlayerPlayTurn(playerGUID, playTurn);
	}

	/*
	 * Associa al giocatore passato come parametro le carte passate come parametro.
	 * Inoltre setta tali carti come non disponibili
	 */
	public void setPlayerCards(Integer playerGUID, ArrayList<Integer> cards) {
		/* setto le carte del giocatore */
		gameState.setPlayerCards(playerGUID, cards);

		/* se le carte sono le mie allora le setto inattive */
		if (localPlayerData.getGUID().equals(playerGUID)) {
			gameState.setCardsState(cards, CardState.INACTIVE);
		}

		/* le carte del giocatore diventano non disponibili */
		deck.setUnavailableCards(cards);
	}

	/*
	 * Questo metodo controlla se e' il momento di iniziare la fase di gioco
	 */
	public void checkInitializationState() {
		/* se tutti i giocatori hanno scelto le carte faccio partire la fase di gioco */
		if ((gameState.getGamePhase() == GamePhase.GAME_INITIALIZATION)
				&& (gameState.doesEveryoneHastheCards())) {
			startGamePhase();
		}
	}

	/*
	 * Metodo per settare la posizione e calcolare le mosse del personaggio
	 * usato dal giocatore passato come parametro
	 */
	public void setPlayerPosition(Integer playerGUID, Integer[] position) {
		/* calcolo di quando puo' ancora muoversi la pedina */
		Integer moveDistance = gameState.getMoveDistance()
				- ManhattanDistance.calculate(gameState.getPlayerPosition(playerGUID), position);

		/* setto la nuova posizione */
		gameState.setPlayerPosition(playerGUID, position);

		/* calcolo e setto le mosse del giocatore */
		gameState.setMoves(moveDistance);
	}

	/*
	 * Metodo utilizzato nella fase di selezione dei personaggi.
	 * Chiede a tutti i giocatori se il personaggio passato come parametro e'
	 * disponibile. In caso affermativo comunica a tutti che lo ha scelto.
	 */
	public void chooseCharacter(Integer i) {
		/* solo se non ho gia' scelto un personaggio */
		if (gameState.getPlayerCharacter(localPlayerData.getGUID()) == null) {
			distributedCriticalSection.enter();

			cluedoNetwork.rMulticast(
					cluedoNetwork.getActivePlayersGUIDS(),
					MessageFactory.createMessage(
					MessageType.IS_CHARACTER_AVAILABLE,
					new CharacterSelectionBody(localPlayerData.getGUID(), i)));

			if (isChoosenCharacterAvailable) {
				cluedoNetwork.rMulticast(
						cluedoNetwork.getActivePlayersGUIDS(),
						MessageFactory.createMessage(
						MessageType.SELECTED_CHARACTER,
						new CharacterSelectionBody(localPlayerData.getGUID(), i)));
			}

			isChoosenCharacterAvailable = true;

			distributedCriticalSection.exit();
		}
	}

	/*
	 * Metodo utilizzato per rispedire un messaggio.
	 * fa parte del protocollo di multicast affidabile
	 */
	public void resend(Message msg) {
		ArrayList<Integer> multicastGroup = new ArrayList<Integer>();
		for (Integer guid : msg.getMulticastGroup()) {
			multicastGroup.add(guid);
		}

		cluedoNetwork.rMulticast(multicastGroup, MessageFactory.createMessage(msg));
	}

	/*
	 * Metodo utilizzato per "segnarsi" le risposte degli altri giocatori sulla
	 * disponibilita' di un personaggio.
	 * Il personaggio e' disponibile solo se tutti i giocatori rispondono
	 * affermativamente
	 */
	public void setCharacterAvailability(Boolean answer) {
		isChoosenCharacterAvailable = isChoosenCharacterAvailable && answer;
	}

	/*
	 * Metodo invocato per comunicare algi altri giocatori la nuova posizione
	 * del personaggio associato al giocatore locale
	 */
	public void sendPlayerPosition(Integer[] position) {
		cluedoNetwork.rMulticast(
				cluedoNetwork.getActivePlayersGUIDS(),
				MessageFactory.createMessage(
				MessageType.POSITION,
				new PositionBody(localPlayerData.getGUID(), position)));
	}

	/*
	 * Restituisce il GUID del prossimo giocatore secondo i turni di gioco
	 * Controlla che il giocatore selezionato non sia andato in crash, altrimenti
	 * ne sceglie un'altro finche' non ne trova uno attivo
	 */
	private Integer getNextPlayerAliveInTurn() {
		Integer playerGUID = gameState.getPlayerInTurn();

		/* continua a scegliere il successivo giocatore finche' non ne trova uno
		che non sia in crash */
		do {
			playerGUID = gameState.getNextPlayerInGameInTurn(playerGUID);
		} while (!cluedoNetwork.isNodeAlive(playerGUID));

		return playerGUID;
	}

	/*
	 * Restituisce il GUID del giocatore di turno dopo il giocatore locale secondo
	 * i turni di gioco.
	 * Controlla che il giocatore selezionato non sia andato in crash, altrimenti
	 * ne sceglie un'altro finche' non ne trova uno attivo
	 */
	private Integer getPlayerInTurnAfterMe() {
		Integer playerGUID = localPlayerData.getGUID();

		do {
			playerGUID = gameState.getNextPlayerInGameInTurn(playerGUID);
		} while (!cluedoNetwork.isNodeAlive(playerGUID));

		return playerGUID;
	}

	/*
	 * Lancia il dado per sapere di quanto puo' spostarsi il giocatore locale
	 */
	public Integer rollTheDice() {
		Integer result;

		result = dice.roll();

		return result;
	}

	/*
	 * Invia a tutti i giocatori il risultato del lancio del dado
	 */
	public void sendDiceOutcome(Integer diceOutcome) {
		cluedoNetwork.rMulticast(
				cluedoNetwork.getActivePlayersGUIDS(),
				MessageFactory.createMessage(
				MessageType.DICE_OUTCOME,
				new DiceOutcomeBody(diceOutcome)));
	}

	/*
	 * Setta la distanza degli spostamenti del giocatore di turno (in base alla
	 * distanza calcola anche le mosse possibili)
	 */
	public void setMoves(Integer moveDistance) {
		gameState.setMoves(moveDistance);
	}

	/*
	 * Metodo invocato per lanciare un sospetto
	 * Un sospetto si compone di:
	 * - 1 sospettato
	 * - 1 arma del delitto
	 * - 1 luogo del delitto
	 *
	 * Il messaggio del sospetto viene passato da giocatore in giocatore seguendo
	 * l'ordine dei turni di gioco finche' uno dei giocatori che ricevono il messaggio
	 * non hanno tra le loro carte almeno una carta facente parte del sospetto.
	 * Quando cio' avviene una di queste carte viene svelata solo a chi han lanciato
	 * il sospetto.
	 * Per chi ha lanciato il sospetto poi le altre carte diventano SEMIACTIVE
	 * (cioe' potrebbero non fare parte della soluzione), per tutti gli altri invece
	 * tutte le carte facenti parte del sospetto diventano SEMIACTIVE
	 */
	public void makeSuggestion(ArrayList<Integer> proposedSolution) {
		/* faccio controllare la mia accusa al prossimo giocatore di turno */
		Message msg = MessageFactory.createMessage(
				MessageType.SUGGESTION,
				new SuggestionBody(
				localPlayerData.getGUID(),
				proposedSolution.toArray(new Integer[0])));
		boolean ringCommunicationSucceded = ringCommunication(msg);

		if (ringCommunicationSucceded) {
			/* se il sospeto lanciato non e' la soluzione allora almeno una carta non puo'
			fare parte della soluzione. Quindi agli altri giocatori dico di settare
			tutte le carte del sospetto come SEMIACTIVE*/
			if (!gameState.isTheSolution(proposedSolution)) {
				ArrayList<Integer> multicastGroup = cluedoNetwork.getActivePlayersGUIDS();
				cluedoNetwork.rMulticast(
						multicastGroup,
						MessageFactory.createMessage(
						MessageType.SEMIACTIVE_CARDS,
						new SemiactiveCardsBody(proposedSolution.toArray(new Integer[0]))));
			}

			/* dopo aver lanciato un sospetto il turno del giocatore termina */
			sendEndTurn();
		}
	}

	/*
	 * Metodo invocato per controllare il sospetto lanciato da un giocatore
	 */
	public void checkSuggestion(Integer accuserPlayerGUID, Integer[] suggestion) {
		ArrayList<Integer> myCards = gameState.getPlayerCards(localPlayerData.getGUID());
		ArrayList<Integer> revealedCards = gameState.getPlayerRevealedCardTo(localPlayerData.getGUID(), accuserPlayerGUID);
		Integer card = null;

		/* se chi ha lanciato il sospetto non e' il giocatore locale */
		if (!accuserPlayerGUID.equals(localPlayerData.getGUID())) {
			for (Integer suggestionCardID : suggestion) {
				/* se ho una carta la comunico a chi ha lanciato il sospetto */
				if (myCards.contains(suggestionCardID)) {
					/* in questo modo memorizzo quali carte ho comunicato e a chi,
					cosi' la prossima volta gliene comunico una diversa se
					ce l'ho, altrimenti si passa al giocatore successivo*/
					if (!revealedCards.contains(suggestionCardID)) {
						card = suggestionCardID;
						break;
					}
				}
			}

			/* se ho una carta da comunicare lo faccio */
			if (card != null) {
				cluedoNetwork.send(
						accuserPlayerGUID,
						MessageFactory.createMessage(
						MessageType.INACTIVE_CARD,
						new InactiveCardBody(card)));

				gameState.addPlayerRevealedCardTo(localPlayerData.getGUID(), accuserPlayerGUID, card);
				/* altrimenti tocca al prossimo giocatore, secondo i turni,
				controllare */
			} else {
				/* altrimenti passo il controllo al prossimo giocatore di turno */
				Message msg = MessageFactory.createMessage(
						MessageType.SUGGESTION,
						new SuggestionBody(accuserPlayerGUID, suggestion));
				ringCommunication(msg);
			}
		}
	}

	private boolean ringCommunication(Message msg) {
		boolean result = true;
		Integer recipient;
		boolean received = false;

		do {
			recipient = getPlayerInTurnAfterMe();

			if (recipient.equals(gameState.getLocalPlayerGUID())) {
				result = false;
				break;
			} else {
				received = cluedoNetwork.send(
						recipient,
						msg);
			}
		} while (!received);

		return result;
	}

	/*
	 * Questo metodo viene invocato in risposta ad un sospetto quando un altro
	 * giocatore possiede una delle carte che fanno parte del sospetto.
	 *
	 * Solo chi ha lanciato un sospetto riceve il messaggio che invoca questo metodo
	 */
	public void setCardNotInTheSolution(Integer cardID) {
		gameState.setCardState(cardID, CardState.INACTIVE);
	}

	/*
	 * Questo metodo viene invocato quando un giocatore sbaglia un sospetto o
	 * un accusa
	 *
	 * Tutti i giocatori ricevono il messaggio che invoca questo metodo, anche chi
	 * ha lanciato il sospetto o l'accusa.
	 * Dato che quest'ultimo possiede in realta' piu' informazioni degli altri
	 * giocatori, solo le carte con uno stato diverso da INACTIVE diventano
	 * SEMIACTIVE (Cioe' chi gia' sa che una carta non fa sicuramente parte
	 * della soluzione non setta quella carte come probabilmente non facente
	 * parte della soluzione).
	 */
	public void setCardsProbablyNotInTheSolution(ArrayList<Integer> cardsID) {
		for (Integer cardID : cardsID) {
			/* se la carta e' gia' inattiva non la setto semiattiva.
			Se la carta e' inattiva significa che posseggo piu' informazioni degli altri,
			cioe' so che sicuramente questa carta non fa parte della soluzione*/
			if (gameState.getCardState(cardID) != CardState.INACTIVE) {
				gameState.setCardState(cardID, CardState.SEMIACTIVE);
			}
		}
	}

	/*
	 * Metodo invocato per lanciare un'accusa
	 * Un'accusa si compone di:
	 * - 1 sospettato
	 * - 1 arma del delitto
	 * - 1 luogo del delitto
	 *
	 * Dato che ogni giocatore possiede la soluzione, il giocatore che lancia
	 * l'accusa controlla se ha vinto o meno e poi spedisce a tutti un messaggio
	 * con il risultato.
	 * Se ha vinto la partita finisce per tutti e si puo' ricominciare, se ha
	 * perso invece la partita finisce per lui, che continua ad osservarne lo
	 * svolgimento, e continua per gli altri
	 */
	public void makeAccusation(ArrayList<Integer> proposedSolution) {
		/* controllo se l'accusa e' corretta */
		boolean wonTheGame = gameState.isTheSolution(proposedSolution);

		if (wonTheGame) {
			/* avverto tutti che ho vinto la partita */
			cluedoNetwork.rMulticast(
					cluedoNetwork.getActivePlayersGUIDS(),
					MessageFactory.createMessage(
					MessageType.WINNER,
					new WinnerBody(localPlayerData.getGUID())));
		} else {
			/* avverto tutti che ho perso la partita */
			cluedoNetwork.rMulticast(
					cluedoNetwork.getActivePlayersGUIDS(),
					MessageFactory.createMessage(
					MessageType.OUT_OF_GAME,
					new OutOfGameBody(localPlayerData.getGUID())));

			/* comunico a tutti le carte che ho usato per l'accusa in modo che
			le settino semiattive */
			cluedoNetwork.rMulticast(
					cluedoNetwork.getActivePlayersGUIDS(),
					MessageFactory.createMessage(
					MessageType.SEMIACTIVE_CARDS,
					new SemiactiveCardsBody(proposedSolution.toArray(new Integer[0]))));
		}
	}

	/*
	 * Questo metodo spedisce un messaggio che dice a tutti i giocatori che il
	 * turno attuale e' finito e di scegliere quindi il prossimo giocatore di
	 * turno. Tutti i giocatori sono ordinati secondo i turni di gioco, percio'
	 * ogni giocatore localmente fara' la stessa scelta degli altri.
	 */
	public void sendEndTurn() {
		cluedoNetwork.rMulticast(
				cluedoNetwork.getActivePlayersGUIDS(),
				MessageFactory.createMessage(MessageType.END_TURN));
	}

	/*
	 * Termino effettivamente il turno. Trovo il prossimo giocatore e cambio
	 * la fase del gioco di conseguenza
	 */
	public void endTurn() {
		/* resetto le mosse */
		gameState.setMoves(0);

		/* se ero di turno non lo sono piu' */
		if (gameState.getGamePhase() == GamePhase.IN_TURN) {
			gameState.setGamePhase(GamePhase.NOT_IN_TURN);
		}

		/* scelgo e setto il prossimo giocatore di turno */
		Integer nextPlayerInTurn = getNextPlayerAliveInTurn();
		gameState.setPlayerInTurn(nextPlayerInTurn);

		/* se la fase di gioco e' RESTART significa e' andato in crash il giocatore
		di turno e adesso sono rimasto solo io. Essendo da solo non e' il mio turno
		ma ho vinto la partita*/
		if (gameState.getGamePhase() != GamePhase.RESTART) {
			/* se il prossimo di turno sono io, allora cambio la fase di gioco*/
			if (localPlayerData.getGUID().equals(nextPlayerInTurn)) {
				gameState.setGamePhase(GamePhase.IN_TURN);
			}
		}
	}

	/*
	 * Restituisce il numero di carte che bisogna pescare.
	 * Questo valore dipende:
	 * - dal numero totale di carte da pescare
	 * - dal numero di giocatori che devono spartirsi le carte
	 * - dal turno di ongi giocatore che pesca le carte
	 */
	private Integer calculateCardsToPick() {
		int totalCardsToPick = Constants.TOTAL_NUMBER_OF_CARDS - Constants.ENVELOPE_SIZE;
		int numberOfPlayers = gameState.getNumberOfPlayers();
		int playerTurnNumber = gameState.getPlayerTurnNumber(localPlayerData.getGUID());
		/* le carte che dovreiu avere*/
		int cardsIShouldHave = totalCardsToPick / numberOfPlayers;
		int cardsLeftToPick = totalCardsToPick % numberOfPlayers;
		/* le carte che effettivamente ho */
		int cardsIHave = gameState.getPlayerCards(localPlayerData.getGUID()).size();

		if ((cardsLeftToPick != 0)
				&& (playerTurnNumber < cardsLeftToPick)) {
			/* se ci sono delle carte in piu' allora al massimo sono MAX_PLAYERS - 1
			 * quindi ogni giocatore il cui numero di turno e' minore o uguale al numero
			 * di carte rimaste se ne prende un'altra
			 */
			cardsIShouldHave++;
		}

		/* il numero di carte che devo pescare */
		return (cardsIShouldHave - cardsIHave);
	}

	private void assignCards(Integer numberOfCards) {
		/* pesco le carte del giocatore locale */
		ArrayList<Integer> cards = pickCards(numberOfCards);

		/* inviao a tutti un messaggio con le carte che ho scelto */
		cluedoNetwork.rMulticast(
				cluedoNetwork.getActivePlayersGUIDS(),
				MessageFactory.createMessage(
				MessageType.CARDS,
				new CardsBody(localPlayerData.getGUID(), cards.toArray(new Integer[0]))));
	}

	/*
	 * Questo metodo setta un giocatore fuori gioco. Ci sono 2 motivi per finire
	 * fuori gioco:
	 *  - si perde la partita
	 *  - si va in crash
	 *
	 * Se un giocatore va in crash e rimangono attivi meno del numero minimo per
	 * iniziare non riavvio la partita perche' si puo' continuare a giocare
	 * anche in 2.
	 * Una volta finita la partita il gioco si riavvia e non ricomincia finche'
	 * non ci sono abbastanza giocatori.
	 */
	public void setPlayerOutOfGame(Integer outOfGamePlayerGUID) {
		/* elimina dai concorrenti il giocatore passato come parametro */
		gameState.setPlayerOutOfGame(outOfGamePlayerGUID);

		/* le carte del giocatore fuori gioco ritornano disponibili */
		deck.setAvailableCards(gameState.getPlayerCards(outOfGamePlayerGUID));

		/* se sono ancora in gioco */
		if (gameState.isPlayerInGame(localPlayerData.getGUID())) {
			/* se sono gia' nella fase di gioco vera e propria devo spartirmi
			le carte del giocatore fuori dal gioco*/
			if ((gameState.getGamePhase() == GamePhase.IN_TURN)
					|| (gameState.getGamePhase() == GamePhase.NOT_IN_TURN)) {
				/* mi spartisco le carte del giocatore fuori gioco */
				assignCards(calculateCardsToPick());
			}

			/* se il gioco non e' nelle fasi di registrazione alla rete,
			di selezione dei personaggi, o di riavvio */
			GamePhase gamePhase = gameState.getGamePhase();
			if ((!gamePhase.equals(GamePhase.REGISTRATION))
					&& (!gamePhase.equals(GamePhase.CHARACTER_SELECTION))
					&& (!gamePhase.equals(GamePhase.RESTART))) {
				/* se rimango l'unico allora vinco (mando comunque un multicast) */
				if (gameState.getNumberOfPlayers().equals(1)) {
					/* sono rimasto l'unico in gioco, ho vinto*/
					cluedoNetwork.rMulticast(
							cluedoNetwork.getActivePlayersGUIDS(),
							MessageFactory.createMessage(
							MessageType.WINNER,
							new WinnerBody(localPlayerData.getGUID())));
				}
			}
		}

		/* se sono io cambio lo stato alle carte e all'envelope */
		if (outOfGamePlayerGUID.equals(localPlayerData.getGUID())) {
			gameState.setEnvelopeState(CardState.ACTIVE);
			gameState.setAllCardsState(CardState.INACTIVE);
			gameState.setGamePhase(GamePhase.NOT_IN_TURN);
		}

		/* se la partita non e' finita */
		if (gameState.getGamePhase() != GamePhase.RESTART) {
			/* se il giocatore fuori gioco era in turno allora finisce il suo turno*/
			if (outOfGamePlayerGUID.equals(gameState.getPlayerInTurn())) {
				endTurn();
			}
		}
	}

	/*
	 * Finisce la partita annunciando il vincitore
	 */
	public void endTheMatch(Integer winnerPlayerGUID) {
		gameState.setWinnerGUID(winnerPlayerGUID);
		gameState.setGamePhase(GamePhase.RESTART);
		gameState.setEnvelopeState(CardState.ACTIVE);
		gameState.setAllCardsState(CardState.INACTIVE);
	}
}
