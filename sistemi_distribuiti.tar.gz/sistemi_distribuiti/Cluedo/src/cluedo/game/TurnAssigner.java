/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.game;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Questa classe si occupa di assegnare i turni di gioco ai diversi giocatori.
 * Ogni giocatore ha un turno diverso dagli altri.
 * I turni sono completamente ordinati.
 *
 * @author enrico
 */
public class TurnAssigner {

	/* il prossimo turno disponibile da assegnare */
	private Integer nextPlayTurn = 0;

	/*
	 * Restituisce il primo turno disponibile
	 */
	public Integer getNextPlayTurn() {
		Integer result;

		result = ++nextPlayTurn;

		Logger.getLogger(getClass().getName()).logp(
				Level.INFO,
				getClass().getName(),
				"getNextPlayTurn",
				"Nuovo turno assegnato: " + result);

		return result;
	}

	/*
	 * Aggiorna il prossimo turno disponibile per l'assegnamento
	 */
	public void updateNextPlayTurn(Integer value) {
		if (value > nextPlayTurn) {
			nextPlayTurn = value;
		}
	}
}
