/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.game;

import cluedo.gui.IView;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public interface IModel {

	public void subscribe(IView subscriber);
	public void sendEndRegistrationPhase();
	public void initializeMatchData();
	public void chooseCharacter(Integer i);
	public void sendPlayerPosition(Integer[] position);
	public Integer rollTheDice();
	public void sendDiceOutcome(Integer diceOutcome);
	public void makeSuggestion(ArrayList<Integer> proposedSolution);
	public void makeAccusation(ArrayList<Integer> proposedSolution);
	public void sendEndTurn();
	public void startNewMatch();
}
