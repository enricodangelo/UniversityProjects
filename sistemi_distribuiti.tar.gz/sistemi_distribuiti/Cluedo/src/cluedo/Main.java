/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo;

import cluedo.game.GameEngine;
import cluedo.game.IGameEngine;
import cluedo.game.IModel;
import cluedo.gui.CluedoGUI;
import cluedo.gui.IView;

/**
 *
 * @author enrico
 */
public class Main {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		String playerName;
		int rmiListeningPort;
		String remoteNodeHost;
		int remoteNodePort;
		boolean connected;
		IGameEngine gameEngine;
		IView gui;

		if (!((args.length == 2) || (args.length == 3))) {
			System.err.println("Cluedo <Player Name> <listening port> [<remote player URL>]");
			System.exit(-1);
		}

		playerName = args[0];
		rmiListeningPort = Integer.parseInt(args[1]);
		
		if (args.length == 3) {
			remoteNodeHost = args[2].split(":")[0];
			remoteNodePort = Integer.parseInt(args[2].split(":")[1]);
		} else {
			remoteNodeHost = "";
			remoteNodePort = -1;
		}

		gameEngine = new GameEngine(playerName, rmiListeningPort);

		if (remoteNodeHost.equals("") && remoteNodePort == -1) {
			/* do inizio ad una nuova rete */
			connected = gameEngine.localNetworkInitialization();
		} else {
			/* mi collego ad una rete esistente */
			connected = gameEngine.remoteNetworkInitialization(remoteNodeHost, remoteNodePort);
		}

		if (!connected) {
			System.exit(-1);
		}

		/* GUI di Cluedo */
		gui = new CluedoGUI();

		gui.setModel((IModel)gameEngine);
		((IModel)gameEngine).subscribe(gui);
	}
}
