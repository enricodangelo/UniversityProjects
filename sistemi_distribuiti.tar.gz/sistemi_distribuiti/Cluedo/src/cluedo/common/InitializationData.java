/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Questa classe contiene tutte le informazioni necessarie ad un nuovo giocatore
 * che entra a fare parte della rete di Cluedo.
 * E' una classe di convenienza, non e' strettamente necessaria
 * @author enrico
 */
public class InitializationData implements Serializable {
	/* array di PlayerData di tutti i giocatori */
	private PlayerData[] playersData;
	/* array dei GUIDs dei giocatori andati in crash */
	private Integer[] crashedNodesGUIDS;
	/* indice di vector clock che il giocatore locale deve utilizzare */
	private Integer vectorClockIndex;

	public InitializationData(
			ArrayList<PlayerData> playersData,
			ArrayList<Integer> crashedNodesGUIDS,
			Integer vectorClockIndex) {
		this.playersData = playersData.toArray(new PlayerData[0]);
		this.crashedNodesGUIDS = crashedNodesGUIDS.toArray(new Integer[0]);
		this.vectorClockIndex = vectorClockIndex;
	}

	public PlayerData[] getPlayersData() {
		return playersData;
	}

	public Integer[] getCrashedNodesGUIDS() {
		return crashedNodesGUIDS;
	}

	public Integer getVectorClockIndex() {
		return vectorClockIndex;
	}

	@Override
	public String toString() {
		String string = "";

		string += "Initialization data:\n";
		string += "VectorClock index = " + vectorClockIndex + "\n";
		if (playersData.length != 0) {
			string += "PlayersData: ";
			for (int i = 0; i < playersData.length; i++) {
				string += playersData[i];
			}
		}
		string += "\n";
		if (crashedNodesGUIDS.length != 0) {
			string += "Crashed Nodes: ";
			for (int i = 0; i < crashedNodesGUIDS.length; i++) {
				string += crashedNodesGUIDS[i] + " ";
			}
		}

		return string;
	}
}
