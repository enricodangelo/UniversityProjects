/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common;

/**
 * Questa enum rappresenta i diversi tipi di cella presenti sul tabellone.
 * Viene usato un tipo di cella per ogni stanza, per ogni porta, e per ogni
 * punto di inizio.
 *
 * @author enrico
 */
public enum CellType {

	/* questo tipo di cella non fa parte del tabellone (bordo del tabellone) */
	UNUSED,
	COLONEL_MUSTARD_STARTING_POINT,
	MISS_SCARLETT_STARTING_POINT,
	MR_GREEN_STARTING_POINT,
	MRS_PEACOCK_STARTING_POINT,
	MRS_WHITE_STARTING_POINT,
	PROFESSOR_PLUM_STARTING_POINT,
	BALLROOM,
	BILLIARD_ROOM,
	CONSERVATORY,
	DINING_ROOM,
	HALL,
	KITCHEN,
	LIBRARY,
	LOUNGE,
	STUDY,
	BALLROOM_DOOR,
	BILLIARD_ROOM_DOOR,
	CONSERVATORY_DOOR,
	DINING_ROOM_DOOR,
	HALL_DOOR,
	KITCHEN_DOOR,
	LIBRARY_DOOR,
	LOUNGE_DOOR,
	STUDY_DOOR,
	CORRIDOR;
}
