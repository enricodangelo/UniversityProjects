/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author enrico
 */
public class GameState {

	/* lock per accesso in mutua esclusione */
	private Lock gameStateLock;
	/* il tabellone di gioco */
	private Board board;
	/* la fase del gioco corrente */
	private GamePhase gamePhase;
	/* elenco di tutti i giocatori che si sono uniti alla rete dall'inizio
	del gioco (i giocatori vengono eliminati da qua solo quando si comincia
	una nuova partita, e solo i giocatori andati in crash durante la partita
	precedente) */
	private Map<Integer, PlayerData> players;
	/* GUID del giocatore locale */
	private Integer localPlayerGUID;
	/* GUID del giocatore di turno */
	private Integer playerInTurn;
	/* soluzione del gioco */
	private ArrayList<Integer> envelope;
	/* stato della soluzione. Indica se la soluzione debba essere mostrata (ACTIVE)
	o meno (INACTIVE). La soluzione viene mostrata quando il giocatore vince
	o quando perde */
	private CardState envelopeState;
	/* indica lo stato delle carte visualizzare nel pannello BlockNotes
	(BlockNotesPanel). Rappresentano la nostra conoscenza attuale degli indizi
	per arrivare alla soluzione */
	private CardState[] cardsState;
	/* distanza entro la quale puo' spostarsi il giocatore di turno */
	private Integer moveDistance;
	/* elenco di celle in cui puo' spostarsi il giocatore di turno (dipende
	da moveDistance) */
	private ArrayList<Integer[]> moves;
	/* GUID del giocatore che ha vinto la partita */
	private Integer winnerGUID;

	public GameState(Integer localPlayerGUID) {
		gameStateLock = new ReentrantLock();
		players = new Hashtable<Integer, PlayerData>();
		this.localPlayerGUID = localPlayerGUID;
		cardsState = new CardState[Constants.TOTAL_NUMBER_OF_CARDS];
	}

	/*
	 * Questo metodo viene invocato ogni volta che si inizia una partita
	 * (fase REGISTRATION), inizializza tutte le variabili
	 */
	public void initialize(ArrayList<Integer> activePlayers) {
		gameStateLock.lock();
		try {
			board = new Board();
			playerInTurn = null;
			envelope = null;
			envelopeState = CardState.INACTIVE;
			for (int i = 0; i < cardsState.length; i++) {
				cardsState[i] = CardState.ACTIVE;
			}
			moveDistance = 0;
			moves = new ArrayList<Integer[]>();
			winnerGUID = null;

			/* rimuovo da players tutti i giocatori che non sono piu' attivi
			e inizializzo playersInGame*/
			ArrayList<Integer> playerstoRemove = new ArrayList<Integer>();
			for (Integer playerGUID : players.keySet()) {
				if (activePlayers.contains(playerGUID)) {
					players.get(playerGUID).resetPlayerData();
				} else {
					playerstoRemove.add(playerGUID);
				}
			}
			for (Integer playerGUID : playerstoRemove) {
				players.remove(playerGUID);
			}
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce il GUID del giocatore locale
	 */
	public Integer getLocalPlayerGUID() {
		Integer result;

		gameStateLock.lock();
		try {
			result = localPlayerGUID;
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce una copia di tutti gli elementi in players.
	 * Questo metodo viene utilizzato, insieme ad altri, in fase di registrazione
	 * alla rete per passare al nuovo giocatore tutte le informazione sugli altri
	 * componenti.
	 */
	public ArrayList<PlayerData> cloneAllPlayersData() {
		ArrayList<PlayerData> result = new ArrayList<PlayerData>();

		gameStateLock.lock();
		try {
			for (PlayerData playerData : players.values()) {
				result.add(new PlayerData(playerData.getName(),
						playerData.getGUID(),
						playerData.getRemoteInterface(),
						playerData.getVectorClockIndex(),
						playerData.isInGame()));
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce i GUIDS dei giocatori in gioco
	 */
	public ArrayList<Integer> getPlayersGUIDS() {
		ArrayList<Integer> result = new ArrayList<Integer>();

		gameStateLock.lock();
		try {
			for (PlayerData playerData : players.values()) {
				if (playerData.isInGame()) {
					result.add(playerData.getGUID());
				}
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce il numero di giocatori in gioco
	 */
	public Integer getNumberOfPlayers() {
		Integer result = 0;

		gameStateLock.lock();
		try {
			for (PlayerData playerData : players.values()) {
				if (playerData.isInGame()) {
					result++;
				}
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce il tipo di cella determinata dalle coordinate passate
	 */
	public CellType getCellType(Integer row, Integer column) {
		CellType result;

		gameStateLock.lock();
		try {
			result = board.getCellType(row, column);
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce il nome del giocatore con il GUID passato come parametro
	 */
	public String getPlayerName(Integer playerGUID) {
		String result;

		gameStateLock.lock();
		try {
			result = players.get(playerGUID).getName();
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Associa al giocatore passato come parametro il personaggio passato come
	 * parametro.
	 * Questo metodo viene invocato quando un giocatore ha scelto il proprio
	 * personaggio.
	 */
	public void setPlayerCharacter(Integer playerGUID, Integer character) {
		gameStateLock.lock();
		try {
			players.get(playerGUID).setCharacter(character);
			board.setPlayerPosition(playerGUID, Constants.STARTING_POINT_POSITION[character]);
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce il personaggio associato al giocatore passato come parametro
	 */
	public Integer getPlayerCharacter(Integer playerGUID) {
		Integer result;

		gameStateLock.lock();
		try {
			result = players.get(playerGUID).getCharacter();
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce l'indice di vector clock associato al giocatore passato come parametro
	 */
	public Integer getPlayerVectorClockIndex(Integer playerGUID) {
		Integer result = null;

		gameStateLock.lock();
		try {
			if (players.containsKey(playerGUID)) {
				result = players.get(playerGUID).getVectorClockIndex();
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce le carte associate al giocatore passato come parametro
	 */
	public ArrayList<Integer> getPlayerCards(Integer playerGUID) {
		ArrayList<Integer> result = null;

		gameStateLock.lock();
		try {
			if (players.containsKey(playerGUID)) {
				result = players.get(playerGUID).getCards();
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Associa al giocatore passato come parametro l'indice del vector clock da utilizzare
	 */
	public void setPlayerVectorClockIndex(Integer playerGUID, Integer vectorClockIndex) {
		gameStateLock.lock();
		try {
			players.get(playerGUID).setVectorClockIndex(vectorClockIndex);
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Aggiunge la carta passata come parametro all'elenco di carte che il
	 * giocatore "playerGUID" ha mostrato a "otherPlayerGUID"
	 */
	public void addPlayerRevealedCardTo(Integer playerGUID, Integer otherPlayerGUID, Integer cardID) {
		gameStateLock.lock();
		try {
			players.get(playerGUID).addRevealedCard(otherPlayerGUID, cardID);
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce l'elenco di carte che  il giocatore "playerGUID" ha mostrato
	 * a "otherPlayerGUID"
	 */
	public ArrayList<Integer> getPlayerRevealedCardTo(Integer playerGUID, Integer otherPlayerGUID) {
		ArrayList<Integer> result;

		gameStateLock.lock();
		try {
			result = players.get(playerGUID).getRevealedCardsTo(otherPlayerGUID);
			if (result == null) {
				result = new ArrayList<Integer>();
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Setta la fase di gioco corrente
	 */
	public void setGamePhase(GamePhase gamePhase) {
		gameStateLock.lock();
		try {
			this.gamePhase = gamePhase;
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce la fase di gioco corrente
	 */
	public GamePhase getGamePhase() {
		GamePhase result;

		gameStateLock.lock();
		try {
			result = gamePhase;
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce true se il giocatore passato come parametro e' ancora
	 * in gioco, false altrimenti.
	 */
	public boolean isPlayerInGame(Integer playerGUID) {
		boolean result;

		gameStateLock.lock();
		try {
			result = players.get(playerGUID).isInGame();
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Setta il giocatore passato come parametro fuori dal gioco
	 */
	public void setPlayerOutOfGame(Integer playerGUID) {
		gameStateLock.lock();
		try {
			if (players.containsKey(playerGUID)) {
				players.get(playerGUID).setNotInGame();
			}
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Setta il giocatore passato come parametro come giocatore in turno
	 */
	public void setPlayerInTurn(Integer playerGUID) {
		gameStateLock.lock();
		try {
			playerInTurn = playerGUID;
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce il GUID del giocatore in turno
	 */
	public Integer getPlayerInTurn() {
		Integer result;

		gameStateLock.lock();
		try {
			result = playerInTurn;
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Setta come soluzione del gioco l'elenco di carte passate come parametro
	 */
	public void setEnvelope(ArrayList<Integer> envelope) {
		gameStateLock.lock();
		try {
			this.envelope = envelope;
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce la soluzione del gioco
	 */
	public ArrayList<Integer> getEnvelope() {
		ArrayList<Integer> result;

		gameStateLock.lock();
		try {
			result = envelope;
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce true se nessun giocatore ancora in gioco ha scelto il
	 * personaggio passato come parametro, false altrimenti.
	 */
	public boolean isCharacterAvailable(Integer characterID) {
		boolean result = true;

		gameStateLock.lock();
		try {
			for (PlayerData playerData : players.values()) {
				if (playerData.isInGame()) {
					Integer usedCharacterID = playerData.getCharacter();
					if ((usedCharacterID != null) && (usedCharacterID.equals(characterID))) {
						result = false;
					}
				}
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Data la distanza passata come parametro calcola le caselle in cui il
	 * giocatore in turno puo' spostarsi
	 */
	public void setMoves(Integer maxDistanceMove) {
		gameStateLock.lock();
		try {
			this.moveDistance = maxDistanceMove;
			moves = board.findAvailableMoves(playerInTurn, moveDistance);
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce la distanza entro la quale puo' spostarsi il giocatore in turno
	 */
	public Integer getMoveDistance() {
		Integer result;

		gameStateLock.lock();
		try {
			result = moveDistance;
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce l'elenco di caselle in cui puo' spostarsi il giocatore in turno
	 */
	public ArrayList<Integer[]> getMoves() {
		ArrayList<Integer[]> result;

		gameStateLock.lock();
		try {
			result = moves;
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce il GUID del giocatore vincitore
	 */
	public Integer getWinnerGUID() {
		Integer result;

		gameStateLock.lock();
		try {
			result = winnerGUID;
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Setta il GUID del giocatore vincitore
	 */
	public void setWinnerGUID(Integer winnerGUID) {
		gameStateLock.lock();
		try {
			this.winnerGUID = winnerGUID;
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Inserisce un nuovo giocatore
	 */
	public void insertNewPlayer(Integer playerGUID, PlayerData playerData) {
		gameStateLock.lock();
		try {
			players.put(playerGUID, playerData);
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce true se tutti i giocatori in gioco hanno scelto il proprio
	 * personaggio, false altrimenti
	 */
	public boolean doesEveryoneHasACharacter() {
		boolean result = true;

		gameStateLock.lock();
		try {
			for (PlayerData playerData : players.values()) {
				if (playerData.isInGame()) {
					if (playerData.getCharacter() == null) {
						result = false;
					}
				}
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce true se tutti i giocatori in gioco hanno pescato le proprie
	 * carte, false altrimenti
	 */
	public boolean doesEveryoneHastheCards() {
		boolean result = true;

		gameStateLock.lock();
		try {
			for (PlayerData playerData : players.values()) {
				if (playerData.isInGame()) {
					if (playerData.getCards().size() == 0) {
						result = false;
					}
				}
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Metodo invocato per verificare che la carta selezionata rappresenti la
	 * stanza in cui si trova il giocatore.
	 * viene invocato mentre si lancia un sospetto.
	 */
	public boolean isTheRightRoomCard(Integer roomCardID) {
		boolean result = false;

		Integer room = board.getRoom(getPlayerPosition(localPlayerGUID));

		if ((roomCardID - Constants.ROOMS_OFFSET) == room) {
			result = true;
		}

		return result;
	}

	/*
	 * Associa al giocatore passato come parametro il turno passato anch'esso
	 * come parametro
	 */
	public void setPlayerPlayTurn(Integer playerGUID, Integer playTurn) {
		gameStateLock.lock();
		try {
			players.get(playerGUID).setPlayTurn(playTurn);
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Associa al giocatore passato come parametro le carte passate anch'esse
	 * come parametro
	 */
	public void setPlayerCards(Integer playerGUID, ArrayList<Integer> playerCards) {
		gameStateLock.lock();
		try {
			players.get(playerGUID).addCards(playerCards);
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce true se il giocatore locale si trova in una stanza
	 */
	public boolean isPlayerInARoom() {
		boolean result;

		gameStateLock.lock();
		try {
			result = board.isInARoom(localPlayerGUID);
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Associa al giocatore passato come parametro la posizione passata
	 */
	public void setPlayerPosition(Integer playerGUID, Integer[] position) {
		gameStateLock.lock();
		try {
			board.setPlayerPosition(playerGUID, position);
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce la posizione del giocatore passato come parametro
	 */
	public Integer[] getPlayerPosition(Integer playerGUID) {
		Integer[] result;

		gameStateLock.lock();
		try {
			result = board.getPlayerPosition(playerGUID);
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce lo stato della carta passata come parametro
	 */
	public CardState getCardState(Integer cardID) {
		CardState result;

		gameStateLock.lock();
		try {
			result = cardsState[cardID];
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Associa alla carta passata come parametro lo stato passato anch'esso
	 * come parametro
	 */
	public void setCardState(Integer cardID, CardState cardState) {
		gameStateLock.lock();
		try {
			cardsState[cardID] = cardState;
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Associa alle carte passate come parametro lo stato passato anch'esso
	 * come parametro
	 */
	public void setCardsState(ArrayList<Integer> cards, CardState cardState) {
		gameStateLock.lock();
		try {
			for (Integer cardID : cards) {
				cardsState[cardID] = cardState;
			}
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Associa a tutte le carte lo stato passato come parametro
	 */
	public void setAllCardsState(CardState cardState) {
		gameStateLock.lock();
		try {
			for (int i = 0; i < cardsState.length; i++) {
				cardsState[i] = cardState;
			}
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce lo stato della soluzione del gioco
	 */
	public CardState getEnvelopeState() {
		CardState result;

		gameStateLock.lock();
		try {
			if (envelope != null) {
				result = envelopeState;
			} else {
				result = CardState.INACTIVE;
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Associa alla soluzione del gioco lo stato passato come parametro
	 */
	public void setEnvelopeState(CardState cardState) {
		gameStateLock.lock();
		try {
			envelopeState = cardState;
		} finally {
			gameStateLock.unlock();
		}
	}

	/*
	 * Restituisce il prossimo giocatore in gioco secondo i turni di gioco
	 */
	public Integer getNextPlayerInGameInTurn(Integer playerGUID) {
		Integer result;

		gameStateLock.lock();
		try {
			ArrayList<Integer> sortedPlayers = sortPlayersByTurns();
			result = null;

			/* se il GUID del giocatore passato e' null allora voglio il primo in turno,
			per fare cio' assegno a playerGUID il GUID dell'ultimo giocatore in turno
			ed eseguo l'algoritmo */
			if (playerGUID == null) {
				playerGUID = sortedPlayers.get(sortedPlayers.size() - 1);
			}

			do {
				for (int i = 0; i < sortedPlayers.size(); i++) {
					if (sortedPlayers.get(i).equals(playerGUID)) {
						result = sortedPlayers.get((i + 1) % sortedPlayers.size());
					}
				}

				playerGUID = result;
				} while (!players.get(playerGUID).isInGame());
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce la lista di giocatori, in gioco e non, ordinata secondo i
	 * turni di gioco.
	 *
	 */
	private ArrayList<Integer> sortPlayersByTurns() {
		Map<Integer, Integer> orderedPlayers = new TreeMap<Integer, Integer>();

		gameStateLock.lock();
		try {
			for (Integer playerGUID : players.keySet()) {
				if (players.get(playerGUID).getPlayTurn() != null) {
					orderedPlayers.put(players.get(playerGUID).getPlayTurn(), playerGUID);
				}
			}
		} finally {
			gameStateLock.unlock();
		}

		return new ArrayList<Integer>(orderedPlayers.values());
	}

	/*
	 * Restituisco il turno di gioco del giocatore passato come parametro.
	 * Il turno di gioco restituito e' un numero compreso tra 0 e il numero
	 * di giocatori in gioco meno uno.
	 * Piu' formalmente [0, getNumberOfPlayers() - 1]
	 */
	public Integer getPlayerTurnNumber(Integer playerGUID) {
		Integer result = null;

		gameStateLock.lock();
		try {
			ArrayList<Integer> sortedPlayers = sortPlayersByTurns();
			ArrayList<Integer> sortedActivePlayers = new ArrayList<Integer>();

			for (Integer sortedPlayerGUID : sortedPlayers) {
				if (players.get(sortedPlayerGUID).isInGame()) {
					sortedActivePlayers.add(sortedPlayerGUID);
				}
			}

			for (int i = 0; i < sortedActivePlayers.size(); i++) {
				if (sortedActivePlayers.get(i).equals(playerGUID)) {
					result = i;
				}
			}
		} finally {
			gameStateLock.unlock();
		}

		return result;
	}

	/*
	 * Restituisce true se l'elenco di carte passate come parametro sono esattamente
	 * quelle presenti nella soluzione del gioco, false altrimenti
	 */
	public boolean isTheSolution(ArrayList<Integer> proposedSolution) {
		boolean result = true;

		for (Integer proposedSolutionPart : proposedSolution) {
			if (!getEnvelope().contains(proposedSolutionPart)) {
				result = false;
			}
		}

		return result;
	}
}
