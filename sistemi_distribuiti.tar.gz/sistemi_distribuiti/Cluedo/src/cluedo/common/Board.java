/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common;

import cluedo.common.CellType;
import cluedo.common.Constants;
import cluedo.common.ManhattanDistance;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;

/**
 * Questa classe rappresenta il tabellone di goco
 * @author enrico
 */
public class Board {

	/* le caselle che formano il tabellone */
	private CellType[][] board;
	/* le posizioni di tutti i giocatori in gioco */
	private Map<Integer, Integer[]> playersPosition;

	public Board() {

		playersPosition = new Hashtable<Integer, Integer[]>();

		board = new CellType[Constants.BOARD_ROWS][Constants.BOARD_COLUMNS];

		/* inizializzo le caselle del tabellone */
		for (int i = 0; i < Constants.BOARD_ROWS; i++) {
			for (int j = 0; j < Constants.BOARD_COLUMNS; j++) {
				/* il bordo e' tutto unused */
				if ((i == 0) || (i == Constants.BOARD_ROWS - 1) || (j == 0) || (j == Constants.BOARD_COLUMNS - 1)) {
					board[i][j] = CellType.UNUSED;
				} else {
					/* il resto per ora e' corridoio */
					board[i][j] = CellType.CORRIDOR;
				}
			}
		}

		/* setto i punti di partenza dei personaggi */
		for (int k = 0; k < Constants.NUMBER_OF_CHARACTERS; k++) {
			int j = Constants.STARTING_POINT_POSITION[k][Constants.X];
			int i = Constants.STARTING_POINT_POSITION[k][Constants.Y];
			switch (k) {
				case 0:
					board[i][j] = CellType.COLONEL_MUSTARD_STARTING_POINT;
					break;
				case 1:
					board[i][j] = CellType.MISS_SCARLETT_STARTING_POINT;
					break;
				case 2:
					board[i][j] = CellType.MR_GREEN_STARTING_POINT;
					break;
				case 3:
					board[i][j] = CellType.MRS_PEACOCK_STARTING_POINT;
					break;
				case 4:
					board[i][j] = CellType.MRS_WHITE_STARTING_POINT;
					break;
				case 5:
					board[i][j] = CellType.PROFESSOR_PLUM_STARTING_POINT;
					break;
			}
		}

		/* setto le caselle che fanno parte delle stanze */
		for (int k = 0; k < Constants.NUMBER_OF_ROOMS; k++) {
			for (int i = Constants.ROOM_UPPERLEFT_CORNER[k][Constants.Y]; i <= Constants.ROOM_LOWERRIGHT_CORNER[k][Constants.Y]; i++) {
				for (int j = Constants.ROOM_UPPERLEFT_CORNER[k][Constants.X]; j <= Constants.ROOM_LOWERRIGHT_CORNER[k][Constants.X]; j++) {
					switch (k) {
						case 0:
							board[i][j] = CellType.BALLROOM;
							break;
						case 1:
							board[i][j] = CellType.BILLIARD_ROOM;
							break;
						case 2:
							board[i][j] = CellType.CONSERVATORY;
							break;
						case 3:
							board[i][j] = CellType.DINING_ROOM;
							break;
						case 4:
							board[i][j] = CellType.HALL;
							break;
						case 5:
							board[i][j] = CellType.KITCHEN;
							break;
						case 6:
							board[i][j] = CellType.LIBRARY;
							break;
						case 7:
							board[i][j] = CellType.LOUNGE;
							break;
						case 8:
							board[i][j] = CellType.STUDY;
							break;
					}
				}
			}
		}

		/* setto le caselle che fanno parte delle porte */
		for (int k = 0; k < Constants.DOORS.length; k++) {
			int[][] roomDoors = Constants.DOORS[k];

			for (int l = 0; l < roomDoors.length; l++) {
				int i = roomDoors[l][Constants.Y];
				int j = roomDoors[l][Constants.X];
				CellType cellType = null;

				switch (k) {
					case 0:
						cellType = CellType.BALLROOM_DOOR;
						break;
					case 1:
						cellType = CellType.BILLIARD_ROOM_DOOR;
						break;
					case 2:
						cellType = CellType.CONSERVATORY_DOOR;
						break;
					case 3:
						cellType = CellType.DINING_ROOM_DOOR;
						break;
					case 4:
						cellType = CellType.HALL_DOOR;
						break;
					case 5:
						cellType = CellType.KITCHEN_DOOR;
						break;
					case 6:
						cellType = CellType.LIBRARY_DOOR;
						break;
					case 7:
						cellType = CellType.LOUNGE_DOOR;
						break;
					case 8:
						cellType = CellType.STUDY_DOOR;
						break;
				}
				board[i][j] = cellType;
			}
		}
	}

	/*
	 * Associo al giocatore passato come parametro la posizione passata
	 */
	public void setPlayerPosition(Integer playerGUID, Integer[] position) {
		playersPosition.put(playerGUID, position);
	}

	/*
	 * Restituisce la posizione del giocatore passato come parametro
	 */
	public Integer[] getPlayerPosition(Integer playerGUID) {
		return playersPosition.get(playerGUID);
	}

	/*
	 * Elimina la posizione del giocatore passato come parametro
	 */
	public void removePlayer(Integer playerGUID) {
		playersPosition.remove(playerGUID);
	}

	/*
	 * Restituisce il tipo di casella indicata dale coordinate passate come parametro
	 */
	public CellType getCellType(Integer row, Integer column) {
		return board[row][column];
	}

	/*
	 * Restituisce la stanza che contiene le coordinate passate come parametro.
	 * Se le coordinate non sono contenute in nessuna stanza, allora viene
	 * restituito null
	 */
	public Integer getRoom(Integer[] position) {
		Integer result = null;

		for (int k = 0; k < Constants.NUMBER_OF_ROOMS; k++) {
			if ((position[Constants.X].compareTo(Constants.ROOM_UPPERLEFT_CORNER[k][Constants.X]) >= 0)
					&& (position[Constants.Y].compareTo(Constants.ROOM_UPPERLEFT_CORNER[k][Constants.Y]) >= 0)
					&& (position[Constants.X].compareTo(Constants.ROOM_LOWERRIGHT_CORNER[k][Constants.X]) <= 0)
					&& (position[Constants.Y].compareTo(Constants.ROOM_LOWERRIGHT_CORNER[k][Constants.Y]) <= 0)) {
				result = k;
				break;
			}
		}

		return result;
	}

	/*
	 * Restituisce true se il giocatore passato cme parametro si trova
	 * all'interno di una stanza, false altrimenti
	 */
	public boolean isInARoom(Integer playerGUID) {
		boolean result = false;

		Integer[] playerPosition = getPlayerPosition(playerGUID);

		if (getRoom(playerPosition) != null) {
			result = true;
		}

		return result;
	}

	/*
	 * Restituisce tutte le caselle in cui il giocatore passato come parametro puo' andare
	 * entro la distanza passata anch'essa come parametro
	 */
	public ArrayList<Integer[]> findAvailableMoves(Integer playerGUID, Integer distance) {
		Integer[] currentPosition = playersPosition.get(playerGUID);
		ArrayList<Integer[]> availableCells = new ArrayList<Integer[]>();
		HashSet<Integer[]> previousIterationCells = new HashSet<Integer[]>();
		HashSet<Integer[]> currentIterationCells = new HashSet<Integer[]>();
		previousIterationCells.add(currentPosition);

		/* solo se maxDistanceMove e' settato */
		if ((distance != null) && (distance.intValue() >= 0)) {
			for (int currentDistance = 1; currentDistance <= distance; currentDistance++) {
				/* resetto l'insieme di caselle trovate in questa iterazione */
				currentIterationCells = new HashSet<Integer[]>();

				for (Integer[] cell : previousIterationCells) {
					/* genero le caselle vicine in ALTO, DESTRA, BASSO, SINISTRA */
					ArrayList<Integer[]> neighborCells = generateNeighbours(cell);
					for (Integer[] neighborCell : neighborCells) {
						/* controllo che le caselle generate siano entro i limiti del tabellone (board) */
						if ((neighborCell[Constants.X] >= 0)
								&& (neighborCell[Constants.X] < Constants.BOARD_COLUMNS)
								&& (neighborCell[Constants.Y] >= 0)
								&& (neighborCell[Constants.Y] < Constants.BOARD_ROWS)) {
							/* neighbr deve trovarsi alla giusta distanza (altrimenti, o l'ho gia' aggiunta o e' troppo distante) */
							if (ManhattanDistance.calculate(currentPosition, neighborCell) == currentDistance) {
								/* se e' possibile spostarsi da cell (la casella che ha generato neighborCell)
								a neighborCell, allora la aggiungo alle caselle trovate in questa iterazione*/
								if (canGo(cell, neighborCell)) {
									currentIterationCells.add(neighborCell);
								}
							}
						}
					}
				}

				/* Aggiungo le caselle trovate all'elenco delle caselle disponibili per muovermi,
				e previousIterationCells diventa currentIterationCells */
				previousIterationCells = new HashSet<Integer[]>();
				for (Integer[] cell : currentIterationCells) {
					boolean newMove = true;
					/* filtro le mosse doppie */
					for (Integer[] otherCell : availableCells) {
						if ((otherCell[0].compareTo(cell[0]) == 0) && (otherCell[1].compareTo(cell[1]) == 0)) {
							newMove = false;
						}
					}
					if (newMove) {
						availableCells.add(cell);
						previousIterationCells.add(cell);
					}
				}
			}
		}

		return availableCells;
	}

	/*
	 * helper method
	 * Data una cella restituisce tutte le celle adiacenti (anche fuori dai
	 * limiti del tabellone)
	 */
	private ArrayList<Integer[]> generateNeighbours(Integer[] cell) {
		ArrayList<Integer[]> neighborCells = new ArrayList<Integer[]>();

		Integer[] N = {cell[Constants.X], cell[Constants.Y] - 1};
		Integer[] W = {cell[Constants.X] + 1, cell[Constants.Y]};
		Integer[] S = {cell[Constants.X], cell[Constants.Y] + 1};
		Integer[] E = {cell[Constants.X] - 1, cell[Constants.Y]};

		neighborCells.add(N);
		neighborCells.add(W);
		neighborCells.add(S);
		neighborCells.add(E);

		return neighborCells;
	}

	/*
	 * Restituisce true se e' possibile spostarsi dalla posizione oldPosition
	 * alla posizione newPosition
	 * oldPosition e newPosition sono assunte essere posizioni adiacenti
	 */
	private boolean canGo(Integer[] oldPosition, Integer[] newPosition) {
		boolean result = false;
		CellType oldPositionCellType = board[oldPosition[Constants.Y]][oldPosition[Constants.X]];
		CellType newPositionCellType = board[newPosition[Constants.Y]][newPosition[Constants.X]];

		if (newPositionCellType != CellType.UNUSED) {
			if (comingFromAStartingPoint(oldPositionCellType, newPositionCellType)
					|| goingThroughADoor(oldPositionCellType, newPositionCellType)
					|| oldPositionCellType == newPositionCellType) {
				if ((!goingToAStartingPoint(newPositionCellType)
						&& isPositionFree(newPosition[Constants.X], newPosition[Constants.Y]))) {
					result = true;
				} else {
					result = false;
				}
			} else {
				result = false;
			}
		} else {
			result = false;
		}

		return result;
	}

	/*
	 * helper method
	 * Restituisce true se nessun giocatore si trova nelle coordinate passate
	 * come parametri, false altrimenti.
	 */
	private boolean isPositionFree(Integer x, Integer y) {
		boolean result = true;

		for (Integer[] playerPosition : playersPosition.values()) {
			if ((!playerPosition[Constants.X].equals(x)) || (!playerPosition[Constants.Y].equals(y))) {
				result = result && true;
			} else {
				return false;
			}
		}

		return result;
	}

	/*
	 * helper method
	 * Restituisce true se oldPosition e' il punto di partenza di un giocatore e
	 * newPosition una casella valida (dipende da come sono disposti i punti di
	 * partenza), false altrimenti.
	 */
	private boolean comingFromAStartingPoint(CellType oldPositionCellType, CellType newPositionCellType) {
		boolean result = false;

		if (((oldPositionCellType == CellType.MRS_WHITE_STARTING_POINT)
				|| (oldPositionCellType == CellType.MR_GREEN_STARTING_POINT))
				&& newPositionCellType == CellType.BALLROOM) {
			result = true;
		} else if (((oldPositionCellType == CellType.COLONEL_MUSTARD_STARTING_POINT)
				|| (oldPositionCellType == CellType.MISS_SCARLETT_STARTING_POINT)
				|| (oldPositionCellType == CellType.MRS_PEACOCK_STARTING_POINT)
				|| (oldPositionCellType == CellType.PROFESSOR_PLUM_STARTING_POINT)) && newPositionCellType == CellType.CORRIDOR) {
			result = true;
		}

		return result;
	}

	/*
	 * helper method
	 * Restituisce true se: oldPositioCellType indica una stanza, e newPositionCellType
	 * indica la porta corrispondente, o viceversa (porta-stanza).
	 * Restituisce false altrimenti
	 */
	private boolean goingThroughADoor(CellType oldPositionCellType, CellType newPositionCellType) {
		boolean result = //da una stanza alla sua porta
				((oldPositionCellType == CellType.BALLROOM) && (newPositionCellType == CellType.BALLROOM_DOOR))
				|| ((oldPositionCellType == CellType.BILLIARD_ROOM) && (newPositionCellType == CellType.BILLIARD_ROOM_DOOR))
				|| ((oldPositionCellType == CellType.CONSERVATORY) && (newPositionCellType == CellType.CONSERVATORY_DOOR))
				|| ((oldPositionCellType == CellType.DINING_ROOM) && (newPositionCellType == CellType.DINING_ROOM_DOOR))
				|| ((oldPositionCellType == CellType.HALL) && (newPositionCellType == CellType.HALL_DOOR))
				|| ((oldPositionCellType == CellType.KITCHEN) && (newPositionCellType == CellType.KITCHEN_DOOR))
				|| ((oldPositionCellType == CellType.LIBRARY) && (newPositionCellType == CellType.LIBRARY_DOOR))
				|| ((oldPositionCellType == CellType.LOUNGE) && (newPositionCellType == CellType.LOUNGE_DOOR))
				|| ((oldPositionCellType == CellType.STUDY) && (newPositionCellType == CellType.STUDY_DOOR))
				|| //da una porta alla sua stanza
				((oldPositionCellType == CellType.BALLROOM_DOOR) && (newPositionCellType == CellType.BALLROOM))
				|| ((oldPositionCellType == CellType.BILLIARD_ROOM_DOOR) && (newPositionCellType == CellType.BILLIARD_ROOM))
				|| ((oldPositionCellType == CellType.CONSERVATORY_DOOR) && (newPositionCellType == CellType.CONSERVATORY))
				|| ((oldPositionCellType == CellType.DINING_ROOM_DOOR) && (newPositionCellType == CellType.DINING_ROOM))
				|| ((oldPositionCellType == CellType.HALL_DOOR) && (newPositionCellType == CellType.HALL))
				|| ((oldPositionCellType == CellType.KITCHEN_DOOR) && (newPositionCellType == CellType.KITCHEN))
				|| ((oldPositionCellType == CellType.LIBRARY_DOOR) && (newPositionCellType == CellType.LIBRARY))
				|| ((oldPositionCellType == CellType.LOUNGE_DOOR) && (newPositionCellType == CellType.LOUNGE))
				|| ((oldPositionCellType == CellType.STUDY_DOOR) && (newPositionCellType == CellType.STUDY))
				|| //dal corridoio ad una porta
				(oldPositionCellType == CellType.CORRIDOR)
				&& ((newPositionCellType == CellType.BALLROOM_DOOR)
				|| (newPositionCellType == CellType.BILLIARD_ROOM_DOOR)
				|| (newPositionCellType == CellType.CONSERVATORY_DOOR)
				|| (newPositionCellType == CellType.DINING_ROOM_DOOR)
				|| (newPositionCellType == CellType.HALL_DOOR)
				|| (newPositionCellType == CellType.KITCHEN_DOOR)
				|| (newPositionCellType == CellType.LIBRARY_DOOR)
				|| (newPositionCellType == CellType.LOUNGE_DOOR)
				|| (newPositionCellType == CellType.STUDY_DOOR))
				|| //da una porta al corridoio
				((oldPositionCellType == CellType.BALLROOM_DOOR)
				|| (oldPositionCellType == CellType.BILLIARD_ROOM_DOOR)
				|| (oldPositionCellType == CellType.CONSERVATORY_DOOR)
				|| (oldPositionCellType == CellType.DINING_ROOM_DOOR)
				|| (oldPositionCellType == CellType.HALL_DOOR)
				|| (oldPositionCellType == CellType.KITCHEN_DOOR)
				|| (oldPositionCellType == CellType.LIBRARY_DOOR)
				|| (oldPositionCellType == CellType.LOUNGE_DOOR)
				|| (oldPositionCellType == CellType.STUDY_DOOR)) && (newPositionCellType == CellType.CORRIDOR);

		return result;
	}

	/*
	 * Restituisce true se la posizione passata come parametro e' il punto
	 * di partenza di un giocatore, false altrimenti
	 */
	private boolean goingToAStartingPoint(CellType newPositionCellType) {
		boolean result = (newPositionCellType == CellType.COLONEL_MUSTARD_STARTING_POINT)
				|| (newPositionCellType == CellType.MISS_SCARLETT_STARTING_POINT)
				|| (newPositionCellType == CellType.MR_GREEN_STARTING_POINT)
				|| (newPositionCellType == CellType.MRS_PEACOCK_STARTING_POINT)
				|| (newPositionCellType == CellType.MRS_WHITE_STARTING_POINT)
				|| (newPositionCellType == CellType.PROFESSOR_PLUM_STARTING_POINT);

		return result;
	}
}
