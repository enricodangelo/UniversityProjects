/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common.message;

import cluedo.common.InitializationData;

/**
 *
 * @author enrico
 */
public class NetworkStatusBody implements IMessageBody {

	private InitializationData networkStatus;

	public NetworkStatusBody(InitializationData networkStatus) {
		this.networkStatus = networkStatus;
	}

	public InitializationData getNetworkStatus() {
		return networkStatus;
	}

	@Override
	public String toString() {
		String string = "";

		string += networkStatus.toString();

		return string;
	}
}
