/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common.message;

import cluedo.game.IRemotePlayer;

/**
 *
 * @author enrico
 */
public class JoinNetworkBody implements IMessageBody {

	private Integer newNodeGUID;
	private IRemotePlayer newNode;

	public JoinNetworkBody(Integer newNodeGUID, IRemotePlayer newNode) {
		this.newNodeGUID = newNodeGUID;
		this.newNode = newNode;
	}

	public IRemotePlayer getNewNode() {
		return newNode;
	}

	public Integer getNewNodeGUID() {
		return newNodeGUID;
	}

	@Override
	public String toString() {
		String string = "";

		string += "newNodeGUID = " + newNodeGUID;

		return string;
	}
}
