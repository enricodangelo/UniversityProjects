/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class CharacterSelectionBody implements IMessageBody {

	private Integer playerGUID;
	private Integer character;

	public CharacterSelectionBody(Integer playerGUID, Integer character) {
		this.playerGUID = playerGUID;
		this.character = character;
	}

	public Integer getPlayerGUID() {
		return playerGUID;
	}

	public Integer getCharacter() {
		return character;
	}

	@Override
	public String toString() {
		String string = "";

		string += "player = " + playerGUID;
		string += "\n";
		string += "character = " + character;

		return string;
	}
}
