/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class CSRequestBody implements IMessageBody {

	private Integer requesterPlayerID;
	private Integer[] requestTimeStamp;

	public CSRequestBody(Integer requesterPlayerID, Integer[] requestTimeStamp) {
		this.requesterPlayerID = requesterPlayerID;
		this.requestTimeStamp = requestTimeStamp;
	}

	public Integer[] getRequestTimeStamp() {
		return requestTimeStamp;
	}

	public Integer getRequesterPlayerID() {
		return requesterPlayerID;
	}
}
