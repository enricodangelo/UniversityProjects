/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common.message;

/**
 *
 * @author enrico
 */
public enum MessageType {

	/* messaggio di test */
	TEST,
	/* messaggio di polling */
	POLL,
	/* notifica di un nodo rilevato in crash*/
	NOTIFY_CRASH,
	/* nuovo nodo da inserire nella rete */
	NEW_NODE,
	/* richiesta d'accesso alla sezione critica */
	CRITICAL_SECTION_REQUEST,
	/* chiude la rete */
	CLOSE_NETWORK,
	/* inizia una nuova partita */
	START_NEW_MATCH,
	/* per sapere se il peronaggio indicato e' ancora libero */
	IS_CHARACTER_AVAILABLE,
	/* indica la disponibilita' di un personaggio */
	CHARACTER_AVAILABILITY,
	/* notifica del personaggio scelto */
	SELECTED_CHARACTER,
	/**/
	PLAYTURN,
	/* messaggio che contiene la soluzione*/
	ENVELOPE,
	/* messaggio che contiene le carte pescate da un giocatore */
	CARDS,
	/* notifica della nuova posizione del giocatore di turno */
	POSITION,
	/* notifica del risultato del lancio del dado */
	DICE_OUTCOME,
	/* sospetto */
	SUGGESTION,
	/* notifica delle carte che potrebbero non far parte della soluzione */
	SEMIACTIVE_CARDS,
	/* notifica delle carte che non fanno parte della soluzione */
	INACTIVE_CARD,
	/* notifica il vincitore della partita */
	WINNER,
	/* notifica che un giocatore non e' piu' in gioco */
	OUT_OF_GAME,
	/* fine del turno per il giocatore di turno */
	END_TURN;
}
