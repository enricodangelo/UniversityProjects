/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common.message;

/**
 * Corpo di un messaggio che notifica il crash di un nod
 *
 * @author enrico
 */
public class NotifyCrashBody implements IMessageBody {

	private Integer crashedNodeGUID;

	public NotifyCrashBody(Integer crashedNodesGUID) {
		this.crashedNodeGUID = crashedNodesGUID;
	}

	public Integer getCrashedNodeGUID() {
		return crashedNodeGUID;
	}

	@Override
	public String toString() {
		String string = "";

		string += "crashedNodeGUID = " + crashedNodeGUID;

		return string;
	}
}
