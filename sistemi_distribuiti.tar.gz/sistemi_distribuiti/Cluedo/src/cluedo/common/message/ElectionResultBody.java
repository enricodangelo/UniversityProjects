/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class ElectionResultBody implements IMessageBody {

	private Integer leaderGUID;

	public ElectionResultBody(Integer leaderGUID) {
		this.leaderGUID = leaderGUID;
	}

	public Integer getLeaderGUID() {
		return leaderGUID;
	}

	@Override
	public String toString() {
		String string = "";

		string += leaderGUID;
		string += "\n";
		
		return string;
	}
}
