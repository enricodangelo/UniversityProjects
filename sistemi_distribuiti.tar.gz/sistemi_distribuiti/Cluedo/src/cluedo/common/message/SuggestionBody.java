/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class SuggestionBody implements  IMessageBody {

	private Integer accuserPlayerGUID;
	private Integer[] suggestion;

	public SuggestionBody(Integer accuserPlayerGUID, Integer[] suggestion) {
		this.accuserPlayerGUID = accuserPlayerGUID;
		this.suggestion = suggestion;
	}

	public Integer getAccuserPlayerGUID() {
		return accuserPlayerGUID;
	}

	public Integer[] getSuggestion() {
		return suggestion;
	}

	@Override
	public String toString() {
		String string = "";

		string += "accuserPlayerGUID: " + accuserPlayerGUID;
		string += "\n";
		string += "suggestion: ";
		for (Integer cardID : suggestion) {
			string += cardID + " ";
		}

		return string;
	}
}
