/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class CharacterAvailabilityBody implements IMessageBody {

	private Boolean availability;

	public CharacterAvailabilityBody(Boolean availability) {
		this.availability = availability;
	}

	public Boolean getAvailability() {
		return availability;
	}

	@Override
	public String toString() {
		String string = "";

		string += "availability: " + availability;
		string += "\n";

		return string;
	}
}
