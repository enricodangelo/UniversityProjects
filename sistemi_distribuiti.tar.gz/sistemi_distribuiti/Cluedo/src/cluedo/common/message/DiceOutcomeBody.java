/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class DiceOutcomeBody implements IMessageBody {

	private Integer diceOutcome;

	public DiceOutcomeBody(Integer diceOutcome) {
		this.diceOutcome = diceOutcome;
	}

	public Integer getDiceOutcome() {
		return diceOutcome;
	}

	@Override
	public String toString() {
		String string = "";

		string += "diceOutcome: " + diceOutcome;
		string += "\n";

		return string;
	}
}
