/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class PlayTurnBody implements IMessageBody {

	private Integer playerGUID;
	private Integer playTurn;

	public PlayTurnBody(Integer playerGUID, Integer playTurn) {
		this.playerGUID = playerGUID;
		this.playTurn = playTurn;
	}

	public Integer getPlayerGUID() {
		return playerGUID;
	}

	public Integer getPlayTurn() {
		return playTurn;
	}

	@Override
	public String toString() {
		String string = "";

		string += "playerGUID = " + playerGUID;
		string += "\n";
		string += "playTurn = " + playTurn;

		return string;
	}
}
