/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

import java.io.Serializable;

/**
 *
 * @author enrico
 */
public interface IMessageBody extends Serializable {

}
