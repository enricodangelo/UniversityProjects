/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

import cluedo.game.VectorClock;

/**
 *
 * @author enrico
 */
public class MessageFactory {
	private static Integer messageCounter = 1;
	private static Integer _idSeed;
	private static Integer _senderGUID;
	private static VectorClock _vectorClock;

	public static void setIDSeed(Integer idSeed) {
		_idSeed = idSeed;
	}

	public static void setSenderGUID(Integer senderGUID) {
		_senderGUID = senderGUID;
	}

	public static void setVectorClock(VectorClock vectorClock) {
		_vectorClock = vectorClock;
	}

	public static Message createMessage(MessageType type, IMessageBody body) {
		Message msg = new Message(
				type,
				_senderGUID,
				_senderGUID,
				_idSeed.toString() + "-" + messageCounter.toString(),
				_vectorClock.getNewTimeStamp(),
				body);

		messageCounter++;

		return msg;
	}

	public static Message createMessage(MessageType type) {
		Message msg = new Message(
				type,
				_senderGUID,
				_senderGUID,
				_idSeed.toString() + "-" + messageCounter.toString(),
				_vectorClock.getNewTimeStamp());

		messageCounter++;

		return msg;
	}

	public static Message createMessage(Message oldMessage) {
		return new Message(_senderGUID, oldMessage);
	}
}
