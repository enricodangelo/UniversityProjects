/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class CardsBody implements IMessageBody{

	private Integer playerGUID;
	private Integer[] cards;

	public CardsBody(Integer playerGUID, Integer[] cards) {
		this.playerGUID = playerGUID;
		this.cards = cards;
	}

	public Integer getPlayerGUID() {
		return playerGUID;
	}

	public Integer[] getCards() {
		return cards;
	}

	@Override
	public String toString() {
		String string = "";

		string += "playerGUID = " + playerGUID;
		string += "\n";
		string += "cards = ";
		for (Integer cardID : cards) {
			string += cardID + " ";
		}

		return string;
	}
}
