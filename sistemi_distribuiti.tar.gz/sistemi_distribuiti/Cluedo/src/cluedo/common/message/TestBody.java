/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common.message;

/**
 * Corpo di un messaggio di test
 *
 * @author enrico
 */
public class TestBody implements IMessageBody {

	private String testMSG;

	public TestBody(String testMSG) {
		this.testMSG = testMSG;
	}

	public String getTestMSG() {
		return testMSG;
	}

	@Override
	public String toString() {
		String string = "";

		string += testMSG;

		return string;
	}
}
