/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class PositionBody implements IMessageBody {

	private Integer playerGUID;
	private Integer[] position;

	public PositionBody(Integer playerGUID, Integer[] position) {
		this.playerGUID = playerGUID;
		this.position = position;
	}

	public Integer getPlayerGUID() {
		return playerGUID;
	}

	public Integer[] getPosition() {
		return position;
	}

	@Override
	public String toString() {
		String string = "";

		string += "playerGUID: " + playerGUID;
		string += "\n";
		string += "position: " + position[0] + " " + position[1];

		return string;
	}
}
