/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;


/**
 *
 * @author enrico
 */
public class VectorClockIndexBody implements IMessageBody {

	private Integer index;

	public VectorClockIndexBody(Integer index) {
		this.index = index;
	}

	public int getIndex() {
		return index;
	}

	@Override
	public String toString() {
		String string = "";

		string += "index = " + index;

		return string;
	}
}
