/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class OutOfGameBody implements IMessageBody {

	private Integer outOfGamePlayerGUID;

	public OutOfGameBody(Integer winnerPlayerGUID) {
		this.outOfGamePlayerGUID = winnerPlayerGUID;
	}

	public Integer getOutOfGamePlayerGUID() {
		return outOfGamePlayerGUID;
	}
}
