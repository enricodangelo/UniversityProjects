/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class EnvelopeBody implements IMessageBody {

	private Integer[] envelope;

	public EnvelopeBody(Integer[] envelope) {
		this.envelope = envelope;
	}

	public Integer[] getEnvelope() {
		return envelope;
	}

	@Override
	public String toString() {
		String string = "";

		string += "envelope = ";
		for (Integer cardID : envelope) {
			string += cardID + " ";
		}
		string += "\n";

		return string;
	}
}
