/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class AccusationBody implements IMessageBody {

	private Integer playerGUID;
	private Boolean winTheGame;

	public AccusationBody(Integer playerGUID, Boolean winTheGame) {
		this.playerGUID = playerGUID;
		this.winTheGame = winTheGame;
	}

	public Integer getPlayerGUID() {
		return playerGUID;
	}

	public Boolean getWinTheGame() {
		return winTheGame;
	}

	@Override
	public String toString() {
		String string = "";

		string += "playerGUID: " + playerGUID;
		string += "\n";
		string += "winTheGame: " + winTheGame;

		return string;
	}
}
