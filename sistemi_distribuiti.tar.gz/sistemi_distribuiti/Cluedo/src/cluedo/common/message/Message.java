/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common.message;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author enrico
 */
public class Message implements Serializable {

	private MessageType type;
	private Integer senderGUID;
	private Integer originalSenderGUID;
	private Integer[] multicastGroup;	//se null significa che il messaggio e' singolo
	private String messageID;
	private Integer[] timestamp;
	private IMessageBody body;

	public IMessageBody getBody() {
		return body;
	}

	public void setBody(IMessageBody body) {
		this.body = body;
	}

	public MessageType getType() {
		return type;
	}

	public Integer getSenderGUID() {
		return senderGUID;
	}

	public Integer getOriginalSender() {
		return originalSenderGUID;
	}

	public Integer[] getMulticastGroup() {
		return multicastGroup;
	}

	public String getMessageID() {
		return messageID;
	}

	public Integer[] getTimestamp() {
		return timestamp;
	}

	public void setMulticastGroup(ArrayList<Integer> multicastGroup) {
		this.multicastGroup = multicastGroup.toArray(new Integer[0]);
	}

	protected Message(
			MessageType type,
			Integer senderGUID,
			Integer originalSenderGUID,
			String messageID,
			Integer[] timestamp,
			IMessageBody body) {
		this.type = type;
		this.senderGUID = senderGUID;
		this.originalSenderGUID = originalSenderGUID;
		this.messageID = messageID;
		this.timestamp = timestamp;
		this.body = body;
	}

	protected Message(
			MessageType type,
			Integer senderGUID,
			Integer originalSenderGUID,
			String messageID,
			Integer[] timestamp) {
		this.type = type;
		this.senderGUID = senderGUID;
		this.originalSenderGUID = originalSenderGUID;
		this.messageID = messageID;
		this.timestamp = timestamp;
	}

	protected Message(Integer senderGUID, Message oldMessage) {
		this.type = oldMessage.type;
		this.senderGUID = senderGUID;
		originalSenderGUID = oldMessage.getOriginalSender();
		multicastGroup = oldMessage.getMulticastGroup();
		messageID = oldMessage.getMessageID();
		timestamp = oldMessage.getTimestamp();
		body = oldMessage.body;
	}

	@Override
	public String toString() {
		String string = "";

		string += "\n";
		string += "MessageType: " + type;
		string += "\n";
		string += "Sender: " + senderGUID + "\n";
		string += "OriginalSender: " + originalSenderGUID + "\n";
		if (multicastGroup != null) {
			string += "Multicast group: ";
			for (Integer guid : multicastGroup) {
				string += guid + " ";
			}
		}
		string += "\n";
		string += "id: " + messageID + "\n";
		string += "timestamp: ";
		for (int i = 0; i < timestamp.length; i++) {
			if (i == 0) {
				string += "[";
			}
			string += timestamp[i];
			if (i != timestamp.length - 1) {
				string += ",";
			}
			if (i == timestamp.length - 1) {
				string += "]";
			}
		}
		string += "\n";
		string += "\n";
		if (body != null) {
			string += body.toString();
			string += "\n";
		}

		return string;
	}
}
