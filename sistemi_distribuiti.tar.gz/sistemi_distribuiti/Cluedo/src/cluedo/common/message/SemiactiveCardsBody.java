/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common.message;

/**
 *
 * @author enrico
 */
public class SemiactiveCardsBody implements IMessageBody {

	private Integer[] semiActiveCards;

	public SemiactiveCardsBody(Integer[] semiActiveCards) {
		this.semiActiveCards = semiActiveCards;
	}

	public Integer[] getSemiActiveCards() {
		return semiActiveCards;
	}
}
