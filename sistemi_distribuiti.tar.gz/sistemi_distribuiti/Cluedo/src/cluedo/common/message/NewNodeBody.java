/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common.message;

import cluedo.game.IRemotePlayer;

/**
 * Corpo di un messaggio che avvisa dell'inserimento di un nuovo nodo
 *
 * @author enrico
 */
public class NewNodeBody implements IMessageBody {

	private String newNodeName;
	private Integer newNodeGUID;
	private IRemotePlayer newNode;
	private Integer vectorClockIndex;

	public NewNodeBody(String newNodeName, Integer newNodeGUID, IRemotePlayer newNode, Integer vectorClockIndex) {
		this.newNodeName = newNodeName;
		this.newNodeGUID = newNodeGUID;
		this.newNode = newNode;
		this.vectorClockIndex = vectorClockIndex;
	}

	public String getNewNodeName() {
		return newNodeName;
	}
	
	public IRemotePlayer getNewNode() {
		return newNode;
	}

	public Integer getNewNodeGUID() {
		return newNodeGUID;
	}

	public Integer getVectorClockIndex() {
		return vectorClockIndex;
	}

	@Override
	public String toString() {
		String string = "";

		string += "newNodeGUID = " + newNodeGUID;
		string += "\n";
		string += "vectorClockIndex = " + vectorClockIndex;

		return string;
	}
}
