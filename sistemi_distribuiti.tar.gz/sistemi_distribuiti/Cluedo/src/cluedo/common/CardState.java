/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common;

/**
 * Questa enum rappresenta gli stati che puo' assumere una carta.
 * Le carte sono usate anche al posto del classico block notes della versione
 * da tavolo del gioco, percio' gli stati indicano anche il livello
 * d'informazione che possediamo sulla soluzione.
 * 
 * @author enrico
 */
public enum CardState {

	/* non abbiamo alcuna informazione su questa carta */
	ACTIVE,
	/* la carta non fa certamente parte della soluzione */
	INACTIVE,
	/* la carta potrebbe non fare parte della soluzione. Faceva parte di un
	   sospetto o di un accusa sbagliati */
	SEMIACTIVE,
	/* la carta e' stata selezionata come facente parte di un'accusa o di
	   un sospetto*/
	SELECTED;
}
