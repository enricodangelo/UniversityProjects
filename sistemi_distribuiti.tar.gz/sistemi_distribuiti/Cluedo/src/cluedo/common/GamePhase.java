/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cluedo.common;

/**
 * Questa enum rappresenta tutti gli stati di gioco.
 *
 * Numerando gli enum abbiamo:
 * REGISTRATION = 1
 * CHARACTER_SELECTION = 2
 * GAME_INITIALIZATION = 3
 * NOT_IN_TURN = 4
 * IN_TURN = 5
 * RESTART = 6
 * e il grafo delle transizioni di stato e' (1 indica che dallo stato indicato
 * dalla riga posso passare allo stato indicato dalla colonna):
 *
 *   1|2|3|4|5|6|
 * --------------
 * 1|1|1| | | | |
 * --------------
 * 2| |1|1| | | |
 * --------------
 * 3| | |1|1|1| |
 * --------------
 * 4| | | |1|1|1|
 * --------------
 * 5| | | |1|1|1|
 * --------------
 * 6|1| | | | | |
 * --------------
 *
 * @author enrico
 */
public enum GamePhase {
	/* fase di registrazione al gioco. Quando i giocatori formano la rete */
	REGISTRATION,
	/* fase di selezione del personaggio */
	CHARACTER_SELECTION,
	/* fase di selezione dei turni di gioco, della soluzione e delle carte
	   dei giocatori*/
	GAME_INITIALIZATION,
	/* giocatore non in turno */
	NOT_IN_TURN,
	/* giocatore in turno */
	IN_TURN,
	/* il gioco e' terminato, si puo' ricominciare da capo o chiudere */
	RESTART;
}
