/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common;

/**
 * Questa classe calcola la distanza Manhattan, o Chess distance, cioe' la
 * distanza in caselle tra due caselle.
 * 
 * @author enrico
 */
public class ManhattanDistance {

	public static int calculate(Integer[] firstCell, Integer[] secondCell) {
		int result = 0;

		for (int i = 0; i < firstCell.length; i++) {
			result += Math.abs(firstCell[i] - secondCell[i]);
		}

		return result;
	}
}
