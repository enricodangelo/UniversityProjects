/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common;

import cluedo.game.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;

/**
 * Questa classe contiene tutte le informazioni, sono necessarie alla logica
 * del gioco,  relative ad un giocatore.
 *
 * @author enrico
 */
public class PlayerData implements Serializable {

	/* il nome del giocatore */
	private final String name;
	/* il global unique identifier del giocatore */
	private final Integer guid;
	/* il riferimento remoto del giocatore */
	private IRemotePlayer remoteInterface;
	/* l'indice del vector clock usato dal giocatore */
	private Integer vectorClockIndex;
	/* il personaggio scelto dal giocatore */
	private Integer character;
	/* il turno di gioco del giocatore.
	 Tutti i giocatori sono totalmente ordinati in base a questo valore */
	private Integer playTurn;
	/* le carte scelte dal giocatore nella partita che sta giocando */
	private ArrayList<Integer> cards;
	/* mantiene per ogni altro giocatore l'elenco di carte mostrategli in luogo di un sospetto sbagliato */
	private Map<Integer, ArrayList<Integer>> revealedCards;

	private Boolean inGame;

	public PlayerData(String name, Integer guid, IRemotePlayer remoteInterface) {
		this.name = name;
		this.guid = guid;
		this.remoteInterface = remoteInterface;
		vectorClockIndex = null;
		character = null;
		playTurn = null;
		cards = new ArrayList<Integer>();
		revealedCards = new Hashtable<Integer, ArrayList<Integer>>();
		inGame = true;
	}

	public PlayerData(String name, Integer guid, IRemotePlayer remotePlayer, Integer vectorClockIndex, Boolean inGame) {
		this(name, guid, remotePlayer);
		this.vectorClockIndex = vectorClockIndex;
		this.inGame = inGame;
	}

	public void resetPlayerData() {
		character = null;
		playTurn = null;
		cards = new ArrayList<Integer>();
		revealedCards = new Hashtable<Integer, ArrayList<Integer>>();
		inGame = true;
	}

	public String getName() {
		return name;
	}

	public Integer getGUID() {
		return guid;
	}

	public IRemotePlayer getRemoteInterface() {
		return remoteInterface;
	}

	public void setVectorClockIndex(Integer vectorClockIndex) {
		this.vectorClockIndex = vectorClockIndex;
	}

	public Integer getVectorClockIndex() {
		return vectorClockIndex;
	}

	public void setCharacter(Integer character) {
		this.character = character;
	}

	public Integer getCharacter() {
		return character;
	}

	public Integer getPlayTurn() {
		return playTurn;
	}

	public void setPlayTurn(Integer playTurn) {
		this.playTurn = playTurn;
	}

	public void addCards(ArrayList<Integer> cards) {
		this.cards.addAll(cards);
	}

	public ArrayList<Integer> getCards() {
		return cards;
	}

	public void addRevealedCard(Integer playerGUID, Integer cardID) {
		ArrayList<Integer> revealeCardForPlayer = revealedCards.get(playerGUID);

		if (revealeCardForPlayer == null) {
			revealedCards.put(playerGUID, new ArrayList<Integer>());
		}

		revealedCards.get(playerGUID).add(cardID);
	}

	public ArrayList<Integer> getRevealedCardsTo(Integer playerGUID) {
		return revealedCards.get(playerGUID);
	}

	public Boolean isInGame() {
		return inGame;
	}

	public void setNotInGame() {
		inGame = false;
	}

	@Override
	public String toString() {
		String string = "";

		string += "name: " + name;
		string += "\n";
		string += "guid: " + guid;
		string += "\n";
		if (vectorClockIndex != null) {
			string += "vectorClockIndex: " + vectorClockIndex;
			string += "\n";
		}
		if (character != null) {
			string += "character: " + character;
			string += "\n";
		}
		if (playTurn != null) {
			string += "playTurn: " + playTurn;
			string += "\n";
		}
		if (cards != null) {
			string += "cards: " + cards;
			string += "\n";
		}
		for (Integer otherPlayerGUID : revealedCards.keySet()) {
			string += "revealedCards to " + otherPlayerGUID + ": ";
			for (Integer cardID : revealedCards.get(otherPlayerGUID)) {
				string += cardID + " ";
			}
			string += "\n";
		}
		if (inGame) {
			string += "in game";
			string += "\n";
		} else {
			string += "not in game";
			string += "\n";
		}

		return string;
	}
}
