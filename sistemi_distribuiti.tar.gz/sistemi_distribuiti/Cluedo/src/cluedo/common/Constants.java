/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cluedo.common;

import java.awt.Color;
import java.awt.Font;

/**
 * Questa classe contiene tutte le costanti utilizzate nel codice
 *
 * @author enrico
 */
public class Constants {
	public static final int MIN_NETWORK_SIZE = 3;
	public static final int MAX_NETWORK_SIZE = 6;
	public static final int POLLING_INTERVAL_SECONDS = 10;
	public static final int ENVELOPE_SIZE = 3;
	public static final int NUMBER_OF_CHARACTERS = 6;
	public static final int NUMBER_OF_ROOMS = 9;
	public static final int NUMBER_OF_WEAOPONS = 6;
	public static final int CHARACTERS_OFFSET = 0;
	public static final int ROOMS_OFFSET = NUMBER_OF_CHARACTERS;
	public static final int WEAPONS_OFFSET = ROOMS_OFFSET + NUMBER_OF_ROOMS;
	public static final int CHARACTERS_LIMIT = CHARACTERS_OFFSET + NUMBER_OF_CHARACTERS;
	public static final int ROOMS_LIMIT = ROOMS_OFFSET + NUMBER_OF_ROOMS;
	public static final int WEAPONS_LIMIT = WEAPONS_OFFSET + NUMBER_OF_WEAOPONS;
	public static final int TOTAL_NUMBER_OF_CARDS = NUMBER_OF_CHARACTERS + NUMBER_OF_ROOMS + NUMBER_OF_WEAOPONS;
	public static final int NUMBER_OF_CARDS_IN_ENVELOPE = 3;

	public static final String RESOURCE_DIR = "/cluedo/resources/";
	public static final String[] CHARACTER_FILENAME = {
		"colonel_mustard.jpeg",
		"miss_scarlett.jpeg",
		"mr_green.jpeg",
		"mrs_peacock.jpeg",
		"mrs_white.jpeg",
		"professor_plum.jpeg"};
	public static final String[] WEAPON_FILENAME = {
		"candlestick.jpeg",
		"knife.jpeg",
		"lead_pipe.jpeg",
		"revolver.jpeg",
		"rope.jpeg",
		"wrench.jpeg"};
	public static final String[] ROOM_FILENAME = {
		"ballroom.jpeg",
		"billiard_room.jpeg",
		"conservatory.jpeg",
		"dining_room.jpeg",
		"hall.jpeg",
		"kitchen.jpeg",
		"library.jpeg",
		"lounge.jpeg",
		"study.jpeg"};
	public static final String[] CHARACTER_SELECTED_FILENAME = {
		"colonel_mustard-selected.jpeg",
		"miss_scarlett-selected.jpeg",
		"mr_green-selected.jpeg",
		"mrs_peacock-selected.jpeg",
		"mrs_white-selected.jpeg",
		"professor_plum-selected.jpeg"};
	public static final String[] WEAPON_SELECTED_FILENAME = {
		"candlestick-selected.jpeg",
		"knife-selected.jpeg",
		"lead_pipe-selected.jpeg",
		"revolver-selected.jpeg",
		"rope-selected.jpeg",
		"wrench-selected.jpeg"};
	public static final String[] ROOM_SELECTED_FILENAME = {
		"ballroom-selected.jpeg",
		"billiard_room-selected.jpeg",
		"conservatory-selected.jpeg",
		"dining_room-selected.jpeg",
		"hall-selected.jpeg",
		"kitchen-selected.jpeg",
		"library-selected.jpeg",
		"lounge-selected.jpeg",
		"study-selected.jpeg"};
	public static final String[] CHARACTER_SEMIACTIVE_FILENAME = {
		"colonel_mustard-semiactive.jpeg",
		"miss_scarlett-semiactive.jpeg",
		"mr_green-semiactive.jpeg",
		"mrs_peacock-semiactive.jpeg",
		"mrs_white-semiactive.jpeg",
		"professor_plum-semiactive.jpeg"};
	public static final String[] WEAPON_SEMIACTIVE_FILENAME = {
		"candlestick-semiactive.jpeg",
		"knife-semiactive.jpeg",
		"lead_pipe-semiactive.jpeg",
		"revolver-semiactive.jpeg",
		"rope-semiactive.jpeg",
		"wrench-semiactive.jpeg"};
	public static final String[] ROOM_SEMIACTIVE_FILENAME = {
		"ballroom-semiactive.jpeg",
		"billiard_room-semiactive.jpeg",
		"conservatory-semiactive.jpeg",
		"dining_room-semiactive.jpeg",
		"hall-semiactive.jpeg",
		"kitchen-semiactive.jpeg",
		"library-semiactive.jpeg",
		"lounge-semiactive.jpeg",
		"study-semiactive.jpeg"};
	public static final String CARD_BACK_FILENAME = "back.jpeg";
	public static final String[] CHARACTER_NAME = {
		"Colonel Mustard",
		"Miss. Scarlett",
		"Mr. Green",
		"Mrs. Peacock",
		"Mrs. White",
		"Professor Plum"};
	public static final Color[] CHARACTER_COLORS = {
		new Color(217, 192, 30, 255),
		new Color(213, 27, 20, 255),
		new Color(59, 110, 25, 255),
		new Color(33, 102, 151, 255),
		new Color(222, 204, 180, 255),
		new Color(83, 17, 60, 255)};
	public static final String[] WEAPON_NAME = {
		"Candelabro",
		"Pugnale",
		"Spranga",
		"Rivoltella",
		"Fune",
		"Chiave Inglese"};
	public static final String[] ROOM_NAME = {
		"Sala da Ballo",
		"Sala da Biliardo",
		"Veranda",
		"Sala da Pranzo",
		"Ingresso",
		"Cucina",
		"Biblioteca",
		"Salotto",
		"Studio"};
	public static final int X = 0;
	public static final int Y = 1;
	public static final Integer[][] STARTING_POINT_POSITION = {
		{0, 17},
		{7, 24},
		{14, 0},
		{23, 6},
		{9, 0},
		{23, 19}};
	public static final Color BOARD_CELL_COLOR = new Color(235, 221, 66, 255);
	public static final Color BOARD_STARTING_POINT_COLOR = new Color(0, 0, 0, 255);
	public static final Color[] BOARD_STARTING_POINT_COLORS = {
		CHARACTER_COLORS[0],
		CHARACTER_COLORS[1],
		CHARACTER_COLORS[2],
		CHARACTER_COLORS[3],
		CHARACTER_COLORS[4],
		CHARACTER_COLORS[5]};
	public static final Color ROOMS_COLOR = new Color(168, 168, 168, 255);
	public static final Color DOORS_COLOR = new Color(117, 80, 25, 255);
	public static final int[][] ROOM_UPPERLEFT_CORNER = {
		{8, 1},
		{18, 8},
		{18, 1},
		{0, 9},
		{9, 18},
		{0, 1},
		{17, 14},
		{0, 19},
		{17, 21}};
	public static final int[][] ROOM_LOWERRIGHT_CORNER = {
		{15, 7},
		{23, 12},
		{23, 5},
		{7, 15},
		{14, 24},
		{5, 6},
		{23, 18},
		{6, 24},
		{23, 24}};
	/* Le porte sono codificate con le coordinete delle due caselle interessate.
	 L'array DOOR contiene le porte ordinate secondo le stanze di appartenenza,
	 un array di porte per ogni stanza */
	public static final int[][][] DOORS = {
		{{7, 5, 8, 5},{9, 7, 9, 8},{14, 7, 14, 8},{15, 5, 16, 5}},
		{{17, 9, 18, 9}},
		{{18, 5, 18, 6}},
		{{6, 15, 6, 16},{7, 12, 8, 12}},
		{{11, 17, 11, 18},{12, 17, 12, 18},{14, 20, 15, 20}},
		{{4, 6, 4, 7}},
		{{16, 16, 17, 16},{20, 13, 20, 14},{22, 13, 22, 14}},
		{{6, 18, 6, 19}},
		{{17, 20, 17, 21}}};
	public static final int DOOR_SIZE = 6;
	public static final Color TOOLTIP_BACKGROUND_COLOR = new Color(46, 46, 46, 153);
	public static final Color TOOLTIP_FOREGROUND_COLOR = new Color(230, 230, 230);
	public static final Font TOOLTIP_FONT = new Font(Font.SANS_SERIF, Font.PLAIN, 20);
	//
	public static final String REMOTEPLAYER_BINDING_NAME = "Player";
	//
	public static final String APP_NAME = "Cluedo";
	//
	public static final int CARD_COLUMNS = 6;
	public static final int CARD_HEIGHT = 135;
	public static final int CARD_WIDTH = 90;
	public static final Color CARD_SELECTED_COLOR = new Color(232, 183, 216, 200);
	public static final Color CARD_SEMIACTIVE_COLOR = new Color(85, 85, 85, 200);
	public static final int APP_HEIGHT = 5 * CARD_HEIGHT;
	public static final int APP_WIDTH = 15 * CARD_WIDTH;
	//
	public static final String DICE_BUTTON_LABEL = "Tira il dado";
	public static final String SUSPECT_BUTTON_LABEL = "Io sospetto...";
	public static final String ACCUSE_BUTTON_LABEL = "Io accuso...";
	public static final String ENDTURN_BUTTON_LABEL = "Fine turno";
	//
	public static final String REGISTRATION_TITLE_LABEL = "Registrazione alla rete...";
	public static final String REGISTRATION_LABEL = "Giocatori presenti: ";
	public static final String REGISTRATION_FINISH_LABEL = "Premere INVIO per scegliere i personaggi (min " + MIN_NETWORK_SIZE + " giocatori)";
	public static final Font REGISTRATION_FONT_VERYBIG = new Font(Font.SANS_SERIF, Font.BOLD, 80);
	public static final Font REGISTRATION_FONT_BIG = new Font(Font.SANS_SERIF, Font.BOLD, 50);
	public static final Font REGISTRATION_FONT_MEDIUM = new Font(Font.SANS_SERIF, Font.PLAIN, 30);
	public static final Font REGISTRATION_FONT_SMALL = new Font(Font.SANS_SERIF, Font.PLAIN, 20);
	public static final Color REGISTRATION_BACKGROUND_COLOR = new Color(51, 51, 51, 255);
	public static final Color REGISTRATION_FOREGROUND_COLOR = new Color(230, 230, 230, 255);
	public static final Color REGISTRATION_NUMBEROFPLAYERS_COLOR = new Color(0, 188, 255, 255);
	//
	public static final String CHARACTER_SELECTION_TITLE_LABEL = "Scegli il tuo personaggio:";
	public static final Color CHARACTER_SELECTION_BACKGROUND_COLOR = REGISTRATION_BACKGROUND_COLOR;
	public static final Color CHARACTER_SELECTION_FOREGROUND_COLOR = REGISTRATION_FOREGROUND_COLOR;
	public static final Color CHARACTER_SELECTION_CHARACTER_NAME_COLOR = REGISTRATION_NUMBEROFPLAYERS_COLOR;
	public static final Font CHARACTER_SELECTION_FONT_BIG = new Font(Font.SANS_SERIF, Font.BOLD, 46);
	public static final Font CHARACTER_SELECTION_FONT_SMALL = new Font(Font.SANS_SERIF, Font.PLAIN, 24);
	public static final int CHARACTER_SELECTION_ARCWIDTH = 30;
	public static final int CHARACTER_SELECTION_ARCHEIGHT = 30;
	public static final int CHARACTER_SELECTION_SPACE = 15;
	public static final int CHARACTER_SELECTION_COLUMNS = 3;
	//
	public static final String INITIALIZATION_LABEL = "Premere INVIO per inizializzare ed iniziare una partita.";
	public static final Font INITIALIZATION_FONT = new Font(Font.SANS_SERIF, Font.PLAIN, 20);
	public static final Color INITIALIZATION_BACKGROUND_COLOR = REGISTRATION_BACKGROUND_COLOR;
	public static final Color INITIALIZATION_FOREGROUND_COLOR = REGISTRATION_FOREGROUND_COLOR;
	//
	public static final int BOARD_HEIGHT = 4 * CARD_HEIGHT;
	public static final int BOARD_WIDTH = 9 * CARD_WIDTH;
	public static final int BOARD_ROWS = 25;
	public static final int BOARD_COLUMNS = 24;
	public static final int BOARD_GAP = 20;
	public static final Color BOARD_BACKGROUND_COLOR = REGISTRATION_BACKGROUND_COLOR;
	public static final Color BOARD_FOREGROUND_COLOR = REGISTRATION_FOREGROUND_COLOR;
	public static final String BOARD_LABEL = "Chi ha ucciso Mr. Black?";
	public static final Font BOARD_FONT_BIG = new Font(Font.SANS_SERIF, Font.PLAIN, 20);
	public static final Font BOARD_FONT_SMALL = new Font(Font.SANS_SERIF, Font.BOLD, 14);
	public static final Color BOARD_AVAILABLE_CELL_MY_TURN_BACKGROUNG_COLOR = new Color(85, 85, 85, 255);
	public static final Color BOARD_AVAILABLE_CELL_MY_TURN_FOREGROUNG_COLOR = new Color(238, 238, 238, 255);
	public static final Color BOARD_AVAILABLE_CELL_NOT_MY_TURN_BACKGROUNG_COLOR = new Color(100, 100, 100, 255);
	public static final Color BOARD_AVAILABLE_CELL_NOT_MY_TURN_FOREGROUNG_COLOR = new Color(200, 200, 200, 200);
	//
	public static final String RESTART_WINNER_LABEL = "HAI VINTO LA PARTITA!";
	public static final String RESTART_NOT_WINNER_LABEL = "HA VINTO LA PARTITA!";
	public static final String RESTART_RESTART_LABEL = "Premere INVIO per iniziare una nuova partita.";
	public static final Font RESTART_FONT_BIG = new Font(Font.SANS_SERIF, Font.BOLD, 50);
	public static final Font RESTART_FONT_SMALL = new Font(Font.SANS_SERIF, Font.PLAIN, 20);
	public static final Font RESTART_FONT_VERYBIG = new Font(Font.SANS_SERIF, Font.BOLD, 80);
	public static final Color RESTART_BACKGROUND_COLOR = REGISTRATION_BACKGROUND_COLOR;
	public static final Color RESTART_RESTART_FOREGROUND_COLOR = REGISTRATION_FOREGROUND_COLOR;
	public static final Color RESTART_FOREGROUND_COLOR = new Color(255, 255, 0, 255);
	public static final Color RESTART_WINNER_FOREGROUND_COLOR = new Color(0, 188, 255, 255);
	//
	public static final String BLOCKNOTES_CHARACTERS_LABEL = "Personaggi";
	public static final String BLOCKNOTES_ROOMS_LABEL = "Stanze";
	public static final String BLOCKNOTES_WEAPONS_LABEL = "Armi del delitto";
}
