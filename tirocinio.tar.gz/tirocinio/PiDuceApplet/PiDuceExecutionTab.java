import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.border.*;
import java.util.regex.*;

public class PiDuceExecutionTab extends Box {

	JButton openButton = new JButton("Open File");
	JButton saveButton = new JButton("Save file as...");
	JButton executeButton = new JButton("Execute");
	JButton saveLogButton = new JButton("Save log as...");
	JLabel logLevelComboBoxLabel = new JLabel("Log Level:");

	String[] logLevelComboBoxItems = { "0", "1", "2", "3" };
	JComboBox logLevelComboBox = new JComboBox(logLevelComboBoxItems);
	JLabel compilerHostnameLabel = new JLabel("Hostname");

	String ipAddress;
	JTextArea compilerHostname = new JTextArea(1, 15);
	JLabel compilerPortLabel = new JLabel("Port");
	JTextArea compilerPort = new JTextArea("2057", 1, 6);
	JLabel machineHostnameLabel = new JLabel("Hostname");

	String hostname;
	JTextArea machineHostname = new JTextArea(1, 15);
	JLabel machinePortLabel = new JLabel("Port");
	JTextArea machinePort = new JTextArea("2047", 1, 6);
	Border compilerBorder = BorderFactory
		.createTitledBorder("PiDuceCompiler informations");

	Border machineBorder = BorderFactory
		.createTitledBorder("PiDuceMachine informations");

	JTextArea sourceTextArea = new JTextArea(20, 60);

	JTextArea bytecodeTextArea = new JTextArea(20, 60);

	JScrollPane sourceScrollPane = new JScrollPane(sourceTextArea);

	JScrollPane bytecodeScrollPane = new JScrollPane(bytecodeTextArea);

	PiDuceTabbedTA programTabArea = new PiDuceTabbedTA(
		sourceScrollPane,
		bytecodeScrollPane);

	JTextArea logTextArea = new JTextArea(20, 60);

	JScrollPane logScrollPane = new JScrollPane(logTextArea);

	JFileChooser chooser = new JFileChooser();

	PiDuceFileFilter defaultFilter = new PiDuceFileFilter("", "All files");

	PiDuceFileFilter sourceFilter = new PiDuceFileFilter(
		".bopi",
		"PiDuce source program *.bopi");

	PiDuceFileFilter bytecodeFilter = new PiDuceFileFilter(
		".bopi.xml",
		"PiDuce bytecode program *.bopi.xml");

	JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

	JPanel compilerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

	JPanel machinePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

	JPanel informationsPanel = new JPanel(new BorderLayout());

	JPanel bottomPanelRight = new JPanel(new FlowLayout(FlowLayout.RIGHT));

	JPanel bottomPanelLeft = new JPanel(new FlowLayout(FlowLayout.LEFT));

	JPanel bottomPanel = new JPanel(new BorderLayout());

	File file;
	
	PiDuceExecutionTab() {
		super(BoxLayout.Y_AXIS);

		try
		{			
			file = File.createTempFile("PiDuceApplet", ".bopi");
			file.deleteOnExit();
			
			machineHostname.setText("pinot.students.cs.unibo.it");
			compilerHostname.setText("pinot.students.cs.unibo.it");
			
			OpenListener openListener = new OpenListener(this);
			SaveListener saveListener = new SaveListener(this.chooser, this.file, this.programTabArea, this.sourceTextArea, this.bytecodeTextArea);
			SaveListener saveLogListener = new SaveListener(this.chooser, this.file, this.logTextArea);
			ExecuteStopListener executeStopListener = new ExecuteStopListener(this);
			
			bytecodeTextArea.setEditable(false);
			
			logTextArea.setEditable(false);
			
			openButton.addActionListener(openListener);
			saveButton.addActionListener(saveListener);
			saveLogButton.addActionListener(saveLogListener);
			executeButton.addActionListener(executeStopListener);
		
			topPanel.add(openButton);
			topPanel.add(saveButton);			
			
			compilerPanel.add(compilerHostnameLabel);
			compilerPanel.add(compilerHostname);
			compilerPanel.add(compilerPortLabel);
			compilerPanel.add(compilerPort);
			compilerPanel.setBorder(compilerBorder);
			
			machinePanel.add(machineHostnameLabel);
			machinePanel.add(machineHostname);
			machinePanel.add(machinePortLabel);
			machinePanel.add(machinePort);
			machinePanel.setBorder(machineBorder);

			informationsPanel.add(compilerPanel, BorderLayout.WEST);
			informationsPanel.add(machinePanel, BorderLayout.EAST);

			bottomPanelLeft.add(saveLogButton);
			
			bottomPanelRight.add(logLevelComboBoxLabel);
			bottomPanelRight.add(logLevelComboBox);
			bottomPanelRight.add(executeButton);

			bottomPanel.add(bottomPanelLeft, BorderLayout.WEST);
			bottomPanel.add(bottomPanelRight, BorderLayout.EAST);
			
			add(topPanel);
			add(programTabArea);
			add(informationsPanel);
			add(bottomPanel);
			add(logScrollPane);
		}
		catch (Exception e) {System.out.println(e);e.printStackTrace();}	
	}
	

	class PiDuceTabbedTA extends JTabbedPane {

		PiDuceTabbedTA(JScrollPane sourceTab, JScrollPane bytecodeTab) {
			super(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
						
			addTab("Source", sourceTab);
			addTab("Bytecode", bytecodeTab);
			setSelectedIndex(0);
		}
		
	}
	
	class OpenListener implements ActionListener {
		JFileChooser chooser;
		JTextArea sourceTextArea;
		JTextArea bytecodeTextArea;
		JTextArea logTextArea;
		JTextArea textArea;
		JTextArea otherTextArea;
		File file;
		
		OpenListener(PiDuceExecutionTab parent) {
			this.chooser = parent.chooser;
			this.sourceTextArea = parent.sourceTextArea;
			this.bytecodeTextArea = parent.bytecodeTextArea;
			this.logTextArea = parent.logTextArea;
			this.file = parent.file;
		}
		
		public void actionPerformed(ActionEvent e) {
			int result;
			String line;

			if (programTabArea.getSelectedIndex() == 0) {
				chooser.setFileFilter(sourceFilter);
				textArea = sourceTextArea;
				otherTextArea = bytecodeTextArea;
			}
			else if (programTabArea.getSelectedIndex() == 1) {
				chooser.setFileFilter(bytecodeFilter);
				textArea = bytecodeTextArea;
				otherTextArea = sourceTextArea;
			}
			
			if (chooser.showOpenDialog(textArea) == JFileChooser.APPROVE_OPTION) {
				file = chooser.getSelectedFile();
				if (file.canRead()) {
					try {
						BufferedReader reader = new BufferedReader(new FileReader(file.toString()));
						textArea.setText("");
						otherTextArea.setText("");
						logTextArea.setText("");
						while ((line = reader.readLine()) != null) {
							textArea.append(line + "\n");
						}
						reader.close();
					} catch (Exception ex) {System.out.println(ex);ex.printStackTrace();}
				}
			}
		}
	}

	class SaveListener implements ActionListener {
		JFileChooser chooser;
		JTextArea sourceTA = null;
		JTextArea bytecodeTA = null;

		PiDuceTabbedTA tabbedTA = null;

		JTextArea source = null;
		File file;
		
		SaveListener (JFileChooser chooser, File file, JTextArea textArea) {
			this.chooser = chooser;
			this.sourceTA = textArea;
			this.file = file;
		}
		
		SaveListener (JFileChooser chooser, File file, PiDuceTabbedTA tabbedTA, JTextArea sourceTA, JTextArea bytecodeTA) {
			try {
				this.chooser = chooser;
				this.tabbedTA = tabbedTA;
				this.sourceTA = sourceTA;
				this.bytecodeTA = bytecodeTA;
				this.file = file;
			}
			catch (Exception e) {System.out.println(e);e.printStackTrace();} 
		}
		
		public void actionPerformed(ActionEvent e) {
			
			if (e.getActionCommand() == "Save log as...") {
				chooser.setFileFilter(defaultFilter);
				source = this.sourceTA;
			}
			else if ((e.getActionCommand() == "Save file as...") && (tabbedTA.getSelectedIndex() == 0)) {
				chooser.setFileFilter(sourceFilter);
				source = sourceTA;
			}
			else if ((e.getActionCommand() == "Save file as...") && (tabbedTA.getSelectedIndex() == 1)) {
				chooser.setFileFilter(bytecodeFilter);
				source = bytecodeTA;
			}
			
			if (chooser.showSaveDialog(source) == JFileChooser.APPROVE_OPTION) {
				try
				{	
					file = chooser.getSelectedFile();
					file.createNewFile();
					saveFile();
				}
				catch (Exception ex) {System.out.println(ex);ex.printStackTrace();}
			}
		}
		
		void saveFile()
		{
			PrintWriter writer;

			if (file.canWrite()) {
				try {
					writer = new PrintWriter(new FileWriter(file));
					writer.print(source.getText() + "\n");
					writer.close();
				} catch (Exception e) {System.out.println(e);e.printStackTrace();}
			}
		}
	}

	class ExecuteStopListener implements ActionListener {

		PiDuceExecutionTab source;

		JTextArea sourceTextArea;
		JTextArea logTextArea;
		JTextArea bytecodeTextArea;
		File file;
		ServerSocket outputListener;
		ServerSocket logListener;
		int THREADS = 3;
		Thread[] lastThreads = new Thread[THREADS];
		
		ExecuteStopListener(PiDuceExecutionTab source)
		{
			this.source = source;
			this.sourceTextArea = source.sourceTextArea;
			this.logTextArea = source.logTextArea;
			this.bytecodeTextArea = source.bytecodeTextArea;
			this.file = source.file;
			try
			{
				outputListener = new ServerSocket(0);
				logListener = new ServerSocket(0);
			}
			catch (Exception e) {System.out.println(e);e.printStackTrace();}
		}
		
		public void actionPerformed(ActionEvent event) {
			saveFile();
			
			logTextArea.setText("");
			bytecodeTextArea.setText("");

			lastThreads[0] = new Thread(new ReadLog(logListener, source), "ReadLog Thread");
			lastThreads[1] = new Thread(new ReadCompilerOutput(outputListener, source, lastThreads[0]), "ReadCompilerOutput Thread");
			lastThreads[2] = new Thread(new SendSource(outputListener, logListener, source), "SendSource Thread");
			for (int i = 0; i < THREADS; i++) {
				lastThreads[i].start();
			}
		}

		void saveFile()
		{
			PrintWriter writer;

			if (file.canWrite()) {
				try {
					writer = new PrintWriter(new FileWriter(file));
					writer.print(sourceTextArea.getText() + "\n");
					writer.close();
				} catch (Exception e) {System.out.println(e);e.printStackTrace();}
			}
		}
		
		class ReadCompilerOutput implements Runnable {
			ServerSocket listener;
			JTextArea bytecodeTextArea;
			JTextArea logTextArea;
			String messages[] = {"Sending compiled to http://" + machineHostname.getText().trim() + ":" + machinePort.getText().trim(),
				"Success sending compiled to http://" + machineHostname.getText().trim() + ":" + machinePort.getText().trim()};
			String warning = "(.*)(warning)(.*)";
			
			ReadCompilerOutput (ServerSocket listener, PiDuceExecutionTab source, Thread logThread) {
				this.listener = listener;
				this.bytecodeTextArea = source.bytecodeTextArea;
				this.logTextArea = source.logTextArea;
			}
			
			public void run() {
				try {
					Socket socket = listener.accept();
					BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
					String line;

					//Discarding useless messages
					do {
						line = in.readLine();
					}
					while ((line != null) &&
						((line.trim().compareTo(messages[0]) == 0) ||
						(line.trim().compareTo(messages[1]) == 0) ||
						(line.matches(warning))));

					if ((line != null) && (line.compareTo("") != 0)) {
						logTextArea.setText("");
						
						while (line != null)
						{
							logTextArea.append(line + "\n");
							line = in.readLine();
						}
					}
				}
				catch (Exception e) {System.out.println(e);e.printStackTrace();}
			}
		}
		
		class ReadLog implements Runnable {
			ServerSocket listener;
			JTextArea logTextArea;
			JTextArea bytecodeTextArea;
			String bytecodeDelimiter = "END BYTECODE";
			
			ReadLog(ServerSocket listener, PiDuceExecutionTab source) {
				this.listener = listener;
				this.logTextArea = source.logTextArea;
				this.bytecodeTextArea = source.bytecodeTextArea;
			}
			
			public void run() {
				try
				{
					Socket socket = listener.accept();
					BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
					String line;

					logTextArea.setText("");
					bytecodeTextArea.setText("");

					//Reading ByteCode
					while ((line = in.readLine()).trim().compareTo(bytecodeDelimiter) != 0)
					{
						bytecodeTextArea.append(line + "\n");
					}
					
					//Reading log messages
					while ((line = in.readLine()) != null) {
						logTextArea.append(line + "\n");
					}
				}
				catch (Exception e) {System.out.println(e);e.printStackTrace();}
			}
		}
		
		class SendSource implements Runnable {
			ServerSocket outputListener;
			ServerSocket logListener;
			JTextArea sourceTextArea;
			JTextArea compilerIPAddress;
			JTextArea compilerPort;
			JTextArea machineHostname;
			JTextArea machinePort;
			JComboBox logLevelComboBox;;
			File file;
			
			SendSource (ServerSocket outputListener, ServerSocket logListener, PiDuceExecutionTab source) {
				this.outputListener = outputListener;
				this.logListener = logListener;
				this.sourceTextArea = source.sourceTextArea;
				this.compilerIPAddress = source.compilerHostname;
				this.compilerPort = source.compilerPort;
				this.machineHostname = source.machineHostname;
				this.machinePort = source.machinePort;
				this.logLevelComboBox = source.logLevelComboBox;;
				this.file = source.file;
			}
			
			public void run() {
				try
				{
					String compilerIP = InetAddress.getByName(compilerHostname.getText().trim()).getHostAddress();
					/*Se il compilatore (PiDuceCompilerService.exe) e' in esecuzione su una macchina senza hostname
					 *registrato occorre assegnare alla stringa compilerIP l'IP della macchina su cui gira perche'
					 *l'indirizzo IP viene risolto tramite DNS
					 * es.
					 * String compilerIP = "192.168.0.1";
					 * Oppure occorre inserire l'indirizzo della macchina su cui gira il compilatore nell'applet
					 */
					Enumeration iface = NetworkInterface.getNetworkInterfaces();
					NetworkInterface ni = (NetworkInterface)iface.nextElement();
					Enumeration ipEnum = ni.getInetAddresses();
					InetAddress inet = (InetAddress)ipEnum.nextElement();
					String myIP = inet.getHostAddress();
					String source = sourceTextArea.getText();
					String machineHost = "http://" + machineHostname.getText().trim();
					String message;
					/*WARNING
					 * InetAddress class applied to the local host returns always 127.0.0.1 IP on linux systems
					 * http://developer.java.sun.com/developer/bugParade/bugs/4665037.html
					 */
					Socket socket = new Socket(compilerIP, Integer.parseInt(compilerPort.getText()));

					message = "POST " + machineHost + " HTTP/1.1\r\n";
					message += "X-PiDuceMachine-Location: ;" + machineHost + ";" + machinePort.getText().trim() + "\n";
					message += "X-PiDuceCompilerOutPut: ;" + myIP + ";" + outputListener.getLocalPort() + "\n";
					message += "X-PiDuceLog: REMOTE ;" + myIP + ";" + logListener.getLocalPort() + ";" + 
						(String)logLevelComboBox.getSelectedItem() + "\n";
					message += "Content-Length: " + source.getBytes().length + "\n";
					message += source;
					
					BufferedWriter bw = new BufferedWriter(new PrintWriter(socket.getOutputStream()));
					bw.write(message);
					bw.flush();
					bw.close();
					Thread.sleep(1000 * 60);
				}
				catch (Exception e) {System.out.println(e);e.printStackTrace();}
			}
		}
	}
	
	private class PiDuceFileFilter extends javax.swing.filechooser.FileFilter {
		String extension;
		String description;
		
		PiDuceFileFilter(String extension, String description) {
			this.extension = extension;
			this.description = description;
		}
		
		public boolean accept(File f) {
			return f.getName().toLowerCase().endsWith(extension)
					|| f.isDirectory();
		}

		public String getDescription() {
			return description;
		}

	}
}
