import java.io.*;
import java.net.*;
import javax.swing.*;
//import java.awt.*;

public class PiDuceGrammarPanel extends JPanel{
	String grammarFileName = "piduce_grammar.txt";

	JTextArea textArea = new JTextArea(48, 65);
	
	JScrollPane scrollPane = new JScrollPane(textArea);

	
	PiDuceGrammarPanel(URL codeBase)
	{		
		String line;
		URL url;
		StringBuffer buf;
		
		textArea.setEditable(false);
				
	    	try {
	    		url = new URL (codeBase, grammarFileName );
			InputStream in = url.openStream();
			BufferedReader dis = new BufferedReader(new InputStreamReader(in));

			while ((line = dis.readLine()) != null){
				textArea.append(line + "\n");
			}
			in.close();
		}
		catch (Exception e) {System.out.println(e);e.printStackTrace();}
		
		add(scrollPane);
	}
}
