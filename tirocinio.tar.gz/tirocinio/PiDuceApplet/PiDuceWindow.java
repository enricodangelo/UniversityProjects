import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;
import java.util.Enumeration;

public class PiDuceWindow extends JApplet
{

	JTabbedPane tabbedPane = new JTabbedPane(
		JTabbedPane.TOP,
		JTabbedPane.SCROLL_TAB_LAYOUT);

	JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

	JButton newTabButton = new JButton("New Execution Tab");

	JButton closeTabButton = new JButton("Close tab");

	JButton closeAllTabButton = new JButton("Close all tabs");

	String hostname;
	String ipAddress;
	
	public void init()
	{
		super.getContentPane().setLayout(new BorderLayout());
		
		tabbedPane.addTab("PiDuce Grammar", new PiDuceGrammarPanel(this.getCodeBase()));

		newTabButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						PiDuceExecutionTab executionTab = new PiDuceExecutionTab();
						tabbedPane.addTab("PiDuce Execution Tab", executionTab);
						tabbedPane.setSelectedIndex(tabbedPane.getTabCount() - 1);
						paint(tabbedPane.getGraphics());
					}
				});
		
		closeTabButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						int i;
						
						if ((i = tabbedPane.getSelectedIndex()) != 0)
						{
							tabbedPane.removeTabAt(i);
						}
					}
				});
		
		closeAllTabButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						int i;
						
						for (i = tabbedPane.getTabCount() - 1; i > 0; i--)
						{
							tabbedPane.removeTabAt(i);
						}
					}
				});
		
		buttonPanel.add(newTabButton);
		buttonPanel.add(closeTabButton);
		buttonPanel.add(closeAllTabButton);
		
		getContentPane().add(buttonPanel, BorderLayout.NORTH);
		getContentPane().add(tabbedPane, BorderLayout.CENTER);
	}
}
