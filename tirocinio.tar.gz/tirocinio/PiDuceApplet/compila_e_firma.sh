#!/bin/bash

rm *.class &&
echo
echo ">>>   O L D   C L A S S   F I L E   R E M O V E D   <<<" &&
echo
javac PiDuceWindow.java &&
echo
echo ">>>   S O U R C E   C O M P I L E D   <<<" &&
echo
jar cvf PiDuceWindow.jar *.class &&
echo
echo ">>>   J A R   M A D E   <<<" &&
echo
jarsigner -keystore mykeystore -storepass mystorepass -keypass mykeypass -signedjar SPiDuceWindow.jar PiDuceWindow.jar Enrico &&
echo
echo ">>>   J A R   S I G N E D   <<<" &&
echo
