template<class T> class DLQueue
  {
    public:
    struct Node
    {
      Node(const T& val, Node * n, Node *p){
        msg = val;
        next = n;
        prev = p;
      };
      T msg;
      Node * next;
      Node * prev;
    };
    private:
      Node * head;
      Node * tail;
      int length;
    public:
      DLQueue():head(NULL),tail(NULL),length(0){}
      ~DLQueue(){}
      bool empty()
      {
        return (length==0);
      }
      T& front()
      {
        return head->msg; 
      }
      void pop_front()
      {
        if (!empty()) 
        {
          length--;
          Node * n = head;
          if (length == 0)
            head = tail = NULL;
          else if (length == 1)
          {
            head = tail;
            head->next = tail->prev = NULL;
          }
          else 
          {
            head = head->next;
            head->prev = NULL;
          }
          delete n;
        }
      }
      Node * push_back(const T& msg)
      {
        if (length == 0){
          head = new Node(msg, NULL, NULL);
          tail = head;
        }
        else {
          tail->next = new Node(msg, NULL, NULL);
          tail->next->prev = tail;
          tail = tail->next;
        }
        length++;
        return tail;
      }
      void erase(Node * n)
      {
        if (length == 0) return;
        if (n == head) 
        {
          pop_front();
          return;
        }
        else if (n == tail)
        {
          tail = tail->prev;
          tail->next = NULL;
        }
        else
        {
          n->prev->next = n->next; 
        }
        delete n;
        length--;
      }
      int inline size(){return length;}
  };
