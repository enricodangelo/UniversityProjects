/***************************************************************************
                          chmgr.h  -  Channel Manager Header File
                             -------------------
    begin                : Mon Dec 15 2003
    copyright            : (C) 2003 by Samuele Carpineti
    email                : carpinet@cs.unibo.it
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
/**************************************************************************
 *  Code conventions: look at "C++ Standard Library Style Guidelines" 
 **************************************************************************/

#ifndef CHMGR_H
#define CHMGR_H

#include <map>
#include <stdio.h>
#include <deque>
#include <queue>
#include <string>
#include <fstream>
#include <iostream>
#include "dlqueue.cpp"
using namespace std;
 
namespace chmgr
{
  union IOMsg; 
  
  typedef DLQueue<IOMsg *>::Node IONode; 
  /**
   * Remote processes use an acknowledge channel for reaction notification.
   */
  struct Remote_Continuation
  {
    char * ack_chan;
  };
  /**
   * Local processes can use a single socket "socket_fd" for interact with
   * the channel manager. They write an identifier "fp" for the function 
   * to trigger when the rendezvous is performed.
   */
  struct Local_Continuation
  {
   int socket_fd;
   char * fp;
  };
  
  enum From 
  {
      _REMOTE, _LOCAL, _NONE
  };
  
  /**
   * Continuations can be remote or local
   */
  struct Continuation 
  {
    From from;
    union 
    {
      Remote_Continuation rc;
      Local_Continuation lc;
    };
    Continuation();
    Continuation(const Continuation& callback);
    ~Continuation(); 
    friend ostream& operator << (ostream& os, const Continuation& c);
  };
  
  class Channel;
  struct Item 
  {
    Item(Channel * __channel, IONode * __it):chan(__channel),in(__it){}
    Item():chan(NULL),in(NULL){}
    Channel * chan;
    IONode * in;
  }; 
  class ItemList
  {
    private: 
      vector<Item *> v;
    public:
      ItemList(int __size);
      ~ItemList();
      void reset(int __index);
      bool empty();
      Item *& operator[](int __index);
  };
  /**
   * This class represent an input request that can be involved in an input 
   * sum so it has a pointer to the other items and its index in this list.    
   */  
  struct InputMsg
  {
    /**
     * This contructor creates an input message with a continuation
     * @param __callback the continuation to trigger when the reaction is
     * performed
     */
    InputMsg(const Continuation * __callback);
    /**
     * This constructor creates an input message 
     * @param __callback the continuation to trigger when the reaction is
     * performed
     * @param __il: a list where are stores the inputs that belong to the same
     * input sum
     * @param __index: the object position in __il 
     */
    InputMsg(const Continuation * __callback, ItemList * __il, int __index);
    /**
     * The destructor deletes the callback
     */
    ~InputMsg();
    /**
     * The continuation
     */
    const Continuation * callback;
    /**
     * A link to the messages that belong to the same sum
     */
    ItemList * input_list;
    /**
     * The position in input_list 
     */
    int index;
  };

  /**
   * An output message represent a send request
   */
  struct OutputMsg
  {
    /**
     * The constructor creates a new output message 
     * @param __callback: the continuation to trigger when the reaction is
     * performed or NULL in asynchronous send
     * @param __data: message to send
     * @param __length: message size 
    */
    OutputMsg(const Continuation * __callback, 
              void * __data, 
              int __length);
    /**
     * The destructor deletes data and callback 
     */
    ~OutputMsg();
     /**
      * The continuation
      */
    const Continuation * callback;
    /**
     * Message length
     */
    int length;
    /**
     * Message to send
     */
    void * data;
  };

  /**
   * A queue has a Polarity:
   * _POSITIVE => channel with only send operations
   * _NEGATIVE => channel with only receive operations
   * _ZERO => channel with no data
   */
  enum Polarity
  {
      _POSITIVE, _NEGATIVE, _ZERO
  };
  
  /**
   * A generic message can be an input message or an output message 
   */
  union IOMsg
  {
        InputMsg * in;
        OutputMsg * out;
  };
  
  class PolarityError {};
  /**
   * A message queue is a queue of input or output messages and 
   * a polarity. If the polarity is _ZERO then the queue is empty; if the
   * polarity is _POSITIVE the queue contains output messages; if the polarity
   * is _NEGATIVE the queue contains input messages. At the same moment the
   * queue cannot contain inputs and outputs, so PolarityError is thrown on
   * error.
   */
  class IOMsgQueue 
  {
    DLQueue<IOMsg *> _M_queue;
    Polarity _M_polarity;
    public:
      IOMsgQueue():_M_polarity(_ZERO){}
      ~IOMsgQueue();
      int size(){return _M_queue.size();}
      /**
      * Enqueues in the channel an input message and return
      * a pointer to the added object.  
      * @param in the message to add
      * @return the value effectively added to the list
      * @exception PolarityError is the queue contains some outputs 
      */ 
      IONode * add_input(InputMsg * __in) throw (PolarityError);
      /**
       * Enqueues in the channel an output message (no return value is needed in
       * this case because output are not linked)
       * @param out the message to add
       * @exception PolarityError is the queue contains some inputs 
       */
      void add_output(OutputMsg * __out) throw (PolarityError);
      /**
       * Return a waiting input message
       * @return an input request or NULL if there are not input messages in the
       * queue
       */
      InputMsg * get_input();
      /**
       * Return a waiting output message
       * @return an output request or NULL if there are not output messages in
       * the queue
       */
      OutputMsg * get_output();
      /**
       * Remove an element from the queue (is used only to erase inputs)
       * @param an iterator on the message
       */
      IOMsg * remove(IONode * __msg);
  };

  class ChannelManager;
  /**
   * A non thread-safe channel implementation. It stores inputs or outputs.
   */
  class Channel {
      IOMsgQueue _M_reqs;
      char * _M_name;
      /**
       * The reaction is implemented here.  
       * @param __in: input
       * @param __out: output
       * @return -1 if a reaction cannot be performed becuase the receiver is
       * unreachable, 0 otherwise
       */
      int _M_react(InputMsg * __in, OutputMsg * __out, ChannelManager * CM);
    public:
      Channel(const char * __ch_name);
      ~Channel();
      /**
       * If the channel contains inputs when a snd is invoked the sender and the
       * receiver must be unblocked; otherwise the request is enqueued. 
       * @param __out: the output message
       * @param __CM: the channel manager where the channel is allocated
       * @return true: if a reaction is performed, false otherwise
       */
      bool snd(OutputMsg * __out, ChannelManager * __CM);
      /**
       * If the channel contains outputs when a rcv is invoked the receiver and the
       * sender must be unblocked; otherwise the request is enqueued. 
       * @param __in: the input message
       * @param __CM: the channel manager where the channel is allocated
       * @param __it: a pointer to the inserted element or NULL if a reaction is
       * performed or if the input is discarded
       * @param __remaining: true if there are other inputs involved in the sum
       * that need to be processed, false otherwise
       * @return true if the reaction is consumed, false otherwise
       */ 
      bool rcv(InputMsg * __in, ChannelManager * __CM, IONode ** __it, bool __remaining = false);
      /**
       * Delete a request from the queue. The request can be linked with another
       * request (e.g. input in a sum) then the delete operation is invoked also
       * in the linked channel. This function must be used only to delete inputs.
       * @param __handle: a pointer to the element
       */
      void delete_input(IONode * __handle);
  };
  /** 
   * Channel Manager operation list
   */
  enum Operation
  {
    _EMPTY, _SND, _RCV, _NEW, _DEL, _EHLO, _CLOSE, _PING, _EXIST 
  };
  /**
   * Used to understand what message the server is waiting from the client who
   * is exectuting a SND
   */
  enum SndExpected
  {
    _DATA, _SCONTINUATION, _SIZE, _SCHANNEL
  };
  /**
   * Used to understand what message the server is waiting from the client who
   * is executing a RCV
   */
  enum RcvExpected
  {
    _NUM, _RCHANNEL, _RCONTINUATION
  };
  /** 
   * This structure is used to store data received from the client who is
   * executing a SND operation
   */
  struct SndReq 
  {
    SndReq(): size(0), nread(0), waiting(_SCHANNEL) {}
    ~SndReq()
    {
      free(data);
      free(chname);
      delete cont;
    }
    /** 
     * This method resets only some fields and does not erase completly the
     * structure becuase pointers are passed to others. 
     * In particular "data" and "callback" are passed to the snd operation 
     * and will be deallocated when the reaction is performed. 
     * "chname" is deleted after the invocation of _M_snd where we need to
     * pass the name of the channel where we want to send data. 
     * However if getting the request from the network some errors
     * happen  ChannelManager::_M_stop deletes "chname", "cont" and "data".
     * In order to understand if the error occurs during the request or only at
     * the end we use the state of the automata used to hadle the snd operation
     * and if we are not in the first state (_SCHANNEL) we can deduce that the
     * error occurs getting the request and not after.
     */
    void reset();    
    SndExpected waiting;  
    char * chname;
    Continuation * cont;
    int nread;
    int size;
    void * data;
  };
   /** 
   * This structure is used to store data received from the client who is
   * executing a RCV operation
   */ 
  struct RcvReq {
    RcvReq() 
      : num(0), waiting(_NUM) {}
    /**
     * This method clean the queues chans,conts and all the other structure 
     * fields
     */
    void reset();
    RcvExpected waiting;
    int num;
    queue<string *> chans;
    queue<string *> conts;
  };
 
  const int OK = 0;
  const int NOTFOUND = 1;
   /** 
   * The channel manager is a network deamon for Bologna-PI primitives.
   * It implements:
   * <LL>
   *  <LI>ping: for test if a channel manager is running
   *  <LI>helo: where the channel manager specifies the addresses used for channel names
   *  <LI>close: closes the current connection
   *  <LI>local send: send on a channel (sender is local)
   *  <LI>remote send: send on a channel(sender is remote)
   *  <LI>local receive: receive on a channel (receiver is local)
   *  <LI>remote receive: linear forwarder from a channel to another channel
   *  <LI>input sum: multiple receive on local channels
   *  <LI>local new: creates a new channel (creator is local)
   *  <LI>remote new: creates a channel (creator is remote)
   *  <LI>delete: deletes a channel 
   *  <LI>exist: test if a channel exist
   * </LL>
   * The messages handled by the channel manager are the following: <BR>
   *    MSG => ANSWER <BR>
   * <LL>
   *   <LI> PING\r\n => PING\r\n  
   *   <LI> HELO\r\n => HELO\r\nNUM\r\nCHAN_NAME_FORMAT[0]\r\nCHAN_NAME_FORMAT[NUM-1]
   *   <LI> CLOSE\r\n 
   *   <LI> SNDLCL\r\nCHAN_NAME\r\nLOCAL_CONT\r\nLENGTH\r\nDATA <BR>
   *        => the local continuatin will be triggered on reaction
   *   <LI> SNDRMT\r\nCHAN_NAME\r\nACK_CHAN\r\nLENGTH\r\nDATA <BR>
   *        => the remote continuatin (ack_chan) will be triggered on reaction
   *   <LI> RCVLCL\r\nNUM\r\nCHAN_NAME[0]\r\nCONTINUATION[0]\r\n <BR>
   *        CHAN_NAME[NUM-1]\r\nCONTINUATION[NUM-1]\r\n <BR>
   *        => the right continuation will be triggered on reaction
   *   <LI> RCVRMT\r\n1\r\nCHAN1\r\nCHAN2     
   *   <LI> NEWLCL\r\nLOCAL_CONT\r\n <BR>
   *        => the channel name will be comunicated to the continuation
   *   <LI> NEWRMT\r\nACK_CHAN\r\n <BR>
   *        => the channel name will be comunicated to the continuation
   *   <LI> DEL\r\nCHAN_NAME\r\n    
   *   <LI> EX[LCL|RMT]\r\nCHAN_NAME\r\n => CHAN_NAME\r\n[FOUND|NOTFOUND]\r\n
   * <\LL>
   */ 
  class ChannelManager
  {
    private:
      friend class Channel;
      class ChannelManagerException {};

      //A channels pool is a map from channels name to object where the
      //rection is implemented 
      struct ltstr {
        bool operator()(const char *s1, const char *s2) const{
          return strcmp(s1,s2)<0;
        }
      };
      
      //a map from channel name to channel objects
      map<const char *, Channel *, ltstr> _M_chans;
      //LOG_LEVEL = 0 No logging information
      //LOG_LEVEL = 1 Reactions are written in the log
      //LOG_LEVEL = 2 Reactions, send and receive operations are recorded
      int _M_LOG_LEVEL;
      ofstream * _M_log;
      
      int _M_port;
      int _M_channel_seq_no;
      const char * _M_address;
      int _M_BUFFSIZE;
      //Connection handling ... the return value is 1 if the operations is
      //completly performed, 0 if it needs more data from the client, -1 if an
      //error is occured processing the  request or sending back some data
      int _M_handle_snd(const int __sockfd, int& __tokens, stringstream& __request, const From __from, SndReq& __out_buf);
      int _M_handle_rcv(const int __sockfd, int& __tokens, stringstream& __request, const From __from, RcvReq& __in_buf);
      int _M_handle_new(const int __sockfd, int& __tokens, stringstream& __request, const From __from);
      int _M_handle_ping(const int __sockfd);
      int _M_handle_helo(const int __sockfd);
      int _M_handle_islocal(const int __sockfd, int& __tokens, stringstream& __request, const From __from);
      int _M_handle_del(const int __sockfd, int& __tokens, stringstream& __request);
      void _M_stop(const int __sockfd, fd_set& __allset, int& __client, stringstream*& __req, SndReq& __snd_req, RcvReq& __rcv_req, Operation& __op, From& __from);
      
      bool _M_is_ack_channel(const char * __channel) const;
      /** 
       * Internal ack channel creation
       */
      char * _M_new_ack_chan();
      /**
       * New
       * @param __callback: the continuation to trigger when the channel is
       * created
       * @return the channel name
       */
      char * _M_new_chan(Continuation * const __callback); 
      /**
       * This method deletes a channel (if it is not present in the channel
       * manager nothing happen)
       * @param __channel: the channel name
       */
      void _M_delete_chan(const char * __channel);
      /**
       * Send
       * @param __channel: the channel where send the message. If the channel
       * does not exist the continuation is unblocked with a special send with
       * length = -1
       * @param __callback: the continuation to trigger when the reaction is
       * performed
       * @param __data: message to send
       * @param __length: message length
       * @return -1 on error (data is not trasnmitted)
       */
       int _M_snd(const char * __channel, 
                  Continuation * __callback, 
                  void * __data, 
                  int __length); 
      /**
       * Input Sum (if some channels are not available in the channel
       * manager the sum is restricted to the existing channels)
       * @param channel: an array of channels names
       * @param callback: an array of continuations
       * @param num: the number of channels involved in the sum
       */
      void _M_rcv(const char * __channel[], 
                  Continuation * __callback[], 
                  int __req_no);
      /** 
       * This method tests if a channel exists
       * @param channel 
       */            
      bool _M_is_local(const char * __channel) const;
    public: 
      /**
       * The constructor builds a channel manager. It starts from base port until
       * he finds a free port to use.
       * @param __ip: the local ip address to use for generate new names (it
       * should one of the ip usable by the local host) 
       * @param __base_port: a sequential scanning is started from __base_port in
       * order to find a free port
       * @param __log_file: a file where to write log messages
       * @param __log_level: 0 no log, 1 only reactions are written in the log, 2
       * all the messages are written in the log
       */
      ChannelManager(const char * __ip, int __base_port, const char * __log_file, int __log_level);
      ChannelManager();
      ~ChannelManager();
      /**
       * A single thread implementation that uses select for handle requests.
       */
      void start();
 };
  
  /**
   * This function unblock a receiver waiting on 'in_cont' sending back data
   * @param channel: the receiver
   * @param in_cont: the receiver continuation
   * @param data: the data to send
   * @param length: message length (if length = -1 there is an error because
   * the channel does not exist in the channel manager)
   * @param ack_chan: not NULL only when a linear fwd react with a remote send in
   * this case in fact (x --0 y | x<d>.ack_chan() ==> y<d>.ack_chan<>)
   */
  int unblock_receiver(const char * channel, const Continuation * in_cont, void * data, int length, const char * ack_chan);
  /**
   * This function unblocks a sender waiting on 'out_cont'
   * @param channel: the channel where the reaction was consumed
   * @param out_cont: callback to unblock
   */
  int unblock_sender(const char * channel, const Continuation * out_cont);

}; //namespace

#endif
