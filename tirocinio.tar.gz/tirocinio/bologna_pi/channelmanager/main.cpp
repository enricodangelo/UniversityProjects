#include <assert.h>
#include <iostream>

#include "chmgr.h"

using namespace std;
using namespace chmgr;

int main(int argc, char **argv)
{
  if (argc == 1) 
  {
    cout << "Usage: ./CM_start LOCAL_IP_ADDR [BASE_PORT] [LOG_FILE] [LOG_LEVEL]" << endl;
    cout << "BASE_PORT = 2047 if no value is passed" << endl;
    cout << "if LOG_LEVEL = 1  reactions are logged" << endl;
    cout << "if LOG_LEVEL = 2  reactions/send/receive are logged" << endl;
    return 1;
  }
  cout << "Starting tests " << endl;
  ChannelManager * CM = NULL;
  try
  {
    if (argc == 2)
      CM = new ChannelManager(argv[1], 2047, NULL, 0);
    else if (argc == 3)
      CM = new ChannelManager(argv[1], atoi(argv[2]), NULL, 0);
    else if (argc == 4)
      CM = new ChannelManager(argv[1], atoi(argv[2]), argv[3], 1);
    else if (argc == 5)
      CM = new ChannelManager(argv[1], atoi(argv[2]), argv[3], atoi(argv[4]));
    CM->start();
  }
  catch (const char * msg)
  {
    cout << msg << endl;
    if (CM != NULL) delete CM;
    return 100;
  }
  catch (...)
  {
    cout << "CM Error" << endl;
    if (CM != NULL) delete CM;
    return 100;
  }
  return 0;
}
