/***************************************************************************
                         chmgr.cpp  -  Channel Manager Implementation
                            -------------------
   begin                : Mon Dec 15 2003
   copyright            : (C) 2003 by Samuele Carpineti
   email                : carpinet@cs.unibo.it
***************************************************************************/

/***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************/

#include <string>
#include <queue>
#include <sstream>
#include <iostream>
#include <ostream>
#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <utility>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "chmgr.h"
#include "../c++/util/socketwr.h"

using namespace chmgr;

/*************************************************************************
 *                      Utility functions:                               *
 *               1. unblock_receiver 2. unblock_sender                   *
 ************************************************************************/
int chmgr::unblock_receiver(const char * channel, 
                            const Continuation * in_cont, 
                            void * data, 
                            int length, 
                            const char * ack_chan)
{
  if (in_cont == NULL) return 1;
  const Continuation& c = *in_cont;
  if (c.from == _LOCAL)
  {
    assert(ack_chan == NULL);
    //Response to the local receiver: 
    //OK \r\n CHAN \r\n LOCAL_CONT \r\n LENGTH \r\n DATA
    //NOTFOUND \r\n CHAN \r\n LOCAL_CONT \r\n 0 \r\n DATA
    ostringstream ost;
    if (length == -1) ost << NOTFOUND;
    else ost << OK;
    ost << "\r\n" << channel << "\r\n" << c.lc.fp
        << "\r\n" << max(length,0) << "\r\n";
    const char * msg = ost.str().c_str();
    if (socket_write(c.lc.socket_fd, msg, strlen(msg)) == -1)
      return -1;
    if (length > 0)
      if (socket_write(c.lc.socket_fd, data, length) == -1)
        return -1;
  }
  else if (c.from == _REMOTE)
  {
    //linear forwarder or remote new
    //linear forwarder - response to the remote receiver: 
    //        SNDRMT \r\n CHAN_NAME\r\n ACK_CHAN\r\n length\r\n data
    //remote new - response to the remote receiver: 
    //        SNDRMT \r\n CHAN_NAME \r\n \r\n length \r\n NEW_CHAN
    const char * ip = get_ip(c.rc.ack_chan).c_str();
    int port = get_port(c.rc.ack_chan);
    if (!(is_valid_ip(ip) && (port>0) && (port<65536)))
      return -1;
    int fd = open_socket(ip, port);
    if (fd == -1) return -1;
    ostringstream ost;
    ost << "SNDRMT\r\n" << c.rc.ack_chan << "\r\n";
    //can be null if we are handling a remote new     
    if (ack_chan != NULL) ost << ack_chan;
    ost << "\r\n" << length << "\r\n";
    const char * msg = ost.str().c_str();
    if (socket_write(fd, msg, strlen(msg)) == -1)
    {
      socket_shutdown(fd);
      return -1;
    }
    if (socket_write(fd, data, length) == -1)
    {
      socket_shutdown(fd);
      return -1;
    }
    socket_shutdown(fd);
  }
  return 1;
}

int chmgr::unblock_sender(const char * channel, const Continuation * out_cont)
{
  const Continuation& c = *out_cont;
  assert((c.from == _LOCAL)||(c.from == _REMOTE));
  if (out_cont == NULL) return 0; 
  if (c.from == _LOCAL)
  {
    //sends an ack to the local sender: OK \r\n CHAN \r\n LOCAL_CONT \r\n 0 \r\n  
    //where 0 is the data lenght (empty data for acks)
    ostringstream ost;
    ost << OK << "\r\n" << channel << "\r\n" << c.lc.fp << "\r\n0\r\n";
    const char * msg = ost.str().c_str();
    if (socket_write(c.lc.socket_fd, msg, strlen(msg)) == -1)
      return -1;
  }
  else if (c.from == _REMOTE)
  {
    //send the ack to the sender's channel manager
    //"SNDRMT \r\n CHANNEL_NAME \r\n \r\n 0 \r\n " 
    //where 0 is the data lenght (empty data for acks)
    const char * ip = get_ip(c.rc.ack_chan).c_str();
    int port = get_port(c.rc.ack_chan);
    if (!(is_valid_ip(ip) && (port>0) && (port<65536))) return -1;
    int fd;
    if ((fd = open_socket(ip, port)) == -1)
      return -1;
    ostringstream ost;
    ost << "SNDRMT\r\n" << c.rc.ack_chan << "\r\n\r\n0\r\n";
    const char * msg = ost.str().c_str();
    if (socket_write(fd, msg, strlen(msg)) == -1)
    {
      socket_shutdown(fd);
      return -1;
    }
    socket_shutdown(fd);
  }
}
/*************************************************************************
 * Continuation: implementation                                          *     
 ************************************************************************/
Continuation::Continuation(){}
Continuation::Continuation(const Continuation& callback)
{
  from = callback.from;
  switch (from)
  {
    case _REMOTE:
      rc.ack_chan = strdup(callback.rc.ack_chan);
      break;
    case _LOCAL:
      lc.fp = strdup(callback.lc.fp);
      lc.socket_fd = callback.lc.socket_fd;
      break;
  }
}
Continuation::~Continuation()
{
  switch (from)
  {
    case _REMOTE: 
      free(rc.ack_chan);
      break;
    case _LOCAL:
      free(lc.fp);
      break;
  }
}
ostream& operator << (ostream& os, const Continuation& c)
{
  switch (c.from)
  {
    case _REMOTE: 
      os << c.rc.ack_chan;
      break;
    case _LOCAL:
      os << c.lc.fp;
      break;
  }
  return os;
}
/*************************************************************************
 * ItemList: implementation                                              *     
 ************************************************************************/
ItemList::ItemList(int __size)
{
  v = vector<Item *>(__size);
  for (vector<Item *>::iterator i = v.begin(); i < v.end(); i++)
    *i = new Item();
}
bool ItemList::empty()
{
  for (int i = 0; i < v.size(); i++)
    if ((v.at(i)->chan != NULL) && (v.at(i)->in != NULL))
      return false;
  return true;
}
ItemList::~ItemList()
{
  for (int i = 0; i < v.size(); i++)
    if ((v.at(i)->chan != NULL) && (v.at(i)->in != NULL))
    {
      Item * item = v.at(i);
      item->chan->delete_input(item->in);
    }
}

void ItemList::reset(int __index)
{
  v.at(__index)->chan = NULL;
  v.at(__index)->in = NULL;
}
Item *& ItemList::operator[](int __index)
{
  return v.at(__index);
}
/*************************************************************************
 * OutputMsg: implementation                                             *     
 ************************************************************************/
OutputMsg::OutputMsg(const Continuation * __callback, 
                     void * __data, 
                     int __length)
{
  callback = __callback;
  length = __length;
  data = __data;
}
OutputMsg::~OutputMsg()
{
  if (length > 0) free(data);
  delete callback;
}
/*************************************************************************
 * InputMsg: implementation                                              *     
 ************************************************************************/

InputMsg::InputMsg(const Continuation * __callback)
{
  callback = __callback;
  input_list = NULL;
}
InputMsg::InputMsg(const Continuation * __callback, 
                   ItemList * __il, 
                   int __index)
{
  callback = __callback;
  input_list = __il;
  index = __index;
}
InputMsg::~InputMsg()
{
  delete callback;
  if (input_list != NULL)
    input_list->reset(index);
}
/*************************************************************************
 * IOMsgQueue: implementation                                            *     
 ************************************************************************/
IOMsgQueue::~IOMsgQueue()
{
  if (_M_polarity == _ZERO) return;
  if (_M_polarity == _NEGATIVE)
    while (!_M_queue.empty())
    {
      InputMsg * in = this->get_input();
      delete in;
    }
  else if (_M_polarity == _NEGATIVE)
  {
    while (!_M_queue.empty())
      delete this->get_output();
  }
}
IONode * IOMsgQueue::add_input(InputMsg * __in) throw (PolarityError)
{
  if (_M_polarity == _POSITIVE) throw PolarityError();
  _M_polarity = _NEGATIVE; 
  IONode * it =  _M_queue.push_back(reinterpret_cast<IOMsg *>(__in));
  return it;
}
void IOMsgQueue::add_output(OutputMsg * __out) throw (PolarityError)
{
  if (_M_polarity == _NEGATIVE) throw PolarityError();
  _M_polarity = _POSITIVE;
  _M_queue.push_back(reinterpret_cast<IOMsg *>(__out));
}
InputMsg * IOMsgQueue::get_input()
{
  if ((_M_polarity == _POSITIVE) || (_M_polarity == _ZERO) || _M_queue.empty())
    return NULL;
  InputMsg * in = reinterpret_cast<InputMsg *&>(_M_queue.front());
  _M_queue.pop_front();
  if (in->input_list != NULL) 
  {
    in->input_list->reset(in->index);
  }
  if (_M_queue.empty()) _M_polarity = _ZERO;
  return in;
}
OutputMsg * IOMsgQueue::get_output(){
  if ((_M_polarity == _NEGATIVE) || (_M_polarity == _ZERO) || _M_queue.empty())
    return NULL;
  OutputMsg * out = reinterpret_cast<OutputMsg *>(_M_queue.front());
  _M_queue.pop_front();
  if (_M_queue.empty()) _M_polarity = _ZERO;
  return out;
}
IOMsg * IOMsgQueue::remove(IONode * __msg){
  if ((_M_polarity == _ZERO) || _M_queue.empty())
    return NULL;
  _M_queue.erase(__msg);
  if (_M_queue.empty()) _M_polarity = _ZERO;
}

/*************************************************************************
 * Channel: implementation                                               *     
 ************************************************************************/

Channel::Channel(const char * __ch_name)
{
  _M_name = (char *)malloc(sizeof(char)*strlen(__ch_name));
  _M_name = strdup(__ch_name);
}
Channel::~Channel()
{
  free(_M_name);
}
int Channel::_M_react(InputMsg * __in, 
                      OutputMsg * __out, 
                      ChannelManager * CM)
{
  //if the receiver is local we can immediatly unblock sender and receiver 
  if (__in->callback->from == _LOCAL)
  {
    //Step 1 
    if (unblock_receiver(_M_name, __in->callback, __out->data, 
                            __out->length, NULL) == -1)
    {
      if (CM && CM->_M_log && (CM->_M_LOG_LEVEL == 2)) 
        *CM->_M_log << "Channel: Error unblocking local receiver on" 
                    << __in->callback << endl;;
      return -1;
    }
    //Step 2 (asend has an empty callback)
    if (__out->callback != NULL)
    {
      if (unblock_sender(_M_name, __out->callback) == -1)
      {
        if (CM && CM->_M_log && (CM->_M_LOG_LEVEL == 2)) 
          *CM->_M_log << "Channel: Error unblocking sender" << endl;
      }
    }
    return 0;
  }
  //if the receiver is not local then we are handling a linear forwarder 
  //so we cannot unblock the sender that, instead, will be unblocked later 
  //in the receiver location when the reaction really happen
  else if (__in->callback->from == _REMOTE)
  {
    if (__out->callback == NULL)
    {
      if (unblock_receiver(_M_name, __in->callback, __out->data, 
                              __out->length, NULL) == -1)
      {
        if (CM && CM->_M_log && (CM->_M_LOG_LEVEL == 2))
          *CM->_M_log << "Channel: Error unblocking remote receiver on" 
                      << __in->callback << endl;
        return -1;
      }
    }
    //x --0 y | x<data>.z<> => y<data>.z<>
    else if (__out->callback->from == _REMOTE)
    {
      if (unblock_receiver(_M_name, __in->callback, __out->data, __out->length,
                            __out->callback->rc.ack_chan) == -1)
      {
        if (CM && CM->_M_log &&(CM->_M_LOG_LEVEL == 2)) 
          *CM->_M_log << "Channel: Error unblocking remote receiver on " 
                      <<  __in->callback << endl;
        return -1;
      }
    }
    // x --0 y | x<data>.local_cont<> => 
    // (ack_chan) y<data>.ack_chan<> | ack_chan().local_cont<>
    else if (__out->callback->from == _LOCAL)
    {
      //in this case we create a new ack channel 'ack_chan' where an input with 
      //the output callback '__out->callback' is added ... so when a reaction 
      //is performed an output on this channel will unblock "__out->callback" 
      //and the channel will be deleted (snd will delete ack_chan)
      const char * ack_chan[1];
      ack_chan[0] = CM->_M_new_ack_chan();
      Continuation * callback[1];
      callback[0] = new Continuation(*__out->callback);
      CM->_M_rcv(ack_chan, callback, 1);
      if (unblock_receiver(this->_M_name, __in->callback, __out->data, 
            __out->length, ack_chan[0]) == -1)
        if (CM && CM->_M_log) 
          *CM->_M_log << "Channel: Error unblocking remote receiver on "
                      << __in->callback << endl;
    }
    return 0;
  }
}
//Messages are deleted here if a reaction is performed
bool Channel::snd(OutputMsg * __out, ChannelManager * __CM)
{
  InputMsg * in = _M_reqs.get_input();
  if (in == NULL)
  {
    _M_reqs.add_output(__out);
    return false; 
  }
  else 
  { //Reaction implementation
    //NOTA BENE: if the output message has length = -1 the input channel is an 
    //ack channel and the remote channel does not exist. 
    //In particular we are in one of the following two situations: 
    //1.   [x<>.P] = x<>.ack<>|ack().P where x is not local and does not exist
    //                                 in the remote channel manager. In this
    //                                 case we can immediatly unblock the
    //                                 receiver with NOTFOUND
    //                               
    //2.   [x().P + y().Q + z().R] = (x',y') x'().(P|y'--0 y) + 
    //                                       y'().(Q|x'--0 x) + 
    //                                       z().(R|y'--0 y|x'--0 x)
    //                                       | x--0 x' | y--0 y'
    //                                       where x,y are not local and one or
    //                                       both does not exist in the remote
    //                                       channel manager. In this case we
    //                                       don't unblock immediatly the receiver
    //                                       with NOTFOUND but only if also the
    //                                       other channels are not reacheable
    if (__out->length == -1)    
    {
      if (in->input_list != NULL) in->input_list->reset(in->index);
      //if there are no more available inputs we can unblock the receiver 
      if ((in->input_list == NULL) || 
            ((in->input_list != NULL) && (in->input_list->empty())))
          unblock_receiver(this->_M_name, in->callback, NULL, -1, NULL);
      delete in;
      return false;
    }
    if (this->_M_react(in, __out, __CM) == -1)
    {
      //if the receiver is not available we can retry with another send
      delete in;
      return this->snd(__out, __CM);
    }
    else 
    {
      //deleting other inputs
      if (in->input_list != NULL)
      { 
        delete in->input_list;
        in->input_list = NULL;
      }
      delete in;
      delete __out;
    }
    return true;
  }  
}

bool Channel::rcv(InputMsg * __in, ChannelManager * __CM, IONode ** __it, bool __remaining) 
{
  OutputMsg * out = _M_reqs.get_output(); 
  if (out == NULL)
  { 
    *__it = _M_reqs.add_input(__in);
    return false;
  }
  else 
  { //reaction implementation
    
    //Like Channel::snd the output messsage can be an error message
    //so we need to unblock the receiver. Unfortunatly in this case rcv
    //can be called for a local sum so we need to use __remaining in order to
    //udnerstand when in practice we can send an error message to the receiver.
    //(__remaing=false indicates that the rcv is at the end of a sum (or the 
    //sum hase only one input) so we can go on with the unblock procedure)
    if (out->length == -1)
    {
      if (__in->input_list != NULL) __in->input_list->reset(__in->index);
      if (!__remaining) 
      {
        if ((__in->input_list == NULL) 
              || ((__in->input_list != NULL) && (__in->input_list->empty())))
            unblock_receiver(_M_name, __in->callback, NULL, -1, NULL);
      }
      delete __in;
      delete out;
      *__it = NULL;
      return false;
    }
    if (this->_M_react(__in, out, __CM) == -1)
    {
      //if the receiver is not available
      _M_reqs.add_output(out);
      delete __in;
      *__it = NULL;
      return false;
    }
    //deleting others input
    if (__in->input_list != NULL) 
    {
      //__in is not present in input_list
      delete __in->input_list;
      __in->input_list = NULL;
    }
    delete __in;
    delete out;
    return true;
  }
}
void Channel::delete_input(IONode * __handle)
{
  InputMsg * msg = reinterpret_cast<InputMsg *>(__handle->msg);
  _M_reqs.remove(__handle);
  delete msg; 
}

/*************************************************************************
 * SndReq,RcvReq: implementation                                         *     
 ************************************************************************/
void SndReq::reset()
{
  size = 0;
  nread = 0;
  waiting = _SCHANNEL;
}
void RcvReq::reset()
{
  num=0;
  waiting = _NUM;
  string * s;
  while (!chans.empty())
  {
    s = chans.front();
    chans.pop();
    delete s;
  }
  while (!conts.empty())
  {
    s = conts.front();
    conts.pop();
    delete s;
  }
}
/*************************************************************************
 * ChannelManager: implementation                                        *     
 ************************************************************************/
ChannelManager::ChannelManager(const char * __ip, 
                               int __base_port, 
                               const char * __log_file, 
                               int __log_level)
{
  if (!is_valid_ip(__ip)) throw "Invalid Ip";
  _M_address = __ip;
  //need to be greater than 2
  _M_BUFFSIZE = 1024;
  _M_port = __base_port;
  if (__log_file == NULL) __log_level = 0;
  if (__log_level < 1) this->_M_LOG_LEVEL = 0;
  else if (__log_level >= 2) this->_M_LOG_LEVEL = 2;
  else _M_LOG_LEVEL = 1;
  if (__log_level > 0) 
  {
    _M_log = new ofstream(__log_file, ios::out|ios::trunc);
    if (!_M_log) 
    {
      cerr << "Channel Manager cannot open a _M_log file";
      _M_LOG_LEVEL = 0;
    }
  }
  _M_channel_seq_no = 0;
}

ChannelManager::~ChannelManager()
{
  if (_M_log) delete _M_log;
}

//__length can be -1 on error
int ChannelManager::_M_snd(const char * __channel, 
                         Continuation * __callback, 
                         void * __data,
                         int __length)
{
  typedef map<const char *, Channel *>::iterator Iter; 
  Iter it = _M_chans.find(__channel);
  if (it != _M_chans.end())
  {
    OutputMsg * out = new OutputMsg(__callback, __data, __length);    
    int res = it->second->snd(out, this); 
    //if the channel is an ack channel we can delete it after the reaction
    if (this->_M_is_ack_channel(__channel)) 
      this->_M_delete_chan(__channel);
    if (_M_log)
    {
       if (_M_LOG_LEVEL == 2) 
         *_M_log << "SND: " << __channel << endl;
       if (res) *_M_log << "SND: Reaction on " << __channel << endl;
    }
    return 0;
  }
  else 
  {
    if (_M_log && (_M_LOG_LEVEL == 2))
      *_M_log << "SND: " << __channel << " Not found" << endl;
    if (__callback != NULL)
          unblock_receiver(__channel , __callback, NULL, -1, NULL);
    return -1;
  }
}
void ChannelManager::_M_rcv(const char * __channel[], 
                            Continuation * __callback[],
                            int __reqs_no)
{
  typedef map<const char *, Channel *>::iterator Iter;
  Iter it[__reqs_no];
  vector<const char *> chans;
  int first = __reqs_no; //min available index in the sum
  int last = -1; // max available index in the sum
  if (_M_log && (_M_LOG_LEVEL == 2)) *_M_log << "RCV: "; 
  for (int i = 0; i < __reqs_no; i++)
  {
    if ((it[i] = _M_chans.find(__channel[i])) == _M_chans.end())
    {
      if (_M_log && (_M_LOG_LEVEL == 2))
      {
        *_M_log << __channel[i] << " Not found";
        if (i !=( __reqs_no - 1)) *_M_log << " + ";
      }
    }
    else //there is an available channel
    {
      if (_M_log && (_M_LOG_LEVEL == 2))
      {
          *_M_log << __channel[i]; 
          if (i !=( __reqs_no - 1)) *_M_log << " + ";
      }
      first = min(first,i);
      last = max(last,i);
    }
  }
  if (_M_log && (_M_LOG_LEVEL == 2)) *_M_log << endl;
  //we can return if there are no available channel but before we need to
  //trigger the continuation with an error message (length = -1)
  //NOTA BENE: only one continuation is triggered so the API needs to know 
  //if it's a part of a sum and in this case it must unblock the other
  //continuations.
  if (last == -1) 
  {
    unblock_receiver(__channel[0], __callback[0], NULL, -1, NULL);
    return;
  }
  Channel * fst_chan = it[first]->second;
  InputMsg * fst_input = new InputMsg(__callback[first]);
  IONode * fst_it;
  bool react = fst_chan->rcv(fst_input, this, &fst_it, (first != last));
  if (_M_log && react) *_M_log << "RCV: Reaction on " << __channel[0] << endl;
  //there are other inputs and the first has not reacted
  if ((first < last) && !react) 
  {
    ItemList * in_list = new ItemList(__reqs_no);
    if (fst_it != NULL) //if in is enqueued
    {
      fst_input->input_list = in_list;
      fst_input->index = first;
      Item * fst_item = new Item(fst_chan, fst_it); 
      (*in_list)[first] = fst_item;
    }
    //if fst_req==NULL then a reaction was consumed
    for (int i = (first + 1); (i < __reqs_no) && (!react); i++)
    {
      if (it[i] == _M_chans.end()) continue;
      InputMsg * input = new InputMsg(__callback[i], in_list, i);
      IONode * in_it;
      react = it[i]->second->rcv(input, this, &in_it, (i != last));
      if (!react && (in_it != NULL))
      {
        Item * in_item = new Item(it[i]->second, in_it); 
        (*in_list)[i] = in_item;  
      }
      if (_M_log)
      {
        if (_M_LOG_LEVEL == 2) 
          *_M_log << "RCV: " << __channel[i] << endl;    
        if (react) *_M_log << "RCV: Reaction on " << __channel[i] << endl;
      }
    }
  }
}

bool ChannelManager::_M_is_ack_channel(const char * __channel) const
{
  //a channel is an ack_channel if _ACK_ is in the name
  char * c = index(__channel,'_');
  if (c == NULL) return false;
  if (strncmp(c, "_ACK_", 5) == 0)
    return true;
  else return false; 
}
char * ChannelManager::_M_new_ack_chan()
{
  _M_channel_seq_no++;
  stringstream ost;
  ost << _M_address << ":" << _M_port << "#_ACK_" << _M_channel_seq_no;
  string channel = ost.str();
  char * name = strdup(channel.c_str());
  _M_chans.insert(make_pair(name, new Channel(name)));
  if (_M_log && (_M_LOG_LEVEL == 2))
    *_M_log << "NEW: " << name << endl;
  return name;   
}

char * ChannelManager::_M_new_chan(Continuation * const __callback)
{
  _M_channel_seq_no++;
  stringstream ost;
  ost << _M_address << ":" << _M_port << '#' << _M_channel_seq_no;
  string channel = ost.str();
  char * name = strdup(channel.c_str());
  _M_chans.insert(make_pair(name,new Channel(name)));
  if (_M_log)
    *_M_log << "NEW: " << name << endl;
  if (__callback != NULL)
    unblock_receiver("" , __callback, name, strlen(name), NULL); 
  return name;
} 

void ChannelManager::_M_delete_chan(const char * __channel)
{
  typedef map<const char *, Channel *>::iterator Iter; 
  Iter it = _M_chans.find(__channel);
  if (it != _M_chans.end())
  {
    _M_chans.erase(it);
    if (_M_log && (_M_LOG_LEVEL == 2))
      *_M_log <<"DELETE: " << __channel << endl;
    delete it->first;
    delete it->second;
  }
  else
  { 
    if (_M_log && (_M_LOG_LEVEL == 2))
      *_M_log <<"DELETE: " <<  __channel << " not found" << endl;
  }
}

bool ChannelManager::_M_is_local(const char * __channel) const
{
  return (_M_chans.find(__channel) != _M_chans.end());
}


int set_op(string str, Operation& op, From& from);
  
void ChannelManager::_M_stop(const int __sockfd, 
                             fd_set& __allset, 
                             int& __client, 
                             stringstream*& __req, 
                             SndReq& __snd_req, 
                             RcvReq& __rcv_req, 
                             Operation& __op, 
                             From& __from)
{
  if (_M_log) *_M_log <<"STOP: " << " connection closed" << endl;
  socket_shutdown(__sockfd); 
  FD_CLR(__sockfd, &__allset);
  __client = -1;
  __req = NULL;
  __op = _EMPTY;
  __from = _NONE;
  __snd_req.reset();
  //if we are not finished with the request we can free data
  if (__snd_req.waiting != _SCHANNEL)
  {
    free(__snd_req.chname);
    free(__snd_req.data);
    delete __snd_req.cont;
  }
  __rcv_req.reset();
}
void ChannelManager::start()
{
   //this->_M_address = URI or ip__M_address ????
  const int FDSETSIZE = 100;
  int i;
  int listenfd = socket(AF_INET, SOCK_STREAM,0);
  int client[FDSETSIZE];
  struct sockaddr_in cliaddrlist[FDSETSIZE];
  int maxfd, maxi, nready;
  int connfd;
  struct sockaddr_in servaddr, cliaddr;
  fd_set allset, rset;
  
  Operation op[FDSETSIZE];
  From from[FDSETSIZE];
  int STATE[FDSETSIZE];
  char buf [_M_BUFFSIZE];   
  //array of streams used for store the requests
  stringstream * req[FDSETSIZE];
  //Data structure for receive operations
  RcvReq rcv_req[FDSETSIZE];
  //Data structure for send
  SndReq snd_req[FDSETSIZE];

  bzero(&servaddr,sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  servaddr.sin_port = htons(this->_M_port);
  while (bind(listenfd, (struct sockaddr *)&servaddr,sizeof(servaddr)) == -1)
  {
    this->_M_port++;
    servaddr.sin_port = htons(this->_M_port);
  }
  listen(listenfd, 100);
  maxfd = listenfd;
  maxi = -1;
  for(int i = 0; i < FDSETSIZE; i++)
  { 
    client[i] = -1;
    op[i] = _EMPTY;
    from[i] = _NONE;
    req[i] = NULL;
    STATE[i] = 0;
  }
  FD_ZERO(&allset);
  FD_SET(listenfd, &allset);
  cout << "Waiting connections on " << _M_address << ":" << _M_port << endl; 
  stringstream * s;
  while (true)
  {
    rset = allset;
    nready = select(maxfd + 1, &rset, NULL, NULL, NULL);
    if (FD_ISSET(listenfd, &rset))
    {
      socklen_t clilen = sizeof(cliaddr);
      connfd = accept(listenfd, (struct sockaddr*)&cliaddr,&clilen);
      for (i = 0; i < FDSETSIZE; i++)
        if (client[i] < 0)
        {
          client[i] = connfd;
          cliaddrlist[i] = cliaddr;
          fcntl(connfd, F_SETFL, O_NONBLOCK);
          break;
        }
      if (i == FDSETSIZE)
      {
        if (_M_log) *_M_log << "Too many client ... " << endl;
        socket_shutdown(connfd);
        continue;
      }
      FD_SET(connfd, &allset);
      if (connfd > maxfd) maxfd = connfd;
      if (i > maxi) maxi = i;
      if (--nready <= 0) continue; // no more readable descriptors
    }
    for (i = 0; i <= maxi; i++)
    { //check all clients for data 
      int sockfd = -1;
      if ((sockfd = client[i]) < 0) continue;
      if (FD_ISSET(sockfd,&rset)) 
      {
        int tokens = 0;
        while (true)
        {
          int res;
          if (tokens <= 0)
          { //tring to get more data
            if ((req[i] != NULL) && (req[i]->str().length()>0))
            {
              string str;
              *req[i] >> str;
              s = new stringstream();
              *s << str;
              delete req[i];
              req[i] = s;
            }
            else if (req[i] == NULL) req[i] = new stringstream();
            res = non_blocking_readn(sockfd, buf, _M_BUFFSIZE);
            if (res == -1)
            {
              //connection was closed
              this->_M_stop(sockfd, allset, client[i], req[i], snd_req[i], 
                              rcv_req[i], op[i], from[i]);
              break;
            }
            else if (res == 0) 
              break; // no more data available
            else 
            {
              req[i]->write((char *)buf, res);
              tokens = 0;
              for (int j = 0; j < res; j++)
              {
                if ((((char *)buf)[j] == '\r') && (STATE[i] == 0)) 
                    STATE[i] = 1;
                else if (STATE[i] == 1) 
                {
                  if (((char *)buf)[j] == '\n') 
                    tokens++;
                  STATE[i] = 0;
                }
              }
            }
          }
          //if i'm waiting binary data i must consider also string without
          //tokens
          if (snd_req[i].waiting != _DATA)
            if (tokens<=0) continue; 
          //i can read the first line   
          if ((op[i] == _EMPTY) && tokens > 0)
          {
            string tmp;
            *req[i] >> tmp;
            tokens--;
            if (set_op(tmp, op[i], from[i]) == -1)
            {
              if (_M_log && (_M_LOG_LEVEL == 2))
                *_M_log << "Error reading Operation From the socket" 
                        << tmp.c_str() << req[i]->str().c_str()<< endl;
              this->_M_stop(sockfd, allset, client[i], req[i], snd_req[i], 
                              rcv_req[i], op[i], from[i]);
              break;
            }
          }
          //operations that needs no tokens or only one token can be executed
          if ((tokens <= 0) && (snd_req[i].waiting != _DATA) && (op[i] != _EHLO) 
                && (op[i] != _CLOSE) && (op[i] != _PING))
            continue;
          int result = 0;
          if ((op[i] == _NEW) && (from[i] != _NONE))
            result = this->_M_handle_new(sockfd, tokens, *req[i], from[i]);
          if ((op[i] == _RCV) && (from[i] != _NONE))
            result = this->_M_handle_rcv(sockfd, tokens, *req[i], from[i], rcv_req[i]);
          if (op[i] == _DEL)
            result = this->_M_handle_del(sockfd, tokens, *req[i]);
          if (op[i] == _EXIST)
            result = this->_M_handle_islocal(sockfd, tokens, *req[i], from[i]);
          if (op[i] == _EHLO)
            result = this->_M_handle_helo(sockfd);
          if (op[i] == _CLOSE)
          {
            this->_M_stop(sockfd, allset, client[i], req[i], snd_req[i], rcv_req[i], op[i], from[i]);
            result = 1;
          }
          if (op[i] == _PING)
            result = this->_M_handle_ping(sockfd);
          if ((op[i] == _SND) && (from[i] != _NONE))
            result = this->_M_handle_snd(sockfd, tokens, *req[i], from[i], snd_req[i]);
          if (result == 1)
          { 
            op[i] = _EMPTY;
            from[i] = _NONE;
          }
          //an error occurs reading the message 
          else if (result == -1) 
          {
            if (_M_log && (_M_LOG_LEVEL ==2)) 
              *_M_log << "An error occurs reading the client message" << endl;
            this->_M_stop(sockfd, allset, client[i], req[i], snd_req[i], 
                            rcv_req[i], op[i], from[i]);
            break;
          }
        } 
      }
    }
  }
}

int ChannelManager::_M_handle_new(const int __sockfd, 
                                  int& __tokens, 
                                  stringstream& __request, 
                                  const From __from)
{
  assert(__tokens>0);
  //reading parameter <CONTINUATION>
  string ack;
  __request >> ack;
  if ((ack.length())==0)
  {
    if (_M_log && (_M_LOG_LEVEL ==2)) 
      *_M_log << "_M_handle_new: error CONTINUATION is missing" << endl;
    return -1;
  }
  __tokens--;
  Continuation * c = new Continuation();
  c->from = __from;
  char * fp_or_chan = strdup(ack.c_str());
  if (c->from == _LOCAL)
  { 
    c->lc.socket_fd = __sockfd;
    c->lc.fp = fp_or_chan;
  }
  else if (c->from == _REMOTE)
  { 
    c->rc.ack_chan = fp_or_chan;
  }
  this->_M_new_chan(c);
  delete c;
  return 1;
}

int ChannelManager::_M_handle_rcv(const int __sockfd, 
                                int& __tokens, 
                                stringstream& __request, 
                                const From __from, 
                                RcvReq& __in_buf){
  assert(__tokens>0);
  //reading parameters <NUM, CHANNEL[0], CONT[0], ..., CHANNEL[NUM-1],
  //CONT[NUM-1]>
  if (__in_buf.waiting == _NUM)
  {
    string s;
    __request >> s;
    __tokens--;
    __in_buf.num = atoi(s.c_str());
    //wrong request with 0 channels
    if (__in_buf.num < 1)
    { 
      if (_M_log && (_M_LOG_LEVEL == 2))
        *_M_log << "_M_handle_rcv: error NUM is missing" << endl;
      return -1;
    }
    __in_buf.waiting = _RCHANNEL;
  }     
  while (__tokens>0)
  {
    string * str = new string();
    __request >> *str;
    __tokens--;
    if (__in_buf.waiting == _RCHANNEL)
    {
      __in_buf.chans.push(str);
      __in_buf.waiting = _RCONTINUATION;
    }
    else if (__in_buf.waiting == _RCONTINUATION)
    {
        __in_buf.conts.push(str);
        __in_buf.waiting = _RCHANNEL; 
    }
    if (__in_buf.conts.size() == __in_buf.num)
    {
      char * channels[__in_buf.num];
      Continuation * cont[__in_buf.num];
      for (int j = 0; j < __in_buf.num; j++)
      {
        string * str = __in_buf.chans.front();
        channels[j] = strdup(str->c_str());
        __in_buf.chans.pop();
        delete str;
        cont[j] = new Continuation();
        cont[j]->from = __from;
        string * ack = __in_buf.conts.front();
        char * fp_or_chan = strdup(ack->c_str());
        __in_buf.conts.pop();
        delete ack;
        if (cont[j]->from == _REMOTE)
        {
          cont[j]->rc.ack_chan = fp_or_chan;
        }
        else if (cont[j]->from == _LOCAL)
        {
          cont[j]->lc.fp = fp_or_chan;
          cont[j]->lc.socket_fd = __sockfd;
        }
      }
      this->_M_rcv((const char **)channels, cont, __in_buf.num);
      for (int j = 0; j < __in_buf.num; j++) 
        free(channels[j]);
      __in_buf.reset();  
      return 1;
    }
  }
  return 0;
}

int ChannelManager::_M_handle_snd(const int __sockfd,
                            int& __tokens, 
                            stringstream& __request, 
                            const From __from, 
                            SndReq& __out_buf )
{
  assert(__tokens > 0 || (__tokens == 0 && __out_buf.waiting == _DATA));
  string tmp;
  char ch;
  //reading parameters <CHANNEL, CONTINUATION, SIZE, MSG> where CONTINUATION can
  //be not present (asend)
  if (__out_buf.waiting == _SCHANNEL)
  {
     __request >> tmp;
     __tokens--;
     __out_buf.chname = strdup(tmp.c_str());
     __out_buf.waiting = _SCONTINUATION;
     do
      {
      __request.readsome(&ch, 1);
      }
      while (ch!='\n');
  }
  if ((__tokens > 0) && (__out_buf.waiting == _SCONTINUATION))
  { 
    //aynchronous send
    if ((__request.peek() == '\r') || (__request.peek() == '\n'))
    {
      __out_buf.waiting = _SIZE;
      __out_buf.cont = NULL;
      __tokens--;
    }
    else 
    {
      __request >> tmp;
      __tokens--; 
      Continuation * c = new Continuation();
      c->from = __from;
      char * fp_or_chan = strdup(tmp.c_str());
      if (c->from == _LOCAL)
      {
        c->lc.socket_fd = __sockfd;
        c->lc.fp = fp_or_chan;
      }
      else if (c->from == _REMOTE)
      {  
        c->rc.ack_chan = fp_or_chan;
      }
      __out_buf.cont = c;
      __out_buf.waiting = _SIZE;
     }
     do
     {
      __request.readsome(&ch, 1);
     }
     while (ch != '\n');
  }
  if ((__tokens > 0) && (__out_buf.waiting == _SIZE))
  { 
     __request >> tmp;
     __tokens--;
     __out_buf.size = atoi(tmp.c_str()); //can be -1 on error
     __out_buf.nread = 0;
     __out_buf.waiting = _DATA;  
     if (__out_buf.size > 0)
       __out_buf.data = malloc(sizeof(char) * __out_buf.size);
     else if (__out_buf.size == 0) __out_buf.data = NULL;
     do
     {
      __request.readsome(&ch, 1);
     }
     while (ch != '\n');
  }
  if (__out_buf.waiting == _DATA)
  {
     //reading binary data
     if (__out_buf.size > 0)
     {
       int nleft = __out_buf.size - __out_buf.nread;
       char last = '\0';
       if (__out_buf.nread>0) last = ((char*)__out_buf.data)[__out_buf.nread];
       char * tmp = &((char *)(__out_buf.data))[__out_buf.nread];
       int n = __request.readsome(tmp, nleft);
       __out_buf.nread += n;
       //here i need to decrease tokens becuase i consumed some data
       if ((n>0) && (last == '\r') && (tmp[0]=='\n')) __tokens--;
       for (int j = 0; j < n-1; j++) 
         if ((tmp[j] == '\r') && (tmp[j + 1] == '\n')) __tokens--;
     }
     //if i read all the data i can call snd
     if (__out_buf.nread >= __out_buf.size)
     { 
        if (this->_M_snd(__out_buf.chname, __out_buf.cont, 
              __out_buf.data, __out_buf.size) == -1)
        {
          //data and cont are not passed on error
          if (__out_buf.size>0) free(__out_buf.data);
          if (__out_buf.cont != NULL) free(__out_buf.cont);
        }
        free(__out_buf.chname);
        __out_buf.waiting = _SCHANNEL; 
        __out_buf.reset();
        return 1;
     }
  }
  return 0;
}

int ChannelManager::_M_handle_del(const int __sockfd, int& __tokens, stringstream& __request)
{
  assert(__tokens > 0);
  //reading parameter <CHANNEL>
  string chname;
  __request >> chname;
  __tokens--; 
  this->_M_delete_chan(chname.c_str());
  return 1;
}
int ChannelManager::_M_handle_helo(const int __sockfd)
{
  string msg;
  msg = "HELO\r\n1\r\n"; 
  msg += _M_address;
  msg += "\r\n";
  if (socket_write(__sockfd, msg.c_str(), msg.length()) == -1)
  {
    if (_M_log && (_M_LOG_LEVEL == 2)) *_M_log << "HELO: Error responding" << endl;
    return -1;
  }  
  if (_M_log && (_M_LOG_LEVEL == 2)) *_M_log << "HELO: done" << endl;
  return 1;
}
int ChannelManager::_M_handle_ping(const int __sockfd)
{
  string msg;
  msg = "PING\r\n"; 
  if (socket_write(__sockfd, msg.c_str(), msg.length()) == -1)
  {
    if (_M_log && (_M_LOG_LEVEL == 2)) *_M_log << "PING: Error responding ..."<< endl;
    return -1;
  }
  if (_M_log && (_M_LOG_LEVEL ==2)) *_M_log << "PING: done"<< endl;
  return 1;
}
int ChannelManager::_M_handle_islocal(const int __sockfd, 
                                      int& __tokens, 
                                      stringstream& __request, 
                                      From __from)
{
  //EX[LCL|RMT] \r\n CHANNEL \r\n [LOCAL_CONT|ACK_CHAN] \r\n
  assert(__tokens > 0);
  if (__tokens < 2) return 0; //waiting for CHANNNEL && CONTINUATION
  //reading parameters <CHANNEL, CONTINUATION>
  string chname;
  __request >> chname;
  __tokens--;
  string fp_or_chan;
  __request >> fp_or_chan;
  __tokens--;
  Continuation c;
  c.from = __from; 
  if (__from == _LOCAL)
  { 
    c.lc.socket_fd = __sockfd;
    c.lc.fp = strdup(fp_or_chan.c_str());
  }
  else if (c.from == _REMOTE)
  { 
    c.rc.ack_chan = strdup(fp_or_chan.c_str());
  }
  //Sending the answer
  //CHANNEL \r\n [LOCAL_CONT|ACK_CHAN] \r\n [5|8] \r\n [FOUND|NOTFOUND]
  const char * found = "FOUND";
  const char * notfound = "NOTFOUND";
  bool islocal = _M_is_local(chname.c_str());
  if (islocal)
    unblock_receiver(chname.c_str(), &c, (void *)found, strlen(found), NULL);
  else unblock_receiver(chname.c_str(), &c, (void *)notfound, strlen(notfound), NULL);
  if (_M_log && (_M_LOG_LEVEL ==2)) 
  {
    *_M_log << "EXISTS: " << chname.c_str();
    if (islocal) *_M_log << "is local" << endl;
    else *_M_log << "is not local" << endl; 
  }
  return 1;
}
int set_op(string str, Operation& op, From& from)
{
  if (str == "SNDRMT")
  { 
    op = _SND;
    from = _REMOTE;
  }
  else if (str == "SNDLCL")
  {
    op = _SND;
    from = _LOCAL;
  }
  else if (str == "RCVRMT")
  {
    op = _RCV;
    from = _REMOTE;
  } 
  else if (str == "RCVLCL")
  {
    op = _RCV;
    from = _LOCAL;
  }
  else if (str == "NEWRMT")
  {
    op = _NEW;
    from = _REMOTE;
  } 
  else if (str == "NEWLCL")
  {
    op = _NEW;
    from = _LOCAL;
  }
  else if (str == "DEL")
  {
    op = _DEL;
    from = _NONE;
  }
  else if (str == "HELO")
  {
    op = _EHLO;
    from = _NONE;
  }
  else if (str == "CLOSE")
  {
    op = _CLOSE;
    from = _NONE;
  }
  else if (str == "PING")
  {
    op = _PING;
    from = _NONE;
  }
  else if (str == "EXLCL")
  {
    op = _EXIST;
    from = _LOCAL;
  }
  else if (str == "EXRMT")
  {
    op = _EXIST;
    from = _REMOTE;
  } 
  else return -1;
}
