#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <string>
#include <pthread.h>
#include "semaphore.h"

//DEBUG
#include <assert.h>
#include <iostream>
using namespace std;

Mutex::Mutex() 
{
  Init(); 
}
void Mutex::Init()
{
  pthread_mutex_init(&mutex, NULL);
}
Mutex::~Mutex()
{
  pthread_mutex_destroy(&mutex);
}
void Mutex::P() 
{
 pthread_mutex_lock(&mutex);
}
void Mutex::V() 
{
 pthread_mutex_unlock(&mutex);
}

Semaphore::Semaphore()
{
  lock = new pthread_mutex_t();
  cond = new pthread_cond_t();
  size = -1;
  pthread_mutex_init(lock, NULL);
  pthread_cond_init(cond, NULL);
}
Semaphore::~Semaphore()
{
  pthread_mutex_destroy(lock);
  pthread_cond_destroy(cond); 
}
void Semaphore::P(void ** data, int * length, char ** channel) 
{
  pthread_mutex_lock(lock);
  if (this->size == -1)
    pthread_cond_wait(cond, lock);
  *data = this->data;
  *length = this->size;
  *channel = this->channel;
  size = -1;
  pthread_mutex_unlock(lock);
}
void Semaphore::V(void * data, int length, char * channel)
{ 
  pthread_mutex_lock(lock);
  this->data = data; 
  this->size = length;
  this->channel = channel;
  pthread_cond_signal(cond);
  pthread_mutex_unlock(lock);
}
