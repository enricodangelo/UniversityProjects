#ifndef SEMAPHORE_H
#define SEMAPHORE_H

class Mutex 
{
   public:
      Mutex();
      /** 
       * Reset the mutex 
       */
      void Init();
      ~Mutex();
      /** 
       * Passeren
       */
      void P();
      /** 
       * Verhogen
       */
      void V();
   private: 
      pthread_mutex_t mutex;
 
};
class Semaphore
{
  public:
    Semaphore();
    ~Semaphore();
    void P(void ** data, int * length, char ** channel);
    void V(void * data, int length, char * channel);
  private:
    void * data;
    int size;
    char * channel;
    pthread_mutex_t * lock;
    pthread_cond_t * cond;
};

#endif
