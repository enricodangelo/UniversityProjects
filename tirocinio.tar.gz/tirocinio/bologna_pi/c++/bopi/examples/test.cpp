/***************************************************************************
                         test.cpp  - A simple API tester
                            -------------------
   begin                : Mon Jan 20 2004
   copyright            : (C) 2003 by Samuele Carpineti
   email                : carpinet@cs.unibo.it
***************************************************************************/

/***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************/

#include <iostream>
#include <string>
#include <unistd.h>
#include <assert.h>
#include <exception>
#include "../bopi.h"
using namespace std;
using namespace bopi;
/**
 * This test creates two channels and after a reaction on the second
 * it deletes both. The message used for the reaction contains plenty of
 * separators only for testing the channel manager.
 */
bool test1()
{
  for(int i = 0; i < 10; i++)
  {
    Channel x;
    new_chan(&x); 
    Channel y; 
    new_chan(&y);
    void * data;
    int length;
    const char * msg = "hello\r\n\r\n\n\r\n\rworld\r\n\r\n";
    y.asnd((const void *)msg, strlen(msg));
    y.asnd((const void *)msg, strlen(msg));
    y.rcv(&data, &length);
    if (strncmp(msg,(char *)data,strlen(msg)) !=0) 
      return false ;
    delete_chan(x);
    delete_chan(y);
  }
  return true; 
}
/**
 * This test creates two local channels and one remote (also if the
 * channel manager is located at 127.0.0.1:2048). After that a sum on
 * these three channels is performed. A reaction must happen on a local
 * channel so an undo linear forwarder need to be created. 
 */
bool test2()
{
  for(int i = 0; i < 10; i++)
  {
    Channel z;
    new_chan(&z, "192.168.0.111", 2048);
    Channel x;
    new_chan(&x);
    Channel y; 
    colocated_at(x,&y);
    void * data;
    int length;
    z.asnd((const void *)"hello", 5);
    vector<Channel> ch; 
    ch.push_back(x);
    ch.push_back(y);
    ch.push_back(z);
    int i = BolognaPi::select(ch, &data, &length);
    assert(i==2);
    if (i != 2) 
      return false;
    if (strncmp("hello",(char *)data,5) != 0)
      return false;
    delete_chan(x);
    delete_chan(y);
    delete_chan(z);
  }
  return true; 
}


/**
 * This test uses synchronous send and receive
 */
void * foo(void * chan)
{
  pthread_t id = pthread_self();
  pthread_detach(id);
  Channel * c = (Channel *) chan;
  const char * msg = "hello\0";
  pthread_yield();
  c->snd(msg,strlen(msg));
  pthread_exit(0);
}
bool test3()
{
  int i;
  void * msg;
  int length;
  Channel c;
  new_chan(&c);
  pthread_t p;
  pthread_create(&p, NULL, foo ,(void *)(&c));
  c.rcv(&msg, &length);
  if (strncmp("hello\0",(char *)msg,6)==0)
    return true;
  else 
    return false;
  delete_chan(c);
  return true; 
}

/**
 * Testing conditional channel constructor
 */
bool test4()
{
 Channel x;
 new_chan(&x);
 Channel y;
 get_ref(&y, x.name);
 try
 {
   //x cannot exist in the passed location
  Channel z;
  get_ref(&z, x.name, "192.168.0.111", 2048);
  return false;
 }
 catch (ChannelNotFound){}
 const char * msg = "hello"; 
 void * data;
 int length;
 Channel z;
 new_chan(&z, "192.168.0.111", 2048);
 Channel t(z);
 Channel w;
 get_ref(&w, t.name);
 z.asnd((const void *)msg, strlen(msg));
 w.rcv(&data, &length);
 if (strncmp(msg,(char *)data, length) != 0) 
   return false;
 free(data);
 y.asnd((const void *)msg, strlen(msg));
 x.rcv(&data, &length);
 if (strncmp(msg,(char *)data, length) != 0) 
   return false;
 free(data);
 Channel k(x);
 k.asnd((const void *)msg, strlen(msg));
 x.rcv(&data,&length);
 if (strncmp(msg,(char *)data, length) != 0) 
   return false;
 free(data);
 delete_chan(x);
 delete_chan(k);
 delete_chan(y);
 return true;
}
/**
 * Testing typed channels
 */
bool test5()
{
  //int channel
  TChannel<int> x;
  new_chan(&x);
  x.asnd(9);
  int v = x.rcv();
  if (v!=9) return false;
  cout << "IntChannel ok" << endl;
  //bool channel
  TChannel<bool> z;
  new_chan(&z);
  z.asnd(9);
  bool b = z.rcv();
  if (!b) return false;
  cout << "BoolChannel ok" << endl;
  //string channel
  TChannel<string> y;
  new_chan(&y);
  y.asnd("Hello wonderful world");
  string s = y.rcv();
  if (strncmp(s.c_str(),"Hello wonderlful world",s.length()!=0)) 
      return false;
  cout << "StringChannel ok" << endl;
  //channel channel
  TChannel< TChannel<int> > w;
  new_chan(&w);
  w.asnd(x);
  TChannel<int> k = w.rcv();
  x.asnd(100);
  int r = k.rcv();
  if (r != 100) return false;
  cout << "ChannelChannel ok" << endl;
  delete_chan(x);
  delete_chan(y);
  delete_chan(w);
  delete_chan(z);
  return true;
}
/**
 * Testing sum with one remote channel missing. 
 * Case 1: the sum go on becuase there are some available channels
 * Case 2: the sum cannot go on because all the channels are not available
 */
bool test6()
{
  Channel z;
  new_chan(&z, "192.168.0.111", 2048);
  delete_chan(z);
  void * data;
  int length;
  try
  {
    z.rcv(&data, &length);
    return false;
  }
  catch (ChannelNotFound){}
  try
  {
    z.snd("hello", 5);
    return false;
  }
  catch (ChannelNotFound){}
  Channel x;
  new_chan(&x, "192.168.0.111", 2048);
  Channel y; 
  new_chan(&y);
  x.asnd((const void *)"hello", 5);
  vector<Channel> ch; 
  ch.push_back(x);
  ch.push_back(y);
  ch.push_back(z);
  int i; 
  i = BolognaPi::select(ch, &data, &length);
  if (i != 0) return false;
  if (strncmp("hello",(char *)data,5) != 0)
    return false;
  free(data);
  delete_chan(x);
  delete_chan(y);
  i = BolognaPi::select(ch, &data, &length);
  if (i != -1) return false;
  try
  {
    x.snd((const void *)"hello", 5);
    return false;
  }
  catch (ChannelNotFound){} 
  Channel w; 
  new_chan(&w);
  ch.push_back(w);
  pthread_t p;
  pthread_create(&p, NULL, foo ,(void *)(&w));
  i = BolognaPi::select(ch, &data, &length);
  if (i != (ch.size()-1)) return false;
  if (strncmp("hello\0",(char *)data,6) != 0)
    return false;
  free(data);
  delete_chan(w);
  return true;
}

bool test7()
{
  Channel x;
  new_chan(&x, "192.168.0.111", 2048); 
  if (fork() == 0)
  {
    if (BolognaPi::initAPI(2048) == -1) return -1;
    x.snd((const void *)"hello\0", 6);
    BolognaPi::exitAPI();
    exit(0);
  }
  else 
  {
    Channel y; 
    new_chan(&y);
    vector<Channel> ch; 
    ch.push_back(x);
    ch.push_back(y);
    void * data;
    int length;
    int i = BolognaPi::select(ch, &data, &length);
    assert(strncmp((char *)data, "hello\0", 6)==0);
    assert(i==0);
  }
}
bool test8()
{
  TChannel<int> x;
  new_chan(&x, "192.168.0.111", 2048);
  if (fork() == 0)
  {
    BolognaPi::reinitAPI();
    x.snd(6);
    BolognaPi::exitAPI();
    exit(0);
  }
  else 
  {
    int v = x.rcv();
    if (v != 6) return false;
  }
  return true;
}
bool test9()
{
  TChannel<int> x;
  TChannel<int> y;
  new_chan(&x);
  new_chan(&y);
  if (fork()==0)
  {
    BolognaPi::reinitAPI();
    y.asnd(100);
    BolognaPi::exitAPI();
    exit(0);
  }
  vector< TChannel<int> > chans;
  chans.push_back(x);
  chans.push_back(y);
  int v;
  int res = BolognaPi::select(chans, &v);
  if (v != 100) return false;
  return true;
}
int main()
{
  if (BolognaPi::initAPI(2047) == -1) return -1;
  try
  {
    if (test1()) cout << "Test1 ok!" << endl;
    else cout << "Test1 failed" << endl;
    if (test2()) cout << "Test2 ok!" << endl;
    else cout << "Test2 failed" << endl;
    if (test3()) cout << "Test3 ok!" << endl;
    else cout << "Test3 failed" << endl;
    BolognaPi::exitAPI();
    try
    {
      test4();
      cout << "Test4 failed" << endl;
    }
    catch (API_Exception) //API is closed now
    {
      cout << "Test4 ok!" << endl;
    }
    if (BolognaPi::initAPI(2047) == -1) return -1;
    if (test4()) cout << "Test5 ok!" << endl;
    else cout << "Test5 failed" << endl;
    if (test5()) cout << "Test6 ok!" << endl;
    else cout << "Test6 failed" << endl;
    if (test6()) cout << "Test7 ok!" << endl;
    else cout << "Test7 failed" << endl;
    if (test7()) cout << "Test8 ok!" << endl;
    else cout << "Test8 failed" << endl;
    if (test8()) cout << "Test9 ok!" << endl;
    else cout << "Test9 failed" << endl;
    if (test9()) cout << "Test10 ok!" << endl;
    else cout << "Test10 failed" << endl;


  }
  catch (CMNotFound& nf)
  {
    cout << nf.what() << endl;
  }
  catch (NetworkError& ne)
  {
    cout << ne.what() << endl;
  }
  catch (ChannelNotFound& notf)
  {
    cout << notf.what() << endl;
  }
  catch (API_Exception& ae)
  {
    cout << ae.what() << endl;
  }
  BolognaPi::exitAPI();
  return 1;
}
