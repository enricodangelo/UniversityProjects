/***************************************************************************
                      game.cpp  -  A simple example 
                            -------------------
   begin                : Mon Jan 5 2004
   copyright            : (C) 2003 by Samuele Carpineti
   email                : carpinet@cs.unibo.it
***************************************************************************/

/***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************/
#include <unistd.h>
#include <string>
#include <utility>
#include <signal.h>
#include "../bopi.h"
using namespace std;
using namespace bopi;
/**
 * In this game there are n players and they run until they become tired.
 * They send periodically to the parent a message "I'm dead" or "I'm alive". The
 * parent looks at this message and it waits until all processes dead.
 */

typedef TChannel< pair<int, int> > GameChannel; //it contain a pid and a message
const int ALIVE = 1;
const int DEAD = 0;
const int GOON = 2;
const int PLAYERS = 10;
int STATUS[PLAYERS];
int RUNNER[PLAYERS];

void status_print(int signal)
{
  cout << "--------------------------------------------" << endl;
  int k = 0;
  for (int j = 0; j < PLAYERS; j++)
    if (STATUS[j] == ALIVE)
    {
      cout << RUNNER[j] << " = ALIVE" << endl;
      k++;
    }
  cout << "ALIVE = " << k << endl;
  cout << "--------------------------------------------" << endl;
  return;
}

bool play(GameChannel heart)
{
  const int ALIVE = 1;
  const int DEAD = 0;
  bool tired;
  cout << "player = " << getpid() << endl;
  srandom(getpid());
  do
  {
    heart.snd(make_pair(getpid(),ALIVE));
    int v = random(); 
    tired = ( v < (RAND_MAX / 10));
    sleep(v%3);
  }
  while (!tired);
  heart.snd(make_pair(getpid(),DEAD));
}

int main()
{
  if (BolognaPi::initAPI(2047)==-1)
    return 0;
  vector<GameChannel> links(PLAYERS);
  TChannel<GameChannel> x;
  TChannel<int> start_game;
  new_chan(&x);
  new_chan(&start_game);
  for(int i = 0; i < PLAYERS; i++)
  {
    int pid;
    if ((pid = fork()) == 0)
    {
      signal(SIGINT, SIG_IGN);
      BolognaPi::reinitAPI();
      GameChannel game_channel = x.rcv();
      start_game.rcv();
      play(game_channel);
      BolognaPi::exitAPI();
      exit(0);
    }
    RUNNER[i] = pid;
    //sending a GameChannel to the player
    new_chan(&links[i]);
    x.asnd(links[i]);
  }
  int running = PLAYERS;
  int index;
  char any;
  cout << "Press Any key to start "; 
  cin >> any;
  signal(SIGINT, status_print);
  for(int i = 0; i < PLAYERS; i++) 
  {
    STATUS[i] = ALIVE;
    start_game.asnd(0);
  }
  while (running > 0)
  {
    pair<int,int> msg;
    if ((index = BolognaPi::select(links, &msg))== -1)
      break;
    if (msg.second == DEAD)
    {
      running--;
      STATUS[index] = DEAD;
      if (running == 0)
        cout << "\nWINNER-PID = " << msg.first << endl; 
    }
  }
  for(int i = 0; i < PLAYERS; i++) delete_chan(links[i]);
  BolognaPi::exitAPI();
  return 0;
}
