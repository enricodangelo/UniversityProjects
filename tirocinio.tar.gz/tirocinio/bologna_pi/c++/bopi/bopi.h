/***************************************************************************
                         bopi.h  -  BolognaPi Header file
                            -------------------
   begin                : Mon Jan 5 2004
   copyright            : (C) 2003 by Samuele Carpineti
   email                : carpinet@cs.unibo.it
***************************************************************************/

/***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************/

#ifndef BOPI_H
#define BOPI_H

#include <map>
#include <list>
#include <vector>
#include <exception>
#include <sstream>
#include <iostream>
#include <ostream>
#include <stdio.h>
#include "../util/socketwr.h"
#include "semaphore.h"

using namespace std;
namespace bopi
{

  /**
   * This exception is thrown when the api is not initialized and some operation
   * that requires initialization is called
   */
  class API_Exception:exception 
  {
    public:
      ~API_Exception() throw() {}
      API_Exception(){}
      const char * what()
      {
        return "API need to be initialized";
      }
  };
  /**
   * This exception is thrown when a channel manager cannot be found in a
   * location
   */
  class CMNotFound:exception
  {
    private:
      const char * ip;
      int port;
    public:
      ~CMNotFound() throw() {}
      CMNotFound(const char * ip, int port)
      {
        this->ip = ip;
        this->port = port;
      }
      const char * what()
      {
        stringstream ost;
        ost << "Channel Manager not found in " << ip << ':' << port;
        return ost.str().c_str();
      }
  };
  /**
   * This exception is thrown when an error occurs reading or writing in a socket
   */
  class NetworkError:exception
  {
    private:
      string s;
    public:
      ~NetworkError() throw (){}
      NetworkError(const char * msg)
      {
        s = msg;
      }
      NetworkError(const char * ip, int port)
      {
        s = ip;
        char buf[6];
        memset((void *)buf, 6, 0);
        printf(buf, "%d", port);
        s += buf;
      }
      const char * what()
      {
        return s.c_str();
      }
  };
  /**
   * A channel cannot be found as expected
   */
  class ChannelNotFound:exception
  {
    string channel;
    public:
      ChannelNotFound() throw() {}
      ChannelNotFound(const char * name)
      {
        channel = name;
      }
      ~ChannelNotFound() throw (){}
      string inline get_name(){return channel;}
      const char * what()
      {
        return "Channel not found";
      }
  };

  /**
   * This function checks is a channel manager is running on ip:port sending an
   * PING message.  
   * @return a file descriptor for the CM or -1 if there is not a CM on ip:port
   * @exception NetworkError if an error occurs reading/writing the socket
   * established with ip:port
   */
  int try_local_CM(const char * ip, int port) throw (NetworkError);
  /**
   * This function checks is a channel manager is running on ip:port sending an
   * HELO message. The local|remote CM responds with HELO followed by the ip used
   * to generate intarnal names. This function consumes only "HELO\r\n" so the
   * caller finds on the returned socket the rest of the CM message.
   * @return a file descriptor for the CM or -1 if there is not a CM on ip:port
   * @exception NetworkError if an error occurs reading/writing the socket
   * established with ip:port
   */
  int try_remote_CM(const char * ip, int port) throw (NetworkError);
  /**
   * A connection with a channel manager keep the socket file descriptor, the
   * address and the port where the channel manager is listening
   */
  struct CM_connection
  {
    ~CM_connection(){socket_shutdown(fp);};
    FILE * fp;
    const char * ip;
    int port;
  };
  /**
   * This class is activated starting one thread that executes the run method.
   * So it reads messages from local/remote channel managers and unblocks
   * local threads.
   */
  class Worker 
  {
    private:
      /** 
       * Connection with the local Channel Manager
       */
      CM_connection CM_conn;
      /**
       * Permanent socket with the local Channel Manager
       */
      int fd;
      /** 
       * Sequence number used to create local continuations 
       */
      int seq_no;
      /**
       * A map from int to semaphore is used becuase send directly pointer on the
       * net is too much dangerous 
       */
      map<int, Semaphore *> lc;
      
      Mutex mutex;
    
    public:
      Worker():seq_no(0){}
      ~Worker();
      
      /** 
       * This method initializes the worker connection with the local Channel Manager     
       */
      void start(int port, CM_connection& conn, vector<string>& local_names) throw (NetworkError,CMNotFound);
      /**
       * This method can be used to add one entry to the local continuations table
       * @param s: a semaphore that will be unblocked when a continuation id is received
       * @return the continuation-id 
       */
      int getId(Semaphore * s);
      /**
       * Invoking this method the Worker starts to read messages from the local
       * channel manager. It should be invoked in a separate thread becuase it
       * uses an infinite loop.
       */
      void run();
      /**
       * Stop the worker thread.
       */
      void stop();
  };

  struct ltaddr 
  {
    bool operator()(pair<const char*, int> p1, pair<const char *, int>p2) const
    {
      return ((strcmp(p1.first,p2.first)<0) && (p1.second<p2.second));
    }
  };

  /** 
   * Channel 
   */
  class Channel
  {
    friend class BolognaPi;
    protected:
    public: 
      
      BolognaPi * getBopiInstance() const throw (API_Exception); 
      string name;
      /** 
       * The default contructor does not create a channel into the local channel
       * manager
       */
      Channel(){}
      /** 
       * Copy constructor 
       */
      Channel(const Channel& chan);
      /** This method creates a channel in a remote location
       * @param ip: the remote CM ip address
       * @param port: the remote CM port
       * @exception API_Exception if the API is not initilized
       * @exception CMNotFound if there is not a CM on ip:port
       * @exception NetworkError if an error occurs communicating with the remote
       * channel manager
       */
      Channel(string ip, int port) throw (API_Exception,CMNotFound, NetworkError); 
      /**
       * This method does not create a new channel in the CM but 
       * instances the object by using another channel passsed as arguments
       * @param the channel name (can be remote or local)
       * @exception API_Exception if the API is not initilized
       * @exception ChannelNotFound if the channel does not exist 
       */
      Channel(string name) throw (API_Exception,ChannelNotFound);
      /**
       * This method does not create a new channel in the CM reachable by using
       * ip:port but instances the object by using the channel name passsed 
       * as arguments (if it exists in the remote channel manager) 
       * @param the channel name (can be remote or local)
       * @exception API_Exception if the API is not initilized
       * @exception ChannelNotFound if the channel is not present at the passed
       * location
       * @exception CMNotFound if there is not a CM on ip:port
       * @exception NetworkError if an error occurs communicating with the remote CM
       */
      Channel(string name, string ip, int port) throw (API_Exception, ChannelNotFound, CMNotFound, NetworkError);
      Channel& operator=(const Channel& ch){name = ch.name;}
      /** 
       * Default destructor (does not erase the channel from the channel manager)
       */
      ~Channel(){}
      /**
       * Synchronous send
       * @param data: message to send
       * @param length: message size
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the remote channel manager where the channel is
       * located
       * @exception CMNotFound if there is not a channel manager listening for the
       * passed channel
       */
      void snd(const void * data, int length) throw (NetworkError,CMNotFound,ChannelNotFound);
      /**
       * Asynchronous send
       * @param data: message to send
       * @param length: message size
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the remote channel manager where the channel is
       * located
       * @exception CMNotFound if there is not a channel manager listening for the
       * passed channel
       */
      void asnd(const void * data, int length) throw (NetworkError,CMNotFound);
      /** 
       * Synchronous receive. 
       * @param data: a buffer (allocated inside the method) where place the
       * received data (users should free data)
       * @param length: a reference to an integer that can be used to store the
       * buffer size
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the remote channel manager where the channel is
       * located
       * @exception CMNotFound if there is not a channel manager listening for the
       * passed channel
       */
      void rcv(void ** data, int * length) throw (NetworkError,CMNotFound,ChannelNotFound);
      /**
       * This method serializes a channel
       */
      friend ostream & operator << (ostream& os, const Channel& c)
      {
        os << c.name;
        return os;
      }
      /**
       * This method reads a channel from a stream
       */
      friend istream & operator >> (istream& is, Channel& c)
      {
        is >> c.name;
      }
  };
  
  /** 
   * Default serialization function 
   */
  template<typename _Obj> struct default_write
  {
    void inline operator()(const _Obj& value, ostream& os)
    {
      os << value;
    }
  };
  
  /** 
   * Default de-serialization function 
   */
  template<typename _Obj> struct default_read
  {
    void inline operator()(_Obj& obj, istream& is){is >> obj;} 
  };
  template<class _T1, class _T2> ostream& operator<< (ostream& os, const pair<_T1, _T2>& p) 
  {
    os << p.first << "\n" << p.second;
    return os;
  } 
  template<class _T1, class _T2> istream& operator>> (istream& is, pair<_T1, _T2>& p)
  {
    is >> p.first;
    is >> p.second;
    return is;
  }
  /**
   * A typed channel is a template where you must specify the object that can be
   * sent on it, and where you can specify the serialization and
   * de-serialization functions used to send/read objects. 
   */
  template<typename _ValueType, 
           typename _Write = default_write<_ValueType>, 
           typename _Read = default_read<_ValueType> > 
  class TChannel: public Channel
  {
      friend class BolognaPi;
      /**
       * This method serializes a typed channel
       */
      friend ostream & operator << (ostream& os, const TChannel<_ValueType>& c)
      {
        os << c.name;
        return os;
      }
      /**
       * This method reads a channel from a stream
       * @exception API_Exception if the API is not initilized
       */
      friend istream & operator >> (istream& is, TChannel<_ValueType>& c) throw (API_Exception)
      {
        is >> c.name;
      }
    private:
      void inline serialize(const _ValueType& msg, ostream& os)
      {
        _Write()(msg, os);
      }
      void inline deserialize(_ValueType& msg, istream& is)
      {
        _Read()(msg, is);
      }
    public:
      template<class T> TChannel<T>& operator=(const TChannel<T>& chan)
      {
        name = chan.name;
      }
      template<class T> TChannel(const TChannel<T>& chan)
      {
        name = chan.name;
      }
      TChannel(){}
      void snd(const _ValueType& msg) throw (NetworkError,CMNotFound,ChannelNotFound)
      {
        stringstream s;
        stringstream s1;
        char c;
        this->serialize(msg,s);
        int n = 0;
        while (s.readsome(&c,1) != 0)
        {
          s1 << c;
          n++;
        }
        char buf[n];
        s1.read(buf,n);
        Channel::snd(buf, n);
      } 
      void asnd(const _ValueType& msg) throw (NetworkError,CMNotFound,API_Exception)
      {
        stringstream s, s1;
        char c;
        this->serialize(msg,s);
        int n = 0;
        while (s.readsome(&c,1) != 0)
        {
          s1 << c;
          n++;
        }
        char buf[n];
        s1.read(buf,n);
        Channel::asnd(buf, n);
      }
      _ValueType rcv() throw (NetworkError,CMNotFound,ChannelNotFound)
      {
        _ValueType value;
        void * data;
        int length;
        Channel::rcv(&data, &length);
        stringstream s;
        s.write((char *)data, length);
        this->deserialize(value, s);
        return value;
      }
  };
  /**
   * This class implements the Bologna-PI  API for synchronous communications using local or
   * remote channels. In particular it allows to interact with local and  remote channel managers
   * and to use pi-like command like send, receive and input sum. This API is reentrant.
   */
  class BolognaPi
  {
    friend class Channel; //Channel can ask for an instance;
    /** 
     * This function deletes a channel from the local channel manager
     * @param chan: the channel to delete
     */
    friend void delete_chan(const Channel& chan)
    {
      chan.getBopiInstance()->delete_ch(chan.name);
    }
    /**
     * This function creates a new channel in the local channel manager and
     * store the result in chan
     * @param chan: a pointer to a channel where store the creation result
     * @exception API_Exception if the API is not initilized
     */
    friend void new_chan(Channel * chan) throw (API_Exception)
    {
      chan->name = chan->getBopiInstance()->new_ch();
    }
    /**
     * This function creates a new channel in the channel manager specified
     * through <ip:port> and it stores the result in chan
     * @exception API_Exception if the API is not initilized
     * @exception CMNotFound if there is not a channel manager in <ip:port>
     */
    friend void new_chan(Channel * chan, string ip, int port) throw (API_Exception,CMNotFound)
    {
      chan->name = chan->getBopiInstance()->new_ch(ip.c_str(), port);
    }
    /**
     * This function creates a reference to an existing channel and it stores
     * the result in chan
     * @param chan: a pointer to a channel where store the creation result
     * @param name: the name of an existing channel
     * @exception API_Exception if the API is not initilized
     * @exception CMNotFound if there is not a channel manager for 'name'
     * @exception ChannelNotFound if a channel called 'name' cannot be found
     */
    friend void get_ref(Channel * chan, string name) throw (API_Exception,CMNotFound,ChannelNotFound)
    {
      if (chan->getBopiInstance()->exists(name)) 
        chan->name = name;
      else throw ChannelNotFound();
    }
    /**
     * This function creates a reference to an existing channel in <ip:port> and 
     * it stores the result in chan
     * @param chan: a pointer to a channel where the fucntion stores the creation result
     * @param name: the name of an existing channel
     * @param ip: the remote CM ip address
     * @param port: the remote CM port
     * @exception API_Exception if the API is not initilized
     * @exception CMNotFound if there is not a channel manager for 'name'
     * @exception ChannelNotFound if a channel called 'name' cannot be found
     */
    friend void get_ref(Channel * chan, string name, string ip, int port) 
      throw (API_Exception,CMNotFound,ChannelNotFound)
    {
      if (chan->getBopiInstance()->rmt_exists(name, ip, port)) 
        chan->name = name;
      else throw ChannelNotFound();
    }
    /**
     * This function creates a channel colocated to another channel (in the same
     * channel manager)
     * @param chan: the existing channel
     * @param dest: the channel where the function stores the result 
     * @exception API_Exception if the API is not initilized
     * @exception CMNotFound if there is not a channel manager for 'name'
     * @exception ChannelNotFound if the channel is not found
     */
    inline friend void colocated_at(Channel& chan, Channel * dest) 
      throw (API_Exception,CMNotFound,ChannelNotFound)
    {
      return new_chan(dest, get_ip(chan.name.c_str()), get_port(chan.name.c_str()));
    }
     /**
     * This function creates a channel colocated to another channel (in the same
     * channel manager)
     * @param chan: the existing channel
     * @param dest: the channel where the function stores the result 
     * @exception API_Exception if the API is not initilized
     * @exception CMNotFound if there is not a channel manager for 'name'
     * @exception ChannelNotFound if the channel is not found
     */
    template<class T> inline friend void new_chan(TChannel<T>& chan, TChannel<T> * dest) 
      throw (API_Exception, CMNotFound, ChannelNotFound)
    {
      return colocated_at(static_cast<Channel *>(chan),dest);
    }
     /**
     * This function creates a new channel in the channel manager specified
     * through <ip:port> and it stores the result in chan
     * @exception API_Exception if the API is not initilized
     */
    template<class T> inline friend void new_chan(TChannel<T> * chan) throw (API_Exception)
    { 
      new_chan(static_cast<Channel *>(chan));
    }
    /**
     * This function creates a reference to an existing channel in <ip:port> and 
     * it stores the result in chan
     * @param chan: a pointer to a channel where the fucntion stores the creation result
     * @param name: the name of an existing channel
     * @param ip: the remote CM ip address
     * @param port: the remote CM port
     * @exception API_Exception if the API is not initilized
     * @exception CMNotFound if there is not a channel manager for 'name'
     * @exception ChannelNotFound if a channel called 'name' cannot be found
     */
    template<class T> inline friend void new_chan(TChannel<T> * chan, string ip, int port)
      throw (API_Exception,CMNotFound)
    {
      new_chan(static_cast<Channel *>(chan), ip, port);
    }
     /**
     * This function creates a reference to an existing channel and it stores
     * the result in chan
     * @param chan: a pointer to a channel where store the creation result
     * @param name: the name of an existing channel
     * @exception API_Exception if the API is not initilized
     * @exception CMNotFound if there is not a channel manager for 'name'
     * @exception ChannelNotFound if a channel called 'name' cannot be found
     */
    template<class T> inline friend void get_ref(TChannel<T> * chan, string name) 
      throw (API_Exception,CMNotFound,ChannelNotFound)
    {
      get_ref(static_cast<Channel *>(chan), name);
    }
    /**
     * This function creates a reference to an existing channel in <ip:port> and 
     * it stores the result in chan
     * @param chan: a pointer to a channel where the fucntion stores the creation result
     * @param name: the name of an existing channel
     * @param ip: the remote CM ip address
     * @param port: the remote CM port
     * @exception API_Exception if the API is not initilized
     * @exception CMNotFound if there is not a channel manager for 'name'
     * @exception ChannelNotFound if a channel called 'name' cannot be found
     */
    template<class T> inline friend void get_ref(TChannel<T> * chan, string name, string ip, int port) 
      throw (API_Exception,CMNotFound,ChannelNotFound)
    {
      get_ref(static_cast<Channel *>(chan), name, ip, port);
    }
    private:
      /** 
       * Shared thread that communicates with the local channel manager. 
       */
      static Worker * worker;
      static pthread_t worker_thread_id;
      /**
       * This method is used to reset/save all the significant fields that 
       * can be inherited from child in fork. This handler is called at each 
       * fork. 
       */
      static void child_handler();
      /**
       * This handler is called at each fork into the parent. 
       */
      static void parent_handler();
      /**
       * This function returns a channel name to use as input proxy (linear
       * forwader). For the moment this is implemented by calling new_ch but 
       * we can think also to a different implementation that reuse old linear
       * forwarder
       */
      string get_linear_fwd();
      /** 
       * This function frees a linear forwader. For the moment it deletes the
       * channel.
       */
      void del_linear_fwd(string fwd);
      /**
       * This function returns a channel to use as output proxy.  For the moment
       * it is implemented by calling new_ch but we can think also to a 
       * different implementation that reuse old proxies
       */
      string get_output_proxy();
      /** 
       * This function frees an output proxy. For the moment it deletes the
       * channel.
       */
      void del_output_proxy(string out_proxy);
      /** 
       * This function creates a connection with a remote Channel Manager
       * @param ip: the Channel Manager ip-address
       * @param port: the Channel Manager port
       * @return a stream associated to <ip:port>
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the channel manager
       * @exception CMNotFound if there is not a channel manager listening on the
       * specified address
       */
      FILE * get_CM_connection(const char * ip, int port) throw (NetworkError, CMNotFound);
      /**
       * This function deletes a connection
       * @param conn: the connection to delete
       * @return -1 on error
       */
      int close_CM_connection(const char * ip, int port);
      /** 
       * Reliable connection shutdown (the connection is closed only when the
       * receiver reads all the data)
       * @param conn: the connection to close
       * @return -1 on error, 0 on success
       */
      int shutdown_CM_connection(const char * ip, int port);
      /**
       * The connection can be deleted
       * @param ip
       * @param port
       */
      void free_CM_connection(const char * ip, int port);
      /**
       * Synchronous/Asynchronous send
       * @param channel: channel where you want to send data
       * @param data: message to send
       * @param length: message size
       * @param sync: true syncronous call, false asynchronous call
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the remote channel manager where the channel is
       * located
       * @exception CMNotFound if there is not a channel manager listening for
       * the passed channel
       * @exception ChannelNotFound if channel cannot be found
       */ 
      void snd(string channel, const void * data, int length, bool synchronous) throw (NetworkError, CMNotFound, ChannelNotFound);
      /**
       * Asynchronous send
       * @param channel: channel where you want to send data
       * @param data: message to send
       * @param length: message size
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the remote channel manager where the channel is
       * located
       * @exception CMNotFound if there is not a channel manager listening for the
       * passed channel
       */
      void asnd(string channel, const void * data, int length) throw (NetworkError,CMNotFound); 
      /**
       * Synchronous send
       * @param channel: channel where you want to send data
       * @param data: message to send
       * @param length: message size
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the remote channel manager where the channel is
       * located
       * @exception CMNotFound if there is not a channel manager listening for the
       * passed channel
       * @exception ChannelNotFound if channel cannot be found
       */
      void snd(string channel, const void * data, int length) throw (NetworkError,CMNotFound, ChannelNotFound);
      /**
       * Synchronous input sum.  
       * @param chans: a list of channels where you want to wait for data
       * @param data: a buffer (allocated inside the method) where place the
       * received data
       * @param length: a pointer to an integer that can be used to store the
       * buffer size
       * @return the channel where the data is received or -1 if an error occurs
       * (the return value cannot be greater than the channels)
       * @exception API_Exception if there is not, in 'chans', one reachable channel  
       * @exception ChannelNotFound if channel cannot be found
       */
      int rcv(vector<string> chans, void ** data, int * length) throw (API_Exception,ChannelNotFound);
      
      /** 
       * Synchronous receive. 
       * @param chan: the input channel
       * @param data: a buffer (allocated inside the method) where place the
       * received data
       * @param length: a reference to an integer that can be used to store the
       * buffer size
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the remote channel manager where the channel is
       * located
       * @exception CMNotFound if there is not a channel manager listening for the
       * passed channel
       * @exception ChannelNotFound if channel cannot be found
       */
      void rcv(string channel, void ** data, int * length) throw (NetworkError,CMNotFound,ChannelNotFound);
      /**
       * Linear forwarder.
       * @param local: local input proxy
       * @param remote: remote channel
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the remote channel manager where the channel is
       * located
       * @exception CMNotFound if there is not a channel manager listening for the
       * remote channel
       */
      void fwd(string local, string remote) throw (NetworkError,CMNotFound);
      /** This method allows to create a new local channel 
        * @param ip: the remote channel manager ip_address where the channel 
        * should be created
        * @param port: the remote channel manager port where the channel 
        * should be created
        * @return an empty string on error, a valid channel name otherwise
        */
      string new_ch() throw (NetworkError); 
      /** This method allows to create a new channel in a remote location
        * @param ip: the remote channel manager ip_address where the channel 
        * should be created
        * @param port: the remote channel manager port where the channel 
        * should be created
        * @return an empty string on error, a valid channel name otherwise
        * @exception NetworkError if an i/o error occurs reading/writing from the
        * socket established with the remote channel manager where the channel is
        * located
        * throw CMNotFound if there is not a channel manager waiting on the passed
        * address
        */
      string new_ch(const char * ip, int port) throw (NetworkError, CMNotFound);
      /** 
       * This method allows to delete local and remote channels that become 
       * unreachable for other communications  
       * @param channel the name to delete
       * @exception NetworkError if an i/o error occurs reading/writing from the
       * socket established with the remote channel manager where the channel is
       * located
       * @exception CMNotFound if there is not a channel manager listening for the
       * passed channel
       */
      void delete_ch(string channel) throw (NetworkError, CMNotFound);
      /**
       * This function is used to determine if a channel is local or remote. The
       * channel name is a string "ip:port/#seq_no" .
       * @return true if the channel is local, false otherwise (the channel can be
       * not present in the CM also if true is returned because someone else can delete
       * the channel)
       */
      bool is_local(string chan);
       /**
       * This function is used to determine if the channel 'name' is allocated in 
       * the local channel manager. 
       * @return true if the channel exists in the local Channel Manager, 
       * false otherwise
       * 
       */ 
      bool lcl_exists(string name);
       /**
       * This function is used to determine if a channel 'name' is allocated in
       * the remote channel manager specified through <ip,port>. 
       * @return true if the channel exists in the local Channel Manager, 
       * false otherwise
       */ 
      bool rmt_exists(string chan, string ip, int port);
      /**
       * This function is used to determine if the channel 'name' is allocated in 
       * the channel manager that can be deduced by using the channel name. 
       * @return true if the channel exists in the Channel Manager, 
       * false otherwise
       */ 
      bool exists(string chan);
      /** 
       * A connection to the local channel manager. (No mutex is needed bacause it
       * is a readonly structure) 
       */
      static CM_connection CM_conn; //readlonly (no mutex)
      /**
       * This vector contains the ip addresses used by the local channel manager
       * to create new channels. (No mutex is needed becuase it is a readonly 
       * field)
       */
      static vector<string> local_names; //readonly (no mutex)
      static map<pair<const char *, int>, FILE *, ltaddr> CM_table;
      Mutex mutex_CM_table;
      static int users;
      static BolognaPi * singleton;
      static int port;
      static Mutex mutex_start; //it protects singleton, users, port, worker, worker_id
      /**
       * This method returns and BolognaPi object that need to be initilized before
       * starting communications
       * @return one BolognaPi instance 
       */
      static BolognaPi * getInstance();
      static void releaseInstance();
      BolognaPi();
      ~BolognaPi();
    public:
      /**
       * This method tries to establish a TCP/IP connection with the local channel
       * manager.
       * @param local_port: the local port where the channel manager is waiting
       * @return -1 on error (the channel manager is not found or it is imposiible
       * to open a connection whith it)
       * local channel manager
       */
      static int initAPI(int local_port);
      /**
       * This method reinitilized the API using the current value port (can be
       * used for child in fork) 
       */
      static void reinitAPI();
      /**
       * This method closes the local connection with the local channel manager.
       * The connection is effectively closed only when the API is not used by any
       * active thread.
       */
      static void exitAPI();
      /**
       * Synchronous input sum.  
       * @param chans: a list of channels where you want to wait for data
       * @param data: a buffer (allocated inside the method) where place the
       * received data
       * @param length: a reference to an integer that can be used to store the
       * buffer size
       * @return the channel where the data is received or -1 if an error occurs
       * (the return value cannot be greater than the channels)
       */
      static int select(vector<Channel> chans, void ** data, int * length);
      template<class T> static int select(vector< TChannel<T> > chans, T * result)
      { 
        if (singleton == NULL) return -1;
        else 
        {
          try
          { 
            void * data;
            int length;
            vector<string> channels;
            for (int i = 0; i < chans.size(); i++)
              channels.push_back(chans[i].name);  
            int index = singleton->rcv(channels, &data, &length);
            if (index == -1) return -1;
            stringstream s;
            s.write((char *)data, length);
            chans[index].deserialize(*result, s);
            return index;
          }
          catch (...)
          {
            return -1;
          }
        } 
      }
  };
};
#endif
