/***************************************************************************
                         bopi.cpp  -  BolognaPi Implementation
                            -------------------
   begin                : Mon Jan 5 2004
   copyright            : (C) 2003 by Samuele Carpineti
   email                : carpinet@cs.unibo.it
***************************************************************************/

/***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************/

#include <pthread.h>
#include <ostream>
#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <fcntl.h>
#include "bopi.h"

using namespace std;
using namespace bopi;

/***************************************************************************
 *  Helper functions implementation                                        *
 **************************************************************************/        
int bopi::try_remote_CM(const char * ip, int port) throw (NetworkError)
{
  int fd;
  if ((fd = open_socket(ip, port)) == -1)
    return -1;
  char * PING = "PING\r\n";
  if (socket_write(fd, PING, strlen(PING)) == -1)
  {
    throw NetworkError(ip, port);
  }
  char * answer = (char *)malloc(sizeof(char)*strlen(PING)+1);
  if (socket_read(fd, answer, strlen(PING)) == -1)
  {
    free(answer);
    throw NetworkError(ip, port);
  }
  if (strncmp(PING, answer, strlen(PING)) == 0) 
  {
    free(answer);
    return fd;
  }
  else return -1;
}
int bopi::try_local_CM(const char * ip, int port) throw (NetworkError)
{
  int fd;
  if ((fd = open_socket(ip, port)) == -1)
    return -1;
  char * HELO = "HELO\r\n";
  if (socket_write(fd, HELO, strlen(HELO)) == -1)
  {
    throw NetworkError(ip, port);
  }
  char * answer = (char *)malloc(sizeof(char)*strlen(HELO)+1);
  if (socket_read(fd, answer, strlen(HELO)) == -1)
  {
    free(answer);
    throw NetworkError(ip, port);
  }
  if (strncmp(HELO, answer, strlen(HELO)) == 0) 
  {
    free(answer);
    return fd;
  }
  else return -1;
}
/**************************************************************************
 *  Worker: methods implementation                                        *
 *************************************************************************/        
void Worker::start(int port, CM_connection& conn, vector<string>& local_names) 
throw (NetworkError, CMNotFound)
{
  mutex.P();
  //INADDR_LOOPBACK
  const char * localhost = "127.0.0.1";
  bool found = false;
  if ((this->fd = try_local_CM(localhost, port)) == -1) 
  {
    throw CMNotFound(localhost, port);
  }
  char * s = socket_readline(fd);
  if (s == NULL) throw CMNotFound(localhost,port);
  int num = atoi(s);
  free(s);
  for (int i = 0; i < num; i++)
  {
    s = socket_readline(fd);
    local_names.push_back(string(s));
    free(s); 
  }
  FILE * fp = fdopen(this->fd,"a+");
  CM_conn.fp = conn.fp = fp;
  if (!CM_conn.fp) throw NetworkError(localhost, port);
  CM_conn.port = conn.port = port;
  CM_conn.ip = conn.ip = "127.0.0.1";
  mutex.V();
}
void Worker::stop()
{
  //i can close directly the socket 
  const char * msg = "CLOSE\r\n";
  socket_write(fd, msg, strlen(msg));
  //this stop the thread at the next read operation on the socket
  socket_shutdown(fd); 
}
/**
 * The shared thread does not write on the channel manager socket 
 * it only reads messages and it unblocks local continuations
 */
void Worker::run()
{
  const int OK = 0;
  const int NOTFOUND = 1;
  char c;
  int id;
  int length;
  while (true)
  { 
    //code \r\n chname \r\n fp \r\n length \r\n data
    stringstream * response = new stringstream();
    char * code = socket_readline(fd);
    int return_code;
    if (code == NULL) break;
    else return_code = atoi(code);
    //cout << "Return Code " << return_code << endl;
    free(code);
    char * subject = socket_readline(fd);
    if (subject == NULL) break;
    //cout << "Read from the net - SUBJECT: " << subject << endl;
    char * tmp = socket_readline(fd);
    if (tmp == NULL) break;
    int id = atoi(tmp);
    free(tmp);
    //cout << "Read from the net - ID: " << id << endl;
    tmp = socket_readline(fd);
    if (tmp == NULL) break;
    int length = atoi(tmp);
    free(tmp);
    //cout << "Read from the net - LENGTH:" << length << endl;
    char * buf = (char *)malloc(sizeof(char)*(length + 1));
    if (length > 0)
      if (socket_read(fd, buf, length)== -1) break;
    buf[length] = '\0';
    //cout << "Read from the net (ERROR IF BINARY)- DATA " << buf << endl;
    map<int, Semaphore *>::iterator it;
    if ((it = lc.find(id)) != lc.end())
    {
      Semaphore * s = lc[id];
      lc.erase(it);
      if (return_code == 0)
        s->V((void *)buf, length, subject);
      else s->V((void *)buf, -1, subject);
    }
    else cerr << "Wrong Continuation" << id << endl;
    delete response;
  }
  //connection with the local channel manager is no more available
  pthread_exit(0); 
}

int Worker::getId(Semaphore * s)
{
  mutex.P();
  seq_no++;
  lc[seq_no] = s;
  mutex.V();
  return seq_no;
}


/***************************************************************************
 *    BolognaPi: methods implementation                                    *  
 **************************************************************************/
/**************************************************************************
 * NOTA BENE: Each method that needs to write on a socket does the operation 
 *            using only one "stream write". In fact POSIX standard requires 
 *            that C stdio FILE * operations are atomic. POSIX-conforming C 
 *            libraries (e.g, on Solaris and GNU/Linux) have an internal 
 *            mutex to serialize operations on FILE * so all the operation 
 *            in this file are thread-safe. 
 **************************************************************************/

//Static fields initialization
int BolognaPi::users(0);
int BolognaPi::port(-1);
BolognaPi * BolognaPi::singleton = NULL;
map<pair<const char *, int>, FILE *, ltaddr> BolognaPi::CM_table;
CM_connection BolognaPi::CM_conn;
vector<string> BolognaPi::local_names;
Worker * BolognaPi::worker = NULL;
pthread_t BolognaPi::worker_thread_id(0);
Mutex BolognaPi::mutex_start;


FILE * BolognaPi::get_CM_connection(const char * ip, int port) throw (NetworkError,CMNotFound)
{
  map<pair<const char *, int>, FILE *>::iterator it;
  mutex_CM_table.P();
  it = CM_table.find(make_pair(ip, port));
  mutex_CM_table.V();
  if (it != CM_table.end()) 
    return it->second;
  else
  {
    int conn = try_remote_CM(ip, port);
    if (conn != -1)
    {
      FILE * fp = fdopen(conn, "a+");
      if (!fp) throw NetworkError(ip, port);
      CM_table.insert(make_pair(make_pair(ip, port), fp));
      return fp;
    }
    else throw (CMNotFound(ip, port));
  }
}

int BolognaPi::close_CM_connection(const char * ip, int port)
{
  map<pair<const char *, int>, FILE *>::iterator it;
  mutex_CM_table.P();
  it = CM_table.find(make_pair(ip, port));
  if (it != CM_table.end())
    CM_table.erase(it);
  mutex_CM_table.V();
  return socket_shutdown(it->second);
}
void BolognaPi::free_CM_connection(const char * ip, int port)
{
  //nothing to do 
}
int BolognaPi::shutdown_CM_connection(const char * ip, int port)
{
  map<pair<const char *, int>, FILE *>::iterator it;
  mutex_CM_table.P();
  it = CM_table.find(make_pair(ip, port));
  if (it != CM_table.end())
  {
    CM_table.erase(it);
    mutex_CM_table.V();
    int n;
    if ((n = socket_shutdown(it->second, SHUT_WR)) == -1)
      return socket_close(it->second);
    else
    {
      char c;
      n = socket_read(it->second, &c, 1); //n should be 0
      socket_shutdown(it->second, SHUT_RD);
    }
    return n;
  }
  else mutex_CM_table.V();
  return -1;
}
string BolognaPi::get_linear_fwd()
{
  return this->new_ch();
}

void BolognaPi::del_linear_fwd(string lfwd)
{
  this->delete_ch(lfwd);
}

string BolognaPi::get_output_proxy()
{
  return this->new_ch();
}

void BolognaPi::del_output_proxy(string out_proxy)
{
  this->delete_ch(out_proxy);
}

void * worker_wrapper(void * worker) 
{
  pthread_t id = pthread_self();
  pthread_detach(id);
  Worker * w = reinterpret_cast<Worker *>(worker);
  w->run();   
}

BolognaPi::BolognaPi(){}

BolognaPi::~BolognaPi()
{
  map<pair<const char *, int>, FILE *>::iterator it;
  for (it = CM_table.begin(); it != CM_table.end(); it++)
  {
    socket_shutdown(it->second);
    CM_table.erase(it);
  }
  if (worker != NULL) worker->stop();
}
BolognaPi * BolognaPi::getInstance()
{
  return singleton;
}
void BolognaPi::parent_handler(){}
void BolognaPi::child_handler()
{
  users = 0;
  //port is not assigned to -1 because the old value is used in reinitAPI()
  singleton = NULL;
  CM_table.erase(CM_table.begin(),CM_table.end());
  local_names.erase(local_names.begin(),local_names.end());
  worker = NULL;
  worker_thread_id = 0;
  mutex_start.Init();
}
void BolognaPi::asnd(string channel, const void * data, int length) throw (NetworkError,CMNotFound)
{
  this->snd(channel, data, length, false);   
}
void BolognaPi::snd(string channel, const void * data, int length) throw (NetworkError,CMNotFound,ChannelNotFound)
{
  this->snd(channel, data, length, true);
}
void BolognaPi::snd(string channel, const void * data, int length, bool synchronous) throw (NetworkError,CMNotFound,ChannelNotFound)
{
  FILE * conn;
  ostringstream ost;
  string ack_chan;
  Semaphore * s;
  int id;
  const char * ip;
  int port;
  if (!this->is_local(channel))
  {
    ip = get_ip(channel.c_str()).c_str();
    port = get_port(channel.c_str());
    conn = get_CM_connection(ip, port);
    ost << "SNDRMT\r\n" << channel << "\r\n";
    if (synchronous)
    {
      ack_chan = this->get_output_proxy();
      ost << ack_chan;
    }
  }
  else
  {
    conn = CM_conn.fp;
    ost << "SNDLCL\r\n" << channel << "\r\n";
    if (synchronous)
    {
      s = new Semaphore();
      id = worker->getId(s);
      ost << id;
    }
  }  
  ost <<  "\r\n" << length << "\r\n";
  int size = ost.str().size();
  ost.write((const char *)data, length);
  if (socket_write(conn, ost.str().c_str(), length + size) == -1)
  {
    if (CM_conn.fp != conn) 
    {
      close_CM_connection(ip, port);
      string s = ip;
      throw NetworkError(s.c_str(), port);
    }
    else throw NetworkError(CM_conn.ip, CM_conn.port);
  }
  if (CM_conn.fp != conn)
    free_CM_connection(ip, port);    
  if (synchronous)
  { //data and size are useless for the moment
    void * ack;
    int size;
    if (!this->is_local(channel))
      rcv(ack_chan, &ack, &size);
    else if (this->is_local(channel))
    {
      void * data;
      int size;
      char * ch_name;
      s->P(&data, &size, &ch_name);
      delete s;
      free(ch_name);
      if (size == -1) throw ChannelNotFound(channel.c_str());
    }
  } 
}
void BolognaPi::rcv(string chan, void ** data, int * length) throw (NetworkError,CMNotFound,ChannelNotFound)
{
  ostringstream ost;
  if (this->is_local(chan))
  {   
    Semaphore * s = new Semaphore();
    int id = worker->getId(s);
    ost << "RCVLCL\r\n1\r\n" << chan << "\r\n" << id << "\r\n";
    const char * msg = ost.str().c_str();
    if (socket_write(CM_conn.fp, msg, strlen(msg)) == -1)
    {
      delete s;
      throw NetworkError(CM_conn.ip, CM_conn.port);
    }
    //the shared thread will call s->V(data,length) where data and length are
    //the data received from the channel manager
    char * chname;
    s->P(data, length, &chname);
    delete s;
    free(chname);
    if (*length == -1) throw ChannelNotFound(chan.c_str());
    return;
  }
  else 
  {
    //a linear forwarder is created 
    string ack_chan = this->get_linear_fwd();
    ost << "RCVRMT\r\n1\r\n" << chan << "\r\n" << ack_chan << "\r\n";
    const char * s = ost.str().c_str();
    const char * ip = get_ip(chan.c_str()).c_str();
    int port = get_port(chan.c_str());
    FILE * conn = get_CM_connection(ip, port);
    if (socket_write(conn, s, strlen(s)) == -1)
    {
      close_CM_connection(ip, port);
      throw NetworkError(ip, port);
    }
    free_CM_connection(ip, port);
    this->rcv(ack_chan, data, length);
    this->del_linear_fwd(ack_chan);
    return;
  }
}
void BolognaPi::fwd(string local, string remote) throw (NetworkError,CMNotFound)
{
  //cout << "LFW= " << remote << " --0 " << local << endl;
  const char * ip = get_ip(remote.c_str()).c_str();
  int port = get_port(remote.c_str());
  FILE * conn = get_CM_connection(ip, port);
  stringstream ost;
  ost << "RCVRMT\r\n1\r\n" << remote << "\r\n" << local << "\r\n";
  const char * s = ost.str().c_str();
  if (socket_write(conn, s, strlen(s)) == -1)
  {
    close_CM_connection(ip, port);
    throw NetworkError(ip, port);
  }
  free_CM_connection(ip, port);
}
string BolognaPi::new_ch() throw (NetworkError)
{
  Semaphore * s = new Semaphore();
  int id = worker->getId(s);
  ostringstream ost;
  ost << "NEWLCL\r\n" << id << "\r\n";
  const char * msg = ost.str().c_str();
  if (socket_write(CM_conn.fp, msg, strlen(msg)) == -1)
  {
    delete s;
    throw NetworkError(CM_conn.ip, CM_conn.port);
  }
  //channel name is allocated using malloc inside the shared thread
  char * ch_name;
  void * data;
  int length;
  //ch_name will be an empty string
  s->P(&data, &length, &ch_name);
  delete s;
  char name[length+1];
  strncpy(name, (char *)data, length);
  name[length] = '\0';
  free(data);
  free(ch_name);
  return string(name);
}

string BolognaPi::new_ch(const char * ip, int port) throw (NetworkError, CMNotFound)
{
  if (!(is_valid_ip(ip) && (port>0) && (port<65536)))
    throw CMNotFound(ip, port); 
  FILE * conn = get_CM_connection(ip, port);
  //a receiver for the remote channel name is created
  string ack = this->get_linear_fwd();
  ostringstream ost;
  ost << "NEWRMT\r\n" << ack << "\r\n"; 
  const char * s = ost.str().c_str();
  if (socket_write(conn, s, strlen(s)) == -1)
  {
    close_CM_connection(ip, port);
    throw NetworkError(ip, port);
  }
  free_CM_connection(ip, port);
  void * data;
  int length;
  this->rcv(ack, &data, &length);
  char name[length + 1];
  memcpy(name, data, length);
  name[length] = '\0';
  free(data);
  this->del_linear_fwd(ack);
  return string(name);
}
void BolognaPi::delete_ch(string ch_name) throw (NetworkError, CMNotFound)
{
  FILE * fp;
  int port;
  const char * ip;
  if (this->is_local(ch_name)) fp = CM_conn.fp;
  else 
  { 
    ip = get_ip(ch_name.c_str()).c_str();
    port = get_port(ch_name.c_str());
    if (!(is_valid_ip(ip) && (port>0) && (port<65536)))
      throw CMNotFound(ip, port); 
    try 
    {
      fp = get_CM_connection(ip, port);
    }
    catch (...)
    {
      close_CM_connection(ip, port);
      throw; 
    }
  }
  ostringstream ost;
  ost << "DEL" << "\r\n" << ch_name << "\r\n";
  const char * s = ost.str().c_str();
  if (socket_write(fp, s, strlen(s)) == -1)
  {
    if (CM_conn.fp != fp) 
    {
      close_CM_connection(ip, port);
      string s = ip;
      
      throw NetworkError(s.c_str(), port); 
    }
    else 
    {
      throw NetworkError(CM_conn.ip, CM_conn.port);
    }
  }
  if (CM_conn.fp != fp) free_CM_connection(ip, port);
  return;
}
int BolognaPi::rcv(vector<string> chans, void ** data, int * length) throw (API_Exception,ChannelNotFound)
{
  //1. rcv uses the standard encoding and create the same new channels and the 
  //   lfwds (not undo lfwd)
  //2. allocate a single semaphore s pointed from different indecies
  //3. s->P(data, length, index) 
  //4. create the linear forwarders for the undo effect by using index that
  //   indicates what is the channel where the reaction was performed
  //5. the new channels can be deallocate only when the remote linear forwarder
  //   is consumed ... annichilator??? ... then unfortunatly i cannot deallocate 
  //6. return the index (data and length are setted by V operations performed by
  //   the shared thread) 
  if (chans.size() == 0) return -1;
  bool one = false;
  string fwds[chans.size()];
  for (int i = 0; i < chans.size(); i++)
  {
    fwds[i] = "";
  }
  int j = 0;
  for (vector<string>::iterator i = chans.begin(); i < chans.end(); i++, j++)
  {
    ostringstream ost;
    if (!this->is_local(*i))
    {
      fwds[j] = this->get_linear_fwd();
      try 
      {
        this->fwd(fwds[j], *i);
        one = true;
      }
      catch (CMNotFound){}
      catch (NetworkError){}
    }
    else one = true;
  }
  if (!one) 
  {
    //TODO
    throw CMNotFound("255.255.255.255",65536);
  }
  Semaphore * s = new Semaphore();
  int id = worker->getId(s);
  ostringstream ost;
  ost << "RCVLCL\r\n" << chans.size() << "\r\n";
  for (int i = 0; i < chans.size(); i++)
  {
    if (fwds[i] == "") ost << chans[i] << "\r\n" << id << "\r\n";
    else ost << fwds[i] << "\r\n" << id << "\r\n";
  }
  const char * msg = ost.str().c_str();
  if (socket_write(CM_conn.fp, msg, strlen(msg)) == -1)
  {
    delete s;
    throw NetworkError(CM_conn.ip, CM_conn.port);
  }
  //the shared thread will call s->V(data, length, name) where data and length are
  //the data received from the channel manager and name is the channel where the
  //reaction was performed
  char * name;
  s->P(data, length, &name);  
  delete s;
  if (*length == -1) 
  {
    string s = name;
    free(name);
    throw ChannelNotFound(s.c_str());
  }
  int index = 0;
  j = 0;
  for (vector<string>::iterator i = chans.begin(); 
       ((i < chans.end()) && (*i != name) && (fwds[j] != name)); 
       i++, j++)
  {
    index++;
  }
  if (index == -1) return -1;

  //creating undo-fwd
  for (int i = 0; i < chans.size(); i++)
  {
    if (i != index)
    {
      if (fwds[i] != "")
      {
        ostringstream o;
        o << "RCVRMT\r\n1\r\n" << fwds[i] << "\r\n" << chans[i] << "\r\n";
        const char * s = o.str().c_str();
        //cout << "UndoFWD= " << fwds[i] << " --0 " << chans[i] << endl; 
        if (socket_write(CM_conn.fp, s, strlen(s)) == -1)
        {
          //cout << "UndoFWD= " << fwds[i] << " --0 " << chans[i] << " not created\n"; 
          //i go on with other FWD ... no excecption
        }
      }
    }
  }
  //i cannot do that!! because i donno if the remote lfw was used
  //for (int i = 0; i < chans.length(); i++)
  //  del_linear_fwd(ack_chan);  
  free(name);
  return index;
}
bool BolognaPi::is_local(string chan) 
{
  for (vector<string>::iterator i = local_names.begin(); i < local_names.end(); i++)
  {
    if (strcmp(i->c_str(),get_ip(chan.c_str()).c_str()) == 0)
      if (get_port(chan.c_str()) == CM_conn.port)
        return true;
  }
  return false;
}
bool BolognaPi::exists(string chan)
{
    try
    {
      if (is_local(chan))
        return this->lcl_exists(chan);
      else 
      {
        try
        {
          const char * ip = get_ip(chan.c_str()).c_str();
          int port = get_port(chan.c_str());
          return this->rmt_exists(chan, ip, port);
        }
        catch (...)
        {
          return false;
        }
      }
    }
    catch(...)
    {
      return false;
    }
}
bool BolognaPi::lcl_exists(string chan)
{
  stringstream ost;
  Semaphore * s = new Semaphore();
  int id = worker->getId(s);
  ost << "EXLCL\r\n" << chan << "\r\n" << id << "\r\n";
  const char * msg = ost.str().c_str();
  if (socket_write(CM_conn.fp, msg, strlen(msg)) == -1)
    throw NetworkError(CM_conn.ip, CM_conn.port);
  char * ch_name;
  void * data;
  int length;
  //in data i will receive FOUND or NOTFOUND
  s->P(&data, &length, &ch_name);
  delete s;
  assert((length == 5) || (length == 8));
  assert(strcmp(ch_name,chan.c_str()) == 0);
  bool result;
  if (strncmp((char *)data, "FOUND", 5) == 0) 
   result = true;
  else if (strncmp((char *)data, "NOTFOUND", 8) == 0) 
   result = false;
  else assert(false);
  free(data);
  free(ch_name);
  return result;
}
bool BolognaPi::rmt_exists(string chan, string ip, int port)
{
  FILE * conn = this->get_CM_connection(ip.c_str(), port);
  string ack = this->get_linear_fwd();
  stringstream ost;
  ost << "EXRMT\r\n" << chan << "\r\n" << ack << "\r\n";
  const char * msg = ost.str().c_str();
  if (socket_write(conn, msg, strlen(msg)) == -1)
  {
    this->free_CM_connection(ip.c_str(), port);
    throw NetworkError(ip.c_str(), port);
  }
  this->free_CM_connection(ip.c_str(), port);
  void * data;
  int length;
  this->rcv(ack, &data, &length);
  bool result;
  if (strncmp((char *)data, "FOUND", 5) == 0) 
   result = true;
  else if (strncmp((char *)data, "NOTFOUND", 8) == 0) 
   result = false;
  else assert(false);
  free(data);
  return result;
}
int BolognaPi::initAPI(int local_port)
{
  mutex_start.P(); 
  users++;
  pthread_atfork(NULL,parent_handler,child_handler);
  int res = -1;
  try
  {
    if (users == 1) singleton = new BolognaPi();
    if (worker == NULL) 
    {
      port = local_port;
      worker = new Worker();
      worker->start(port, CM_conn, local_names);
      pthread_create(&worker_thread_id, NULL, &worker_wrapper, (void *)(worker));
    }
    res = 0;
  }
  catch (...)
  {
    res = -1;
  }
  mutex_start.V();
  return res;
}
void BolognaPi::reinitAPI()
{
  initAPI(port);
}
void BolognaPi::exitAPI()
{
  mutex_start.P(); 
  users--;
  if (users == 0)
  {
    delete singleton;
    singleton = NULL;
    worker = NULL;
    worker_thread_id = 0;
    port = -1;
  }
  mutex_start.V(); 
}
int BolognaPi::select(vector<Channel> chans, void ** data, int *length) 
{
  if (singleton == NULL) return -1;
  else 
  {
    try
    {
      vector<string> channels;
      for (vector<Channel>::iterator i = chans.begin(); i < chans.end(); i++)
        channels.push_back(string(i->name));  
      return singleton->rcv(channels, data, length);
    }
    catch (...)
    {
      return -1;
    }
  }
}
/**************************************************************************
 *        Basic Channel Implementation                                    *
 **************************************************************************/
BolognaPi * Channel::getBopiInstance() const throw (API_Exception)
{
  BolognaPi * bopi = BolognaPi::getInstance();
  if (bopi == NULL) throw API_Exception();
  else return bopi;
}
Channel::Channel(const Channel& chan)
{
  name = chan.name;
}
void Channel::snd(const void * data, int length) throw (NetworkError,CMNotFound,ChannelNotFound)
{
  this->getBopiInstance()->snd(name, data, length);
}
void Channel::asnd(const void * data, int length) throw (NetworkError,CMNotFound)
{
  this->getBopiInstance()->asnd(name, data, length);
}
void Channel::rcv(void ** data, int * length) throw (NetworkError,CMNotFound,ChannelNotFound)
{
  this->getBopiInstance()->rcv(name, data, length);
}
