/***************************************************************************
                   socketwr.cpp  -  A small wrapper for socket syscalls
                             -------------------
    begin                : Mon Dec 15 2003
    copyright            : (C) 2003 by Samuele Carpineti
    email                : carpinet@cs.unibo.it
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#include <iostream>
#include <ostream>
#include <sstream>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "socketwr.h"
using namespace std;

bool is_valid_ip(const char * ip)
{
  if (ip == NULL) return false; 
  return (inet_addr(ip) != INADDR_NONE); 
}
string get_ip(const char * chan)
{
  //ip:port/#NUM or ip:port#NUM
  int pos = -1;
  for (int i = 0; i < strlen(chan); i++)
  {
    if (chan[i]==':') pos = i;
  }
  if (pos == -1) return NULL;
  char * copy = strndup(chan, pos);
  string s(copy);
  free(copy);
  return s;
}

int get_port(const char * chan)
{
  //ip:port/#NUM or ip:port#NUM
  int first = -1;
  int second = -1;
  for (int i = 0; i < strlen(chan); i++)
  {
    if (chan[i]==':') first = i;
    if (chan[i]=='/') second = i;
    else if (chan[i]=='#') second = i;
  }
  if (first == -1) return -1;
  if (second == -1) return -1;
  if ((second - first) <= 0) return -1;
  char * s = (char *)malloc(sizeof(char)*(second - first));
  strncpy(s, &chan[first + 1], second - first);
  s[second - first - 1]='\0';
  int port = atoi(s);
  free(s);
  return port;
}
int open_socket(const char * ip, int port)
{
  if (!is_valid_ip(ip)) return -1;
  int sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd == -1) return -1;
  struct sockaddr_in local, serv;
  memset (&local, 0, sizeof(local));
  local.sin_family = AF_INET;
  local.sin_addr.s_addr = htonl(INADDR_ANY);
  local.sin_port = 0; 
  if (bind(sockfd, (struct sockaddr*) &local, sizeof(local)) == -1)
    return -1;
  memset (&serv, 0, sizeof(serv));
  serv.sin_family = AF_INET;
  if ((serv.sin_addr.s_addr = inet_addr(ip)) == INADDR_NONE)
    return -1;
  serv.sin_port = htons(port);
  if (connect(sockfd, (const struct sockaddr*)&serv, sizeof(serv)) == -1)
    return -1;
  return sockfd;
}
int socket_write(FILE * fp, const void * buf, int n)
{
  //if the receiver closes the socket a sigpipe arrives 
  const char * ptr;
  int nwritten = fwrite(buf, 1, n, fp);
  fflush(fp);
  if (ferror(fp)) 
  {
    clearerr(fp);
    return -1;
  }
  return (n-nwritten);
}
int socket_write(int fd, const void * buf, int n)
{
  //if the receiver closes the socket a sigpipe arrives 
  int nleft, nwritten;
  const char * ptr = (const char *)buf;
  signal(SIGPIPE,SIG_IGN);
  nleft = n;
  while (nleft > 0)
  {
    if ((nwritten = write(fd, ptr, nleft))<=0)
    {
      if (errno==EINTR) nwritten = 0;
      else 
      {
        signal(SIGPIPE,SIG_DFL);
        return -1;
      }
    }
    nleft -= nwritten;
    ptr += nwritten;
  }
  signal(SIGPIPE, SIG_DFL);
  return (n-nleft);
}
int socket_write(int fd, char ch)
{
  char c[1]; 
  c[0]=ch;
  return socket_write(fd, c, 1);
}
int socket_shutdown(FILE * fp)
{
  int fd = fileno(fp);
  if (fd != -1) return socket_shutdown(fd);
  else return -1;
}
int socket_shutdown(FILE * fp, int flag)
{
  int fd = fileno(fp);
  if (fd != -1) return socket_shutdown(fd,flag);
  else return -1;
}
int socket_close(FILE * fp)
{
  return fclose(fp);
}
int socket_shutdown(int fd)
{
  return shutdown(fd,SHUT_RDWR);
}
int socket_shutdown(int fd, int flag)
{
  return shutdown(fd,flag);
}
int socket_close(int fd)
{
  return close(fd);
}
int socket_read(int fd, void * buf, int n)
{
  int nleft, nread;
  char *ptr;
  ptr = (char *)buf; 
  nleft = n;
  while (nleft>0)
  {
    if ((nread = read(fd, ptr, nleft))<0)
    {
      if (errno==EINTR) nread=0;
      else return -1;
    }
    else if (nread==0) break; //EOF
    nleft -= nread; 
    ptr += nread; 
  }
  return (n-nleft);
}
int socket_read(FILE * fp, void * buf, int n)
{
  return fread(buf, sizeof(char), n, fp);
}

char * socket_readline(int fd)
{
  int STATE = 0;
  char c;
  stringstream ost;
  while (socket_read(fd, &c, 1)!=-1)
  {
    ost << c;
    if ((STATE == 0) && (c == '\r')) STATE = 1;
    if ((STATE == 1) && (c == '\n')) 
    {
      string s;
      ost >> s;
      char * n = strdup(s.c_str());
      return n;
    }
  }
  return NULL;
}
int non_blocking_readn(int fd, void * buf, int n)
{
  int nleft, nread;
  char * ptr;
  ptr = (char *)buf; 
  nleft = n;
  while (nleft>0)
  {
    if ((nread = read(fd, ptr, nleft))<0)
    {
      if (errno==EINTR) nread=0;
      if (errno==EAGAIN) break;
      else return -1;
    }
    else if ((nread==0) && (nleft==n)) return -1;
    else if ((nread==0) && (nleft!=n)) return (n-nleft);
    nleft -= nread; 
    ptr += nread; 
  }
  return (n-nleft);
}
