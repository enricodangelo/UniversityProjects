/***************************************************************************
                          socketwr.h  -  description
                             -------------------
    begin                : Mon Dec 15 2003
    copyright            : (C) 2003 by Samuele Carpineti
    email                : carpinet@cs.unibo.it
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#ifndef SOCKETWR_H
#define SOCKETWR_H
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <string>
#include <string.h>
/**
 * This function check if a string is an IP address
 * @param ip: the address to check
 * @return true if the ip is valid, false otherwise
 */
bool is_valid_ip(const char * ip);

/**
 * From a channel name to an ip address
 * @param chan: a channel name in the form ip:port/#seqno
 * @return a string representation of an ip address
 */
std::string get_ip(const char * chan);

/**
 * From a channel name to a port
 * @param chan: a channel name in the form ip:port/#seqno
 * @return the port
 */
int get_port(const char * chan);

/**
 * This function opens a socket with one remote host
 * @param ip: the server address
 * @param port: the remote port
 * @return -1 on error, a valid file descriptor otherwise
 */
int open_socket(const char * ip, int port);

/**
 * This function writes the buffer on fp. POSIX guarantees 
 * that the operation is thread-safe.
 * @param fp: the destination
 * @param buf: the buffer to write
 * @param n: buffer size 
 * @return -1 on error, the characters written otherwise
 */
int socket_write(FILE * fp, const void * buf, int n);
/**
 * This function allow to write on a socket handling OS interrupt for syscalls
 * @param fd: the socket fd
 * @param buf: buffer to write
 * @param length: number of characters to write
 * @return -1 on error
 */
int socket_write(int fd, const void * buf, int length);
/**
 * This function allow to write on a socket handling OS interrupt for syscalls
 * @param fd: the socket fd
 * @param c: the character to write
 * @return -1 on error
 */
int socket_write(int fd, char c);
/**
 * This function allows to read from a socket handling OS interrupt for syscalls
 * @param fd: the socket fd
 * @param buf: the buffer where to store data
 * @param n: bytes to read
 * @return -1 on error
 */
int socket_read(int fd, void * buf, int n);
/**
 * This function allows to read from a socket stream
 * @param fp: the socket stream
 * @param buf: the buffer where to store data
 * @param n: bytes to read
 * @return -1 on error
 */
int socket_read(FILE * fp, void * buf, int n);

/**
 * This function reads a line using as delimiter "\r\n" and put the result in a
 * buffer allocated using a malloc (the caller must delete the value)
 * @param fd: the socket fd
 */
char * socket_readline(int fd);

/**
 * Read n byets from fd and write the result on a buffer that must be big enough
 * @param fd the file descriptor (O_NONBLOCK must be activated on fd)
 * @param buf the buffer where the result is stored
 * @param n bytes to be read
 * @return the number of available characters (0 if there are no data available)
 * or -1 if EOF is read
 */
int non_blocking_readn(int fd, void * buf, int n);
/**
 * This function shutdown the socket (FYN is sent)
 * @param fd: the socket fd
 * @return -1 on error
 */
int socket_shutdown(int fd);
/**
 * This function shutdown the socket in the method specified by flag
 * @param fd: the socket fd
 * @param flag: SHUT_RDWR, SHUT_RD, SHUT_WR
 * @return -1 on error
 */
int socket_shutdown(int fd, int flag);
/**
 * This function closes the socket immediatly in both the directions (it
 * decreases the pointers number to fd)
 * @param fd: the socket fd
 */
int socket_close(int fd);
/**
 * This function shutdown the socket (FYN is sent)
 * @param fp: the socket fp
 * @return -1 on error
 */
int socket_shutdown(FILE * fp);
/**
 * This function shutdown the socket in the method specified by flag
 * @param fp: the socket fp
 * @param flag: SHUT_RDWR, SHUT_RD, SHUT_WR
 * @return -1 on error
 */
int socket_shutdown(FILE * fp, int flag);
/**
 * This function closes the socket immediatly in both the directions (it
 * decreases the pointers number to fp)
 * @param fp: the socket fp
 */
int socket_close(FILE * fp);
#endif
