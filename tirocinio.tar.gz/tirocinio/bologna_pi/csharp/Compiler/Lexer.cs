// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Text.RegularExpressions;
using System.Collections;

namespace BoPi.Compiler
{
	public class GenericValue
	{
		private readonly int location;

		public int Location { get { return location; } }

		public GenericValue(int location)
		{ this.location = location; }
	}

	public class IntValue : GenericValue
	{
		private readonly int val;

		public int Value { get { return val; } }

		public IntValue(int val, int location) : base(location)
		{ this.val = val; }
	}

	public class StringValue : GenericValue
	{
		private readonly String val;

		public String Value { get { return val; } }

		public StringValue(String val, int location) : base(location)
		{ this.val = val; }
	}
    
	public interface IToken
	{		
		/* integer returned by Token's jay class
		 * that correspond at this keyword*/
		int Token { get; }
		/* return true if <code>str</code>
		 * match with this token */
		bool Match(String str, ref int length);
	}

	internal class SimpleToken : IToken	
	{	
		private readonly int token;
		private readonly String val;

		public int Token { get { return token; } }

		public SimpleToken(string val, int token)
		{
			this.val = val;
			this.token = token;
		}

		public bool Match(String str, ref int length)
		{
			length = val.Length;
			return (str.StartsWith(val));
		}
	}

	internal class RegexpToken : IToken	
	{	
		private readonly int token;
		private readonly Regex val;

		public int Token { get { return token; } }

		public RegexpToken(string pattern, int token)
		{
			this.val = new Regex("^(" + pattern + "){1}");
			this.token = token;
		}

		public bool Match(String str, ref int length)
		{
			Match m = val.Match(str);
			length = m.Length;
			return m.Success;
		}
	}
	
	class Lexer : yyParser.yyInput
	{
		public Object Value;
		private ArrayList tokens;
		private static Regex annotation = new Regex("^(//.*\n)");
		private string m_input = "";
		//line number
		public int location;

		public Lexer(string m_input)
		{	
			location=1;
			tokens= new ArrayList();			
			tokens.Add(new SimpleToken("->", Token.ARROW));
			tokens.Add(new SimpleToken("&", Token.AMPERSAND));
			tokens.Add(new SimpleToken("-", Token.MINUS));
			tokens.Add(new SimpleToken("==", Token.EQ));
			tokens.Add(new SimpleToken("=", Token.EQ));
			tokens.Add(new SimpleToken("^IO", Token.IO));
			tokens.Add(new SimpleToken("^I", Token.I));
			tokens.Add(new SimpleToken("^O", Token.O));
			tokens.Add(new SimpleToken("^", Token.EXP));
			tokens.Add(new SimpleToken("!=", Token.NE));
			tokens.Add(new SimpleToken("{", Token.LBRACE));
			tokens.Add(new SimpleToken("}", Token.RBRACE));
			tokens.Add(new SimpleToken("(", Token.LPAREN));
			tokens.Add(new SimpleToken(")", Token.RPAREN));
			tokens.Add(new SimpleToken("[", Token.LBRACK));
			tokens.Add(new SimpleToken("]", Token.RBRACK));
			tokens.Add(new SimpleToken("#", Token.SHARP));
			tokens.Add(new SimpleToken(":", Token.COLON));
			tokens.Add(new SimpleToken(".", Token.DOT));
			tokens.Add(new SimpleToken("+", Token.PLUS));
			tokens.Add(new SimpleToken("*", Token.TIMES));
			tokens.Add(new SimpleToken("/", Token.DIVIDE));
			tokens.Add(new SimpleToken("\\", Token.BACKSLASH));
			tokens.Add(new SimpleToken("=", Token.EQ));
			tokens.Add(new SimpleToken(">=", Token.GE));
			tokens.Add(new SimpleToken("<=", Token.LE));
			tokens.Add(new SimpleToken(">", Token.GT));
			tokens.Add(new SimpleToken("<", Token.LT));
			tokens.Add(new SimpleToken(",", Token.COMMA));
			tokens.Add(new SimpleToken("|", Token.ORMATCH));
			tokens.Add(new SimpleToken("~", Token.TILDE));
			tokens.Add(new RegexpToken("\\bwsdl=\"[^\"]*\"", Token.IMPORTBODY));
			tokens.Add(new RegexpToken("\\blocation\\s*=\\s*\"[^\"]*\"\\s*", Token.LOCATION));
			tokens.Add(new RegexpToken("\\bspawn\\b", Token.SPAWN));
			tokens.Add(new RegexpToken("\\bmatch\\b", Token.MATCH));
			tokens.Add(new RegexpToken("\\bselect\\b",  Token.SELECT));
			tokens.Add(new RegexpToken("\\bjoin\\b", Token.JOIN_KW));
			tokens.Add(new RegexpToken("\\bint\\b", Token.INT));
			tokens.Add(new RegexpToken("\\bstring\\b", Token.STRING));
			tokens.Add(new RegexpToken("\\bnew\\b", Token.NEW));
			tokens.Add(new RegexpToken("\\bin\\b", Token.IN));
			tokens.Add(new RegexpToken("\\bvoid\\b", Token.VOID));
			tokens.Add(new RegexpToken("\\bwith\\b", Token.WITH));
			tokens.Add(new RegexpToken("\\bor\\b", Token.OR));
			tokens.Add(new RegexpToken("\\band\\b", Token.AND));
			tokens.Add(new RegexpToken("\\bnot\\b", Token.NOT));
			tokens.Add(new RegexpToken("\\bfirst\\b", Token.FIRST));
			tokens.Add(new RegexpToken("\\brest\\b", Token.REST));
			tokens.Add(new RegexpToken("\\bimport\\b", Token.IMPORT));
			tokens.Add(new RegexpToken("\\bschemadef\\b", Token.SCHEMADEF));
			tokens.Add(new RegexpToken("\"([^\"]*|(\\\")*)*\"", Token.TEXT));
			tokens.Add(new RegexpToken("[1-9][0-9]*", Token.NUMBER));
			tokens.Add(new SimpleToken("0", Token.ZERO));
			tokens.Add(new RegexpToken("[A-Za-z][A-Za-z0-9_]*\\!", Token.CHANOUT));
			tokens.Add(new RegexpToken("[A-Za-z][A-Za-z0-9_]*\\?", Token.CHANIN));
			tokens.Add(new RegexpToken("[A-Za-z][A-Za-z0-9_]*", Token.ID));
			tokens.Add(new RegexpToken("\\@[A-Za-z][A-Za-z0-9_]*", Token.ID));
			this.m_input = m_input;
		}
		
		public Object value() {
			return Value;
		}

		public bool advance()
		{
			while ((m_input.Length!=0) && ((m_input[0]=='\n') || (m_input[0]=='\t') || (m_input[0]==' ')))
			{
				if (m_input[0]=='\n') location++;
				m_input=m_input.Remove(0, 1);
			}
			Match m=annotation.Match(m_input);
			if (m.Success)
			{
				m_input=m_input.Remove(0, m.Length);
                location ++;				
				advance();
			}
			return (m_input.Length!=0);
		}

		public int token()
		{
			IToken tmp;
			int length=0;
			for (int i=0;i<tokens.Count;i++)
			{
				tmp=(IToken)tokens[i];
				if (tmp.Match(m_input, ref length))
				{
					switch (tmp.Token)
					{
						case Token.TEXT:
						{
							Value=new StringValue(m_input.Substring(1, length-2).Replace("\\\"","\""), location);
							break;
						}
						case Token.NUMBER:
						{
							Value=new IntValue(Int32.Parse(m_input.Substring(0, length)), location);
							break;
						}
						case Token.ID:
						{
							if (!m_input.StartsWith("@"))
                                Value=new StringValue(m_input.Substring(0, length), location);
							else
								Value=new StringValue(m_input.Substring(1, length-1), location);
							break;
						}
						case Token.CHANIN:
						case Token.CHANOUT:
						{
							Value=new StringValue(m_input.Substring(0, length-1), location);
							break;
						}
						case Token.IMPORTBODY:
						{
							MatchCollection m=Regex.Matches(m_input, "\"[^\"]*\"");
							String wsdl=m_input.Substring(m[0].Index+1, m[0].Length-2);							
							Value=wsdl;
							break;
						}
						case Token.LOCATION:
						{
							Match m=Regex.Match(m_input, "\"[^\"]*\"");
							Value=m_input.Substring(m.Index+1, m.Length-2);
							break;
						}

						default:
						{
							Value=location;
							break;
						}
						
					}
					m_input=m_input.Remove(0, length);
					return tmp.Token;
				}				
			}
			return Token.ERROR;
		}
	}
}
