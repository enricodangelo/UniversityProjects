#!/bin/sh
#
# This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce)
# developed at the Department of Computer Science of Bologna.
# Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani

export MONO_TRACE_LISTENER=Console.Error
cd ../Binaries
mono --debug ./PiDuceCompiler.exe $*
#MONO_PATH=../Common:../Types mono --debug compiler.exe $*
#MONO_PATH=../Common:../Types mono --trace=N:BoPi.Compiler --debug compiler.exe $*
