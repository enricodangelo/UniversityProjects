// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Xml;
using System.Diagnostics;
using BoPi.Common;
using BoPi.Types;

namespace BoPi.Compiler
{	
	public enum BinaryOp {
		PLUS,
		MINUS,
		TIMES,
		DIVIDE,
		EQEQ,
		NE,
		GT,
		GE,
		LT,
		LE,
		OR,
		AND
	}

	public enum UnaryOp {
		NOT,
		REST,
		FIRST,
		UMINUS
	}

	public interface IExpression
	{
		int Location { get; }

		void ResolveNames(CompilerValueSymbolTable st);
		void Compile(XmlWriter code);
		IType TypeOf();
	}

	public abstract class Expression : IExpression
	{
		private readonly int location;

		public int Location { get { return location; } }

		public Expression(int location)
		{ this.location = location; }

		public abstract void ResolveNames(CompilerValueSymbolTable st);
		public abstract void Compile(XmlWriter code);
		public abstract IType TypeOf();
    protected ITypeChecker typeChecker = new TypeChecker();
	}

	public class VoidExp : Expression
	{
		public VoidExp(int location) : base(location)
		{ }

		public override IType TypeOf()
		{ return new Types.Void(); }		
    
    public override void ResolveNames(CompilerValueSymbolTable st) 
    { }

		public override void Compile(XmlWriter code)
		{
      code.WriteStartElement("void");
			code.WriteEndElement(); // </void>
		}
	}

	public class VariableExp : Expression
	{
		private String name;
    private ISymbolTableValueEntry varEntry;

		public VariableExp(String name, int location) : base(location)
		{ this.name = name; }

		public override void ResolveNames(CompilerValueSymbolTable st)
		{ varEntry = st.Lookup(this.name, Location); }

		public override IType TypeOf()
		{
			Debug.Assert(varEntry != null);
			Debug.Assert(varEntry.Type != null);
			return varEntry.Type;
		}

		public override void Compile(XmlWriter code)
		{
			code.WriteStartElement("load");
			code.WriteAttributeString("index", varEntry.Index.ToString());
      code.WriteAttributeString("name", varEntry.Name);
			code.WriteEndElement(); // </load>
		}
	}

	public class IntExp : Expression
	{
		private readonly int val;

		public IntExp(int val, int location) : base(location)
		{ this.val = val; }	

		public override IType TypeOf()
		{ return new IntType(); }

    public override void ResolveNames(CompilerValueSymbolTable st)
    { }

		public override void Compile(XmlWriter code)
		{
			code.WriteStartElement("intlit");
			code.WriteString(val.ToString());
			code.WriteEndElement(); // </intlit>
		}		
	}

	public class StringExp : Expression
	{
		private readonly String val;

		public StringExp(String val, int location) : base(location)
		{ this.val = val; }		

		public override IType TypeOf()
		{ return new StringLiteral(val); }
    
    public override void ResolveNames(CompilerValueSymbolTable st)
    { }

		public override void Compile(XmlWriter code)
		{
			code.WriteStartElement("stringlit");
			code.WriteCData(val);
			code.WriteEndElement(); // </stringlit>
		}
	}

	public class LabelExp : Expression
	{
		private readonly IExpression content;
		private readonly String label;

		public LabelExp(String label, IExpression content, int location)
			: base(location)
		{
			this.content = content;
			this.label = label;
		}

		public override IType TypeOf()
		{ return new Labelled(new UnionLabel(label), content.TypeOf()); }

		public override void ResolveNames(CompilerValueSymbolTable st)
		{ content.ResolveNames(st); }

		public override void Compile(XmlWriter code)
		{
			code.WriteStartElement("labelled");
			code.WriteAttributeString("label", label);
			content.Compile(code);
			code.WriteEndElement();
		}
	}
	
	public class BinaryExp : Expression
	{
		private readonly BinaryOp op;
		private readonly IExpression left;
		private readonly IExpression right;

		public BinaryExp(IExpression left, BinaryOp op, IExpression right, int location)
			: base(location)
		{
			this.left = left;
			this.op = op;
			this.right = right;
		}	

		public override IType TypeOf()
		{
			IType left = this.left.TypeOf();
			IType right = this.right.TypeOf();
			IntType integer = new IntType();
			StringType str = new StringType();
			switch (op)
			{	
				case BinaryOp.PLUS:
            if (typeChecker.IsSubtype(left, integer) && 
						  typeChecker.IsSubtype(right, integer))
						          return integer;						
            if (typeChecker.IsSubtype(left, str) && 
						  typeChecker.IsSubtype(right, str))
											return str;							
					break;
				case BinaryOp.EQEQ:
				case BinaryOp.NE:
          if (typeChecker.IsSubtype(left, integer) && 
              typeChecker.IsSubtype(right, integer))
                           return integer;							
          if (typeChecker.IsSubtype(left, str) && 
              typeChecker.IsSubtype(right, str))
                           return str;							
                  break;
        default:
          if (typeChecker.IsSubtype(left, integer) && 
              typeChecker.IsSubtype(right, integer))
                        return integer;		
          break;
      }
			CompilerOutput.Error("illtyped expression: " + left + " is not equals to " + right, Location);
			return new ErrorType();
		}

		public override void ResolveNames(CompilerValueSymbolTable st)
		{
			left.ResolveNames(st);
			right.ResolveNames(st);
		}

		public override void Compile(XmlWriter code)
		{
			code.WriteStartElement("binop");
			switch (op) {
				case BinaryOp.PLUS: code.WriteAttributeString("op", "add"); break;
        case BinaryOp.MINUS: code.WriteAttributeString("op", "sub"); break;
				case BinaryOp.TIMES: code.WriteAttributeString("op", "mul"); break;
				case BinaryOp.DIVIDE: code.WriteAttributeString("op", "div"); break;
				case BinaryOp.EQEQ: code.WriteAttributeString("op", "eq"); break;
				case BinaryOp.NE: code.WriteAttributeString("op", "neq"); break;
				case BinaryOp.GT: code.WriteAttributeString("op", "gt"); break;
				case BinaryOp.GE: code.WriteAttributeString("op", "ge"); break;
				case BinaryOp.LT: code.WriteAttributeString("op", "lt"); break;
				case BinaryOp.LE: code.WriteAttributeString("op", "le"); break;
				case BinaryOp.AND: code.WriteAttributeString("op", "and"); break;
				case BinaryOp.OR: code.WriteAttributeString("op", "or"); break;
				default: Debug.Assert(false); break;
			}
			left.Compile(code);
			right.Compile(code);
			code.WriteEndElement();
		}
	}

	public class SequenceExp : Expression
	{
		private readonly IExpression top;
		private readonly IExpression tail;

		public SequenceExp(IExpression top, IExpression tail, int location)
			: base(location)
		{
			this.top = top;
			this.tail = tail;
		}	

		public override IType TypeOf()
		{
			return new Sequence(top.TypeOf(), tail.TypeOf());
		}

		public override void ResolveNames(CompilerValueSymbolTable st)
		{
			top.ResolveNames(st);
			tail.ResolveNames(st);
		}

		public override void Compile(XmlWriter code)
		{
			code.WriteStartElement("seq");
			top.Compile(code);
			tail.Compile(code);
			code.WriteEndElement(); // </seq>
		}
	}

	public class UnaryExp : Expression
	{
		private readonly UnaryOp op;
		private readonly IExpression exp;		

		public UnaryExp(UnaryOp op, IExpression exp, int location)
			: base(location)
		{
			this.op = op;
			this.exp = exp;
		}	

		public override IType TypeOf()
		{
			IType content = exp.TypeOf();
			switch (op)
			{
				case UnaryOp.FIRST:
				case UnaryOp.REST:
					StringType str = new StringType();
          if (typeChecker.IsSubtype(content, str))
						return str;
					break;						
				case UnaryOp.UMINUS:{
					/*
					 * is necessary to perform this check because 
					 * parser do not recognize negative integer
					 * */
					if (content.IsIntLiteral())
						return new IntLiteral(-((IntLiteral)content).Val);
					IntType integer = new IntType();
          if (typeChecker.IsSubtype(content, integer))
						return integer;
					break;
        }
				case UnaryOp.NOT:
					{
						IntType integer = new IntType();
          	if (typeChecker.IsSubtype(content, integer))
							return integer;
					}
					break;
			}
			CompilerOutput.Error("illtyped expression", Location);
			return new ErrorType();
		}

		public override void ResolveNames(CompilerValueSymbolTable st)
		{ exp.ResolveNames(st); }

		public override void Compile(XmlWriter code)
		{
			code.WriteStartElement("unop");
			switch (op) {
				case UnaryOp.UMINUS: code.WriteAttributeString("op", "minus"); break;
				case UnaryOp.NOT: code.WriteAttributeString("op", "not"); break;
				default: Debug.Assert(false); break;
			}
			exp.Compile(code);
			code.WriteEndElement();
		}
	}
}
