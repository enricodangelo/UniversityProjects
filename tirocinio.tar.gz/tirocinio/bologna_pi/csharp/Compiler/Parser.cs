// created by jay 0.7 (c) 1998 Axel.Schreiner@informatik.uni-osnabrueck.de

#line 2 "Parser.jay"
// -*-csharp-*-
// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.IO;
using System.Text;
using System.Collections;
using BoPi.Types;
namespace BoPi.Compiler{


public class BoPiParser {

  Lexer lexer;
  Hashtable locationMap;
  static public int yacc_verbose_flag = 2;

#line default

  /** error output stream.
      It should be changeable.
    */
  public System.IO.TextWriter ErrorOutput = System.Console.Out;

  /** simplified error message.
      @see <a href="#yyerror(java.lang.String, java.lang.String[])">yyerror</a>
    */
  public void yyerror (string message) {
    yyerror(message, null);
  }

  /** (syntax) error message.
      Can be overwritten to control message format.
      @param message text to be displayed.
      @param expected vector of acceptable tokens, if available.
    */
  public void yyerror (string message, string[] expected) {
    if ((yacc_verbose_flag > 0) && (expected != null) && (expected.Length  > 0)) {
      ErrorOutput.Write (message+", expecting");
      for (int n = 0; n < expected.Length; ++ n)
        ErrorOutput.Write (" "+expected[n]);
        ErrorOutput.WriteLine ();
    } else
      ErrorOutput.WriteLine (message);
  }

  /** debugging support, requires the package jay.yydebug.
      Set to null to suppress debugging messages.
    */
//t  internal yydebug.yyDebug debug;

  protected static  int yyFinal = 12;
//t  public static  string [] yyRule = {
//t    "$accept : process",
//t    "process : CHANOUT LPAREN E RPAREN",
//t    "process : CHANIN TIMES LPAREN F RPAREN DOT process",
//t    "process : CHANIN LPAREN F RPAREN DOT process",
//t    "process : SCHEMADEF schema_decl_ne_list IN process",
//t    "process : NEW ID COLON LT S GT K IN process",
//t    "process : NEW ID COLON LT S GT K LOCATION IN process",
//t    "process : NEW ID COLON LT S GT IN process",
//t    "process : NEW ID COLON LT S GT LOCATION IN process",
//t    "process : IMPORT ID COLON LT S GT K IN process",
//t    "process : IMPORT ID COLON LT S GT K IMPORTBODY IN process",
//t    "process : NEW error IN process",
//t    "process : SPAWN LBRACE process RBRACE process",
//t    "process : MATCH E WITH LPAREN Matchdec RPAREN",
//t    "process : SELECT LPAREN Selectdec RPAREN",
//t    "process : JOIN_KW star_opt join_pattern_row_ne_list",
//t    "process : ZERO",
//t    "process : error",
//t    "star_opt :",
//t    "star_opt : TIMES",
//t    "join_pattern_row_ne_list : join_pattern_row",
//t    "join_pattern_row_ne_list : join_pattern_row_ne_list ORMATCH join_pattern_row",
//t    "join_pattern_row : join_pattern_atom_ne_list DOT process",
//t    "join_pattern_atom_ne_list : join_pattern_atom",
//t    "join_pattern_atom_ne_list : join_pattern_atom_ne_list AMPERSAND join_pattern_atom",
//t    "join_pattern_atom : CHANIN LPAREN F RPAREN",
//t    "schema_decl_ne_list : schema_decl",
//t    "schema_decl_ne_list : schema_decl_ne_list AND schema_decl",
//t    "schema_decl : ID EQ S",
//t    "Matchdec : F ARROW process",
//t    "Matchdec : Matchdec ORMATCH F ARROW process",
//t    "Matchdec : F ARROW process error",
//t    "Selectdec : CHANIN LPAREN F RPAREN DOT process",
//t    "Selectdec : CHANIN LPAREN F RPAREN DOT process COMMA Selectdec",
//t    "F : S",
//t    "F : ID COLON F",
//t    "F : L LBRACK F RBRACK",
//t    "F : L LBRACK F RBRACK COMMA F",
//t    "E : LPAREN E RPAREN",
//t    "E : VOID",
//t    "E : ID",
//t    "E : NUMBER",
//t    "E : ZERO",
//t    "E : TEXT",
//t    "E : ID LBRACK E RBRACK",
//t    "E : ID LBRACK RBRACK",
//t    "E : E PLUS E",
//t    "E : E MINUS E",
//t    "E : E TIMES E",
//t    "E : E DIVIDE E",
//t    "E : E EQEQ E",
//t    "E : E NE E",
//t    "E : E GT E",
//t    "E : E GE E",
//t    "E : E LT E",
//t    "E : E LE E",
//t    "E : E OR E",
//t    "E : E AND E",
//t    "E : E COMMA E",
//t    "E : NOT E",
//t    "E : MINUS E",
//t    "E : REST E",
//t    "E : FIRST E",
//t    "E : error",
//t    "L : ID",
//t    "L : TILDE",
//t    "L : L SHARP L",
//t    "L : L BACKSLASH L",
//t    "L : LBRACE L RBRACE",
//t    "S : LPAREN RPAREN",
//t    "S : VOID",
//t    "S : LPAREN S RPAREN",
//t    "S : S PLUS S",
//t    "S : ID",
//t    "S : L LBRACK S RBRACK",
//t    "S : L LBRACK RBRACK",
//t    "S : L LBRACK S RBRACK COMMA S",
//t    "S : L LBRACK RBRACK COMMA S",
//t    "S : LT S GT K",
//t    "S : T COMMA S",
//t    "S : T",
//t    "S : error",
//t    "K : I",
//t    "K : O",
//t    "K : IO",
//t    "K : error",
//t    "T : INT",
//t    "T : STRING",
//t    "T : ZERO",
//t    "T : NUMBER",
//t    "T : MINUS NUMBER",
//t    "T : TEXT",
//t  };
  protected static  string [] yyNames = {    
    "end-of-file",null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,"ERROR","ARROW","EQEQ","I","O",
    "IO","NE","LBRACE","RBRACE","LPAREN","RPAREN","LBRACK","RBRACK",
    "COLON","DOT","PLUS","MINUS","TIMES","DIVIDE","BACKSLASH","AMPERSAND",
    "EQ","LT","LE","GT","GE","COMMA","SHARP","TILDE","SPAWN","MATCH",
    "SELECT","INT","STRING","NEW","IN","VOID","WITH","SCHEMADEF","TEXT",
    "NUMBER","ZERO","CHANOUT","CHANIN","ID","EXP","OR","AND","NOT",
    "FIRST","REST","ORMATCH","LOCATION","IMPORT","IMPORTBODY","JOIN_KW",
    "Declaration","ORPLUS","UMINUS",
  };

  /** index-checked interface to yyNames[].
      @param token single character or %token value.
      @return token name or [illegal] or [unknown].
    */
  public static string yyname (int token) {
    if ((token < 0) || (token > yyNames.Length)) return "[illegal]";
    string name;
    if ((name = yyNames[token]) != null) return name;
    return "[unknown]";
  }

  /** computes list of expected tokens on error by tracing the tables.
      @param state for which to compute the list.
      @return list of token names.
    */
  protected string[] yyExpecting (int state) {
    int token, n, len = 0;
    bool[] ok = new bool[yyNames.Length];

    if ((n = yySindex[state]) != 0)
      for (token = n < 0 ? -n : 0;
           (token < yyNames.Length) && (n+token < yyTable.Length); ++ token)
        if (yyCheck[n+token] == token && !ok[token] && yyNames[token] != null) {
          ++ len;
          ok[token] = true;
        }
    if ((n = yyRindex[state]) != 0)
      for (token = n < 0 ? -n : 0;
           (token < yyNames.Length) && (n+token < yyTable.Length); ++ token)
        if (yyCheck[n+token] == token && !ok[token] && yyNames[token] != null) {
          ++ len;
          ok[token] = true;
        }

    string [] result = new string[len];
    for (n = token = 0; n < len;  ++ token)
      if (ok[token]) result[n++] = yyNames[token];
    return result;
  }

  /** the generated parser, with debugging messages.
      Maintains a state and a value stack, currently with fixed maximum size.
      @param yyLex scanner.
      @param yydebug debug message writer implementing yyDebug, or null.
      @return result of the last reduction, if any.
      @throws yyException on irrecoverable parse error.
    */
  internal Object yyparse (yyParser.yyInput yyLex, Object yyd)
				 {
//t    this.debug = (yydebug.yyDebug)yyd;
    return yyparse(yyLex);
  }

  /** initial size and increment of the state/value stack [default 256].
      This is not final so that it can be overwritten outside of invocations
      of yyparse().
    */
  protected int yyMax;

  /** executed at the beginning of a reduce action.
      Used as $$ = yyDefault($1), prior to the user-specified action, if any.
      Can be overwritten to provide deep copy, etc.
      @param first value for $1, or null.
      @return first.
    */
  protected Object yyDefault (Object first) {
    return first;
  }

  /** the generated parser.
      Maintains a state and a value stack, currently with fixed maximum size.
      @param yyLex scanner.
      @return result of the last reduction, if any.
      @throws yyException on irrecoverable parse error.
    */
  internal Object yyparse (yyParser.yyInput yyLex)
				{
    if (yyMax <= 0) yyMax = 256;			// initial size
    int yyState = 0;                                   // state stack ptr
    int [] yyStates = new int[yyMax];	                // state stack 
    Object yyVal = null;                               // value stack ptr
    Object [] yyVals = new Object[yyMax];	        // value stack
    int yyToken = -1;					// current input
    int yyErrorFlag = 0;				// #tks to shift

    int yyTop = 0;
    goto skip;
    yyLoop:
    yyTop++;
    skip:
    for (;; ++ yyTop) {
      if (yyTop >= yyStates.Length) {			// dynamically increase
        int[] i = new int[yyStates.Length+yyMax];
        yyStates.CopyTo (i, 0);
        yyStates = i;
        Object[] o = new Object[yyVals.Length+yyMax];
        yyVals.CopyTo (o, 0);
        yyVals = o;
      }
      yyStates[yyTop] = yyState;
      yyVals[yyTop] = yyVal;
//t      if (debug != null) debug.push(yyState, yyVal);

      yyDiscarded: for (;;) {	// discarding a token does not change stack
        int yyN;
        if ((yyN = yyDefRed[yyState]) == 0) {	// else [default] reduce (yyN)
          if (yyToken < 0) {
            yyToken = yyLex.advance() ? yyLex.token() : 0;
//t            if (debug != null)
//t              debug.lex(yyState, yyToken, yyname(yyToken), yyLex.value());
          }
          if ((yyN = yySindex[yyState]) != 0 && ((yyN += yyToken) >= 0)
              && (yyN < yyTable.Length) && (yyCheck[yyN] == yyToken)) {
//t            if (debug != null)
//t              debug.shift(yyState, yyTable[yyN], yyErrorFlag-1);
            yyState = yyTable[yyN];		// shift to yyN
            yyVal = yyLex.value();
            yyToken = -1;
            if (yyErrorFlag > 0) -- yyErrorFlag;
            goto yyLoop;
          }
          if ((yyN = yyRindex[yyState]) != 0 && (yyN += yyToken) >= 0
              && yyN < yyTable.Length && yyCheck[yyN] == yyToken)
            yyN = yyTable[yyN];			// reduce (yyN)
          else
            switch (yyErrorFlag) {
  
            case 0:
              yyerror(String.Format ("syntax error, got token `{0}'", yyname (yyToken)), yyExpecting(yyState));
//t              if (debug != null) debug.error("syntax error");
              goto case 1;
            case 1: case 2:
              yyErrorFlag = 3;
              do {
                if ((yyN = yySindex[yyStates[yyTop]]) != 0
                    && (yyN += Token.yyErrorCode) >= 0 && yyN < yyTable.Length
                    && yyCheck[yyN] == Token.yyErrorCode) {
//t                  if (debug != null)
//t                    debug.shift(yyStates[yyTop], yyTable[yyN], 3);
                  yyState = yyTable[yyN];
                  yyVal = yyLex.value();
                  goto yyLoop;
                }
//t                if (debug != null) debug.pop(yyStates[yyTop]);
              } while (-- yyTop >= 0);
//t              if (debug != null) debug.reject();
              throw new yyParser.yyException("irrecoverable syntax error");
  
            case 3:
              if (yyToken == 0) {
//t                if (debug != null) debug.reject();
                throw new yyParser.yyException("irrecoverable syntax error at end-of-file");
              }
//t              if (debug != null)
//t                debug.discard(yyState, yyToken, yyname(yyToken),
//t  							yyLex.value());
              yyToken = -1;
              goto yyDiscarded;		// leave stack alone
            }
        }
        int yyV = yyTop + 1-yyLen[yyN];
//t        if (debug != null)
//t          debug.reduce(yyState, yyStates[yyV-1], yyN, yyRule[yyN], yyLen[yyN]);
        yyVal = yyDefault(yyV > yyTop ? null : yyVals[yyV]);
        switch (yyN) {
case 1:
#line 121 "Parser.jay"
  { yyVal = new Output (((StringValue)yyVals[-3+yyTop]).Value, ((IExpression)yyVals[-1+yyTop]), ((StringValue)yyVals[-3+yyTop]).Location); }
  break;
case 2:
#line 124 "Parser.jay"
  { yyVal = new Input (((StringValue)yyVals[-6+yyTop]).Value, true, ((IPattern)yyVals[-3+yyTop]), ((IProcess)yyVals[0+yyTop]), ((StringValue)yyVals[-6+yyTop]).Location); }
  break;
case 3:
#line 127 "Parser.jay"
  { yyVal = new Input (((StringValue)yyVals[-5+yyTop]).Value, false, ((IPattern)yyVals[-3+yyTop]), ((IProcess)yyVals[0+yyTop]), ((StringValue)yyVals[-5+yyTop]).Location); }
  break;
case 4:
#line 130 "Parser.jay"
  { yyVal = new SchemaDec(((ArrayList)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]), ((int)yyVals[-3+yyTop])); }
  break;
case 5:
#line 133 "Parser.jay"
  { yyVal = new New(((StringValue)yyVals[-7+yyTop]).Value, new Chan(((IType)yyVals[-4+yyTop]), ((int)yyVals[-2+yyTop])), ((IProcess)yyVals[0+yyTop]), "", ((int)yyVals[-8+yyTop])); }
  break;
case 6:
#line 136 "Parser.jay"
  { yyVal = new New(((StringValue)yyVals[-8+yyTop]).Value, new Chan(((IType)yyVals[-5+yyTop]), ((int)yyVals[-3+yyTop])), ((IProcess)yyVals[0+yyTop]), ((string)yyVals[-2+yyTop]), ((int)yyVals[-9+yyTop])); }
  break;
case 7:
#line 139 "Parser.jay"
  { yyVal = new New(((StringValue)yyVals[-6+yyTop]).Value, new Chan(((IType)yyVals[-3+yyTop]), Chan.CAPABILITY.OUT), ((IProcess)yyVals[0+yyTop]), "", ((int)yyVals[-7+yyTop])); }
  break;
case 8:
#line 142 "Parser.jay"
  { yyVal = new New(((StringValue)yyVals[-7+yyTop]).Value, new Chan(((IType)yyVals[-4+yyTop]), Chan.CAPABILITY.OUT), ((IProcess)yyVals[0+yyTop]), ((string)yyVals[-2+yyTop]), ((int)yyVals[-8+yyTop])); }
  break;
case 9:
#line 145 "Parser.jay"
  { yyVal = new ImportDec(((StringValue)yyVals[-7+yyTop]).Value, new Chan(((IType)yyVals[-4+yyTop]), ((int)yyVals[-2+yyTop])), ((IProcess)yyVals[0+yyTop]), "", ((int)yyVals[-8+yyTop])); }
  break;
case 10:
#line 148 "Parser.jay"
  { yyVal = new ImportDec(((StringValue)yyVals[-8+yyTop]).Value, new Chan(((IType)yyVals[-5+yyTop]), ((int)yyVals[-3+yyTop])), ((IProcess)yyVals[0+yyTop]), ((string)yyVals[-2+yyTop]), ((int)yyVals[-9+yyTop])); }
  break;
case 11:
#line 151 "Parser.jay"
  { CompilerOutput.Error("declaration of new channels must be `new ID:<schema>'", lexer.location); }
  break;
case 12:
#line 154 "Parser.jay"
  { yyVal = new Spawn(((IProcess)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]), ((int)yyVals[-4+yyTop])); }
  break;
case 13:
#line 157 "Parser.jay"
  { yyVal = new MatchWith(((IExpression)yyVals[-4+yyTop]), ((ArrayList)yyVals[-1+yyTop]), ((int)yyVals[-5+yyTop])); }
  break;
case 14:
#line 160 "Parser.jay"
  { yyVal = new Select(((ArrayList)yyVals[-1+yyTop]), ((int)yyVals[-3+yyTop])); }
  break;
case 15:
#line 163 "Parser.jay"
  { yyVal = new JoinPatternDefinitionProcess(((bool)yyVals[-1+yyTop]), ((ArrayList)yyVals[0+yyTop]), ((int)yyVals[-2+yyTop])); }
  break;
case 16:
#line 166 "Parser.jay"
  { yyVal = new Zero(((int)yyVals[0+yyTop]));}
  break;
case 17:
#line 168 "Parser.jay"
  { CompilerOutput.Error("Error in process expression", lexer.location); }
  break;
case 18:
#line 172 "Parser.jay"
  { yyVal = false; }
  break;
case 19:
#line 173 "Parser.jay"
  { yyVal = true; }
  break;
case 20:
#line 178 "Parser.jay"
  {
	  ArrayList rows = new ArrayList();
		rows.Add(((JoinPatternRow)yyVals[0+yyTop]));
		yyVal = rows;
	}
  break;
case 21:
#line 185 "Parser.jay"
  {
	  ArrayList rows = (ArrayList) ((ArrayList)yyVals[-2+yyTop]);
		rows.Add(((JoinPatternRow)yyVals[0+yyTop]));
		yyVal = rows;
	}
  break;
case 22:
#line 194 "Parser.jay"
  { yyVal = new JoinPatternRow(((ArrayList)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop]), ((IProcess)yyVals[0+yyTop]).Location); }
  break;
case 23:
#line 199 "Parser.jay"
  {
		ArrayList atoms = new ArrayList();
		atoms.Add(((JoinPatternAtom)yyVals[0+yyTop]));
		yyVal = atoms;
	}
  break;
case 24:
#line 205 "Parser.jay"
  {
		ArrayList atoms = (ArrayList) ((ArrayList)yyVals[-2+yyTop]);
		atoms.Add(((JoinPatternAtom)yyVals[0+yyTop]));
		yyVal = atoms;
	}
  break;
case 25:
#line 214 "Parser.jay"
  { yyVal = new JoinPatternAtom(((StringValue)yyVals[-3+yyTop]).Value, ((IPattern)yyVals[-1+yyTop]), ((StringValue)yyVals[-3+yyTop]).Location); }
  break;
case 26:
#line 219 "Parser.jay"
  {
		ArrayList decls = new ArrayList();
		decls.Add(((SchemaDec.Declaration)yyVals[0+yyTop]));
		yyVal = decls;
	}
  break;
case 27:
#line 226 "Parser.jay"
  {
		ArrayList decls = (ArrayList) ((ArrayList)yyVals[-2+yyTop]);
		decls.Add(((SchemaDec.Declaration)yyVals[0+yyTop]));
		yyVal = decls;
	}
  break;
case 28:
#line 235 "Parser.jay"
  { yyVal = new SchemaDec.Declaration(((StringValue)yyVals[-2+yyTop]).Value, ((IType)yyVals[0+yyTop]), ((StringValue)yyVals[-2+yyTop]).Location); }
  break;
case 29:
#line 240 "Parser.jay"
  {
	  yyVal = new ArrayList();
		((ArrayList) yyVal).Add(new MatchWith.Branch(((IPattern)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop])));
	}
  break;
case 30:
#line 246 "Parser.jay"
  {
		((ArrayList)yyVals[-4+yyTop]).Add(new MatchWith.Branch(((IPattern)yyVals[-2+yyTop]), ((IProcess)yyVals[0+yyTop])));
		yyVal = ((ArrayList)yyVals[-4+yyTop]);
	}
  break;
case 31:
#line 252 "Parser.jay"
  { CompilerOutput.Error("expected token |", lexer.location); }
  break;
case 32:
#line 257 "Parser.jay"
  {
		Input ch = new Input(((StringValue)yyVals[-5+yyTop]).Value, false, ((IPattern)yyVals[-3+yyTop]), ((IProcess)yyVals[0+yyTop]), ((StringValue)yyVals[-5+yyTop]).Location);
		ArrayList tmp = new ArrayList();
		tmp.Add(ch);
		yyVal=tmp;
	}
  break;
case 33:
#line 265 "Parser.jay"
  {
		Input ch = new Input(((StringValue)yyVals[-7+yyTop]).Value, false, ((IPattern)yyVals[-5+yyTop]), ((IProcess)yyVals[-2+yyTop]), ((StringValue)yyVals[-7+yyTop]).Location);
		ArrayList tmp = (ArrayList) ((ArrayList)yyVals[0+yyTop]);
		tmp.Add(ch);
		yyVal = ((ArrayList)yyVals[0+yyTop]);
	}
  break;
case 34:
#line 275 "Parser.jay"
  { yyVal = new SchemaPattern(((IType)yyVals[0+yyTop]), lexer.location); }
  break;
case 35:
#line 278 "Parser.jay"
  { yyVal = new VarPattern(((StringValue)yyVals[-2+yyTop]).Value, ((IPattern)yyVals[0+yyTop]), ((StringValue)yyVals[-2+yyTop]).Location); }
  break;
case 36:
#line 281 "Parser.jay"
  {
		if ((((LabelsSet)yyVals[-3+yyTop]) is UnionLabel) && ((UnionLabel)((LabelsSet)yyVals[-3+yyTop])).labels.Count==0) {
			CompilerOutput.Error("emptyset of label in pattern",((int)yyVals[-2+yyTop]));
			yyVal = ((IPattern)yyVals[-1+yyTop]);
		}
		
		if ((((LabelsSet)yyVals[-3+yyTop]) is DifferenceLabel) && ((DifferenceLabel) ((LabelsSet)yyVals[-3+yyTop])).diffLabels.labels.Count == 0) {
			LabelsSet anyl = new AnyLabel();
			locationMap.Add(anyl, GetLocation(((LabelsSet)yyVals[-3+yyTop])));
			yyVal = new LabelPattern(anyl, ((IPattern)yyVals[-1+yyTop]), GetLocation(((LabelsSet)yyVals[-3+yyTop])));
		} else
			yyVal = new LabelPattern(((LabelsSet)yyVals[-3+yyTop]),((IPattern)yyVals[-1+yyTop]),GetLocation(((LabelsSet)yyVals[-3+yyTop])));
	}
  break;
case 37:
#line 296 "Parser.jay"
  {
		IPattern f;
		if ((((LabelsSet)yyVals[-5+yyTop]) is UnionLabel) && ((UnionLabel) ((LabelsSet)yyVals[-5+yyTop])).labels.Count == 0) {
			CompilerOutput.Error("emptyset of label in pattern",((int)yyVals[-4+yyTop]));
			f = ((IPattern)yyVals[-3+yyTop]);
		}

		if ((((LabelsSet)yyVals[-5+yyTop]) is DifferenceLabel) && ((DifferenceLabel) ((LabelsSet)yyVals[-5+yyTop])).diffLabels.labels.Count == 0) {
			LabelsSet anyl= new AnyLabel();
			f = new LabelPattern(anyl, ((IPattern)yyVals[-3+yyTop]), GetLocation(((LabelsSet)yyVals[-5+yyTop])));
			locationMap.Add(anyl, GetLocation(((LabelsSet)yyVals[-5+yyTop])));
		} else 
			f = new LabelPattern(((LabelsSet)yyVals[-5+yyTop]), ((IPattern)yyVals[-3+yyTop]), GetLocation(((LabelsSet)yyVals[-5+yyTop])));

		yyVal = new SequencePattern(f, ((IPattern)yyVals[0+yyTop]),GetLocation(((LabelsSet)yyVals[-5+yyTop])));
	}
  break;
case 38:
#line 315 "Parser.jay"
  {yyVal = ((IExpression)yyVals[-1+yyTop]);}
  break;
case 39:
#line 316 "Parser.jay"
  {yyVal = new VoidExp(((int)yyVals[0+yyTop]));}
  break;
case 40:
#line 317 "Parser.jay"
  {yyVal = new VariableExp(((StringValue)yyVals[0+yyTop]).Value, ((StringValue)yyVals[0+yyTop]).Location);}
  break;
case 41:
#line 318 "Parser.jay"
  {yyVal = new IntExp(((IntValue)yyVals[0+yyTop]).Value, ((IntValue)yyVals[0+yyTop]).Location);}
  break;
case 42:
#line 319 "Parser.jay"
  {yyVal = new IntExp(0, ((int)yyVals[0+yyTop]));}
  break;
case 43:
#line 320 "Parser.jay"
  {yyVal = new StringExp(((StringValue)yyVals[0+yyTop]).Value, ((StringValue)yyVals[0+yyTop]).Location);}
  break;
case 44:
#line 321 "Parser.jay"
  {yyVal = new LabelExp(((StringValue)yyVals[-3+yyTop]).Value, ((IExpression)yyVals[-1+yyTop]), ((StringValue)yyVals[-3+yyTop]).Location);}
  break;
case 45:
#line 322 "Parser.jay"
  {yyVal = new LabelExp(((StringValue)yyVals[-2+yyTop]).Value, new BoPi.Compiler.VoidExp(((int)yyVals[-1+yyTop])), ((StringValue)yyVals[-2+yyTop]).Location);}
  break;
case 46:
#line 323 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.PLUS, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 47:
#line 324 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.MINUS, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 48:
#line 325 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.TIMES, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 49:
#line 326 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.DIVIDE, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 50:
#line 327 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.EQEQ, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 51:
#line 328 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.NE, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 52:
#line 329 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.GT, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 53:
#line 330 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.GE, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 54:
#line 331 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.LT, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 55:
#line 332 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.LE, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 56:
#line 333 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.OR, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 57:
#line 334 "Parser.jay"
  {yyVal = new BinaryExp(((IExpression)yyVals[-2+yyTop]), BinaryOp.AND, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 58:
#line 335 "Parser.jay"
  {yyVal = new SequenceExp(((IExpression)yyVals[-2+yyTop]), ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[-2+yyTop]).Location);}
  break;
case 59:
#line 336 "Parser.jay"
  {yyVal = new UnaryExp(UnaryOp.NOT, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[0+yyTop]).Location);}
  break;
case 60:
#line 337 "Parser.jay"
  {yyVal = new UnaryExp(UnaryOp.UMINUS, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[0+yyTop]).Location);}
  break;
case 61:
#line 338 "Parser.jay"
  {yyVal = new UnaryExp(UnaryOp.REST, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[0+yyTop]).Location);}
  break;
case 62:
#line 339 "Parser.jay"
  {yyVal = new UnaryExp(UnaryOp.FIRST, ((IExpression)yyVals[0+yyTop]), ((IExpression)yyVals[0+yyTop]).Location);}
  break;
case 63:
#line 341 "Parser.jay"
  { CompilerOutput.Error("Error in expression", lexer.location); }
  break;
case 64:
#line 346 "Parser.jay"
  { 
		yyVal = new UnionLabel(((StringValue)yyVals[0+yyTop]).Value);
		locationMap.Add(yyVal, ((StringValue)yyVals[0+yyTop]).Location);
	}
  break;
case 65:
#line 352 "Parser.jay"
  {
		yyVal = new AnyLabel();
		locationMap.Add(yyVal, ((int)yyVals[0+yyTop]));
	}
  break;
case 66:
#line 358 "Parser.jay"
  { yyVal = LabelsSet.NormalizeUnion(((LabelsSet)yyVals[-2+yyTop]), ((LabelsSet)yyVals[0+yyTop])); }
  break;
case 67:
#line 361 "Parser.jay"
  { yyVal = LabelsSet.NormalizeDifference(((LabelsSet)yyVals[-2+yyTop]), ((LabelsSet)yyVals[0+yyTop])); }
  break;
case 68:
#line 364 "Parser.jay"
  { yyVal = ((LabelsSet)yyVals[-1+yyTop]); }
  break;
case 69:
#line 367 "Parser.jay"
  {yyVal= new Types.Void();}
  break;
case 70:
#line 368 "Parser.jay"
  {yyVal= new Types.Void();}
  break;
case 71:
#line 369 "Parser.jay"
  {yyVal= ((IType)yyVals[-1+yyTop]);}
  break;
case 72:
#line 370 "Parser.jay"
  {yyVal= new Union (((IType)yyVals[-2+yyTop]),((IType)yyVals[0+yyTop]));}
  break;
case 73:
#line 371 "Parser.jay"
  {yyVal= new ConstantTypeName(((StringValue)yyVals[0+yyTop]).Value);}
  break;
case 74:
#line 372 "Parser.jay"
  {if ((((LabelsSet)yyVals[-3+yyTop]) is UnionLabel) && ((UnionLabel)((LabelsSet)yyVals[-3+yyTop])).labels.Count==0)
					{
						CompilerOutput.Error("emptyset of label",((int)yyVals[-2+yyTop]));
						yyVal=((IType)yyVals[-1+yyTop]);
					}
					if ((((LabelsSet)yyVals[-3+yyTop]) is DifferenceLabel) &&
            ((DifferenceLabel)((LabelsSet)yyVals[-3+yyTop])).diffLabels.labels.Count==0){
              LabelsSet anyl= new AnyLabel();
              locationMap.Add(anyl,GetLocation(((LabelsSet)yyVals[-3+yyTop])));
					    yyVal= new Labelled(new AnyLabel(),((IType)yyVals[-1+yyTop]));
              locationMap.Add(yyVal,GetLocation(((LabelsSet)yyVals[-3+yyTop])));
          }
					else
					    yyVal= new Labelled(((LabelsSet)yyVals[-3+yyTop]),((IType)yyVals[-1+yyTop]));}
  break;
case 75:
#line 386 "Parser.jay"
  {if ((((LabelsSet)yyVals[-2+yyTop]) is UnionLabel) && ((UnionLabel)((LabelsSet)yyVals[-2+yyTop])).labels.Count==0)
					{
						CompilerOutput.Error("emptyset of label",((int)yyVals[-1+yyTop]));
						yyVal=new Types.Void();
					}
					if ((((LabelsSet)yyVals[-2+yyTop]) is DifferenceLabel) &&
            ((DifferenceLabel)((LabelsSet)yyVals[-2+yyTop])).diffLabels.labels.Count==0){
              LabelsSet anyl= new AnyLabel();
              locationMap.Add(anyl,GetLocation(((LabelsSet)yyVals[-2+yyTop])));
					    yyVal= new Labelled(anyl,new Types.Void());
              locationMap.Add(yyVal,GetLocation(((LabelsSet)yyVals[-2+yyTop])));
          }
					else
					    yyVal= new Labelled(((LabelsSet)yyVals[-2+yyTop]),new Types.Void());}
  break;
case 76:
#line 401 "Parser.jay"
  {if ((((LabelsSet)yyVals[-5+yyTop]) is UnionLabel) && ((UnionLabel)((LabelsSet)yyVals[-5+yyTop])).labels.Count==0)
					{
						CompilerOutput.Error("emptyset of label",((int)yyVals[-4+yyTop]));
						yyVal=new Sequence(((IType)yyVals[-3+yyTop]),((IType)yyVals[0+yyTop]));
					}
					if ((((LabelsSet)yyVals[-5+yyTop]) is DifferenceLabel) &&
            ((DifferenceLabel)((LabelsSet)yyVals[-5+yyTop])).diffLabels.labels.Count==0){
              LabelsSet anyl= new AnyLabel();
              locationMap.Add(yyVal,GetLocation(((LabelsSet)yyVals[-5+yyTop])));
					    yyVal= new Sequence(new Labelled(anyl,((IType)yyVals[-3+yyTop])),((IType)yyVals[0+yyTop]));
          }
					else
					    yyVal= new Sequence(new Labelled(((LabelsSet)yyVals[-5+yyTop]),((IType)yyVals[-3+yyTop])),((IType)yyVals[0+yyTop]));}
  break;
case 77:
#line 414 "Parser.jay"
  {if ((((LabelsSet)yyVals[-4+yyTop]) is UnionLabel) && ((UnionLabel)((LabelsSet)yyVals[-4+yyTop])).labels.Count==0)
					{
						CompilerOutput.Error("emptyset of label",((int)yyVals[-3+yyTop]));
						yyVal=new Sequence(new Types.Void(),((IType)yyVals[0+yyTop]));
					}
					if ((((LabelsSet)yyVals[-4+yyTop]) is DifferenceLabel) && ((DifferenceLabel)((LabelsSet)yyVals[-4+yyTop])).diffLabels.labels.Count==0)
					    yyVal= new Sequence(new Labelled(new AnyLabel(),new Types.Void()),((IType)yyVals[0+yyTop]));
					else
					    yyVal= new Sequence(new Labelled(((LabelsSet)yyVals[-4+yyTop]),new Types.Void()),((IType)yyVals[0+yyTop]));}
  break;
case 78:
#line 423 "Parser.jay"
  {yyVal= new Chan(((IType)yyVals[-2+yyTop]),((int)yyVals[0+yyTop]));}
  break;
case 79:
#line 424 "Parser.jay"
  {yyVal= new Sequence(((IType)yyVals[-2+yyTop]),((IType)yyVals[0+yyTop]));}
  break;
case 80:
#line 425 "Parser.jay"
  {yyVal= ((IType)yyVals[0+yyTop]);}
  break;
case 81:
#line 427 "Parser.jay"
  { CompilerOutput.Error("Error in schema expression", lexer.location); }
  break;
case 82:
#line 430 "Parser.jay"
  {yyVal=Chan.CAPABILITY.IN;}
  break;
case 83:
#line 431 "Parser.jay"
  {yyVal=Chan.CAPABILITY.OUT;}
  break;
case 84:
#line 432 "Parser.jay"
  {yyVal=Chan.CAPABILITY.INOUT;}
  break;
case 85:
#line 433 "Parser.jay"
  { CompilerOutput.Error("wrong capability", lexer.location);}
  break;
case 86:
#line 436 "Parser.jay"
  {yyVal= new IntType();}
  break;
case 87:
#line 437 "Parser.jay"
  {yyVal= new StringType();}
  break;
case 88:
#line 438 "Parser.jay"
  {yyVal= new IntLiteral(0);}
  break;
case 89:
#line 439 "Parser.jay"
  {yyVal= new IntLiteral(((IntValue)yyVals[0+yyTop]).Value);}
  break;
case 90:
#line 440 "Parser.jay"
  {yyVal= new IntLiteral(-((IntValue)yyVals[0+yyTop]).Value);}
  break;
case 91:
#line 441 "Parser.jay"
  {yyVal= new StringLiteral(((StringValue)yyVals[0+yyTop]).Value);}
  break;
#line default
        }
        yyTop -= yyLen[yyN];
        yyState = yyStates[yyTop];
        int yyM = yyLhs[yyN];
        if (yyState == 0 && yyM == 0) {
//t          if (debug != null) debug.shift(0, yyFinal);
          yyState = yyFinal;
          if (yyToken < 0) {
            yyToken = yyLex.advance() ? yyLex.token() : 0;
//t            if (debug != null)
//t               debug.lex(yyState, yyToken,yyname(yyToken), yyLex.value());
          }
          if (yyToken == 0) {
//t            if (debug != null) debug.accept(yyVal);
            return yyVal;
          }
          goto yyLoop;
        }
        if (((yyN = yyGindex[yyM]) != 0) && ((yyN += yyState) >= 0)
            && (yyN < yyTable.Length) && (yyCheck[yyN] == yyState))
          yyState = yyTable[yyN];
        else
          yyState = yyDgoto[yyM];
//t        if (debug != null) debug.shift(yyStates[yyTop], yyState);
	 goto yyLoop;
      }
    }
  }

   static  short [] yyLhs  = {              -1,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    1,    1,   10,
   10,   13,   11,   11,   14,   12,   12,   15,    2,    2,
    2,    3,    3,    4,    4,    4,    4,    5,    5,    5,
    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,
    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,
    5,    5,    5,    8,    8,    8,    8,    8,    6,    6,
    6,    6,    6,    6,    6,    6,    6,    6,    6,    6,
    6,    9,    9,    9,    9,    7,    7,    7,    7,    7,
    7,
  };
   static  short [] yyLen = {           2,
    4,    7,    6,    4,    9,   10,    8,    9,    9,   10,
    4,    5,    6,    4,    3,    1,    1,    0,    1,    1,
    3,    3,    1,    3,    4,    1,    3,    3,    3,    5,
    4,    6,    8,    1,    3,    4,    6,    3,    1,    1,
    1,    1,    1,    4,    3,    3,    3,    3,    3,    3,
    3,    3,    3,    3,    3,    3,    3,    3,    2,    2,
    2,    2,    1,    1,    1,    3,    3,    3,    2,    1,
    3,    3,    1,    4,    3,    6,    5,    4,    3,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    2,
    1,
  };
   static  short [] yyDefRed = {            0,
   17,    0,    0,    0,    0,    0,   16,    0,    0,    0,
    0,    0,    0,   63,    0,    0,   39,   43,   41,   42,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   26,    0,    0,    0,    0,   19,    0,    0,    0,   60,
    0,   59,   62,   61,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   81,    0,    0,    0,
    0,   65,   86,   87,   70,   91,   89,   88,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,   20,   23,
    0,   38,   45,    0,    0,    0,    0,    0,   48,   49,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   14,
   11,    0,    0,    0,    0,    4,   27,    1,   64,    0,
   69,    0,   90,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,   12,   44,    0,
    0,    0,    0,    0,   68,   71,    0,   35,    0,    0,
    0,    0,    0,    0,   67,   66,    0,    0,    0,   21,
   22,   24,   13,    0,    0,    0,    0,    0,   85,   82,
   83,   84,   78,    3,    0,    0,    0,    0,    0,   25,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    2,
    0,    0,   31,    0,    7,    0,    0,    0,   37,    0,
    0,    0,   30,    0,    8,    5,    0,    9,    0,   33,
    6,   10,
  };
  protected static  short [] yyDgoto  = {            12,
   37,  140,   60,   80,   25,   81,   82,  115,  173,   87,
   88,   30,   89,   90,   31,
  };
  protected static  short [] yySindex = {         -173,
    0, -241,  -80, -226, -245, -243,    0, -200, -203, -215,
 -181,    0, -173,    0,  -80,  -80,    0,    0,    0,    0,
 -176,  -80,  -80,  -80,   34, -190, -157, -142, -135, -275,
    0,  -80,  280, -111, -119,    0, -144, -102,   60,    0,
 -116,    0,    0,    0,  -80,  -80,  -80,  -80,  -80,  -80,
  -80,  -80,  -80,  -80,  -80, -100,  -80,  -80,  -99,  -98,
 -173, -107,  316, -173, -243,   86,    0, -244,  106, -129,
  316,    0,    0,    0,    0,    0,    0,    0,  -96,  -89,
  -77,  -91, -196,  280,  -79,  -67, -106, -235,    0,    0,
 -173,    0,    0,  142, -113, -113, -126, -126,    0,    0,
 -113, -113, -113, -113,  312,  280,  441,  441,  280,    0,
    0,  316,    0,  -77, -187,    0,    0,    0,    0, -258,
    0, -207,    0, -161,  280,  -70,  316,  316,  162, -244,
 -244,  -64,  316,  280, -144, -173, -144,    0,    0, -262,
  -54,  -62, -148,  198,    0,    0, -115,    0, -173,  -77,
  -77,  -74,  -57, -182,    0,    0,  -49, -143,  -53,    0,
    0,    0,    0,  280, -173,  -42, -247, -182,    0,    0,
    0,    0,    0,    0,  316,  -51,  -46, -173, -115,    0,
  -24,  -17, -173, -173,  -52, -276,  -77,  280,  316,    0,
 -286, -173,    0,  -38,    0, -173, -173,  -48,    0,  -77,
 -173,  -44,    0, -190,    0,    0, -173,    0, -173,    0,
    0,    0,
  };
  protected static  short [] yyRindex = {            0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
  -50,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    8,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  181,    0,
 -230, -237,    0,    0,    0,    0,    1,    0,    0,    0,
    0,    0,    0,    0,  -31,   27,  234,  260,    0,    0,
   53,  206,  376,  395, -192,    0,  398,  402,    0,    0,
    0,    0,  -61, -273,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0, -150,
  -94, -208,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0, -164, -160,    0,    0,    0,
    0, -259,    0,    0,    0,    0,  -39,    0,    0,    0,
    0,    0,    0,  -26,    0,    0,    0,    0,    0,  -34,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,
  };
  protected static  short [] yyGindex = {          -13,
    0,    0,   42,  -82,  603,  -59,    0,  -30, -145,    0,
    0,    0,  114,  117,  186,
  };
  protected static  short [] yyTable = {            38,
   15,  132,   83,  114,  163,  201,  145,   29,  169,  122,
   27,  124,  170,  171,  172,  197,   64,  130,   28,   68,
   80,  186,   13,  141,  202,  131,  142,   34,   65,   80,
   28,   80,  198,  191,   80,  136,   34,  120,   34,   26,
   72,  137,  148,   80,  184,  164,  153,  111,   29,   75,
  116,  159,  143,   83,   80,   28,  119,   29,   75,  146,
   75,  185,   33,   75,  127,   32,   80,  150,  151,  154,
   34,  129,   75,  158,   58,   83,   58,  138,   83,  130,
  144,  181,    1,   75,  168,   35,  177,  131,  130,  127,
   58,   41,   36,   36,   83,   75,  131,   74,   83,  155,
  156,   58,   36,   83,   36,  199,   74,   72,   74,   59,
  127,   74,    2,    3,    4,  187,   72,    5,   72,  147,
   74,    6,  161,  127,    7,    8,    9,   62,  127,  200,
   72,   74,  167,   83,   61,  174,   10,  179,   11,   14,
  169,   72,   63,   74,  170,  171,  172,   49,   50,   15,
   85,  182,   93,   72,   84,   86,   16,   83,   47,   48,
   49,   50,   91,   79,  190,  106,  109,  123,  110,  194,
  195,  112,   79,  125,   79,   14,   17,  126,  203,   18,
   19,   20,  205,  206,   21,   15,   79,  208,   22,   23,
   24,  128,   16,  211,  127,  212,   73,   79,  134,  133,
  149,  135,  157,  165,  166,   73,   64,   73,  175,   79,
   73,  176,   17,  180,   64,   18,   19,   20,   77,   73,
   21,  178,   64,   76,   22,   23,   24,   77,  183,   77,
   73,  188,   76,  192,   76,   50,  189,   50,  193,  196,
   32,   77,   73,  207,  204,  210,   76,  209,  160,   18,
  117,   50,   77,  162,    0,    0,   15,   76,    0,    0,
    0,    0,   50,    0,   77,   15,   40,   15,    0,   76,
   40,   50,   50,    0,   40,    0,   40,    0,    0,   40,
   40,   40,   40,   15,    0,    0,   40,   40,   40,   40,
   40,    0,   45,   51,    0,   51,   46,    0,    0,    0,
    0,   40,    0,    0,    0,   47,   48,   49,   50,   51,
   40,   40,   51,   52,   53,   54,   55,    0,   45,   54,
   51,   54,   46,    0,    0,    0,   92,   56,    0,   51,
   51,   47,   48,   49,   50,   54,   57,   58,   51,   52,
   53,   54,   55,    0,   45,    0,   54,    0,   46,    0,
    0,    0,  118,    0,    0,   54,   54,   47,   48,   49,
   50,   67,   57,   58,   51,   52,   53,   54,   55,   68,
    0,   69,  121,    0,    0,    0,    0,    0,   70,    0,
    0,    0,    0,    0,   71,    0,    0,    0,   57,   58,
   72,    0,    0,    0,   73,   74,    0,    0,   75,    0,
   45,   76,   77,   78,   46,    0,  113,    0,    0,    0,
  139,    0,    0,   47,   48,   49,   50,   67,    0,    0,
   51,   52,   53,   54,   55,   68,    0,   69,    0,    0,
  152,    0,    0,    0,   70,    0,    0,    0,   73,    0,
   71,    0,    0,    0,   57,   58,   72,   73,   64,   73,
   73,   74,   73,   67,   75,    0,   64,   76,   77,   78,
    0,   68,   79,   69,   64,    0,  152,    0,    0,    0,
   70,    0,   55,    0,   55,    0,   71,    0,    0,    0,
    0,    0,   72,    0,    0,    0,   73,   74,   55,    0,
   75,    0,   46,   76,   77,   78,   46,    0,  113,   55,
   46,    0,   46,    0,    0,   46,   46,    0,   55,   55,
    0,    0,   46,   46,   46,   46,   46,    0,   47,    0,
    0,    0,   47,    0,    0,    0,   47,   46,   47,    0,
    0,   47,   47,    0,    0,   67,   46,   46,   47,   47,
   47,   47,   47,   68,    0,   69,    0,    0,    0,    0,
    0,    0,   70,   47,    0,    0,    0,    0,   71,    0,
    0,    0,   47,   47,   72,    0,    0,    0,   73,   74,
   45,   67,   75,    0,   46,   76,   77,   78,    0,   68,
   79,   69,    0,   47,   48,   49,   50,    0,   70,    0,
   51,   52,   53,   54,   71,    0,    0,    0,    0,    0,
   72,    0,    0,    0,   73,   74,    0,    0,   75,    0,
    0,   76,   77,   78,   57,   58,  113,   39,   40,    0,
    0,    0,    0,    0,   42,   43,   44,    0,    0,    0,
    0,    0,    0,    0,   66,    0,    0,    0,    0,    0,
    0,    0,   52,   94,   52,    0,    0,   95,   96,   97,
   98,   99,  100,  101,  102,  103,  104,  105,   52,  107,
  108,   53,    0,   53,   56,    0,   56,    0,   57,   52,
   57,    0,    0,    0,    0,    0,    0,   53,   52,   52,
   56,    0,    0,    0,   57,    0,    0,    0,   53,    0,
    0,   56,    0,    0,    0,   57,    0,   53,   53,   45,
   56,   56,    0,   46,   57,   57,    0,    0,    0,    0,
    0,    0,   47,   48,   49,   50,    0,    0,    0,   51,
   52,   53,   54,
  };
  protected static  short [] yyCheck = {            13,
    0,   84,   33,   63,  267,  292,  265,  267,  256,   69,
  256,   71,  260,  261,  262,  292,  292,  276,  292,  264,
  258,  167,  264,  106,  311,  284,  109,  258,  304,  267,
  304,  269,  309,  179,  272,  271,  267,   68,  269,  266,
  285,  277,  125,  281,  292,  308,  129,   61,  308,  258,
   64,  134,  112,   84,  292,  301,  301,  301,  267,  267,
  269,  309,  266,  272,  272,  266,  304,  127,  128,  129,
  274,  268,  281,  133,  267,  106,  269,   91,  109,  276,
  268,  164,  256,  292,  144,  301,  269,  284,  276,  272,
  283,  268,  274,  258,  125,  304,  284,  258,  129,  130,
  131,  294,  267,  134,  269,  188,  267,  258,  269,  300,
  272,  272,  286,  287,  288,  175,  267,  291,  269,  281,
  281,  295,  136,  272,  298,  299,  300,  270,  272,  189,
  281,  292,  281,  164,  292,  149,  310,  281,  312,  256,
  256,  292,  278,  304,  260,  261,  262,  274,  275,  266,
  270,  165,  269,  304,  266,  300,  273,  188,  272,  273,
  274,  275,  265,  258,  178,  266,  266,  297,  267,  183,
  184,  279,  267,  270,  269,  256,  293,  267,  192,  296,
  297,  298,  196,  197,  301,  266,  281,  201,  305,  306,
  307,  283,  273,  207,  272,  209,  258,  292,  266,  279,
  271,  308,  267,  258,  267,  267,  268,  269,  283,  304,
  272,  269,  293,  267,  276,  296,  297,  298,  258,  281,
  301,  271,  284,  258,  305,  306,  307,  267,  271,  269,
  292,  283,  267,  258,  269,  267,  283,  269,  256,  292,
  267,  281,  304,  292,  283,  204,  281,  292,  135,  300,
   65,  283,  292,  137,   -1,   -1,  256,  292,   -1,   -1,
   -1,   -1,  294,   -1,  304,  265,  259,  267,   -1,  304,
  263,  303,  304,   -1,  267,   -1,  269,   -1,   -1,  272,
  273,  274,  275,  283,   -1,   -1,  279,  280,  281,  282,
  283,   -1,  259,  267,   -1,  269,  263,   -1,   -1,   -1,
   -1,  294,   -1,   -1,   -1,  272,  273,  274,  275,  283,
  303,  304,  279,  280,  281,  282,  283,   -1,  259,  267,
  294,  269,  263,   -1,   -1,   -1,  267,  294,   -1,  303,
  304,  272,  273,  274,  275,  283,  303,  304,  279,  280,
  281,  282,  283,   -1,  259,   -1,  294,   -1,  263,   -1,
   -1,   -1,  267,   -1,   -1,  303,  304,  272,  273,  274,
  275,  256,  303,  304,  279,  280,  281,  282,  283,  264,
   -1,  266,  267,   -1,   -1,   -1,   -1,   -1,  273,   -1,
   -1,   -1,   -1,   -1,  279,   -1,   -1,   -1,  303,  304,
  285,   -1,   -1,   -1,  289,  290,   -1,   -1,  293,   -1,
  259,  296,  297,  298,  263,   -1,  301,   -1,   -1,   -1,
  269,   -1,   -1,  272,  273,  274,  275,  256,   -1,   -1,
  279,  280,  281,  282,  283,  264,   -1,  266,   -1,   -1,
  269,   -1,   -1,   -1,  273,   -1,   -1,   -1,  258,   -1,
  279,   -1,   -1,   -1,  303,  304,  285,  267,  268,  269,
  289,  290,  272,  256,  293,   -1,  276,  296,  297,  298,
   -1,  264,  301,  266,  284,   -1,  269,   -1,   -1,   -1,
  273,   -1,  267,   -1,  269,   -1,  279,   -1,   -1,   -1,
   -1,   -1,  285,   -1,   -1,   -1,  289,  290,  283,   -1,
  293,   -1,  259,  296,  297,  298,  263,   -1,  301,  294,
  267,   -1,  269,   -1,   -1,  272,  273,   -1,  303,  304,
   -1,   -1,  279,  280,  281,  282,  283,   -1,  259,   -1,
   -1,   -1,  263,   -1,   -1,   -1,  267,  294,  269,   -1,
   -1,  272,  273,   -1,   -1,  256,  303,  304,  279,  280,
  281,  282,  283,  264,   -1,  266,   -1,   -1,   -1,   -1,
   -1,   -1,  273,  294,   -1,   -1,   -1,   -1,  279,   -1,
   -1,   -1,  303,  304,  285,   -1,   -1,   -1,  289,  290,
  259,  256,  293,   -1,  263,  296,  297,  298,   -1,  264,
  301,  266,   -1,  272,  273,  274,  275,   -1,  273,   -1,
  279,  280,  281,  282,  279,   -1,   -1,   -1,   -1,   -1,
  285,   -1,   -1,   -1,  289,  290,   -1,   -1,  293,   -1,
   -1,  296,  297,  298,  303,  304,  301,   15,   16,   -1,
   -1,   -1,   -1,   -1,   22,   23,   24,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   32,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,  267,   41,  269,   -1,   -1,   45,   46,   47,
   48,   49,   50,   51,   52,   53,   54,   55,  283,   57,
   58,  267,   -1,  269,  267,   -1,  269,   -1,  267,  294,
  269,   -1,   -1,   -1,   -1,   -1,   -1,  283,  303,  304,
  283,   -1,   -1,   -1,  283,   -1,   -1,   -1,  294,   -1,
   -1,  294,   -1,   -1,   -1,  294,   -1,  303,  304,  259,
  303,  304,   -1,  263,  303,  304,   -1,   -1,   -1,   -1,
   -1,   -1,  272,  273,  274,  275,   -1,   -1,   -1,  279,
  280,  281,  282,
  };

#line 445 "Parser.jay"

    public Object parse (string file)
    {
        locationMap = new Hashtable();
        lexer = new Lexer(file);
        return yyparse (lexer);
    }
    public int GetLocation(Object obj)
    {
      return (int)locationMap[obj];
    }
}
#line default
namespace yydebug {
        using System;
	 internal interface yyDebug {
		 void push (int state, Object value);
		 void lex (int state, int token, string name, Object value);
		 void shift (int from, int to, int errorFlag);
		 void pop (int state);
		 void discard (int state, int token, string name, Object value);
		 void reduce (int from, int to, int rule, string text, int len);
		 void shift (int from, int to);
		 void accept (Object value);
		 void error (string message);
		 void reject ();
	 }
	 
	 class yyDebugSimple : yyDebug {
		 void println (string s){
			 Console.Error.WriteLine (s);
		 }
		 
		 public void push (int state, Object value) {
			 println ("push\tstate "+state+"\tvalue "+value);
		 }
		 
		 public void lex (int state, int token, string name, Object value) {
			 println("lex\tstate "+state+"\treading "+name+"\tvalue "+value);
		 }
		 
		 public void shift (int from, int to, int errorFlag) {
			 switch (errorFlag) {
			 default:				// normally
				 println("shift\tfrom state "+from+" to "+to);
				 break;
			 case 0: case 1: case 2:		// in error recovery
				 println("shift\tfrom state "+from+" to "+to
					     +"\t"+errorFlag+" left to recover");
				 break;
			 case 3:				// normally
				 println("shift\tfrom state "+from+" to "+to+"\ton error");
				 break;
			 }
		 }
		 
		 public void pop (int state) {
			 println("pop\tstate "+state+"\ton error");
		 }
		 
		 public void discard (int state, int token, string name, Object value) {
			 println("discard\tstate "+state+"\ttoken "+name+"\tvalue "+value);
		 }
		 
		 public void reduce (int from, int to, int rule, string text, int len) {
			 println("reduce\tstate "+from+"\tuncover "+to
				     +"\trule ("+rule+") "+text);
		 }
		 
		 public void shift (int from, int to) {
			 println("goto\tfrom state "+from+" to "+to);
		 }
		 
		 public void accept (Object value) {
			 println("accept\tvalue "+value);
		 }
		 
		 public void error (string message) {
			 println("error\t"+message);
		 }
		 
		 public void reject () {
			 println("reject");
		 }
		 
	 }
}
// %token constants
 class Token {
  public const int ERROR = 257;
  public const int ARROW = 258;
  public const int EQEQ = 259;
  public const int I = 260;
  public const int O = 261;
  public const int IO = 262;
  public const int NE = 263;
  public const int LBRACE = 264;
  public const int RBRACE = 265;
  public const int LPAREN = 266;
  public const int RPAREN = 267;
  public const int LBRACK = 268;
  public const int RBRACK = 269;
  public const int COLON = 270;
  public const int DOT = 271;
  public const int PLUS = 272;
  public const int MINUS = 273;
  public const int TIMES = 274;
  public const int DIVIDE = 275;
  public const int BACKSLASH = 276;
  public const int AMPERSAND = 277;
  public const int EQ = 278;
  public const int LT = 279;
  public const int LE = 280;
  public const int GT = 281;
  public const int GE = 282;
  public const int COMMA = 283;
  public const int SHARP = 284;
  public const int TILDE = 285;
  public const int SPAWN = 286;
  public const int MATCH = 287;
  public const int SELECT = 288;
  public const int INT = 289;
  public const int STRING = 290;
  public const int NEW = 291;
  public const int IN = 292;
  public const int VOID = 293;
  public const int WITH = 294;
  public const int SCHEMADEF = 295;
  public const int TEXT = 296;
  public const int NUMBER = 297;
  public const int ZERO = 298;
  public const int CHANOUT = 299;
  public const int CHANIN = 300;
  public const int ID = 301;
  public const int EXP = 302;
  public const int OR = 303;
  public const int AND = 304;
  public const int NOT = 305;
  public const int FIRST = 306;
  public const int REST = 307;
  public const int ORMATCH = 308;
  public const int LOCATION = 309;
  public const int IMPORT = 310;
  public const int IMPORTBODY = 311;
  public const int JOIN_KW = 312;
  public const int Declaration = 313;
  public const int ORPLUS = 314;
  public const int UMINUS = 315;
  public const int yyErrorCode = 256;
 }
 namespace yyParser {
  using System;
  /** thrown for irrecoverable syntax errors and stack overflow.
    */
  internal class yyException : System.Exception {
    public yyException (string message) : base (message) {
    }
  }

  /** must be implemented by a scanner object to supply input to the parser.
    */
  internal interface yyInput {
    /** move on to next token.
        @return false if positioned beyond tokens.
        @throws IOException on input error.
      */
    bool advance (); // throws java.io.IOException;
    /** classifies current token.
        Should not be called if advance() returned false.
        @return current %token or single character.
      */
    int token ();
    /** associated with current token.
        Should not be called if advance() returned false.
        @return value for token().
      */
    Object value ();
  }
 }
} // close outermost namespace, that MUST HAVE BEEN opened in the prolog
