// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using BoPi.Common;
using BoPi.Types;
using System.Xml;

namespace BoPi.Compiler
{
	public interface IPattern
	{
		void ResolveNames(TypeSymbolTable tst, CompilerValueSymbolTable vst);
		IType SchemaOf();
		void AllocateNames(AllocateContext context);
    void Compile(XmlWriter code);
		int Location { get; }
	}

	public abstract class Pattern : IPattern
	{
    private readonly int location;

		public int Location {
			get { return location; }
		}

		public Pattern(int location)
		{ this.location = location; }

		public abstract void ResolveNames(TypeSymbolTable tst, CompilerValueSymbolTable vst);
		public abstract IType SchemaOf();
		public virtual void AllocateNames(AllocateContext context)
		{ }
		public abstract void Compile(XmlWriter code);
	}

	public class SchemaPattern : Pattern
	{
		private readonly IType content;

		public SchemaPattern(IType content, int location)
			: base(location)
		{ this.content = content; }

		public override void ResolveNames(TypeSymbolTable tst, CompilerValueSymbolTable vst)
		{ content.ResolveNames(tst); }

		public override IType SchemaOf()
		{ return content; }

    public override void Compile(XmlWriter code)
    {
      code.WriteStartElement("schema");
      content.Compile(code);
      code.WriteEndElement();
    }
	}

	public class VarPattern : Pattern
	{
		private readonly IPattern content;
		private readonly String id;
		private ISymbolTableValueEntry entry;

		public VarPattern(String id, IPattern content, int location)
			: base(location)
		{
			this.content = content;
			this.id = id;
			this.entry = null;
		}

		public override void ResolveNames(TypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			content.ResolveNames(tst, vst);
			entry = vst.New(id, content.SchemaOf());
		}

		public override IType SchemaOf()
		{ return content.SchemaOf(); }

		public override void AllocateNames(AllocateContext context)
		{
			if (entry.Used) entry.Index = context.NextIndex;
			content.AllocateNames(context);
		}

    public override void Compile(XmlWriter code)
    {
			if (entry.Used) {
      	code.WriteStartElement("bind");
      	code.WriteAttributeString("index", entry.Index.ToString());
				code.WriteAttributeString("name", entry.Name);
			}

      content.Compile(code);

			if (entry.Used)
      	code.WriteEndElement();
    }
	}
  
	public class LabelPattern : Pattern
	{
		private readonly LabelsSet label;
		private readonly IPattern content;

		public LabelPattern(LabelsSet label, IPattern content, int location)
			: base(location)
		{
			this.content = content;
			this.label = label;
		}

		public override void ResolveNames(TypeSymbolTable tst, CompilerValueSymbolTable vst)
		{ content.ResolveNames(tst, vst); }

		public override IType SchemaOf()
		{ return new Labelled(label,content.SchemaOf()); }

		public override void AllocateNames(AllocateContext context)
		{ content.AllocateNames(context); }

    public override void Compile(XmlWriter code)
    {
      code.WriteStartElement("labelled");
      label.GetCode(code);
      content.Compile(code);
      code.WriteEndElement();
    }
	}
  
	public class SequencePattern : Pattern
	{		
		private readonly IPattern top;
		private readonly IPattern tail;

		public SequencePattern(IPattern top, IPattern tail, int location)
			: base(location)
		{
			this.top = top;
			this.tail = tail;
		}

		public override void ResolveNames(TypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			top.ResolveNames(tst, vst);
			tail.ResolveNames(tst, vst);
		}

		public override IType SchemaOf()
		{ return new Sequence(top.SchemaOf(),tail.SchemaOf()); }

		public override void AllocateNames(AllocateContext context)
		{
			top.AllocateNames(context);
			tail.AllocateNames(context);
		}

    public override void Compile(XmlWriter code)
    {			
      top.Compile(code);
      tail.Compile(code);
    }
	}
}
