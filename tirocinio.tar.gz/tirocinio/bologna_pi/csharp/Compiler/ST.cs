// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using BoPi.Common;
using BoPi.Types;

namespace BoPi.Compiler
{

  public class CompilerTypeSymbolTable : TypeSymbolTable
  {
    private int nextIndex = 0;
    private ArraySet names = new ArraySet();

    public ISymbolTableTypeEntry Lookup(string name, int location)
    {
      ISymbolTableTypeEntry entry = (ISymbolTableTypeEntry) base.Lookup(name);
    	if (entry == null) {
    	  CompilerOutput.Error("constant name " + name + " is not declared", location);
    		return New(name, new ErrorType());
    	} else return entry;
    }

    public override ISymbolTableEntry Lookup(string name)
    {
      ISymbolTableTypeEntry entry = (ISymbolTableTypeEntry) base.Lookup(name);
    	if (entry == null) 
    		return New(name, new ErrorType());
    	else return entry;
    }
    
    public override ISymbolTableTypeEntry New(string name, IType type)
    {
      ISymbolTableTypeEntry entry = base.New(name, type);
      if (names.Contains(name)) 
        entry.FreshName = name + "%" + (nextIndex++).ToString();
      else 
        entry.FreshName = name;
      names.Add(name);
      return entry;
    }
  }

	public class CompilerValueSymbolTable : ValueSymbolTable
	{
		private int nextIndex = 0;

		public ISymbolTableValueEntry Lookup(string name, int location)
		{
			ISymbolTableValueEntry entry = (ISymbolTableValueEntry) base.Lookup(name);
			if (entry == null) {
				CompilerOutput.Error("variable " + name + " is not declared", location);
				return New(name, new ErrorType());
			} else return entry;
		}

		public override ISymbolTableValueEntry New(string name, IType type)
		{
			ISymbolTableValueEntry entry = base.New(name, type);
			return entry;
		}

    public ISymbolTableValueEntry New()
    {
			int index = nextIndex++;
			ISymbolTableValueEntry entry = this.New("%tmp" + index.ToString(), null);
			entry.SetUsed(); // temporary locations are assumed to be always used
			return entry;
		}
	}
}

