// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Diagnostics;
using System.Xml;
using System.IO;
using BoPi.Common;
using BoPi.Types;

namespace BoPi.Compiler
{
	public class AllocateContext
	{
		private readonly Stack size;
		private int currentSize; // size of the environment

		public AllocateContext()
		{
			this.size = new Stack();
			this.currentSize = 0;
		}

		public void Enter()
		{ size.Push(currentSize); }

		public void Exit()
		{ currentSize = (int) size.Pop(); }

		public int NextIndex { get { return currentSize++; } }
		public int Size { get { return currentSize; } }

		public void Alloc(int n)
		{
			Debug.Assert(n >= currentSize);
			currentSize = n;
		}
	}

	public interface IProcess
	{
		int Location { get; }
		void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst);
		void Check();
		void AllocateNames(AllocateContext context);
		void Compile(XmlWriter dec, XmlWriter code);
	}

	public abstract class Process : IProcess
	{
		private readonly int location;

		public Process(int location)
		{ this.location = location; }

		public int Location { get { return location; } }

		public abstract void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst);
		public abstract void Check();
		public virtual void AllocateNames(AllocateContext context)
		{ }
		public abstract void Compile(XmlWriter dec, XmlWriter code);

    public static ITypeChecker typeChecker = new TypeChecker();		
	}

	public class Output : Process
	{
		private readonly string id;
		private ISymbolTableValueEntry entry;
		private readonly IExpression exp;

		public Output(string id, IExpression exp, int location)
			: base(location)
		{
			this.id = id;
			this.entry = null;
			this.exp = exp;
		}

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{ 
			entry = vst.Lookup(id, Location);
			exp.ResolveNames(vst);
		}

		public override void Check()
		{
			Debug.Assert(entry != null);
			Debug.Assert(entry.Type != null);

			IType t = exp.TypeOf();
      IType s = entry.Type;
      if (entry.Fresh) s = new Chan(s.AsChan().Carried, Chan.CAPABILITY.INOUT);

      if (!typeChecker.IsSubtype(s, new Chan(t, Chan.CAPABILITY.OUT)))
      {
        if (entry.Type.IsChan()) {
          Chan c = entry.Type.AsChan();
          if (!c.HasOutputCapability())
            CompilerOutput.Error("channel - " + id + " - does not have output capability", Location);
          if (!typeChecker.IsSubtype(t, c.Carried))
            CompilerOutput.Error("the expression cannot be sent over the channel - " + 
              id + " - " + t + "!<:" + c.Carried, Location);
        }
        else CompilerOutput.Error("variable - " + id + " - the output is not correct (check that " + id + " is a sum of channels with output capability and that the expression can be sent over it", Location);
      }
		}

		public override void Compile(XmlWriter dec, XmlWriter code)
		{	
			code.WriteStartElement("send");
			code.WriteAttributeString("ch", entry.Index.ToString());
      code.WriteAttributeString("ch-name", entry.Name.ToString());
			code.WriteStartElement("expression");
			exp.Compile(code);
			code.WriteEndElement(); // </expression>
			code.WriteEndElement(); // </send>
		}
	}

	public class Input : Process
	{
		public readonly string id;
		private ISymbolTableValueEntry entry;
		private readonly IPattern f;
		private readonly IProcess p;
		private readonly bool star;  //true => x?*(F).P  | false => x?(F).P

		public ISymbolTableValueEntry Entry { get { return entry; } }
		public IPattern Pattern { get { return f; } }
		public IProcess Process { get { return p; } }
						
		public Input(string id, bool star, IPattern f, IProcess p, int location)
			: base(location)
		{
			this.id = id;
			this.entry = null;
			this.f = f;
			this.p = p;
			this.star = star;
		}

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			entry = vst.Lookup(id, Location);
			vst.Enter();
			f.ResolveNames(tst, vst);
			p.ResolveNames(tst, vst);

			foreach (ISymbolTableValueEntry e in vst.Exit())
				if (!e.Used)
					CompilerOutput.Warning("unused variable - " + e.Name, Location);
		}

		public override void Check()
		{
			Debug.Assert(entry != null);
			Debug.Assert(entry.Type != null);

			IType t = f.SchemaOf();
      String error;
      if (!typeChecker.IsCorrect(t, out error))
        CompilerOutput.Error("input pattern - error " + error, Location);
      else 
      {
        IType s = entry.Type;
        if (entry.Fresh) s = new Chan(s.AsChan().Carried, Chan.CAPABILITY.INOUT);
        
        if (!typeChecker.IsSubtype(s, new Chan(t, Chan.CAPABILITY.IN)))
        {
          if (s.IsChan())//only for giving a more readable error message
          { 
            Chan c = s.AsChan();
            if (!c.HasInputCapability())
              CompilerOutput.Error("channel - " + id + " - does not have input capability", Location);
            if (!typeChecker.IsSubtype(c.Carried, t))
              CompilerOutput.Error("the schema of the pattern is not exhaustive for channel - " +
                id  + " - " + c.Carried + "!<:" + t,Location);
          }
          else CompilerOutput.Error("variable - " + id + " - the input is not correct (check that " + id + " is a sum of channels with input capability and that the pattern is exhaustive", Location);
        }
      }
			p.Check();
		}

		public override void AllocateNames(AllocateContext context)
		{
			f.AllocateNames(context);
			p.AllocateNames(context);
		}

		public override void Compile(XmlWriter dec, XmlWriter code)
		{			
			if (star)
				code.WriteStartElement("service");
			else
        code.WriteStartElement("receive");
		  code.WriteAttributeString("ch", entry.Index.ToString());
      code.WriteAttributeString("ch-name", entry.Name.ToString());
			code.WriteStartElement("pattern");
			f.Compile(code);
			code.WriteEndElement(); // </pattern>
			code.WriteEndElement(); // </service> or </receive>
			p.Compile(dec, code);
		}
	}

	public class Spawn : Process
	{
		private readonly IProcess left;
		private readonly IProcess right;
		private int parentEnvSize;
		private int leftEnvSize;

		public Spawn(IProcess left, IProcess right, int location)
			: base(location)
		{
			this.left = left;
			this.right = right;
			this.parentEnvSize = 0;
			this.leftEnvSize = 0;
		}

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
      vst.Enter();
			left.ResolveNames(tst, vst);
      vst.Exit();
			right.ResolveNames(tst, vst);
		}

		public override void Check()
		{
			left.Check();
			right.Check();
		}

		public override void AllocateNames(AllocateContext context)
		{
			parentEnvSize = context.Size;
			context.Enter();
			left.AllocateNames(context);
			leftEnvSize = context.Size;
			Debug.Assert(leftEnvSize >= parentEnvSize);
			context.Exit();
			right.AllocateNames(context);
		}

		public override void Compile(XmlWriter dec, XmlWriter code)
		{
			code.WriteStartElement("spawn");
			code.WriteAttributeString("parent-env-size", parentEnvSize.ToString());
			code.WriteAttributeString("local-env-size", (leftEnvSize - parentEnvSize).ToString());
			left.Compile(dec, code);
      code.WriteEndElement(); // </spawn>
			right.Compile(dec, code);			
		}
	}

	public class Zero : Process
	{
		public Zero(int location) : base(location)
		{ }

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{ }

		public override void Check()
		{ }		

		public override void Compile(XmlWriter dec, XmlWriter code)
		{ }
	}

	public class MatchWith : Process
	{
		public class Branch
		{
			private readonly IPattern pattern;
			private readonly IProcess process;

			public IPattern Pattern { get { return pattern; } }
			public IProcess Process { get { return process; } }

			public Branch(IPattern pattern, IProcess process)
			{
				this.pattern = pattern;
				this.process = process;
			}

			public int AllocateNames(AllocateContext context)
			{
				context.Enter();
				pattern.AllocateNames(context);
				process.AllocateNames(context);
				int size = context.Size;
				context.Exit();
				return size;
			}

			public void Compile(XmlWriter dec, XmlWriter code)
			{
				code.WriteStartElement("branch");				
				code.WriteStartElement("pattern");
				pattern.Compile(code);				
				code.WriteEndElement(); // </pattern>
				code.WriteStartElement("process");
				process.Compile(dec, code);
				code.WriteEndElement(); // </process>
				code.WriteEndElement(); // </branch>
			}
		}

		private readonly IExpression exp;
		private readonly IList branches;

		public MatchWith(IExpression exp, ArrayList branches, int location)
			: base(location)
		{
			this.exp = exp;
			this.branches = branches;
		}

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			exp.ResolveNames(vst);
			foreach (Branch b in branches) {
				vst.Enter();
				b.Pattern.ResolveNames(tst, vst);
				b.Process.ResolveNames(tst, vst);
				foreach (ISymbolTableValueEntry e in vst.Exit())
					if (!e.Used)
						CompilerOutput.Warning("unused variable - " + e.Name, b.Pattern.Location);
			}
		}
						
		public override void Check()
		{
			IType schemaofexp = exp.TypeOf();

			foreach (Branch b in branches)
				b.Process.Check();

			IType[] schemasofpatterns = new IType[branches.Count];		
			for (int i = 0; i < branches.Count; i++) {
				Branch branch = (Branch) branches[i];
				schemasofpatterns[i] = branch.Pattern.SchemaOf();

				string error;
				if (!typeChecker.IsCorrect(schemasofpatterns[i], out error))
					CompilerOutput.Error("pattern - error " + error, Location);
			}

			IType t = schemasofpatterns[0];
      //a branch is useless iff:
      //(a) it is a subtype of the union of the previous patterns; 
      //(b) the schema of the expression is not a subtype of the previous patterns (previous patterns are exahustive without using the branch)
      //(c) it does not intersect the type of the expression to match
      if (TypesOperations.EmptyIntersection(t, schemaofexp))
        CompilerOutput.Warning("pattern matching useless branch (intersection with expression type is empty)", ((Branch) branches[0]).Pattern.Location);
			for (int i = 1; i < branches.Count; i++) {
        if (TypesOperations.EmptyIntersection(schemasofpatterns[i], schemaofexp))
          CompilerOutput.Warning("useless branch (intersection with expression type is empty)", ((Branch) branches[i]).Pattern.Location);
        else if (typeChecker.IsSubtype(schemasofpatterns[i], t) || typeChecker.IsSubtype(schemaofexp, t))
          CompilerOutput.Warning("redundant branch (" + schemasofpatterns[i] + "<:" + t +")", ((Branch) branches[i]).Pattern.Location);
				t = new Union(t, schemasofpatterns[i]);
			}
			if (!typeChecker.IsSubtype(schemaofexp, t))
				CompilerOutput.Error("pattern matching must be exhaustive", Location);
		}

		public override void AllocateNames(AllocateContext context)
		{
			int maxSize = 0;
			foreach (Branch branch in branches)
				maxSize = Math.Max(maxSize, branch.AllocateNames(context));
			context.Alloc(maxSize);
		}

		public override void Compile(XmlWriter dec, XmlWriter code)
		{
			code.WriteStartElement("match");			
			code.WriteStartElement("expression");
			exp.Compile(code);
			code.WriteEndElement(); // </expression>
			foreach (Branch branch in branches)
				branch.Compile(dec, code);
			code.WriteEndElement(); // </match>
		}
	}

	public class Select : Process
	{
		private readonly ArrayList selectdec;

		public Select(ArrayList selectdec, int location)
			: base(location)
		{ this.selectdec = selectdec; }

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
      foreach (Input c in selectdec)
        c.ResolveNames(tst, vst);
		}

		public override void Check()
		{			
			IList nameclash = new ArrayList();
			foreach (Input c in selectdec)	{
				if (nameclash.Contains(c.id))
					CompilerOutput.Error("channel - " + c.id + " - is duplicate in select", c.Location);
				nameclash.Add(c.id);
				c.Check();				
			}
		}

		public override void AllocateNames(AllocateContext context)
		{
			Debug.Assert(false);
		}

		public override void Compile(XmlWriter dec, XmlWriter code)
		{
			code.WriteStartElement("select");			
			foreach (Input ch in selectdec) {
				code.WriteStartElement("branch");				
				code.WriteStartElement("receive");
				code.WriteAttributeString("ch",ch.Entry.Index.ToString());
        code.WriteAttributeString("ch-name", ch.Entry.Name.ToString());
				code.WriteEndElement();
				code.WriteStartElement("pattern");
				ch.Pattern.Compile(code);
				code.WriteEndElement(); // </pattern>
				code.WriteStartElement("process");
				ch.Process.Compile(dec, code);
				code.WriteEndElement(); // </process>
				code.WriteEndElement(); // </branch>
			}
			code.WriteEndElement(); // </select>
		}
	}

	public class ImportDec : Process
	{
		private readonly string name;
		private ISymbolTableValueEntry entry;
		private readonly IType type;
		private readonly IProcess p;
		private readonly string wsdl;

		public ImportDec(string name,IType type,IProcess p,string wsdl,int location)
			: base(location)
		{
			this.name = name;
			this.entry = null;
			this.type = type;
			this.p = p;
			this.wsdl = wsdl;
		}

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			type.ResolveNames(tst);
			vst.Enter();
			entry = vst.New(name, type);
			p.ResolveNames(tst, vst);
			foreach (ISymbolTableValueEntry e in vst.Exit())
				if (!e.Used)
					CompilerOutput.Warning("unused variable - " + e.Name, Location);
		}

		public override void Check()
		{
			Debug.Assert(entry != null);
			p.Check();
		}

		public override void AllocateNames(AllocateContext context)
		{
			if (entry.Used) entry.Index = context.NextIndex;
			p.AllocateNames(context);
		}

		public override void Compile(XmlWriter dec, XmlWriter code)
		{
			if (entry.Used) {
				code.WriteStartElement("import");
				code.WriteAttributeString("target", entry.Index.ToString());
				code.WriteAttributeString("location","");
				code.WriteAttributeString("wsdl",wsdl);			
				//if (wsdl=="") code.WriteAttributeString("name",name); TODO: wsdl="" ???
				type.Compile(code);
				code.WriteEndElement();//import
			}

			p.Compile(dec, code);
		}
	}

	public class New : Process
	{
		private readonly string name;
		private ISymbolTableValueEntry entry;
		private readonly IType type;
		private readonly IProcess p;
		private readonly string chanlocation;

		public New(string name, IType type, IProcess p, string chanlocation, int location)
			: base(location)
		{
			this.name = name;
			this.entry = null;
			this.type = type;
			this.p = p;
			this.chanlocation = chanlocation;
		}

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			type.ResolveNames(tst);
			vst.Enter();
			entry = vst.New(name, type);
			entry.Fresh = true;
			p.ResolveNames(tst, vst);
			foreach (ISymbolTableValueEntry e in vst.Exit())
				if (!e.Used)
					CompilerOutput.Warning("unused channel - " + e.Name, Location);
		}

		public override void Check()
		{
      string error;
      if (!typeChecker.IsCorrect(type, out error))
				CompilerOutput.Error("channel declaration is not correct: - " + type + " " + error, Location);

			p.Check();
		}
		
		public override void AllocateNames(AllocateContext context)
		{
			if (entry.Used) entry.Index = context.NextIndex;
			p.AllocateNames(context);
		}

		public override void Compile(XmlWriter dec, XmlWriter code)
		{
			if (entry.Used) {
				code.WriteStartElement("new");
				code.WriteAttributeString("target", entry.Index.ToString());
      	code.WriteAttributeString("target-name", entry.Name.ToString());
				if (chanlocation != "") code.WriteAttributeString("location", chanlocation);
				type.Compile(code);
				code.WriteEndElement();//new+
			}

			p.Compile(dec, code);
		}
	}

	public class SchemaDec : Process
	{
		public class Declaration
		{
			private readonly int location;
			private readonly string name;
			private ISymbolTableTypeEntry entry;
			private readonly IType type;

			public int Location { get { return location; } }
			public string Name { get { return name; } }
			public ISymbolTableTypeEntry Entry { get { return entry; } }
			public IType Type { get { return type; } }

			public Declaration(string name, IType type, int location)
			{
				this.name = name;
				this.type = type;
				this.location = location;
			}

			public void Declare(CompilerTypeSymbolTable tst)
			{
				entry = tst.New(name, null);
			}

			public void ResolveNames(CompilerTypeSymbolTable tst)
			{
				Debug.Assert(entry != null);
				type.ResolveNames(tst);
				entry.Type = type;
			}

			public bool Check()
			{
				string error;
				if (!typeChecker.IsCorrect(type, out error)) {
					CompilerOutput.Error(name + " - " + error, location);
					return false;
				}

				if (name != "empty" && typeChecker.IsEmpty(type)) {
					CompilerOutput.Warning(name + " - schema declaration is empty", location);
					return false;
				}

				return true;
			}

			public void Compile(XmlWriter dec, XmlWriter code)
			{
				if (entry.Used) {
					dec.WriteStartElement("schemadec");
					if (entry.Name != entry.FreshName)
						dec.WriteAttributeString("original-name", entry.Name);
					dec.WriteAttributeString("name", entry.FreshName);
					type.Compile(dec);
					dec.WriteEndElement(); // </schemadec>
				}
			}
		}

		private ArrayList decls;
		private readonly IProcess p;

		public SchemaDec(ArrayList decls, IProcess p, int location)
			: base(location)
		{
			this.decls = decls;
			this.p = p;
		}

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			tst.Enter();
			foreach (Declaration decl in decls) {
				if (tst.Clash(decl.Name))
          CompilerOutput.Error("multiple definitions of - " + decl.Name, decl.Location);
				decl.Declare(tst);
			}

			foreach (Declaration decl in decls)
				decl.ResolveNames(tst);

			p.ResolveNames(tst, vst);
			foreach (ISymbolTableTypeEntry e in tst.Exit())
				if (!e.Used)
					CompilerOutput.Warning("unused schema - " + e.Name, Location);
		}

		public override void Check()
		{	
			ArrayList declsOK = new ArrayList();
			foreach (Declaration decl in decls)
				if (decl.Check())
					declsOK.Add(decl);
			decls = declsOK;

			p.Check();			
		}

		public override void AllocateNames(AllocateContext context)
		{ p.AllocateNames(context); }

		public override void Compile(XmlWriter dec, XmlWriter code)
		{
			foreach (Declaration decl in decls)
				decl.Compile(dec, code);

			p.Compile(dec, code);
		}		 
	}

	// BEGIN: JOIN PATTERNS
  // an input channel with associated pattern occurring in an
  // input definition
  public class JoinPatternAtom
  {
		private int location;
    private string channel;
		private ISymbolTableValueEntry entry;
		private int index;
    private IPattern pattern;

		public string Channel { get { return channel; } }
		public ISymbolTableValueEntry Entry { get { return entry; } }

    public JoinPatternAtom(string channel, IPattern pattern, int location)
    {
      this.channel = channel;
			this.entry = null;
			this.index = -1;
      this.pattern = pattern;
			this.location = location;
    }

		public void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			entry = vst.Lookup(channel, location);
			pattern.ResolveNames(tst, vst);
		}

		public void ComputeChannelIndex(ArrayList channels)
		{
			this.index = channels.IndexOf(channel);
			Debug.Assert(this.index >= 0);
		}
    
		public void Check()
		{
			IType t = pattern.SchemaOf();
      string error = "";
      if (!Process.typeChecker.IsCorrect(t, out error))
        CompilerOutput.Error("input pattern - error " + error, location);
			if (!entry.Type.IsChan()) 
				CompilerOutput.Error("variable - " + channel + " - does not have type channel", location);
			else {
				if (!entry.Fresh)
					CompilerOutput.Error("channel - " + channel + " - is not fresh, it cannot be used in a join definition", location);
        Chan c = new Chan(entry.Type.AsChan().Carried, Chan.CAPABILITY.INOUT);
				if (!Process.typeChecker.IsSubtype(c.Carried, t)) //TODO TypeChecker should be allocated in a different place
					CompilerOutput.Error("the schema of the pattern is not exhaustive for channel - " + channel  + " - " + c.Carried + "!<:" + t, location);
			}            
		}

		public void AllocateNames(AllocateContext context)
		{ pattern.AllocateNames(context); }

		public void Compile(XmlWriter code)
		{
			code.WriteStartElement("receive");
			code.WriteAttributeString("index", index.ToString());
      code.WriteAttributeString("index-name", entry.Name.ToString());
			code.WriteStartElement("pattern");
			pattern.Compile(code);
			code.WriteEndElement(); // </pattern>
			code.WriteEndElement(); // </receive>
		}
  }

  // a set of input channels associated with a continuation
  public class JoinPatternRow
  {
    private ArrayList atoms;
    private IProcess continuation;
		private int location;

		public ArrayList Atoms { get { return atoms; } }

    public JoinPatternRow(ArrayList atoms, IProcess continuation, int location)
    {
      this.atoms = atoms;
      this.continuation = continuation;
			this.location = location;
    }

		public void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			vst.Enter();
      foreach (JoinPatternAtom atom in atoms)
        atom.ResolveNames(tst, vst);
			continuation.ResolveNames(tst, vst);
			foreach (ISymbolTableValueEntry e in vst.Exit())
				if (!e.Used)
					CompilerOutput.Warning("unused variable - " + e.Name, location);
		}

		public void Check()
		{
			ArrayList channels = new ArrayList();
			foreach (JoinPatternAtom atom in atoms) {
				if (channels.Contains(atom.Channel))
					CompilerOutput.Error("non-linear join pattern detected: " + atom.Channel + " channel is used multiple times", location);
				channels.Add(atom.Channel);
				atom.Check();
			}

			continuation.Check();
		}

		public void AllocateNames(AllocateContext context)
		{
			foreach (JoinPatternAtom atom in atoms)
				atom.AllocateNames(context);
			continuation.AllocateNames(context);
		}

		public void Compile(XmlWriter dec, XmlWriter code)
		{
			code.WriteStartElement("branch");
			foreach (JoinPatternAtom atom in atoms)
				atom.Compile(code);
			code.WriteStartElement("process");
			continuation.Compile(dec, code);
			code.WriteEndElement(); // </process>
			code.WriteEndElement(); // </branch>
		}
  }

	public class JoinPatternDefinitionProcess : Process
	{
		private bool service;
    private ArrayList rows;
		private ArrayList channels;
		private ArrayList entries;

		public JoinPatternDefinitionProcess(bool service, ArrayList rows, int location)
			: base(location)
		{
			this.service = service;
			this.rows = rows;

			// collect channel names
			this.channels = new ArrayList();
			foreach (JoinPatternRow row in rows)
				foreach (JoinPatternAtom atom in row.Atoms)
					if (!this.channels.Contains(atom.Channel))
						this.channels.Add(atom.Channel);

			// assign each channel its index
			foreach (JoinPatternRow row in rows)
				foreach (JoinPatternAtom atom in row.Atoms)
					atom.ComputeChannelIndex(this.channels);

			this.entries = new ArrayList();
		}

		public override void ResolveNames(CompilerTypeSymbolTable tst, CompilerValueSymbolTable vst)
		{
			foreach (string channel in channels)
				entries.Add(vst.Lookup(channel, Location));

      foreach (JoinPatternRow row in rows)
        row.ResolveNames(tst, vst);
		}

		public override void Check()
		{
			foreach (JoinPatternRow row in rows)
				row.Check();
		}

		public override void AllocateNames(AllocateContext context)
		{
			foreach (JoinPatternRow row in rows)
				row.AllocateNames(context);
		}

		public override void Compile(XmlWriter dec, XmlWriter code)
		{
			code.WriteStartElement("join-select");
			code.WriteAttributeString("service", service.ToString());

			code.WriteStartElement("channels");
			foreach (ISymbolTableValueEntry entry in entries) {
				code.WriteStartElement("channel");
				// LUCA: are these two cases still possible? Remind that join patterns can be done with local channels only!
				code.WriteAttributeString("ch", entry.Index.ToString());
        code.WriteAttributeString("ch-name", entry.Name);
				code.WriteEndElement(); // </channel>
			}
			code.WriteEndElement(); // </channels>

			foreach (JoinPatternRow row in rows)
				row.Compile(dec, code);

			CompileAutomaton().ToXML(code);
			code.WriteEndElement(); // </join-select>
		}

    private State GetStateOfRow(JoinPatternRow row)
    {
      State state = new State(entries.Count);
      foreach (JoinPatternAtom atom in row.Atoms)
				state = state.Full(GetChannelIndex(atom.Entry));
      return state;
    }

    private int GetChannelIndex(ISymbolTableEntry entry)
    { return entries.IndexOf(entry); }

    public StateSet CompileAutomaton()
    {
      int stateSize = entries.Count;
      Debug.Assert(stateSize > 0);

      ArrayList finalStates = new ArrayList();
      foreach (JoinPatternRow row in rows) {
				State finalState = GetStateOfRow(row);
				Debug.Assert(!finalStates.Contains(finalState));
				finalStates.Add(finalState);
      }

      StateSet stateSet = new StateSet(entries, rows.Count);
      Queue stateQueue = new Queue();
      stateQueue.Enqueue(new State(stateSize));
      while (stateQueue.Count > 0) {
				State state = stateSet.Find((State) stateQueue.Dequeue());
				if (!state.Initialized) {
				  state.Initialized = true;
				  state.Final = state.Contains(finalStates);
				  int[] transitions = new int[2 * stateSize];
				  for (int i = 0; i < stateSize; i++) {
				    if (state.Final > 0)
				      transitions[stateSize + i] = 0;
	    			else {
				      State newStatePositive = stateSet.Find(state.Full(i));
				      transitions[stateSize + i] = newStatePositive.Index;
	    			  stateQueue.Enqueue(newStatePositive);
				    }

	    			State newStateNegative = stateSet.Find(state.Empty(i));
				    transitions[i] = newStateNegative.Index;
		  		  stateQueue.Enqueue(newStateNegative);
				  }
			  	state.SetTransitions(transitions);
				}
      }

      return stateSet;
    }
  }

  public class State
  {
    public bool Initialized;
    public int Index;
    public int Final;
    private int[] transitions;
    private bool[] channels;

    public State(int stateSize)
    {
      Debug.Assert(stateSize > 0);
      this.channels = new bool[stateSize];
      for (int i = 0; i < stateSize; i++)
				this.channels[i] = false;
    }

    private State(bool[] channels)
    {
      this.channels = (bool[]) channels.Clone();
    }

    private State(bool[] channels, int toggle)
    {
      Debug.Assert(toggle >= 0 && toggle < channels.Length);
      this.channels = (bool[]) channels.Clone();
      this.channels[toggle] = !this.channels[toggle];
    }

    public override bool Equals(object obj)
    {
      State state = (State) obj;
      if (channels.Length != state.channels.Length)
				return false;

      for (int i = 0; i < channels.Length; i++)
				if (channels[i] != state.channels[i])
				  return false;

      return true;
    }

		public override int GetHashCode()
		{ return base.GetHashCode(); }

		public State Full(int s)
		{
			if (channels[s])
				return this;
			else
				return new State(channels, s);
		}

		public State Empty(int s)
		{
			if (!channels[s])
				return this;
			else
				return new State(channels, s);
		}

    public void SetTransitions(int[] transitions)
    {
      Debug.Assert(this.transitions == null);
      this.transitions = transitions;
    }

    public void Dump(ArrayList entries)
    {
      Console.Write("State " + Index + " final: " + Final + " [");
      for (int i = 0; i < entries.Count; i++) {
				if (this.channels[i])
				  Console.Write(" " + ((ISymbolTableValueEntry)entries[i]).Name);
      }
      Console.WriteLine(" ]");

      for (int i = 0; i < entries.Count; i++) {
				Console.WriteLine("-" + ((ISymbolTableValueEntry)entries[i]).Name + " -> " + transitions[i]);
      }

      for (int i = entries.Count; i < 2 * entries.Count; i++) {
				Console.WriteLine("+" + ((ISymbolTableValueEntry)entries[i - entries.Count]).Name + " -> " + transitions[i]);	
      }
    }

    public void ToXML(XmlWriter xml, ArrayList entries)
    {
      xml.WriteStartElement("state");

      xml.WriteAttributeString("index", Index.ToString());

			string stateName = "";
			for (int i = 0; i < entries.Count; i++)
				if (this.channels[i])
					stateName = stateName + "+" + ((ISymbolTableValueEntry)entries[i]).Name;
			if (stateName != "")
				xml.WriteAttributeString("name", stateName);

      if (Final != 0)
				xml.WriteAttributeString("continue", Final.ToString());

      for (int i = 0; i < entries.Count; i++) {
				xml.WriteStartElement("empty");
				xml.WriteAttributeString("index", i.ToString());
				xml.WriteAttributeString("next", transitions[i].ToString());
				xml.WriteEndElement();
      }
				 
      for (int i = 0; i < entries.Count; i++) {
				xml.WriteStartElement("full");
				xml.WriteAttributeString("index", i.ToString());
				xml.WriteAttributeString("next", transitions[entries.Count + i].ToString());
				xml.WriteEndElement();
      }
      xml.WriteEndElement();
    }

    public bool Contains(State state)
    {
      for (int i = 0; i < channels.Length; i++)
				if (state.channels[i] && !channels[i])
				  return false;
      return true;
    }

    public int Contains(ArrayList finalStates)
    {
      for (int i = 0; i < finalStates.Count; i++)
				if (this.Contains((State) finalStates[i]))
				  return i + 1;
      return 0;
    }
  }

  public class StateSet
  {
    private ArrayList entries;
    private ArrayList states;
    private int nContinuations;

    public StateSet(ArrayList entries, int nContinuations)
    { 
      this.entries = entries;
      this.states = new ArrayList();
      this.nContinuations = nContinuations;
    }

    public State Find(State state)
    {
      int index = states.IndexOf(state);
      if (index >= 0)
				return (State) states[index];
      else {
				Debug.Assert(!state.Initialized);
				state.Index = states.Count;
				states.Add(state);
				return state;
      }
    }

    public void Dump()
    {
      foreach (State state in states) {
				state.Dump(entries);
      }
    }

    public void ToXML(XmlWriter xml)
    {
      xml.WriteStartElement("automaton");
      xml.WriteAttributeString("channels", entries.Count.ToString());
      xml.WriteAttributeString("states", states.Count.ToString());
      xml.WriteAttributeString("continuations", nContinuations.ToString());
      foreach (State state in states)
				state.ToXML(xml, entries);
      xml.WriteEndElement();
    }

    public string ToXMLString()
    {
      StringWriter writer = new StringWriter();
      XmlWriter xml = new XmlTextWriter(writer);
      ToXML(xml);
      return writer.ToString();
    }
  }
	// END: JOIN PATTERNS
}
