// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.IO;
using System.Net;
using System.Xml;
using System.Text.RegularExpressions;
using BoPi.Common;
using System.Net.Sockets;
using System.Threading;
using System.Collections;
using System.Text;

namespace BoPi.Compiler
{
  /// <summary>
  /// Compiles BoPi programs producing the XML bytecode
  /// </summary>

	public class CompilerOptions 
	{
		private string host = "";
		private string filename;
		private bool usage = false;
		private bool remoteLog = false;
		private string logIPAddress = "";
		private int logPort = 0;
		private int logLevel = 0;
		
		public string Host
		{
			get { return host; }
			set { host = value; }
		}
		public string Filename
		{
			get { return filename; }
			set { filename = value; }
		}
		public bool Usage
		{
			get { return usage; } 
			set { usage = value; } 
		}
		public bool RemoteLog
		{
			get { return remoteLog; }
			set { remoteLog = value; }
		}
		public string LogIPAddress
		{
			get { return logIPAddress; } 
			set { logIPAddress = value; }
		}
		public int LogPort
		{
			get { return logPort; } 
			set { logPort = value; }
		}
		public int LogLevel
		{
			get { return logLevel; } 
			set { logLevel = value; }
		}
	}


  public class Compiler
  {
	  private static string usage = "Usage: compiler.exe [OPTION] FILE[@HOST]" 
		  + System.Environment.NewLine 
		  + "Compile a PiDuce source file"
		  + System.Environment.NewLine + "Options" + System.Environment.NewLine
		  + "-help, /help" + "\t print this message" 
		  + System.Environment.NewLine
		  + "HOST is in the form http://<hostname>:<port>"
		  + "<hostname> is the machine on wich PiDuceMachine is running"
		  + "<port> is the port on wich PiDuceMachine.exe is listening"
		  + System.Environment.NewLine;
	  
	  public static string Usage { get { return usage; } }
	  
		private static CompilerOptions Parse(string[] args)
		{
			CompilerOptions options = new CompilerOptions();
			      
			foreach (string par in args) //parsing arguments
			{
				if (par.StartsWith("-help") || par.StartsWith("/help"))
				{ options.Usage = true; }
				else if (par.StartsWith("-netlog:") || par.StartsWith("/netlog:"))
				{
					try
					{
						Regex separator = new Regex(";");
						if (separator.Split(par).Length != 3) {
							Console.WriteLine("Error: malformed option");
							Environment.Exit(-1);
						}
						
						int FirstParStart = par.IndexOf(":") + 1;
						int FirstParLen = par.IndexOf(";", FirstParStart + 1) - FirstParStart;
						int SecondParStart = par.IndexOf(";", FirstParStart + FirstParLen) + 1;
						int SecondParLen = par.IndexOf(";", SecondParStart) - SecondParStart;
						int ThirdParStart = par.IndexOf(";", SecondParStart + SecondParLen) + 1;
						
						options.RemoteLog = true;
						options.LogIPAddress = par.Substring(FirstParStart, FirstParLen);
						options.LogPort = Int32.Parse(par.Substring(SecondParStart, SecondParLen));
						options.LogLevel = Int32.Parse(par.Substring(ThirdParStart));
					}
					catch (Exception e)
					{
						Console.WriteLine(e);
					}
				}
				else 
				{ 
					try 
					{
						if (par.IndexOf("@") != -1) {
							options.Host = par.Substring(par.IndexOf("@") + 1);
							options.Filename = par.Substring(0, par.IndexOf("@"));
						}
						else {
							options.Filename = par;
						}	
					} 
					catch (Exception e)
					{
						Console.WriteLine("Error loading the program {0} {1}", par, e);
					}
				}
			}
			return options;
		}

    [STAThread]
    static void Main(string[] args)
    {
      if (args.Length < 1) {
	Console.WriteLine(Usage);
	return;
      }
      CompilerOptions options = Parse(args);
      if (options.Usage)
      { Console.WriteLine(Usage); Environment.Exit(0);}
      
      Compile(options);
    }
    
    public static void Compile(CompilerOptions options)
    {
      String m_input = "";
      Process ast = null;
      BoPiParser prg = new BoPiParser();		
      StreamReader file;

      CompilerOutput.FileName = options.Filename;
      try {
	      file = new StreamReader(options.Filename);
	      while (file.Peek() != -1)
		      m_input += file.ReadLine() + "\n";				
	      file.Close();
      } catch (Exception) {
	      Console.WriteLine("Error reading file {0}", options.Filename);
	      Environment.Exit(-1);
      }

      try {
	  		string dany = "dany = void + (int,any) + (string,any) +  <empty>^O + <dany>^I + (~[dany],dany)";
    		string any = "any = void + (int,any) + (string,any) + (~[any],any) + <empty>^O + <dany>^I";
    		string empty = "empty= ~[empty]";
 	  		m_input = "schemadef " + dany + " and " + any + " and " + empty + " in " + m_input;			
	  		ast=(Process) prg.parse(m_input);
				ast.ResolveNames(new CompilerTypeSymbolTable(), new CompilerValueSymbolTable());
			} catch (Exception e) {
	  		Console.WriteLine(e.Message);
	  		Environment.Exit(-1);
			}

      ast.Check();
      if (CompilerOutput.HasErrors) {
	  		CompilerOutput.PrintResult();
	  		return;
			}

      XmlTextWriter dec;
      StringWriter swrdec = null;
      StringWriter swr = new StringWriter();
      XmlTextWriter code = new XmlTextWriter(swr);
      code.Formatting = XmlUtil.IndentMode;
      if (options.Host != "") {                
	  		if (!options.Host.StartsWith("http://")) {
	      	CompilerOutput.Message("Must specify a valid location to upload code");
	      	return;
	    	}

	  		swrdec = new StringWriter();
	  		dec = new XmlTextWriter(swrdec);
	  		dec.Formatting = XmlUtil.IndentMode;
			} else {
	  		dec = new XmlTextWriter(options.Filename + ".xml", System.Text.Encoding.UTF8);            
	  		dec.Formatting = XmlUtil.IndentMode;
	  		dec.WriteStartDocument();
			}

      dec.WriteStartElement("BoPi");
      dec.WriteAttributeString("xmlns", null, null, "http://cs.unibo.it/BoPi/opcode");
      dec.WriteAttributeString("xmlns", "value", null, "http://cs.unibo.it/BoPi/value");
      dec.WriteStartElement("schemadecl");
			AllocateContext allocateContext = new AllocateContext();
			ast.AllocateNames(allocateContext);
      ast.Compile(dec, code);
      dec.WriteEndElement();
      dec.WriteStartElement("process");			
			dec.WriteAttributeString("env-size", allocateContext.Size.ToString());
      XmlUtil.CopyXml(dec, swr.ToString());
      dec.WriteEndElement();
      dec.WriteEndElement();			
      dec.Flush();
      if (options.Host != "") {
	  		WebClient wc = new  WebClient();
	  		try {
	      	CompilerOutput.Message("Sending compiled to " + options.Host);
	      	wc.Headers.Add("User-Agent: BoPi Client");
	      	wc.Headers.Add("Content-Type: text/xml; charset=utf-8");
	      	wc.Headers.Add("SOAPAction: http://cs.unibo.it/BoPi/loadcode");

		if (options.RemoteLog) {
			wc.Headers.Add(String.Concat("X-BoPiLog: REMOTE ", ";", options.LogIPAddress, ";", options.LogPort, ";", options.LogLevel));
		}
		
	      	wc.UploadData(options.Host, "POST", System.Text.Encoding.UTF8.GetBytes(XmlUtil.AddSoap(swrdec.ToString())));
	      	CompilerOutput.Message("Success sending compiled to " + options.Host);

	    	} catch (Exception e) {
			Console.WriteLine(e.Message);
	      	CompilerOutput.Message("Failed sending compiled to "+options.Host);
	    	}
	}
    }
  }
}
