// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;

namespace BoPi.Compiler
{
	public class CompilerOutput
	{
		private static System.IO.TextWriter display = Console.Out;
		private static int warnings = 0;
		private static int errors = 0;
		private static string fileName = "";


		public static void setTextWriter(System.IO.TextWriter tw)
		{
			display = tw;
		}

		public static string FileName {
			set { fileName = value; }
		}

		public static void Error(String error, int location)
		{
			errors++;
			display.WriteLine("{0}({1}): error: {2}", fileName, location, error);
			display.Flush();
		}

		public static void Warning(String error, int location)
		{
			warnings++;
			display.WriteLine("{0}({1}): warning: {2}", fileName, location, error);
			display.Flush();
		}

		public static void Message(String msg)
		{
			display.WriteLine(msg);
			display.Flush();
		}

		public static void PrintResult()
		{
			if (errors > 0) {
				display.WriteLine("Compilation ended with errors:");
				display.WriteLine("  number of errors: {0}", errors);
				display.Flush();
				errors = 0;
			} else
				display.WriteLine("Compilation was successful.");
				display.Flush();
			if (warnings > 0)
				display.WriteLine("  number of warnings: {0}", warnings);
				display.Flush();
				warnings = 0;
		}

		public static bool HasErrors { get { return errors > 0; } }
	}
}
