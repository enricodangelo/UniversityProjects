// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.IO;
using System.Net;
using System.Xml;
using System.Text.RegularExpressions;
using BoPi.Common;
using System.Net.Sockets;
using System.Threading;
using System.Collections;
using System.Text;

namespace BoPi.Compiler
{
  /// <summary>
  /// Compiles BoPi programs producing the XML bytecode
  /// </summary>

	class CompilerServiceOptions// : CompilerOptions
	{
		private int listeningPort;
		private bool usage;

		public int ListeningPort
		{
			get { return listeningPort; }
			set { listeningPort = value; }
		}
		new public bool Usage
		{
			get { return usage; } 
			set { usage = value; } 
		}

	}

	class CompilerService
	{
		private static string usage = "Usage: compiler.exe [OPTION] FILE[@HOST]" 
			+ System.Environment.NewLine 
			+ "Service for PiDuce Compiler" + System.Environment.NewLine
			+ "(used with PiDuceApplet)" + System.Environment.NewLine
			+ System.Environment.NewLine + "Options" + System.Environment.NewLine
			+ "-help, /help" + "\t print this message" 
			+ System.Environment.NewLine
			+ "-port:<port number>, /port:<port number>" + System.Environment.NewLine
			+ "<port number> is the port on wich PiDuceCompilerService will listen for incoming connections"
			+ System.Environment.NewLine;
		
		public static string Usage { get { return usage; } }
	  
		private static CompilerServiceOptions Parse(string[] args)
		{
			CompilerServiceOptions options = new CompilerServiceOptions();
			      
			foreach (string par in args) //parsing arguments
			{
				if (par.StartsWith("-port:") || par.StartsWith("/port:")) {
					options.ListeningPort = Int32.Parse(par.Substring(par.IndexOf(":") + 1));
				}
				if (par.StartsWith("-help") || par.StartsWith("/help")) {
					options.Usage = true;
				}
			}
			return options;
		}
		
		[STAThread]
			static void Main(string[] args)
			{
				if (args.Length != 1) {
					Console.WriteLine(Usage);
					return;
				}
				CompilerServiceOptions options = Parse(args);
				
				if (options.Usage) { Console.WriteLine(Usage); Environment.Exit(0); }
				
				ListenForSource(options);
			}

		private static void ListenForSource(CompilerServiceOptions options)
		{
			try
			{
				string localIPAddress = Dns.GetHostByName(Dns.GetHostName()).AddressList[0].ToString();
				TcpListener tcpListener = new TcpListener(IPAddress.Parse(localIPAddress), options.ListeningPort);
				tcpListener.Start();	//waiting on ListeningPort
				while(true)
				{
					Console.WriteLine("IDLE [" + localIPAddress + "]");
					Console.WriteLine("The compiler is waiting on " + options.ListeningPort);
					CSThread myThread = new CSThread(tcpListener.AcceptSocket());
					Thread thread = new Thread(new ThreadStart(myThread.StartReading));
					thread.Start();	//starts a new thread for every incoming connection
				}				
			}
			catch (Exception e)
			{
				Console.WriteLine(e);
			}
		}
				
		public class CSThread {
			private Socket socket;						//accepted socket
			private String filename = RandomString(8, true);		//temporary filename for source program
			private StreamReader streamReader;				//StreamReader associated whit "socket" (read source code)
			private StreamWriter streamWriter;				//StreamWriter associated with "tcpClient" (writes bytecode and errors)
			private String appletHost;					//host running PiDuceApplet
			private int appletPort;						//port of the host running PiDuceApplet
			private String machine;						//host:port running PiDuceMachine.exe
			private String logIPAddress;					//IP of the host running PiDuceMachine.exe
			private int logPort;						//listenong port of the host running PiDuceMachine.exe
			private int logLevel;						//verbosity of log
			private String compilerExe = "PiDuceCompiler.exe";		//name of PiDuceCompiler executable

			public CSThread(Socket socket) {//, CompilerServiceOptions options) {
				this.socket = socket;
			}
		
			public void StartReading() {
				try {
					if (socket.Connected) {
						streamReader = new StreamReader(new NetworkStream(socket));
						ParseHeader(streamReader);
						ReadSource(streamReader);
						streamWriter = new StreamWriter(new TcpClient(appletHost, appletPort).GetStream());
						System.Diagnostics.Process p = new System.Diagnostics.Process();
						System.Diagnostics.ProcessStartInfo psI;
						StreamReader sr;
						
						Console.WriteLine("Have received remote source code i start compiling it");

						if (Environment.OSVersion.ToString().StartsWith("Win")) {
							psI = new System.Diagnostics.ProcessStartInfo(compilerExe);
							psI.Arguments = filename + "@" + machine + " -netlog:" + logIPAddress + "\\;" + logPort + "\\;" + logLevel;
						}
						else {
							psI = new System.Diagnostics.ProcessStartInfo("mono");
							psI.Arguments = compilerExe + " " + filename + "@" + machine +
								" -netlog:" + logIPAddress + "\\;" + logPort + "\\;" + logLevel;
						}
						psI.UseShellExecute = false;
						psI.RedirectStandardOutput = true;
						psI.CreateNoWindow = true;
						p.StartInfo = psI;
						  
						p.Start();
						
						sr = p.StandardOutput;
						String output = sr.ReadToEnd();
						streamWriter.WriteLine(output);

						p.WaitForExit();
						 
						File.Delete(filename);
						streamReader.Close();
						streamWriter.Close();
						socket.Close();
					}
					else {
						Console.WriteLine("Socket not connected");
						Environment.Exit(-1);
					}
				}
				catch (ObjectDisposedException e)
				{
					Console.WriteLine("Socket closed by client.");
				}
				catch (System.IO.IOException)
				{
					Console.WriteLine("Problems writing on socket.");
				}
				catch (Exception e)
				{
					Console.WriteLine(e);
				}
			}

			private void ParseHeader(StreamReader streamReader)
			{
				Regex separator = new Regex(";");
				String line;
			
				if ((line = streamReader.ReadLine()) != null) {	//POST ... HTTP/1.1\r\n
					if (line.EndsWith("HTTP/1.1") || line.EndsWith("http/1.1")) {
						line = streamReader.ReadLine();	//X-PiDuceMachine-Location:
						String[] piduceMachinepar = separator.Split(line);
						machine = piduceMachinepar[1] + ":" + piduceMachinepar[2];

						line = streamReader.ReadLine();	//X-PiDuceCompilerOutPut:
						String[] compilerOutputpar = separator.Split(line);
						appletHost = compilerOutputpar[1];
						appletPort = Int32.Parse(compilerOutputpar[2]);

						line = streamReader.ReadLine();	//X-PiDuceLog: REMOTE ...;
						String[] piduceCompilerpar = separator.Split(line);
						logIPAddress = piduceCompilerpar[1];
						logPort = Int32.Parse(piduceCompilerpar[2]);
						logLevel = Int32.Parse(piduceCompilerpar[3]);

						line = streamReader.ReadLine();	//Content-Length:
					}
					else {	//if read an erroneous header exit
						Console.WriteLine("Error reading header: format unknown");
						Environment.Exit(0);
					}
				}
			}
		
			private void ReadSource(StreamReader streamReader)
			{
				StreamWriter file = new StreamWriter(this.filename);
				String line;

				while ((line = streamReader.ReadLine()) != null) {
					file.WriteLine(line);
				}
				file.Close();
				streamReader.Close();
			}

			//Used for generating a random filename
			private static string RandomString(int size, bool lowerCase)
			{
				StringBuilder builder = new StringBuilder();
				builder.Append("[file_");
				Random random = new Random();
				char ch ;
				
				for (int i = 0; i < size; i++)
				{
					do {
						ch = Convert.ToChar(Convert.ToInt32(26 * random.NextDouble() + 65)) ;
					}
					while ((ch == '[') || (ch == ']'));
					builder.Append(ch);
				}
				builder.Append("]");
				if(lowerCase)
					return builder.ToString().ToLower();
				return builder.ToString();
			}
		}
	}
}
