//autore Leonardo Mezzina
using System;
using System.Collections;
using BoPi.Types;

namespace BoPi.Loader
{
	/// <summary>
	/// class useful for the symboltable
	/// </summary>
	public class SymbolTable: Types.ITypesEnv
	{
		private struct data
		{
      public int typeofname; //0 for schema, 1 for var
			public String wsdl;
			public String location;
			public IType t;
		}
		private Hashtable table,exttable;
    
	  //TODO controllare qua
    public bool ContainsName(String name)
    {
      return table.ContainsKey(name)|| exttable.ContainsKey(name);
    }
	  public IType LookupName(String name)
		{
			data d;
			if (!table.ContainsKey(name)) return new ErrorType();
			
			d=(data)table[name];
			if (d.typeofname==0)
				return d.t;
			return new ErrorType();
		}
    public void InsertName(String name, IType t)
		{
			data d;		
			d.typeofname=0;
			d.location="";
			d.wsdl="";
			d.t=t;
			table[name]=d;
		}
	  public String GetFreshName()
		{
			int cont=0;
			String tmp="";
			lock(table)
			{
				while (table.ContainsKey(tmp))
				{
					tmp="name_"+cont.ToString();
					cont++;
				}			
			}
			return tmp;
		}
		public String GetFreshName(String name)
		{
			int cont=0;
			String tmp=name;
			lock(table)
			{
				while (table.ContainsKey(tmp))
				{
					tmp=name+"_"+cont.ToString();
					cont++;
				}			
			}
			return tmp;
		}
		private bool remove(String name)
		{			
			if (table.ContainsKey(name))
			{
				table.Remove(name);
				return true;
			}            
			return false;
		}

		public SymbolTable()
		{
      table=new Hashtable();
		}
		private SymbolTable(Hashtable h)
		{
			this.table=h;
		}


		public bool insert(String name,IType s,int typeofname,String location,String wsdl)
		{
			data d;		
			d.typeofname=typeofname;
			d.location=location;
			d.wsdl=wsdl;
			d.t=s;
			table[name]=d;
			return true;
		}

		public IType lookupvar(String name)
		{
			data d;
			if (!table.Contains(name)) return new ErrorType();
			d=(data)table[name];
			if (d.typeofname==1)
					return d.t;
			return new ErrorType();
		}

		public String lookupwsdl(String name)
		{
			data d;
			if (!table.Contains(name)) 
				throw new ApplicationException("I do know why i am here");
			d=(data)table[name];
			if (d.typeofname==1)
				return d.wsdl;
    		throw new ApplicationException("I do know why i am here");
		}

		public String lookuplocation(String name)
		{
			data d;
			if (!table.Contains(name)) 
				throw new ApplicationException("I do know why i am here");
			d=(data)table[name];
			if (d.typeofname==1)
				return d.location;
			throw new ApplicationException("I do know why i am here");

		}

		public void resetext()
		{
            exttable=new Hashtable();
		}

		public  bool inserttypeext(String name,IType t)
		{
			data d;		
			d.typeofname=0;
			d.location="";
			d.wsdl="";
			d.t=t;
			exttable[name]=d;
			return true;
		}

		public IType lookupschemaext(String name)
		{
			data d;
			if (!exttable.Contains(name)) return new ErrorType();			
			d=(data)exttable[name];
			if (d.typeofname==0)
				return d.t;
			return new ErrorType();
		}



	}
}
