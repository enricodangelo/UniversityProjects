// created by jay 0.7 (c) 1998 Axel.Schreiner@informatik.uni-osnabrueck.de
// modified by Mezzina Leonardo for BoPiCompiler

					// line 1 "loaderparser.jay"
  // -*-csharp-*-
//Author: Leo
using System;
using System.IO;
using System.Text;
using System.Collections;
using BoPi.wsdlgest;
using BoPi.Types;

namespace BoPi.Loader{


public class LoaderParser {

Lexer lexer;
SymbolTable st=new SymbolTable();
static public int yacc_verbose_flag = 2;

					// line 24

  /** error output stream.
      It should be changeable.
    */
  public System.IO.TextWriter ErrorOutput = System.Console.Out;

  /** simplified error message.
      @see <a href="#yyerror(java.lang.String, java.lang.String[])">yyerror</a>
    */
  public void yyerror (string message) {
    yyerror(message, null);
  }

  /** (syntax) error message.
      Can be overwritten to control message format.
      @param message text to be displayed.
      @param expected vector of acceptable tokens, if available.
    */
  public void yyerror (string message, string[] expected) {
    message="On Line "+lexer.location.ToString()+" "+message;
    if ((yacc_verbose_flag > 0) && (expected != null) && (expected.Length  > 0)) {
      ErrorOutput.Write (message+", expecting");
      for (int n = 0; n < expected.Length; ++ n)
        ErrorOutput.Write (" "+expected[n]);
        ErrorOutput.WriteLine ();
    } else
      ErrorOutput.WriteLine (message);
  }

  /** debugging support, requires the package jay.yydebug.
      Set to null to suppress debugging messages.
    */
  internal yydebug.yyDebug debug;

  protected static  int yyFinal = 5;
  public static  string [] yyRule = {
    "$accept : P",
    "P : SCHEMADEF ID EQ S P",
    "P : NEW ID COLON LT S GT K P",
    "P : NEW ID COLON LT S GT K LOCATION P",
    "P : NEW ID COLON LT S GT P",
    "P : NEW ID COLON LT S GT LOCATION P",
    "P : LOAD LOCATION P",
    "P : IMPORT ID IMPORTBODY P",
    "P :",
    "L : ID",
    "L : TILDE",
    "L : L SHARP L",
    "L : L BACKSLASH L",
    "L : LGRA L RGRA",
    "S : LPAR RPAR",
    "S : VOID",
    "S : LPAR S RPAR",
    "S : S PLUS S",
    "S : ID",
    "S : L LBRACK S RBRACK",
    "S : L LBRACK RBRACK",
    "S : L LBRACK S RBRACK COMMA S",
    "S : L LBRACK RBRACK COMMA S",
    "S : LT S GT K",
    "S : T COMMA S",
    "S : T",
    "K : I",
    "K : O",
    "K : IO",
    "T : INT",
    "T : STRING",
    "T : NUMBER",
    "T : MINUS NUMBER",
    "T : TEXT",
  };
  protected static  string [] yyNames = {    
    "end-of-file",null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,"'#'",null,null,null,
    null,"'('","')'",null,"'+'","','",null,null,null,null,null,null,null,
    null,null,null,null,null,null,"':'",null,"'<'","'='","'>'",null,"'@'",
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,"'['",
    "'\\\\'","']'",null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,"'{'",null,"'}'","'~'",null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,null,
    null,null,null,null,null,null,null,null,null,null,null,null,null,
    "ERROR","I","\"^I\"","O","\"^o\"","IO","\"^Io\"","LBRACK","RBRACK",
    "AT","LPAR","RPAR","LGRA","RGRA","COLON","PLUS","BACKSLASH","EQ","LT",
    "GT","COMMA","SHARP","TILDE","INT","STRING","NEW","VOID","SCHEMADEF",
    "TEXT","NUMBER","ID","LOCATION","LOAD","IMPORT","IMPORTBODY","ORPLUS",
    "AND","OR","EQEQ","NEQ","GTE","LTE","MINUS","TIMES","DIVIDE","NOT",
    "FIRST","REST","UMINUS",
  };

  /** index-checked interface to yyNames[].
      @param token single character or %token value.
      @return token name or [illegal] or [unknown].
    */
  public static string yyname (int token) {
    if ((token < 0) || (token > yyNames.Length)) return "[illegal]";
    string name;
    if ((name = yyNames[token]) != null) return name;
    return "[unknown]";
  }

  /** computes list of expected tokens on error by tracing the tables.
      @param state for which to compute the list.
      @return list of token names.
    */
  protected string[] yyExpecting (int state) {
    int token, n, len = 0;
    bool[] ok = new bool[yyNames.Length];

    if ((n = yySindex[state]) != 0)
      for (token = n < 0 ? -n : 0;
           (token < yyNames.Length) && (n+token < yyTable.Length); ++ token)
        if (yyCheck[n+token] == token && !ok[token] && yyNames[token] != null) {
          ++ len;
          ok[token] = true;
        }
    if ((n = yyRindex[state]) != 0)
      for (token = n < 0 ? -n : 0;
           (token < yyNames.Length) && (n+token < yyTable.Length); ++ token)
        if (yyCheck[n+token] == token && !ok[token] && yyNames[token] != null) {
          ++ len;
          ok[token] = true;
        }

    string [] result = new string[len];
    for (n = token = 0; n < len;  ++ token)
      if (ok[token]) result[n++] = yyNames[token];
    return result;
  }

  /** the generated parser, with debugging messages.
      Maintains a state and a value stack, currently with fixed maximum size.
      @param yyLex scanner.
      @param yydebug debug message writer implementing yyDebug, or null.
      @return result of the last reduction, if any.
      @throws yyException on irrecoverable parse error.
    */
  internal Object yyparse (yyParser.yyInput yyLex, Object yyd)
				 {
    this.debug = (yydebug.yyDebug)yyd;
    return yyparse(yyLex);
  }

  /** initial size and increment of the state/value stack [default 256].
      This is not final so that it can be overwritten outside of invocations
      of yyparse().
    */
  protected int yyMax;

  /** executed at the beginning of a reduce action.
      Used as $$ = yyDefault($1), prior to the user-specified action, if any.
      Can be overwritten to provide deep copy, etc.
      @param first value for $1, or null.
      @return first.
    */
  protected Object yyDefault (Object first) {
    return first;
  }

  /** the generated parser.
      Maintains a state and a value stack, currently with fixed maximum size.
      @param yyLex scanner.
      @return result of the last reduction, if any.
      @throws yyException on irrecoverable parse error.
    */
  internal Object yyparse (yyParser.yyInput yyLex)
				{
    if (yyMax <= 0) yyMax = 256;			// initial size
    int yyState = 0;                                   // state stack ptr
    int [] yyStates = new int[yyMax];	                // state stack 
    Object yyVal = null;                               // value stack ptr
    Object [] yyVals = new Object[yyMax];	        // value stack
    int yyToken = -1;					// current input
    int yyErrorFlag = 0;				// #tks to shift

    int yyTop = 0;
    goto skip;
    yyLoop:
    yyTop++;
    skip:
    for (;; ++ yyTop) {
      if (yyTop >= yyStates.Length) {			// dynamically increase
        int[] i = new int[yyStates.Length+yyMax];
        yyStates.CopyTo (i, 0);
        yyStates = i;
        Object[] o = new Object[yyVals.Length+yyMax];
        yyVals.CopyTo (o, 0);
        yyVals = o;
      }
      yyStates[yyTop] = yyState;
      yyVals[yyTop] = yyVal;
      if (debug != null) debug.push(yyState, yyVal);

      yyDiscarded: for (;;) {	// discarding a token does not change stack
        int yyN;
        if ((yyN = yyDefRed[yyState]) == 0) {	// else [default] reduce (yyN)
          if (yyToken < 0) {
            yyToken = yyLex.advance() ? yyLex.token() : 0;
            if (debug != null)
              debug.lex(yyState, yyToken, yyname(yyToken), yyLex.value());
          }
          if ((yyN = yySindex[yyState]) != 0 && ((yyN += yyToken) >= 0)
              && (yyN < yyTable.Length) && (yyCheck[yyN] == yyToken)) {
            if (debug != null)
              debug.shift(yyState, yyTable[yyN], yyErrorFlag-1);
            yyState = yyTable[yyN];		// shift to yyN
            yyVal = yyLex.value();
            yyToken = -1;
            if (yyErrorFlag > 0) -- yyErrorFlag;
            goto yyLoop;
          }
          if ((yyN = yyRindex[yyState]) != 0 && (yyN += yyToken) >= 0
              && yyN < yyTable.Length && yyCheck[yyN] == yyToken)
            yyN = yyTable[yyN];			// reduce (yyN)
          else
            switch (yyErrorFlag) {
  
            case 0:
              yyerror(String.Format ("syntax error, got token `{0}'", yyname (yyToken)), yyExpecting(yyState));
              if (debug != null) debug.error("syntax error");
              goto case 1;
            case 1: case 2:
              yyErrorFlag = 3;
              do {
                if ((yyN = yySindex[yyStates[yyTop]]) != 0
                    && (yyN += Token.yyErrorCode) >= 0 && yyN < yyTable.Length
                    && yyCheck[yyN] == Token.yyErrorCode) {
                  if (debug != null)
                    debug.shift(yyStates[yyTop], yyTable[yyN], 3);
                  yyState = yyTable[yyN];
                  yyVal = yyLex.value();
                  goto yyLoop;
                }
                if (debug != null) debug.pop(yyStates[yyTop]);
              } while (-- yyTop >= 0);
              if (debug != null) debug.reject();
              throw new yyParser.yyException("irrecoverable syntax error");
  
            case 3:
              if (yyToken == 0) {
                if (debug != null) debug.reject();
                throw new yyParser.yyException("irrecoverable syntax error at end-of-file");
              }
              if (debug != null)
                debug.discard(yyState, yyToken, yyname(yyToken),
  							yyLex.value());
              yyToken = -1;
              goto yyDiscarded;		// leave stack alone
            }
        }
        int yyV = yyTop + 1-yyLen[yyN];
        if (debug != null)
          debug.reduce(yyState, yyStates[yyV-1], yyN, yyRule[yyN], yyLen[yyN]);
        yyVal = yyDefault(yyV > yyTop ? null : yyVals[yyV]);
        switch (yyN) {
case 1:
					// line 79 "loaderparser.jay"
  {yyVal=new Schemadec(((stringvalue)((stringvalue)yyVals[-3+yyTop])).val,((Types.Type)yyVals[-1+yyTop]),((Lprocess)yyVals[0+yyTop]),((stringvalue)((stringvalue)yyVals[-3+yyTop])).location);}
  break;
case 2:
					// line 80 "loaderparser.jay"
  {yyVal=new Chandec(((stringvalue)((stringvalue)yyVals[-6+yyTop])).val,new XmlChan(((Types.Type)yyVals[-3+yyTop]),((int)yyVals[-1+yyTop])),((Lprocess)yyVals[0+yyTop]),"",((stringvalue)((stringvalue)yyVals[-6+yyTop])).location); }
  break;
case 3:
					// line 81 "loaderparser.jay"
  {yyVal=new Chandec(((stringvalue)((stringvalue)yyVals[-7+yyTop])).val,new XmlChan(((Types.Type)yyVals[-4+yyTop]),((int)yyVals[-2+yyTop])),((Lprocess)yyVals[0+yyTop]),((string)yyVals[-1+yyTop]),((stringvalue)((stringvalue)yyVals[-7+yyTop])).location);}
  break;
case 4:
					// line 82 "loaderparser.jay"
  {yyVal=new Chandec(((stringvalue)((stringvalue)yyVals[-5+yyTop])).val,new XmlChan(((Types.Type)yyVals[-2+yyTop]),2),((Lprocess)yyVals[0+yyTop]),"",((stringvalue)((stringvalue)yyVals[-5+yyTop])).location);}
  break;
case 5:
					// line 83 "loaderparser.jay"
  {yyVal=new Chandec(((stringvalue)((stringvalue)yyVals[-6+yyTop])).val,new XmlChan(((Types.Type)yyVals[-3+yyTop]),2),((Lprocess)yyVals[0+yyTop]),((string)yyVals[-1+yyTop]),((stringvalue)((stringvalue)yyVals[-6+yyTop])).location);}
  break;
case 6:
					// line 84 "loaderparser.jay"
  {yyVal= new Loaddec(((stringvalue)((stringvalue)yyVals[-2+yyTop])).val,((string)yyVals[-1+yyTop]),((Lprocess)yyVals[0+yyTop]),((stringvalue)((stringvalue)yyVals[-2+yyTop])).location); }
  break;
case 7:
					// line 85 "loaderparser.jay"
  {yyVal=new Importdec(((stringvalue)((stringvalue)yyVals[-2+yyTop])).val,((Lprocess)yyVals[0+yyTop]),((string)yyVals[-1+yyTop]),((stringvalue)((stringvalue)yyVals[-2+yyTop])).location);}
  break;
case 8:
					// line 86 "loaderparser.jay"
  {yyVal=new Enddec();}
  break;
case 9:
					// line 88 "loaderparser.jay"
  {yyVal=new UnionLabel(((stringvalue)yyVals[0+yyTop]).val,((stringvalue)yyVals[0+yyTop]).location);}
  break;
case 10:
					// line 89 "loaderparser.jay"
  {yyVal=new AnyLabel(((int)yyVals[0+yyTop]));}
  break;
case 11:
					// line 90 "loaderparser.jay"
  {yyVal=LabelsSet.normalizeunion(((LabelsSet)yyVals[-2+yyTop]),((LabelsSet)yyVals[0+yyTop]));}
  break;
case 12:
					// line 91 "loaderparser.jay"
  {yyVal=LabelsSet.normalizedifference(((LabelsSet)yyVals[-2+yyTop]),((LabelsSet)yyVals[0+yyTop]));}
  break;
case 13:
					// line 92 "loaderparser.jay"
  {yyVal=((LabelsSet)yyVals[-1+yyTop]);}
  break;
case 14:
					// line 94 "loaderparser.jay"
  {yyVal= new XmlVoid();}
  break;
case 15:
					// line 95 "loaderparser.jay"
  {yyVal= new XmlVoid();}
  break;
case 16:
					// line 96 "loaderparser.jay"
  {yyVal= ((Types.Type)yyVals[-1+yyTop]);}
  break;
case 17:
					// line 97 "loaderparser.jay"
  {yyVal= new XmlUnion (((Types.Type)yyVals[-2+yyTop]),((Types.Type)yyVals[0+yyTop]));}
  break;
case 18:
					// line 98 "loaderparser.jay"
  {yyVal= new XmlConstantTypeName(((stringvalue)yyVals[0+yyTop]).val);}
  break;
case 19:
					// line 99 "loaderparser.jay"
  {if ((((LabelsSet)yyVals[-3+yyTop]) is UnionLabel) && ((UnionLabel)((LabelsSet)yyVals[-3+yyTop])).labels.Count==0)
					{
						LoaderOutput.print("emptyset of label",((int)yyVals[-2+yyTop]));
						yyVal=((Types.Type)yyVals[-1+yyTop]);
					}
					if ((((LabelsSet)yyVals[-3+yyTop]) is DifferenceLabel) && ((DifferenceLabel)((LabelsSet)yyVals[-3+yyTop])).diffLabels.labels.Count==0)
					    yyVal= new XmlLabelled(new AnyLabel(((LabelsSet)yyVals[-3+yyTop]).location),((Types.Type)yyVals[-1+yyTop]));
					else
					    yyVal= new XmlLabelled(((LabelsSet)yyVals[-3+yyTop]),((Types.Type)yyVals[-1+yyTop]));}
  break;
case 20:
					// line 108 "loaderparser.jay"
  {if ((((LabelsSet)yyVals[-2+yyTop]) is UnionLabel) && ((UnionLabel)((LabelsSet)yyVals[-2+yyTop])).labels.Count==0)
					{
						LoaderOutput.print("emptyset of label",((int)yyVals[-1+yyTop]));
						yyVal=new XmlVoid();
					}
					if ((((LabelsSet)yyVals[-2+yyTop]) is DifferenceLabel) && ((DifferenceLabel)((LabelsSet)yyVals[-2+yyTop])).diffLabels.labels.Count==0)
					    yyVal= new XmlLabelled(new AnyLabel(((LabelsSet)yyVals[-2+yyTop]).location),new XmlVoid());
					else
					    yyVal= new XmlLabelled(((LabelsSet)yyVals[-2+yyTop]),new XmlVoid());}
  break;
case 21:
					// line 118 "loaderparser.jay"
  {if ((((LabelsSet)yyVals[-5+yyTop]) is UnionLabel) && ((UnionLabel)((LabelsSet)yyVals[-5+yyTop])).labels.Count==0)
					{
						LoaderOutput.print("emptyset of label",((int)yyVals[-4+yyTop]));
						yyVal=new XmlSequence(((Types.Type)yyVals[-3+yyTop]),((Types.Type)yyVals[0+yyTop]));
					}
					if ((((LabelsSet)yyVals[-5+yyTop]) is DifferenceLabel) && ((DifferenceLabel)((LabelsSet)yyVals[-5+yyTop])).diffLabels.labels.Count==0)
					    yyVal= new XmlSequence(new Labelled(new AnyLabel(((LabelsSet)yyVals[-5+yyTop]).location),((Types.Type)yyVals[-3+yyTop])),((Types.Type)yyVals[0+yyTop]));
					else
					    yyVal= new XmlSequence(new XmlLabelled(((LabelsSet)yyVals[-5+yyTop]),((Types.Type)yyVals[-3+yyTop])),((Types.Type)yyVals[0+yyTop]));}
  break;
case 22:
					// line 127 "loaderparser.jay"
  {if ((((LabelsSet)yyVals[-4+yyTop]) is UnionLabel) && ((UnionLabel)((LabelsSet)yyVals[-4+yyTop])).labels.Count==0)
					{
						LoaderOutput.print("emptyset of label",((int)yyVals[-3+yyTop]));
						yyVal=new XmlSequence(new XmlVoid(),((Types.Type)yyVals[0+yyTop]));
					}
					if ((((LabelsSet)yyVals[-4+yyTop]) is DifferenceLabel) && ((DifferenceLabel)((LabelsSet)yyVals[-4+yyTop])).diffLabels.labels.Count==0)
					    yyVal= new XmlSequence(new Labelled(new AnyLabel(),new XmlVoid()),((Types.Type)yyVals[0+yyTop]));
					else
					    yyVal= new XmlSequence(new Labelled(((LabelsSet)yyVals[-4+yyTop]),new XmlVoid()),((Types.Type)yyVals[0+yyTop]));}
  break;
case 23:
					// line 136 "loaderparser.jay"
  {yyVal= new XmlChan(((Types.Type)yyVals[-2+yyTop]),((int)yyVals[0+yyTop]));}
  break;
case 24:
					// line 137 "loaderparser.jay"
  {yyVal= new XmlSequence(((Types.Type)yyVals[-2+yyTop]),((Types.Type)yyVals[0+yyTop]));}
  break;
case 25:
					// line 138 "loaderparser.jay"
  {yyVal= ((Types.Type)yyVals[0+yyTop]);}
  break;
case 26:
					// line 140 "loaderparser.jay"
  {yyVal=-1;}
  break;
case 27:
					// line 141 "loaderparser.jay"
  {yyVal=1;}
  break;
case 28:
					// line 142 "loaderparser.jay"
  {yyVal=2;}
  break;
case 29:
					// line 144 "loaderparser.jay"
  {yyVal= new XmlIntType();}
  break;
case 30:
					// line 145 "loaderparser.jay"
  {yyVal= new XmlStringType();}
  break;
case 31:
					// line 146 "loaderparser.jay"
  {yyVal= new XmlIntLiteral(((intvalue)yyVals[0+yyTop]).val);}
  break;
case 32:
					// line 147 "loaderparser.jay"
  {yyVal= new XmlIntLiteral(-((intvalue)yyVals[0+yyTop]).val);}
  break;
case 33:
					// line 148 "loaderparser.jay"
  {yyVal= new XmlStringLiteral(((stringvalue)yyVals[0+yyTop]).val);}
  break;
					// line 453
        }
        yyTop -= yyLen[yyN];
        yyState = yyStates[yyTop];
        int yyM = yyLhs[yyN];
        if (yyState == 0 && yyM == 0) {
          if (debug != null) debug.shift(0, yyFinal);
          yyState = yyFinal;
          if (yyToken < 0) {
            yyToken = yyLex.advance() ? yyLex.token() : 0;
            if (debug != null)
               debug.lex(yyState, yyToken,yyname(yyToken), yyLex.value());
          }
          if (yyToken == 0) {
            if (debug != null) debug.accept(yyVal);
            return yyVal;
          }
          goto yyLoop;
        }
        if (((yyN = yyGindex[yyM]) != 0) && ((yyN += yyState) >= 0)
            && (yyN < yyTable.Length) && (yyCheck[yyN] == yyState))
          yyState = yyTable[yyN];
        else
          yyState = yyDgoto[yyM];
        if (debug != null) debug.shift(yyStates[yyTop], yyState);
	 goto yyLoop;
      }
    }
  }

   static  short [] yyLhs  = {              -1,
    0,    0,    0,    0,    0,    0,    0,    0,    3,    3,
    3,    3,    3,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    4,    4,    4,    2,    2,
    2,    2,    2,
  };
   static  short [] yyLen = {           2,
    5,    8,    9,    7,    8,    3,    4,    0,    1,    1,
    3,    3,    3,    2,    1,    3,    3,    1,    4,    3,
    6,    5,    4,    3,    1,    1,    1,    1,    1,    1,
    1,    2,    1,
  };
   static  short [] yyDefRed = {            0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    6,    0,    0,    0,    0,    0,   10,   29,   30,
   15,   33,   31,    0,    0,    0,    0,    0,    7,    0,
   14,    0,    9,    0,    0,   32,    0,    1,    0,    0,
    0,    0,    0,   16,   13,    0,    0,    0,    0,    0,
   12,   11,   26,   27,   28,    0,    4,    0,   23,    0,
    0,    5,    0,    2,    0,    0,    3,    0,
  };
  protected static  short [] yyDgoto  = {             5,
   26,   27,   28,   58,
  };
  protected static  short [] yySindex = {         -160,
 -278, -276, -263, -252,    0, -225, -210, -160, -218, -201,
 -166,    0, -160, -166, -188, -264, -166,    0,    0,    0,
    0,    0,    0,    0, -221, -253, -200, -251,    0, -231,
    0, -213,    0, -226, -205,    0, -166,    0, -166, -197,
 -264, -264, -256,    0,    0, -246, -196, -196, -192, -265,
    0,    0,    0,    0,    0, -160,    0, -228,    0, -166,
 -183,    0, -160,    0, -196, -166,    0, -196,
  };
  protected static  short [] yyRindex = {           96,
    0,    0,    0,    0,    0,    0,    0,   96,    0,    0,
    0,    0,   96,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    1,    0,   96,   10,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,   96,    0,    0,    0,   48,   57,   30,    0,
    0,    0,    0,    0,    0,   96,    0,   96,    0,    0,
   39,    0,   96,    0,   66,    0,    0,   75,
  };
  protected static  short [] yyGindex = {           -5,
    3,    0,    8,   54,
  };
  protected static  short [] yyTable = {            61,
   18,   53,   12,   54,   16,   55,   37,   29,    6,   25,
    7,   53,   40,   54,   18,   55,   30,   32,   37,   35,
   38,   41,   33,   34,    8,    1,   42,    2,    1,   20,
    2,   56,    3,    4,    9,    3,    4,   57,   19,   47,
   37,   48,   50,   45,   43,   10,   41,   17,   51,   52,
   62,   42,   64,    1,   44,    2,   24,   67,   37,   63,
    3,    4,   65,   11,   36,   22,   37,   49,   68,   15,
   46,   16,   13,   14,   21,   37,   39,   17,   15,   31,
   16,   18,   19,   20,   60,   21,   17,   22,   23,   24,
   18,   19,   20,   66,   21,    8,   22,   23,   24,   59,
   15,   25,   16,    0,    0,    0,    0,    0,   17,    0,
   25,    0,   18,   19,   20,    0,   21,    0,   22,   23,
   24,    1,    0,    2,    0,    0,    0,    0,    3,    4,
    0,    0,   25,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    9,   18,    0,    0,   18,    0,
    0,    0,   18,    9,   25,    0,   18,   25,    9,    0,
    0,   25,   18,    0,   18,   25,    0,    0,    0,   18,
   18,   25,    0,   25,   20,    0,    0,   20,   25,   25,
    0,   20,    0,   19,    0,   20,   19,    0,    0,    0,
   19,   20,   17,   20,   19,   17,    0,    0,   20,   20,
   19,   24,   19,   17,   24,    0,    0,   19,   19,   17,
   22,   17,   24,   22,    0,    0,   17,   17,   24,   21,
   24,   22,   21,    0,    0,   24,   24,   22,    0,   22,
   21,    0,    0,    0,   22,   22,   21,    0,   21,    0,
    0,    0,    0,   21,   21,
  };
  protected static  short [] yyCheck = {           265,
    0,  258,    8,  260,  269,  262,  272,   13,  287,    0,
  287,  258,  264,  260,  279,  262,   14,   15,  272,   17,
   26,  273,  287,   16,  288,  282,  278,  284,  282,    0,
  284,  288,  289,  290,  287,  289,  290,   43,    0,   37,
  272,   39,   40,  270,  276,  271,  273,    0,   41,   42,
   56,  278,   58,  282,  268,  284,    0,   63,  272,  288,
  289,  290,   60,  274,  286,    0,  272,  265,   66,  267,
  276,  269,  291,  275,    0,  272,  277,  275,  267,  268,
  269,  279,  280,  281,  277,  283,  275,  285,  286,  287,
  279,  280,  281,  277,  283,    0,  285,  286,  287,   46,
  267,  299,  269,   -1,   -1,   -1,   -1,   -1,  275,   -1,
  299,   -1,  279,  280,  281,   -1,  283,   -1,  285,  286,
  287,  282,   -1,  284,   -1,   -1,   -1,   -1,  289,  290,
   -1,   -1,  299,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  264,  265,   -1,   -1,  268,   -1,
   -1,   -1,  272,  273,  265,   -1,  276,  268,  278,   -1,
   -1,  272,  282,   -1,  284,  276,   -1,   -1,   -1,  289,
  290,  282,   -1,  284,  265,   -1,   -1,  268,  289,  290,
   -1,  272,   -1,  265,   -1,  276,  268,   -1,   -1,   -1,
  272,  282,  265,  284,  276,  268,   -1,   -1,  289,  290,
  282,  265,  284,  276,  268,   -1,   -1,  289,  290,  282,
  265,  284,  276,  268,   -1,   -1,  289,  290,  282,  265,
  284,  276,  268,   -1,   -1,  289,  290,  282,   -1,  284,
  276,   -1,   -1,   -1,  289,  290,  282,   -1,  284,   -1,
   -1,   -1,   -1,  289,  290,
  };

					// line 154 "loaderparser.jay"
    public Object parse (string file)
    {
	lexer = new Lexer(file);
	return yyparse (lexer);
    }


}
					// line 616
namespace yydebug {
        using System;
	 internal interface yyDebug {
		 void push (int state, Object value);
		 void lex (int state, int token, string name, Object value);
		 void shift (int from, int to, int errorFlag);
		 void pop (int state);
		 void discard (int state, int token, string name, Object value);
		 void reduce (int from, int to, int rule, string text, int len);
		 void shift (int from, int to);
		 void accept (Object value);
		 void error (string message);
		 void reject ();
	 }
	 
	 class yyDebugSimple : yyDebug {
		 void println (string s){
			 Console.Error.WriteLine (s);
		 }
		 
		 public void push (int state, Object value) {
			 println ("push\tstate "+state+"\tvalue "+value);
		 }
		 
		 public void lex (int state, int token, string name, Object value) {
			 println("lex\tstate "+state+"\treading "+name+"\tvalue "+value);
		 }
		 
		 public void shift (int from, int to, int errorFlag) {
			 switch (errorFlag) {
			 default:				// normally
				 println("shift\tfrom state "+from+" to "+to);
				 break;
			 case 0: case 1: case 2:		// in error recovery
				 println("shift\tfrom state "+from+" to "+to
					     +"\t"+errorFlag+" left to recover");
				 break;
			 case 3:				// normally
				 println("shift\tfrom state "+from+" to "+to+"\ton error");
				 break;
			 }
		 }
		 
		 public void pop (int state) {
			 println("pop\tstate "+state+"\ton error");
		 }
		 
		 public void discard (int state, int token, string name, Object value) {
			 println("discard\tstate "+state+"\ttoken "+name+"\tvalue "+value);
		 }
		 
		 public void reduce (int from, int to, int rule, string text, int len) {
			 println("reduce\tstate "+from+"\tuncover "+to
				     +"\trule ("+rule+") "+text);
		 }
		 
		 public void shift (int from, int to) {
			 println("goto\tfrom state "+from+" to "+to);
		 }
		 
		 public void accept (Object value) {
			 println("accept\tvalue "+value);
		 }
		 
		 public void error (string message) {
			 println("error\t"+message);
		 }
		 
		 public void reject () {
			 println("reject");
		 }
		 
	 }
}
// %token constants
 class Token {
  public const int ERROR = 257;
  public const int I = 258;
  public const int O = 260;
  public const int IO = 262;
  public const int LBRACK = 264;
  public const int RBRACK = 265;
  public const int AT = 266;
  public const int LPAR = 267;
  public const int RPAR = 268;
  public const int LGRA = 269;
  public const int RGRA = 270;
  public const int COLON = 271;
  public const int PLUS = 272;
  public const int BACKSLASH = 273;
  public const int EQ = 274;
  public const int LT = 275;
  public const int GT = 276;
  public const int COMMA = 277;
  public const int SHARP = 278;
  public const int TILDE = 279;
  public const int INT = 280;
  public const int STRING = 281;
  public const int NEW = 282;
  public const int VOID = 283;
  public const int SCHEMADEF = 284;
  public const int TEXT = 285;
  public const int NUMBER = 286;
  public const int ID = 287;
  public const int LOCATION = 288;
  public const int LOAD = 289;
  public const int IMPORT = 290;
  public const int IMPORTBODY = 291;
  public const int ORPLUS = 292;
  public const int AND = 293;
  public const int OR = 294;
  public const int EQEQ = 295;
  public const int NEQ = 296;
  public const int GTE = 297;
  public const int LTE = 298;
  public const int MINUS = 299;
  public const int TIMES = 300;
  public const int DIVIDE = 301;
  public const int NOT = 302;
  public const int FIRST = 303;
  public const int REST = 304;
  public const int UMINUS = 305;
  public const int yyErrorCode = 256;
 }
 namespace yyParser {
  using System;
  /** thrown for irrecoverable syntax errors and stack overflow.
    */
  internal class yyException : System.Exception {
    public yyException (string message) : base (message) {
    }
  }

  /** must be implemented by a scanner object to supply input to the parser.
    */
  internal interface yyInput {
    /** move on to next token.
        @return false if positioned beyond tokens.
        @throws IOException on input error.
      */
    bool advance (); // throws java.io.IOException;
    /** classifies current token.
        Should not be called if advance() returned false.
        @return current %token or single character.
      */
    int token ();
    /** associated with current token.
        Should not be called if advance() returned false.
        @return value for token().
      */
    Object value ();
  }
 }
} // close outermost namespace, that MUST HAVE BEEN opened in the prolog
