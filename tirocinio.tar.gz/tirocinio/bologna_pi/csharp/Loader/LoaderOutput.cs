using System;

namespace BoPi.Loader
{
	public class LoaderOutput
	{
		private static System.IO.TextWriter display=Console.Out;
		public static void print(String msg,int location)
		{
			display.WriteLine("At line {0}: "+msg,location);
		}
		public static void print(String msg)
		{
			display.WriteLine(msg);
		}

	}
}
