using System;
using System.IO;


namespace BoPi.Loader
{
	/// <summary>
	/// Descrizione di riepilogo per Class1.
	/// </summary>
	class main
	{
		/// <summary>
		/// Il punto di ingresso principale dell'applicazione.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			String m_input="";
			LoaderParser prg=new LoaderParser();		
			Lprocess ast;
			String filename;
			//			used for debugging purpose
			 			//args=new string[1];
						//args[0]=@"C:\Documents and Settings\leo\Desktop\load.txt";
			
			if (args.Length<1) 
			{
				Console.WriteLine("Usage: BoPiLoader <filename>");
				return;
			}		
			filename=args[0];

			try
			{
				using (StreamReader file = new StreamReader(filename)) 
				{
					while (file.Peek() != -1)
					{
						m_input += file.ReadLine() +"\n";				
					}
					file.Close();					
				}
			}
			catch (Exception)
			{
				Console.WriteLine("File {0} cannot be read",filename);
				return;
			}
			try
			{
				ast=(Lprocess)prg.parse(m_input);
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);				
				return;
			}					
			ast.execute(new SymbolTable());
            Console.ReadLine();
		}
	}
}
