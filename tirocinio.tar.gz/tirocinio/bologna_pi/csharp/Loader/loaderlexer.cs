//autore Leonardo Mezzina


using System;
using System.Text.RegularExpressions;
using System.Collections;

namespace BoPi.Loader {
	public class genericvalue
	{
		public int location;
	}
	public class intvalue:genericvalue
	{
		public int val;
		public intvalue(int val,int location)
		{
			this.val=val;
			this.location=location;
		}
	}

	public class stringvalue:genericvalue
	{
		public String val;
		public stringvalue(String val,int location)
		{
			this.val=val;
			this.location=location;
		}
	}

    
	public interface IToken
	{		
		/* integer returned by Token's jay class
		 * that correspond at this keyword*/
		int gettoken();
		/* return true if <code>str</code>
		 * match with this token */
		bool match(String str,ref int length);
	}
	public class simpletoken:IToken	
	{	
		private int token;
		private String val;
		public simpletoken(string val,int token)
		{
			this.val=val;
			this.token=token;
		}
		public int gettoken()
		{
			return token;
		}
		public bool match(String str,ref int length)
		{
			length=val.Length;
			return (str.StartsWith(val));
		}
	}
	public class regextoken:IToken	
	{	
		private int token;
		private Regex val;
		public regextoken(string pattern,int token)
		{
			this.val= new Regex("^("+pattern+"){1}");
			this.token=token;
		}
		public int gettoken()
		{
			return token;
		}
		public bool match(String str,ref int length)
		{
			Match m=val.Match(str);
			length=m.Length;
			return m.Success;
		}
	}

	
	class Lexer : yyParser.yyInput
	{
		public Object Value;
		private ArrayList tokens;
		private Regex text;
		private Regex annotation;
		private Regex number;
		private Regex identifier;        
		private string m_input="";
		//line number
		public int location;



		public Lexer(string m_input) {	
			location=1;
			text=new Regex("\"([^\"]*|(\\\")*)*\"");
			number= new Regex("[1-9][0-9]*");
			identifier= new Regex("[A-Za-z][A-Za-z0-9_]");
			annotation= new Regex("^(//.*\n)");
			tokens= new ArrayList();			
			tokens.Add(new simpletoken("{",Token.LGRA));
			tokens.Add(new simpletoken("}",Token.RGRA));
			tokens.Add(new simpletoken("=",Token.EQ));
			tokens.Add(new simpletoken("^IO",Token.IO));
			tokens.Add(new simpletoken("^I",Token.I));
			tokens.Add(new simpletoken("^O",Token.O));
			tokens.Add(new simpletoken("(",Token.LPAR));
			tokens.Add(new simpletoken(")",Token.RPAR));
			tokens.Add(new simpletoken("[",Token.LBRACK));
			tokens.Add(new simpletoken("]",Token.RBRACK));
			tokens.Add(new simpletoken("#",Token.SHARP));
			tokens.Add(new simpletoken(":",Token.COLON));
			tokens.Add(new simpletoken("+",Token.PLUS));
			tokens.Add(new simpletoken("\\",Token.BACKSLASH));
			tokens.Add(new simpletoken("=",Token.EQ));
			tokens.Add(new simpletoken(">",Token.GT));
			tokens.Add(new simpletoken("<",Token.LT));
			tokens.Add(new simpletoken(",",Token.COMMA));
			tokens.Add(new simpletoken("~",Token.TILDE));
			tokens.Add(new regextoken("\\bwsdl=\"[^\"]*\"",Token.IMPORTBODY));
			tokens.Add(new regextoken("\\bload\\s*file=\\s*\"[^\"]*\"\\s*",Token.LOAD));
			tokens.Add(new regextoken("\\blocation\\s*=\\s*\"[^\"]*\"\\s*",Token.LOCATION));
			tokens.Add(new regextoken("\\bint\\b",Token.INT));
			tokens.Add(new regextoken("\\bstring\\b",Token.STRING));
			tokens.Add(new regextoken("\\bnew\\b",Token.NEW));
			tokens.Add(new regextoken("\\bvoid\\b",Token.VOID));
			tokens.Add(new regextoken("\\bimport\\b",Token.IMPORT));
			tokens.Add(new regextoken("\\bschemadef\\b",Token.SCHEMADEF));
			tokens.Add(new regextoken("\"([^\"]*|(\\\")*)*\"",Token.TEXT));
			tokens.Add(new regextoken("[1-9][0-9]*|0",Token.NUMBER));			
			tokens.Add(new regextoken("[A-Za-z][A-Za-z0-9_]*",Token.ID));
			tokens.Add(new regextoken("\\@[A-Za-z][A-Za-z0-9_]*",Token.ID));
			this.m_input=m_input;
		}
		
		public Object value() {
			return Value;
		}

		public bool advance()
		{
			while ((m_input.Length!=0) && ((m_input[0]=='\n') || (m_input[0]=='\t') || (m_input[0]==' ')))
			{
				if (m_input[0]=='\n') location++;
				m_input=m_input.Remove(0,1);
			}
			Match m=annotation.Match(m_input);
			if (m.Success)
			{
				m_input=m_input.Remove(0,m.Length);
                location ++;				
				advance();
			}
			return (m_input.Length!=0);
		}

		public int token()
		{
			IToken tmp;
			int length=0;
			for (int i=0;i<tokens.Count;i++)
			{
				tmp=(IToken)tokens[i];
				if (tmp.match(m_input,ref length))
				{
					switch (tmp.gettoken())
					{
						case Token.TEXT:
						{
							Value=new stringvalue(m_input.Substring(1,length-2).Replace("\\\"","\""),location);
							break;
						}
						case Token.NUMBER:
						{
							Value=new intvalue(Int32.Parse(m_input.Substring(0,length)),location);
							break;
						}
						case Token.ID:
						{
							if (!m_input.StartsWith("@"))
                                Value=new stringvalue(m_input.Substring(0,length),location);
							else
								Value=new stringvalue(m_input.Substring(1,length-1),location);
							break;
						}
						case Token.IMPORTBODY:
						{
							MatchCollection m=Regex.Matches(m_input,"\"[^\"]*\"");
							Value=m_input.Substring(m[0].Index+1,m[0].Length-2);							
							break;
						}
						case Token.LOCATION:
						{
							Match m=Regex.Match(m_input,"\"[^\"]*\"");
							Value=m_input.Substring(m.Index+1,m.Length-2);
							break;
						}
						case Token.LOAD:
						{
							Match m=Regex.Match(m_input,"\"[^\"]*\"");
							Value=new stringvalue(m_input.Substring(m.Index+1,m.Length-2),location);
							break;
						}

						default:
						{
							Value=location;
							break;
						}
						
					}
					m_input=m_input.Remove(0,length);
					return tmp.gettoken();
				}				
			}
			return Token.ERROR;
		}

	
		
		
	}
}
