//autore Leonardo Mezzina
using System;
using System.Xml;
using System.Collections;
using BoPi.Web;
using BoPi.Common;
using BoPi.Types;
using BoPi.Machine;
using BoPi.wsdlgest;
using System.Net;
namespace BoPi.Loader
{
	public abstract class Lprocess 
	{		
		public int location;
		public abstract bool execute(SymbolTable st);
    protected ITypeChecker typeChecker = new TypeChecker();
	}

	public class Enddec:Lprocess
	{
		public override bool execute(SymbolTable st)
		{
			return true;
		}
	}


	public class Importdec:Lprocess
	{
		private readonly string name;
		private  IType type;
		private readonly Lprocess p;
		private readonly String wsdl;
		public Importdec(String name,Lprocess p,String wsdl,int location)
		{
			this.name=name;
			this.type=type;
			this.p=p;
			this.wsdl=wsdl;
			this.location=location;			
		}
		public override bool execute(SymbolTable st)
		{
			String  chanlocation,soapaction,namespaceuri;
			try
			{
				BoPi.wsdlgest.Wsdl2BoPi converter= new Wsdl2BoPi(Web.Webclient.download(wsdl));
				type= converter.getBoPifromWsdl(st,out chanlocation,out soapaction,out namespaceuri);
        st.insert(name,type,1,chanlocation,wsdl);
        String error = "";
				if (typeChecker.IsCorrect(type, st, ref error) && typeChecker.IsDetermined(type,st))
					return p.execute(st);
				LoaderOutput.print("Error in schema definition of "+name,location);
				return false;
			}
			catch (Exception){
        return false;
      }
		}
	}

	public class Chandec:Lprocess
	{
		private readonly string name;
		private readonly IType type;
		private readonly Lprocess p;
		private String chanlocation;
		public Chandec(String name,IType type,Lprocess p,String chanlocation,int location)
		{
			this.name=name;
			this.type=type;
			this.p=p;
			this.location=location;
			if (chanlocation=="") 
				chanlocation=Webutil.getlocalmachine();
			else
        this.chanlocation=chanlocation;
		}


		public override bool execute(SymbolTable st)
		{			
      st.insert(name,type,1,"","");
      String error = "";
			if (!typeChecker.IsCorrect(type, st, ref error) || !typeChecker.IsDetermined(type, st))
			{
				LoaderOutput.print("Error in schema definition of "+name,location);
				return false;
			}
			try
			{
				Bopi2Wsdl encoder= new Bopi2Wsdl();
				String tosend=encoder.getwsdlfrombopi(type,st,"bopichanaction/","LLLLLLL");
    			tosend=tosend.Substring(tosend.IndexOf("\n"));
				XmlNode res=new Web.Webclient().upload(chanlocation,xmlutil.addSoap(tosend),"http://cs.unibo.it/BoPi/addchannel");
				if ((res.Attributes["location"]==null) || (res.Attributes["location"].Value==""))
				    return false;
				chanlocation=res.Attributes["location"].Value;
				st.insert(name,type,1,chanlocation,chanlocation+"?wsdl");
				return p.execute(st);
			}
			catch (Exception){
        return false;
      }
		}
	}

	public class Schemadec:Lprocess
	{
		public Lprocess p;
		private readonly String name;
		private readonly IType  type;
		public Schemadec(String name,IType type,Lprocess p,int location)
		{
			this.name=name;
			this.type=type;
      this.location=location;
			this.p=p;
		}	 
		public override bool execute(SymbolTable st)
		{
      st.InsertName(name,type);
			return p.execute(st);
		}


	}


	public class Loaddec:Lprocess
	{
		public Lprocess p;
		private readonly String filename,destination;
		public Loaddec(String filename,String destination,Lprocess p,int location)
		{
			this.filename=filename;
			this.destination=destination;
			this.location=location;
			this.p=p;
		}	 
		private IType schemaparse(XmlNode schema)
		{
			if (schema.NamespaceURI!="http://cs.unibo.it/BoPi/opcode")
				throw new ApplicationException("Invalid schema in source");
			switch (schema.LocalName)
			{
				case "schema":				
					return schemaparse(schema.FirstChild);				
				case "schemaref": 
					return new XmlConstantTypeName(schema.Attributes["name",""].Value);
				case "void":
					return new XmlVoid();					
				case "choice":
					return new XmlUnion(schemaparse(schema.ChildNodes[0]),schemaparse(schema.ChildNodes[1]));					
				case "sequence":
					return new XmlSequence(schemaparse(schema.ChildNodes[0]),schemaparse(schema.ChildNodes[1]));
				case "string":
					return new XmlStringType();
				case "int":
					return new XmlIntType();
				case "intLit":
					return new XmlIntLiteral(Int32.Parse(schema.InnerText));
				case "stringLit":
					return new XmlStringLiteral(schema.InnerText);					
				case "chan":
					int cap;
					if (schema.Attributes["capability",""].Value=="I")
						cap=-1;
					else if (schema.Attributes["capability",""].Value=="IO")
						cap=2;
					else
						cap=1;
					return new XmlChan(schemaparse(schema.FirstChild),cap);					
				case "labelled":
					ISet labels= new ArraySet();
					LabelsSet res;
					if (schema.FirstChild.LocalName=="unionlabel")
					{
						foreach (XmlNode label in schema.FirstChild.ChildNodes)
							labels.Add(label.Attributes["name",""].Value);
						res=new UnionLabel(labels);
					}
					else if (schema.FirstChild.LocalName=="anylabel")
						res=new AnyLabel();
					else
					{
						foreach (XmlNode label in schema.FirstChild.ChildNodes)
							labels.Add(label.Attributes["name",""].Value);
						res=new DifferenceLabel(new UnionLabel(labels));
					}
					return new XmlLabelled(res,schemaparse(schema.ChildNodes[1]));			
			}
			throw new ApplicationException("Invalid schema in source");
		}

		public override bool execute(SymbolTable st)
		{
			XmlDocument file=new XmlDocument();
			IType type;
			file.Load(filename);
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(file.NameTable);
			nsmgr.AddNamespace("opcode","http://cs.unibo.it/BoPi/opcode");
			nsmgr.AddNamespace("value","http://cs.unibo.it/BoPi/value");
			XmlNode schemadecl=file.SelectSingleNode("opcode:BoPi/opcode:schemadecl",nsmgr);
			st.resetext();
			foreach (XmlNode schema in schemadecl.ChildNodes)
			{
				type=schemaparse(schema.FirstChild);
				st.inserttypeext(schema.Attributes["name",""].Value,type);
			}
			foreach (XmlNode current in file.SelectNodes("//opcode:import[@name!='']",nsmgr))
			{
        String error = "";
				type=schemaparse(current.FirstChild);
				if (!typeChecker.IsCorrect(type, st, ref error) || !typeChecker.IsDetermined(type, st))
				{
					LoaderOutput.print("Error in schema definition in file "+ filename,location);
					return false;
				}
				if (st.lookupvar(current.Attributes["name"].Value) is  ErrorType)
				{
					LoaderOutput.print("I need a declaration for channel " +current.Attributes["name"].Value+" in file " + filename,location);
					return false;
				}
				if (!typeChecker.IsSubtype(type, st.lookupvar(current.Attributes["name"].Value),st))
				{
					LoaderOutput.print("Wrong type for channel " +current.Attributes["name"].Value+" in file " + filename,location);
					return false;
				}
				current.Attributes["location"].Value=st.lookuplocation(current.Attributes["name"].Value);
				current.Attributes["wsdl"].Value=st.lookupwsdl(current.Attributes["name"].Value);
			}
			WebClient wc= new  WebClient();
			try
			{
				LoaderOutput.print("Sending compiled to "+destination);
				wc.Headers.Add("User-Agent: BoPi Client");
				wc.Headers.Add("Content-Type: text/xml; charset=utf-8");
				wc.Headers.Add("SOAPAction: http://cs.unibo.it/BoPi/loadcode");
				wc.UploadData(destination,"POST",System.Text.Encoding.UTF8.GetBytes(xmlutil.addSoap(file.DocumentElement.OuterXml)));
				LoaderOutput.print("Success sending compiled to "+destination);
			}
			catch (Exception)
			{
				LoaderOutput.print("Failed sending compiled to "+destination);
			}
			return p.execute(st);
		}
	}
}
