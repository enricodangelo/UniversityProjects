// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Xml;
using System.IO;

namespace BoPi.Common
{
	public class XmlUtil
	{
		private static Formatting indentmode = Formatting.Indented;
		
		public static Formatting IndentMode { get { return indentmode; } }

		public static void CopyXml(XmlWriter dest,String src)
		{
			XmlTextReader reader=new XmlTextReader(src,XmlNodeType.Element,null);
			while (reader.Read())
			{
				switch (reader.NodeType) 
				{
					case XmlNodeType.Element:
						if (reader.NamespaceURI!="")
                            dest.WriteStartElement(reader.Prefix,reader.LocalName,reader.NamespaceURI);
						else
							dest.WriteStartElement(reader.LocalName);						
						if (reader.HasAttributes)
						{
							for (int i=0;i<reader.AttributeCount;i++)
							{								
								reader.MoveToAttribute(i);
								if (reader.Value!="http://cs.unibo.it/BoPi/value") 					
                                    dest.WriteAttributeString(reader.Name,reader.Value);
							}
							reader.MoveToElement();
						}
						if (reader.IsEmptyElement)
							dest.WriteEndElement();

						break;
					case XmlNodeType.Text:
						dest.WriteString(reader.Value);
						break;
					case XmlNodeType.CDATA:
						dest.WriteCData(reader.Value);
						break;
					case XmlNodeType.ProcessingInstruction:
						break;
					case XmlNodeType.Comment:
						break;
					case XmlNodeType.EntityReference:
						break;
					case XmlNodeType.EndElement:
						dest.WriteEndElement();
						break;
				}

			}
		}
    public static XmlNode RemoveSoap(String xmlrequest)
		{			
			XmlDocument xml = new XmlDocument();
			xml.LoadXml(xmlrequest);
			return xml.GetElementsByTagName("Body","http://schemas.xmlsoap.org/soap/envelope/")[0].FirstChild;
		}
		public static string AddSoap(String xmlrequest)
		{
			String res = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n<soap:Body>"+xmlrequest;
			res += "</soap:Body></soap:Envelope>";
			return res;
		}
	}
}
