// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;

namespace BoPi.Common
{
	public interface ISet : System.Collections.ICollection, System.Collections.IList
	{
		/// <summary>
		/// Adds a new element to the Collection if it is not already present.
		/// </summary>
		/// <param name="obj">The object to add to the collection.</param>
		/// <returns>Returns true if the object was added to the collection, otherwise false.</returns>
		new bool Add(System.Object obj);
		/// <summary>
		/// Adds all the elements of the specified collection to the Set.
		/// </summary>
		/// <param name="c">Collection of objects to add.</param>
		/// <returns>true</returns>
		bool AddAll(System.Collections.ICollection c);
	}
	public class ArraySet : ArrayList, ISet
	{
		public ArraySet() : base()
		{	
		}

		public ArraySet(System.Collections.ICollection c) 
		{
			this.AddAll(c);
		}

		public ArraySet(int capacity) : base(capacity)
		{
		}

		/// <summary>
		/// Adds a new element to the ArrayList if it is not already present.
		/// </summary>		
		/// <param name="obj">Element to insert to the ArrayList.</param>
		/// <returns>Returns true if the new element was inserted, false otherwise.</returns>
		new virtual public  bool Add(System.Object obj)
		{
			bool inserted;
			if ((inserted = this.Contains(obj)) == false)
			{
				base.Add(obj);
			}
			return !inserted;
		}

		/// <summary>
		/// Adds all the elements of the specified collection that are not present to the list.
		/// </summary>
		/// <param name="c">Collection where the new elements will be added</param>
		/// <returns>Returns true if at least one element was added, false otherwise.</returns>
		public bool AddAll(ICollection c)
		{
			IEnumerator e = new ArrayList(c).GetEnumerator();
			bool added = false;
			while (e.MoveNext() == true)
			{
				if (this.Add(e.Current) == true)
					added = true;
			}
			return added;
		}
		
		/// <summary>
		/// Returns a copy of the HashSet instance.
		/// </summary>		
		/// <returns>Returns a shallow copy of the current HashSet.</returns>
		public override System.Object Clone()
		{
			return base.MemberwiseClone();
		}

		public override string ToString()
		{
			String result="";
			foreach (Object o in this)
				result+=o.ToString()+",";
			if  (result=="") return result;
			return result.Substring(0,result.Length-1);
		}

	}



	/// <summary>
	/// Class that perform some useful operation over Sets
	/// </summary>
	public class SetAlgorithms 
	{
		public static bool Included(ISet A, ISet B){
			return Difference(A, B).Count == 0;
		}
		public static ISet Intersect(ISet A, ISet B) 
		{			
			ISet result=new ArraySet();			
			if ((A==null) || (B==null)) return result;
			foreach (object o in A)
				if (B.Contains(o))	result.Add(o);			
			return result;
		}
		public static ISet Union(ISet  A, ISet B) 
		{
			ISet result;
			if (A==null) return B;
			else if (B==null) return A;
			result=new ArraySet(A);
			foreach (object o in B) if (!result.Contains(o)) result.Add(o);
			return result;
		}
		public static ISet Difference(ISet A, ISet B) 
		{
			ISet result;
			if (A==null) return new ArraySet();
			else if (B==null) return A; 
			result=new ArraySet(A);			
			foreach (object o in A)
				if (B.Contains(o))	result.Remove(o);
			return result;
		}
	}
}
