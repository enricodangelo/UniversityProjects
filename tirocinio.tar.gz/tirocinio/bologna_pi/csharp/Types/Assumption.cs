// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
namespace BoPi.Types
{
  /// <summary>
  /// Subtyping assumption
  /// </summary>
  internal class Assumption 
  {
    private readonly IType s;
    private readonly IType t;
    internal Assumption(IType s, IType t) 
    {
      this.s = s;            
      this.t = t;
    }
    public override bool Equals(Object obj) 
    {
      if (obj is Assumption)
      {
        Assumption a = (Assumption) obj;
        return ((this == obj) || (s.Equals(a.s)) && (t.Equals(a.t)));
      }
      return false;
    }
    public override String ToString() 
    {
      return s + "<:" + t;
    }
    public override int GetHashCode() 
    {			
      return (s + "<:" + t).GetHashCode();
    }
  }
}
