// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using BoPi.Common;
using System.Diagnostics;

namespace BoPi.Types
{
  public class TypesOperations
  {
    public static IType Union(IType s, IType t)
    { return new Union(s, t); }

    /// <summary>
    /// Computes the Intersection between two types.
    /// </summary>
    /// <param name="s">the fist type</param>
    /// <param name="t">the second type</param>
    /// <returns>the intersect type</returns>
    public static bool EmptyIntersection(IType s, IType t)
    { 
      IType intersection = Intersect(s, t, new Hashtable());
      if (intersection.IsErrorType()) 
        return false;
      else if ((new EmptynessChecker()).IsEmpty(intersection)) 
        return true;
      else return false;
    }

    /// <summary>
    /// Computes the Intersection between two types.
    /// </summary>
    /// <param name="s">the fist type</param>
    /// <param name="t">the second type</param>
    /// <returns>the intersect type</returns>
    /// <remarks>the method is internal because it is not precise: ErrorType is used when the intersection 
    /// cannot be expressed as schema.
    /// </remarks>
    internal static IType Intersect(IType s, IType t)
    { return Intersect(s, t, new Hashtable()); }

    /// <summary>
    /// Computes the Intersection between two types.
    /// </summary>
    /// <param name="s">the fist type</param>
    /// <param name="t">the second type</param>
    /// <param name="computing">pairs of type names the algorithm is calculating</param>
    /// <returns>the intersect type</returns>
    private static IType Intersect(IType s, IType t, Hashtable inC)
    {
      SubtypingChecker sc = new SubtypingChecker();
      if (s.IsSequence()) s = s.AsSequence().Unroll();
      if (t.IsSequence()) t = t.AsSequence().Unroll();
      if (s.IsBottom() || t.IsBottom())				
        return s;
      if (s.IsErrorType() || t.IsErrorType())
        return s;
      if (s.IsUnion()) 
      { 
        IType int1 = Intersect(s.AsUnion().Fst, t, inC);
        IType int2 = Intersect(s.AsUnion().Snd, t, inC);
        if (int1.IsBottom() && int2.IsBottom()) return new Bottom();
        else if (int1.IsBottom()) return int2;
        else if (int2.IsBottom()) return int1;
        else return new Union(int1,int2);
      }
      if (t.IsUnion()) return Intersect(t, s, inC);
      if (s.IsConstantTypeName() && t.IsConstantTypeName()) 
      {
        //these names are unique because of "#". 
        string name1 = s.AsConstantTypeName() + "#" + t.AsConstantTypeName();
        string name2 = t.AsConstantTypeName() + "#" + s.AsConstantTypeName();
        if (!inC.ContainsKey(name1) && !inC.ContainsKey(name2)) //we start to compute the Intersection
        {
          IType defofs = s.AsConstantTypeName().Entry.Type;
          IType defoft = t.AsConstantTypeName().Entry.Type;
          if (defofs.IsErrorType() || defoft.IsErrorType()) return new ErrorType();
					ISymbolTableTypeEntry entry1 = new SymbolTableTypeEntry(name1, null);
					inC.Add(name1, entry1);
					ISymbolTableTypeEntry entry2 = null;
					// LUCA: if name1 == name2 then one entry is enough (the hash table would complain otherwise)
					if (name1 != name2) {
						entry2 = new SymbolTableTypeEntry(name2, null);
						inC.Add(name2, entry2);
					}
          IType int1= Intersect(defofs, defoft, inC);
					entry1.Type = int1;
					if (name1 != name2)
						entry2.Type = int1;
          return new ConstantTypeName(name1, entry1);
        }
        //we already have the Intersection
        else if (inC.ContainsKey(name1)) return new ConstantTypeName(name1, (ISymbolTableTypeEntry) inC[name1]);
        else return new ConstantTypeName(name2, (ISymbolTableTypeEntry) inC[name2]);
      }
      else if (s.IsConstantTypeName()) 
        return Intersect(s.AsConstantTypeName().Entry.Type, t, inC);
      else if (t.IsConstantTypeName()) 
        return Intersect(s, t.AsConstantTypeName().Entry.Type, inC);
      else if (s.IsBaseType() || s.IsVoid()) 
      {
        if (sc.IsSubtype(s, t)) return s;
        else if (sc.IsSubtype(t, s)) return t; 
        else return new Bottom();
      }
      else if (s.IsSequence())
      {
        if (t.IsSequence()) 
        {
          IType top = Intersect(s.AsSequence().Top, t.AsSequence().Top, inC);
          if (top.IsBottom()) return new Bottom();
          IType tail = Intersect(s.AsSequence().Tail, t.AsSequence().Tail, inC);
          if (tail.IsBottom()) return new Bottom();
          return new Sequence(top, tail);
        }
        else if (t.IsBaseType() || t.IsVoid() || t.IsChan() || t.IsLabelled()) 
          return Intersect(t, s, inC);
      }
      else if (s.IsChan()) 
      {
        if (t.IsChan())
        {
          IType cs= s.AsChan().Carried;
          IType ct= t.AsChan().Carried;
          // i && i = i, i && io = i, o && o = o, o && io = o, io && io = io, i && o = io
          if (s.AsChan().Capability == Chan.CAPABILITY.IN && t.AsChan().Capability != Chan.CAPABILITY.OUT)
            return new Chan(Intersect(cs, ct, inC), Chan.CAPABILITY.IN);
          else if (s.AsChan().Capability == Chan.CAPABILITY.INOUT && t.AsChan().Capability == Chan.CAPABILITY.IN) 
            return new Chan(Intersect(cs, ct, inC), Chan.CAPABILITY.IN);
          else if (s.AsChan().Capability == Chan.CAPABILITY.OUT && t.AsChan().Capability != Chan.CAPABILITY.IN)
            //return new Chan(new Union(s.AsChan().Carried, t.AsChan().Carried), Chan.CAPABILITY.OUT);
            return new Chan(DeterminedUnion(new Union(cs, ct)), Chan.CAPABILITY.OUT);
          else if (s.AsChan().Capability == Chan.CAPABILITY.INOUT && t.AsChan().Capability == Chan.CAPABILITY.OUT)   
            return new Chan(DeterminedUnion(new Union(cs, ct)), Chan.CAPABILITY.OUT);
          else if (s.AsChan().Capability == Chan.CAPABILITY.INOUT && t.AsChan().Capability == Chan.CAPABILITY.INOUT) 
          { 
            if (sc.IsSubtype(cs, ct) && sc.IsSubtype(ct, cs))
              return s;
            else return new Bottom();
          }
          if (s.AsChan().Capability == Chan.CAPABILITY.OUT && t.AsChan().Capability == Chan.CAPABILITY.IN)
            return Intersect(t, s, inC);
          else if (s.AsChan().Capability == Chan.CAPABILITY.IN && t.AsChan().Capability == Chan.CAPABILITY.OUT)
          {
            if (sc.IsSubtype(cs, ct) && sc.IsSubtype(ct,cs))
              return new Chan(cs, Chan.CAPABILITY.INOUT);
            else if (!sc.IsSubtype(ct, cs))
              return new Bottom();
            else if (sc.IsSubtype(ct, cs))
              return new ErrorType(); //the intersection is not empty but for the moment i'm not able to compute it! SAMUELE:TODO
          }
        }
        else if (t.IsSequence() && sc.IsSubtype(new Void(), t.AsSequence().Tail)) 
          return Intersect(s, t.AsSequence().Top, inC);
        else if (t.IsSequence()) 
          return new Sequence(Intersect(s, t.AsSequence().Top, inC), Intersect(new Void(), t.AsSequence().Tail, inC));
        else if (t.IsBaseType() || t.IsVoid() || t.IsLabelled()) 
          return new Bottom();
      }
      else if (s.IsLabelled()) 
      {
        if (t.IsLabelled())
        {
          AbstractLabelsSet labels = LabelsSet.Intersection(s.AsLabelled().Labels, t.AsLabelled().Labels);
          if (!labels.IsEmpty())
          {
            IType content = Intersect(s.AsLabelled().Content, t.AsLabelled().Content, inC);
            return new Labelled((LabelsSet) labels, content);
          }
          else return new Bottom();
        } 
        else if (t.IsSequence()) 
        {
          if (sc.IsSubtype(new Void(), t.AsSequence().Tail)) 
            return TypesOperations.Intersect(s,t.AsSequence().Top, inC);
        }
        else if (t.IsChan() || t.IsBaseType() || t.IsVoid()) return new Bottom();
      }
      throw new ApplicationException("private static Type intersect: Unhandled case " + s + " x " + t);
    }
    private static IType DeterminedUnion(IType t)
    {
      DeterminednessChecker dc = new DeterminednessChecker();
      if (dc.IsDetermined(t)) return t;
      //types is a set containing either void or sequences
      ISet types = Expand(t);
      //labelled types in chkdtypes have an empty Intersection with labels in
      //types
      ISet chkdtypes = new ArraySet();
      //types added during the process
      //Each iteraction selects the first Li[Si],Ti and for each Lj[Sj],Tj 
      //(i<>j) the types Li^Lj[Si+Sj],(Ti+Tj) and Lj\Li[Sj],Tj are added to
      //the set "newtypes" (only if the set of labels is not empty) and 
      //Li=Li\Lj (if i=0 the iteration terminates immediatly). When the 
      //iteration terminates the type Li\Lj1\...\Ljn[Si],Ti is added to the 
      //set of checked types "chkdtypes" and "newtypes" is used as new set
      //of types to check. 
      //NOTA BENE: Li\Lj1\...\Ljn ^ Lk = 0 for each k<>i
      //the algorithm terminates when there are no types in the set "types"       
      while (types.Count > 0)
      {
        ISet newtypes = new ArraySet();
        IType s = (IType)types[0];
        //void and non-labelled sequences are merely added to the set
        if (s.IsSequence() && s.AsSequence().Top.IsLabelled())
        {
          Sequence si = s.AsSequence();
          LabelsSet li = si.Top.AsLabelled().Labels;
          for (int j=1; j<types.Count; j++)
          {
            IType rj = (IType)types[j];
            if (rj.IsVoid() || (rj.IsSequence() && !rj.AsSequence().Top.IsLabelled())) continue;
            Sequence sj = rj.AsSequence();
            LabelsSet lj = sj.Top.AsLabelled().Labels;
            LabelsSet lint = LabelsSet.Intersection(li, lj);							
            LabelsSet ld2 = LabelsSet.Difference(lj, lint);                 
            if (!lint.IsEmpty()) 
            {
              IType content = new Union(si.Top.AsLabelled().Content, sj.Top.AsLabelled().Content);
              IType tail = new Union(si.Tail, sj.Tail);
              Sequence seq = new Sequence(new Labelled(lint, content), tail);
              newtypes.Add(seq);
            }
            if (!ld2.IsEmpty()) 
            {
              Sequence seq = new Sequence(new Labelled(ld2, sj.Top.AsLabelled().Content), sj.Tail);
              newtypes.Add(seq);
            }
            li = LabelsSet.Difference(li,lint);              
          }
          if (!li.IsEmpty()) 
          {
            Sequence seq = new Sequence(new Labelled(li, si.Top.AsLabelled().Content), si.Tail);
            chkdtypes.Add(seq);            
          }
        }
        else chkdtypes.Add(s);
        types = newtypes;
      }
      for(int i=0; i< chkdtypes.Count; i++) 
      {
        IType type = (IType)chkdtypes[i];
        if (type.IsLabelled()) 
          chkdtypes[i] = new Labelled(type.AsLabelled().Labels, DeterminedUnion(type.AsLabelled().Content));
        else if (type.IsSequence())
          chkdtypes[i] = new Sequence(DeterminedUnion(type.AsSequence().Top), DeterminedUnion(type.AsSequence().Tail));
        else if (type.IsChan())
          chkdtypes[i] = new Chan(DeterminedUnion(type.AsChan().Carried), type.AsChan().Capability);
        else if (type.IsUnion())
          chkdtypes[i] = new Union(DeterminedUnion(type.AsUnion().Fst), DeterminedUnion(type.AsUnion().Snd));
        else if (type.IsVoid() || type.IsBaseType() || type.IsErrorType()) {}
        else if (type.IsConstantTypeName()) 
          Debug.Assert(false,"This type cannot be a "+type.GetType());
      }
      IType u = TypesOperations.Unify(chkdtypes);
      Debug.Assert(new DeterminednessChecker().IsDetermined(u), " this type must be determined");
      return u;
    }
    /// <summary>
    /// Given a sequence type <c>s</c> and a type <c>t</c> Expands <c>t</c> as set containing either 
    /// guarded sequences or void
    /// </summary>
    /// <param name="s">the sequence</param>
    /// <param name="t">the type to Expand</param>
    /// <returns>a set containing either guarded sequences or void obtained by Expanding <c>t</c></returns>	
    /// <remarks>constant type name must be guarded</remarks>
    internal static ISet Expand(IType t)
    {	
      //s is Unrolled yet
      if (t.IsUnion())
      { 
        ISet exp = Expand(t.AsUnion().Fst);
        exp.AddAll(Expand(t.AsUnion().Snd));
        return exp;
      }
      else if (t.IsConstantTypeName())
        return Expand(t.AsConstantTypeName().Entry.Type);
      else if (t.IsSequence())
      {
        IType newS = t.AsSequence().Unroll();
        if (newS != t) return Expand(newS);
        else 
        {
          ISet exp = new ArraySet();
          exp.Add(t);
          return exp;
        }
      }
      else if (t.IsBaseType() || t.IsLabelled() || t.IsChan()) 
        return Expand(new Sequence(t, new Void()));
      else if (t.IsVoid())
      { 
        ISet exp = new ArraySet();
        exp.Add(t);
        return exp;
      }
      return new ArraySet();
    }
    internal static IType Unify(ISet types)
    {
      if (types.Count == 0) return new Bottom();
      else if (types.Count == 1) return (IType)types[0];
      else 
      {
        Union u = new Union((IType)types[0], (IType)types[1]);
        for (int i=2; i< types.Count; i++)
          u = new Union(u, (IType)types[i]);
        return u;
      }
    }
  }
}
