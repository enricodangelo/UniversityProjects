// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using BoPi.Common;
namespace BoPi.Types
{
  class EmptyLabel:AbstractLabelsSet
  {
    public override AbstractLabelsSet Intersect(AbstractLabelsSet label)
    { return this; }

    public override bool IsEmpty()
    { return true; }

    public override bool Includes(AbstractLabelsSet labels)
    { return false; }
  }

  class VoidLabel:AbstractLabelsSet 
  {
    public override AbstractLabelsSet Intersect(AbstractLabelsSet label)
    {
      if (label is VoidLabel)
        return this;
      else return new EmptyLabel();
    }
    public override bool IsEmpty()
    { return false; }

    public override bool Includes(AbstractLabelsSet labels)
    { return labels is VoidLabel; }		
  }
  class IntLiteralLabel:AbstractLabelsSet
  {
    private int val;

    public IntLiteralLabel(int val)
    { this.val=val; }

    public override AbstractLabelsSet Intersect(AbstractLabelsSet label)
    {
      if ((label is IntLiteralLabel) && 
        (((IntLiteralLabel)label).val==val))
        return label;
      else if (label is IntLabel) return this;
      else return new EmptyLabel();			
    }

    public override bool IsEmpty()
    { return false; }

    public override bool Includes(AbstractLabelsSet labels)
    {
      if (labels is IntLiteralLabel) return ((IntLiteralLabel)labels).val == val;
      else return false;
    }
  }

  class IntLabel:AbstractLabelsSet
  {
    public override AbstractLabelsSet Intersect(AbstractLabelsSet label)
    {
      if (label is IntLabel) return this;
      else if (label is IntLiteralLabel) return label;
      else return new EmptyLabel();
    }
    public override bool IsEmpty()
    { return false; }

    public override bool Includes(AbstractLabelsSet labels)
    {
      if (labels is IntLabel || labels is IntLiteralLabel) return true;
      else return false;
    }
  }


  class StringLiteralLabel:AbstractLabelsSet
  {
    private String val;
    public StringLiteralLabel(String val)
    { this.val=val; }

    public override AbstractLabelsSet Intersect(AbstractLabelsSet label)
    {
      if ((label is StringLiteralLabel) && 
        (((StringLiteralLabel)label).val==val))
        return label;
      else if (label is StringLabel) return this;
      else return new EmptyLabel();			
    }
    public override bool IsEmpty()
    { return false; }

    public override bool Includes(AbstractLabelsSet labels)
    {
      if (labels is StringLiteralLabel) return ((StringLiteralLabel)labels).val == val;
      else return false;
    }
  }

  class StringLabel:AbstractLabelsSet
  {
    public override AbstractLabelsSet Intersect(AbstractLabelsSet label)
    {
      if (label is StringLabel) return this;
      else if (label is StringLiteralLabel) return label;
      else return new EmptyLabel();
    }
    public override bool IsEmpty()
    { return false; }

    public override bool Includes(AbstractLabelsSet labels)
    {
      if (labels is StringLabel || labels is StringLiteralLabel) return true;
      else return false;
    }
  }

  class ChanLabel:AbstractLabelsSet
  {
    protected Chan.CAPABILITY capability;

    public ChanLabel(Chan.CAPABILITY capability)
    { this.capability=capability; }

    public override AbstractLabelsSet Intersect(AbstractLabelsSet label)
    {
      if (label is ChanLabel)
      {
        ChanLabel chanLabel = (ChanLabel) label; 
        if (capability == Chan.CAPABILITY.IN && chanLabel.capability != Chan.CAPABILITY.OUT) return this;
        else if (capability == Chan.CAPABILITY.OUT && chanLabel.capability != Chan.CAPABILITY.IN) return this;
        else return new ChanLabel(Chan.CAPABILITY.INOUT);
      }
      else return new EmptyLabel();
    }

    public override bool IsEmpty()
    { return false; }

    public override bool Includes(AbstractLabelsSet labels)
    {
      if (labels is ChanLabel) 
        return Chan.HasMoreEqCapability(((ChanLabel)labels).capability, capability);
      else return false;
    }
  }
}
