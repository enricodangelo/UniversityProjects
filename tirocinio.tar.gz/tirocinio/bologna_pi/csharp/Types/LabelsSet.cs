// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Xml;
using BoPi.Common;

namespace BoPi.Types
{
  public abstract class AbstractLabelsSet
  {
    public abstract AbstractLabelsSet Intersect(AbstractLabelsSet label);
    public abstract bool IsEmpty();
    public abstract bool Includes(AbstractLabelsSet label);
  }
  public abstract class LabelsSet:AbstractLabelsSet
  {
    public abstract void GetCode(XmlWriter xml);
    public abstract LabelsSet Subtract(LabelsSet label);
    public abstract LabelsSet Add(LabelsSet label);
    public override abstract AbstractLabelsSet Intersect(AbstractLabelsSet label);		
    public abstract override bool IsEmpty();
    public override abstract String ToString();
    public static bool Included(LabelsSet label, ISet labels)
    {
      LabelsSet l = label;
      foreach (AbstractLabelsSet ls in labels)
      {
        if (ls is LabelsSet) l = l.Subtract((LabelsSet)ls);
        if (l.IsEmpty()) return true;		
      }
      if (!l.IsEmpty()) return false; 
      else return true;
    }
    public static LabelsSet Difference(LabelsSet label, ISet labels)
    {
      LabelsSet l = label;
      foreach (AbstractLabelsSet ls in labels)
      {
        if (ls is LabelsSet) l = l.Subtract((LabelsSet)ls);
        if (l.IsEmpty()) return l;		
      }
      return l; 
    }
    public static LabelsSet Intersection(LabelsSet label, ISet labels)
    {
      LabelsSet l = label;
      bool intersected = false;
      foreach (AbstractLabelsSet ls in labels)
      {
        if (ls is LabelsSet)
        { 
          intersected = true;
          l = LabelsSet.Intersection(l, (LabelsSet)ls);
        }
        if (l.IsEmpty()) return l;		
      }
      if (!intersected) return new UnionLabel(new ArraySet());
      else return l; 
    }
    public static LabelsSet Difference(LabelsSet label1, LabelsSet label2) 
    {
      return label1.Subtract(label2);
    }
    public static LabelsSet Union(LabelsSet label1, LabelsSet label2) 
    {
      return label1.Add(label2);
    }
    public static LabelsSet Intersection(LabelsSet label1, LabelsSet label2) 
    {
      return (LabelsSet)label1.Intersect(label2);
    }


    /// <summary>
    /// used by parser to compute the rule L=L\L
    /// </summary>
    /// <param name="label1">represent $1</param>
    /// <param name="label2">represent $3</param>
    /// <returns>$$</returns>
    public static LabelsSet NormalizeDifference(LabelsSet label1, LabelsSet label2) 
    {
      //~ - ~\A = A
      if ((label1 is AnyLabel) && (label2 is DifferenceLabel))
      {
        DifferenceLabel diff= (DifferenceLabel)label2;
        return new UnionLabel(diff.diffLabels.labels);
      }
      // ~ - A = ~\A
      if ((label1 is AnyLabel) && (label2 is UnionLabel))
      {
        UnionLabel un = (UnionLabel)label2;
        return new DifferenceLabel(un);
      }
      // ~\A - ~\B =(B\A)
      if ((label1 is DifferenceLabel) &&  (label2 is DifferenceLabel))
      {
        DifferenceLabel diff1=(DifferenceLabel) label1;
        DifferenceLabel diff2=(DifferenceLabel) label2;
        return new UnionLabel(SetAlgorithms.Difference(diff2.diffLabels.labels,diff1.diffLabels.labels));                
      }
      //~\A - B = ~\(A U B)
      if ((label1 is DifferenceLabel) && (label2 is UnionLabel))
      {
        DifferenceLabel diff=(DifferenceLabel) label1;
        UnionLabel un = (UnionLabel)label2;
        diff.diffLabels.labels.AddAll(un.labels);
        return diff;
      }
      //A - ~\B = A inter B
      if ((label1 is UnionLabel) && (label2 is DifferenceLabel))
      {
        UnionLabel un = (UnionLabel)label1;
        DifferenceLabel diff=(DifferenceLabel) label2;
        return new UnionLabel(SetAlgorithms.Intersect(un.labels,diff.diffLabels.labels));
      }
      //A - B = A\B
      if ((label1 is UnionLabel) && (label2 is UnionLabel))
      {
        UnionLabel un1 = (UnionLabel)label1;
        UnionLabel un2 = (UnionLabel)label2;
        return new UnionLabel(SetAlgorithms.Difference(un1.labels,un2.labels));
      }
      //error no label => emptyset
      return new UnionLabel(new ArraySet());			

    }

    /// <summary>
    /// used by parser to compute the rule L=L#L
    /// </summary>
    /// <param name="label1">represent $1</param>
    /// <param name="label2">represent $3</param>
    /// <returns>$$</returns>
    public static LabelsSet NormalizeUnion(LabelsSet label1, LabelsSet label2) 
    {
      //~ + ~=~
      if (label1 is AnyLabel)  return label1;
      if (label2 is AnyLabel)  return label2;

      //A + B =A U B
      if ((label1 is UnionLabel) && (label2 is UnionLabel))
      {
        UnionLabel ul = (UnionLabel) label1;
        //Union is coded by AddAll
        ul.labels.AddAll(((UnionLabel) label2).labels);
        return ul;
      }
      //~\A + ~\B = ~\(A inter B)
      if ((label1 is DifferenceLabel) && (label2 is DifferenceLabel))
      {
        DifferenceLabel diff1=(DifferenceLabel)label1;
        DifferenceLabel diff2=(DifferenceLabel)label2;
        return new DifferenceLabel(new UnionLabel(SetAlgorithms.Intersect(
          diff1.diffLabels.labels,diff2.diffLabels.labels)));
      }
      // A + ~\B = ~\(B inter A)
      if ((label1 is UnionLabel) &&  (label2 is DifferenceLabel))
      {
        UnionLabel ul = (UnionLabel) label1;
        DifferenceLabel diff2=(DifferenceLabel)label2;
        return new DifferenceLabel(new UnionLabel(SetAlgorithms.Difference(diff2.diffLabels.labels,ul.labels)));
      }
      if ((label2 is UnionLabel) &&  (label1 is DifferenceLabel))
      {
        UnionLabel ul = (UnionLabel) label2;
        DifferenceLabel diff2=(DifferenceLabel)label1;
        return new DifferenceLabel(new UnionLabel(SetAlgorithms.Difference(diff2.diffLabels.labels,ul.labels)));
      }
      //return emptyset
      return new UnionLabel(new ArraySet());			
    }
  }
  
  public class AnyLabel:LabelsSet 
  {
    public override void GetCode(XmlWriter xml)
    {
      xml.WriteStartElement("anylabel");
      xml.WriteEndElement();
    }
    public override bool Includes(AbstractLabelsSet label) 
    {
      if (label is LabelsSet)
        return true;
      return false;
    }	
    public override bool IsEmpty() 
    {
      return false;
    }
    public override LabelsSet Subtract(LabelsSet label) 
    {
      //~\~=0
      if (label is AnyLabel)
        return new UnionLabel(new ArraySet(0));
      //~\L=~\L
      if (label is UnionLabel)
        return new DifferenceLabel((UnionLabel) label);
      //~\(~\L) = L
      if (label is DifferenceLabel)
        return new UnionLabel(((DifferenceLabel) label).diffLabels);
      throw new ApplicationException("AnyLabel.Subtract: This code must be unreacheable");
    }
    public override LabelsSet Add(LabelsSet label) 
    {
      return this;
    }
    public override AbstractLabelsSet Intersect(AbstractLabelsSet label) 
    {
      //~ inter L = L
      if (label is LabelsSet)
        return label;
      else return new EmptyLabel();
    }
    public override String ToString() 
    {
      return "~";
    }	

  }
  /**
   * This class represents ~\L
   */
  public class DifferenceLabel:LabelsSet 
  {
    public UnionLabel diffLabels;
    public override void GetCode(XmlWriter xml)
    {
      xml.WriteStartElement("Differencelabel");
      foreach (String str in diffLabels.labels)
      {
        xml.WriteStartElement("label");
        xml.WriteAttributeString("name",str);
        xml.WriteEndElement();
      }
      xml.WriteEndElement();
    }

    public override bool Includes(AbstractLabelsSet label) 
    {
      if (label is LabelsSet)
        return !diffLabels.Includes(label);
      else return false;
    }
    public DifferenceLabel(UnionLabel labels) 
    {
      this.diffLabels = labels;
    }
    public override bool IsEmpty() 
    {
      return false;
    }
    public override LabelsSet Subtract(LabelsSet label) 
    {
      //(~\L) \~=0
      if (label is AnyLabel)
        return new UnionLabel(new ArraySet(0));
      //~\L1 \ L2=~\L1UL2
      if (label is UnionLabel)
        return new DifferenceLabel(new UnionLabel(SetAlgorithms.Union(((UnionLabel) label).labels, diffLabels.labels)));
      //(~\L) \ (~\L1) = L1\L
      if (label is DifferenceLabel) 
      {
        ISet s = SetAlgorithms.Difference(((DifferenceLabel) label).diffLabels.labels, diffLabels.labels);
        return new UnionLabel(s);
      }
      throw new ApplicationException("This code must be unreacheable");
    }
    public override LabelsSet Add(LabelsSet label) 
    {
      if (label is AnyLabel)
        return new AnyLabel();
      if (label is DifferenceLabel)
      {
        ISet Intersection = SetAlgorithms.Intersect(diffLabels.labels, ((DifferenceLabel) label).diffLabels.labels);
        if (Intersection.Count==0)
          return new AnyLabel();
        else
          return new DifferenceLabel(new UnionLabel(Intersection));
      }
      if (label is UnionLabel) 
      {
        //~\L1 + L2 = ~\(L1 \ L1 inter L2 )
        ISet Difference =SetAlgorithms.Difference(diffLabels.labels,
          SetAlgorithms.Intersect(diffLabels.labels, ((UnionLabel) label).labels));
        if (Difference.Count==0)
          return new AnyLabel();
        else
          return new DifferenceLabel(new UnionLabel(Difference));
      }
      throw new ApplicationException("DifferenceLabel.Add: This code must be unreacheable");
    }
    public override AbstractLabelsSet Intersect(AbstractLabelsSet label) 
    {
      if (!(label is LabelsSet)) return new EmptyLabel();
      if (label is AnyLabel) return this;
      //~\L1 inter ~\L2 = ~\(L1+L2)
      if (label is DifferenceLabel) 
        return new DifferenceLabel((UnionLabel)LabelsSet.Union(this.diffLabels, ((DifferenceLabel)label).diffLabels));
      //~\L1 inter L2 = L2 \ L1
      if (label is UnionLabel)
        return new UnionLabel(SetAlgorithms.Difference(((UnionLabel)label).labels, diffLabels.labels));
      throw new ApplicationException("DifferenceLabel.Intersect: This code must be unreacheable");
    }
    public override String ToString() 
    {
      return "~\\" + diffLabels.ToString();
    }
  }
  public class UnionLabel:LabelsSet 
  {
    public ISet labels;
    public UnionLabel(ISet labels)
    {
      this.labels = labels;
    }
    public UnionLabel(String label) 
    {
      labels = new ArraySet(1);
      labels.Add(label);
    }
    public UnionLabel(UnionLabel label) 
    {
      this.labels = label.labels;
    }
    public override bool Includes(AbstractLabelsSet label) 
    {
      if (label is LabelsSet)
      {
        if (label is UnionLabel)
          return (SetAlgorithms.Difference(((UnionLabel) label).labels, labels).Count)==0;
      }
      else if (label is EmptyLabel) return true;
      return false;
    }
    public override bool IsEmpty() 
    {
      return (labels.Count==0);
    }
    public override LabelsSet Subtract(LabelsSet label) 
    {
      //L \~=0
      if (label is AnyLabel)
        return new UnionLabel(new ArraySet(0));
      //L \ L1=
      if (label is UnionLabel) 
      {
        return new UnionLabel(SetAlgorithms.Difference(labels, ((UnionLabel) label).labels));
      }
      //L \ (~\L1) = L inter L1
      if (label is DifferenceLabel) 
      {
        ISet s=SetAlgorithms.Intersect(((DifferenceLabel) label).diffLabels.labels, labels);
        return new UnionLabel(s);
      }
      throw new ApplicationException("UnionLabel.Subtract: This code must be unreacheable");
    }
    public override LabelsSet Add(LabelsSet label) 
    {
      if (label is AnyLabel) return new AnyLabel();
      if (label is DifferenceLabel) return label.Add(this);
      if (label is UnionLabel)
        return new UnionLabel(SetAlgorithms.Union(labels, ((UnionLabel) label).labels));
      throw new ApplicationException("UnionLabel.Add: This code must be unreacheable");
    }
    public override AbstractLabelsSet Intersect(AbstractLabelsSet label) 
    {
      if (!(label is LabelsSet)) return new EmptyLabel();
      if (label is AnyLabel) return this;
      if (label is DifferenceLabel) return label.Intersect(this);
      if (label is UnionLabel) 
        return new UnionLabel(SetAlgorithms.Intersect(((UnionLabel)label).labels, labels));
      throw new ApplicationException("UnionLabel.Intersect: This code must be unreacheable");
    }
    public override String ToString() 
    {
      return labels.ToString();
    }
    public override void GetCode(XmlWriter xml)
    {
      xml.WriteStartElement("unionlabel");
      foreach (String str in labels)
      {
        xml.WriteStartElement("label");
        xml.WriteAttributeString("name",str);
        xml.WriteEndElement();
      }
      xml.WriteEndElement();
    }
  }
}
