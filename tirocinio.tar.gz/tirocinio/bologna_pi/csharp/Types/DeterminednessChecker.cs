// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using BoPi.Common;
using System.Diagnostics;

namespace BoPi.Types
{
  public class DeterminednessChecker
  {
    private ISet ndet = new ArraySet();
    
    /// <summary>
    /// Check if the type is determined. A type is determined if every union
    /// starts with a different label. <c>a[int]+a[string]</c> is not
    /// determined.
    /// </summary>
    /// <param name="s">the type</param>
    /// <returns>true if the type is determined, false otherwise</returns>
    public bool IsDetermined(IType s)
    { return IsDetermined(s, new ArraySet()); }

    private bool IsDetermined(IType s, ISet det)
    {
      if (det.Contains(s)) return true;
      else if (ndet.Contains(s)) return false;
      else 
      {
        bool res = true;
        det.Add(s);
        if (s.IsBottom() || s.IsBaseType() || s.IsVoid())
        { res = true; }
        else if (s.IsChan())  
        { res = IsDetermined(s.AsChan().Carried, det); }
        else if (s.IsLabelled())
        { res = IsDetermined(s.AsLabelled().Content, det); }
        else if (s.IsSequence()) 
        { res = IsDetermined(s.AsSequence().Top, det) && IsDetermined(s.AsSequence().Tail, det); }
        else if (s.IsUnion()) 
        {
          Union u = s.AsUnion();
          ISet firstoffst = GetFirst(u.Fst, new ArraySet());
          ISet firstofsnd = GetFirst(u.Snd, new ArraySet());
          for (int i = 0; i < firstoffst.Count && res; i++)
          {
            for (int j = 0; j < firstofsnd.Count && res; j++)
            {
              if (firstoffst[i] is LabelsSet && firstofsnd[j] is LabelsSet)
                res &= ((LabelsSet)firstoffst[i]).Intersect((LabelsSet)firstofsnd[j]).IsEmpty();
              //              else if (firstoffst[i] is ChanLabel && firstofsnd[j] is ChanLabel)
              //                res &= ((ChanLabel)firstoffst[i]).Intersect((ChanLabel)firstofsnd[j]).IsEmpty();
              //              AbstractLabelsSet l2 = (AbstractLabelsSet)firstofsnd[j];
              //              if (l1.GetType().Equals(l2.GetType())) 
              //                res &= l1.Intersect(l2).IsEmpty();
            }
          }
          res &= IsDetermined(u.Fst, det) && IsDetermined(u.Snd, det);
        }
        else if (s.IsConstantTypeName())
        { res = IsDetermined(s.AsConstantTypeName().Entry.Type, det); }
        if (!res) 
        {
          det.Remove(s);
          ndet.Add(s);
        }
        return res;
      }
    }

    /// <summary>
    /// Returns the first of this type (the set of labels starting the type)
    /// </summary>
    /// <returns>the first of this type (a set of AbstractLabelsSet)</returns>
    public ISet GetFirst(IType s, ISet visited)
    {
      ISet first = new ArraySet();
      GetFirst(s, new ArraySet(), first);
      return first;
    }

    private void GetFirst(IType s, ISet visited, ISet first)
    {
      if (!visited.Contains(s))
      {
        visited.Add(s);
        if (s.IsUnion())
        {
          GetFirst(s.AsUnion().Fst, visited, first);
          GetFirst(s.AsUnion().Snd, visited, first);
        }
        else if (s.IsSequence())
        {
          IType t = s.AsSequence().Unroll();
          if (t != s) GetFirst(t, visited, first);
          else GetFirst(s.AsSequence().Top, visited, first);
        }
        else if (s.IsConstantTypeName())
          GetFirst(s.AsConstantTypeName().Entry.Type, visited, first);		      
        else if (s.IsLabelled())
          first.Add(s.AsLabelled().Labels);
        else if (s.IsChan())
          first.Add(new ChanLabel(s.AsChan().Capability));
        else if (s.IsInt())
          first.Add(new IntLabel());
        else if (s.IsIntLiteral())
          first.Add(new IntLiteralLabel(s.AsIntLiteral().Val));
        else if (s.IsString())
          first.Add(new StringLabel());
        else if (s.IsStringLiteral())
          first.Add(new StringLiteralLabel(s.AsStringLiteral().Val));
        else if (s.IsVoid()) 
          first.Add(new VoidLabel());
        else if (s.IsErrorType()) {}
        else Debug.Assert(false, "DeterminednessChecker.GetFirst(): " + "Unhandled case " + s.GetType());
      }	
    }
  }
}
