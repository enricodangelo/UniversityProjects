// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Diagnostics;
using System.Collections;
using BoPi.Common;
using System.Xml;

namespace BoPi.Types
{
  /// <summary>
  /// Class that represent the bottom type
  /// </summary>
  public class Bottom: Type 
  {
    public override bool IsBottom()
    { return true; }

    public override Bottom AsBottom()
    { return this; }

    public override String ToString()
    { return "empty"; }

    public override bool Equals(Object obj)
    { return (obj is Bottom); }

    public override int GetHashCode()
    { return ToString().GetHashCode(); }

    public override void Compile(XmlWriter xml)
    {
      xml.WriteStartElement("bottom");
      xml.WriteEndElement();
    }
  }
  /// <summary>
  /// Class that represent the union type
  /// </summary>
  public class Union: Type 
  {
    private IType fst;
    private IType snd;

    public Union(IType fst, IType snd) 
    {
      this.fst = fst;
      this.snd = snd;
    }
    public IType Fst { get { return fst; } }
    public IType Snd { get { return snd; } }

    public override bool IsUnion()
    { return true; }

    public override Union AsUnion()
    { return this; }

    public override bool Equals(Object obj)
    {
      if (obj is Union)
      {
        Union u = (Union)obj;
        return u.fst.Equals(fst) && u.snd.Equals(snd);
      }
      else return false;
    }

    public override int GetHashCode()
    {
      IList pair = new ArrayList(2);
      pair.Add(fst);
      pair.Add(snd);
      return pair.GetHashCode();
    }

    public override String ToString() 
    { return fst.ToString() + "+" + snd.ToString(); }

		public override void ResolveNames(TypeSymbolTable st)
		{
			fst.ResolveNames(st);
			snd.ResolveNames(st);
		}

    public override void Compile(XmlWriter xml)
    {
      xml.WriteStartElement("choice");
      fst.Compile(xml);
      snd.Compile(xml);
      xml.WriteEndElement();
    }
  }

  /// <summary>
  /// Denotes the empty type (it recognizes the empty string)
  /// </summary>
  public class Void : Type 
  {	
    public override bool IsVoid()
    { return true; }

    public override Void AsVoid()
    { return this; }

    public override bool Equals(Object obj)
    { return (obj is Void); }

    public override int GetHashCode()
    { return ToString().GetHashCode(); }

    public override String ToString()
    { return "void"; }

    public override void Compile(XmlWriter xml)
    {
      xml.WriteStartElement("void");
      xml.WriteEndElement();
    }
  }
  
  public class ConstantTypeName : Type 
  {
    private readonly String name;
		private ISymbolTableTypeEntry entry;
    
		public ConstantTypeName(String name) : this(name, null)
		{ }

    public ConstantTypeName(String name, ISymbolTableTypeEntry entry) 
    {
      this.name = name;
			this.entry = entry;
    }
    public String Name { get { return name; } }

		public ISymbolTableTypeEntry Entry { get { return entry; } }

    public override bool IsConstantTypeName()
    { return true; }

    public override ConstantTypeName AsConstantTypeName()
    { return this; }

    public override bool Equals(Object obj) 
    {
      if (obj is ConstantTypeName) return (obj == this);
        //return ((ConstantTypeName)obj).Name.Equals(name);
      else return false;
    }

    public override int GetHashCode()
    { return ToString().GetHashCode(); }

    public override String ToString() 
    { return name; }

		public override void ResolveNames(TypeSymbolTable st)
		{ entry = (ISymbolTableTypeEntry) st.Lookup(name); }

    public override void Compile(XmlWriter xml)
    {
			Debug.Assert(entry.Used);
      xml.WriteStartElement("schemaref");
      //xml.WriteAttributeString("name", entry.Name);
      xml.WriteAttributeString("name", entry.FreshName);
      xml.WriteEndElement();
    }
  }

  /// <summary>
  /// Denotes sequences.
  /// </summary>
  public class Sequence :Type 
  {
    private IType top;
    private IType tail;

    public Sequence(IType top, IType tail) 
    {	
      this.top = top;
      this.tail = tail;
    }
    public IType Top { get { return top; } }

    public IType Tail { get { return tail; } }

    public override bool IsSequence()
    { return true; }

    public override Sequence AsSequence()
    { return this; }

    /// <summary>
    /// Normalizes the top of a sequence. In particular: 
    /// (a) (S,T),R = S,(T,R); (b) (S+T),R = (S,R) + (T,R); (c) U,S = E(U),S; (d) (),S = S
    /// If no normalization is possible the method returns reference to the the same object (this)
    /// </summary>
    /// <returns>the normalized type or this if no normalization can be performed</returns>
    public IType Unroll()
    {
      //Equivalence (S,R),T = S,(R,T)
      if (top.IsSequence()) 
        return (new Sequence(top.AsSequence().top, new Sequence(top.AsSequence().tail, tail))).Unroll();
        //Equivalence S+T,R = S,R + T,R 
      else if (top.IsUnion())
      {
        return new Union(new Sequence(top.AsUnion().Fst,tail), new Sequence(top.AsUnion().Snd,tail));
      }
        //Equivalence U,S = E(U),S
      else if (top.IsConstantTypeName())
      {
        ConstantTypeName v = top.AsConstantTypeName();
        //unguarded recursion loops 
        return new Sequence(v.Entry.Type, tail);
      }
        //Equivalence (),S = S	
      else if (top.IsVoid()) return tail;
      else return this;
    }
    public override bool Equals(Object obj)
    {
      if (obj is Sequence)
      {
        Sequence s = (Sequence)obj;
        return s.top.Equals(top) && s.tail.Equals(tail);
      }
      else return false;
    }

    public override int GetHashCode()
    {
      IList pair = new ArrayList(2);
      pair.Add(top);
      pair.Add(tail);
      return pair.GetHashCode();
    }

    public override string ToString()
    { return top.ToString() + "," + tail.ToString(); }

		public override void ResolveNames(TypeSymbolTable st)
		{
			top.ResolveNames(st);
			tail.ResolveNames(st);
		}
    public override void Compile(XmlWriter xml)
    {
      xml.WriteStartElement("sequence");
      top.Compile(xml);
      tail.Compile(xml);
      xml.WriteEndElement();
    }
  }
    
  public class Labelled: Type 
  {
    private LabelsSet matchedLabels;
    private IType content;
		
    public Labelled(LabelsSet labels, IType content) 
    {
      this.matchedLabels = labels;
      this.content = content;
    }

    public LabelsSet Labels 
    { get { return matchedLabels; } }

    public IType Content { get { return content; } }

    public override bool IsLabelled()
    { return true; }

    public override Labelled AsLabelled()
    { return this; }

    public override bool Equals(Object obj)
    {
      if (obj is Labelled)
      {
        Labelled l = (Labelled)obj;
        return Labels.Includes(l.Labels) && 
          l.Labels.Includes(matchedLabels) && Content.Equals(l.Content);
      }
      return false;
    }

    public override int GetHashCode()
    {
      IList pair = new ArrayList(2);
      pair.Add(matchedLabels);
      pair.Add(content);
      return pair.GetHashCode();
    }

    public override String ToString()
    { return "{" + matchedLabels + "}[" + content + "]"; }

		public override void ResolveNames(TypeSymbolTable st)
		{ content.ResolveNames(st); }

    public override void Compile(XmlWriter xml)
    {
      xml.WriteStartElement("labelled");
      matchedLabels.GetCode(xml);
      content.Compile(xml);
      xml.WriteEndElement();
    }
  }
  
  public abstract class BaseType: Type
  {
    public override bool IsBaseType()
    { return true; }
  }

  public class IntLiteral:BaseType 
  {
    private readonly int val;
		
    public IntLiteral(int val)
    { this.val=val; }

    public int Val { get { return val; } }

    public override bool IsIntLiteral()
    { return true; }

    public override IntLiteral AsIntLiteral()
    { return this; }	

    public override String ToString() 
    { return val.ToString(); }        

    public override bool Equals(Object obj) 
    { return ((obj is IntLiteral) && (val==((IntLiteral) obj).val)); }

    public override int GetHashCode()
    { return val.GetHashCode(); }

    public override void Compile(XmlWriter xml)
    {
      xml.WriteStartElement("intLit");
      xml.WriteString(val.ToString());
      xml.WriteEndElement();
    }
  }
    
  public class IntType:BaseType 
  {
    public override bool IsInt()
    { return true; }

    public override IntType AsInt()
    { return this; }

    public override bool Equals(Object obj) 
    { return (obj is IntType); }

    public override int GetHashCode()
    { return ToString().GetHashCode(); }

    public override String ToString() 
    { return "int"; }  

    public override void Compile(XmlWriter xml)
    {
      xml.WriteStartElement("int");
      xml.WriteEndElement();
    }
  }
  
  public class StringLiteral:BaseType 
  {
    private readonly String val;

    public StringLiteral(String val)
    { this.val=val; }

    public String Val { get { return val; }}

    public override bool IsStringLiteral()
    { return true; }

    public override StringLiteral AsStringLiteral()
    { return this; }

    public override String ToString() 
    { return "\""+val+"\""; }

    public override bool Equals(Object obj) 
    { return ((obj is StringLiteral) && (val.Equals(((StringLiteral) obj).val)));	}

    public override int GetHashCode()
    { return val.GetHashCode(); }

    public override void Compile(XmlWriter xml)
    {
      xml.WriteStartElement("strLit");
      xml.WriteCData(val);
      xml.WriteEndElement();
    }
  } 
  public class StringType:BaseType 
  {
    public override bool IsString()
    { return true; }

    public override StringType AsString()
    { return this; }

    public override bool Equals(Object obj) 
    { return (obj is StringType); }

    public override int GetHashCode()
    { return ToString().GetHashCode(); }

    public override String ToString() 
    { return "String"; }

    public override void Compile(XmlWriter xml)
    {
      xml.WriteStartElement("string");
      xml.WriteEndElement();
    }
  }
  
  /**
   * Denotes the channel type. In particular a channel can have one of the following capabilities: 
   * input capability, output capability, both. 
   */
  public class Chan:Type 
  {
    public enum CAPABILITY { OUT = +1, IN = -1, INOUT = +2 }
    private IType carried;
    private CAPABILITY capability;
		
    public Chan(IType carried, int capability)
    {
      this.carried = carried;
      if (capability == +1) this.capability = CAPABILITY.OUT;
      else if (capability == -1) this.capability = CAPABILITY.IN;
      else this.capability = CAPABILITY.INOUT;
      this.carried = carried;
    }
    public Chan(IType carried, Chan.CAPABILITY capability) 
    {
      this.carried = carried;
      this.capability = capability;
    }
    public IType Carried { get { return carried; } }
				
    public CAPABILITY Capability { get { return capability; } }

    public override bool IsChan()
    { return true; }

    public override Chan AsChan()
    { return this; }

    public bool HasInputCapability() 
    { return (capability == CAPABILITY.IN) || (capability == CAPABILITY.INOUT); }

    public bool HasOutputCapability() 
    { return (capability == CAPABILITY.OUT) || (capability == CAPABILITY.INOUT); }

    public bool HasInputOutputCapability() 
    { return (capability == CAPABILITY.INOUT); }

    public static bool HasMoreEqCapability(Chan.CAPABILITY cap1, Chan.CAPABILITY cap2) 
    { return ((Math.Abs((int)cap1) > Math.Abs((int)cap2)) || (cap1 == cap2)); }
        
    public override bool Equals(Object obj)
    {
      if (obj is Chan) {
        Chan c = (Chan)obj;
        return (c.Capability == capability && c.Carried.Equals(carried));
      }
      else return false;
    }

    public override int GetHashCode()
    {
      IList pair = new ArrayList(2);
      pair.Add(capability);
      pair.Add(carried);
      return pair.GetHashCode();
    }

    public override string ToString()
    {
      String res = "<"+carried.ToString()+">";
      if (capability == CAPABILITY.IN)
        res = res+"^I";
      if (capability == CAPABILITY.OUT)
        res = res+"^O";
      if (capability == CAPABILITY.INOUT)
        res = res+"^IO";
      return res;
    }

		public override void ResolveNames(TypeSymbolTable st)
		{ carried.ResolveNames(st); }

    public override void Compile(XmlWriter xml)
    {
      String strcap="";
      if (capability==Chan.CAPABILITY.OUT) strcap="O";
      if (capability==Chan.CAPABILITY.INOUT) strcap="IO";
      if (capability==Chan.CAPABILITY.IN) strcap="I";
      xml.WriteStartElement("chan");
      xml.WriteAttributeString("capability",strcap);
      carried.Compile(xml);
      xml.WriteEndElement();
    }
  }

  public class ErrorType:Type 
  {		
    public override bool IsErrorType()
    { return true; }

    public override bool Equals(Object obj)
    { return (obj is ErrorType); }

    public override int GetHashCode()
    { return ToString().GetHashCode(); }

    public override String ToString() 
    { return "ErrorType"; }   
    
    public override void Compile(XmlWriter xml) 
    { xml.WriteElementString("ErrorType", "", ""); }
  }
}
