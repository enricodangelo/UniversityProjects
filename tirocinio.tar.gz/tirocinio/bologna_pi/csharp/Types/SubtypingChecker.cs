// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.IO;
using BoPi.Common;

namespace BoPi.Types
{
  public interface ISubtypingChecker 
  {
    bool IsSubtype(IType s, IType t);
  }
  /// <summary>
  /// Summary description for Class1.
  /// </summary>
  public class SubtypingChecker
  {
    private EmptynessChecker ec = new EmptynessChecker();
    private DeterminednessChecker dc = new DeterminednessChecker();
    private ISet aF = new ArraySet();
    public SubtypingChecker(EmptynessChecker ec, DeterminednessChecker dc)
    {
      this.ec = ec;
      this.dc = dc;
    }
    
    public SubtypingChecker(): this(new EmptynessChecker(), new DeterminednessChecker())
    {}
    
    public SubtypingChecker(EmptynessChecker ec): this(ec, new DeterminednessChecker())
    {}
    
    public SubtypingChecker(DeterminednessChecker dc): this(new EmptynessChecker(), dc)
    {}
    public bool IsSubtype(IType s, IType t)
    {
      return IsSubtype(s, t, new ArraySet());
    }
    /// <summary>
    /// Checks the subtyping relation between two types.
    /// </summary>
    /// <param name="s">the first type</param>
    /// <param name="t">the second type</param>
    /// <param name="ta">the object containing typing assumptions</param>
    /// <returns>true if <c>s</c> is a subtype of <c>t</c>, false otherwise</returns>
    /// <remarks>The sets in <c>ta<c> are updated. In particular <c>ta</c> is
    /// updated considering the relation that have been used for 
    /// proving <c>s&lt:t</c>.
    /// These sets prevent the same test to be performed twice. </remarks>
    public bool IsSubtype(IType s, IType t, ISet aT)
    {
      if (ec.IsEmpty(s)) return true;
      if (s.IsVoid() && t.IsVoid()) return true;
      else if (s.IsVoid() && (t.IsBaseType() || t.IsChan() || t.IsLabelled())) return false;
      else if (s.IsErrorType() || t.IsErrorType()) return true;
      else if (s.IsBaseType() && t.IsBaseType()) 
      {
        if (s.IsInt() && t.IsInt()) return true;
        else if (s.IsIntLiteral() && t.IsInt()) return true;
        else if (s.IsIntLiteral() && t.IsIntLiteral()) 
          return (s.AsIntLiteral().Val == t.AsIntLiteral().Val);	
        else if (s.IsString() && t.IsString()) return true;
        else if (s.IsStringLiteral() && t.IsString()) return true;
        else if (s.IsStringLiteral() && t.IsStringLiteral()) 
          return s.AsStringLiteral().Val.Equals(t.AsStringLiteral().Val);
        else return false;
      }
      else if (s.IsLabelled() && t.IsLabelled()) 
      { 
        Labelled l1 = s.AsLabelled();
        Labelled l2 = t.AsLabelled();
        return l2.Labels.Includes(l1.Labels) && IsSubtype(l1.Content, l2.Content, aT);
      }
      else if (s.IsLabelled() && (t.IsBaseType() || t.IsChan()))
        return false;
      else if (s.IsBaseType() && (t.IsLabelled() || t.IsChan()))
        return false;
      else if (s.IsChan() && (t.IsLabelled() || t.IsBaseType()))
        return false;
        /* TypesAlgorithms for channels works as follow &ltS1&gt^K1 &lt: &ltS2&gt^K2 :
        * if K2 is included in or is equal to K1 then 
        * if K2={Input Capability} then S1&lt:S2 (covariance)
        * if K2={Output Capability} then S2&lt:S1 (contravariance)
        * if K2={Output Capability, InputCapability} then S2&lt:S1 &&  S1&lt:S2 (invariance)
        * else return false; */
      else if (s.IsChan() && t.IsChan()) 
      {
        Chan chan1 = s.AsChan();
        Chan chan2 = t.AsChan();
        if (Chan.HasMoreEqCapability(chan1.Capability, chan2.Capability))
        {	  
          bool isSubtype = true;
          if (chan2.HasInputCapability())
            isSubtype &= IsSubtype(chan1.Carried, chan2.Carried, aT);
          if (chan2.HasOutputCapability())
            isSubtype &= IsSubtype(chan2.Carried, chan1.Carried, aT);
          return isSubtype;
        }
        return false;
      }
      else if (s.IsSequence()) 
        return auxSubType(s.AsSequence(), t, aT);
      else 
      { 
        Assumption ass = new Assumption(s, t);
        if (aT.Contains(ass))
          return true;
        else if (aF.Contains(ass))
          return false;
        else 
        {
          bool res = false; 
          aT.Add(ass);
          if (s.IsConstantTypeName()) 
            res= IsSubtype(s.AsConstantTypeName().Entry.Type, t, aT);
          else if (s.IsUnion()) 
            res = IsSubtype(s.AsUnion().Fst, t, aT) && IsSubtype(s.AsUnion().Snd, t, aT); 
          else if (s.IsLabelled()) 
            res = auxSubType(new Sequence(s, new Void()), t, aT);
          else if (s.IsVoid()) 
          {
            if (t.IsUnion())
              res = IsSubtype(s, t.AsUnion().Fst, aT) || IsSubtype(s, t.AsUnion().Snd, aT);
            else if (t.IsSequence()) 
              res = IsSubtype(s, t.AsSequence().Top, aT) && IsSubtype(s, t.AsSequence().Tail, aT);
            else if (t.IsConstantTypeName())
              res = IsSubtype(s, t.AsConstantTypeName().Entry.Type, aT);
          }
          else if (s.IsBaseType() || s.IsChan()) 
          {
            if (t.IsUnion())
              res = IsSubtype(s, t.AsUnion().Fst, aT) || IsSubtype(s, t.AsUnion().Snd, aT);
            else res = auxSubType(new Sequence(s,new Void()), t, aT);
          } 
          else if (s.IsVoid() && t.IsSequence())
            res = IsSubtype(s, t.AsSequence().Top, aT) && 
              IsSubtype(s, t.AsSequence().Tail, aT); 
          else if (t.IsUnion()) 
            res = IsSubtype(s, t.AsUnion().Fst, aT) || 
              IsSubtype(s, t.AsUnion().Snd, aT); 
          else if (t.IsConstantTypeName()) 
            res = IsSubtype(s, t.AsConstantTypeName().Entry.Type, aT); 
          else throw new ApplicationException("IsSubtype: Unhandled case "+ s.GetType() + "?<:?" + t.GetType());
          if (!res) 
          { 
            aT.Remove(ass); 
            aF.Add(ass);
          }
          return res;
        }
      }
    }
    /// <summary>
    /// Checks the subtyping relation between a sequence and a type.
    /// </summary>
    /// <param name="s">the sequence</param>
    /// <param name="t">the type</param>
    /// <param name="ta">a set containing typing assumptions </param>
    /// <returns>true if <c>s</c> is a subtype of <c>t</c>, false otherwise</returns>
    private bool auxSubType(Sequence s, IType t, ISet aT)
    {	
      IType newS = s.Unroll();
      if (newS != s) 
        return IsSubtype(newS, t, aT);
      Assumption ass = new Assumption(s, t);
      if (aT.Contains(ass))
        return true;
      else if (aF.Contains(ass))
        return false;
      else 
      {
        bool res = false;
        //Equivalence of S with S,()
        if (t.IsLabelled() || t.IsBaseType() || t.IsChan()) 
          return auxSubType(s, new Sequence(t, new Void()), aT);
        else if (t.IsConstantTypeName()) 
          res= auxSubType(s, t.AsConstantTypeName().Entry.Type, aT);
        else if (t.IsSequence())
        {
          IType newT = t.AsSequence().Unroll();
          if (newT != t) res= IsSubtype(s, newT, aT);
          else res= IsSubtype(s.Top, t.AsSequence().Top, aT) && 
                 IsSubtype(s.Tail, t.AsSequence().Tail, aT);
        }
        else if (t.IsUnion())
        {
          //this simplified version of the algorithm can be applied only if t is determined 
          if (dc.IsDetermined(t))
          {
            Union u = t.AsUnion();
            if (s.Top.IsBaseType() || s.Top.IsChan()) 
              res= IsSubtype(s, u.Fst, aT) || IsSubtype(s, u.Snd, aT);
            else if (s.Top.IsLabelled())
            {
              Labelled top = s.Top.AsLabelled();
              LabelsSet l = top.Labels;
              ISet first = dc.GetFirst(u.Fst, new ArraySet());
              LabelsSet intersect = LabelsSet.Intersection(l, first);
              LabelsSet Difference = LabelsSet.Difference(l, first);
              bool isSubtype = true;
              Sequence seq1 = new Sequence(new Labelled(intersect, top.Content), s.Tail);
              Sequence seq2 = new Sequence(new Labelled(Difference, top.Content), s.Tail);
              if (!intersect.IsEmpty())
                isSubtype &= auxSubType(seq1, u.Fst, aT);
              if (!Difference.IsEmpty())
                isSubtype &= auxSubType(seq2, u.Snd, aT);
              res= isSubtype;
            }
          }
          else //if (!dc.IsDetermined(t))
          {
            ISet expansion = TypesOperations.Expand(t.AsUnion());
            expansion = Filter(s, expansion);
            //if top is labelled a label normalization is performed
            IType ntop;
            if (s.Top.IsLabelled()) 
            { 
              //computes the "first" of the set of types
              ArraySet first = new ArraySet();
              foreach (Sequence seq in expansion)	first.Add(seq.Top.AsLabelled().Labels);
              //normalize the type with respect to "first". 
              //A label of exptop is either included or disjoint from each label of first
              ntop = normalize(s.Top.AsLabelled(), first); 
              //if the type is modified IsSubtype is invoked because normalization does not return a sequence
              s = new Sequence(ntop, s.Tail);
            }
            if (s.Top.IsUnion())
              res = IsSubtype(s, t, aT);
            else if (s.Top.IsBaseType() || s.Top.IsChan() || s.Top.IsLabelled())
            {
              bool isLabelledSeq = s.Top.IsLabelled();
              ulong subsetNum = ((ulong)1) << expansion.Count;
              bool issub=true;
              for (ulong c = 0; c < subsetNum && issub; c++) 
              {
                ISet inter1 = new ArraySet(); 
                ISet inter2 = new ArraySet();
                for (int i = 0; i < expansion.Count; i++) 
                {	
                  Sequence seq = (Sequence)expansion[i];
                  ulong bitmask = ((ulong)1) << i;
                  if ((c & bitmask) != 0) 
                  {
                    if (isLabelledSeq) inter1.Add(seq.Top.AsLabelled().Content);
                    else inter1.Add(seq.Top);
                  }
                  else inter2.Add(seq.Tail);
                }
                issub = false;
                if (inter1.Count != 0) 
                {
                  IType t1 = TypesOperations.Unify(inter1);
                  if (isLabelledSeq)
                    issub |= IsSubtype(s.Top.AsLabelled().Content, t1, aT);
                  issub |= IsSubtype(s.Top, t1, aT);
                }
                if (!issub && inter2.Count != 0) 
                {
                  IType t2 = TypesOperations.Unify(inter2);
                  issub = IsSubtype(s.Tail, t2, aT);
                }
              }
              res = issub;
            }
            else throw new ApplicationException("auxSubType: " + s.Top);
          }
        }
        if (!res) 
        { 
          aT.Remove(ass); 
          aF.Add(ass);
        }
        return res;
      }
    }
    /// <summary>
    /// Given a labelled type <c>L[S]</c> and a set of first <c>{L0, L1, ...., Ln}</c> splits <c>L[S]</c> is an equivalent union of schemas 
    /// <c>L0'[S] + L1'[S] + ... + Ln[S]</c> such that the Intersection between <c>Li'</c> and <c>Li</c> is either empty or included in Li' 
    /// and the union of <c>Li</c> is equal to <c>L</c>.  
    /// </summary>
    /// <param name="s">the labelled type <c>L[S]</c></param>
    /// <param name="first">a set containing AbstractLabelsSet <c>{L0, L1, ...., Ln}</c></param>
    /// <returns>a type <c>L0'[S] + L1'[S] + ... + Ln[S]</c> such that Intersection between <c>Li'</c> and <c>Li</c> is either empty or included in Li' 
    /// and the union of <c>Li</c> is equal to <c>L</c>.
    /// is equal to <c>L</c></returns>
    private static IType normalize(Labelled s, ISet first)
    {
      //The algorithm works as follows:
      //the set "labels" contains the set of labels to normalize. Initially it
      //contains the labels of "s". Then, for each label "Li" in "first"
      //each label "L" in labels it is rewritten as "L\Li" and "L^Li" (^ is the
      //Intersection). 
      ISet labels = new ArraySet();
      labels.Add(s.Labels);
      for (int j = 0; j < first.Count; j++)
      {
        ISet normalizedLabels = new ArraySet();
        LabelsSet fl = (LabelsSet)first[j];
        for (int i = 0; i < labels.Count; i++)
        {
          LabelsSet ls = (LabelsSet)labels[i];
          LabelsSet diff = ls.Subtract(fl);
          if (!diff.IsEmpty()) normalizedLabels.Add(diff);
          AbstractLabelsSet inter = ls.Intersect(fl);
          if (!inter.IsEmpty()) normalizedLabels.Add(inter);
        }
        labels = normalizedLabels;
      }
      //A new schema is built
      ISet types = new ArraySet(labels.Count);
      for (int i=0; i < labels.Count; i++)
        types.Add(new Labelled((LabelsSet)labels[i], s.Content));
      return TypesOperations.Unify(types);
    }
    /// <summary>
    /// Given a sequence type <c>s</c> Filters the set of sequences <c>types</c> by erasing 
    /// those types having a top with an empty Intersection with the top of <c>s</c>
    /// </summary>
    /// <param name="s">the sequence</param>
    /// <param name="t">the set of sequence</param>
    /// <returns>a set of guarded sequences whose top has a non empty Intersection with the top of <c>s</c></returns>		
    private static ISet Filter(Sequence s, ISet types)
    {
      ISet exp = new ArraySet();
      foreach (IType u in types)
      {
        if (u.IsSequence())
        {
          Sequence t = u.AsSequence();
          if (s.Top.IsLabelled() && t.Top.IsLabelled()) 
          {
            if (!s.Top.AsLabelled().Labels.Intersect(t.Top.AsLabelled().Labels).IsEmpty()) 
              exp.Add(t);
          }
          else if (s.Top.IsInt() && t.Top.IsInt()) exp.Add(t);
          else if (s.Top.IsIntLiteral() && t.Top.IsIntLiteral()) 
          {
            if (s.Top.AsIntLiteral().Val == t.Top.AsIntLiteral().Val) 
              exp.Add(t);
          }
          else if (s.Top.IsString() && t.Top.IsString()) exp.Add(t);
          else if (s.Top.IsStringLiteral() && t.Top.IsStringLiteral()) 
          {
            if (s.Top.AsStringLiteral().Val == t.Top.AsStringLiteral().Val) 
              exp.Add(t);
          }
          else if (s.Top.IsChan() && t.Top.IsChan()) 
          {
            if (Chan.HasMoreEqCapability(s.Top.AsChan().Capability, t.Top.AsChan().Capability))
              exp.Add(t);
          }
        }
      }
      return exp;
    }
  }
}