// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.IO;
using System.Diagnostics;
using BoPi.Common;

namespace BoPi.Types
{
  public class EmptynessChecker
  { 
    private ISet eF = new ArraySet();
    /// <summary>
    /// Checks if a given type is empty. (ErrorType is not empty by definition)
    /// </summary>
    /// <param name="s">the type to check for emptiness</param>
    /// <returns>true if <c>s</c> is empty, false otherwise</returns>
    public bool IsEmpty(IType s)
    { return IsEmpty(s, new ArraySet()); }
    
    private bool IsEmpty(IType s, ISet eT)
    {
      if (s.IsBaseType()) return false;
      else if (s.IsVoid()) return false;
      else if (s.IsChan()) return false;
      else if (s.IsBottom()) return true;
      else if (s.IsErrorType()) return false;
      else if (eT.Contains(s)) return true;
      else if (eF.Contains(s)) return false;
      else 
      {
        eT.Add(s);
        bool empty = false;
        if (s.IsLabelled()) 
          empty = s.AsLabelled().Labels.IsEmpty() || 
            IsEmpty(s.AsLabelled().Content, eT);
        else if (s.IsSequence()) 
          empty = IsEmpty(s.AsSequence().Top, eT) || 
            IsEmpty(s.AsSequence().Tail, eT);
        else if (s.IsUnion()) 
          empty = IsEmpty(s.AsUnion().Fst, eT) && 
            IsEmpty(s.AsUnion().Snd, eT);
        else if (s.IsConstantTypeName()) 
          empty = IsEmpty(s.AsConstantTypeName().Entry.Type, eT);
        else Debug.Assert(false, "public static bool IsEmpty: This code should be unreacheable");
        if (!empty)
        {
          eT.Remove(s); 
          eF.Add(s);
        }
        return empty;
      }
    }
  }
}
