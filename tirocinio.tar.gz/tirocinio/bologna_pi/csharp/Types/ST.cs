// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System.Collections;
using System.Diagnostics;
using BoPi.Types;

namespace BoPi.Common
{
	public interface ISymbolTableEntry
	{
		string Name { get; }
		IType Type { get; set; }
		bool Used { get; }
		void SetUsed();
	}

	public interface ISymbolTableValueEntry : ISymbolTableEntry
	{
		int Index { get; set; }
		bool Fresh { get; set; }
	}

	public interface ISymbolTableTypeEntry : ISymbolTableEntry
	{ 
    string FreshName {get; set; }
  }

	public abstract class AbstractSymbolTableEntry
	{
		private readonly string name;
		private IType type;
		private bool used;

		public AbstractSymbolTableEntry(string name, IType type)
		{
			this.name = name;
			this.type = type;
			this.used = false;
		}

		public string Name { get { return this.name; } }

		public IType Type {
			get { return this.type; }
			set { this.type = value; }
		}

		public bool Used { get { return this.used; } }

		public void SetUsed()
		{ this.used = true; }
	}

	public class SymbolTableValueEntry : AbstractSymbolTableEntry, ISymbolTableValueEntry
	{
		private int index;
		private bool fresh;

		public int Index {
			get { return index; }
			set { index = value; }
		}

		public bool Fresh {
			get { return fresh; }
			set { fresh = value; }
		}

		public SymbolTableValueEntry(string name, IType type) : base(name, type)
		{ 
			index = -1;
			fresh = false;
		}
	}

	public class SymbolTableTypeEntry : AbstractSymbolTableEntry, ISymbolTableTypeEntry
	{
    private string freshName;

		public SymbolTableTypeEntry(string name, IType type) : base(name, type)
		{ }
    
    public string FreshName 
    {
      get { return freshName; }
      set { freshName = value; }
    }
	}

	public class ST
	{
		private readonly Hashtable table;
		private readonly Stack envStack;

		protected class Bucket
		{
			public readonly string name;
			public Binding current;
	
			public Bucket(string name)
			{
				this.name = name;
				this.current = null;
			}
		}

		protected class Binding
		{
			public readonly Bucket bucket;
			public readonly ISymbolTableEntry entry;
			public readonly Binding previous;

			public Binding(Bucket bucket, ISymbolTableEntry entry, Binding previous)
			{
				this.bucket = bucket;
				this.entry = entry;
				this.previous = previous;
			}
		}

		protected class Environment
		{
			public ArrayList bindings = new ArrayList();

			public bool Has(string name)
			{
				foreach (Binding binding in bindings)
					if (binding.bucket.name == name)
						return true;
				return false;
			}
		}

		public ST()
		{
			this.table = new Hashtable();
			this.envStack = new Stack();
			this.envStack.Push(new Environment());
		}

		protected Bucket GetBucket(string name)
		{
			if (table.ContainsKey(name))
				return (Bucket) table[name];
			else {
				Bucket bucket = new Bucket(name);
				table.Add(name, bucket);
				return bucket;
			}
		}

		protected Environment Top {
			get {
				Debug.Assert(envStack.Count > 0);
				return (Environment) envStack.Peek();
			}
		}

		protected void New(Bucket bucket, ISymbolTableEntry entry)
		{
			Environment env = Top;
			Binding binding = new Binding(bucket, entry, bucket.current);
			env.bindings.Add(binding);
			bucket.current = binding;
		}

		public virtual void Enter()
		{
			this.envStack.Push(new Environment());
		}

		public virtual ArrayList Exit()
		{
			ArrayList entries = new ArrayList();
			foreach (Binding binding in Top.bindings) {
				entries.Add(binding.entry);
				binding.bucket.current = binding.previous;
			}
			this.envStack.Pop();
			return entries;
		}

		public virtual ISymbolTableEntry Lookup(string name)
		{
			Bucket bucket = GetBucket(name);
			if (bucket.current != null) {
				if (bucket.current.entry != null)
					bucket.current.entry.SetUsed();
				return bucket.current.entry;
			} else
				return null;
		}

		public virtual bool Clash(string name)
		{ return Top.Has(name); }
	}

	public class ValueSymbolTable : ST
	{
		public virtual ISymbolTableValueEntry New(string name, IType type)
		{
			ISymbolTableValueEntry entry = new SymbolTableValueEntry(name, type);
			New(GetBucket(name), entry);
			return entry;
		}
	}

	public class TypeSymbolTable : ST
	{
		public virtual ISymbolTableTypeEntry New(string name, IType type)
		{
			ISymbolTableTypeEntry entry = new SymbolTableTypeEntry(name, type);
			New(GetBucket(name), entry);
			return entry;
		}
	}
}
