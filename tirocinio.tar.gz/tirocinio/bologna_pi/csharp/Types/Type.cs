// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using BoPi.Common;
using System.Xml;

namespace BoPi.Types
{
  public abstract class Type: IType 
  {	
    public virtual IntType AsInt()
    { 
      throw new ApplicationException(this + " is not Int");
    }
    public virtual StringType AsString()
    { 
      throw new ApplicationException(this + " is not String");
    }
    public virtual IntLiteral AsIntLiteral()
    { 
      throw new ApplicationException(this + " is not IntLiteral");
    }
    public virtual StringLiteral AsStringLiteral()
    { 
      throw new ApplicationException(this + " is not StringLiteral");
    }
    public virtual Labelled AsLabelled()
    { 
      throw new ApplicationException(this + " is not Labelled");
    }
    public virtual Sequence AsSequence()
    { 
      throw new ApplicationException(this + " is not Sequence");
    }
    public virtual Union AsUnion()
    { 
      throw new ApplicationException(this + " is not Union");
    }
    public virtual ConstantTypeName AsConstantTypeName()
    { 
      throw new ApplicationException(this + " is not ConstantTypeName");
    }
    public virtual Chan AsChan()
    { 
      throw new ApplicationException(this + " is not Chan");
    }
    public virtual Void AsVoid()
    { 
      throw new ApplicationException(this + " is not Void");
    }
    public virtual Bottom AsBottom()
    { 
      throw new ApplicationException(this + " is not Bottom");
    }
    public virtual bool IsInt()
    { 
      return false;
    }
    public virtual bool IsString()
    { 
      return false;
    }
    public virtual bool IsIntLiteral()
    { 
      return false;
    }
    public virtual bool IsStringLiteral()
    { 
      return false;
    }
    public virtual bool IsLabelled()
    { 
      return false;
    }
    public virtual bool IsSequence()
    { 
      return false;
    }
    public virtual bool IsUnion()
    { 
      return false;
    }
    public virtual bool IsConstantTypeName()
    { 
      return false;
    }
    public virtual bool IsBaseType()
    { 
      return false;
    }
    public virtual bool IsChan()
    { 
      return false;
    }
    public virtual bool IsVoid()
    { 
      return false;
    }
    public virtual bool IsBottom()
    { 
      return false;
    }
    public virtual bool IsErrorType()
    { 
      return false;
    }
    public abstract override bool Equals(Object obj);
    public abstract override int GetHashCode();
    public abstract override String ToString();
    public abstract void Compile(XmlWriter xml);
		public virtual void ResolveNames(TypeSymbolTable st)
		{ }
  }
}
