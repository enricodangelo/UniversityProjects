// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using BoPi.Common;
using System.Xml;

namespace BoPi.Types
{
  ///<summary>Interface of BoPi types</summary>
  public interface IType
  {	
    bool IsInt();
    bool IsString();
    bool IsIntLiteral();
    bool IsStringLiteral();
    bool IsLabelled();
    bool IsSequence();
    bool IsUnion();
    bool IsConstantTypeName();
    bool IsBaseType();
    bool IsChan();
    bool IsVoid();
    bool IsBottom();
    bool IsErrorType();
    IntType AsInt();
    StringType AsString();
    IntLiteral AsIntLiteral();
    StringLiteral AsStringLiteral();
    Labelled AsLabelled();
    Sequence AsSequence();
    Union AsUnion();
    ConstantTypeName AsConstantTypeName();
    Chan AsChan();
    Void AsVoid();
    Bottom AsBottom();
    /// <summary>
    /// A type is equal to an object only if the object is a type having the same structure of this type 
    /// </summary>
    /// <param name="obj">the object to compare with</param>
    /// <returns></returns>
    bool Equals(Object obj);
    int GetHashCode();
    String ToString();
		void ResolveNames(TypeSymbolTable st);
    void Compile(XmlWriter xml);
  }
}
