// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using BoPi.Common;

namespace BoPi.Types 
{
  public class CorrectnessChecker
  {
    private DeterminednessChecker dc;
    public const string UNGUARDED_RECURSION = "Recursion must be guarded";    
    public const string NON_DETERMINED_CHANNEL = "Channel content must be determined";      
    public const string NON_TAIL_RECURSION = "The type is not tail recursive";
	 	public const string FOUND_ERRORTYPE = "Error in type"; 	

    public CorrectnessChecker()
    { dc = new DeterminednessChecker(); }
    
    public CorrectnessChecker(DeterminednessChecker dc)
    { this.dc = dc; }
    
    private bool IsGuarded(ConstantTypeName t)
    {
			ArraySet head = new ArraySet();
      GetTopLevelHeadEntries(t.Entry.Type, head);
			return !head.Contains(t.Entry); 
    }
    
    private bool IsTopLevelRecursive(ConstantTypeName t) {
      ArraySet tle = new ArraySet();
      GetTopLevelEntries(t.Entry.Type, tle);
			return tle.Contains(t.Entry); 
    }
    
    private bool IsTailRecursive(ConstantTypeName t)
    {
      ArraySet tail = new ArraySet();
      GetTailEntries(t.Entry.Type, tail);
      return tail.Contains(t.Entry);
    }
    
    private void GetTopLevelHeadEntries(IType s, ISet head)
    {
      if (s.IsUnion()) {
        GetTopLevelHeadEntries(s.AsUnion().Fst, head); 
        GetTopLevelHeadEntries(s.AsUnion().Snd, head); 
      }
      else if (s.IsSequence()) {
        if (IsNullable(s.AsSequence().Top)) 
          GetTopLevelHeadEntries(s.AsSequence().Tail, head); 
        GetTopLevelHeadEntries(s.AsSequence().Top, head); 
      }
      else if (s.IsConstantTypeName()) {
        if (!head.Contains(s.AsConstantTypeName().Entry)) {
          head.Add(s.AsConstantTypeName().Entry);
          GetTopLevelHeadEntries(s.AsConstantTypeName().Entry.Type, head);
        }
      }
    }

    private void GetTailEntries(IType s, ISet tail)
    {
      if (s.IsUnion()) {
        GetTailEntries(s.AsUnion().Fst, tail); 
        GetTailEntries(s.AsUnion().Snd, tail); 
      }
      else if (s.IsSequence()) {
        if (IsNullable(s.AsSequence().Tail)) 
          GetTailEntries(s.AsSequence().Top, tail); 
        GetTailEntries(s.AsSequence().Tail, tail); 
      }
      else if (s.IsConstantTypeName()) {
        if (!tail.Contains(s.AsConstantTypeName().Entry)) {
          tail.Add(s.AsConstantTypeName().Entry);
          GetTailEntries(s.AsConstantTypeName().Entry.Type, tail);
        }
      }
    }
    
		private static bool IsNullableAux(IType s, ArraySet visited)
		{
			if (s.IsVoid())
				return true;
			else if (s.IsConstantTypeName()) {
				ConstantTypeName t = s.AsConstantTypeName();
				if (visited.Contains(t.Entry))
					return false;
				else {
					visited.Add(t.Entry);
					return IsNullableAux(t.Entry.Type, visited);
				}
			} else if (s.IsUnion())
				return IsNullableAux(s.AsUnion().Fst, visited) || IsNullableAux(s.AsUnion().Snd, visited);
			else if (s.IsSequence())
				return IsNullableAux(s.AsSequence().Top, visited) && IsNullableAux(s.AsSequence().Tail, visited);
			else
				return false;
		}

		private static bool IsNullable(IType s)
		{ return IsNullableAux(s, new ArraySet()); }

    private static void GetTopLevelEntries(IType s, ISet visited) 
    {
      if (s.IsConstantTypeName()) {
				ConstantTypeName t = s.AsConstantTypeName();
				if (!visited.Contains(t.Entry)){
					visited.Add(t.Entry);
					GetTopLevelEntries(t.Entry.Type, visited);
				}
      } else if (s.IsUnion()) {
        GetTopLevelEntries(s.AsUnion().Fst, visited);
        GetTopLevelEntries(s.AsUnion().Snd, visited);
      } else if (s.IsSequence()) {
				GetTopLevelEntries(s.AsSequence().Tail, visited);
				GetTopLevelEntries(s.AsSequence().Top, visited);
      }
    }
    /// <summary>
    /// A type is correct if and only if both the following conditions hold: 
    /// 1. every recursion is guarded (e.g. A = A and A = B when B = A are not correct)
    /// 2. the content of every channel schema is determined
    /// </summary>
    /// <param name="s">the type to check for correctness</param>
    /// <param name="error">if the method returns false error message contains either 
    /// UNGUARDED_RECURSION or NON_DETERMINED_CHANNEL dependig on the error found.</param>
    /// <returns>true if the type is correct, false otherwise</returns>
    public bool IsCorrect(IType s,  out String error)
    { return IsCorrect(s, new ArraySet(), out error); }

    private bool IsCorrect(IType s, ISet cor, out String error)
    {
      error = "";
      if (cor.Contains(s)) return true;
      else 
      {
        bool res = true;
        cor.Add(s);
        if (s.IsChan())
        {
          res = dc.IsDetermined(s.AsChan().Carried);
          if (!res) error = NON_DETERMINED_CHANNEL;
          else res = IsCorrect(s.AsChan().Carried, cor, out error);
        }
        else if (s.IsLabelled())
          res = IsCorrect(s.AsLabelled().Content, cor, out error);
        else if (s.IsSequence())
          res = IsCorrect(s.AsSequence().Top, cor, out error) &&
            IsCorrect(s.AsSequence().Tail, cor, out error);
        else if (s.IsUnion())
          res = IsCorrect(s.AsUnion().Fst, cor, out error) &&
            IsCorrect(s.AsUnion().Snd, cor, out error);
        else if (s.IsConstantTypeName())
        {
          res = IsGuarded(s.AsConstantTypeName());
          if (!res)
            error = UNGUARDED_RECURSION;
          else {
            res = !(IsTopLevelRecursive(s.AsConstantTypeName()) && !IsTailRecursive(s.AsConstantTypeName()));
            if (!res) error = NON_TAIL_RECURSION;
            else res = IsCorrect(s.AsConstantTypeName().Entry.Type, cor, out error);
          }
        } 
        else if (s.IsVoid() || s.IsBottom() || s.IsBaseType())
          res = true;
        else if (s.IsErrorType()){
					error = FOUND_ERRORTYPE;
          res = false;
	      }
        if (!res) cor.Remove(s);
        return res;
      }
    }
  }
}
