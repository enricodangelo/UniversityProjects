// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.IO;
using System.Net;
using System.Xml;
using System.Text.RegularExpressions;
using System.Diagnostics;
using BoPi.Common;

namespace BoPi.Types
{
  class Tester
  {
    static internal void Determinednesstests()
    {
      Console.WriteLine("Testing Determinedness");
      DeterminednessChecker dc = new DeterminednessChecker();
      if (!dc.IsDetermined(new IntType())) Console.WriteLine("NOTOK1");
      else Console.WriteLine("OK1");
      if (!dc.IsDetermined(new Union(new IntType(), new StringType()))) Console.WriteLine("NOTOK2");
      else Console.WriteLine("OK2");
      if (!dc.IsDetermined(new Union(new IntType(), new Union(new StringType(), new Labelled(new AnyLabel(), new Void())))))
        Console.WriteLine("NOTOK3");
      else Console.WriteLine("OK3");
      if (dc.IsDetermined(new Union(new IntType(), new Union(new Labelled(new UnionLabel("a"), new Void()), new Labelled(new AnyLabel(), new Void())))))
        Console.WriteLine("NOTOK3");
      else Console.WriteLine("OK3");
    }
    static internal void Intersectiontests()
    {
      Console.WriteLine("Testing Intersection");
      ITypeChecker tc = new TypeChecker();
      TypeSymbolTable defs = new TypeSymbolTable();
      IType int1;

      //test
      IType intlist = new Union(new Sequence(new IntType(), new ConstantTypeName("IntList")), new Void());
      IType i5list = new Union(new Sequence(new IntLiteral(5), new ConstantTypeName("I5List")), new Void());
      defs.New("IntList", intlist);
      defs.New("I5List", i5list);
      intlist.ResolveNames(defs);
      i5list.ResolveNames(defs);
      int1 = TypesOperations.Intersect(intlist, i5list);
      if (!tc.IsSubtype(int1, intlist) || !tc.IsSubtype(int1, i5list))
        Console.WriteLine("An Intersection must be a subtype of its operands");
      else Console.WriteLine("OK1");

      //test
      IType int2list = new Union(
        new Sequence(new IntType(), 
        new Sequence(new IntType(), new ConstantTypeName("Int2List"))), new Void());
      IType int3list = new Union(
        new Sequence(new IntType(), 
        new Sequence(new IntType(), 
        new Sequence(new IntType(), new ConstantTypeName("Int3List")))), new Void());
      defs.New("Int2List", int2list);
      defs.New("Int3List", int3list);
      int2list.ResolveNames(defs);
      int3list.ResolveNames(defs);
      int1 = TypesOperations.Intersect(int2list, int3list);
      if (!tc.IsSubtype(int1, int2list) || !tc.IsSubtype(int1, int3list))
        Console.WriteLine("An Intersection must be a subtype of its operands");
      else Console.WriteLine("OK2");

      //test
      IType intlistchano = new Chan(intlist, Chan.CAPABILITY.OUT);
      IType i5listchano = new Chan(i5list, Chan.CAPABILITY.OUT);
      int1 = TypesOperations.Intersect(intlistchano, i5listchano);
      if (!tc.IsSubtype(int1, intlistchano) || !tc.IsSubtype(int1, i5listchano))
        Console.WriteLine("An Intersection must be a subtype of its operands");
      else Console.WriteLine("OK3");
      //test
      IType intlistchani = new Chan(intlist, Chan.CAPABILITY.IN);
      IType i5listchani = new Chan(i5list, Chan.CAPABILITY.IN);
      int1 = TypesOperations.Intersect(intlistchani, i5listchani);
      if (!tc.IsSubtype(int1, intlistchani) || !tc.IsSubtype(int1, i5listchani))
        Console.WriteLine("An Intersection must be a subtype of its operands");
      else Console.WriteLine("OK4");
      //test
      IType intlistchanio = new Chan(intlist, Chan.CAPABILITY.INOUT);
      IType int5listchanio = new Chan(i5list, Chan.CAPABILITY.INOUT);
      int1 = TypesOperations.Intersect(intlistchanio, int5listchanio);
      if (!tc.IsSubtype(int1, intlistchanio) || !tc.IsSubtype(int1, int5listchanio)) 
        Console.WriteLine("An Intersection must be a subtype of its operands");
      else Console.WriteLine("OK5");
      IType c1 = new Chan(new IntType(), Chan.CAPABILITY.OUT);
      IType c1s = new Sequence(new Chan(new IntLiteral(5), Chan.CAPABILITY.OUT), new Void());
      int1 = TypesOperations.Intersect(c1,c1s);
      if (!tc.IsSubtype(int1, c1) || !tc.IsSubtype(int1, c1s))
        Console.WriteLine("An Intersection must be a subtype of its operands");
      else Console.WriteLine("OK6");
      //test
      Sequence seq1 = new Sequence(new Labelled(new AnyLabel(), new IntType()), new IntType());
      Sequence seq2 = new Sequence(new Labelled(new UnionLabel("a"), new StringType()), new StringType());
      IType nd1o = new Chan(seq1, Chan.CAPABILITY.OUT);
      IType nd2o = new Chan(seq2, Chan.CAPABILITY.OUT);
      int1 = TypesOperations.Intersect(nd1o, nd2o);
      if (!tc.IsSubtype(int1, nd1o) || !tc.IsSubtype(int1, nd2o))
        Console.WriteLine("An Intersection must be a subtype of its operands");
      else Console.WriteLine("OK7");
      //test
      seq1 = new Sequence(new Labelled(new DifferenceLabel(new UnionLabel("a")), new IntType()), new IntType());
      Sequence seq3 = new Sequence(new Labelled(new UnionLabel("a"), new StringType()), new StringType());
      Sequence seq4 = new Sequence(new Labelled(new UnionLabel("b"), new StringType()), new StringType());
      IType nd3o = new Chan(new Union(seq1,seq3), Chan.CAPABILITY.OUT);
      IType nd4o = new Chan(new Union(seq2,seq4), Chan.CAPABILITY.OUT);
      int1 = TypesOperations.Intersect(nd3o, nd4o);
      if (!tc.IsSubtype(int1, nd3o) || !tc.IsSubtype(int1, nd4o)) 
      {
        Console.Write("nd3o=" + nd3o.ToString());
        Console.Write(" x nd4o=" + nd4o.ToString());
        Console.WriteLine("=" + int1);
        if (int1.IsConstantTypeName()) Console.Write("=" + int1.AsConstantTypeName().Entry.Type.ToString());
        Console.WriteLine("An Intersection must be a subtype of its operands");
      }
      else Console.WriteLine("OK8");
    }
    static internal void Subtypingtests()
    {
      Console.WriteLine("Testing subtyping");
      ITypeChecker tc = new TypeChecker();

      TypeSymbolTable defs = new TypeSymbolTable();
      IType any = new ConstantTypeName("any");
      IType seq1= new Sequence(new IntType(), any);
      IType seq2= new Sequence(new StringType(), any);
      IType seq3= new Sequence(new Labelled(new AnyLabel(),any), any);
      IType anydef = new Union(seq1, new Union(seq2,new Union(seq3, new Void())));
      defs.New("any", anydef);
      any.ResolveNames(defs);

      if (tc.IsSubtype(new Chan(any, Chan.CAPABILITY.INOUT),new Chan(any, Chan.CAPABILITY.IN)))
        Console.WriteLine("OK0");
      else Console.WriteLine("NOOK0");
      
      IType U = new ConstantTypeName("U");
      IType seq4 = new Union(new Sequence(new Labelled(new UnionLabel("a"), new Void()), new Sequence(new Labelled(new UnionLabel("a"), new Void()), U)), new Void());
      IType V = new ConstantTypeName("V");
      IType seq5 = new Union(new Sequence(new Labelled(new UnionLabel("a"), new Void()), new Sequence(new Labelled(new UnionLabel("a"), new Void()), new Sequence(new Labelled(new UnionLabel("a") , new Void()), V))), new Void());
      defs.New("U",seq4);
      defs.New("V",seq5);
      U.ResolveNames(defs);
      V.ResolveNames(defs);
      if (!tc.IsSubtype(U, V)) 
        Console.WriteLine("OK1");
      else Console.WriteLine("NOOK1");
      if (!tc.IsSubtype(V, U)) 
        Console.WriteLine("OK2");
      else Console.WriteLine("NOOK2");
      ISet single = new ArraySet();
      single.Add("val");
      LabelsSet l = new UnionLabel(single);
      IType val = new Sequence(new Labelled(l,new IntType()), new Labelled(l, new IntType()));
      if (tc.IsSubtype(val, any)) 
        Console.WriteLine("OK3");
      else Console.WriteLine("NOOK3");
      if (tc.IsSubtype(new IntType(), any)) 
        Console.WriteLine("OK4");
      else Console.WriteLine("NOOK4");
      if (tc.IsSubtype(new StringType(), any)) 
        Console.WriteLine("OK5");
      else Console.WriteLine("NOOK5");
      if (tc.IsSubtype(new Void(), any)) 
        Console.WriteLine("OK6");
      else Console.WriteLine("NOOK6");
      if (tc.IsSubtype(new Labelled(new AnyLabel(), new Union(new IntType(), new StringType())), 
        new Union(new Labelled(new AnyLabel(), new IntType()), new Labelled(new AnyLabel(),new StringType())))) 
        Console.WriteLine("OK7");
      else Console.WriteLine("NOOK7");
      if (tc.IsSubtype(new Labelled(l, new Union(new IntType(), new StringType())), 
        new Union(new Labelled(l, new IntType()), new Labelled(l,new StringType())))) 
        Console.WriteLine("OK8");
      else Console.WriteLine("NOOK8");

      //test
      //<int+string>^o, int+string <: <int>^o,int + <string>^o,string //this test will not work because unions starting with channels are considered determined
      IType s = new Sequence(new Chan(new Union(new IntType(), new StringType()), Chan.CAPABILITY.OUT), new Union(new IntType(), new StringType()));
      IType t = new Union(new Sequence(new Chan(new IntType(), Chan.CAPABILITY.OUT),new IntType()), new Sequence(new Chan(new StringType(), Chan.CAPABILITY.OUT),new StringType()));
      if (!tc.IsSubtype(s, t))
        Console.WriteLine("NOOK9 " + s + " <: "+ t);
      else Console.WriteLine("OK9");
      if (tc.IsSubtype(t, s))
        Console.WriteLine("NOOK10");
      else Console.WriteLine("OK10");
      IType c1 = new Chan(new IntType(), Chan.CAPABILITY.OUT);
      IType c1s = new Sequence(new Chan(new IntLiteral(5), Chan.CAPABILITY.OUT), new Void());
      if (!tc.IsSubtype(c1, c1s))
        Console.WriteLine("NOOK11");
      else Console.WriteLine("OK11");
      if (tc.IsSubtype(c1s, c1))
        Console.WriteLine("NOOK12");
      else Console.WriteLine("OK12");
    }

    /// <summary>
    /// ...
    /// </summary>
    [STAThread]
    static void Main(string[] args)
    {
      Subtypingtests();
      Intersectiontests(); 
      Determinednesstests();
      Console.ReadLine();
    }
  }
}