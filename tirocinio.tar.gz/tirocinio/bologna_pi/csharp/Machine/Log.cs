using System;
using System.IO;
using System.Xml;

namespace BoPi.Machine
{
	public abstract class Log : ILog
	{
		public int logLevel;
		public StreamWriter streamWriter;
		
		public Log(int logLevel)
		{
			this.logLevel = logLevel;
		}

		/*Write a log message to the log locaton
		 *PiDuce commands recognized are:
		 * - import
		 * - new
		 * - spawn
		 * - join-select
		 * - match
		 * - send
		 * - receive
		 * - service 
		 */
		public virtual void WriteLog(uint id, XmlElement xe, Env env)
		{
			try
			{
				string op = xe.LocalName;
				string msg;

				if (logLevel > 0) {	//logLevel == 1
					if (op == "send") {
						int ch = Int32.Parse(xe.GetAttribute("ch"));
						string chname = xe.GetAttribute("ch-name");
						msg = "[TID: " + id + "] " + "SEND:\n" +
							"\tchannel = " + env.Get(ch) + "\n" +
							"\tchannel name = " + chname;
						
						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
					else if (op == "receive") {
						int ch = Int32.Parse(xe.GetAttribute("ch"));
						string chname = xe.GetAttribute("ch-name");
						msg = "[TID: " + id + "] " + "RECEIVE:\n" +
							"\tchannel = " + env.Get(ch) + "\n" +
							"\tchannel name = " + chname;
						
						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
					/* command no more present
					else if (op == "select") {
						msg = "[" + id + "]: " + "select " + jmpto + " " + location;
						
						Console.WriteLine(msg);
						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
					*/
					else if (op == "join-select") {
						string service = xe.GetAttribute("service");
						XmlNodeList childNodes = xe.ChildNodes;
						XmlNodeList channels = null;
						msg = "[TID: " + id + "] " + "JOIN-SELECT:\n" +
							"\tservice = " + service;

						for (int i = 0; i < childNodes.Count; i++) {
							if (childNodes[i].Name == "channels") {
								channels = childNodes[i].ChildNodes;
							}
						}
						for (int i = 0; i < channels.Count; i++) {
							msg = String.Concat(msg, "\n\tchannel = " + env.Get(Int32.Parse(((XmlElement)channels[i]).GetAttribute("ch"))));
							msg = String.Concat(msg, "\n\tchannel name = " + ((XmlElement)channels[i]).GetAttribute("ch-name"));
						}
						
						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
					else if (op == "service") {
						int ch = Int32.Parse(xe.GetAttribute("ch"));
						string chname = xe.GetAttribute("ch-name");
						msg = "[TID: " + id + "] " + "SERVICE:\n" +
							"\tchannel = " + env.Get(ch) + "\n" +
							"\tchannel name = " + chname;
						
						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
				}

				if (logLevel > 1) {	//logLevel == 2
					if (op == "import") {
						int target = Int32.Parse(xe.GetAttribute("target"));
						string location = xe.GetAttribute("location");
						string wsdl = xe.GetAttribute("wsdl");
						XmlElement childNode = (XmlElement)xe.ChildNodes[0];
						string capability = childNode.GetAttribute("capability");
						
						msg = "[TID: " + id + "] " + "IMPORT:\n" +
							"\ttarget = " + target + "\n" +
							"\tlocation = " + location + "\n" +
							"\tWSDL = " + wsdl + "\n" +
							"\tcapability = " + capability;

						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
					/*
					if (op == "import") {
						int target = Int32.Parse(xe.GetAttribute("target"));
						string location = xe.GetAttribute("location");
						string wsdl = xe.GetAttribute("wsdl");;
						string capability = xe.GetAttribute("capability");
						
						msg = "[TID: " + id + "] " + "IMPORT:\n" +
							"\ttarget = " + env.Get(target) + "\n" +
							"\tlocation = " + location + "\n" +
							"\tWSDL = " + wsdl + "\n" +
							"\tcapability = " + capability;
						
						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
					*/
					else if (op == "new") {
						int target = Int32.Parse(xe.GetAttribute("target"));
						string targetname = xe.GetAttribute("target-name");
						string location = xe.GetAttribute("location");
						string capability = "";

						XmlNodeList chan = xe.ChildNodes;
						for (int i = 0; i < chan.Count; i++) {
							if (chan[i].Name == "chan") {
								capability = ((XmlElement)chan[i]).GetAttribute("capability");;
							}
						}

						msg = "[TID: " + id + "] " + "NEW:\n" +
							"\ttarget = " + env.Get(target) + "\n" +
							"\ttarget name = " + targetname + "\n";

						
						if (location != "") {
							msg += "\tlocation = " + location + "\n";
						}

						msg += "\tcapability = " + capability;

						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
				}
				
				if (logLevel > 2) {	//logLevel == 3
					if (op == "spawn") {
						string parentenvsize = xe.GetAttribute("parent-env-size");;
						string localenvsize = xe.GetAttribute("local-env-size");
						msg = "[TID: " + id + "] " + "SPAWN:\n" +
							"\tparent env size = " + parentenvsize + "\n" +
							"\tlocal env size = " + localenvsize;
						
						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
					else if (op == "store") {
						int target = Int32.Parse(xe.GetAttribute("target"));
						msg = "[TID: " + id + "] " + "STORE\n" + 
							"\ttarget = " + env.Get(target);
						
						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
					else if (op == "match") {
						msg = "[TID: " + id + "] " + "MATCH";
						
						this.streamWriter.WriteLine(msg);
						this.streamWriter.Flush();
						return;
					}
				}
			}
			
			catch (System.IO.IOException e)
			{
				this.logLevel = 0;
			}
			
			catch (Exception e)
			{
				Console.WriteLine("Error writing to log location.");
				Console.WriteLine(e.ToString());
			}
		}

		public abstract void CloseStream();
	}
}
