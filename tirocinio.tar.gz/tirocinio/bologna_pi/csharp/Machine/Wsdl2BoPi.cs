// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Xml;
using System.Collections;
using System.Xml.Schema;
using BoPi.Machine;
using BoPi.Types;
using BoPi.Common;

namespace BoPi.wsdlgest
{
	public class Wsdl2BoPi
	{
		TypeSymbolTable typedefs = new TypeSymbolTable();
		int nextFreshIndex = 0;

		XmlNamespaceManager nsmgr;
		XmlDocument wsdl;
		String schemaprefix;
		String targetprefix;
		String extprefix;
		String extwsdlprefix;
		String tnsuri;

		public Wsdl2BoPi(String wsdlptr)
		{
			wsdl = new XmlDocument();
			wsdl.LoadXml(wsdlptr);
			nsmgr = new XmlNamespaceManager(wsdl.NameTable);
			nsmgr.AddNamespace("w","http://schemas.xmlsoap.org/wsdl/");	
			nsmgr.AddNamespace("xsd","http://www.w3.org/2001/XMLSchema");
			nsmgr.AddNamespace("ext","http://www.cs.unibo.it/BoPi/extended");
			nsmgr.AddNamespace("extw","http://www.cs.unibo.it/BoPi/extendedwsdl");
			tnsuri=wsdl.SelectSingleNode("w:definitions/@targetNamespace",nsmgr).Value;
			nsmgr.AddNamespace("tns",tnsuri);
			nsmgr.AddNamespace("soap","http://schemas.xmlsoap.org/wsdl/soap/");
			/*get schema prefix for identifing node type xsd:int*/
			//TODO CASE WHEN TARGETNAMESPACE OF SCHEMA IS DIFFERENT FROM WSDL
			schemaprefix="";
			foreach (XmlNode node in wsdl.SelectSingleNode("w:definitions",nsmgr).Attributes)
			{
				if (node.Value=="http://www.w3.org/2001/XMLSchema")
					schemaprefix=node.LocalName;
				if (node.Value=="http://www.cs.unibo.it/BoPi/extended") extprefix=node.LocalName;
				if (node.Value=="http://www.cs.unibo.it/BoPi/extendedwsdl") extwsdlprefix=node.LocalName;
				if ((node.Value==tnsuri) && (node.Name!="targetNamespace"))
					targetprefix=node.LocalName;
			}
			if (schemaprefix==null) throw new wsdlException("unable to locate schema namespace");
			if (schemaprefix!="") schemaprefix+=":";
            if (targetprefix==null) throw new wsdlException("unable to locate target namespace");
			if (targetprefix!="") targetprefix+=":";
			if ((extprefix!=null) && (extprefix!="")) extprefix+=":";
			if ((extwsdlprefix!=null) && (extwsdlprefix!="")) extwsdlprefix+=":";
			/***********/
		}

		private string GetFreshName(string prefix)
		{ return prefix /*+ GetFreshName()*/; }

		private string GetFreshName()
		{ return "%" + (nextFreshIndex++).ToString(); }

		public bool isbopischema()
		{
			return (extprefix!=null);
		}

		public IType getBoPifromWsdl(out String chanlocation,out String soapaction,out String namespaceuri)
		{

			bool first=true;
			namespaceuri=tnsuri;
			String capability="";
			IType resi=null,reso=null,res=null;
			Hashtable operationstyle=new Hashtable();
			String bindingstyle="document"; //default style is document
			soapaction="";
			XmlNode service=wsdl.SelectSingleNode("w:definitions/w:service/w:port",nsmgr);
			chanlocation=service.FirstChild.Attributes["location",""].Value;
			if (service.FirstChild.FirstChild!=null) 
				capability=service.FirstChild.FirstChild.InnerText;
			service=service.Attributes["binding",""];
			XmlNode binding=wsdl.SelectSingleNode("w:definitions/w:binding/soap:binding/@style",nsmgr);
			if (binding!=null) bindingstyle=binding.Value;			
			XmlNodeList operations=wsdl.SelectNodes("w:definitions/w:binding[@name='"+service.Value.Substring(targetprefix.Length)+"']/w:operation",nsmgr);
			String bindingtype=wsdl.SelectSingleNode("w:definitions/w:binding[@name='"+service.Value.Substring(targetprefix.Length)+"']/@type",nsmgr).Value.Substring(targetprefix.Length);
			foreach (XmlNode node in operations )
			{
				if (node==operations[0])
                    soapaction=node.SelectSingleNode("soap:operation/@soapAction",nsmgr).Value;
				binding=node.SelectSingleNode("soap:operation/@style",nsmgr);
				if (binding!=null) operationstyle[node.Attributes["name",""].Value]=binding.Value;
				else operationstyle[node.Attributes["name",""].Value]=bindingstyle;		
				if (node.SelectSingleNode("//soap:body[@use!='literal']",nsmgr)!=null)
					throw new wsdlException("only literal is supported as use");
			}
			XmlNode portype= wsdl.SelectSingleNode("w:definitions/w:portType[@name='"+bindingtype+"']",nsmgr);
			XmlNode input,output;

			foreach (XmlNode node in portype.SelectNodes("w:operation",nsmgr))
			{
				input=node.SelectSingleNode("w:input/@message",nsmgr);
				if (input!=null)
					resi=getBoPifromMessage(wsdl.SelectSingleNode("w:definitions/w:message[@name='"+input.Value.Substring(targetprefix.Length)+"']",nsmgr),node.Attributes["name",""].Value,(String)operationstyle[node.Attributes["name",""].Value]);
				output=node.SelectSingleNode("w:output/@message",nsmgr);
				if (output!=null)
					reso=new XmlChan(getBoPifromMessage(wsdl.SelectSingleNode("w:definitions/w:message[@name='"+output.Value.Substring(targetprefix.Length)+"']",nsmgr),node.Attributes["name",""].Value,(String)operationstyle[node.Attributes["name",""].Value]),Chan.CAPABILITY.OUT);
				if ((input!=null) && (output!=null))
        {
          if (resi.IsVoid()) resi = reso; 
	  else
					resi= new XmlSequence(resi,reso);
        }
				else if ((input==null) && (output!=null))
					resi= reso;
				else if ((input!=null) && (output==null))
					resi= resi;
				else throw new wsdlException("No messages definited in operation");
				if (first) {first=!first;res=resi;}
				else res=new XmlUnion(resi,res);
				break;//<-------------- to raplace when add support to operation
			}					
			if ((capability=="O") || (capability==""))
        return new XmlChan(res,Chan.CAPABILITY.OUT);
			if (capability=="I")
				return new XmlChan(res,Chan.CAPABILITY.IN);
			if (capability=="IO")
				return new XmlChan(res,Chan.CAPABILITY.INOUT);
			throw new wsdlException("Invalid capability inserted");			

		}
		IType getBoPifromMessage(XmlNode message,String operationname,String style)
		{
			IType res=null,tmp=null;			
			String type;
			bool first=true;
      XmlNodeList nodes = message.SelectNodes("w:part",nsmgr); 
      if (nodes.Count == 0) 
        return new Types.Void();
      else 
      {
        foreach (XmlNode node in nodes)
        {
          if (node.Attributes["element",""] != null)
          {
            //schema element
            XmlNode next;
            if (node.Attributes["element",""].Value.StartsWith(targetprefix))
            {
              type=node.Attributes["element",""].Value.Substring(targetprefix.Length);
              next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:element[@name='"+type+"']",nsmgr);
              if (next==null)
                throw new wsdlException(type +" is not found as element definition");
              tmp=getBoPiFromSchema(next,new Hashtable(),new XmlVoid());
            }
            else if (node.Attributes["element",""].Value.StartsWith(extprefix))
            {
              type=node.Attributes["element",""].Value.Substring(extprefix.Length);
              next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[2]/xsd:element[@name='"+type+"']",nsmgr);
              if (next==null)
                throw new wsdlException(type +" is not found as element definition");
              tmp=getBoPifromSchemaext(next);
            }
            else
              throw new wsdlException("Error in the type of elment in message part");									
            
          }
          else if (node.Attributes["type",""]!=null) 
          {
            if (node.Attributes["type",""].Value.StartsWith(targetprefix))
            {
              type=node.Attributes["type",""].Value.Substring(targetprefix.Length);
              XmlNode next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:complexType[@name='"+type+"']",nsmgr);
              if (next==null)
                next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:simpleType[@name='"+type+"']",nsmgr);
              if (next==null)
                throw new wsdlException(type +" is not found as element definition");
              tmp=getBoPiFromSchema(next,new Hashtable(),new XmlVoid());
            }
            else if (node.Attributes["type",""].Value.StartsWith(extprefix))
            {
              type=node.Attributes["type",""].Value.Substring(extprefix.Length);
              XmlNode next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[2]/xsd:complexType[@name='"+type+"']",nsmgr);
              if (next==null)
                next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[2]/xsd:simpleType[@name='"+type+"']",nsmgr);
              if (next==null)
                throw new wsdlException(type +" is not found as element definition");
              tmp=getBoPifromSchemaext(next);
            }
            else if (node.Attributes["type",""].Value.StartsWith(schemaprefix))
            {
              type=node.Attributes["type",""].Value.Substring(schemaprefix.Length);
              if (type=="int")
                tmp=new XmlIntType(); 
              else if (type=="string")
                tmp=new XmlStringType(); 
              else
                throw new wsdlException(type +" is not found as type definition");
            }
            else throw new wsdlException("Error in the type of elment in message part");

          }
          else throw new wsdlException("non supportated part option for message "+message.Attributes["name",""].Value);
          if (style=="rpc")
            tmp=new XmlLabelled(new Types.UnionLabel(operationname),tmp);
          if (first)
          {
            res=tmp;
            first=!first;
          }
          else
          {
            res= new XmlSequence(res,tmp);
          }	
        }
        return res;
      }
		}
      
		private IType getBoPiFromSchema(XmlNode currentnode, Hashtable visited,IType prectype)
		{
			String minoccurs="",maxoccurs="";
			if (currentnode==null) return new XmlVoid(); //void i think
			getoccurs(currentnode,ref minoccurs,ref maxoccurs);
			if (currentnode.NamespaceURI!="http://www.w3.org/2001/XMLSchema") 
				throw new wsdlException("non supported schema");
			else if (currentnode.LocalName=="complexType") 
			{
				return getBoPiFromSchema(currentnode.FirstChild,visited,new XmlVoid());
			}
			else if (currentnode.LocalName=="simpleType") 
			{
				/*in bopi is allowed only this pattern for symple type
				 * <xsd:simpleType>
				 *		<xsd:restriction base="xsd:int"|"xsd:string" >
				 *			<xsd:enumaration value="n"/>
				 *		</xsd:restriction>
				 * </xsd:simpleType>
				 * */
				if (currentnode.SelectNodes("xsd:restriction[(@base='"+schemaprefix+"int') or  (@base='"+schemaprefix+"string')]/xsd:enumeration",nsmgr).Count!=1)
					throw new wsdlException("non supported simpletype schema");
				String litvalue=currentnode.FirstChild.Attributes["base",""].Value.Substring(schemaprefix.Length);
				if (litvalue=="int") 
					return new XmlIntLiteral(Int32.Parse(currentnode.SelectSingleNode("xsd:restriction[@base='"+schemaprefix+"int']/xsd:enumeration/@value",nsmgr).Value));
				else 
					return new XmlStringLiteral(currentnode.SelectSingleNode("xsd:restriction[@base='"+schemaprefix+"string']/xsd:enumeration/@value",nsmgr).Value);

			}
			else if (currentnode.LocalName=="element")
			{
				IType el;
				if (currentnode.Attributes["type",""]!=null)
				{
					if (currentnode.FirstChild!=null)
						throw new wsdlException(currentnode.Name+" is an incorrect type definition");
					if (currentnode.Attributes["type",""].Value.StartsWith(schemaprefix))
					{
						//return a labelled of int or  string
						if (currentnode.Attributes["type",""].Value==schemaprefix+"int")
							el= new XmlLabelled(new Types.UnionLabel(currentnode.Attributes["name",""].Value),new XmlIntType());
						else if  (currentnode.Attributes["type",""].Value==schemaprefix+"string")
							el= new XmlLabelled(new Types.UnionLabel(currentnode.Attributes["name",""].Value),new XmlStringType());
						else throw new wsdlException(currentnode.Attributes["type",""].Value+" is not a supportated type");						
						
					}
					else if (currentnode.Attributes["type",""].Value.StartsWith(targetprefix))
					{
						//insert a lebeled 
						String type=currentnode.Attributes["type",""].Value.Substring(targetprefix.Length);
						XmlNode next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:complexType[@name='"+type+"']",nsmgr);
						if (next==null)
							next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:simpleType[@name='"+type+"']",nsmgr);
						if (next==null)
							throw new wsdlException(type +" is not found as type definition");
						//i need to know in advance if the type is recursive so i add it in the st as new schema
						if (isrecursivetype(next,new ArrayList()))
						{
							//vedere di ottimizzare molto complesso 
							String typeofschema = GetFreshName(currentnode.Attributes["type",""].Value.Substring(targetprefix.Length));
							if (visited.Contains(typeofschema))
								el = new XmlLabelled(new Types.UnionLabel(currentnode.Attributes["name",""].Value),
																		 new XmlConstantTypeName(typeofschema, (ISymbolTableTypeEntry) visited[typeofschema]));
							else {
								ISymbolTableTypeEntry entry = typedefs.New(typeofschema, null);
								visited.Add(typeofschema, entry);
								el = new XmlLabelled(new Types.UnionLabel(currentnode.Attributes["name",""].Value),
																		 new XmlConstantTypeName(typeofschema, entry));
								IType t = getBoPiFromSchema(next,visited,prectype);
								entry.Type = t;
							}
						}
						else
							//pu� partire da zero in quanto sta dentro una label
							el=new XmlLabelled(new Types.UnionLabel(currentnode.Attributes["name",""].Value),getBoPiFromSchema(next,visited,new XmlVoid()));
					}
					else 						
						throw new wsdlException(currentnode.Attributes["type",""].Value+ "unknow type");
					return sequencecostruct(typedefs,el,prectype,minoccurs,maxoccurs);
				} else if (currentnode.Attributes["ref",""]!=null) {
					String name;
					XmlNode next;
					IType type;
					if (currentnode.Attributes["ref",""].Value.StartsWith(targetprefix))
					{
						name=currentnode.Attributes["ref",""].Value.Substring(targetprefix.Length);
            next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:element[@name='"+name+"']",nsmgr);
						type=getBoPiFromSchema(next,visited,new XmlVoid());
						return sequencecostruct(typedefs,type,prectype,minoccurs,maxoccurs);
					}
					else if (currentnode.Attributes["ref",""].Value.StartsWith(extprefix))
					{
						name=currentnode.Attributes["ref",""].Value.Substring(extprefix.Length);
						next=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[2]/xsd:element[@name='"+name+"']",nsmgr);
						type=getBoPifromSchemaext(next,visited);
						return sequencecostruct(typedefs,type,prectype,"1","1");
					}
					else throw new wsdlException("Unsupportaded prefix in ref");					
				}
				else  
				{
					return sequencecostruct(typedefs,new XmlLabelled(new Types.UnionLabel(currentnode.Attributes["name",""].Value),getBoPiFromSchema(currentnode.FirstChild,visited,new XmlVoid())),prectype,minoccurs,maxoccurs);
				}
			}
			else if (currentnode.LocalName=="sequence")
			{
				if (currentnode.ChildNodes.Count==0)
					return new XmlVoid();
				else
				{
					//open sequence 
					IType currentype;
					XmlNode node;
					if ((minoccurs!="1") && (maxoccurs!="1"))prectype=new XmlVoid();
					for (int i=(currentnode.ChildNodes.Count-1);i>=0;i--)
					{
						node=currentnode.ChildNodes[i];
						currentype=getBoPiFromSchema(node,visited,prectype);
						prectype=currentype;
					}
					return prectype;
					//return sequencecostruct(typedefs,prectype,prectypeseq,minoccurs,maxoccurs);
				}
			}
			else if (currentnode.LocalName=="choice")
			{
				if (currentnode.ChildNodes.Count==0)
					return new XmlVoid();
				else
				{
					//open union
					IType currentype,un=null;
					foreach (XmlNode node in currentnode.ChildNodes)
					{
						currentype=getBoPiFromSchema(node,visited,prectype);
						if (node!=currentnode.FirstChild)
							un=new XmlUnion(currentype,un);
						else
							un=currentype;						
					}
//					if (!un.IsDetermined(typedefs)) throw new wsdlException("Found non deterministic definition of schema: " + un.GetType() + "- " + un.ToString());
					return un;
				}
			}
			else throw new wsdlException("usupported schema");
		}

		IType getBoPifromSchemaext(XmlNode currentnode)
		{ return getBoPifromSchemaext(currentnode, new Hashtable()); }

		IType getBoPifromSchemaext(XmlNode currentnode, Hashtable visited)
		{
			String val;
			XmlNode node;
			if (currentnode==null) return new XmlVoid(); //void i think
			if (currentnode.NamespaceURI!="http://www.w3.org/2001/XMLSchema")
				throw new wsdlException("non supported schema");
			else if (currentnode.LocalName=="element") 
			{
				if (currentnode.Attributes["name"].Value=="void")
					return new XmlVoid();
				if (currentnode.Attributes["name"].Value=="int")
					return new XmlIntType();
				if (currentnode.Attributes["name"].Value=="string")
					return new XmlStringType();
				if (currentnode.Attributes["name"].Value=="intLit")
				{
					try
					{
						return new XmlIntLiteral(Int32.Parse(currentnode.FirstChild.FirstChild.Attributes["value",""].Value));
					}
					catch (Exception){throw new wsdlException("error in int lieral type. It is not a valid integer");}
				}
				if (currentnode.Attributes["name"].Value=="stringLit")
					return new XmlStringLiteral(currentnode.FirstChild.FirstChild.Attributes["value",""].Value);
				if (currentnode.Attributes["name"].Value.StartsWith("chan_IO"))
				{
					val=currentnode.Attributes["type",""].Value;
					if (!val.StartsWith(targetprefix))
						throw new wsdlException("Error in the extended namespace");
					val=val.Substring(targetprefix.Length);
					node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:complexType[@name='"+val+"']",nsmgr);
					//useless with this implemetation of xmlchan but open at future optimization
					if (node==null)
						node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:simpleType[@name='"+val+"']",nsmgr);
					if (node==null)
						throw new wsdlException("type declaration not found "+val);
                    return new XmlChan(getBoPiFromSchema(node,visited,new XmlVoid()),2);					
				}
				if (currentnode.Attributes["name"].Value.StartsWith("chan_I"))
				{
					val=currentnode.Attributes["type",""].Value;
					if (!val.StartsWith(targetprefix))
						throw new wsdlException("Error in the extended namespace");
					val=val.Substring(targetprefix.Length);
					node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:complexType[@name='"+val+"']",nsmgr);
					//useless with this implemetation of xmlchan but open at future optimization
					if (node==null)
						node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:simpleType[@name='"+val+"']",nsmgr);
					if (node==null)
						throw new wsdlException("type declaration not found "+val);
					return new XmlChan(getBoPiFromSchema(node,visited,new XmlVoid()),-1);
				}
				if (currentnode.Attributes["name"].Value.StartsWith("chan_O"))
				{
					val=currentnode.Attributes["type",""].Value;
					if (!val.StartsWith(targetprefix))
						throw new wsdlException("Error in the extended namespace");
					val=val.Substring(targetprefix.Length);
					node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:complexType[@name='"+val+"']",nsmgr);
					//useless with this implemetation of xmlchan but open at future optimization
					if (node==null)
						node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:simpleType[@name='"+val+"']",nsmgr);
					if (node==null)
						throw new wsdlException("type declaration not found "+val);
					return new XmlChan(getBoPiFromSchema(node,visited,new XmlVoid()),1);					
				}
				if (currentnode.Attributes["name"].Value.StartsWith("anylabel"))
				{
					val=currentnode.Attributes["type",""].Value;
					if (!val.StartsWith(targetprefix))
						throw new wsdlException("Error in the extended namespace");
					val=val.Substring(targetprefix.Length);
					node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:complexType[@name='"+val+"']",nsmgr);
					//useless with this implemetation of anylabel but open at future optimization
					if (node==null)
						node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:simpleType[@name='"+val+"']",nsmgr);
					if (node==null)
						throw new wsdlException("type declaration not found "+val);
					return new XmlLabelled(new Types.AnyLabel(),getBoPiFromSchema(node,visited,new XmlVoid()));					
				}
				if (currentnode.Attributes["name"].Value.StartsWith("unionlabel"))
				{
					val="";
					ISet lab=new ArraySet();
					currentnode=currentnode.FirstChild.FirstChild; //pointer at sequence
					foreach (XmlNode child in currentnode.ChildNodes)
					{
						if (child==currentnode.FirstChild)
							val=child.Attributes["type",""].Value;
						lab.Add(child.Attributes["name",""].Value);
					}
					if (!val.StartsWith(targetprefix))
						throw new wsdlException("Error in the extended namespace");
					val=val.Substring(targetprefix.Length);
					node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:complexType[@name='"+val+"']",nsmgr);
					//useless with this implemetation of anylabel but open at future optimization
					if (node==null)
						node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:simpleType[@name='"+val+"']",nsmgr);
					if (node==null)
						throw new wsdlException("type declaration not found "+val);
					return new XmlLabelled(new Types.UnionLabel(lab),getBoPiFromSchema(node,visited,new XmlVoid()));
					 
				}

				if (currentnode.Attributes["name"].Value.StartsWith("differencelabel"))
				{
					val="";
					ISet lab=new ArraySet();
					currentnode=currentnode.FirstChild.FirstChild; //pointer at sequence
					foreach (XmlNode child in currentnode.ChildNodes)
					{
						if (child==currentnode.FirstChild)
							val=child.Attributes["type",""].Value;
						lab.Add(child.Attributes["name",""].Value);
					}
					if (!val.StartsWith(targetprefix))
						throw new wsdlException("Error in the extended namespace");
					val=val.Substring(targetprefix.Length);
					node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:complexType[@name='"+val+"']",nsmgr);
					//useless with this implemetation of anylabel but open at future optimization
					if (node==null)
						node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:simpleType[@name='"+val+"']",nsmgr);
					if (node==null)
						throw new wsdlException("type declaration not found "+val);
					return new XmlLabelled(new Types.DifferenceLabel(new Types.UnionLabel(lab)),getBoPiFromSchema(node,visited,new XmlVoid()));
					 
				}
				if (currentnode.Attributes["name"].Value.StartsWith("schema_"))
				{
					String name = GetFreshName(currentnode.Attributes["name"].Value.Substring("schema_".Length));
					val=currentnode.Attributes["type"].Value.Substring(targetprefix.Length);
					node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:complexType[@name='"+val+"']",nsmgr);
					//useless with this implemetation of anylabel but open at future optimization
					if (node==null)
						node=wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema[1]/xsd:simpleType[@name='"+val+"']",nsmgr);
					if (node==null)
						throw new wsdlException("type declaration not found "+val);

					if (visited.ContainsKey(name))
						return new XmlConstantTypeName(name, (ISymbolTableTypeEntry) visited[name]);
					else {
						ISymbolTableTypeEntry entry = typedefs.New(name, null);
						visited.Add(name, entry);
						entry.Type = getBoPiFromSchema(node, visited, new XmlVoid());
						return new XmlConstantTypeName(name, entry);
					}
				}
				throw new wsdlException("invalid element in extended schema");				
			}
			throw new wsdlException("invalid format of extended schema");
		}


		void getoccurs(XmlNode currentnode,ref String minoccurs,ref String maxoccurs)
		{
			if (currentnode.Attributes["minOccurs",""]!=null)
				minoccurs=currentnode.Attributes["minOccurs",""].Value;
			else
				minoccurs="1"; //default value i hope
			if (currentnode.Attributes["maxOccurs",""]!=null)
				maxoccurs=currentnode.Attributes["maxOccurs",""].Value;
			else
				maxoccurs=minoccurs; //default value i hope
			maxoccurs=maxoccurs.Trim();
			minoccurs=minoccurs.Trim();
		}



		void checkoccurs(ref String min,ref String max)
		{
			int imin,imax;
			try{imin=Int32.Parse(min);}
			catch(Exception){imin=1;}
			if (max!="unbounded")
			{
				try{imax=Int32.Parse(max);}
				catch(Exception){imax=1;}
				if (imin<0) imin=0;
				if (imax<0) imax=0;
				if (imin>imax)
					imax=imin;
				max=imax.ToString();
			}
			min=imin.ToString();
		}
    
		IType sequencecostruct(TypeSymbolTable t,IType schema,IType prectype,String minoccurs,String maxoccurs)
		{
			IType res;
			int imin,imax;
			checkoccurs(ref minoccurs,ref maxoccurs);
			if (schema is XmlUnion) 
			{
				XmlUnion un=(XmlUnion)schema;
				return new XmlUnion(sequencecostruct(t,un.Fst,prectype,minoccurs,maxoccurs),
					sequencecostruct(t,un.Snd,prectype,minoccurs,maxoccurs));
			}
			if (minoccurs==maxoccurs)
			{
				if (minoccurs=="0") return prectype;
				//u=S,S,......,S maxoccurs=minoccurs times
				IType seq=null;				
				try{imin=Int32.Parse(minoccurs);}
				catch(Exception){imin=1;}
				for (int i=1;i<=imin;i++)
				{
					if (i==1) seq=schema;
					else seq=new XmlSequence(schema,seq);
				}
				if (prectype is Types.Void)
					return seq;
				else
					return new XmlSequence(seq,prectype);
			}
			else if ((minoccurs=="0") && (maxoccurs=="unbounded"))
			{
				//U=void+(S,U)
				String type = GetFreshName("list");
				ISymbolTableTypeEntry entry = typedefs.New(type, null);
			  res = new XmlUnion(prectype, new XmlSequence(schema, new XmlConstantTypeName(type, entry)));				
				entry.Type = res;
				return new XmlConstantTypeName(type, entry);
			}
			else if ((minoccurs!="0") && (maxoccurs=="unbounded"))
			{
				//U=S,S,....S minoccurs times
				//U'=void+(S,U)
				//U''=U,U'
				String type;
				IType list =sequencecostruct(t,schema,prectype,"0",maxoccurs);
				IType seq=sequencecostruct(t,schema,new XmlVoid(),minoccurs,minoccurs);
				
				type = GetFreshName("listunbandoneofmin" + minoccurs);
				res = new XmlSequence(seq, list);
				ISymbolTableTypeEntry entry = typedefs.New(type, res);
				return new XmlConstantTypeName(type, entry);
			}
			else
			{
				IType acc=null,seq=null;
				try{imin=Int32.Parse(minoccurs);}
				catch(Exception){imin=1;}
				try{imax=Int32.Parse(maxoccurs);}
				catch(Exception){imax=1;}
				if (imin!=0)
					seq=sequencecostruct(t,schema,prectype,minoccurs,minoccurs);
				//U=S,S....S+(void+(S,(void+(S,......(void+S,void)))))
				for (int i=0;i<(imax-imin);i++)
				{
					if (i==0)
					{
						if (prectype is Types.Void)
							acc=new XmlUnion(prectype,schema);
						else
							acc=new XmlUnion(prectype,new XmlSequence(schema,prectype));
					}
					else
						acc=new XmlUnion(prectype,new XmlSequence(schema,acc));
				}
				if (seq!=null)
                    acc=new XmlSequence(seq,acc);
				String type = GetFreshName("minormax");
				ISymbolTableTypeEntry entry = typedefs.New(type, acc);
				return new XmlConstantTypeName(type, entry);
			}
		}

		bool isrecursivetype(XmlNode currentnode, IList visited)
		{
			bool res=false;
			String type;
			foreach (XmlNode node in currentnode.SelectNodes(".//xsd:element",nsmgr))
			{			

				if (node.Attributes["type",""]==null) res|=false;
				else if (node.Attributes["type",""].Value.StartsWith(schemaprefix)) res|=false;
				else if (node.Attributes["type",""].Value.StartsWith(targetprefix)) 
				{
					type=node.Attributes["type",""].Value.Substring(targetprefix.Length);
					if (visited.Contains(type)) return true;
					visited.Add(type);
					res|=isrecursivetype(wsdl.SelectSingleNode("w:definitions/w:types/xsd:schema/xsd:complexType[@name='"+type+"']",nsmgr),visited);
				}
			}
			return res;

		}
	}	
	class wsdlException:Exception
	{
		public wsdlException(String message):base("Parsing wsdl Exception: "+message){}
	}
}
