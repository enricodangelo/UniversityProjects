// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;

namespace BoPi.Machine
{
	public class MachineOutput
	{
		private static System.IO.TextWriter display=Console.Out;

		public static void PrintError(String error)
		{
			display .WriteLine("Error: " + error);
		}
		public static void Print(String msg)
		{
			display.WriteLine(msg);
		}

	}
}
