// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Xml;
using BoPi.Common;
using BoPi.wsdlgest;
using BoPi.Machine;
using System.Collections;
using System.Text;
using System.Threading;
using System.Text.RegularExpressions;

namespace BoPi.Web
{

  public class Webclient
  {	
    private Hashtable parseheader(String received)
    {
      String[] lines=received.Split("\n".ToCharArray());
      Hashtable res= new Hashtable();
      int start;
      foreach (String line in lines)
      {
        start=line.IndexOf(":");
        if (start==-1) continue;
        res[line.Substring(0,start)]=line.Substring(start+1);
      }
      return res;
    }


    public const string BOPI_CLIENT = "BoPi Client";

    public delegate String DownloadDelegate (string url);

    public static String Download(String url)
    {
      WebClient wc = new WebClient();
      try
      {
        wc.Headers.Add("User-Agent: " + BOPI_CLIENT);
        return System.Text.Encoding.UTF8.GetString(wc.DownloadData(url));
      }
      catch(Exception){return "";}
    }

    public delegate XmlNode UploadDelegate (String url,String data,String soapaction);

    public XmlNode Upload(String url,String data,String soapaction)
    {
      XmlNode res=null;
      Socket m_socClient= new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
      try
      {				
        int port;
        String address,location;
        if (url.StartsWith("http://"))
          url=url.Substring(7);
        else if (url.StartsWith("https://"))
          return uploadhttps(url,data,soapaction);
        int portstart=url.IndexOf(":");
        int locationstart=url.IndexOf("/");
        if (locationstart==-1) return null;
        if (portstart==-1) 
        {
          port=80;
          address=url.Substring(0,locationstart);
        }
        else
        {
          address=url.Substring(0,portstart);
          port=Int32.Parse(url.Substring(portstart+1,locationstart-portstart-1));
        }
        int size;
        byte[] buffer=System.Text.Encoding.UTF8.GetBytes(data);
        byte[] rcvbuffer= new byte[100];
        location=url.Substring(locationstart);
        IPEndPoint remoteEP = new IPEndPoint (Dns.GetHostByName(address).AddressList[0],port);
        m_socClient.Connect (remoteEP); 
        String response="";
        String request="POST "+location+" HTTP/1.1\r\n";
        request+="User-Agent: " + BOPI_CLIENT + "\r\n";
        request+="Content-Type: text/xml; charset=utf-8\r\n";
        request+="SOAPAction: "+soapaction+"\r\n";
        request+="Content-Length: "+buffer.Length+"\r\n";
        request+="Expect: 100-continue\r\n";
        request+="Connection: Keep-Alive\r\n";
        request+="Host: "+address+":"+port.ToString()+"\r\n\r\n";			
        m_socClient.Send(System.Text.Encoding.ASCII.GetBytes(request));
        m_socClient.Send(buffer);
        do
        {
          size=m_socClient.Receive(rcvbuffer);
          response+=System.Text.Encoding.UTF8.GetString(rcvbuffer,0,size);
          if ((response.StartsWith("HTTP/1.1 100 Continue")) && (response.IndexOf("\r\n\r\n")!=-1))
            response=response.Substring(response.IndexOf("\r\n\r\n")+4);
        }while ((response.IndexOf("\r\n\r\n")==-1) && (size!=0));
        Hashtable h=parseheader(response);
        int headerend=response.IndexOf("\r\n\r\n");
        if (headerend!=-1)
        {
          int contentlen=Int32.Parse((String)h["Content-Length"]);
          while (response.Length<headerend+contentlen+4)
          {
            size=m_socClient.Receive(rcvbuffer);
            response+=System.Text.Encoding.UTF8.GetString(rcvbuffer,0,size);
          }
          res = XmlUtil.RemoveSoap(response.Substring(headerend+4));	
        }			
      }
      catch (Exception e)
      {
        Console.WriteLine(e);
        res=null;
      }
      finally
      {
        m_socClient.Close();
      }
      return res;
    }

    public  XmlNode uploadhttps(String url,String data,String soapaction)
    {	
      XmlNode res=null;
      try
      {
        WebClient wc = new WebClient();
        wc.Headers.Add("User-Agent: " + BOPI_CLIENT);
        wc.Headers.Add("Content-Type: text/xml; charset=utf-8");
        wc.Headers.Add("SOAPAction: "+soapaction);
        res = XmlUtil.RemoveSoap(System.Text.Encoding.UTF8.GetString(wc.UploadData(url,"POST",System.Text.Encoding.UTF8.GetBytes(data))));
      }
      catch(WebException e)
      {			
        if (e.Status==WebExceptionStatus.UnknownError)
        {
          return Upload(url,data,soapaction);
        }
        else
          throw new ApplicationException(e.Status+"unable to send data to "+url);
      }			
      return res;
    }
  }

  public class WebServer
  {
    private static IManageOutputRequest channelManager;
    private static IScheduler scheduler;
    private static int port = 1811;
    private static string localMachine = 
      Dns.GetHostByName(Dns.GetHostName()).AddressList[0].ToString();
      //(Dns.GetHostByAddress(Dns.GetHostByName(Dns.GetHostName()).AddressList[0]).HostName.Split(' '))[0];

    private static bool keepAlive = true;
    private static ManualResetEvent allDone = new ManualResetEvent(false);

    public static int Port { get { return port;} }

    public static string GetLocalMachine()
    { return "http://" + localMachine  + ":" + port.ToString() + "/"; }

    public static void Init(IManageOutputRequest channelManager, IScheduler scheduler, int port)
    {
      WebServer.channelManager = channelManager;
      WebServer.scheduler = scheduler;
      WebServer.port = port;
    }

    public static void Stop()
    {
      keepAlive = false;
      allDone.Set();
    }

    private static Hashtable parseheader(String received)
    {
      String[] lines = received.Split("\n".ToCharArray());
      Hashtable res = new Hashtable();
      int start;
      foreach (String line in lines)
      {
        start = line.IndexOf(":");
        if (start == -1) continue;
        res[line.Substring(0,start)]=line.Substring(start+1).Trim();
      }
      return res;
    }

    // State object for reading client data asynchronously
    private class StateObject 
    {
      public StateObject(Socket handler) 
      {workSocket = handler;}
      public Socket workSocket = null;
      public const int BufferSize = 1024;
      public byte[] buffer = new byte[BufferSize];
      public StringBuilder sb = new StringBuilder();  
      public void Clean()
      {
        sb = new StringBuilder(); 
        buffer=new byte[BufferSize];
      }
    }
    
    public static void StartListening() 
    {
      IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName());
      IPAddress ipAddress = ipHostInfo.AddressList[0];
      IPEndPoint localEndPoint = new IPEndPoint(ipAddress, port);
      Socket listener = new Socket(AddressFamily.InterNetwork,
        SocketType.Stream, ProtocolType.Tcp );

      try 
      {
        listener.Bind(localEndPoint);
        listener.Listen(100);
        Console.WriteLine("The machine is waiting on " + Port);
        while (keepAlive)
        {
          allDone.Reset();
          listener.BeginAccept(new AsyncCallback(AcceptCallback), listener );
          allDone.WaitOne();
        }
        if (listener.Connected)
        { listener.Shutdown(SocketShutdown.Both); }
        listener.Close();
      } 
      catch (Exception e) 
      {
        Console.WriteLine(e.ToString());
      }
    }
    //SAMUELE every xxxCallback catches ObjectDisposedException because of the wrong method
    //Webutil.Webclient.upload which closes the connection every time also if HTTP1.1 is used.
    private static void AcceptCallback(IAsyncResult ar) 
    {
      try
      {
        allDone.Set();
        Socket listener = (Socket) ar.AsyncState;
        Socket handler = listener.EndAccept(ar);
        StateObject state = new StateObject(handler);
        handler.BeginReceive( state.buffer, 0, StateObject.BufferSize, 0,
          new AsyncCallback(ReadCallback), state);
      } 
      catch (ObjectDisposedException) {}
      catch (SocketException) {}
    }

    private static void ReadCallback(IAsyncResult ar) 
    {
      String content = String.Empty;
      // Retrieve the state object and the handler socket
      // from the asynchronous state object.
      StateObject state = (StateObject) ar.AsyncState;
      Socket handler = state.workSocket;
      try 
      {
        int bytesRead = handler.EndReceive(ar);
        if (bytesRead > 0) 
        {
          // There  might be more data, so store the data received so far.
          state.sb.Append(Encoding.ASCII.GetString(state.buffer,0,bytesRead));
          content = state.sb.ToString();
          do 
          {
            if (content.IndexOf("\r\n\r\n") > -1)
            {
              ProcessRequest(handler, content);
              // Cleans the buffer for next requests
              state.Clean();
            } 
            // Continuing with next requests or data received.
            handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
              new AsyncCallback(ReadCallback), state);
          } while (content.IndexOf("<EOF>") > -1);
        }
      } 
      catch (ObjectDisposedException) { }
      catch (SocketException) {}
    }
    
    private static void Send(Socket handler, String data) 
    {
      try
      {
        byte[] byteData = Encoding.ASCII.GetBytes(data);
        handler.BeginSend(byteData, 0, byteData.Length, 0,
          new AsyncCallback(SendCallback), handler);
      } 
      catch (ObjectDisposedException) {}
      catch (SocketException) {}
    }

    private static void SendCallback(IAsyncResult ar) 
    {
      try
      {
        Socket handler = (Socket) ar.AsyncState;
        handler.EndSend(ar);
      }
      catch (ObjectDisposedException) {}
      catch (SocketException) {}
    }
    private const string LINEARFWD_MSG = "http://cs.unibo.it/BoPi/linearforwarder";
    private const string LOADCODE_MSG = "http://cs.unibo.it/BoPi/loadcode";
    private const string ADDCHANNEL_MSG = "http://cs.unibo.it/BoPi/addchannel";

    private static void ProcessRequest(Socket m_socWorker, String received)
    {
      int endheader=received.IndexOf("\r\n\r\n");
      String responseMessage = "";
      if (endheader==-1)
        responseMessage = "HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\n\r\n";
      else 
      {
        String[] request=received.Split("\n".ToCharArray(),1);
        if (request[0].IndexOf("HTTP/")==-1)
          responseMessage = "HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\n\r\n";
        else if (received.StartsWith("POST"))
        {
          int read = received.Length;
          byte[] buffer = new byte[1024];
          String location = request[0].Substring(6,request[0].IndexOf("HTTP/")-6).Trim();
          Hashtable header = parseheader(received.Substring(0,endheader));
          try	
          {
            int contentLength = Int32.Parse((String)header["Content-Length"]);
            int requestLength = contentLength + endheader + 4;
            while (read < requestLength)
            {
              int n = m_socWorker.Receive(buffer, 0, 1024, SocketFlags.None);
              received += System.Text.Encoding.UTF8.GetString(buffer, 0, n);
              read += n;
            }
            String response = XmlUtil.AddSoap("<ok/>");
            received = received.Substring(endheader+4);
            if (((String)header["SOAPAction"])==LINEARFWD_MSG)
            {
              XmlNode lfreq = XmlUtil.RemoveSoap(received);
              MachineOutput.Print("Have received a linearforwarder's request:"+lfreq.OuterXml);
              if (channelManager.LinearForwarder(location,lfreq.FirstChild.Attributes["location"].Value,lfreq.FirstChild.Attributes["wsdl"].Value))
                responseMessage += "HTTP/1.1 200 OK\r\nContent-Type: text/xml; charset=utf-8\r\nContent-Length: "+response.Length+"\r\n\r\n"+response;
              else
                responseMessage += "HTTP/1.1 500 Errore interno del server.\r\nContent-Length: 0\r\n\r\n";
            }
            else if (((String)header["SOAPAction"])==LOADCODE_MSG)
            {
              MachineOutput.Print("Have received remote code i start loading it");

	      /* L'header X-BoPiLog è sempre presente e formato correttamente
	       * in quanto è inserito dal compilatore (BoPiCompiler).
	       * Può avere uno dei seguenti formati:
	       * X-BoPiLog: NOLOG
	       * X-BoPiLog: LOCALE ;<logFile>;<logLevel>
	       * X-BoPiLog: REMOTE ;<ipAddress>;<port>;<logLevel>
	       */
	      string logHeader=((String)header["X-BoPiLog"]);
	      Regex separator = new Regex(";");
	      string[] logHeaderFields = separator.Split(logHeader);
	      ILog log = null;
	      
	      if (logHeaderFields[0] == "REMOTE ")
	      {
		      //log to socket: header = REMOTE ;ipAddress;port;logLevel
		      string ipAddress = logHeaderFields[1];
		      int port = Int32.Parse(logHeaderFields[2]);
		      int logLevel = Int32.Parse(logHeaderFields[3]);
		      
		      log = new SocketLog(ipAddress, port, logLevel);
		     
		      try {
			      //send the bytecode
			      XmlTextReader rawBytecode = new XmlTextReader(new StringReader(XmlUtil.RemoveSoap(received).OuterXml));
			      XmlTextWriter bytecode = new XmlTextWriter(((SocketLog)log).streamWriter);
			      bytecode.Formatting = Formatting.Indented;
			      
			      bytecode.WriteNode(rawBytecode, true);	//fallisce
			      ((SocketLog)log).streamWriter.WriteLine("\nEND BYTECODE");
		      }
		      catch (System.IO.IOException e) {
			      Console.WriteLine(e.ToString());
			      Console.WriteLine("Connection closed by PiDuceApplet");
		      }
	      }
	      else if (logHeaderFields[0] == "LOCAL ")
	      {
		      //log to file: header = LOCAL ;logFile;logLevel
		      string logFile = logHeaderFields[1];
		      int logLevel = Int32.Parse(logHeaderFields[2]);
		      
		      log = new FileLog(logFile, logLevel);
	      }
	      /*If logHeaderFields[0] == NOLOG log is set to null*/
	      
	      scheduler.AddProgram(XmlUtil.RemoveSoap(received).OuterXml, log);

              responseMessage += "HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n";
            }
            else if (((String)header["SOAPAction"])==ADDCHANNEL_MSG)
            {
              MachineOutput.Print("Have received request to add channel  " + location);
              response = channelManager.AddChannel(location,XmlUtil.RemoveSoap(received).OuterXml);
              if (response=="")
                responseMessage += "HTTP/1.1 500 Errore interno del server.\r\nContent-Length: 0\r\n\r\n";
              else
              {
                response = Web.WebServer.GetLocalMachine() + response;
                response = "<newchannel xmlns=\"http://cs.unibo.it/BoPi/controlmessage\" location=\""+response+"\"/>"; 
                response = XmlUtil.AddSoap(response);					
                responseMessage += "HTTP/1.1 200 OK\r\nContent-Length: "+response.Length.ToString()+"\r\n\r\n"+response;
              }
            }				
            else //
            {
              ArrayList responsecontainer = new ArrayList();
              //MachineOutput.print("Have received "+Valueutil.getvaluefromxml(XmlUtil.RemoveSoap(received))+" for the channel "+location);
              IValue val = ValueUtil.ParseValue(XmlUtil.RemoveSoap(received));
              if (channelManager.ForeignRequest(location, val, responsecontainer))
              {
                if ((String)header["Expect"]=="100-continue")
                  responseMessage += "HTTP/1.1 100 Continue\r\n\r\n";
                lock (responsecontainer)
                {
                  //to prevent deadlock
                  if (responsecontainer.Count==0)
                    System.Threading.Monitor.Wait(responsecontainer);
                  responseMessage += "HTTP/1.1 200 OK\r\nContent-Type: text/xml; charset=utf-8\r\nContent-Length: "+((String)responsecontainer[0]).Length+"\r\n\r\n"+(String)responsecontainer[0];                                
                }
              }
              else if (channelManager.LocalOutput(location, val))
                responseMessage += "HTTP/1.1 200 OK\r\nContent-Type: text/xml; charset=utf-8\r\nContent-Length: "+response.Length+"\r\n\r\n"+response;
              else
              {
                Console.WriteLine("Error reading the Request");
                responseMessage += "HTTP/1.1 500 Errore interno del server.\r\nContent-Type: text/xml; charset=utf-8\r\nContent-Length: "+response.Length+"\r\n\r\n"+response;
              }
            }
          }
          catch (Exception e)
          {
									Console.WriteLine(e.ToString());
            responseMessage += "HTTP/1.1 400 Bad Request\r\nContent-Length:"+ e.ToString().Length + "\r\n\r\n" + e.ToString();
          }
        }
        else if (received.StartsWith("GET"))
        {
          String location=request[0].Substring(5,request[0].IndexOf("HTTP/")-5).Trim();
          if (!location.EndsWith("?wsdl"))
            responseMessage += "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n";
          else
          {
            String wsdl = channelManager.GetWsdl(location.Substring(0,location.Length-5));
            if (wsdl == "")
              responseMessage += "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n";
            else
              responseMessage += "HTTP/1.1 200 OK\r\nContent-Length: "+wsdl.Length+"\r\n\r\n"+wsdl;
          }
        }				
        else 
        {  responseMessage += "HTTP/1.1 501 Not Implemented\r\nContent-Length: 0\r\n\r\n"; }
      }
      Send(m_socWorker, responseMessage);
    }	
  }
}
