// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Xml;
using System.Collections;
using System.IO;
using System.Net;
using BoPi.Common;
using BoPi.Machine;
using BoPi.Web;
using BoPi.Types;


namespace BoPi.wsdlgest
{
	public class Bopi2Wsdl
	{
		String tnsuri;
		StringWriter wsdlsw;
		XmlTextWriter wsdl;

		public Bopi2Wsdl()
		{
			wsdlsw = new StringWriter();
			wsdl = new XmlTextWriter(wsdlsw);
			wsdl.Formatting = Formatting.Indented;
			tnsuri = WebServer.GetLocalMachine();
		}

		public String GetWsdlFromBoPi(Chan service, String soapaction, String chanlocation)
		{
			IType output = null;
      IType input = null;
			GetInOut(service, out input, out output);
      ICollection outList;
      ICollection inList = GetParts(input);
      if (output != null) outList = GetParts(output);
      else outList = new ArrayList();

			wsdl.WriteRaw("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
			wsdl.WriteStartElement("wsdl","definitions","http://schemas.xmlsoap.org/wsdl/");
			wsdl.WriteAttributeString("xmlns","http",null,"http://schemas.xmlsoap.org/wsdl/http/");
			wsdl.WriteAttributeString("xmlns","soap",null,"http://schemas.xmlsoap.org/wsdl/soap/");
			wsdl.WriteAttributeString("xmlns","s",null,"http://www.w3.org/2001/XMLSchema");
			wsdl.WriteAttributeString("xmlns","soapenc",null,"http://schemas.xmlsoap.org/soap/encoding/");
			//add the ability to code all the BoPi schema element
			wsdl.WriteAttributeString("xmlns","ext",null,"http://www.cs.unibo.it/BoPi/extended");
			//add the ability to have input capability on wsdl
			wsdl.WriteAttributeString("xmlns","ewsdl",null,"http://www.cs.unibo.it/BoPi/extendedwsdl");
			wsdl.WriteAttributeString("xmlns","tns",null,tnsuri);
			wsdl.WriteAttributeString("targetNamespace",tnsuri);
      //WSDL Types
			wsdl.WriteStartElement("types","http://schemas.xmlsoap.org/wsdl/");		
      ISet ioList = new ArraySet();      
      foreach (IType t in inList) ioList.Add(t);
      foreach (IType t in outList) ioList.Add(t);
			IDictionary schemaTable = addschemadef(ioList);
			wsdl.WriteEndElement();
      
      //WSDL Messages
      //input message
      wsdl.WriteStartElement("message","http://schemas.xmlsoap.org/wsdl/");
      wsdl.WriteAttributeString("name","serviceSoapIn");
      AddMessageParts(inList, schemaTable, "par");
      wsdl.WriteEndElement();
      //output message
		  if (output != null)
			{
				wsdl.WriteStartElement("message","http://schemas.xmlsoap.org/wsdl/");
				wsdl.WriteAttributeString("name","serviceSoapOut");
        AddMessageParts(outList, schemaTable, "res");
				wsdl.WriteEndElement();
			}
      
      //WSDL PortType
			wsdl.WriteStartElement("portType","http://schemas.xmlsoap.org/wsdl/");
			wsdl.WriteAttributeString("name","serviceSoap");
			wsdl.WriteStartElement("operation","http://schemas.xmlsoap.org/wsdl/");
			wsdl.WriteAttributeString("name","bopichanoperation");
			  
      wsdl.WriteStartElement("input","http://schemas.xmlsoap.org/wsdl/");
			wsdl.WriteAttributeString("message","tns:serviceSoapIn");
			wsdl.WriteEndElement();
      
			if (output != null)
			{
				wsdl.WriteStartElement("output","http://schemas.xmlsoap.org/wsdl/");
				wsdl.WriteAttributeString("message","tns:serviceSoapOut");
				wsdl.WriteEndElement();
			}
			wsdl.WriteEndElement();//operation
			wsdl.WriteEndElement();//porttype

      //WSDL Binding (a soap binding over http)
			wsdl.WriteStartElement("binding","http://schemas.xmlsoap.org/wsdl/");
			wsdl.WriteAttributeString("name","serviceSoap");
			wsdl.WriteAttributeString("type","tns:serviceSoap");
			wsdl.WriteStartElement("binding","http://schemas.xmlsoap.org/wsdl/soap/");
			wsdl.WriteAttributeString("style","document");
			wsdl.WriteAttributeString("transport","http://schemas.xmlsoap.org/soap/http");
			wsdl.WriteEndElement();
			wsdl.WriteStartElement("operation","http://schemas.xmlsoap.org/wsdl/");
			wsdl.WriteAttributeString("name","bopichanoperation");
			wsdl.WriteStartElement("operation","http://schemas.xmlsoap.org/wsdl/soap/");
			if (!soapaction.StartsWith("http://"))
        wsdl.WriteAttributeString("soapAction",tnsuri+soapaction);
			else //for another machine
				wsdl.WriteAttributeString("soapAction",soapaction);
			wsdl.WriteAttributeString("style","document");
			wsdl.WriteEndElement();
      
      wsdl.WriteStartElement("input","http://schemas.xmlsoap.org/wsdl/");
      wsdl.WriteStartElement("body","http://schemas.xmlsoap.org/wsdl/soap/");
      wsdl.WriteAttributeString("use","literal");
      wsdl.WriteEndElement();
      wsdl.WriteEndElement();
			if (output != null)
			{
				wsdl.WriteStartElement("output","http://schemas.xmlsoap.org/wsdl/");
				wsdl.WriteStartElement("body","http://schemas.xmlsoap.org/wsdl/soap/");
				wsdl.WriteAttributeString("use","literal");
				wsdl.WriteEndElement();
				wsdl.WriteEndElement();
			}
			wsdl.WriteEndElement();
			wsdl.WriteEndElement();
      
      //WSDL Service
			wsdl.WriteStartElement("service","http://schemas.xmlsoap.org/wsdl/");
			wsdl.WriteAttributeString("name","bopiservice");
			wsdl.WriteStartElement("port","http://schemas.xmlsoap.org/wsdl/");
			wsdl.WriteAttributeString("name","serviceSoap");
			wsdl.WriteAttributeString("binding","tns:serviceSoap");
			wsdl.WriteStartElement("address","http://schemas.xmlsoap.org/wsdl/soap/");
			if (!chanlocation.StartsWith("http://"))
        wsdl.WriteAttributeString("location",tnsuri+chanlocation);
			else //for remote machine
				wsdl.WriteAttributeString("location",chanlocation);
			wsdl.WriteStartElement("wsdlcapability","http://www.cs.unibo.it/BoPi/extendedwsdl");
      if (service.HasInputCapability())
        wsdl.WriteString("I");
			if (service.HasOutputCapability())
				wsdl.WriteString("O");
			wsdl.WriteEndElement();
			wsdl.WriteEndElement();
			wsdl.WriteEndElement();
			wsdl.WriteEndElement();			
			wsdl.WriteEndElement();	
      
			return wsdlsw.ToString();
		}
		private IDictionary addschemadef(ICollection list)
		{			
      IDictionary schemaTable = new Hashtable();
			wsdl.WriteStartElement("schema","http://www.w3.org/2001/XMLSchema");
			wsdl.WriteAttributeString("targetNamespace",tnsuri);
			wsdl.WriteAttributeString("elementFormDefault","qualified");			
			StringWriter extendedsw = new StringWriter();
			XmlTextWriter extended = new XmlTextWriter(extendedsw);
			StringWriter standardsw = new StringWriter();
			XmlTextWriter standard = new XmlTextWriter(standardsw);
			standard.Formatting = Formatting.Indented;
			extended.Formatting = Formatting.Indented;		
			IList alreadydeclared = new ArrayList();
      foreach (IType t in list)
      { 
        if (schemaTable.Contains(t.ToString())) continue;
        if (t.IsInt()) schemaTable[t.ToString()] = "s:int";
        else if (t.IsString()) schemaTable[t.ToString()] = "s:string";
        else if (t.IsVoid()) schemaTable[t.ToString()] = "ext:void";
        else if (t.IsSequence() || t.IsUnion() || t.IsConstantTypeName() || t.IsChan() || t.IsLabelled() || t.IsIntLiteral() || t.IsStringLiteral())
        {
          String ts = XmlTypeFactor.BuildType(t).getschema(standard,wsdl,extended,0,alreadydeclared);
          schemaTable[t.ToString()] = ts;
        }
        else throw new ApplicationException("Bopi2Wsdl.addschemadef(...): Wrong Type " + t.GetType());
      }
			XmlUtil.CopyXml(wsdl,standardsw.ToString());
			wsdl.WriteEndElement();//for schemas
			wsdl.WriteStartElement("schema","http://www.w3.org/2001/XMLSchema");
			wsdl.WriteAttributeString("targetNamespace","http://www.cs.unibo.it/BoPi/extended");
			wsdl.WriteAttributeString("elementFormDefault","qualified");			
			XmlUtil.CopyXml(wsdl,extendedsw.ToString());
			wsdl.WriteEndElement();
      return schemaTable;
		}
    private void AddMessageParts(ICollection list, IDictionary schemaTable, String prefix)
    {
      int i = 0;
      foreach (IType t in list)
      {        
        if (t.IsVoid()) continue;
        wsdl.WriteStartElement("part","http://schemas.xmlsoap.org/wsdl/");
        wsdl.WriteAttributeString("name", prefix + i);
        i++;
        if (t.IsString() || t.IsInt())
           wsdl.WriteAttributeString("type", (String)schemaTable[t.ToString()]);
        else
        {
          String type = (String)schemaTable[t.ToString()];
          if (type.StartsWith("element"))
            wsdl.WriteAttributeString("element", type.Substring("element".Length));
          else if (type.StartsWith("type"))
            wsdl.WriteAttributeString("type", type.Substring("type".Length));
        }
        wsdl.WriteEndElement();
      }
    }
    private ISet GetParts(IType t)
    {
      IType tmp = t;
      ISet s = new ArraySet();
      while (tmp.IsConstantTypeName()) 
        tmp = tmp.AsConstantTypeName().Entry.Type;
      if (!tmp.IsSequence()) s.Add(tmp);
      else 
      {
        tmp = tmp.AsSequence().Unroll();
        while (tmp.IsSequence())
        {
          s.Add(tmp.AsSequence().Top); 
          tmp = tmp.AsSequence().Tail;
        }
        s.Add(tmp);
      }
      return s;
    }
	  public static void GetInOut(Chan service, out IType input, out IType output)
		{
      IType carried = service.Carried;
      while (carried.IsConstantTypeName()) 
        carried = carried.AsConstantTypeName().Entry.Type;
      if (carried.IsChan() && carried.AsChan().Capability == Chan.CAPABILITY.OUT)
      {
        input = new Types.Void();
        output = carried.AsChan().Carried;
      }
      else if (carried.IsSequence())			
      {
				Sequence seq = carried.AsSequence();
        //looking for the top and the tail of the sequence
        IType tail = seq;
        IType top = null;
        while (tail.IsSequence())
        {
          IType tmp = tail.AsSequence().Top;
          while(tmp.IsConstantTypeName())
            tmp = tmp.AsConstantTypeName().Entry.Type;
          if (top == null) 
            top = tmp;
          else 
            top = new Sequence(top, tmp);
          tmp = tail.AsSequence().Tail;
          while (tmp.IsConstantTypeName()) 
            tmp = tmp.AsConstantTypeName().Entry.Type;
          tail = tmp;
        }
				if (tail.IsChan() && (tail.AsChan().Capability == Chan.CAPABILITY.OUT))
				{
					output = tail.AsChan().Carried;
					input = top;
				}
				else
				{
					output = null;
					input = carried;
				}
			}
			else
			{
				output = null;
				input = carried;
			}
		}
	}
}
