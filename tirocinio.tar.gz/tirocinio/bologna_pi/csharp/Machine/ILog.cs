using System;
using System.Xml;

namespace BoPi.Machine
{
	public interface ILog
	{
		void WriteLog(uint id, XmlElement xe, Env env);

		void CloseStream();
	}
}
