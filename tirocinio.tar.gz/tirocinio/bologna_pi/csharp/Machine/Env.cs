// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using BoPi.Types;
using System.Diagnostics;

namespace BoPi.Machine
{	
	public class Env
	{
		private readonly IValue[] table;
	
		public Env(int size)
		{ this.table = new IValue[size]; }

		private Env(IValue[] table)
		{ this.table = (IValue[]) table.Clone(); }

		private Env(IValue[] table, int parentSize, int size)
		{
			this.table = new IValue[size];
			Array.Copy(table, this.table, parentSize);
		}

		public void Set(int index, IValue v)
		{
			Debug.Assert(index >= 0 && index < table.Length);
			table[index] = v;
		}

		public IValue Get(int index)
		{
			Debug.Assert(index >= 0 && index < table.Length);
			return table[index];
		}

		public Env Clone()
		{ return new Env(table); }

		public Env Clone(int parentSize, int size)
		{ return new Env(table, parentSize, size); }
						
		public override string ToString()
		{
			string s = "";
			for (int i = 0; i < table.Length; i++)
				s += "(" + i.ToString() + "=" + table[i] + ") ";
			return s;
		}
	}
}
