// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Xml;
using BoPi.Web;
using System.Threading;
using System.Collections;
using System.Text.RegularExpressions;

namespace BoPi.Machine
{
  public class MachineOptions 
  {
    private int port = 1811;
    private bool keepAlive = false;
    private bool usage = false;
    private ILog log = null;
    private IList programs = new ArrayList();

    public int Port
    { 
      get { return port; }
      set { port = value; }
    }
    public bool KeepAlive
    { 
      get { return keepAlive; }
      set { keepAlive = value; }
    }
    public ILog Log
    {
      get { return log; }
      set { log = value; }
    }
    public bool Usage
    {
      get { return usage; } 
      set { usage = value; } 
    }
    public IList Programs { get { return programs; } }
  }

	public class Machine
	{
    private static string usage = "Usage: machine.exe [OPTION] [FILE] ... " 
      + System.Environment.NewLine 
      + "Run a PiDuce machine and execute FILEs"
      + System.Environment.NewLine + "Options" + System.Environment.NewLine
      + "-port:PORT, /port:PORT" + "\t use PORT instead of the default port number 1811" 
      + System.Environment.NewLine
      + "-d, /d" + "\t keep the machine available over the network"
      + System.Environment.NewLine
      + "-netlog:IPADDRESS;PORT;LOGLEVEL, /netlog:IPADDRESS;PORT;LOGLEVEL" + "\t log the machine internal operations and send the log over the network"
      + System.Environment.NewLine
      + "-filelog:FILENAME;LOGLEVEL, /filelog:FILENAME;LOGLEVEL" + "\t log the machine internal operations to a given file"
      + System.Environment.NewLine
      + "IPADDRESS is the IPv4 ip address of the machine to which send the log"
      + System.Environment.NewLine
      + "PORT is the port of the machine to which send the log"
      + System.Environment.NewLine
      + "FILENAME is the name of the file in which to log"
      + System.Environment.NewLine
      + "LOGLEVEL is a number between 0 and 3 included"
      + System.Environment.NewLine;


    public static string Usage { get { return usage; } } 
    
    private static MachineOptions Parse(string[] args)
    {
      MachineOptions options = new MachineOptions();
      
      foreach (string par in args) //parsing arguments
      {
        if (par.StartsWith("-port:") || par.StartsWith("/port:"))
        { 
          try 
          { options.Port = Int16.Parse(par.Substring("-port".Length + 1)); }
          catch (OverflowException) 
          { Console.WriteLine("Wrong port number ... using the default port number {0}", options.Port); }
        }
        else if (par.StartsWith("-d") || par.StartsWith("/d"))
        { options.KeepAlive = true; }
        else if (par.StartsWith("-help") || par.StartsWith("/help"))
        { options.Usage = true; }
	else if (par.StartsWith("-netlog:") || par.StartsWith("/netlog:"))
	{
		try
		{
			Regex separator = new Regex(";");
			if (separator.Split(par).Length != 3) {
				Console.WriteLine("Error: malformed option");
				Environment.Exit(-1);
			}
			
			int FirstParStart = par.IndexOf(":") + 1;
			int FirstParLen = par.IndexOf(";", FirstParStart + 1) - FirstParStart;
			int SecondParStart = par.IndexOf(";", FirstParStart + FirstParLen) + 1;
			int SecondParLen = par.IndexOf(";", SecondParStart) - SecondParStart;
			int ThirdParStart = par.IndexOf(";", SecondParStart + SecondParLen) + 1;
			
			string LogIPAddress = par.Substring(FirstParStart, FirstParLen);
			int LogPort = Int32.Parse(par.Substring(SecondParStart, SecondParLen));
			int LogLevel = Int32.Parse(par.Substring(ThirdParStart));

			options.Log = new SocketLog(LogIPAddress, LogPort, LogLevel);
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
		}
	}
	else if (par.StartsWith("-filelog:") || par.StartsWith("/filelog:"))
	{
		try {
			Regex separator = new Regex(";");
			if (separator.Split(par).Length != 2) {
				Console.WriteLine("Error: malformed option");
				Environment.Exit(-1);
			}
			
			int FirstParStart = par.IndexOf(":") + 1;
			int FirstParLen = par.IndexOf(";", FirstParStart + 1) - FirstParStart;
			int SecondParStart = par.IndexOf(";", FirstParStart + FirstParLen) + 1;
			
			string LogFile = par.Substring(FirstParStart, FirstParLen);
			int LogLevel = Int32.Parse(par.Substring(SecondParStart));
			
			options.Log = new FileLog(LogFile, LogLevel);
		}
		catch (Exception e)
		{
			Console.WriteLine(e);
		}
	}
        else 
        { 
          try 
          {
            XmlDocument program = new XmlDocument();
            program.Load(par);
            options.Programs.Add(program);
          } 
          catch (Exception e)
          { Console.WriteLine("Error loading the program {0} {1}", par, e);  }
        }
      }
      return options;
    }

		[STAThread]
		public static void Main(string[] args)
    {	
      MachineOptions options = Parse(args);
      if (options.Usage) 
      { Console.WriteLine(Usage); Environment.Exit(0); }

      //starting the machine
      ChannelManager chmgr = new ChannelManager(); 
      Scheduler scheduler = new Scheduler(chmgr, options.KeepAlive);
      foreach (XmlDocument bytecode in options.Programs)
      {
	      scheduler.AddProgram(bytecode.InnerXml, options.Log);
      }

      WebServer.Init(chmgr, scheduler, options.Port);
      Thread wThread = new Thread(new ThreadStart(WebServer.StartListening));
      wThread.Name = "WebServer";
      wThread.Start();
      scheduler.Run();
		}
	}
}
