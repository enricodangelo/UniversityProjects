using System;
using System.Net.Sockets;
using System.IO;

namespace BoPi.Machine
{
	public class FileLog : Log
	{
		public FileLog(string logFile, int logLevel) : base(logLevel)
		{
			base.streamWriter = File.AppendText(logFile);
		}

		public override void CloseStream()
		{
			base.streamWriter.Close();
		}
	}
}
