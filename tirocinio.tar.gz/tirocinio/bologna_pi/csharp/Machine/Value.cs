// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Xml;
using BoPi.Types;
using System.Diagnostics;
using BoPi.wsdlgest;

namespace BoPi.Machine
{
	public interface IValue
	{
		void GetXmlFromValue(XmlWriter xml, String namespaceuri);
		IType TypeOf();
	}

	public abstract class Value : IValue
	{
		public abstract void GetXmlFromValue(XmlWriter xml, string namespaceuri);
		public abstract IType TypeOf();

		public virtual void GetSimpleXmlFromValue(XmlWriter xml, string namespaceURI)
		{ GetXmlFromValue(xml, namespaceURI); }
	}

	public class VoidValue : Value
	{
		public override void GetXmlFromValue(XmlWriter xml, string namespaceuri)
		{
			xml.WriteStartElement("void", "http://www.cs.unibo.it/BoPi/extended");
			xml.WriteEndElement(); // </void>
		}

		public override void GetSimpleXmlFromValue(XmlWriter xml, string namespaceURI)
		{ }

		public override string ToString()
		{ return "void"; }

		public override IType TypeOf()
		{ return new Types.Void(); }		
	}

	public class IntValue : Value
	{
		private readonly int val;	

		public IntValue(int val)
		{ this.val = val; }

		public override void GetXmlFromValue(XmlWriter xml, string namespaceURI)
		{
			xml.WriteStartElement("intLit", "http://www.cs.unibo.it/BoPi/extended");
			xml.WriteString(val.ToString());
			xml.WriteEndElement(); // </intLit>
		}

		public override void GetSimpleXmlFromValue(XmlWriter xml, string namespaceURI)
		{ xml.WriteString(val.ToString()); }

		public override string ToString()
		{ return val.ToString(); }

		public override IType TypeOf()
		{ return new Types.IntLiteral(val); }

		public static IntValue operator+(IntValue op1, IntValue op2)
		{ return new IntValue(op1.val + op2.val); }

		public static IntValue operator*(IntValue op1, IntValue op2)
		{ return new IntValue(op1.val * op2.val); }

		public static IntValue operator-(IntValue op1, IntValue op2)
		{ return new IntValue(op1.val - op2.val); }

		public static IntValue operator-(IntValue op1)
		{ return new IntValue(-op1.val); }

		public static IntValue operator/(IntValue op1, IntValue op2)
		{ return new IntValue(op1.val / op2.val); }

		public static IntValue operator<(IntValue op1, IntValue op2)
		{
			if (op1.val < op2.val) return new IntValue(1);
			else return new IntValue(0);
		}
		
		public static IntValue operator>(IntValue op1, IntValue op2)
		{
			if (op1.val > op2.val) return new IntValue(1);
			else return new IntValue(0);
		}
		
		public static IntValue operator<=(IntValue op1, IntValue op2)
		{
			if (op1.val <= op2.val) return new IntValue(1);
			else return new IntValue(0);
		}
		
		public static IntValue operator>=(IntValue op1, IntValue op2)
		{
			if (op1.val >= op2.val) return new IntValue(1);
			else return new IntValue(0);
		}
		
		public static IntValue operator==(IntValue op1, IntValue op2)
		{
			if (op1.val == op2.val) return new IntValue(1);
			else return new IntValue(0);
		}
		
		public static IntValue operator!=(IntValue op1, IntValue op2)
		{
			if (op1.val != op2.val) return new IntValue(1);
			else return new IntValue(0);
		}
	
		public static IntValue operator&(IntValue op1, IntValue op2)
		{
			if (op1.val != 0 && op2.val != 0) return new IntValue(1);
			else return new IntValue(0);
		}

		public static IntValue operator|(IntValue op1, IntValue op2)
		{
			if (op1.val != 0 || op2.val != 0) return new IntValue(1);
			else return new IntValue(0);
		}

		public static IntValue operator!(IntValue op1)
		{
			if (op1.val == 0) return new IntValue(1);
			else return new IntValue(0);
		}

		public override bool Equals(object obj)
		{
			if (obj.GetType() != this.GetType()) return false;
			return ((IntValue) obj).val == val;
		}

		public override int GetHashCode()
		{ return val.GetHashCode(); }
	}

	public class StringValue : Value
	{
		private readonly string val;

		public StringValue(string val)
		{ this.val = val; }

		public override void GetXmlFromValue(XmlWriter xml, String namespaceURI)
		{
			xml.WriteStartElement("stringLit", "http://www.cs.unibo.it/BoPi/extended");
			xml.WriteString(val);
			xml.WriteEndElement(); // </stringLit>
		}

		public override void GetSimpleXmlFromValue(XmlWriter xml, string namespaceURI)
		{ xml.WriteString(val); }

		public override string ToString()
		{ return val; }

		public override IType TypeOf()
		{ return new Types.StringLiteral(val); }

		public static StringValue operator+(StringValue op1, StringValue op2)
		{ return new StringValue(op1.val + op2.val); }

		public static StringValue operator-(StringValue op1)
		{ return new StringValue(op1.val[0].ToString()); }

		public static StringValue operator+(StringValue op1)
		{ return new StringValue(op1.val.Substring(1)); }

		public static IntValue operator==(StringValue op1, StringValue op2)
		{
			if (op1.val == op2.val)return new IntValue(1);
			else return new IntValue(0);
		}

		public static IntValue operator!=(StringValue op1, StringValue op2)
		{
			if (op1.val != op2.val) return new IntValue(1);
			else return new IntValue(0);
		}

		public override bool Equals(object obj)
		{
			if (obj.GetType() != this.GetType()) return false;
			return ((StringValue)obj).val == val;           		
		}

		public override int GetHashCode()
		{ return val.GetHashCode (); }
	}

  public abstract class ChannelValue : Value
  {
    private readonly string location;
    private readonly string wsdl;
    private readonly Chan type;
    
    public ChannelValue(string wsdl, string location, Chan type)
    {
      this.location = location;
      this.type = type;
      this.wsdl = wsdl;
    }

    public string Location { get { return location; } }
    public string Wsdl { get { return wsdl; } }
    public Chan Type { get { return type; } }

    public override IType TypeOf() 
    { return type; }

    public override void GetXmlFromValue(XmlWriter xml, String namespaceuri)
    {
      xml.WriteStartElement("chan","http://www.cs.unibo.it/BoPi/extended");
      xml.WriteAttributeString("wsdlLocation", Web.WebServer.GetLocalMachine() + wsdl);
      xml.WriteAttributeString("location", Web.WebServer.GetLocalMachine() + location);
      xml.WriteEndElement();
    }

    public override string ToString()
    { return "<chan wsdl=" + wsdl + "/>"; }

    public abstract bool IsLocalChannel();
    public abstract bool IsRemoteChannel();
    public abstract LocalChannel AsLocalChannel();
    public abstract RemoteChannel AsRemoteChannel();
  }

  public class LocalChannel : ChannelValue
  {
    public LocalChannel(string wsdl, string location, Chan type): base(wsdl, location, type){}
    public override bool IsLocalChannel() { return true; }
    public override bool IsRemoteChannel() { return false; }
    public override LocalChannel AsLocalChannel() { return this; }
    public override RemoteChannel AsRemoteChannel() { throw new ApplicationException("Cannot cast from LocalChannel to RemoteChannel"); }
  }

	public class RemoteChannel : ChannelValue
	{
    public override bool IsLocalChannel() { return false; }
    public override bool IsRemoteChannel() { return true; }
    public override LocalChannel AsLocalChannel() { throw new ApplicationException("Cannot cast from RemoteChannel to LocalChannel"); }
    public override RemoteChannel AsRemoteChannel() { return this; }
    
    private readonly string soapAction;
    private readonly string namespaceUri;
    
    public string SoapAction { get { return soapAction; } }
    public string NamespaceUri { get { return namespaceUri; } }

    public RemoteChannel(String wsdl, Chan type, string chanLocation, string soapAction, string namespaceUri): base(wsdl, chanLocation, type)
		{
      this.soapAction = soapAction;
      this.namespaceUri = namespaceUri;
		}
	}

	public class LabelValue : Value
	{
		private readonly IValue content;
		private readonly string label;

		public IValue Content { get { return content; } }
		public string Label { get { return label; } }

		public LabelValue(string label, IValue content)
		{
			this.label = label;
			this.content = content;
		}		

		public override void GetXmlFromValue(XmlWriter xml, string namespaceURI)
		{
			xml.WriteStartElement(label, namespaceURI);
			((Value) content).GetSimpleXmlFromValue(xml, namespaceURI);
			xml.WriteEndElement();
		}
		
		public override string ToString()
		{ return "<" + label + ">" + content.ToString() + "</" + label + ">"; }

		public override IType TypeOf()
		{ return new Types.Labelled(new Types.UnionLabel(label), content.TypeOf()); }
	}

	public class SequenceValue : Value
	{
		private readonly IValue top;
		private readonly IValue tail;

		public IValue Top { get { return top; } }
		public IValue Tail { get { return tail; } }

		public SequenceValue(IValue top, IValue tail)
		{
			if (top is SequenceValue) {
				//(S,R),T = S,(R,T)
				IValue topOfTop = ((SequenceValue) top).top;
				IValue tailOfTop = ((SequenceValue) top).tail;
				SequenceValue s = new SequenceValue(topOfTop, new SequenceValue(tailOfTop, tail));
				top = s.top;
				tail = s.tail;
			}

			this.top = top;
			this.tail = tail;
		}

		public override void GetXmlFromValue(XmlWriter xml, string namespaceURI)
		{
			top.GetXmlFromValue(xml, namespaceURI);
			tail.GetXmlFromValue(xml, namespaceURI);
		}

		public override string ToString()
		{ return top.ToString() + "," + tail.ToString(); }

		public override IType TypeOf()
		{ return new Types.Sequence(top.TypeOf(), tail.TypeOf()); }
	}

	public class ValueUtil
	{
		public static IValue ParseValue(XmlNode currentnode)
		{	
			IValue first = new VoidValue();
			IValue seq = null;

			while (currentnode != null) {
				if (currentnode.NamespaceURI == "http://www.cs.unibo.it/BoPi/extended") {
          if (currentnode.LocalName == "intLit")
            first = new IntValue(Int32.Parse(currentnode.InnerText));
          else if (currentnode.LocalName == "stringLit")
            first = new StringValue(currentnode.InnerText);
          else if (currentnode.LocalName == "chan") 
          {
            string wsdl = currentnode.Attributes["wsdlLocation", ""].Value;
            string location = currentnode.Attributes["location", ""].Value;
            Wsdl2BoPi decoder = new Wsdl2BoPi(Web.Webclient.Download(wsdl));
            string chanLocation, soapAction, namespaceUri;
            Chan type = decoder.getBoPifromWsdl(out chanLocation, out soapAction, out namespaceUri).AsChan();
            first = new RemoteChannel(wsdl, type, chanLocation, soapAction, namespaceUri);
          }
          else if (currentnode.LocalName == "void")
            first = new VoidValue();
          else
            throw new ApplicationException("Invalid format of value");
				} else {
					IValue res = null;
					if (currentnode.ChildNodes.Count == 0)
						res = new VoidValue();
					else if ((currentnode.ChildNodes.Count == 1 && currentnode.FirstChild.NodeType == XmlNodeType.CDATA))
						res = new StringValue(currentnode.InnerText);
					else if ((currentnode.ChildNodes.Count == 1 && currentnode.FirstChild.NodeType == XmlNodeType.Text)) {
						try {
							res = new IntValue(Int32.Parse(currentnode.InnerText));
						} catch (Exception) {
							res = new StringValue(currentnode.InnerText);
						}
					} else
						res = ParseValue(currentnode.FirstChild);
					first = new LabelValue(currentnode.LocalName, res);
				}

				if (seq == null)
					seq = first;
				else if (!(first is VoidValue))
					seq = new SequenceValue(seq, first);

				currentnode = currentnode.NextSibling;
			}

			if (seq == null) return new VoidValue(); 
      else return seq;
		}

		public static void SplitInputOutput(IValue v, out IValue input, out ChannelValue output)
		{
			if (v is SequenceValue) {
				SequenceValue seq = (SequenceValue) v;
				input = seq.Top;
				while (seq.Tail is SequenceValue) {
					input = new SequenceValue(input, ((SequenceValue) seq.Tail).Top);
					seq = (SequenceValue) seq.Tail;
				}

				Debug.Assert(seq.Tail is ChannelValue);
				output = (ChannelValue) seq.Tail;
			} else {
				input = new VoidValue();
				Debug.Assert(v is ChannelValue);
				output = (ChannelValue) v;
			}
		}
	}
}
