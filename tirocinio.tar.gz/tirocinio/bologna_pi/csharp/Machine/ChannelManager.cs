// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Threading;
using System.Net;
using System.Xml;
using System.IO;
using System.Runtime.Remoting.Messaging;
using BoPi.Web;
using BoPi.Common;
using BoPi.Types;
using BoPi.wsdlgest;
using System.Diagnostics;

namespace BoPi.Machine
{
  public interface IInputRequest
  {
    bool Send(IValue value);
    void Empty();
  }

  public class Channel
  {
    private readonly String location;
		private readonly IType type;
    private readonly IList valueQueue;
    private readonly IList inputQueue;

    public Channel(String location, IType type)
    {
      this.location = location;
			this.type = type;
      this.valueQueue = new ArrayList();
      this.inputQueue = new ArrayList();
    }
		
    public void EnqueueRequest(IInputRequest request)
    { inputQueue.Add(request); }

    public void RemoveRequest(IInputRequest request)
    {
      Debug.Assert(inputQueue.Contains(request));
      inputQueue.Remove(request);
    }

    public IValue DequeueValue()
    {
      Debug.Assert(!Empty());
      IValue res = (IValue) valueQueue[0];
      valueQueue.Remove(res);

      if (Empty())
        foreach (IInputRequest request in inputQueue)
          request.Empty();

      return res;
    }

    public void Send(IValue v)
    {
      foreach (IInputRequest request in inputQueue)
        if (request.Send(v))
          return;

      valueQueue.Add(v);
    }

    public bool Empty()
    { return valueQueue.Count == 0; }

    public string Location { get { return location; } }
		public IType Type { get { return type; } }
  }

  public interface IManageOutputRequest
  {
    bool LocalOutput(String location, IValue v);
    String GetWsdl(String location);
    bool LinearForwarder(String location, String forwardtolocation, String wsdl);
    bool ForeignRequest(String location, IValue v, ArrayList responsecontainer);
    String AddChannel(String channellocation, String wsdl);
  }

  public abstract class AbstractInputRequest : IInputRequest
  {
    public virtual bool Send(IValue v)
    { return false; }

    public virtual void Empty()
    { }
  }

  public class DebugRequest : AbstractInputRequest
  {
    public override bool Send(IValue v)
    {
      Console.WriteLine(">>> " + v.ToString());
      return true;
    }
  }

  public class ForeignRequest : AbstractInputRequest
  {
    private Channel channel;
    private ArrayList responseContainer;
            
    public ForeignRequest(Channel channel, ArrayList responseContainer)
    {
      this.channel = channel;
      this.responseContainer = responseContainer;
    }

    public override bool Send(IValue v)
    {
      channel.RemoveRequest(this);
      StringWriter sw = new StringWriter();
      XmlTextWriter xml = new XmlTextWriter(sw);
      v.GetXmlFromValue(xml, WebServer.GetLocalMachine());
      sw.Flush();
      responseContainer.Add(XmlUtil.AddSoap(sw.ToString()));
      //removechannel(location); // LUCA: ???
      lock (responseContainer) {
        Monitor.Pulse(responseContainer);
      }
      return true;
    }
  }
          
  public class ForwardRequest : AbstractInputRequest
  {
    private Channel channel;
    private String forwardToLocation;
    private String SOAPAction;
            
    public ForwardRequest(Channel channel, String forwardToLocation, String SOAPAction)
    {
      this.channel = channel;
      this.forwardToLocation = forwardToLocation;
      this.SOAPAction = SOAPAction;
    }
		
    public override bool Send(IValue v)
    {
      channel.RemoveRequest(this);
      StringWriter sw = new StringWriter();
      XmlTextWriter xml = new XmlTextWriter(sw);
      //value belongs to current machine namespace
      v.GetXmlFromValue(xml, Web.WebServer.GetLocalMachine());
      sw.Flush();
      new Web.Webclient.UploadDelegate(new Web.Webclient().Upload).BeginInvoke(forwardToLocation,
                                                                               XmlUtil.AddSoap(sw.ToString()),
                                                                               SOAPAction, null, null);
      return true;
    }
  }
          
  public class SingleInputRequest : AbstractInputRequest
  {
    private Channel channel;
    private Pattern f;
		private Env e;
    private VmThread thread; // thread that made the request
		private XmlElement cont;

		public Channel Channel { get { return channel; } }

    public SingleInputRequest(Channel channel, Pattern f, Env e, VmThread thread, XmlElement cont)
    {
      this.channel = channel;
      this.f = f;
			this.e = e;
      this.thread = thread;	
      this.cont = cont;
    }

    public override bool Send(IValue v)
    {
      bool res = f.patternmatch(e, v);
      Debug.Assert(res, f.ToString() + " does not match the value " + v.ToString() + " of schema " + v.TypeOf());
      channel.RemoveRequest(this);
			thread.Unblock(cont);
      return true;
    }
  }

  public class MultipleInputRequest : AbstractInputRequest
  {
    private Channel channel;
    private Pattern f;
		private Env e;
    private VmThread thread; // thread that made the request
    private XmlElement cont;

		public Channel Channel { get { return channel; } }

    public MultipleInputRequest(Channel channel, Pattern f, Env e, VmThread thread, XmlElement cont)
    {
      this.channel = channel;
      this.f = f;
			this.e = e;
      this.thread = thread;	
      this.cont = cont;
    }

    public override bool Send(IValue v)
    {
			Env newEnv = e.Clone();
      bool res = f.patternmatch(newEnv, v);
      Debug.Assert(res, f.ToString() + " does not match the value " + v.ToString() + " of schema " + v.TypeOf());
			thread.Fork(cont, newEnv, thread.log);
      return true;
    }
  }

  public class ChannelManager : IManageOutputRequest
  {
    private Hashtable channels;
    private int freshIndex = 0;
              
    public ChannelManager()
    { channels = new Hashtable(); }

    public Channel GetChannel(String location)
    {
      lock (channels) {
        if (channels.ContainsKey(location))
          return (Channel) channels[location];
        else
          return null;
      }
    }

    public string GetWsdl(String location)
    {
      IType type = null;
      lock (channels) {
        if (channels.ContainsKey(location)) 
          type = ((Channel) channels[location]).Type;
        else
					return "";
      }
      Bopi2Wsdl decoder = new Bopi2Wsdl();
      return decoder.GetWsdlFromBoPi(type.AsChan(), "bopichanaction/", location);
    }
                        
    public String AddChannel(String location, String wsdl)
    {
      String chanLocation, soapAction, namespaceUri;;
      if (location.StartsWith("/")) chanLocation = location.Substring(1);
      Wsdl2BoPi decoder = new Wsdl2BoPi(wsdl);
      IType type = decoder.getBoPifromWsdl(out chanLocation, out soapAction, out namespaceUri);
      lock (channels) {
        if (!channels.ContainsKey(location)) {
          channels[location] = new Channel(location, type);				
          return location;
        } else 
					return AddChannel(type);
      }
    }
                    
    public String AddChannel(String location, IType type)
    {
      if (location.StartsWith("/")) location = location.Substring(1);
      lock (channels) {
        //if the channel stdout is already declared no action is performed
        if (location.Equals("stdout") && channels.ContainsKey(location)) 
          return location;
        if (!channels.ContainsKey(location)) {
          Channel channel = new Channel(location, type);
          if (location.Equals("stdout"))
          { channel.EnqueueRequest(new DebugRequest()); }
          channels[location] = channel;
          return location;
        } else 
					return AddChannel(type);
      }
    }
                    
    public String AddChannel(IType type)
    {	
      lock(channels) {
        String location = "local/chan" + freshIndex.ToString();
        while (channels.ContainsKey(location)) {
          freshIndex++;
          location = "local/chan" + freshIndex.ToString();
        }
        channels[location] = new Channel(location, type);
        return location;
      }                              
    }

    public void RemoveChannel(String location)		
    {
      lock(channels) {
        channels.Remove(location);
      }
    }
     
    public bool ForeignRequest(String location, IValue v, ArrayList responseContainer)
    {
      lock (channels) {
        if (!channels.ContainsKey(location))
          return false;
        Chan chanType = ((Channel) channels[location]).Type.AsChan();
        IType inputType, outputType;
        Bopi2Wsdl.GetInOut(chanType, out inputType, out outputType);
        if (outputType == null) return false;
        //add a new channel for getting the response
        String responseLocation = AddChannel(outputType);

        Chan reply = new Chan(outputType, Chan.CAPABILITY.OUT);
        LocalChannel replyChannel = new LocalChannel(responseLocation + "?wsdl", responseLocation, reply);
        //Console.WriteLine("Synchronous service invoked, created a reply channel");
        if (v is VoidValue) v =  replyChannel;
        else v = new SequenceValue(v, replyChannel);
        Channel ch = (Channel) channels[responseLocation];
        ch.EnqueueRequest(new ForeignRequest(ch, responseContainer));
        LocalOutput(location,v);
      }
      return true;
    }
              
    private void OnReceive(IAsyncResult iar)
    {
      try 
      {
        AsyncResult ar = (AsyncResult)iar;
        Webclient.UploadDelegate ud = (Webclient.UploadDelegate)ar.AsyncDelegate;
        ChannelValue chan = (ChannelValue)ar.AsyncState;
        XmlNode res = ud.EndInvoke(iar);
        if (res == null) return;
        IValue v = ValueUtil.ParseValue(res);
        Output(chan, v);                        
      } 
      catch (Exception e)
      {
        MachineOutput.Print("An error occured getting the response from a synchronous remote service " + e);
      }
    }                                
                                
    /***
     * Quando fai il check per il sottotipaggio devi passare
     * un env costruito in modo tale da contenere sia gli schemi
     * per il canale remoto sia gli schemi per il canale locale
     * */
    public bool LinearForwarder(String location, String forwardtolocation, String wsdl)
    {
      lock (channels)
      {
        if (channels.ContainsKey(location))
        {
          String soapaction = "bopichanaction/";
          Channel ch = (Channel) channels[location];
          ForwardRequest request = new ForwardRequest(ch, forwardtolocation, soapaction);
          if (!ch.Empty())
            request.Send(ch.DequeueValue());
          else
            ch.EnqueueRequest(request);
          return true;
        } 
        else return false;
      }
    }

    public bool LocalOutput(String location, IValue v)
    {
      lock (channels) {
        if (channels.ContainsKey(location))
        {
          Channel c = (Channel) channels[location];
          c.Send(v);
          return true;
        }
        else return false;
      }
    }
    
    public bool Output(ChannelValue channel, IValue v)
    {
      lock (channels) 
      {
        //check whether is local channel
        if (channel.IsLocalChannel()) 
        { return LocalOutput(channel.Location, v); }
        else //the channel is not local
        {
            StringWriter sw = new StringWriter();
            XmlTextWriter xml = new XmlTextWriter(sw);
            RemoteChannel remote = channel.AsRemoteChannel();
            Debug.Assert(remote.Type.HasOutputCapability(), "The channel must have the output capability", "The channel schema is " + remote.Type.ToString());
            Debug.Assert((new TypeChecker()).IsSubtype(v.TypeOf(), remote.Type.Carried), "The value to sent is not a subtype of the channel schema", "The channel schema is " + remote.Type.ToString());
            IType input, output;
            Bopi2Wsdl.GetInOut(remote.Type, out input, out output);
            IValue inputValue;
            ChannelValue reply;
            if (output != null) //the service is synchronous so the last parameter is the reply channel
            {
							ValueUtil.SplitInputOutput(v, out inputValue, out reply);
              inputValue.GetXmlFromValue(xml, remote.NamespaceUri);
              //Console.WriteLine("Invoking a synchronous service");
              new Webclient.UploadDelegate(new Web.Webclient().Upload).
                BeginInvoke(remote.Location, XmlUtil.AddSoap(sw.ToString()), remote.SoapAction, new AsyncCallback(OnReceive), reply);
            }
            else //the service is asynchronous
            {
              //Console.WriteLine("Invoking an asynchronous service");
              v.GetXmlFromValue(xml,remote.NamespaceUri);
              new Web.Webclient.UploadDelegate(new Web.Webclient().Upload).
                BeginInvoke(remote.Location, XmlUtil.AddSoap(sw.ToString()), remote.SoapAction, null, null);
            }
        }		
        return true;
      }
    }
                    
    public int Select(IList locations, IList patterns, Env e, VmThread sender, IList conts)
    {
						Debug.Assert(false);
						/*
      int i;
      lock (channels) {
        if (locations.Count != patterns.Count) 
          throw new ChannelManagerException("Invalid parameters for select");

        if (locations.Count != conts.Count) 
          throw new ChannelManagerException("Invalid parameters for select");

        for (i = 0; i < locations.Count; i++) {
          if (!((String) locations[i]).StartsWith(WebServer.GetLocalMachine()))
            throw new ChannelManagerException("remote input on select not yet implemented");

          locations[i] = ((String) locations[i]).Substring(WebServer.GetLocalMachine().Length);
          if (!channels.ContainsKey(locations[i]))
            throw new ChannelManagerException("Error channel located at " + locations[i] + " not found for input");

          Debug.Assert(((Channel)channels[locations[i]]).Type.IsChan(), "The subject of an input must be a channel " + locations[i]);
          Debug.Assert(((Channel)channels[locations[i]]).Type.AsChan().HasInputCapability(), "The subject of an input must be a channel with input capability "  + locations[i]);
        }

        for (i = 0; i < locations.Count; i++) {
          Channel channel = (Channel) channels[locations[i]];
          if (!channel.Empty()) {
            ((Pattern) patterns[i]).patternmatch(e, channel.DequeueValue());
            return i;
          }
        }

        InputRequest first = null;
        InputRequest prev = null;
        for (i = 0; i < locations.Count; i++) {
          Channel ch = (Channel) channels[locations[i]];
          InputRequest request = new InputRequest(ch, (Pattern) patterns[i],
                                                  e, sender, (XmlElement) conts[i]);
          ch.EnqueueRequest(request);

          if (prev == null)
            first = prev;
          else {
            prev.SetNext(request);
            prev = request;
          }
        }

        Debug.Assert(prev != null && first != null);
        prev.SetNext(first);
      }
			*/

      return -1;
    }

		public void ServiceJoinSelect(ArrayList joinChannels,
																	ArrayList rows,
																	IJoinAutomaton automaton,
																	Env env,
																	VmThread thread)
		{
			// we create the JoinInputDefinition which will attach the join input
			// requests to the joined channels. This has to be done first because
			// for the automaton to be updated correctly it is necessary that the
			// join input requets are in place. Unfortunately, it also means that
			// for a short period of time the automaton does not reflect the true
			// state of the channels, despite being attached to them.
			new JoinInputDefinition(true, joinChannels, automaton, env, thread);

			//Console.WriteLine("InitAutomaton...");
			for (int i = 0; i < joinChannels.Count; i++) {
				Channel channel = (Channel) joinChannels[i];
				if (!channel.Empty()) {
					//Console.WriteLine("found nonempty channel " + i);
					automaton.Full(i);

					// the presence of an active row must be checked immediately
					// because the automaton may not be able to handle overlapping
					// patterns
					JoinPatternRow row = automaton.ActiveRow;
					if (row != null) {
						Env newEnv = env.Clone();
						row.Match(newEnv);
						thread.Fork(row.Next, newEnv, thread.log);
					}
				}
			}
		}

    public XmlElement JoinSelect(ArrayList joinChannels,
																 ArrayList rows,
																 IJoinAutomaton automaton,
																 Env env,
																 VmThread sender)
    {
			//Console.WriteLine("InitAutomaton...");
			for (int i = 0; i < joinChannels.Count; i++) {
				Channel channel = (Channel) joinChannels[i];
				if (!channel.Empty()) {
					//Console.WriteLine("found nonempty channel " + i);
					automaton.Full(i);
					
					// the presence of an active row must be checked immediately
					// because the automaton may not be able to handle overlapping
					// patterns
					JoinPatternRow row = automaton.ActiveRow;
					if (row != null) {
						row.Match(env);
						return row.Next;
					}
				}
			}

			//Console.WriteLine("no active row found");
			JoinInputDefinition def = new JoinInputDefinition(false, joinChannels, automaton, env, sender);
			Debug.Assert(def != null);
			return null;
    }

    private delegate void RemoteInputDelegate(RemoteChannel channel, Pattern f, Env e, VmThread sender, XmlElement next);
                      
    private void RemoteInput(RemoteChannel channel, Pattern f, Env e, VmThread sender, XmlElement next)
    {
      lock (channels)
      {
        string fwdLocation = AddChannel(channel.Type);
        Channel fwd = (Channel) channels[fwdLocation];
        fwd.EnqueueRequest(new SingleInputRequest(fwd, f, e, sender, next));
        String request = "<linearforward xmlns=\"http://cs.unibo.it/BoPi/controlmessage\" >";
        request += "<forwardto location=\"" + WebServer.GetLocalMachine() + fwdLocation + "\" wsdl=\"" + WebServer.GetLocalMachine() + fwdLocation + "?wsdl" + "\" />";
        request += "</linearforward>";
        new Web.Webclient().Upload(channel.Location, XmlUtil.AddSoap(request), "http://cs.unibo.it/BoPi/linearforwarder");
      }
    }
                  
    public bool Input(ChannelValue channel, Pattern f, Env e, VmThread thread, XmlElement next, bool isService)
    {	
      lock (channels) {
        if (!channel.IsLocalChannel()) 
        {
          new RemoteInputDelegate(RemoteInput).BeginInvoke(channel.AsRemoteChannel(), f, e, thread, next, null, null);
          return false;
        }
        else //the channel is not local
        {
          if (!channels.ContainsKey(channel.Location))
            throw new ChannelManagerException("Error channel located at "+ channel.Location +" not found for input");

          Debug.Assert((new TypeChecker()).IsSubtype(((Channel)channels[channel.Location]).Type.AsChan().Carried, f.schemaof()), "The pattern is not exhaustive for the channel" );

          Channel ch = (Channel) channels[channel.Location];
          if (isService) 
          {
            while (!ch.Empty()) 
            {
              Env newEnv = e.Clone();
              bool res = f.patternmatch(newEnv, ch.DequeueValue());
              Debug.Assert(res);
              thread.Fork(next, newEnv, thread.log);
            }
            ch.EnqueueRequest(new MultipleInputRequest(ch, f, e, thread, next));
            return false;
          } 
          else 
          {
            if (!ch.Empty()) 
            {
              bool res = f.patternmatch(e, ch.DequeueValue());
              Debug.Assert(res);
              return true;
            } 
            else 
            {
              ch.EnqueueRequest(new SingleInputRequest(ch, f, e, thread, next));
              return false;
            }
          }
        }
      }
    }
  }
            
  public class ChannelManagerException:Exception
  {
    public ChannelManagerException(String error):base(error){}
  }
}

/*
  Local Variables:
  mode: csharp
  indent-tabs-mode:nil
  tab-width:4
  fill-column:99
  End:
*/
