// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Xml;
using System.IO;
using BoPi.Types;
using BoPi.Common;

namespace BoPi.wsdlgest
{
  public class XmlTypeFactor 
  {
    public static IXmlType BuildType(IType t)
    {
      if (t.IsBottom()) return new XmlBottom();
      if (t.IsString()) return new XmlStringType();
      if (t.IsInt()) return new XmlIntType();
      if (t.IsStringLiteral()) return new XmlStringLiteral(t.AsStringLiteral().Val);
      if (t.IsIntLiteral()) return new XmlIntLiteral(t.AsIntLiteral().Val);
      if (t.IsVoid()) return new XmlVoid();
      if (t.IsChan()) return new XmlChan(BuildType(t.AsChan().Carried), t.AsChan().Capability);
      if (t.IsLabelled()) return new XmlLabelled(t.AsLabelled().Labels, BuildType(t.AsLabelled().Content));
      if (t.IsSequence()) return new XmlSequence(t.AsSequence().Top, t.AsSequence().Tail);
      if (t.IsUnion()) return new XmlUnion(BuildType(t.AsUnion().Fst), BuildType(t.AsUnion().Snd));
      if (t.IsConstantTypeName()) return new XmlConstantTypeName(t.AsConstantTypeName().Name, t.AsConstantTypeName().Entry);
      throw new ApplicationException("XmlTypeFactor.BuildType() undhandled case "+ t.GetType());
    }
  }
	public interface IXmlType: IType
	{
		/// <summary>
		/// Return xmlschema from an elment 
		/// </summary>
		/// <param name="standard">append standard xmlschema value</param>
		/// <param name="extended"> append extende xmlschema bopi value</param>
		/// <param name="globaldec">append globaldeclaration of type</param>
		/// <param name="structure">it rapresent IType structure (choice|sequence|null) that contains this element 
		/// 0 stay for start 1 stay forsequence, 2 stay for choice 3 neither seq nor choice nor start</param>
		/// <param name="alreadydeclarated">array list tha contains all global declaration</param>
		/// <returns>Type name start with element if it is a labelled start with type else</returns>
		String getschema(XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated);
		/// <summary>
		/// check if is possible to write an element in the
		/// standard format L[int] with schema
		/// </summary>
		/// <param name="code"></param>
		/// <param name="st">type environment</param>
		/// <returns>true or false</returns>
		bool issimpletype();
		void getsimplecode(XmlWriter code);
	}

	public class XmlBottom: Bottom,IXmlType
	{
    public String getschema(XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated){
      throw new ApplicationException("XmlBottom.getschema(...)");            
    }
		public bool issimpletype(){
      throw new ApplicationException("XmlBottom.issimpletype(...)");
    }
		public void getsimplecode(XmlWriter code){
      throw new ApplicationException("XmlBottom.getsimplecode(...)");
    }
  }

	public class XmlUnion: Union,IXmlType
	{
		public XmlUnion(IType fst,IType snd):base(fst,snd){}

		public void getsimplecode(XmlWriter code){}

		public bool issimpletype()
		{
			return false;
		}

    public String getschema(XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated)
		{
			String pref="";

			//void+l[dd]
			if ((Fst is XmlVoid) && (Snd is XmlLabelled) && (((XmlLabelled)Snd).Labels is UnionLabel)
				&& (((UnionLabel)((XmlLabelled)Snd).Labels).labels.Count==1))
			{
				String labelname=(String)((UnionLabel)((XmlLabelled)Snd).Labels).labels[0];
				IXmlType content=(IXmlType)((XmlLabelled)Snd).Content;
				standard.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				standard.WriteAttributeString("name",labelname);
				standard.WriteAttributeString("minOccurs","0");
				standard.WriteAttributeString("maxOccurs","1");	
				if (content.issimpletype())
					content.getsimplecode(standard);
				else
				{
					standard.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
					standard.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");
					content.getschema(standard,globaldec,extended,3,alreadydeclarated);
					standard.WriteEndElement();
					standard.WriteEndElement();				
				}
				standard.WriteEndElement();	
				return "elementtns:"+labelname;			
			}
			if ((Fst is XmlLabelled) && (Snd is XmlVoid) && (((XmlLabelled)Fst).Labels is UnionLabel)
				&& (((UnionLabel)((XmlLabelled)Fst).Labels).labels.Count==1))
			{
				String labelname=(String)((UnionLabel)((XmlLabelled)Fst).Labels).labels[0];
				IXmlType content=(IXmlType)((XmlLabelled)Fst).Content;
				standard.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				standard.WriteAttributeString("name",labelname);
				standard.WriteAttributeString("minOccurs","0");
				standard.WriteAttributeString("maxOccurs","1");	
				if (content.issimpletype())
					content.getsimplecode(standard);
				else
				{
					standard.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
					standard.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");
					content.getschema(standard,globaldec,extended,3,alreadydeclarated);
					standard.WriteEndElement();
					standard.WriteEndElement();				
				}
				standard.WriteEndElement();	
				return "elementtns:"+labelname;			
			}

			/***********/

			/* is impossibile that service assume return value different from 
			 * "servicetype" or "servicetypeO" */
			if (alreadydeclarated.Contains("servicetype")) pref="O";
			if (structure==0) 
			{	
				alreadydeclarated.Add("servicetype"+pref);
				standard.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
				standard.WriteAttributeString("name","servicetype"+pref);
			}
			if (structure!=2)
				standard.WriteStartElement("choice","http://www.w3.org/2001/XMLSchema");
			((IXmlType)Fst).getschema(standard,globaldec,extended,2,alreadydeclarated);
			((IXmlType)Snd).getschema(standard,globaldec,extended,2,alreadydeclarated);
			if (structure==0) 
				standard.WriteEndElement();		
			if (structure!=2) 
				standard.WriteEndElement();
			return "typetns:servicetype"+pref;

		}
	}

	public class XmlVoid: Types.Void,IXmlType
	{
    public String getschema(XmlWriter standard,XmlWriter globaldec,XmlWriter extended,int structure, IList alreadydeclarated)
		{			
			if (!alreadydeclarated.Contains("ext:void"))
			{
				extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				extended.WriteAttributeString("name","void");
				extended.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
				extended.WriteEndElement();
				extended.WriteEndElement();
				alreadydeclarated.Add("ext:void");
			}
			if (structure!=0)
			{
				standard.WriteStartElement("element");
				standard.WriteAttributeString("ref","ext:void");
				standard.WriteEndElement();
			}
			return "elementext:void";
		}
		public void getsimplecode(XmlWriter code)
		{
			code.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
			code.WriteEndElement();
		}
		public bool issimpletype()
		{
			return true;
		}
	}

	public class XmlConstantTypeName:ConstantTypeName,IXmlType
	{
		bool VISITED;
		public XmlConstantTypeName(String name, ISymbolTableTypeEntry entry)
						: base(name, entry)
		{ VISITED = false; }

		public String getschema( XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated)
		{
			String labelname="";
			IXmlType content=null;
			if (islist(standard,ref content,ref labelname))
			{
				standard.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				standard.WriteAttributeString("name",labelname);
				standard.WriteAttributeString("minOccurs","0");
				standard.WriteAttributeString("maxOccurs","unbounded");	
				if (content.issimpletype())
					content.getsimplecode(standard);
				else
				{
					standard.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
					standard.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");
					content.getschema(standard,globaldec,extended,3,alreadydeclarated);
					standard.WriteEndElement();
					standard.WriteEndElement();				
				}
				standard.WriteEndElement();	
				return "elementtns:"+labelname;
			}
			else
			{
				if (!alreadydeclarated.Contains("tns:schema_"+Name))
				{
					//add element in the extedend schema
					extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
					extended.WriteAttributeString("name","schema_"+Name);
					extended.WriteAttributeString("type","tns:schema_"+Name);
					extended.WriteEndElement();
					//add type decl in standard schema
					StringWriter sw=new StringWriter();
					XmlWriter constdecl=new XmlTextWriter(sw);
					constdecl.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
					constdecl.WriteAttributeString("name","schema_"+Name);
					alreadydeclarated.Add("tns:schema_"+Name);				
					//((IXmlType)st.LookupName(Name)).getschema(constdecl,globaldec,extended,3,alreadydeclarated);
					((IXmlType)Entry.Type).getschema(constdecl,globaldec,extended,3,alreadydeclarated);

					constdecl.WriteEndElement();
					////////////copy constdecl in global
					XmlUtil.CopyXml(globaldec,sw.ToString());
				}

				if (structure!=0)
				{
					standard.WriteStartElement("element");
					standard.WriteAttributeString("ref","ext:schema_"+Name);
					standard.WriteEndElement();
				}
				return "elementext:schema_"+Name;
			}
		}

		public bool islist(XmlWriter code,ref IXmlType content,ref String labelname )
		{
			IType t = Entry.Type;
			if (t is XmlUnion)
			{
				XmlUnion un=(XmlUnion)t;
				if ((un.Fst is XmlVoid) && (un.Snd is XmlSequence))
				{
					XmlSequence seq=(XmlSequence)un.Snd;
					if (seq.Tail is XmlConstantTypeName)
					{
						XmlConstantTypeName consta=(XmlConstantTypeName)seq.Tail;
						if ( (consta.Name==Name) &&
							(seq.Top is XmlLabelled) && (((XmlLabelled)(seq.Top)).Labels is UnionLabel) &&
							(((UnionLabel)((XmlLabelled)(seq.Top)).Labels).labels.Count==1))
						{
							labelname=(String)(((UnionLabel)((XmlLabelled)(seq.Top)).Labels).labels[0]);
							content=((IXmlType)((XmlLabelled)(seq.Top)).Content);
							return true;

						}

					}
					
				}
			}			
			return false;
		}
		public void getsimplecode(XmlWriter code)
		{
			if (VISITED) return ;
			VISITED=true;
			((IXmlType)Entry.Type).getsimplecode(code);
			VISITED=false;
			return;

		}
		public bool issimpletype()
		{
			bool res;
			if (VISITED) return false;
			VISITED=true;
			res=((IXmlType)Entry.Type).issimpletype();
			VISITED=false;
			return res;
		}
	}



	public class XmlSequence:Sequence,IXmlType
	{
		public XmlSequence(IType top,IType tail):base(top,tail){}
		public String getschema(XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated)
		{
			String pref="";
			if (alreadydeclarated.Contains("servicetype")) pref="O";
			if (structure==0) 
			{
				standard.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
				standard.WriteAttributeString("name","servicetype"+pref);
				alreadydeclarated.Add("servicetype"+pref);
			}
			if (structure!=1)
				standard.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");
			((IXmlType)Top).getschema(standard,globaldec,extended,1,alreadydeclarated);
			((IXmlType)Tail).getschema(standard,globaldec,extended,1,alreadydeclarated);
			if (structure==0) 
				standard.WriteEndElement();		
			if (structure!=1) 
				standard.WriteEndElement();
			return "typetns:servicetype"+pref;

		}
		public bool issimpletype()
		{
			return false;
		}
		public void getsimplecode(XmlWriter code){}
	}

	public class XmlLabelled:Labelled,IXmlType
	{
		public XmlLabelled(LabelsSet labels, IType content):base(labels,content){}
		public bool issimpletype()
		{

			return false;
		}
		public void getsimplecode(XmlWriter code){}
		public String getschema( XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated)
		{
			int cont=0;
			if (Labels is AnyLabel)
			{
				while (alreadydeclarated.Contains("tns:anylabel"+cont.ToString())) cont++;
				extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				extended.WriteAttributeString("name","anylabel"+cont.ToString());
				extended.WriteAttributeString("type","tns:anylabel"+cont.ToString());
				extended.WriteEndElement();
				alreadydeclarated.Add("tns:anylabel"+cont.ToString());
				StringWriter sw=new StringWriter();
				XmlWriter labelschema=new XmlTextWriter(sw);
				labelschema.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
				labelschema.WriteAttributeString("name","anylabel"+cont.ToString());
				labelschema.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");
				((IXmlType)Content).getschema(labelschema,globaldec,extended,1,alreadydeclarated);
				labelschema.WriteEndElement();
				labelschema.WriteEndElement();
				//copy labelschema to globaldec
				XmlUtil.CopyXml(globaldec,sw.ToString());
				if (structure!=0)
				{
					standard.WriteStartElement("element");
					standard.WriteAttributeString("ref","ext:anylabel"+cont.ToString());
					standard.WriteEndElement();
				}
				return "elementext:anylabel"+cont.ToString();
			}	
			else if (Labels is UnionLabel)
			{
				bool issimple;
				issimple=((IXmlType)Content).issimpletype();
				ISet labels=((UnionLabel)Labels).labels;
				StringWriter sw=new StringWriter();
				XmlWriter labelschema=new XmlTextWriter(sw);
				if (labels.Count>1)
				{
					while (alreadydeclarated.Contains("tns:unionlabel"+cont.ToString())) cont++;
					alreadydeclarated.Add("tns:unionlabel"+cont.ToString());
					extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
					extended.WriteAttributeString("name","unionlabel"+cont.ToString());
					extended.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
					extended.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");				
					foreach (String str in labels)
					{
						extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
						extended.WriteAttributeString("name",str);
						extended.WriteAttributeString("type","tns:unionlabel"+cont.ToString());
						extended.WriteEndElement();
					}
					extended.WriteEndElement();
					extended.WriteEndElement();
					extended.WriteEndElement();
					labelschema.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
					labelschema.WriteAttributeString("name","unionlabel"+cont.ToString());
					labelschema.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");
					((IXmlType)Content).getschema(labelschema,globaldec,extended,2,alreadydeclarated);
					labelschema.WriteEndElement();
					labelschema.WriteEndElement();
					XmlUtil.CopyXml(globaldec,sw.ToString());
					if (structure!=0)
					{
						standard.WriteStartElement("element");
						standard.WriteAttributeString("ref","ext:unionlabel"+cont.ToString());
						standard.WriteEndElement();
					}
					return "elementext:unionlabel"+cont.ToString();
				}
				else
				{
					String name=(String)labels[0];
					standard.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
					standard.WriteAttributeString("name",name);
					if (!issimple)
					{						
						standard.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
						standard.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");
						((IXmlType)Content).getschema(standard,globaldec,extended,1,alreadydeclarated);
						standard.WriteEndElement();
						standard.WriteEndElement();
					}
					else
                        ((IXmlType)Content).getsimplecode(standard);
                    standard.WriteEndElement();
					return "elementtns:"+name;


				}
			}
			else 
			{
				while (alreadydeclarated.Contains("tns:differencelabel"+cont.ToString())) cont++;
				alreadydeclarated.Add("tns:differencelabel"+cont.ToString());
				extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				extended.WriteAttributeString("name","differencelabel"+cont.ToString());
				extended.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
				extended.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");
				ISet labels=((DifferenceLabel)Labels).diffLabels.labels;
				foreach (String str in labels)
				{
					extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
					extended.WriteAttributeString("name",str);
					extended.WriteAttributeString("type","tns:differencelabel"+cont.ToString());
					extended.WriteEndElement();
				}
				extended.WriteEndElement();
				extended.WriteEndElement();
				extended.WriteEndElement();
				StringWriter sw=new StringWriter();
				XmlWriter labelschema=new XmlTextWriter(sw);
				labelschema.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
				labelschema.WriteAttributeString("name","differencelabel"+cont.ToString());
				labelschema.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");
				((IXmlType)Content).getschema(labelschema,globaldec,extended,2,alreadydeclarated);
				labelschema.WriteEndElement();
				labelschema.WriteEndElement();
				XmlUtil.CopyXml(globaldec,sw.ToString());
				if (structure!=0)
				{
					standard.WriteStartElement("element");
					standard.WriteAttributeString("ref","ext:differencelabel"+cont.ToString());
					standard.WriteEndElement();
				}
				return "elementext:differencelabel"+cont.ToString();
			}
		}
	}	
	

	public class XmlIntLiteral:IntLiteral,IXmlType
	{
		public XmlIntLiteral(int val):base(val){}
		public void getsimplecode(XmlWriter code)
		{
			code.WriteStartElement("simpleType","http://www.w3.org/2001/XMLSchema");
			code.WriteStartElement("restriction","http://www.w3.org/2001/XMLSchema");
			code.WriteAttributeString("base","s:int");
			code.WriteStartElement("enumeration","http://www.w3.org/2001/XMLSchema");
			code.WriteAttributeString("value",Val.ToString());
			code.WriteEndElement();
			code.WriteEndElement();
			code.WriteEndElement();
		}
		public bool issimpletype()
		{
			return true;
		}
		public String getschema(XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated)
		{
			if (!alreadydeclarated.Contains("intLit"+Val.ToString()))
			{
				extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				extended.WriteAttributeString("name","intLit"+Val.ToString());
				extended.WriteStartElement("simpleType","http://www.w3.org/2001/XMLSchema");
				extended.WriteStartElement("restriction");
				extended.WriteAttributeString("base","s:int");
				extended.WriteStartElement("enumeration");
				extended.WriteAttributeString("value",Val.ToString());
				extended.WriteEndElement();//enum
				extended.WriteEndElement();//rest
				extended.WriteEndElement();//simple
				extended.WriteEndElement();//eleme
				alreadydeclarated.Add("intLit"+Val);

			}
			if (structure!=0)
			{
				standard.WriteStartElement("element");
				standard.WriteAttributeString("ref","ext:intLit"+Val.ToString());
				standard.WriteEndElement();
			}
			return "elementext:intLit"+Val.ToString();
		}
	}


	public class XmlIntType:IntType,IXmlType
	{
		public void getsimplecode(XmlWriter code)
		{
			code.WriteAttributeString("type","s:int");
		}

		public bool issimpletype()
		{
			return true;
		}
		public String getschema(XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated)
		{
			if (!alreadydeclarated.Contains("int"))
			{
				extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				extended.WriteAttributeString("name","int");
				extended.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
				extended.WriteEndElement();
				extended.WriteEndElement();
				alreadydeclarated.Add("int");
			}
			if (structure!=0)
			{
				standard.WriteStartElement("element");
				standard.WriteAttributeString("ref","ext:int");
				standard.WriteEndElement();
			}
			return "elementext:int";
	
		}

	
	}



	public class XmlStringLiteral:StringLiteral,IXmlType
	{
		public XmlStringLiteral(String val):base(val){}
		public void getsimplecode(XmlWriter code)
		{
			code.WriteStartElement("simpleType","http://www.w3.org/2001/XMLSchema");
			code.WriteStartElement("restriction","http://www.w3.org/2001/XMLSchema");
			code.WriteAttributeString("base","s:string");
			code.WriteStartElement("enumeration","http://www.w3.org/2001/XMLSchema");
			code.WriteAttributeString("value",Val);
			code.WriteEndElement();
			code.WriteEndElement();
			code.WriteEndElement();
		}

		public bool issimpletype()
		{
			return true;
		}

		public String getschema(XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated)
        {
			if (!alreadydeclarated.Contains("stringLit"+Val.GetHashCode().ToString()))
			{
				extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				extended.WriteAttributeString("name","stringLit"+Val.GetHashCode().ToString());
				extended.WriteStartElement("simpleType","http://www.w3.org/2001/XMLSchema");
				extended.WriteStartElement("restriction");
				extended.WriteAttributeString("base","s:string");
				extended.WriteStartElement("enumeration");
				extended.WriteAttributeString("value",Val);
				extended.WriteEndElement();//enum
				extended.WriteEndElement();//rest
				extended.WriteEndElement();//simple
				extended.WriteEndElement();//eleme
				alreadydeclarated.Add("stringLit"+Val.GetHashCode().ToString());
			}
			if (structure!=0)
			{
				standard.WriteStartElement("element");
				standard.WriteAttributeString("ref","ext:stringLit"+Val.GetHashCode().ToString());
				standard.WriteEndElement();
			}
			return "elementext:stringLit"+Val.GetHashCode().ToString();

		}


	}


	public class XmlStringType:StringType ,IXmlType
	{
		public void getsimplecode(XmlWriter code)
		{
			code.WriteAttributeString("type","s:string");
		}

		public bool issimpletype()
		{
			return true;
		}

		public String getschema(XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated)
		{
			if (!alreadydeclarated.Contains("string"))
			{
				extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
				extended.WriteAttributeString("name","string");
				extended.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
				extended.WriteEndElement();
				extended.WriteEndElement();
				alreadydeclarated.Add("string");
			}
			if (structure!=0)
			{
				standard.WriteStartElement("element");
				standard.WriteAttributeString("ref","ext:string");
				standard.WriteEndElement();
			}
			return "elementext:string";
	
		}
	}

	public class XmlChan:Chan,IXmlType
	{
		public XmlChan(IType t, int capability):base(t,capability){}
		public XmlChan(IType t, Chan.CAPABILITY capability):base(t,capability){}

		public bool issimpletype()
		{
			return false;
		}
		public void getsimplecode(XmlWriter code)
		{}

		public String getschema(XmlWriter standard, XmlWriter globaldec, XmlWriter extended, int structure, IList alreadydeclarated)
		{
      int cont=0;
			String cap="";
			if (Capability==Chan.CAPABILITY.OUT) cap="O";
			if (Capability==Chan.CAPABILITY.IN) cap="I";
			if (Capability==Chan.CAPABILITY.INOUT) cap="IO";
			while (alreadydeclarated.Contains("tns:chan_"+cap+cont.ToString())) cont++;
			extended.WriteStartElement("element","http://www.w3.org/2001/XMLSchema");
			extended.WriteAttributeString("name","chan_"+cap+cont.ToString());
			extended.WriteAttributeString("type","tns:chan_"+cap+cont.ToString());
			extended.WriteEndElement();
			alreadydeclarated.Add("tns:chan_"+cap+cont.ToString());
			StringWriter sw=new StringWriter();
			XmlWriter chanschema=new XmlTextWriter(sw);
			chanschema.WriteStartElement("complexType","http://www.w3.org/2001/XMLSchema");
			chanschema.WriteAttributeString("name","chan_"+cap+cont.ToString());
			chanschema.WriteStartElement("sequence","http://www.w3.org/2001/XMLSchema");				
			((IXmlType)Carried).getschema(chanschema,globaldec,extended,1,alreadydeclarated);
			chanschema.WriteEndElement();
			chanschema.WriteEndElement();
			XmlUtil.CopyXml(globaldec,sw.ToString());
			//copy labelschema to globaldec
			if (structure!=0)
			{
				standard.WriteStartElement("element");
				standard.WriteAttributeString("ref","ext:chan_"+cap+cont.ToString());
				standard.WriteEndElement();
			}
			return "elementext:chan_"+cap+cont.ToString();
		}
	}
	public class XmlErrorType:ErrorType
	{		
	}
}
