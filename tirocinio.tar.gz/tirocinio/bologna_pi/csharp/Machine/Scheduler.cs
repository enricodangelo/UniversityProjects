// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Xml;
using System.Diagnostics;
using System.Threading;
using System.Runtime.Remoting.Messaging;
using BoPi.wsdlgest;
using BoPi.Web;
using BoPi.Types;
using BoPi.Common;

namespace BoPi.Machine
{
	public interface IScheduler
	{
		//void Fork(XmlElement current, TypeSymbolTable schemas, Env env);
		void Fork(XmlElement current, TypeSymbolTable schemas, Env env, ILog log);
		//void AddProgram(String compiled);
		void AddProgram(String compiled, ILog log);
	}
  
	public class Scheduler : IScheduler
	{
		private Queue ready;
		private ArrayList blocked;
		private ChannelManager chanman;
    private bool keepAlive;
    
		public Scheduler(ChannelManager chanman, bool keepAlive)
		{
			this.ready = new Queue();
			this.blocked = new ArrayList();
			this.chanman = chanman;
      this.keepAlive = keepAlive;
		}

		public void AddProgram(String compiled, ILog log)
		{
			lock (this) {
				ready.Enqueue(new VmThread(compiled, this, chanman, log));
				Monitor.Pulse(this);
			}
		}

		public void Run()
		{
			bool run = true;
			do {
				VmThread thread;
        do {
          thread = null;
          lock (this) {
            if (ready.Count != 0)
              thread = (VmThread) ready.Dequeue();
          }

          if (thread != null)
						thread.Next();
        } while (thread != null);

        lock (this) {
          if (keepAlive || blocked.Count != 0) {
            Console.WriteLine("IDLE [" + WebServer.GetLocalMachine() + "]");
            Monitor.Wait(this);
          }
					run = keepAlive || ready.Count != 0;
        }
			} while (run);

      WebServer.Stop();
		}
    
	public void Fork(XmlElement current, TypeSymbolTable schemas, Env e, ILog log)
	{
		lock (this) {
			ready.Enqueue(new VmThread(current, schemas, e, this, chanman, log));
			Monitor.Pulse(this);
		}
	}

		public void Ready(VmThread thread)
		{
			lock (this) {
				ready.Enqueue(thread);
				Monitor.Pulse(this);
			}
		}

		public void Block(VmThread thread)
		{
			lock (this) {
				blocked.Add(thread);
			}
		}

		public void Unblock(VmThread thread)
		{
			lock (this) {
				Debug.Assert(blocked.Contains(thread));
				blocked.Remove(thread);
			}
		}

		public void Kill(VmThread thread)
		{
			lock (this) {
				Debug.Assert(blocked.Contains(thread));
				blocked.Remove(thread);
			}
		}
	}

  public class VmThread
	{
		private XmlNamespaceManager nsmgr; // FOR DOM
		private TypeSymbolTable schemas;
		private Env e; // env of the thread
		private XmlElement current; // element to be executed
		private Scheduler scheduler;
		private ChannelManager chanman;
    private ITypeChecker typeChecker = new TypeChecker();
		public ILog log;	//log location, socket or file
		static public uint tid = 0;
    
		bool CheckSchemas(XmlDocument program)
		{
			String location,soapaction,namespaceuri; //useless in this contest
      String error;
			foreach (XmlElement pattern in program.SelectNodes("//opcode:pattern", nsmgr)) {
        IType t = ParsePattern(pattern.FirstChild).schemaof();
        if (!typeChecker.IsCorrect(t, out error) || !typeChecker.IsDetermined(t)) {
					MachineOutput.PrintError("Invalid pattern " + error);
					MachineOutput.Print(pattern.OuterXml);
					return false;
				}
			}

			foreach (XmlNode schema in program.SelectNodes("//opcode:schemadec",nsmgr)) {
        IType t = ParseSchema(schema.FirstChild);
				if (!typeChecker.IsCorrect(t, out error)) {
					MachineOutput.PrintError("Invalid schema declaration " + error);
					MachineOutput.Print(schema.FirstChild.OuterXml);
					return false;
				}
			}

			foreach (XmlNode schema in program.SelectNodes("//opcode:new",nsmgr)) {
        IType t = ParseSchema(schema.FirstChild);
				if (!typeChecker.IsCorrect(t, out error) || !typeChecker.IsDetermined(t)) {
					MachineOutput.PrintError("Invalid new channel declaration " + error );
					MachineOutput.Print(schema.FirstChild.OuterXml);
					return false;
				}
			}

			foreach (XmlNode schema in program.SelectNodes("//opcode:import",nsmgr)) {
        IType t = ParseSchema(schema.FirstChild);
        if (!typeChecker.IsCorrect(t, out error) || !typeChecker.IsDetermined(t)) {
					MachineOutput.PrintError("Invalid new channel declaration");
					MachineOutput.Print(schema.FirstChild.OuterXml);
					return false;
				}

				if (schema.Attributes["wsdl"].Value == "")
					program = null;
				else {
					if (schema.Attributes["location"].Value == "") {
						try {
							Wsdl2BoPi converter = new Wsdl2BoPi(Web.Webclient.Download(schema.Attributes["wsdl"].Value));
							IType channeltype= converter.getBoPifromWsdl(out location,out soapaction,out namespaceuri);
							schema.Attributes["location"].Value=location;
						} catch (Exception ex) {
							MachineOutput.PrintError("The channel at " + schema.Attributes["wsdl"].Value + " cannot be imported\n" + ex);
							return false;
						}
					}
				}
			}
			return true;
		}

		public VmThread(XmlElement current, TypeSymbolTable schemas, Env e, Scheduler scheduler, ChannelManager chanman, ILog log)
		{
			this.current = current;
			this.scheduler = scheduler;
			nsmgr = new XmlNamespaceManager(current.OwnerDocument.NameTable);
			// are these needed? they should have been added by the other constructor
			nsmgr.AddNamespace("opcode", "http://cs.unibo.it/BoPi/opcode");
			nsmgr.AddNamespace("value", "http://cs.unibo.it/BoPi/value");
			this.schemas = schemas;
			this.e = e;
			this.chanman = chanman;
			this.log = log;
			tid++;
		}
		
		public VmThread(String xmlprogram, Scheduler scheduler, ChannelManager chanman, ILog log)
		{
			this.scheduler = scheduler;
			XmlDocument program = new XmlDocument();
			schemas = new TypeSymbolTable();
			nsmgr = new XmlNamespaceManager(program.NameTable);
			nsmgr.AddNamespace("opcode", "http://cs.unibo.it/BoPi/opcode");
			nsmgr.AddNamespace("value", "http://cs.unibo.it/BoPi/value");
			program.LoadXml(xmlprogram);
			XmlNode schemadecl = program.SelectSingleNode("//opcode:BoPi/opcode:schemadecl", nsmgr);
			foreach (XmlElement schema in schemadecl.ChildNodes)
				schemas.New(schema.GetAttribute("name"), null);

			foreach (XmlElement schema in schemadecl.ChildNodes) {
				ISymbolTableEntry entry = schemas.Lookup(schema.GetAttribute("name"));
				entry.Type = ParseSchema(schema.FirstChild);
			}

			XmlElement process = (XmlElement) program.DocumentElement.SelectSingleNode("opcode:process", nsmgr);
			int envSize = Int32.Parse(process.GetAttribute("env-size"));
			e = new Env(envSize);
			current = (XmlElement) process.FirstChild;
			this.chanman = chanman;
			this.log = log;
			tid++;
			if (!CheckSchemas(program))
				current = null;
		}	

		public void Ready(XmlElement next)
		{ 
			current = next;
			scheduler.Ready(this);
		}

		public void Block()
		{ scheduler.Block(this); }

		public void Unblock(XmlElement next)
		{
			scheduler.Unblock(this);
			Ready(next);
		}

		public void Fork(XmlElement current, Env e, ILog log)
		{ scheduler.Fork(current, schemas, e, log); }

		public void Kill(string message)
		{
			Console.WriteLine(message);
			scheduler.Kill(this);
		}

		public void OnReceiveNewChannel(IAsyncResult result)
		{
      AsyncResult ar = (AsyncResult) result;
      Webclient.UploadDelegate ud = (Webclient.UploadDelegate) ar.AsyncDelegate;
      IList par = (IList) ar.AsyncState;
      int target = (int) par[1];
      try {
        XmlNode res = ud.EndInvoke(result);
        if (res == null || res.Attributes["location"] == null || res.Attributes["location"].Value == "")
          Kill("An error occured creating remote channel: The channel reference lacks the location");
        else {				
          string location = res.Attributes["location"].Value;
          string wsdlLocation = location + "?wsdl";
          String chanLocation, soapAction, namespaceUri;;
          Wsdl2BoPi decoder = new Wsdl2BoPi(Webclient.Download(wsdlLocation));
          IType type = decoder.getBoPifromWsdl(out chanLocation, out soapAction, out namespaceUri);
          RemoteChannel chan = new RemoteChannel(wsdlLocation, type.AsChan(), chanLocation, soapAction, namespaceUri);
          e.Set(target, chan);
          Unblock((XmlElement) par[0]);
        }
      } catch (Exception ex) { 
        Kill("An error occured creating remote channel: " + ex);
      }
		}
    
    public void OnReceiveWsdl(IAsyncResult result)
    {
      AsyncResult ar = (AsyncResult) result;
      Webclient.DownloadDelegate ud = (Webclient.DownloadDelegate) ar.AsyncDelegate;
      IList par = (IList) ar.AsyncState;
      int target = (int) par[1];
      string wsdlLocation = (String)par[2];
      try {
        string wsdl = ud.EndInvoke(result);
        String chanLocation, soapAction, namespaceUri;;
        Wsdl2BoPi decoder = new Wsdl2BoPi(wsdl);
        IType type = decoder.getBoPifromWsdl(out chanLocation, out soapAction, out namespaceUri);
        RemoteChannel chan = new RemoteChannel(wsdlLocation, type.AsChan(), chanLocation, soapAction, namespaceUri);
        e.Set(target, chan);
        Unblock((XmlElement) par[0]);
      } catch (Exception ex) { 
        string message = "An error occured importing the channel " + wsdlLocation + ": "+ ex; 
        Kill(message);
      }
    }
    
		public void Next()		
		{
      if (current == null)
				return;
      //Console.WriteLine("Executing {0}", current.LocalName);
			switch (current.LocalName) {
				case "import":
				{
          String wsdl = current.Attributes["wsdl"].Value;
          IList par = new ArrayList();

	WriteLog((XmlElement)current, e);
	  
          par.Add(current.NextSibling);
          par.Add(Int32.Parse(current.GetAttribute("target")));
          par.Add(wsdl);
					Block();
          new Web.Webclient.DownloadDelegate(Webclient.Download).BeginInvoke(wsdl, new AsyncCallback(OnReceiveWsdl), par);
				}
				break;

				case "new":
				{
					IType schematype = ParseSchema(current.FirstChild);
					String location;
					if (current.Attributes["location"]!=null) 
					{
						location=current.Attributes["location"].Value;
						if (location.StartsWith("http://")) 
						{
							if (location.StartsWith(WebServer.GetLocalMachine())) 
							{
								location = chanman.AddChannel(location.Substring(WebServer.GetLocalMachine().Length),schematype);
							} 
							else { //remote new
								Bopi2Wsdl encoder = new Bopi2Wsdl();
								String tosend = encoder.GetWsdlFromBoPi(schematype.AsChan(), "bopichanaction/", location);
								tosend = tosend.Substring(tosend.IndexOf("\n"));
								IList par = new ArrayList();
								
								WriteLog((XmlElement)current, e);
								
								par.Add(current.NextSibling);
								par.Add(Int32.Parse(current.GetAttribute("target")));
								Block();
								new Web.Webclient.UploadDelegate(new Web.Webclient().Upload).BeginInvoke(location,Common.XmlUtil.AddSoap(tosend),"http://cs.unibo.it/BoPi/addchannel",new AsyncCallback(OnReceiveNewChannel), par);
								return;
							}
						} else //local new
						{
							location = chanman.AddChannel(location,schematype);
						}
					} 
					else // local new without location
					{
						location = chanman.AddChannel(schematype);
					}
					int target = Int32.Parse(current.GetAttribute("target"));
					e.Set(target, new LocalChannel(location+"?wsdl", location, schematype.AsChan()));

					WriteLog((XmlElement)current, e);
					
					Ready((XmlElement) current.NextSibling);
				}
				break;

				case "spawn":
				{
					int parentEnvSize = Int32.Parse(current.GetAttribute("parent-env-size"));
					int localEnvSize = Int32.Parse(current.GetAttribute("local-env-size"));
					scheduler.Fork((XmlElement) current.FirstChild, schemas, e.Clone(parentEnvSize, parentEnvSize + localEnvSize), this.log);

					WriteLog((XmlElement)current, e);
					
					Ready((XmlElement) current.NextSibling);
				}
				break;

				case "select":
				{
					ArrayList continuations = new ArrayList();
					ArrayList locations = new ArrayList();
					ArrayList patterns = new ArrayList();
					foreach (XmlElement branch in current.SelectNodes("opcode:branch", nsmgr)) {
						continuations.Add(branch.SelectSingleNode("opcode:process", nsmgr).FirstChild);
						XmlElement receive = (XmlElement) branch.SelectSingleNode("opcode:receive", nsmgr);
						int ch = Int32.Parse(receive.GetAttribute("ch"));
						String location= ((ChannelValue) e.Get(ch)).Location;
						locations.Add(location);
						patterns.Add(ParsePattern(branch.SelectSingleNode("opcode:pattern", nsmgr).FirstChild));
					}
					/*
					int res = chanman.Select(locations, patterns, e, sender, this, conts);
					if (res !=- 1) {
						sender.setCurrent((XmlElement) conts[res]);
						return true;
					} else
						return false;
					*/

					WriteLog((XmlElement)current, e);
					
					Debug.Assert(false);
				}
				break;

 				case "join-select":
 				{
					bool isService = Boolean.Parse(current.Attributes["service", ""].Value);
					ArrayList channels = new ArrayList();
					foreach (XmlElement channel in current.SelectNodes("opcode:channels/opcode:channel", nsmgr)) {
						int channelIndex = Int32.Parse(channel.GetAttribute("ch"));
 						String location = ((ChannelValue) e.Get(channelIndex)).Location;
 						Channel ch = chanman.GetChannel(location);
 						System.Diagnostics.Debug.Assert(ch != null);
						channels.Add(ch);
					}

 					ArrayList rows = new ArrayList();
 					foreach (XmlElement row in current.SelectNodes("opcode:branch", nsmgr)) {
 						ArrayList atoms = new ArrayList();
 						foreach (XmlElement atom in row.SelectNodes("opcode:receive", nsmgr)) {
							int channelIndex = Int32.Parse(atom.GetAttribute("index"));
							Debug.Assert(channelIndex >= 0 && channelIndex < channels.Count);
 							Pattern pattern = ParsePattern(atom.SelectSingleNode("opcode:pattern", nsmgr).FirstChild);
 							atoms.Add(new JoinPatternAtom((Channel) channels[channelIndex], channelIndex, pattern));
 						}
 						rows.Add(new JoinPatternRow(atoms, (XmlElement) row.SelectSingleNode("opcode:process", nsmgr).FirstChild));
 					}

					IJoinAutomaton automaton = new JoinAutomaton(rows, nsmgr, (XmlElement) current.SelectSingleNode("opcode:automaton", nsmgr));
					//IJoinAutomaton automaton = new NaiveJoinAutomaton(rows);

					if (isService) {
						chanman.ServiceJoinSelect(channels, rows, automaton, e, this);
					} else {
						Block();
						XmlElement next = chanman.JoinSelect(channels, rows, automaton, e, this);
						if (next != null) Unblock(next);
					}

					WriteLog((XmlElement)current, e);
 				}
				break;

				case "match":
				{
					WriteLog((XmlElement)current, e);
					IValue v = ParseExpression((XmlElement) current.SelectSingleNode("opcode:expression", nsmgr).FirstChild, e);
					foreach (XmlElement branch in current.SelectNodes("opcode:branch", nsmgr)) {
						Pattern f = ParsePattern(branch.SelectSingleNode("opcode:pattern", nsmgr).FirstChild);
						if (f.patternmatch(e, v)) {
							Ready((XmlElement) branch.SelectSingleNode("opcode:process", nsmgr).FirstChild);
							return;
						}
					}
				}
				break;

				case "store":
				{
					int target = Int32.Parse(current.GetAttribute("target"));
					IValue v =  ParseExpression((XmlElement) current.FirstChild, e);
					e.Set(target, v);

					WriteLog((XmlElement)current, e);
					
					Ready((XmlElement) current.NextSibling);
				}
				break;

				case "send":
				{
					int channelIndex = Int32.Parse(current.GetAttribute("ch"));
					ChannelValue chan = (ChannelValue) e.Get(channelIndex);
					IValue v = ParseExpression((XmlElement) current.SelectSingleNode("opcode:expression", nsmgr).FirstChild, e);
					chanman.Output(chan, v);

					WriteLog((XmlElement)current, e);
					
					Ready((XmlElement) current.NextSibling);
				}
				break;

				case "receive":
				{
					int channelIndex = Int32.Parse(current.GetAttribute("ch"));
					ChannelValue channel = (ChannelValue) e.Get(channelIndex);
					Pattern f = ParsePattern(current.SelectSingleNode("opcode:pattern", nsmgr).FirstChild);
					Block();

					WriteLog((XmlElement)current, e);
					
					XmlElement next = (XmlElement) current.NextSibling;
					if (chanman.Input(channel, f, e, this, next, false))
						Unblock(next);
				}
				break;

				case "service":
				{
					int channelIndex = Int32.Parse(current.GetAttribute("ch"));
					ChannelValue channel = (ChannelValue) e.Get(channelIndex);
					Pattern f = ParsePattern(current.SelectSingleNode("opcode:pattern", nsmgr).FirstChild);

					WriteLog((XmlElement)current, e);
					
					chanman.Input(channel, f, e, this, (XmlElement) current.NextSibling, true);
				}
				break;
			}
		}

		private uint GetTid()
		{
			return tid;
		}

		private void WriteLog(XmlElement current, Env e)
		{
			if (this.log == null) {
				Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>> log e' null");
			}
			if (this.log != null) {
				this.log.WriteLog(this.GetTid(), current, e);
			}
		}

		private IValue ParseExpression(XmlElement node, Env env)
		{
			Debug.Assert(node != null);
			Debug.Assert(node.NamespaceURI == "http://cs.unibo.it/BoPi/opcode");
			switch (node.LocalName) {
				case "void":
					return new VoidValue();
				case "load":
					{
						int index = Int32.Parse(node.GetAttribute("index"));
						return e.Get(index);
					}
				case "intlit":
					return new IntValue(Int32.Parse(node.InnerText));
				case "stringlit":
					return new StringValue(node.InnerText);
				case "seq":
					{
						IValue v1 = ParseExpression((XmlElement) node.ChildNodes[0], env);
						IValue v2 = ParseExpression((XmlElement) node.ChildNodes[1], env);
						return new SequenceValue(v1, v2);
					}
				case "binop":
					{
						IValue v1 = ParseExpression((XmlElement) node.ChildNodes[0], env);
						IValue v2 = ParseExpression((XmlElement) node.ChildNodes[1], env);
						string op = node.GetAttribute("op");
						switch (op) {
							case "add":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 + (IntValue) v2;
									else if ((v1 is StringValue) && (v2 is StringValue)) return (StringValue) v1 + (StringValue) v2;
									else throw new ApplicationException("invalid op for add");
								}
							case "sub":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 - (IntValue) v2;
									else throw new ApplicationException("invalid op for sub");
								}
							case "mul":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 * (IntValue) v2;
									else throw new ApplicationException("invalid op for mul");
								}
							case "div":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 / (IntValue) v2;
									else throw new ApplicationException("invalid op for div");
								}
							case "eq":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 == (IntValue) v2;
									else if ((v1 is StringValue) && (v2 is StringValue)) return (StringValue) v1 == (StringValue) v2;
									else throw new ApplicationException("invalid op for eq");
								}
							case "neq":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 == (IntValue) v2;
									else if ((v1 is StringValue) && (v2 is StringValue)) return (StringValue) v1 != (StringValue) v2;
									else throw new ApplicationException("invalid op for neq");
								}
							case "gt":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 > (IntValue) v2;
									else throw new ApplicationException("invalid op for gt");
								}
							case "ge":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 >= (IntValue) v2;
									else throw new ApplicationException("invalid op for ge");
								}
							case "lt":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 < (IntValue) v2;
									else throw new ApplicationException("invalid op for lt");
								}
							case "le":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 <= (IntValue) v2;
									else throw new ApplicationException("invalid op for le");
								}
							case "and":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 & (IntValue) v2;
									else throw new ApplicationException("invalid op for and");
								}
							case "or":
								{
									if ((v1 is IntValue) && (v2 is IntValue)) return (IntValue) v1 | (IntValue) v2;
									else throw new ApplicationException("invalid op for or");
								}
							default:
								throw new ApplicationException("unknown binary operator " + op);
						}
					}
				case "unop":
					{
						IValue v = ParseExpression((XmlElement) node.FirstChild, env);
						string op = node.GetAttribute("op");
						switch (op) {
							case "neg":
								{
									if (v is IntValue) return -((IntValue) v);
									else throw new ApplicationException("invalid op for neg");
								}
							case "not":
								{
									if (v is IntValue) return !((IntValue) v);
									else throw new ApplicationException("invalid op for not");
								}
							default:
								throw new ApplicationException("invalid unary operator " + op);
						}
					}
				case "labelled":
					return new LabelValue(node.GetAttribute("label"), ParseExpression((XmlElement) node.FirstChild, env));
				default:
					throw new ApplicationException("invalid expression " + node.LocalName);
			}
		}

		private Pattern ParsePattern(XmlNode toparse)
		{
			Pattern first;
			Pattern seq = null;
			XmlNode pattern = toparse;
			if (toparse.NamespaceURI != "http://cs.unibo.it/BoPi/opcode")
				throw new ApplicationException("Invalid pattern in source");

			while (pattern != null) {
				switch (pattern.LocalName) {
					case "pattern":
						first = null;
						Debug.Assert(false);
						break;
					case "schema":
						first = new SchemaPattern(ParseSchema(pattern.FirstChild));
						break;
					case "bind":
						first = new VarPattern(Int32.Parse(pattern.Attributes["index", ""].Value), ParsePattern(pattern.FirstChild));
						break;
					case "labelled":
						ISet labels = new ArraySet();
						LabelsSet res;
						if (pattern.FirstChild.LocalName == "unionlabel") {
							foreach (XmlNode label in pattern.FirstChild.ChildNodes)
								labels.Add(label.Attributes["name", ""].Value);
							res = new UnionLabel(labels);
						} else if (pattern.FirstChild.LocalName == "anylabel") {
							res = new AnyLabel();
						} else {
							foreach (XmlNode label in pattern.FirstChild.ChildNodes)
								labels.Add(label.Attributes["name", ""].Value);
							res = new DifferenceLabel(new UnionLabel(labels));
						}
						first = new LabelPattern(res, ParsePattern(pattern.ChildNodes[1]));			
						break;
					default:
						throw new ApplicationException("Invalid pattern in source");
				}

				if (seq == null)
					seq = first;
				else
					seq = new SequencePattern(seq, first);
				pattern = pattern.NextSibling;
			}

			if (seq == null) return new SchemaPattern(new Types.Void());
			return seq;
		}

		private IType ParseSchema(XmlNode schema)
		{
			if (schema.NamespaceURI != "http://cs.unibo.it/BoPi/opcode")
				throw new ApplicationException("Invalid schema in source");
			switch (schema.LocalName)
			{
				case "schema":				
					return ParseSchema(schema.FirstChild);				
				case "schemaref": 
					{
						string name = schema.Attributes["name", ""].Value;
						return new XmlConstantTypeName(name, (ISymbolTableTypeEntry) schemas.Lookup(name));
					}
				case "void":
					return new XmlVoid();					
				case "choice":
					return new XmlUnion(ParseSchema(schema.ChildNodes[0]), ParseSchema(schema.ChildNodes[1]));					
				case "sequence":
					return new XmlSequence(ParseSchema(schema.ChildNodes[0]), ParseSchema(schema.ChildNodes[1]));
				case "string":
					return new XmlStringType();
				case "int":
					return new XmlIntType();
				case "intLit":
					return new XmlIntLiteral(Int32.Parse(schema.InnerText));
				case "stringLit":
					return new XmlStringLiteral(schema.InnerText);					
				case "chan":
					int cap;
					if (schema.Attributes["capability", ""].Value == "I")
						cap = -1;
					else if (schema.Attributes["capability", ""].Value == "IO")
						cap = 2;
					else
						cap = 1;
					return new XmlChan(ParseSchema(schema.FirstChild), cap);					
				case "labelled":
					ArraySet labels= new ArraySet();
					LabelsSet res;
					if (schema.FirstChild.LocalName == "unionlabel")
					{
						foreach (XmlNode label in schema.FirstChild.ChildNodes)
							labels.Add(label.Attributes["name", ""].Value);
						res = new UnionLabel(labels);
					}
					else if (schema.FirstChild.LocalName == "anylabel")
						res = new AnyLabel();
					else
					{
						foreach (XmlNode label in schema.FirstChild.ChildNodes)
							labels.Add(label.Attributes["name", ""].Value);
						res = new DifferenceLabel(new UnionLabel(labels));
					}
					return new XmlLabelled(res, ParseSchema(schema.ChildNodes[1]));			
			}
			throw new ApplicationException("Invalid schema in source");
		}
	}
}

