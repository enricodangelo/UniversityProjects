using System;
using System.Net.Sockets;
using System.IO;

namespace BoPi.Machine
{
	public class SocketLog : Log
	{
		private NetworkStream networkStream;
		private String ipAddress;
		private int port;
		private TcpClient socket;

		public SocketLog(String ipAddress, int port, int logLevel) : base(logLevel)
		{
			this.ipAddress = ipAddress;
			this.port = port;

			if (!this.Connect())
			{
				return;
				Console.WriteLine("Cannot connect to client");
				Environment.Exit(-1);
			}
		}

		private void WriteBytecode(String bytecode)
		{
			base.streamWriter.WriteLine(bytecode);
			base.streamWriter.WriteLine("END BYTECODE");
			base.streamWriter.Flush();
		}

		public override void CloseStream()
		{
			networkStream.Close();
			base.streamWriter.Close();
		}

		//Funzione di supporto per logging su socket
		//Crea e connette un socket all'indirizzo passato alla macchina dal compilatore
		private bool Connect()
		{
			try
			{
				socket = new TcpClient(this.ipAddress, this.port);
			}
			catch
			{
				Console.WriteLine("Failed to connect to server at {0}:{1}", this.ipAddress, this.port);
				return false;
			}

			networkStream = socket.GetStream();
			base.streamWriter = new StreamWriter(networkStream);
			return true;
		}
	}
}
