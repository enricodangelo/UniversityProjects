// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using BoPi.Types;
using BoPi.Common;
namespace BoPi.Machine
{
	public abstract class Pattern
	{
		public abstract IType schemaof();
		public abstract bool patternmatch (Env e, IValue v);
	}

	public class SchemaPattern:Pattern
	{
		private readonly IType content;
    private ITypeChecker typeChecker = new TypeChecker(); 
		public override string ToString()
		{
			return content.ToString ();
		}

		public SchemaPattern(IType content)
		{
			this.content=content;

		}
		public override bool patternmatch(Env e, IValue v)
		{
		  return typeChecker.IsSubtype(v.TypeOf(), schemaof()); 
		}	

		public override IType schemaof()
		{
			return content;
		}
	}

	public class VarPattern:Pattern
	{
		private readonly Pattern content;
		private readonly int index;

		public VarPattern(int index, Pattern content)
		{
			this.content = content;
			this.index = index;
		}

		public override IType schemaof()
		{ return content.schemaof();	}

		public override bool patternmatch(Env e, IValue v)
		{
			if (content.patternmatch(e,v))
			{
				e.Set(index, (Value) v);
				return true;
			}
			else 
				return false;
		}

		public override string ToString()
		{ return index + ":" + content.ToString(); }
	}
  
	public class LabelPattern:Pattern
	{
		private readonly LabelsSet label;
		private readonly Pattern content;
		public LabelPattern(LabelsSet label, Pattern content)
		{
			this.content=content;
			this.label=label;
		}

		public override IType schemaof()
		{
			return new Labelled(label,content.schemaof());
		}

		public override bool patternmatch(Env e, IValue v)
		{
			if (v is LabelValue)
			{
				if (label.Includes(new UnionLabel(((LabelValue)v).Label)))
					return content.patternmatch(e,((LabelValue)v).Content);
			}
			return false;
		}
		public override string ToString()
		{
			return label.ToString()+"["+content.ToString()+"]";
		}
	}

	public class SequencePattern:Pattern
	{		
		public readonly Pattern top;
		public readonly Pattern tail;
		public SequencePattern(Pattern top,Pattern tail)
		{
			if (top is SequencePattern) 
			{
				//(S,R),T = S,(R,T)
				Pattern topOfTop = ((SequencePattern) top).top;
				Pattern tailOfTop = ((SequencePattern) top).tail;
				SequencePattern s= new SequencePattern(topOfTop, new SequencePattern(tailOfTop, tail));
				top = s.top;
				tail = s.tail;
			}			
			this.top = top;
			this.tail = tail;		
		}
		public override IType schemaof()
		{ return restruct(top.schemaof(), tail.schemaof()); }

		public override bool patternmatch(Env e, IValue v)
		{
			bool res;
			if (v is SequenceValue)
			{
				SequenceValue seq=(SequenceValue)v;
				res = top.patternmatch(e,seq.Top) && tail.patternmatch(e, seq.Tail);							
				if (res) return true;				
			}
			if ((top.patternmatch(e,new VoidValue()) && (tail.patternmatch(e,v))))
				return true;
			if ((top.patternmatch(e,v) && (tail.patternmatch(e,new VoidValue()))))
				return true;

			return false;
		}
		public override string ToString()
		{
			return top.ToString()+","+tail.ToString();
		}

		bool validtype(IType t)
		{
			if ((t is Labelled) || (t is Chan) || (t is IntType) || (t is StringType)
				|| (t is IntLiteral) || (t is StringLiteral))
				return true;
			return false;
		}

		IType restruct(IType top,IType tail)
		{
			Sequence seq;
			Union un;
			if (top is Sequence)
			{
				seq=(Sequence) top;
				if (validtype(seq.Top))
					return new Sequence(seq.Top,restruct(seq.Tail,tail));
			}
			if (top is Union)
			{
				un=(Union)top;
				return new Union(restruct(un.Fst,tail),restruct(un.Snd,tail));
			}
			if (validtype(top))
				return new Sequence(top,tail);
			if (top is Types.Void)
				return tail;
			return new ErrorType();
		}	
	}
}
