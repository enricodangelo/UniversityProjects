// This file is part of the PiDuce project (http://www.cs.unibo.it/Piduce/)
// developed at the Department of Computer Science of Bologna.
// Authors: Samuele Carpineti, Cosimo Laneve, Leonardo Mezzina, Luca Padovani
//
// See Copyright for the status of this software.

using System;
using System.Collections;
using System.Diagnostics;
using System.Xml;
using BoPi.Common;

namespace BoPi.Machine
{
  public class JoinPatternAtom
  {
		private Channel channel;
    private int index;
    private Pattern pattern;

    public JoinPatternAtom(Channel channel, int index, Pattern pattern)
    {
			this.channel = channel;
      this.index = index;
      this.pattern = pattern;
    }

    public int Index { get { return index; } }
		public Channel Channel { get { return channel; } }
    public Pattern Pattern { get { return pattern; } }
  }

  public class JoinPatternRow
  {
    private ArrayList atoms; // ArrayList of JoinPatternAtom
    private XmlElement next;

    public JoinPatternRow(ArrayList atoms, XmlElement next)
    {
      this.atoms = atoms;
      this.next = next;
    }

		public void Match(Env env)
		{
      foreach (JoinPatternAtom atom in atoms) {
				IValue thisValue = atom.Channel.DequeueValue();
				bool matchRes = atom.Pattern.patternmatch(env, thisValue);
				Debug.Assert(matchRes);
      }
		}

    public void Match(Env env, int channelIndex, IValue v)
    {
      foreach (JoinPatternAtom atom in atoms) {
				IValue thisValue = (channelIndex == atom.Index) ? v : atom.Channel.DequeueValue();
				bool matchRes = atom.Pattern.patternmatch(env, thisValue);
				Debug.Assert(matchRes);
      }
    }

    public ArrayList Atoms { get { return atoms; } }
    public XmlElement Next { get { return next; } }
  }

  public class JoinInputRequest : IInputRequest
  {
    private JoinInputDefinition definition;
    private Channel channel;
    private int index;

    public JoinInputRequest(JoinInputDefinition definition, Channel channel, int index)
    {
      this.definition = definition;
      this.channel = channel;
      this.index = index;
    }

    public bool Send(IValue v)
    { 
			return definition.Send(this, v);
		}

    public void Empty()
    { definition.Empty(this); }

		public Channel Channel { get { return channel; } }
		public int Index { get { return index; } }
  }

	public interface IJoinAutomaton
	{
		void Full(int channelIndex);
		void Empty(int channelIndex);
		JoinPatternRow ActiveRow { get; }
	}

	public class NaiveJoinAutomaton : IJoinAutomaton
	{
		private ArrayList rows;
    private Hashtable status;

    public NaiveJoinAutomaton(ArrayList rows)
    {
			this.rows = rows;
      this.status = new Hashtable();
    }

		public JoinPatternRow ActiveRow {
			get {
      	foreach (JoinPatternRow row in rows) {
					bool full = true;
					foreach (JoinPatternAtom atom in row.Atoms) {
				  	if (!status.Contains(atom.Index)) {
				    	full = false;
				    	break;
				  	}
					}
		
					if (full)
				  	return row;
      	}

				return null;
			}
		}

    public void Full(int channelIndex)
    {
      if (!status.Contains(channelIndex))
				status.Add(channelIndex, true);
    }

    public void Empty(int channelIndex)
    {
      if (status.Contains(channelIndex))
				status.Remove(channelIndex);
    }
	}

	public class JoinAutomaton : IJoinAutomaton
	{
		private ArrayList rows;
    private int state;
    private int nChannels;
    private int[,] transitions;
    private int[] continuations;

    public JoinAutomaton(ArrayList rows, XmlNamespaceManager nsmgr, XmlElement root)
    {
      this.rows = rows;
      this.state = 0;

      this.nChannels = Int32.Parse(root.GetAttribute("channels"));
      int nStates = Int32.Parse(root.GetAttribute("states"));
      int nContinuations = Int32.Parse(root.GetAttribute("continuations"));
      Debug.Assert(nChannels > 0);
      Debug.Assert(nStates > 0);
      Debug.Assert(nContinuations > 0);
      this.transitions = new int[nStates, nChannels * 2];
      this.continuations = new int[nStates];

      foreach (XmlElement state in root.SelectNodes("opcode:state", nsmgr)) {
				int stateIndex = Int32.Parse(state.GetAttribute("index"));
				Debug.Assert(stateIndex >= 0 && stateIndex < nStates);

				foreach (XmlElement move in state.SelectNodes("opcode:empty", nsmgr)) {
				  int channelIndex = Int32.Parse(move.GetAttribute("index"));
				  int next = Int32.Parse(move.GetAttribute("next"));
					Debug.Assert(channelIndex >= 0 && channelIndex < this.nChannels);
				  Debug.Assert(next >= 0 && next < nStates);
				  transitions[stateIndex, channelIndex] = next;
				}

				foreach (XmlElement move in state.SelectNodes("opcode:full", nsmgr)) {
				  int channelIndex = Int32.Parse(move.GetAttribute("index"));
				  int next = Int32.Parse(move.GetAttribute("next"));
					Debug.Assert(channelIndex >= 0 && channelIndex < this.nChannels);
				  Debug.Assert(next >= 0 && next < nStates);
				  transitions[stateIndex, this.nChannels + channelIndex] = next;
				}

				if (state.HasAttribute("continue")) {
				  int continuation = Int32.Parse(state.GetAttribute("continue")) - 1;
				  Debug.Assert(continuation >= 0 && continuation < nContinuations);
				  continuations[stateIndex] = continuation;
				} else
				  continuations[stateIndex] = -1;
      }
    }

		public JoinPatternRow ActiveRow {
			get {
      	int rowIndex = continuations[state];
				if (rowIndex >= 0) {
					Debug.Assert(rowIndex < rows.Count);
					return (JoinPatternRow) rows[rowIndex];
				} else
					return null;
			}
		}

		public void Full(int channelIndex)
		{
			Debug.Assert(channelIndex >= 0 && channelIndex < nChannels);
      state = transitions[state, this.nChannels + channelIndex];
		}

    public void Empty(int channelIndex)
    {
			Debug.Assert(channelIndex >= 0 && channelIndex < nChannels);
      state = transitions[state, channelIndex];
		}
	}

  public class JoinInputDefinition
  {
		private bool service;
		private IJoinAutomaton automaton;
		private ArrayList requests; // all JoinInputRequests
    private Env env;
    private VmThread thread;

    public JoinInputDefinition(bool service,
															 ArrayList channels,
															 IJoinAutomaton automaton,
			       									 Env env,
			       									 VmThread thread)
    {
			this.service = service;
			this.automaton = automaton;
      this.env = env;
      this.thread = thread;

      Debug.Assert(channels.Count > 0);
      requests = new ArrayList();
      for (int i = 0; i < channels.Count; i++) {
				Channel channel = (Channel) channels[i];
				IInputRequest request = new JoinInputRequest(this, channel, i);
				requests.Add(request);
				channel.EnqueueRequest(request);
			}
    }

    public bool Send(JoinInputRequest request, IValue v)
    {
      if (request.Channel.Empty()) {
				automaton.Full(request.Index);
				JoinPatternRow row = automaton.ActiveRow;
				//Console.WriteLine("Send on join {0}", row != null);
				if (row != null) {
					// the channel was empty when this method was called,
					// we declared it full but never really pushed the value
					// in its queue. Now there is a match, which means that
					// the value v has activated a pattern and it is consumed
					// immediately. Thus, we declare that the channel is empty now
					automaton.Empty(request.Index);
					Debug.Assert(request.Channel.Empty());

					if (service) {
						Env newEnv = env.Clone();
	  				row.Match(newEnv, request.Index, v);
						thread.Fork(row.Next, newEnv, thread.log);
					} else {
						row.Match(env, request.Index, v);
						foreach (JoinInputRequest req in requests)
							req.Channel.RemoveRequest(req);
						thread.Unblock(row.Next);
					}

  				return true;
				}
      }

      return false;
    }

		public void Empty(JoinInputRequest request)
		{ automaton.Empty(request.Index); }
  }
}
