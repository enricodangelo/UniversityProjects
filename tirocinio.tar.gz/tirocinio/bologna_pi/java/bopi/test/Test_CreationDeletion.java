/*
 * Created on 16-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;

import bopi.api.API_Exception;
import bopi.api.BolognaPiAPI;
import bopi.api.BolognaPiImpl;

/**
 * 
 * @author Paolo Milazzo
 */
public class Test_CreationDeletion implements Test {

	// test name
	private String name = "Creation and Deletion of Local Channels"; 

	// test description
	private String[] desc = {
		"Connects to the local channel manager, creates 200 new local",
		"channels, checks if they are really local (TODO), makes 500",
		"reactions and delete the channels in non-linear order"
	};
	
	// test number
	private int testNum;

	// output and logfile printers
	private OutputPrinter output;
	private LogPrinter log;
	
	// TCP port used to connect the local channel manager
	private int CMPort;
	private String CMAddrString = "127.0.0.1";

	private static final int NUM_REACTIONS = 500;

	// default constructor
	public Test_CreationDeletion(int testNum, OutputPrinter outputPrinter, 
							     LogPrinter logPrinter, String CMAddr, int CMPort) {
		// set output
		if (outputPrinter!=null) output = outputPrinter;
		else {
			System.err.println("[Tester Debug] outputPrinter null in Test_CreationDeletion()"); 
			output = new OutputPrinter();
		}
		// set log
		if (logPrinter!=null) log = logPrinter;
		else {
			System.err.println("[Tester Debug] logPrinter null in Test_CreationDeletion()"); 
			log = new LogPrinter();
		}
		// set testNum
		this.testNum = testNum;
		
		// set CMPort and CMAddr;
		this.CMPort = CMPort;
		this.CMAddrString = CMAddr;
	}


	public int execute() {
        
		// test start
		output.printTestStart(testNum,name,desc);
		log.printTestStart(testNum,name,desc);
		
		// ACTION: connect to the local channel manager
		output.printAct("Initialization");

		// get API instance
		output.printSubAct("BolognaPiImpl.getInstance(CMPort)");
		BolognaPiAPI api = null;
		try {
			api = BolognaPiImpl.getInstance(CMAddrString, CMPort); // TODO: REMOVE
		} catch (API_Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		output.printSubActOk();
		
		// call initAPI()...
		output.printSubAct("initAPI()");
		try {
			api.initAPI();
		}
		catch(API_Exception apie) {
			handleException(apie, "initAPI() FAILED");
			return 0;
		}            

		output.printSubActOk();
		output.printActOk();

		// ACTION: creating 200 new local channels
		output.printAct("Creation of 200 local channels");
		output.printSubAct("creating");
		String[] chanNames = new String[200];
		for (int i=0; i<200; i++) {
			try {
				chanNames[i] = api.newChannel();
			} catch (API_Exception apie) {
				handleException(apie, "ERROR ON CREATING CHANNEL NUMBER " + i);
				return 0;
			}
		}
		
		output.printSubActOk();
		output.printActOk();
		
		
		// ACTION: 500 random reactions
		output.printAct(NUM_REACTIONS + " random reactions");
		
		// randomly choose a sequence of 500 channel names
		output.printSubAct("choosing channels");
		String[] reactChannels = new String[NUM_REACTIONS];
		Random rng = new Random();
		for (int i=0; i<NUM_REACTIONS; i++) {
			reactChannels[i] = chanNames[rng.nextInt(200)];
		}
		output.printSubActOk();
		
		// execute send or receive or asend (first round)
		output.printSubAct("first round of messages");
		int[] messages = new int[NUM_REACTIONS]; // 0 = send/asend , 1 = recv
		for (int i=0; i<NUM_REACTIONS; i++) {
			messages[i] = rng.nextInt(2);
			if (messages[i]==0) {
				if (rng.nextBoolean()) { // send 
					new SenderThread(api,reactChannels[i],i).start();
				}
				else { // asend
					char[] charData = Integer.toString(10000+i).toCharArray();
					byte[] data = new byte[charData.length];
					for (int j=0; j<charData.length; j++) data[j] = (byte) charData[j];					
					try {
						api.asend(reactChannels[i],data);
					} catch (API_Exception e1) {
						// TODO HANDLE EXCEPTION
						System.out.println("ERROR ON " + i + " (ASEND)");
					}
				}
			}
			else { // recv
				new ReceiverThread(api,reactChannels[i],i).start();
			}
		}
		output.printSubActOk();
		
		// execute send or receive or asend (second round)
		output.printSubAct("second round of messages");
		for (int i=0; i<NUM_REACTIONS; i++) {
			if (messages[i]==0) { // first round was send or asend
				new ReceiverThread(api,reactChannels[i],i).start(); // recv
			}
			else { // first round was recv
				if (rng.nextBoolean()) { // send
					new SenderThread(api,reactChannels[i],i).start();
				}
				else { // asend
					char[] charData = Integer.toString(10000+i).toCharArray();
					byte[] data = new byte[charData.length];
					for (int j=0; j<charData.length; j++) data[j] = (byte) charData[j];					
					try {
						api.asend(reactChannels[i],data);
					} catch (API_Exception e1) {
						// TODO HANDLE EXCEPTION
						System.out.println("ERROR ON " + i + " (ASEND)");
					}
				}
			}
		}
		output.printSubActOk();
		output.printActOk();

		try {
			System.out.println("Sleeping..."); // TODO: REMOVE SLEEP (USE SYNCH)
			Thread.sleep(15000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		
		// ACTION: Deleting channels
		output.printAct("Deletion of the new channels in non-liner order");

		// deleting channels 0-19, 80-119, 180-199
		output.printSubAct("deleting 0-19");
		for (int i=0; i<20; i++) {
			try {
				api.deleteChannel(chanNames[i]);
			} catch (API_Exception e1) {
				handleException(e1,"ERROR ON DELETING CHANNEL NUMBER " + i);
				return 0;
			}
		}
		log.println("CHANNELS 0-19 DELETED");
		output.printSubActOk();
		
		output.printSubAct("deleting 80-119");
		for (int i=80; i<119; i++) {
			try {
				api.deleteChannel(chanNames[i]);
			} catch (API_Exception e1) {
				handleException(e1,"ERROR ON DELETING CHANNEL NUMBER " + i);
				return 0;
			}
		}
		log.println("CHANNELS 80-119 DELETED");
		output.printSubActOk();
		
		output.printSubAct("deleting 180-199");
		for (int i=180; i<199; i++) {
			try {
				api.deleteChannel(chanNames[i]);
			} catch (API_Exception e1) {
				handleException(e1,"ERROR ON DELETING CHANNEL NUMBER " + i);
				return 0;
			}
		}
		log.println("CHANNELS 180-199 DELETED");
		output.printSubActOk();
		
		// deleting remaing channels in random order
		output.printSubAct("deleting remaining channels (randomly)");		
		HashSet chanNamesSet = new HashSet(13,1);		
		for (int i=0; i<200; i++) {
			if ((i>=20 && i<80) || (i>=120 && i<180)) {
				chanNamesSet.add(chanNames[i]);
			}
		}
		Iterator i = chanNamesSet.iterator();
		String tmp = null;
		while (i.hasNext()) {
			try {
				tmp = (String)i.next();
				api.deleteChannel(tmp);
			} catch (API_Exception e1) {
				for (int j=0; j<200; j++) {
					if (chanNames[j].equals(tmp)) {
						handleException(e1,"ERROR ON DELETING CHANNEL NUMBER " + j);
						return  0;
					}
				}
			}
		}
				
		log.println("REMAINING CHANNEL REMOVED");
		output.printSubActOk();
		output.printActOk();

		// ACTION: disconnecting the channel manager
		output.printAct("Termination");
		output.printSubAct("exit");
		try {
			api.exitAPI();
		} catch (API_Exception apie) {
			handleException(apie, "exitAPI() FAILED");
			return 0;
		}
		
		output.printSubActOk();
		output.printActOk();
		output.printTestOk();
		log.printTestOk();		
		
		return 1;        
	}

	public String getName() {
		return name;
	}

	public String[] getDescription() {
		return desc;
	}

	// prints error messages when an exception occurs
	private void handleException(Exception e, String logMsg) {
		output.printSubActFail();
		log.println(logMsg);
		output.printException(e);
		log.printException(e);
		output.printTestFail();
		log.printTestFail();		
	}

	// prints error messages when an error occurs
	private void handleError(String msg) {
		log.println("ERROR: " + msg);
		output.printSubActFail();
		output.printError(msg);
		output.printActFail();
		output.printTestFail();
		log.printTestFail();
	}

	class SenderThread extends Thread {
		
		private int idx;
		private String chan;
		private BolognaPiAPI api;
		
		public SenderThread(BolognaPiAPI api, String chan, int idx) {
			this.api = api;
			this.chan = chan;
			this.idx = idx;
		}
		
		public void run() {
			char[] charData = Integer.toString(20000+idx).toCharArray();
			byte[] data = new byte[charData.length];
			try {
				api.initAPI();
			} catch (API_Exception e) {
				System.out.println("initAPI() ERROR in SenderThread");
			}
			for (int i=0; i<charData.length; i++) data[i] = (byte) charData[i];
			try { 
				api.send(chan,data);
			}
			catch(API_Exception apie) {
				// TODO: HANDLE EXCEPTION (SETTING A VALUE FOR TEST FAILING)
				System.out.println("ERROR ON " + idx + " SEND");
			}
			try {
				api.exitAPI();
			} catch (API_Exception e) {
				System.out.println("exitAPI() ERROR in SenderThread");
			}
		}
		
	}

	class ReceiverThread extends Thread {
		
		private int idx;
		private String chan;
		private BolognaPiAPI api;
		
		public ReceiverThread(BolognaPiAPI api, String chan, int idx) {
			this.api = api;
			this.chan = chan;
			this.idx = idx;
		}
		
		public void run() {
			try {
				api.initAPI();
			} catch (API_Exception e) {
				System.out.println("initAPI() ERROR in ReceiverThread");
			}
			try { 
				api.recv(chan); // TODO: receive data
			}
			catch(API_Exception apie) {
				// TODO: HANDLE EXCEPTION (SETTING A VALUE FOR TEST FAILING)
				System.out.println("ERROR ON " + idx + " RECV");
			}
			try {
				api.exitAPI();
			} catch (API_Exception e) {
				System.out.println("exitAPI() ERROR in ReceiverThread");
			}
		}
		
	}


}
