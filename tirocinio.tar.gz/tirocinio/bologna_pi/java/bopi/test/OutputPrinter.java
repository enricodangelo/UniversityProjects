/*
 * Created on 15-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 * 
 * @author Paolo Milazzo
 */
public class OutputPrinter {

	/* Levels of verbosity:
	 * 1 - (default) test numbers, names and results
	 * 2 - more details about what happens
	 * 3 - full details (messages exchanged)
	 */
	private int verbosity = 1;

	// stream used for output (default: standard output)
	private PrintStream output = System.out;

	// default constructor: do nothing
	public OutputPrinter() { }

	// special constructor 1: sets the verbosity level
	public OutputPrinter(int verb) { 
		if ((verb>0) && (verb<4)) verbosity=verb;
		else output.println("[BoPiTest debug] wrong verbosity level in special constructor 1");
	}
	
	// special constructor 2: sets verbosity and specifies the output file
	public OutputPrinter(String outputFileName, int verb) {
		try {
			// initializing the output file
			if (outputFileName!=null) {
				FileOutputStream outputStream = 
					new FileOutputStream(new File(outputFileName));
				output = new PrintStream(outputStream);
			}
		}
		catch(FileNotFoundException fnfe) {
			System.err.println("Error on output file initialization " + outputFileName);
			System.exit(1);
		}
		if ((verb>0) && (verb<4)) verbosity=verb;
		else output.println("[BoPiTest debug] wrong verbosity level in special constructor 2");
	}

	// prints a message about the starting of a test
	public void printTestStart(int num, String name, String[] description) {
		output.println();
		switch (verbosity) {
			case 1: output.print("TEST " + num + ": " + name + "...  ");
					break;
			case 2: 
			case 3: output.println("TEST " + num + ": " + name);
					for (int i=0; i<description.length; i++) {
						output.println(description[i]);
					}
					output.println("******************");
					output.println("TEST STARTED");
					break;
			default: output.println("[BoPiTest debug] wrong verbosity level in printTestStart");
		}
	}

	// prints a message about the completion of a test
	public void printTestOk() {
		switch (verbosity) {
			case 1: output.println("PASSED");
					break;
			case 2: 
			case 3: output.println("TEST COMPLETED");
					output.println("******************");
					break;
			default: output.println("[BoPiTest debug]  wrong verbosity level in printTestFail");
		}
	}

	// prints a message about the failure of a test
	public void printTestFail() {
		switch (verbosity) {
			case 1: output.println("FAILED");
					break;
			case 2: 
			case 3: output.println("TEST FAILED");
					output.println("******************");
					break;
			default: output.println("[BoPiTest debug]  wrong verbosity level in printTestFail");
		}
	}
	
	// prints a message about an exception raised
	public void printException(Exception e) {
		if (verbosity==3) {
			output.println(e.toString());
			output.println("see logs for stack trace");
		}
	}
	
	// prints a message about an error
	public void printError(String msg) {
		if (verbosity==3) {
			output.println("ERROR: " + msg);
		}
	}
	
	// prints a message about the starting of an action
	public void printAct(String desc) {
		switch (verbosity) {
			case 1: break;
			case 2: output.print(desc + "... "); break;
			case 3: output.println("ACTION: " + desc); break;
		}
	}

	// prints a message about the starting of an action
	public void printSubAct(String desc) {
		switch (verbosity) {
			case 1: break;
			case 2: break;
			case 3: output.print(desc + "... "); break;
		}
	}

	// prints a message about the starting of an action
	public void printActOk() {
		switch (verbosity) {
			case 1: break;
			case 2: output.println("OK"); break;
			case 3: output.println("RESULT: OK"); break;
		}
	}

	// prints a message about the starting of an action
	public void printSubActOk() {
		switch (verbosity) {
			case 1: break;
			case 2: break;
			case 3: output.println("Done"); break;
		}
	}

	// prints a message about the starting of an action
	public void printActFail() {
		switch (verbosity) {
			case 1: break;
			case 2: output.println("FAILED"); break;
			case 3: output.println("RESULT: FAILED"); break;
		}
	}

	// prints a message about the starting of an action
	public void printSubActFail() {
		switch (verbosity) {
			case 1: break;
			case 2: break;
			case 3: output.println("Error"); break;
		}
	}
	
	// prints a newline
	public void println() {
		output.println();
	}

	// prints the string representation of an object
	public void print(Object o) {
		output.print(o);
	}
	
	// prints the string representation of an object (and a newline)
	public void println(Object o) {
		output.println(o);
	}

	// prints a string
	public void print(String s) {
		output.print(s);
	}
	
	// prints a string (and a newline)
	public void println(String s) {
		output.println(s);
	}

	// prints the string representation of an integer	
	public void print(int i) {
		output.print(i);
	}

	// prints the string representation of an integer (and a newline)
	public void println(int i) {
		output.println(i);
	}

	// prints the string representation of a char
	public void print(char c) {
		output.print(c);
	}

	// prints the string representation of a char (and a newline)
	public void println(char c) {
		output.println(c);
	}

	// prints the string representation of a byte
	public void print(byte b) {
		output.print(b);
	}

	// prints the string representation of a byte (and a newline)
	public void println(byte b) {
		output.println(b);
	}

	// prints the string representation of a byte array
	public void print(byte[] b) {
		output.print(b);
	}

	// prints the string representation of a byte array (and a newline)
	public void println(byte[] b) {
		output.println(b);
	}
	
}

