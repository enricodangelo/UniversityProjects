/*
 * Created on 29-mar-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;
import java.io.FileInputStream;
import bopi.api.BolognaPiAPI;
import bopi.api.BolognaPiImpl;
import bopi.api.Channel;
import bopi.vm.VMException;
import bopi.vm.VirtualMachine;
/**
 * 
 * @author Samuele Carpineti
 */
public class VMTest02Client {
	private final static String IPADDR= "127.0.0.1";
	public static void main(String[] args) throws VMException {
		try {
			BolognaPiAPI api= BolognaPiImpl.getInstance(IPADDR, 2050);
			api.initAPI();
			Channel tmp= new Channel();
			Channel output= Channel.getReference(IPADDR + ":2050#1");
			VirtualMachine vm= new VirtualMachine(VirtualMachine.MULTI_THREAD, IPADDR, 2050, "logFile", 0);
			Channel c= vm.getLoaderChannel();
			FileInputStream stream;
			stream= new FileInputStream("test-files/VMTest02Client.xml");
			byte[] pbuffer= new byte[stream.available()];
			stream.read(pbuffer);
			c.send(pbuffer);
			byte[] x= output.recv();
			for (int i= 0; i < x.length; i++)
				System.out.print((char) x[i]);
			System.out.println();
            System.out.println("------ Client: terminated --------- ");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}