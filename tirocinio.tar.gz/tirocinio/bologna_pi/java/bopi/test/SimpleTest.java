/*
 * Created on 15-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;

/**
 * 
 * @author Paolo Milazzo
 */
public class SimpleTest implements Test {

	protected String name = "SimpleTest";
	protected String[] description = 
		{ "Base class implementing the Test interface",
		  "To be extended by real test classes" };
	protected LogPrinter log = new LogPrinter();
	protected OutputPrinter output = new OutputPrinter();

	public int execute() {
		return 1;
	}

	public String getName() {
		return name;
	}

	public String[] getDescription() {
		return description;	
	}

}
