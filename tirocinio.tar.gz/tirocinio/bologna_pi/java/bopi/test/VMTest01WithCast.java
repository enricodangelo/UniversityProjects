/*
 * VMTest01WithCast.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Jun 21, 2004
 */
package bopi.test;

import java.io.FileInputStream;
import bopi.api.BolognaPiAPI;
import bopi.api.BolognaPiImpl;
import bopi.api.Channel;
import bopi.vm.VMException;
import bopi.vm.VirtualMachine;

/**
 * 
 * @author Samuele Carpineti
 */
public class VMTest01WithCast {
	//  private final static String IPADDR = "192.168.1.40";
	//private final static String IPADDR = "130.136.3.116";
	//private final static String IPADDR = "130.136.32.134";
	private final static String IPADDR= "127.0.0.1";
	public static void main(String[] args) throws VMException  {
		try {
			BolognaPiAPI api= BolognaPiImpl.getInstance(IPADDR, 2047);
			api.initAPI();
			Channel tmp= new Channel();
			Channel output= Channel.getReference(IPADDR + ":2047#1");
			VirtualMachine vm= new VirtualMachine(VirtualMachine.MULTI_THREAD, IPADDR, 2047, "logFile", 0);
			Channel c= vm.getLoaderChannel();
			FileInputStream stream;
			stream= new FileInputStream("test-files/VMTest01WithCast.xml");
			byte[] pbuffer= new byte[stream.available()];
			stream.read(pbuffer);
			c.send(pbuffer);
			while (true) {
				byte[] x= output.recv();
				System.out.print("Console: ");
				for (int i= 0; i < x.length; i++)
					System.out.print((char) x[i]);
				System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
