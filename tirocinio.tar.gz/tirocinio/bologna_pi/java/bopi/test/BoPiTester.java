package bopi.test;

// TODO: ricevere l'indirizzo IP del channel manager come parametro

public class BoPiTester {

    /* Levels of verbosity:
     * 1 - (default) test numbers, names and results
     * 2 - more details about what happens
     * 3 - full details (messages exchanged)
     */
    private static int verbosity = 1;

	// logfile and output printers
	private static String logfileName = "testerLog";
	private static LogPrinter logPrinter;
	private static String outfileName = null;
	private static OutputPrinter outPrinter;
    
    // variables used for selective test execution
    // test numbers must be continuous!!
    private static boolean executeAll = true;
    private static boolean onlyPrintDescription = false;
    private static int currentTest = 1;
    private static final int FIRST_TEST_NUM = 0;
    private static final int LAST_TEST_NUM = 3;
    private static final int NUM_TEST = LAST_TEST_NUM - FIRST_TEST_NUM +1;
    private static Test[] testers = new Test[NUM_TEST];
    
    // variables used for final summary
    private static int tests = NUM_TEST;
    private static int passed = 0;
    
    // port number of the local channel manager
    private static int CMPort = 2047;
    private static String CMAddr = /* "131.114.3.12"; */ /*"130.136.3.116"; */ "192.168.0.111";
        
    // main
    public static void main(String[] args) {
        
        // tester initialization
        readArgs(args);
		if (outfileName == null) outPrinter = new OutputPrinter(verbosity);
		else outPrinter = new OutputPrinter(outfileName,verbosity);
		logPrinter = new LogPrinter(logfileName);		
        testers[0] = new Test_ChannelManager(0,outPrinter,logPrinter,CMAddr,CMPort);
        testers[1] = new Test_SingleReaction(CMAddr,CMPort);
		testers[2] = new Test_CreationDeletion(2,outPrinter,logPrinter,CMAddr,CMPort);
		testers[3] = new Test_LocalChoice(3,outPrinter,logPrinter,CMAddr,CMPort);
		
        // tests
        do {
			testers[currentTest++].execute(); // TODO: USE RETURN VALUE
        }
        while ((currentTest<=LAST_TEST_NUM) && executeAll);
        
        // TODO: HANDLE RESULTS
/*        // result summary
        if (!onlyPrintDescription) {
            printlnOut(0);
            printlnOut(0,"SUMMARY");
            printlnOut(0,"Tests Executed:    " + (executeAll?tests:1));
            printlnOut(0,"Tests Passed:      " + passed);
        } 
*/
    }
    
    

    /********************************************************************
     *
     *  METHODS FOR INITIALIZATION AND COMMAND LINE ARGUMENTS HANDLING
     *
     ********************************************************************/

    // reads the argument list and sets the related values
    private static void readArgs(String[] args) {
        int i = 0;
        try {
            while ((i<args.length) && (args[i].startsWith("-"))) {
                // "-v" specifies the verbosity level
                if (args[i].equals("-v")) {
                    verbosity = Integer.parseInt(args[++i]);
                }
                // "-log" specifies the logfile
                else if (args[i].equals("-log")) {
                    logfileName = args[++i];
                }
                // "-o" specifies the output file
                else if (args[i].equals("-o")) {
                    outfileName = args[++i];
                }
                // "-t" specifies a particular test to be executed
                else if (args[i].equals("-t")) {
                    executeAll = false;
                    currentTest = Integer.parseInt(args[++i]);
                    if ((currentTest<FIRST_TEST_NUM)||(currentTest>LAST_TEST_NUM)) {
                        System.err.println("wrong test number " + currentTest + 
                            " (not in [" + FIRST_TEST_NUM + "-" + LAST_TEST_NUM +"])");
                    }
                }
                // "-p" specifies the TCP port number of the local channel manager
                else if (args[i].equals("-h") || args[i].equals("--help")) {
                    CMPort = Integer.parseInt(args[++i]);
                }                
                // "-l" show test names and descriptions
                else if (args[i].equals("-l")) {
                    onlyPrintDescription = true;
                }                
                // "-h" "--help" show usage
                else if (args[i].equals("-h") || args[i].equals("--help")) {
                    usage();
                    System.exit(0);
                }
                else {
                    usage();
                    System.exit(1);
                }
                i++;
            }
        }
        catch(ArrayIndexOutOfBoundsException oube) {
            usage();
            System.exit(1);
        }
        catch(NumberFormatException nfe) {
            usage();
            System.exit(1);
        }
    }
    
    // shows command line arguments
    private static void usage() {
        System.out.println();
        System.out.println("Usage:  java BoPiTest [options]");
        System.out.println();
        System.out.println("where options include:");
        System.out.println("    -v <value>       select the verbosity level (see below)");
        System.out.println("    -log <filename>  set the file for logs (default: testerLog)");
        System.out.println("    -o <filename>    set the file for output (instad of console)");
        System.out.println("    -t <test_num>    execute a particular test given its number ["
                                                      + FIRST_TEST_NUM + "-" + LAST_TEST_NUM + "]");
        System.out.println("    -p <port_num>    set the TCP port of the channel manager (default: 2047)");
        System.out.println("    -h | --help      this screen");
        System.out.println();
        System.out.println("Levels of verbosity:");
        System.out.println("1 - (default) test numbers, names and results");
        System.out.println("2 - more details about what happens");
        System.out.println("3 - full details (messages exchanged)");
    }   
}