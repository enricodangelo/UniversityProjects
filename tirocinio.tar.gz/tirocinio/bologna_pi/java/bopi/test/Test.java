/*
 * Created on 15-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;

/**
 * 
 * @author Paolo Milazzo
 */
public interface Test {

	public int execute();
	
	public String getName();
	
	public String[] getDescription();
	
}
