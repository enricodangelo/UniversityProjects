/*
 * Created on 29-mar-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;

import java.io.FileInputStream;

import bopi.api.BolognaPiAPI;
import bopi.api.BolognaPiImpl;
import bopi.api.Channel;
import bopi.vm.VMException;
import bopi.vm.VirtualMachine;

/**
 * 
 * @author Paolo Milazzo
 */
public class VMTest02Server {

	private final static String IPADDR = "127.0.0.1";

	public static void main(String[] args) throws VMException {
		try {
			BolognaPiAPI api = BolognaPiImpl.getInstance(IPADDR,2047);
			api.initAPI();
            Channel tmp = new Channel();
			VirtualMachine vm = new VirtualMachine(VirtualMachine.MULTI_THREAD,
												   IPADDR,
												   2047,
												   "logFile", 0);
			Channel c = vm.getLoaderChannel();
			FileInputStream stream;
			stream = new FileInputStream("test-files/VMTest02Server.xml");
            byte[] pbuffer= new byte[stream.available()];
            stream.read(pbuffer);
            c.send(pbuffer);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
 