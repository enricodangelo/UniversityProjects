/*
 * Created on 19-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;

import java.util.Random;
import java.util.Vector;

import bopi.api.API_Exception;
import bopi.api.BolognaPiAPI;
import bopi.api.BolognaPiImpl;

/**
 * 
 * @author Paolo Milazzo
 */
public class Test_LocalChoice implements Test {

	// test name
	private String name = "Reactions using Local Choices"; 

	// test description
	private String[] desc = {
		"Connects to the local channel manager, creates 100 new local",
		"channels, and makes 100 reactions using 4 terms choices",
		"TODO: THIS TEST MAKES LESS THAN 100 REACTIONS AND LEAVES ",		"GARBAGE MESSAGES AND GARBAGE THREADS"
	};
	
	// test number
	private int testNum;

	// output and logfile printers
	private OutputPrinter output;
	private LogPrinter log;
	
	// TCP port used to connect the local channel manager
	private int CMPort;
	private String CMAddrString = "127.0.0.1";

	private static final int NUM_CHANNELS = 100;

	// default constructor
	public Test_LocalChoice(int testNum, OutputPrinter outputPrinter, 
					   LogPrinter logPrinter, String CMAddr, int CMPort) {
		// set output
		if (outputPrinter!=null) output = outputPrinter;
		else {
			System.err.println("[Tester Debug] outputPrinter null in Test_CreationDeletion()"); 
			output = new OutputPrinter();
		}
		// set log
		if (logPrinter!=null) log = logPrinter;
		else {
			System.err.println("[Tester Debug] logPrinter null in Test_CreationDeletion()"); 
			log = new LogPrinter();
		}
		// set testNum
		this.testNum = testNum;
		
		// set CMPort;
		this.CMPort = CMPort;
		this.CMAddrString = CMAddr;
	}


	public int execute() {
        
		// test start
		output.printTestStart(testNum,name,desc);
		log.printTestStart(testNum,name,desc);
		
		// ACTION: connect to the local channel manager
		output.printAct("Initialization");

		// get API instance
		output.printSubAct("BolognaPiImpl.getInstance(CMPort)");
		BolognaPiAPI api = null;
		try {
			api = BolognaPiImpl.getInstance(CMAddrString, CMPort); // TODO: REMOVE
		} catch (API_Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		output.printSubActOk();
		
		// call initAPI()...
		output.printSubAct("initAPI()");
		try {
			api.initAPI();
		}
		catch(API_Exception apie) {
			handleException(apie, "initAPI() FAILED");
			return 0;
		}            

		output.printSubActOk();
		output.printActOk();

		// ACTION: creating 200 new local channels
		output.printAct("Creation of " + NUM_CHANNELS + " local channels");
		output.printSubAct("creating");
		String[] chanNames = new String[NUM_CHANNELS];
		for (int i=0; i<NUM_CHANNELS; i++) {
			try {
				chanNames[i] = api.newChannel();
			} catch (API_Exception apie) {
				handleException(apie, "ERROR ON CREATING CHANNEL NUMBER " + i);
				return 0;
			}
		}
		
		output.printSubActOk();
		output.printActOk();
		

		// ACTION: executing NUM_CHANNEL/2 OUTPUT OPERATIONS
		output.printAct("Sending messages");
		output.printSubAct("First round of " + NUM_CHANNELS/2 + "messages");
		Random rng = new Random(1); // TODO: REMOVE 1
		
		for (int i=0; i<(NUM_CHANNELS/2); i++) {
			if (rng.nextBoolean()) { // send
				new SenderThread(api,chanNames[i],i).start();
			}
			else { // asend
				char[] charData = Integer.toString(10000+i).toCharArray();
				byte[] data = new byte[charData.length];
				for (int j=0; j<charData.length; j++) data[j] = (byte) charData[j];					
				try {
					System.out.println("asend: " + chanNames[i] + "PRIMA");				
					api.asend(chanNames[i],data);
					System.out.println("asend: " + chanNames[i] + "DOPO");				
				} catch (API_Exception e1) {
					// TODO HANDLE EXCEPTION
					System.out.println("ERROR ON " + i + " (ASEND)");
				}
			}
		}
		
		output.printSubActOk();
		
		// sending local choice messages
		output.printSubAct("local choice messages");
		Vector v = new Vector();
		
		for (int i=0; i<NUM_CHANNELS; i++) {
			v.add(chanNames[i]);
			v.add(chanNames[i]);
			v.add(chanNames[i]);
			v.add(chanNames[i]);			
		}
			
		String[] tmp = new String[4];	
		for (int i=0; i<NUM_CHANNELS; i++) {
			tmp[0] = (String) v.remove(rng.nextInt(v.size()));
			tmp[1] = (String) v.remove(rng.nextInt(v.size()));
			tmp[2] = (String) v.remove(rng.nextInt(v.size()));
			tmp[3] = (String) v.remove(rng.nextInt(v.size()));

			new ReceiverThread(api,tmp).start();
		}
					

		output.printSubAct("second round of "+ NUM_CHANNELS/2 + "messages");
		
		for (int i=((NUM_CHANNELS/2)+1); i<NUM_CHANNELS; i++) {
			if (rng.nextBoolean()) { // send
				new SenderThread(api,chanNames[i],i).start();
			}
			else { // asend
				char[] charData = Integer.toString(10000+i).toCharArray();
				byte[] data = new byte[charData.length];
				for (int j=0; j<charData.length; j++) data[j] = (byte) charData[j];					
				try {
					api.asend(chanNames[i],data);
				} catch (API_Exception e1) {
					// TODO HANDLE EXCEPTION
					System.out.println("ERROR ON " + i + " (ASEND)");
				}
			}
		}


		try {
			System.out.println("Sleeping..."); // TODO: REMOVE SLEEP (USE SYNCH)
			Thread.sleep(15000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}



		// ACTION: Deleting channels
		output.printAct("Deletion of the new channels");
		output.printSubAct("deleting 0-19");
		for (int i=0; i<NUM_CHANNELS; i++) {
			try {
				api.deleteChannel(chanNames[i]);
			} catch (API_Exception e1) {
				handleException(e1,"ERROR ON DELETING CHANNEL NUMBER " + i);
				return 0;
			}
		}
		log.println("CHANNELS DELETED");
		output.printSubActOk();
		output.printSubActOk();
		output.printActOk();
		
		// ACTION: disconnecting the channel manager
		output.printAct("Termination");
		output.printSubAct("exit");
		try {
			api.exitAPI();
		} catch (API_Exception apie) {
			handleException(apie, "exitAPI() FAILED");
			return 0;
		}
		
		output.printSubActOk();
		output.printActOk();
		output.printTestOk();
		log.printTestOk();		
		
		return 1;        
	}

	public String getName() {
		return name;
	}

	public String[] getDescription() {
		return desc;
	}

	// prints error messages when an exception occurs
	private void handleException(Exception e, String logMsg) {
		output.printSubActFail();
		log.println(logMsg);
		output.printException(e);
		log.printException(e);
		output.printTestFail();
		log.printTestFail();		
	}

	// prints error messages when an error occurs
	private void handleError(String msg) {
		log.println("ERROR: " + msg);
		output.printSubActFail();
		output.printError(msg);
		output.printActFail();
		output.printTestFail();
		log.printTestFail();
	}

	class SenderThread extends Thread {
		
		private int idx;
		private String chan;
		private BolognaPiAPI api;
		
		public SenderThread(BolognaPiAPI api, String chan, int idx) {
			this.api = api;
			this.chan = chan;
			this.idx = idx;
		}
		
		public void run() {
			char[] charData = Integer.toString(20000+idx).toCharArray();
			byte[] data = new byte[charData.length];
			try {
				api.initAPI();
			} catch (API_Exception e) {
				System.out.println("initAPI() ERROR in SenderThread");
			}
			for (int i=0; i<charData.length; i++) data[i] = (byte) charData[i];
			try { 
				System.out.println("send: " + chan + "PRIMA");				
				api.send(chan,data);
				System.out.println("send: " + chan + "DOPO");
			}
			catch(API_Exception apie) {
				// TODO: HANDLE EXCEPTION (SETTING A VALUE FOR TEST FAILING)
				System.out.println("ERROR ON " + idx + " SEND");
			}
			try {
				api.exitAPI();
			} catch (API_Exception e) {
				System.out.println("exitAPI() ERROR in SenderThread");
			}
		}
		
	}

	class ReceiverThread extends Thread {
		
		private int idx;
		private String[] chans;
		private BolognaPiAPI api;
		
		public ReceiverThread(BolognaPiAPI api, String[] chans) {
			this.api = api;
			this.chans = new String[4]; 
			this.chans[0] = new String(chans[0]);
			this.chans[1] = new String(chans[1]);
			this.chans[2] = new String(chans[2]);
			this.chans[3] = new String(chans[3]);
		}
		
		public void run() {
			try {
				api.initAPI();
			} catch (API_Exception e) {
				System.out.println("initAPI() ERROR in ReceiverThread");
			}
			try { 
				System.out.println("recv: " + chans + "PRIMA");
				api.recv(chans); // TODO: receive data
				System.out.println("recv: " + chans + "DOPO");				
			}
			catch(API_Exception apie) {
				// TODO: HANDLE EXCEPTION (SETTING A VALUE FOR TEST FAILING)
				System.out.println("ERROR ON RECEIVER THREAD");
			}
			try {
				api.exitAPI();
			} catch (API_Exception e) {
				System.out.println("exitAPI() ERROR in ReceiverThread");
			}
		}
		
	}

}
