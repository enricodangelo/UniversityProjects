/*
 * Created on 16-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.net.InetAddress;
import java.net.Socket;

/**
 * 
 * @author Paolo Milazzo
 */
public class Test_ChannelManager implements Test {

	// test name
	private String name = "Simple Interaction with the Local Channel Manager (no API)"; 

	// test description
	private String[] desc = {
		"Connects to the local channel manager and sends/receives HELO"
	};
	
	// test number
	private int testNum;

	// output and logfile printers
	private OutputPrinter output;
	private LogPrinter log;
	
	// TCP port used to connect the local channel manager
	private int CMPort;
	private String CMAddrString = "127.0.0.1";

	// default constructor
	public Test_ChannelManager(int testNum, OutputPrinter outputPrinter, 
							   LogPrinter logPrinter, String CMAddr, int CMPort) {
		// set output
		if (outputPrinter!=null) output = outputPrinter;
		else {
			System.err.println("[Tester Debug] outputPrinter null in Test_ChannelManager()"); 
			output = new OutputPrinter();
		}
		// set log
		if (logPrinter!=null) log = logPrinter;
		else {
			System.err.println("[Tester Debug] logPrinter null in Test_ChannelManager()"); 
			log = new LogPrinter();
		}
		// set testNum
		this.testNum = testNum;
		
		// set CMPort and CMAddr;
		this.CMPort = CMPort;
		this.CMAddrString = CMAddr;
	}


	// executes the test
	public int execute() {

		// test start
		output.printTestStart(testNum,name,desc);
		log.printTestStart(testNum,name,desc);
		
		// ACTION: connect to the local channel manager
		output.printAct("Connecting to the local channel manager");
		output.printSubAct("opening socket connection to localhost:" + CMPort);
		
		// get localhost
		InetAddress CMAddr = null;
		try {
			CMAddr = InetAddress.getByName(CMAddrString);
		}
		catch (Exception e) {
			handleException(e,"UNABLE TO OBTAIN LOCALHOST ADDRESS (InetAddress.getLocalHost())");
			return 0;
		}
		
		// socket connection to the local channel manager
		Socket CMSock = null;
		try {
			CMSock = new Socket(CMAddr,CMPort);
		}
		catch (Exception e) {
			handleException(e,"UNABLE TO CONNECT TO LOCAL CHANNEL MANAGER (new Socket(CMAddr,CMPort))");
			return 0;
		}

		// creation of input/output streams to the local channel manager
		BufferedInputStream is = null;
		BufferedOutputStream os = null;
		try {
			is = new BufferedInputStream(CMSock.getInputStream());
			os = new BufferedOutputStream(CMSock.getOutputStream());
		}
		catch (Exception e) {
			handleException(e,"UNABLE TO OBTAIN INPUT/OUTPUT STREAMS TO LOCAL CM");
			return 0;
		}
		
		// nothing bad happened		
		output.printSubActOk();
		output.printActOk();
        
        
		// ACTION: send HELO and wait reply
		output.printAct("Sending HELO and waiting reply");

		// send HELO
		output.printSubAct("sending <HELO>");
		byte[] helo = {'H','E','L','O','\r','\n'};
		try {
			os.write(helo);
			os.flush();
		}
		catch(Exception e) {
			log.println("MESSAGE SENT: " + helo);
			log.println("MESSAGE LENGTH: " + helo.length);
			handleException(e,"UNABLE TO WRITE HELO TO LOCAL CHANNEL MANAGER");
			return 0;
		}
		
		// nothing bad happened
		output.printSubActOk();
        
		// wait HELO reply
		output.printSubAct("wait reply");
		char c = 'a'; StringBuffer sb = new StringBuffer();		
		log.print("RECEIVED: ");
		try {
			
			// HELO
			sb.append((char) is.read()); // 'H'
			sb.append((char) is.read()); // 'E'
			sb.append((char) is.read()); // 'L'
			sb.append((char) is.read()); // 'O'
			log.print(sb.toString());
			if (!sb.toString().equals("HELO")) {
				log.println();
				handleError("ERROR: MALFORMED HELO MESSAGE");
				return 0;
			}
			
			// \r
			if ((c = (char) is.read())=='\r')
				log.print("\r");
			else {
				log.println(c);
				handleError("MALFORMED HELO MESSAGE");
				return 0;
			}

			// \n
			if ((c = (char) is.read())=='\n')
				log.print("\n");
			else {
				log.println(c);
				handleError("MALFORMED HELO MESSAGE");
				return 0;
			}

			// NUM
			int i = 4; sb = new StringBuffer();
			while (true) {
				c = (char) is.read();
				if (c=='\r') {
					c= (char) is.read();
					if (c=='\n') break;
				} 
				sb.append(c);
			}
			int num = -1;
			try {
				log.println(sb.toString() + "\r\n");
				num = Integer.parseInt(sb.toString());
			}
			catch (NumberFormatException nfe) {
				handleException(nfe,"INVALID NUM IN HELO: " + sb.toString());
				return 0;	
			}
			if (num<0) {
				log.println();
				handleError("NUM < 0 IN HELO");
				return 0;
			}
			
			// IP ADDRS
			for (int j=0; j<num; j++) {
				sb = new StringBuffer();
				while (true) {
					c = (char) is.read();
					if (c=='\r') {
						c= (char) is.read();
						if (c=='\n') break;
					} 
					sb.append(c);
				}
				try {
					log.println(sb.toString() + "\r\n");
					InetAddress.getByName(sb.toString());
				}
				catch(Exception e) {
					handleException(e,"INVALID IP ADDRESS " + sb.toString());
					return 0;	
				}
			}
			// check if there are further (erroneous) data
			if (is.available()!=0) {
				log.println();
				handleError("RECEIVED MORE DATA THAN NECESSARY");
				byte[] surplus = new byte[is.available()];
				is.read(surplus);
				log.println("RECEIVED: " + surplus);
			}   
		}
		catch(Exception e) {
			log.println();
			handleException(e,"UNABLE TO RECEIVE THE REPLY FROM HELO");
			return 0;
		}
		
		// nothing bad happened		
		output.printSubActOk();
		output.printActOk();
		output.printTestOk();
		log.printTestOk();
		
		// TODO: CREATE A NEW CHANNEL, REACT AND DELETE IT
        
		return 1;
	}

	// return name
	public String getName() {
		return name;	
	}

	// return desc
	public String[] getDescription() {
		return desc;
	}

	// prints error messages when an exception occurs
	private void handleException(Exception e, String logMsg) {
		output.printSubActFail();
		log.println(logMsg);
		output.printException(e);
		log.printException(e);
		output.printTestFail();
		log.printTestFail();		
	}

	// prints error messages when an error occurs
	private void handleError(String msg) {
		log.println("ERROR: " + msg);
		output.printSubActFail();
		output.printError(msg);
		output.printActFail();
		output.printTestFail();
		log.printTestFail();
	}
}
