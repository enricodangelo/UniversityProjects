/*
 * Created on 20-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;

import bopi.api.BolognaPiAPI;
import bopi.api.BolognaPiImpl;

/**
 * 
 * @author Paolo Milazzo
 */
public class Test_SingleReaction implements Test {

	private int CMPort = 2047;
	private String CMAddr = "127.0.0.1";
	
	public Test_SingleReaction(String addr, int port) {
		CMPort = port;
		CMAddr = addr;
	}

	public int execute() {
		try {
		
		BolognaPiAPI api = BolognaPiImpl.getInstance(CMAddr,CMPort); 
		System.out.println("Istanza Creata");
		api.initAPI();
		System.out.println("initAPI()");
		String chan = api.newChannel();
		System.out.println("newChannel()");
		byte[] data = {'A','B','C','D'};
		api.asend(chan,data);
		System.out.println("asend()");
		byte[] data2 = api.recv(chan);
		System.out.println("recv()");
		System.out.println("data lenght: " + data2.length);
		System.out.print("data: ");
		for(int i=0; i<data2.length; i++) 
			System.out.print((char) data2[i]);
		System.out.println();
		api.deleteChannel(chan);
		System.out.println("deleteChannel()");
		api.exitAPI();
		System.out.println("exitAPI()"); 
		Thread.sleep(5000); 
		return 1;
		}
		catch (Exception e) {
			System.out.println(e);
			return 0;	
		}
	}

	public String getName() {
		return "Single Reaction";
	}

	public String[] getDescription() {
		String[] ret = { "Executes a reaction" };
		return ret;
	}

}
