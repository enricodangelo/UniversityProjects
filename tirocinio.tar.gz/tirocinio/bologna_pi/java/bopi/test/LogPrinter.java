/*
 * Created on 15-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 * 
 * @author Paolo Milazzo
 */
public class LogPrinter {

	// default file name for logs
	public static final String DEFAULT_LOG_FILE = "testerLog";
	
	// stream used for logs
	private PrintStream logfile = null;

	// default constructor: initializes the logfile using the default name
	public LogPrinter() {
		this(DEFAULT_LOG_FILE);
	}

	// constructor that specifies the name of the logfile
	public LogPrinter(String logFileName) {
		try {
			// initializing the logfile
			FileOutputStream logfileStream = 
				new FileOutputStream(new File(logFileName));
			logfile = new PrintStream(logfileStream, true);
			logfile.println("Logfile initialized");
			logfile.println();
		}
		catch(FileNotFoundException fnfe) {
			System.err.println("Error on logfile initialization " + logFileName);
			System.exit(1);
		}
	}

	// prints a message about the starting of a test
	public void printTestStart(int num, String name, String[] description) {
		logfile.println("TEST NUMBER " + num + " STARTED");
		logfile.println("TEST NAME: " + name);		
	}

	// prints a message about the completion of a test
	public void printTestOk() {
		logfile.println("*** TEST COMPLETED ***");
		logfile.println();
	}

	// prints a message about the failure of a test
	public void printTestFail() {
		logfile.println("*** TEST FAILED ***");
		logfile.println();
	}
	
	// prints a message about an exception raised
	public void printException(Exception e) {
		logfile.println("EXCEPTION RAISED: " + e);
		e.printStackTrace(logfile);		
	}
	
	// prints a newline
	public void println() {
		logfile.println();
	}

	// prints the string representation of an object
	public void print(Object o) {
		logfile.print(o);
	}
	
	// prints the string representation of an object (and a newline)
	public void println(Object o) {
		logfile.println(o);
	}

	// prints a string
	public void print(String s) {
		logfile.print(s);
	}
	
	// prints a string
	public void println(String s) {
		logfile.println(s);
	}

	// prints the string representation of an integer	
	public void print(int i) {
		logfile.print(i);
	}

	// prints the string representation of an integer (and a newline)
	public void println(int i) {
		logfile.println(i);
	}

	// prints the string representation of a char
	public void print(char c) {
		logfile.print(c);
	}

	// prints the string representation of a char (and a newline)
	public void println(char c) {
		logfile.println(c);
	}

	// prints the string representation of a byte
	public void print(byte b) {
		logfile.print(b);
	}

	// prints the string representation of a byte (and a newline)
	public void println(byte b) {
		logfile.println(b);
	}

	// prints the string representation of a byte array
	public void print(byte[] b) {
		logfile.print(b);
	}

	// prints the string representation of a byte array (and a newline)
	public void println(byte[] b) {
		logfile.println(b);
	}

}
