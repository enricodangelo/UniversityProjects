package bopi.api;

/**
 * This exception is thrown when the API is not initialized and some
 * operation that requires initialization is called.
 * This is the super-class of all exception thrown by the API
 * 
 * @author Paolo Milazzo
 */
public class API_Exception extends Exception {

	private static final long serialVersionUID = 3616444605290591545L;
	// keeps a copy of an exception that was catched and
	// that caused this exception
	private Exception originalException;
    
	public API_Exception() {
    }
    public API_Exception(Exception original) {
    	originalException = original;
    }
    
    public API_Exception(String msg) {
        super(msg);
    }
    
    public API_Exception(String msg, Exception original) {
    	super(msg);
    	originalException = original;
    }

}