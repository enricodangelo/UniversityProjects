package bopi.api;
public interface Blockable {
	public void setData(byte[] data);
	public byte[] getData();
	public void setStatus(int status);
	public int getStatus();
	public String getSubject();
	public void setSubject(String subject);
	public void block();
	public void unblock();
}