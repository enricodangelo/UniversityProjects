package bopi.api;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

/**
 * This interface defines the API that can be used by Java programs
 * in order to interact with the communication services provided by
 * the BolognaPi runtime.
 */
public interface BolognaPiAPI {

    /**
     * Initializes data structures, connections and threads used by the API.
     */
    public void initAPI() throws API_Exception;

    /**
     * Terminates threads and connections used by the API.
     */
    public void exitAPI() throws API_Exception;

    /**
     * Synchronously sends some data over a channel. The channel is 
     * identified by a string representing its name. In a point-to-point 
     * implementation based on channel managers, this channel can be either 
     * local or remote.
     */
    public void send(String channelName, byte[] data) throws API_Exception;
    
	/**
	 * Synchronously sends some data over a channel. The channel is 
	 * identified by a string representing its name. In a point-to-point 
	 * implementation based on channel managers, this channel can be either 
	 * local or remote. A Blockable object must be given for stopping and
	 * resuming the caller.
	 */
	public void send(String channelName, byte[] data, Blockable blk) throws API_Exception;
    
    /**
     * Synchronously sends some data over a channel. The channel is 
     * identified by a string representing its name. In a point-to-point 
     * implementation based on channel managers, this channel can be either 
     * local or remote.
     *
     * This version of send() uses a InputStream for data access, so it
     * is proper for binary data.
     */
    public void send(String channelName, InputStream data, int length) throws API_Exception;

	/**
	 * Synchronously sends some data over a channel. The channel is 
	 * identified by a string representing its name. In a point-to-point 
	 * implementation based on channel managers, this channel can be either 
	 * local or remote.
	 *
	 * This version of send() uses a InputStream for data access, so it
	 * is proper for binary data. A Blockable object must be given for stopping and
	 * resuming the caller.
	 */
	public void send(String channelName, InputStream data, int length, Blockable blk) throws API_Exception;

    /**
     * Synchronously sends some data over a channel. The channel is 
     * identified by a string representing its name. In a point-to-point 
     * implementation based on channel managers, this channel can be either 
     * local or remote.
     *
     * This version of send() uses a Reader for data access, so it
     * is proper for character data.
     */
    public void send(String channelName, Reader data, int length) throws API_Exception;

	/**
	 * Synchronously sends some data over a channel. The channel is 
	 * identified by a string representing its name. In a point-to-point 
	 * implementation based on channel managers, this channel can be either 
	 * local or remote.
	 *
	 * This version of send() uses a Reader for data access, so it
	 * is proper for character data. A Blockable object must be given for stopping and
	 * resuming the caller.
	 */
	public void send(String channelName, Reader data, int length, Blockable blk) throws API_Exception;

    /**
     * Asynchronously sends some data over a channel. The channel is 
     * identified by a string representing its name. In a point-to-point 
     * implementation based on channel managers, this channel can be either 
     * local or remote.
     *
     * This version of asend() uses a InputStream for data access, so it
     * is proper for binary data.
     */
    public void asend(String channelName, byte[] data) throws API_Exception;

    /**
     * Asynchronously sends some data over a channel. The channel is 
     * identified by a string representing its name. In a point-to-point 
     * implementation based on channel managers, this channel can be either 
     * local or remote.
     *
     * This version of asend() uses a InputStream for data access, so it
     * is proper for binary data.
     */
    public void asend(String channelName, InputStream data, int length) throws API_Exception;

    /**
     * Asynchronously sends some data over a channel. The channel is 
     * identified by a string representing its name. In a point-to-point 
     * implementation based on channel managers, this channel can be either 
     * local or remote.
     *
     * This version of asend() uses a Reader for data access, so it
     * is proper for character data.
     */
    public void asend(String channelName, Reader data, int length) throws API_Exception;

    /**
     * Receives some data over a single channel. The channel is identified by a
     * string representing its name. In a point-to-point implementation
     * based on channel managers, this channel can be either local or
     * remote.
     */
    public byte[] recv(String channelName) throws API_Exception;

    /**
     * Receives some data over a set of channels. Channels are identified by a
     * string representing their names. In a point-to-point implementation
     * based on channel managers, these channels can be either local or
     * remote.
     */
    public byte[] recv(String[] channelNames) throws API_Exception;

	/**
	 * Receives some data over a single channel. The channel is identified by a
	 * string representing its name. In a point-to-point implementation
	 * based on channel managers, this channel can be either local or
	 * remote. A Blockable object must be given for stopping and resuming 
	 * the caller.
	 */
	public byte[] recv(String channelName, Blockable blk) throws API_Exception;

	/**
	 * Receives some data over a set of channels. Channels are identified by a
	 * string representing their names. In a point-to-point implementation
	 * based on channel managers, these channels can be either local or
	 * remote. A Blockable object must be given for stopping and resuming 
	 * the caller.
	 */
	public byte[] recv(String[] channelNames, Blockable blk) throws API_Exception;
 
    /**
     * Receives some data over a single channel. The channel is identified by a
     * string representing its name. In a point-to-point implementation
     * based on channel managers, this channel can be either local or
     * remote.
     *
     * This version of recv() uses a OutputStream to return the received
     * data, so it is proper for binary data. The length of the data is
     * returned
     */
    public int recv(String channelName, OutputStream data) throws API_Exception;

    /**
     * Receives some data over a set of channels. Channels are identified by a
     * string representing their names. In a point-to-point implementation
     * based on channel managers, these channels can be either local or
     * remote.
     *
     * This version of recv() uses a OutputStream to return the received
     * data, so it is proper for binary data. The length of the data is
     * returned
     */
    public int recv(String[] channelNames, OutputStream data) throws API_Exception;

	/**
	 * Receives some data over a single channel. The channel is identified by a
	 * string representing its name. In a point-to-point implementation
	 * based on channel managers, this channel can be either local or
	 * remote.
	 *
	 * This version of recv() uses a OutputStream to return the received
	 * data, so it is proper for binary data. The length of the data is
	 * returned. A Blockable object must be given for stopping and resuming 
	 * the caller.
	 */
	public int recv(String channelName, OutputStream data, Blockable blk) throws API_Exception;

	/**
	 * Receives some data over a set of channels. Channels are identified by a
	 * string representing their names. In a point-to-point implementation
	 * based on channel managers, these channels can be either local or
	 * remote.
	 *
	 * This version of recv() uses a OutputStream to return the received
	 * data, so it is proper for binary data. The length of the data is
	 * returned. A Blockable object must be given for stopping and resuming 
	 * the caller.
	 */
	public int recv(String[] channelNames, OutputStream data, Blockable blk) throws API_Exception;

    /**
     * Receives some data over a single channel. The channel is identified by a
     * string representing its name. In a point-to-point implementation
     * based on channel managers, this channel can be either local or
     * remote.
     *
     * This version of recv() uses a Writer to return the received
     * data, so it is proper for character data. The length of the data is
     * returned
     */
    public int recv(String channelName, Writer data) throws API_Exception;

    /**
     * Receives some data over a set of channels. Channels are identified by a
     * string representing their names. In a point-to-point implementation
     * based on channel managers, these channels can be either local or
     * remote.
     *
     * This version of recv() uses a Writer to return the received
     * data, so it is proper for character data. The length of the data
     * is returned
     */
    public int recv(String[] channelNames, Writer data) throws API_Exception;

	/**
	 * Receives some data over a single channel. The channel is identified by a
	 * string representing its name. In a point-to-point implementation
	 * based on channel managers, this channel can be either local or
	 * remote.
	 *
	 * This version of recv() uses a Writer to return the received
	 * data, so it is proper for character data. The length of the data is
	 * returned. A Blockable object must be given for stopping and resuming 
	 * the caller.
	 */
	public int recv(String channelName, Writer data, Blockable blk) throws API_Exception;

	/**
	 * Receives some data over a set of channels. Channels are identified by a
	 * string representing their names. In a point-to-point implementation
	 * based on channel managers, these channels can be either local or
	 * remote.
	 *
	 * This version of recv() uses a Writer to return the received
	 * data, so it is proper for character data. The length of the data
	 * is returned. A Blockable object must be given for stopping and resuming 
	 * the caller.
	 */
	public int recv(String[] channelNames, Writer data, Blockable blk) throws API_Exception;

    /**
     * Linear Forwarder
     */
    public void fwd(String srcChannel, String dstChannel) throws API_Exception;

    /**
     * Creates a new local channel and returns an identifier for it (a string
     * representing its name). 
     */
    public String newChannel() throws API_Exception;

	/**
	 * Creates a new channel and returns an identifier for it (a string
	 * representing its name). The new channel is created at the same location
	 * identified by ip and port values
	 */
	public String newChannel(String ip, int port) throws API_Exception;

    /**
     * Creates a new channel and returns an identifier for it (a string
     * representing its name). The new channel is created at the same location
     * of 'colocatedChannel'
     */
    public String newChannel(String colocatedChannel) throws API_Exception;

    /**
     * Removes the channel identified by channelName. After the call, 
     * communications over this channel are no longer possible.
	 * The channel to be removed can be either local or remote.
	 * 
	 * @param channelName the name of the channel that will be removed
     */
    public void deleteChannel(String channelName) throws API_Exception;
    
    /** 
     * Checks if a channel is local (channelName = IPADDR:PORT#SEQNUM)
     * This method dosn't check for the existance of the channel
     * and it dosn't communicates with the local channel manager.
     * The test for locality is done only by examining the channel name.
     */
    public boolean isLocal(String channelName);
}