package bopi.api;

import java.io.OutputStream;
import java.io.PrintStream;
import java.io.IOException;

/*
 * This class represents messages sent to the local channel manager. Messages
 * have one of the following formats: <"SND" "LCL" "1" \n CHAN \0 IDX \0 LENGTH
 * \0 DATA> <"SND" "RMT" "1" \n CHAN \0 ACK_CHAN \0 LENGTH \0 DATA> <"RCV" "LCL"
 * NUM \n CHAN[0] \0 ... CHAN[NUM-1] \0 IDX \0 0 \0>
 * 
 * TODO: RIVEDERE IL PROSSIMO:
 * 
 * <"RCV" "RMT" NUM \0 CHAN[0] \0 ... CHAN[NUM-1] \0 ACK_CHAN \0 0 \0>
 * 
 * 
 * where:
 * 
 * TODO: FINIRE LA DESCRIZIONE
 */
public class MsgToCM {

    // Fields:
    public String type; // "SND" or "RCV" or "NEW" or "DEL"

    public String location; // LCL or RMT

    public String[] chanNames; // Subject channels

    public String continuation;// Private data if LCL or forward/ack

    // channel if RMT
    public String dataLength; // Length of the data field

    public byte[] data; // Data field

    // Default constructor
    private MsgToCM() {
    }

    // Creates a new SND message. The length of the data is inferred from 'data'
    public static MsgToCM createSND(String loc, String chan, byte[] data) {
        MsgToCM msg = new MsgToCM();
        msg.type = "SND";
        msg.location = loc;
        msg.chanNames = new String[1];
        msg.chanNames[0] = chan;
        msg.continuation = null;
        msg.dataLength = Integer.toString(data.length);
        msg.data = new byte[data.length];
        System.arraycopy(data, 0, msg.data, 0, data.length);
        return msg;
    }

    // Creates a new RCV message (multi-subject version).
    public static MsgToCM createRCV(String loc, String[] chans) {
        MsgToCM msg = new MsgToCM();
        msg.type = "RCV";
        msg.location = loc;
        msg.chanNames = chans;
        msg.continuation = null;
        msg.dataLength = "0";
        msg.data = null;
        return msg;
    }

    // Creates a new RCV message (single subject version).
    public static MsgToCM createRCV(String loc, String chan) {
        MsgToCM msg = new MsgToCM();
        msg.type = "RCV";
        msg.location = loc;
        msg.chanNames = new String[1];
        msg.chanNames[0] = chan;
        msg.continuation = null;
        msg.dataLength = "0";
        msg.data = null;
        return msg;
    }

    // Create a new NEW message
    public static MsgToCM createNEW(String loc) {
        MsgToCM msg = new MsgToCM();
        msg.type = "NEW";
        msg.location = loc;
        msg.chanNames = null;
        msg.continuation = null;
        msg.dataLength = "0";
        msg.data = null;
        return msg;
    }

    // Create a new DEL message
    public static MsgToCM createDEL(String chan) {
        MsgToCM msg = new MsgToCM();
        msg.type = "DEL";
        msg.location = null;
        msg.chanNames = new String[1];
        msg.chanNames[0] = chan;
        msg.continuation = null;
        msg.dataLength = "0";
        msg.data = null;
        return msg;
    }

    // Adds a 'continuation' to the message (this is not part of the
    // constructor)
    public void setContinuation(String cont) {
        this.continuation = new String(cont);
    }

    // Checks if the message is valid...
    public boolean isValid() {
        // TODO: MORE CHECKS (chanNames values != null and wellformed, etc...)
        if (type.equals("SND")
                && (continuation == null || chanNames.length != 1)) return false;

        else if (type.equals("RCV")
                && (continuation == null || (location.equals("RMT") && chanNames.length != 1))) return false;

        else if (type.equals("NEW") && (continuation == null)) return false;

        return true;
    }

    // Sends the message over the given output stream
    // Returns 0 if ok, -1 if error, -2 if invalid message
    public int putMessage(OutputStream os) {
        if (!isValid()) {
            System.err.println("not valid");
            return -2;
        }
        PrintStream ps = new PrintStream(os, true);
        if (type.equals("SND")) {
            ps.print(type);
            ps.print(location + "\r\n");
            ps.print(chanNames[0] + "\r\n");
            if (continuation.equals("-1")) // if async
            ps.print("\r\n");
            else
            // if sync
            ps.print(continuation + "\r\n");
            ps.print(dataLength + "\r\n");
            try {
                ps.write(data);
            } catch (IOException ioe) {
                System.err.println(ioe);
                return -1;
            }
        } else if (type.equals("RCV")) {
            ps.print(type);
            ps.print(location + "\r\n");
            ps.print(Integer.toString(chanNames.length) + "\r\n");
            // the same continuation is sent for all channels
            // why? two cases: 1) there is a single channel (either lcl or rmt)
            //                 2) there are multiple channels... but they are
            //                    all local!
            for (int i = 0; i < chanNames.length; i++) {
                ps.print(chanNames[i] + "\r\n");
                ps.print(continuation + "\r\n");
            }
        } else if (type.equals("NEW")) {
            ps.print(type);
            ps.print(location + "\r\n");
            ps.print(continuation + "\r\n");
        } else if (type.equals("DEL")) {
            ps.print(type + "\r\n");
            ps.print(chanNames[0] + "\r\n");
        } else { /* TODO: HANDLE ERRORS */
        }
        // if an IO error occurs, return -1
        if (ps.checkError()) {
            System.err.println("IO error");
            return -1;
        }
        return 0;

    }
}