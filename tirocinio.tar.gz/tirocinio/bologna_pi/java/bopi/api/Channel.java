/*
 * Created on 23-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.api;

import java.io.StringReader;
import java.io.StringWriter;

/**
 * 
 * @author Paolo Milazzo
 */
public class Channel {

	/**
	 * An instance of the API used for communications
	 */
	private BolognaPiAPI api = null;

	/**
	 * the name of the channel
	 */
	private String name = null;

	/** 
	 * Default constructor for a local channel
	 * 
	 * @throws API_Exception if an error occurs calling getInstance() or
	 * if it uses an api object that is not initialized
	 * 
     * @see BolognaPiImpl#getInstance()
	 */
	public Channel() throws API_Exception {
		api = BolognaPiImpl.getInstance();
		name = api.newChannel();
	}

	/**
	 * Constructor for remote channels
	 * 	 
	 * @param ip the ip address of the remote channel manager where the
	 * new channel will be created
	 * @param port the tcp port number of the remote channel manager where the
	 * new channel will be created
	 * @throws API_Exception if an error occurs calling getInstance() or
	 * if it uses an api object that is not initialized
	 * 
     * @see BolognaPiImpl#getInstance()
	 */	
	public Channel(String ip, int port) throws API_Exception {
		api = BolognaPiImpl.getInstance();
		name = api.newChannel(ip,port);
	}

	/**
	 * Constructor for colocated channels
	 * 	 
	 * @param colocated the name of the channel residing at the location
	 * where the new channel will be created
	 * @throws API_Exception if an error occurs calling getInstance() or
	 * if it uses an api object that is not initialized
	 * 
	 * @see BolognaPiImpl#getInstance()
	 */	
	public Channel(String colocated) throws API_Exception {
		// TODO: CHECK IF COLOCATED EXISTS
		api = BolognaPiImpl.getInstance();
		name = api.newChannel(colocated);
	}
	
	// private constructor for the creation of references to 
	// pre-existing channels
	private Channel(String ref, boolean isReference) throws API_Exception {
		if (isReference) {
			api = BolognaPiImpl.getInstance();
			name = new String(ref);
		}
		else throw new API_Exception("A reference to the channel " + ref + " cannot be created");
	}
	
	/**
	 * Returns a Channel object that is a reference to a pre-existent channel
	 * 
	 * @param name - the name of the channel that must be referenced
	 * @throws API_Exception if an error occurs calling getInstance() or
	 * if it uses an api object that is not initialized
	 * 
	 * @see BolognaPiImpl#getInstance()
	 */
	public static Channel getReference(String name) throws API_Exception {
		// TODO: CHECK IF NAME EXISTS
		return new Channel(name, true);
	}
	
	// sends a message (synchronously)
	public void send(byte[] data) throws API_Exception {
		api.send(name,data);
	}

	// sends a String (synchronously)
	public void send(String data) throws API_Exception {
		api.send(name, new StringReader(data), data.length());
	}
	
	// sends an int (synchronously) - the int value is sent as
	// a string
	public void send(int data) throws API_Exception {
		String strData = Integer.toString(data);
		api.send(name, new StringReader(strData), strData.length());
	}
	
	// sends a message (asynchrnously)
	public void asend(byte[] data) throws API_Exception {
		api.asend(name,data);
	}
	
	// sends a String (asynchronously)	
	public void asend(String data) throws API_Exception {
		api.asend(name, new StringReader(data), data.length());
	}
	
	// sends an int (asynchronously) - the int value is sent as
	// a string
	public void asend(int data) throws API_Exception {
		String strData = Integer.toString(data);
		api.asend(name, new StringReader(strData), strData.length());
	}
	
	// receives a message
	public byte[] recv() throws API_Exception {
		return api.recv(name);
	}

	// receives a String		
	public String recvString() throws API_Exception {
		StringWriter sw = new StringWriter();
		int length = api.recv(name, sw);
		String data = sw.toString();
		if (data.length()!=length) throw new API_Exception(); // TODO: EXCEPTION
		return data; 
	}

	// receives an int - the int value is received as a string	
	public int recvInt() throws API_Exception {
		String strData = recvString();
		int data;
		try {
			data = Integer.parseInt(strData);
		}
		catch (NumberFormatException nfe) {
			throw new API_Exception(); // TODO: EXCEPTION
		}
		return data;
	}
	
	// deletes the channel
	public void delete() throws API_Exception {
		api.deleteChannel(name);
	}
	
	// returns the name of the channel
	public String getName() {
		return name;
	}
	
	public String toString(){
		return name;
	}
}
