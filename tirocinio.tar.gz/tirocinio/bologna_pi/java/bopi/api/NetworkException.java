/*
 * Created on 27-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.api;

/**
 * This exception is thrown when an error occurs reading from or
 * writing to a socket
 *  
 * @author Paolo Milazzo
 */
public class NetworkException extends API_Exception {

	private static final long serialVersionUID = 3257852060589502512L;

	public NetworkException() {
		super();
	}

	public NetworkException(String msg) {
		super(msg);
	}

	public NetworkException(Exception original) {
		super(original);
	}

	public NetworkException(String msg, Exception original) {
		super(msg, original);
	}
}
