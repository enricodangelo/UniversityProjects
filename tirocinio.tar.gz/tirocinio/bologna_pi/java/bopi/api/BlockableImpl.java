package bopi.api;
public class BlockableImpl implements Blockable {
	private byte[] data;
	private String subject; // The subject of the communication
	// TODO: HANDLE THE STATUS    
	private int status; // 0 = OK, 1 = NOT FOUND
	public void setData(byte[] data) {
		this.data= new byte[data.length];
		System.arraycopy(data, 0, this.data, 0, data.length);
	}
	public byte[] getData() {
		return this.data;
	}
	public String getStringData() {
		StringBuffer sb= new StringBuffer();
		for (int i= 0; i < data.length; i++) {
			sb.append((char) data[i]);
		}
		return sb.toString();
	}
	public void setSubject(String subject) {
		this.subject= subject;
	}
	public String getSubject() {
		return this.subject;
	}
	// this method is not synchronized!!!
	public void block() {
		try {
			this.wait();
		} catch (InterruptedException ie) {
			// TODO: HANDLE EXCEPTION		
		}
	}
	// this method is not synchronized!!!
	public void unblock() {
			this.notify();
	}
	public void setStatus(int status) {
		this.status= status;
	}
	public int getStatus() {
		return this.status;
	}
}
