/*
 * Created on 27-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.api;

/**
 * This exception is thrown when a channel manager cannot be found at
 * a certain location
 *  
 * @author Paolo Milazzo
 */
public class CMNotFoundException extends API_Exception {

	private static final long serialVersionUID = 3761971549133355061L;

	public CMNotFoundException() {
		super();
	}

	public CMNotFoundException(String msg) {
		super(msg);
	}

	public CMNotFoundException(Exception original) {
		super(original);
	}

	public CMNotFoundException(String msg, Exception original) {
		super(msg, original);
	}

}
