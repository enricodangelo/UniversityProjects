/*
 * Created on 27-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.api;

/**
 * This exception is thrown when a channel cannot be found
 *  
 * @author Paolo Milazzo
 */
public class ChannelNotFoundException extends API_Exception {

	private static final long serialVersionUID = 3978147646944852281L;

	public ChannelNotFoundException() {
		super();
	}

	public ChannelNotFoundException(String msg) {
		super(msg);
	}

	public ChannelNotFoundException(Exception original) {
		super(original);
	}

	public ChannelNotFoundException(String msg, Exception original) {
		super(msg, original);
	}
}
