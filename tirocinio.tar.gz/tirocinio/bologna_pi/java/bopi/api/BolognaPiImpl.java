package bopi.api;

import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.io.IOException;

/**
 * Implementation of the BolognaPiAPI based on channel managers. This
 * implementation uses TCP/IP for communications over point-to-point networks.
 * Channel names are assumed to be in the form IPADDR:PORT#SEQNUM where IPADDRES
 * is a valid IP address in standard dotted notation, PORT is a TCP port number
 * and SEQNUM is a number that is used to univocally identify the channel.
 * 
 * @author Paolo Milazzo
 * @see BolognaPiAPI
 */
public class BolognaPiImpl implements BolognaPiAPI {
	// Singleton!
	private static BolognaPiImpl instance = null;

	// Single thread shared by all the callers of this API (counted by 'users')
	private static ListenerThread sharedListener = null;

	private static int users = 0;

	// IP Adresses and TCP port number of the local channel manager
	private static String[] CMAddrs = null;

	private static String CMConnectionAddr = null;

	private static String CMPort = null;

	private static int CMPort_intVal;

	/**
	 * Default constructor. It is private because we want use getInstance()
	 */
	private BolognaPiImpl() {
	}

	/**
	 * This method and getInstance(String CM_addr, int CM_Port) substitute the
	 * constructor of the class. The first time one of them is called it creates
	 * a new instance of the class. This instance is used also as the return
	 * value of any further call. This version of getInstance() uses 'localhost'
	 * as IP address for the connection to the local channel manager on the port
	 * specified as argument
	 * 
	 * @param CM_Port
	 *            the TCP port number of the local channel manager (on
	 *            localhost)
	 * @return the single instance of this class
	 * @throws API_Exception
	 *             if an error occurs
	 * @see BolognaPiAPI
	 */
	public static synchronized BolognaPiImpl getInstance(int CM_Port) throws API_Exception {
		if (instance == null)
			return getInstance("localhost", CM_Port);
		return getInstance(CMConnectionAddr, CM_Port);
	}

	/**
	 * This method and getInstance(int CM_Port) substitute the constructor of
	 * the class. The first time one of them is called it creates a new instance
	 * of the class. This instance is used also as the return value of any
	 * further call. This version of getInstance() uses the IP address and TCP
	 * port passed as arguments to connect to the local channel manager
	 * 
	 * @param CM_Addr
	 *            the IP address of the local channel manager
	 * @param CM_Port
	 *            the TCP port number of the local channel manager
	 * @return the single instance of this class
	 * @throws API_Exception
	 *             if an error occurs
	 * @see BolognaPiAPI
	 */
	public static synchronized BolognaPiImpl getInstance(String CM_Addr, int CM_Port) throws API_Exception {
		if (CM_Addr == null) {
			throw new API_Exception("the string representing the IP address is null");
		}
		if (instance == null) {
			instance = new BolognaPiImpl();
			// store CM_Port and CM_Addr;
			CMPort = Integer.toString(CM_Port);
			CMPort_intVal = CM_Port;
			CMConnectionAddr = new String(CM_Addr);
			try {
				// TODO: PROBABLY HERE THERE IS SOMETHING TO REMOVE!!!
				InetAddress CMInetAddress = InetAddress.getByName(CMConnectionAddr);
				sharedListener = new ListenerThread(CMInetAddress, CMPort_intVal);
				sharedListener.setDaemon(true);
				CMAddrs = sharedListener.getLocalAddresses();
			} catch (IOException ioe) {
				throw new API_Exception("Error occured creating the shared listener thread");
			}
		} else {
			if (!CM_Addr.equals(CMConnectionAddr) || CM_Port != CMPort_intVal) {
				// throw new API_Exception("Channel Manager already connected at
				// a different TCP/IP address");
			}
		}
		return instance;
	}

	/**
	 * This method returns the single instance of this class. The instance must
	 * be already created by the version of getInstance() that allows the
	 * specification of the TCP port number
	 * 
	 * @return the single instance
	 * @throws API_Exception
	 *             if the instance is not initialized (that is when
	 *             getInstance(int CM_port) of getInstance(String CM_Addr, int
	 *             CM_Port) were not called before)
	 * @see BolognaPiAPI
	 */
	public static synchronized BolognaPiImpl getInstance() throws API_Exception {
		if (instance == null)
			throw new API_Exception("Instance not present");
		return instance;
	}

	/**
	 * Connects the local channel manager and starts the execution of the shared
	 * listener thread (the thread that waits for messages from the channel
	 * manager) if it is not running.
	 * 
	 * @throws API_Exception
	 *             if an error occurs during the creation and initialization of
	 *             the shared listener thread
	 * @see ListenerThread
	 */
	public synchronized void initAPI() throws API_Exception {
		users++;
		if (!sharedListener.isRunning()) {
			try {
				InetAddress CMInetAddress = InetAddress.getByName(CMConnectionAddr);
				sharedListener = new ListenerThread(CMInetAddress, CMPort_intVal);
				sharedListener.setDaemon(true);
			} catch (IOException ioe) {
				throw new API_Exception("Error on creating the shared listener thread");
			}
			CMAddrs = sharedListener.connectAndRun();
			if (CMAddrs != null)
				sharedListener.start();
			else
				throw new API_Exception("Error on getting the list of local channels (HELO)");
		}
	}

	/**
	 * Stops the execution of the shared listener thread
	 * 
	 * @throws API_Exception
	 *             if an input/output error occurs during the termination of the
	 *             thread
	 * @see ListenerThread
	 */
	public synchronized void exitAPI() throws API_Exception {
		users--;
		if ((users <= 0) && (sharedListener.isRunning())) {
			try {
				sharedListener.terminate();
			} catch (IOException ioe) {
				throw new API_Exception("Error or terminating the shared listener thread");
			}
		}
	}

	/**
	 * Synchronously sends a message over a channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            the data to be sent
	 * @param blk
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#send(String, byte[], Blockable)
	 */
	public void send(String channelName, byte[] data, Blockable blk) throws API_Exception {
		this.send(channelName, data, blk, true);
	}

	/**
	 * Synchronously sends a message over a channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            the data to be sent
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#send(String, byte[])
	 */
	public void send(String channelName, byte[] data) throws API_Exception {
		this.send(channelName, data, new BlockableImpl(), true);
	}

	/**
	 * Synchronously sends a message over a channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            an InputStream that can be used to obtain the data
	 * @param length
	 *            the length of the data
	 * @param blk
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#send(String, InputStream, int, Blockable)
	 */
	public void send(String channelName, InputStream data, int length, Blockable blk) throws API_Exception {
		byte[] buf = new byte[length];
		try {
			if (data.read(buf) != length) { /* TODO: HANDLE ERRORS */
			}
		} catch (IOException ioe) {
			throw new API_Exception("Error occured reading from an InputStream");
		}
		this.send(channelName, buf, blk, true);
	}

	/**
	 * Synchronously sends a message over a channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            an InputStream that can be used to obtain the data
	 * @param length
	 *            the length of the data
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#send(String, InputStream, int)
	 */
	public void send(String channelName, InputStream data, int length) throws API_Exception {
		this.send(channelName, data, length, new BlockableImpl());
	}

	/**
	 * Synchronously sends a message over a channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            a Reader that can be used to obtain the data
	 * @param length
	 *            the length of the data
	 * @param blk
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#send(String, Reader, int, Blockable)
	 */
	public void send(String channelName, Reader data, int length, Blockable blk) throws API_Exception {
		char[] cbuf = new char[length];
		byte[] buf = new byte[length];
		try {
			if (data.read(cbuf) != length) { /* TODO HANDLE ERRORS */
			}
		} catch (IOException ioe) {
			throw new API_Exception("Error occured reading from a Reader");
		}
		for (int i = 0; i < length; i++) {
			buf[i] = (byte) cbuf[i];
		}
		this.send(channelName, buf, blk, true);
	}

	/**
	 * Synchronously sends a message over a channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            a Reader that can be used to obtain the data
	 * @param length
	 *            the length of the data
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#send(String, Reader, int)
	 */
	public void send(String channelName, Reader data, int length) throws API_Exception {
		this.send(channelName, data, length, new BlockableImpl());
	}

	/**
	 * Asynchronously sends a message over a channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            the data to be sent
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#asend(String, byte[])
	 */
	public void asend(String channelName, byte[] data) throws API_Exception {
		this.send(channelName, data, null, false);
	}

	/**
	 * Asynchronously sends a message over a channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            an InputStream that can be used to obtain the data
	 * @param length
	 *            the length of the data
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#asend(String, InputStream, int)
	 */
	public void asend(String channelName, InputStream data, int length) throws API_Exception {
		byte[] buf = new byte[length];
		try {
			if (data.read(buf) != length) { /* TODO: HANDLE ERRORS */
			}
		} catch (IOException ioe) {
			throw new API_Exception("Error occured reading from an InputStream");
		}
		this.send(channelName, buf, null, false);
	}

	/**
	 * Asynchronously sends a message over a channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            an InputStream that can be used to obtain the data
	 * @param length
	 *            the length of the data
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#asend(String, Reader, int)
	 */
	public void asend(String channelName, Reader data, int length) throws API_Exception {
		char[] cbuf = new char[length];
		byte[] buf = new byte[length];
		try {
			if (data.read(cbuf) != length) { /* TODO HANDLE ERRORS */
			}
		} catch (IOException ioe) {
			throw new API_Exception("Error occured reading from a Reader");
		}
		for (int i = 0; i < length; i++) {
			buf[i] = (byte) cbuf[i];
		}
		this.send(channelName, buf, null, false);
	}

	/**
	 * Receives a message over a single channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param blk
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String, Blockable)
	 */
	public byte[] recv(String channelName, Blockable blk) throws API_Exception {
		String[] names = { channelName };
		return recv(names, blk);
	}

	/**
	 * Receives a message over a single channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String)
	 */
	public byte[] recv(String channelName) throws API_Exception {
		return recv(channelName, new BlockableImpl());
	}

	/**
	 * Receives a message over a set of channels. Implementation of the
	 * BolognaPiAPI interface method. Distributed coiche is encoded into local
	 * choice usign linear forwarders
	 * 
	 * @param channelNames
	 *            the names of the subject channels
	 * @param blk
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String[], Blockable)
	 */
	public byte[] recv(String[] channelNames, Blockable blk) throws API_Exception {
		String[] localChannels = new String[channelNames.length];
		for (int i = 0; i < channelNames.length; i++) {
			if (isLocal(channelNames[i]))
				localChannels[i] = channelNames[i];
			else {
				// create a new local channel ...
				localChannels[i] = newChannel();
				// ... send the message to the remote channel manager...
				MsgToCM msg1 = MsgToCM.createRCV("RMT", channelNames[i]);
				msg1.setContinuation(localChannels[i]); // LINEAR FORWARDER!!!
				try {
					Socket sock = channelConnect(channelNames[i]);
					int res = msg1.putMessage(sock.getOutputStream());
					handlePutMessageRetVal(res);
				} catch (UnknownHostException uhe) {
					throw new CMNotFoundException("Unknown Host " + getChannelIp(channelNames[i]) + ":"
							+ getChannelPort(channelNames[i]), uhe);
				} catch (IOException ioe) {
					throw new NetworkException("NetworkError on connection to " + getChannelIp(channelNames[i]) + ":"
							+ getChannelPort(channelNames[i]), ioe);
				}
			}
		}
		// ... receive a message on one of the local channels ...
		MsgToCM msg2 = MsgToCM.createRCV("LCL", localChannels);
		synchronized (blk) {
			sharedListener.sendLocal(msg2, blk);
			blk.block();
		}
		String chosen = blk.getSubject();
		// ... send the reverse forwarders (if necessary)
		if (channelNames.length > 1) {
			for (int i = 0; i < channelNames.length; i++) {
				if ((!chosen.equals(localChannels[i])) && (!localChannels[i].equals(channelNames[i]))) {
					MsgToCM msg3 = MsgToCM.createRCV("RMT", localChannels[i]);
					msg3.setContinuation(channelNames[i]); // REVERSE
															// FORWARDER!!!
					sharedListener.sendLocalAsRemote(msg3);
				}
			}
		}
		// TODO: I would like to delete all the local channels used only for
		// linear forwarders but I can't (because they must handle the
		// reverse forwarder)
		return blk.getData();
	}

	/***************************************************************************
	 * This two methods are quite dangerous but allow us a better implementation
	 * of the runtime because we do not block the process and we split the
	 * receive in two phases. In the first there is the request of receiving a
	 * value. In the second undo forwarders are created. (In this way if the
	 * machine is single thread after the request of receiving the thread is
	 * blocked and the next operation will use the undo forwaders) /*
	 **************************************************************************/
	/**
	 * Request of receiving a message over a set of channels. Distributed coiche
	 * is encoded into local choice usign linear forwarders. <bold>The method
	 * undoFwd must be called after the receive on the same set of channels</bold>
	 * 
	 * @param channelNames
	 *            the names of the subject channels
	 * @param blk
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String[], Blockable)
	 */
	public void reqRecv(String[] channelNames, Blockable blk) throws API_Exception {
		String[] localChannels = new String[channelNames.length];
		for (int i = 0; i < channelNames.length; i++) {
			if (isLocal(channelNames[i]))
				localChannels[i] = channelNames[i];
			else {
				// create a new local channel ...
				localChannels[i] = newChannel();
				// ... send the message to the remote channel manager...
				MsgToCM msg1 = MsgToCM.createRCV("RMT", channelNames[i]);
				msg1.setContinuation(localChannels[i]); // LINEAR FORWARDER!!!
				try {
					Socket sock = channelConnect(channelNames[i]);
					int res = msg1.putMessage(sock.getOutputStream());
					handlePutMessageRetVal(res);
				} catch (UnknownHostException uhe) {
					throw new CMNotFoundException("Unknown Host " + getChannelIp(channelNames[i]) + ":"
							+ getChannelPort(channelNames[i]), uhe);
				} catch (IOException ioe) {
					throw new NetworkException("NetworkError on connection to " + getChannelIp(channelNames[i]) + ":"
							+ getChannelPort(channelNames[i]), ioe);
				}
			}
		}
		// ... receive a message on one of the local channels ...
		MsgToCM msg2 = MsgToCM.createRCV("LCL", localChannels);
		synchronized (blk) {
			sharedListener.sendLocal(msg2, blk);
			blk.block();
		}
	}

	/**
	 * it must be called after the "reqRecv" passing the same set of channels
	 * and the name of the channel where the reaction was performed. It provides
	 * for undo forwarders.
	 * 
	 * @param channelNames -
	 *            the names of the subject channels
	 * @param choosen -
	 *            the name of the channel that have reacted
	 * @throws API_Exception
	 *             if something is not initialized properly
	 */
	public void undoFwd(String[] channelNames, String choosen) throws API_Exception {
		if (channelNames.length == 1)
			return;
		String[] localChannels = new String[channelNames.length];
		for (int i = 0; i < channelNames.length; i++) {
			if (isLocal(channelNames[i]))
				localChannels[i] = channelNames[i];
		}
		// ... send the reverse forwarders (if necessary)
		if (channelNames.length > 1) {
			for (int i = 0; i < channelNames.length; i++) {
				if ((!choosen.equals(localChannels[i])) && (!localChannels[i].equals(channelNames[i]))) {
					MsgToCM msg3 = MsgToCM.createRCV("RMT", localChannels[i]);
					msg3.setContinuation(channelNames[i]); // REVERSE
															// FORWARDER!!!
					sharedListener.sendLocalAsRemote(msg3);
				}
			}
		}
		// TODO: I would like to delete all the local channels used only for
		// linear forwarders but I can't (because they must handle the
		// reverse forwarder)
	}

	/**
	 * Receives a message over a set of channels. Implementation of the
	 * BolognaPiAPI interface method. Distributed coiche is encoded into local
	 * choice usign linear forwarders
	 * 
	 * @param channelNames
	 *            the names of the subject channels
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String[])
	 */
	public byte[] recv(String[] channelNames) throws API_Exception {
		return recv(channelNames, new BlockableImpl());
	}

	/**
	 * Receives a message over a single channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            an OutputStream that must be used to return data
	 * @param blk
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String, OutputStream, Blockable)
	 */
	public int recv(String channelName, OutputStream data, Blockable blk) throws API_Exception {
		String[] names = { channelName };
		return recv(names, data, blk);
	}

	/**
	 * Receives a message over a single channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            an OutputStream that must be used to return data
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String, OutputStream)
	 */
	public int recv(String channelName, OutputStream data) throws API_Exception {
		return recv(channelName, data, new BlockableImpl());
	}

	/**
	 * Receives a message over a set of channels. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelNames -
	 *            the names of the subject channels
	 * @param data -
	 *            an OutputStream that must be used to return data
	 * @param blk -
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String[], OutputStream, Blockable)
	 */
	public int recv(String[] channelNames, OutputStream data, Blockable blk) throws API_Exception {
		byte[] buf = recv(channelNames, blk);
		try {
			data.write(buf);
		} catch (IOException ioe) {
			throw new API_Exception("Error occured writing to an OutputStream");
		}
		return buf.length;
	}

	/**
	 * Receives a message over a set of channels. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelNames -
	 *            the names of the subject channels
	 * @param data -
	 *            an OutputStream that must be used to return data
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String[], OutputStream)
	 */
	public int recv(String[] channelNames, OutputStream data) throws API_Exception {
		return recv(channelNames, data, new BlockableImpl());
	}

	/**
	 * Receives a message over a single channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            a Writer that must be used to return data
	 * @param blk
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String, Writer, Blockable)
	 */
	public int recv(String channelName, Writer data, Blockable blk) throws API_Exception {
		String[] names = { channelName };
		return recv(names, data, blk);
	}

	/**
	 * Receives a message over a single channel. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelName
	 *            the name of the subject channel
	 * @param data
	 *            a Writer that must be used to return data
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String, Writer)
	 */
	public int recv(String channelName, Writer data) throws API_Exception {
		return recv(channelName, data, new BlockableImpl());
	}

	/**
	 * Receives a message over a set of channels. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelNames -
	 *            the name of the subject channel
	 * @param data
	 *            an OutputStream that must be used to return data
	 * @param blk
	 *            a blockable object used to stop/resume the caller
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String[], Writer, Blockable)
	 */
	public int recv(String[] channelNames, Writer data, Blockable blk) throws API_Exception {
		byte[] buf = recv(channelNames, blk);
		char[] cbuf = new char[buf.length];
		for (int i = 0; i < buf.length; i++) {
			cbuf[i] = (char) buf[i];
		}
		try {
			data.write(cbuf);
		} catch (IOException ioe) {
			throw new API_Exception("Error occured writing to a Writer");
		}
		return cbuf.length;
	}

	/**
	 * Receives a message over a set of channels. Implementation of the
	 * BolognaPiAPI interface method.
	 * 
	 * @param channelNames -
	 *            the name of the subject channel
	 * @param data -
	 *            an OutputStream that must be used to return data
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#recv(String[], Writer)
	 */
	public int recv(String[] channelNames, Writer data) throws API_Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * Creates a linear forwarder from srcChannel to dstChannel. Implementation
	 * of the BolognaPiAPI interface method. Both the two channel involved can
	 * be either local or remote.
	 * 
	 * @param srcChannel
	 *            the name of the channel whose output message must be
	 *            redirected
	 * @param dstChannel
	 *            the name of the channel where the redirected message must be
	 *            sent
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#fwd(String, String)
	 */
	public void fwd(String srcChannel, String dstChannel) throws API_Exception {
		// Note: I don't check if srcChannel is local because linear forwarders
		// should be used with remote channels. If srcChannel is local a new
		// connection to the local channel manager is created
		MsgToCM msg1 = MsgToCM.createRCV("RMT", srcChannel);
		msg1.setContinuation(dstChannel);
		try {
			Socket sock = channelConnect(srcChannel);
			int res = msg1.putMessage(sock.getOutputStream());
			handlePutMessageRetVal(res);
		} catch (UnknownHostException uhe) {
			throw new CMNotFoundException(
					"Unknown Host " + getChannelIp(srcChannel) + ":" + getChannelPort(srcChannel), uhe);
		} catch (IOException ioe) {
			throw new NetworkException("NetworkError on connection to " + getChannelIp(srcChannel) + ":"
					+ getChannelPort(srcChannel), ioe);
		}
	}

	/**
	 * Creates a new local channel. The name of the channel is generated by the
	 * local channel manager. Implementation of the BolognaPiAPI interface
	 * method.
	 * 
	 * @return the name of the new channel created
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @see BolognaPiAPI#newChannel()
	 */
	public String newChannel() throws API_Exception {
		BlockableImpl blk = new BlockableImpl();
		synchronized (blk) {
			sharedListener.sendLocal(MsgToCM.createNEW("LCL"), blk);
			blk.block();
		}
		return blk.getStringData();
	}

	/**
	 * Creates a new channel at the location identified by the IP address and
	 * the TCP port number passed as arguments. The name of the channel is
	 * generated by the channel manager. Implementation of the BolognaPiAPI
	 * interface method.
	 * 
	 * @return the name of the new channel created
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @see BolognaPiAPI#newChannel(String, int)
	 */
	public String newChannel(String ip, int port) throws API_Exception {
		if (CMPort_intVal == port && CMConnectionAddr.equals(ip))
			return newChannel();
		else {
			// create a new local ch annel ...
			String ackChan = newChannel();
			// ... send a message to the remote channel manager ...
			MsgToCM msg1 = MsgToCM.createNEW("RMT");
			msg1.setContinuation(ackChan);
			try {
				Socket sock = new Socket(ip, port);
				int res = msg1.putMessage(sock.getOutputStream());
				handlePutMessageRetVal(res);
			} catch (UnknownHostException uhe) {
				throw new CMNotFoundException("Unknown Host " + ip + ":" + port, uhe);
			} catch (IOException ioe) {
				throw new NetworkException("NetworkError on connection to " + ip + ":" + port, ioe);
			}
			// ... receive a message on the local channel ...
			MsgToCM msg2 = MsgToCM.createRCV("LCL", ackChan);
			BlockableImpl blk = new BlockableImpl();
			synchronized (blk) {
				sharedListener.sendLocal(msg2, blk);
				blk.block();
			}
			// ... delete the local channel (garbage collection)
			sharedListener.asendLocal(MsgToCM.createDEL(ackChan));
			return blk.getStringData();
		}
	}

	/**
	 * Creates a new channel at the location where the channel passed as
	 * argument resides (they will be colocated). The name of the channel is
	 * generated by the channel manager. Implementation of the BolognaPiAPI
	 * interface method.
	 * 
	 * @param colocatedChannel -
	 *            the name of a channel colocated with the new one
	 * @return the name of the new channel created
	 * @throws API_Exception
	 *             if something is not initialized properly
	 * @throws NetworkException
	 *             if an error occurs writing on a socket
	 * @throws CMNotFoundException
	 *             if a channel manager is not found
	 * @throws ChannelNotFoundException
	 *             if colocatedChannel dosn't exists
	 * @see BolognaPiAPI#newChannel(String, int)
	 */
	public String newChannel(String colocatedChannel) throws API_Exception {
		// TODO: CHECK IF COLOCATEDCHANNEL EXISTS
		if (isLocal(colocatedChannel))
			return newChannel();
		return newChannel(getChannelIp(colocatedChannel), getChannelPort(colocatedChannel));
	}

	/**
	 * Checks if a channel is local. Implementation of the BolognaPiAPI
	 * interface method. Checks if a channel is local (channelName =
	 * IPADDR:PORT#SEQNUM) This method dosn't check for the existance of the
	 * channel and it dosn't communicates with the local channel manager. The
	 * test for locality is done only by examining the channel name.
	 * 
	 * @param channelName
	 *            -the name of the channel that must be checked for locality
	 * @return true if the channel is local, false otherwise
	 */
	public boolean isLocal(String channelName) {
		String tmp;
		for (int i = 0; i < CMAddrs.length; i++) {
			tmp = CMAddrs[i] + ':' + CMPort;
			if (tmp.equals(channelName.substring(0, tmp.length())))
				return true;
		}
		return false;
	}

	/**
	 * Removes the channel identified by channelName. After the call,
	 * communications over this channel are no longer possible. The channel to
	 * be removed can be either local or remote.
	 * 
	 * @param channelName
	 *            the name of the channel that will be removed
	 */
	public void deleteChannel(String channelName) throws API_Exception {
		if (isLocal(channelName)) {
			sharedListener.asendLocal(MsgToCM.createDEL(channelName));
		} else {
			MsgToCM msg = MsgToCM.createDEL(channelName);
			msg.setContinuation(""); // paranoid
			try {
				Socket sock = channelConnect(channelName);
				if (msg.putMessage(sock.getOutputStream()) != 0) {
					throw new API_Exception();
				}
			} catch (UnknownHostException uhe) {
				throw new API_Exception();
			} catch (IOException ioe) {
				throw new API_Exception();
			}
		}
	}

	/**
	 * Single implementation of the send api. This method is called by the
	 * implementations of all variants of send and asend.
	 */
	private void send(String channelName, byte[] data, Blockable blk, boolean isSynchronous) throws API_Exception {
		//
		// NOTE: Throws API_Exception and NetworkException (through sendLocal)
		//
		if (isLocal(channelName)) {
			// if local and synchronous: send the message to the channel manager
			// and wait
			if (isSynchronous) {
				synchronized (blk) {
					MsgToCM msg = MsgToCM.createSND("LCL", channelName, data);
					sharedListener.sendLocal(msg, blk);
					blk.block();
				}
			} else {
				sharedListener.asendLocal(MsgToCM.createSND("LCL", channelName, data));
			}
		} else { // if remote: define the continuation...
			String ackChan = "-1"; // initialized for an asynchronous message
			if (isSynchronous) {
				ackChan = newChannel();
			}
			// ... send the message to the remote channel manager...
			MsgToCM msg1 = MsgToCM.createSND("RMT", channelName, data);
			msg1.setContinuation(ackChan); // ack channel = the new local
											// channel
			try {
				Socket sock = channelConnect(channelName);
				int res = msg1.putMessage(sock.getOutputStream());
				handlePutMessageRetVal(res);
			} catch (UnknownHostException uhe) {
				throw new CMNotFoundException("Unknown Host " + getChannelIp(channelName) + ":"
						+ getChannelPort(channelName), uhe);
			} catch (IOException ioe) {
				throw new NetworkException("NetworkError on connection to " + getChannelIp(channelName) + ":"
						+ getChannelPort(channelName), ioe);
			}
			if (isSynchronous) {
				// ... receive the ack on the local channel ...
				MsgToCM msg2 = MsgToCM.createRCV("LCL", ackChan);
				synchronized (blk) {
					sharedListener.sendLocal(msg2, blk);
					blk.block();
				}
				// ... delete the local channel (garbage collection)
				sharedListener.asendLocal(MsgToCM.createDEL(ackChan));
			}
		}
	}

	/**
	 * Given the name of a channel it returns the IP address where it should
	 * reside (extracted by the name itself)
	 * 
	 * @param channelName
	 *            the name of a channel
	 * @return the IP address where the channel resides
	 */
	private String getChannelIp(String channelName) {
		int sep = channelName.indexOf(':');
		return channelName.substring(0, sep - 1);
	}

	/**
	 * Given the name of a channel it returns the TCP port number extracted by
	 * the name itself
	 * 
	 * @param channelName
	 *            the name of a channel
	 * @return the TCP port number
	 */
	private int getChannelPort(String channelName) {
		int sep1 = channelName.indexOf(':');
		int sep2 = channelName.indexOf('#');
		int port = Integer.parseInt(// TCP port from the name of
				channelName.substring(sep1 + 1, sep2 - 1)); // the destination
															// channel
		return port;
	}

	/**
	 * Creates a connected socket to the channel manager that handle the channel
	 * passed as parameter
	 */
	private Socket channelConnect(String channelName) throws UnknownHostException, IOException {
		int sep1 = channelName.indexOf(':');
		int sep2 = channelName.indexOf('#');
		String addr = channelName.substring(0, sep1); // get the IP address
														// and the
		int port = Integer.parseInt(// TCP port from the name of
				channelName.substring(sep1 + 1, sep2)); // the destination
														// channel
		return new Socket(addr, port);
	}

	/**
	 * Looks at the return value of a previous call to putMessage and throws an
	 * exception
	 */
	private void handlePutMessageRetVal(int res) throws API_Exception {
		// if a network error occurs in putMessage()
		if (res == -1) {
			throw new NetworkException("Error writing to the remote CM socket");
		}
		// if an initialization error occurs (invalid message)
		if (res == -2) {
			throw new API_Exception("Trying to send an invalid message");
		}
		// if a strange value is returned
		else if (res != 0) {
			throw new API_Exception("[api debug] unhandled return value (msg1.putMessage())");
		}
	}
}
