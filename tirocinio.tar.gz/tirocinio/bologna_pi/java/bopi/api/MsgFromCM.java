package bopi.api;

import java.io.InputStream;
import java.io.IOException;


/*
 * This class represents messages received from the local channel manager.
 * Messages have the format: <CHAN \n IDX \n LENGTH \n DATA>
 * where: 
 *   - STATUS 0 = OK , 1 = NOT FOUND
 *   - CHAN   is a string representing the name of a channel;
 *   - IDX    is a string representing an index of the vector used to store the 
 *            waiting threads in the ListenerThread class;
 *   - LENGTH is a string representing the number of bytes of the following 
 *            data field;
 *   - DATA   is the data and its size is LENGTH (in bytes)
 */
public class MsgFromCM {

	public String chan;
    public int wtIdx;
    public int status;
    public byte[] data;
    

    // default (private) constructor
    // called only by getMessage()
    private MsgFromCM(String recvChan, int recvIdx, byte[] recvData) {
    	chan = recvChan;
        wtIdx = recvIdx;
        data = recvData;
    }

    // reads a message from the channel manager
    // message format: <STATUS \r\n CHAN \r\n IDX \r\n LENGTH \r\n DATA>
    // returns null if an error occurs
    public static MsgFromCM getMessage(InputStream is) {
        StringBuffer sb = new StringBuffer();
        char c; int r;
        
        try {
            
            // read the STATUS
			while(true) {
				if ((r = is.read()) == -1) return null;            	
				c = (char) r;
				if (c=='\r') {
					if ((r = is.read()) == -1) return null;
					c = (char) r;
					if (c=='\n') break;
					sb.append('\r');
				}
				sb.append(c);
			}
			//status can be either OK = 0 or NOTFOUND = 1
			int status = Integer.parseInt(sb.toString());            
            if (status != 0) return null;               
            // read the CHAN
			sb.delete(0,sb.capacity());            
            while(true){
				if ((r = is.read()) == -1) return null;            	
                c = (char) r;				                
				if (c=='\r') {
					if ((r = is.read()) == -1) return null;
					c = (char) r;
					if (c=='\n') break;
					sb.append('\r'); 
				}
				sb.append(c);
            }
            String recvChan = sb.toString();
            
            // read the IDX (index used to unblock a thread)
            sb.delete(0,sb.capacity());            
            while(true) {
				if ((r = is.read()) == -1) return null;            	
				c = (char) r;
				if (c=='\r') {
					if ((r = is.read()) == -1) return null;
					c = (char) r;
					if (c=='\n') break;
					sb.append('\r');
				}
				sb.append(c);
            }
            int recvIdx = Integer.parseInt(sb.toString());            
			            
            // read the LENGTH
            sb.delete(0,sb.capacity());
            while(true){
				if ((r = is.read()) == -1) return null;            	
				c = (char) r;
				if (c=='\r') {
					if ((r = is.read()) == -1) return null;
					c = (char) r;
					if (c=='\n') break;
					sb.append('\r');
				}
				sb.append(c);
            }
            int length = Integer.parseInt(sb.toString());
            
            // read the DATA
            byte[] recvData = new byte[length];
            int tmp;
            for (int i=0; i<length; i++) {
                tmp = is.read();
                if (tmp!=-1)
                    recvData[i] = (byte) tmp;
                else 
                    { return null; }
            }
        
            // return a new MsgFromCM object representing the message received
            return new MsgFromCM(recvChan,recvIdx,recvData);
        }   
        catch (IOException ioe) {
        	// IOException is thrown when someone closes the socket (safe) 
        	// or something bad happens
            return null;
        }
    }
}
