package bopi.api;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Hashtable;

public class ListenerThread extends Thread {
    
    // IP address and TCP port used to connect to the channel manager
    private InetAddress CMAddr = null;
    private int CMPort;
    
    // IP addersses used in local channel names
    private String[] CMNameAddrs = null;
    
    // Socket connected to the local channel manager and 
    // its input/output streams (buffered)
    private Socket CMSock = null;
    private BufferedInputStream is = null;
    private BufferedOutputStream os = null;
    
    // Flag used to terminate execution and to check if the thread
    // is running
    private boolean stop = true;
    
    // HashTable of waiting threads
    private Hashtable<Integer, Blockable> wt = new Hashtable<Integer, Blockable>();
    private int currentIdx = 0;
    
    // Default constructor: starts the connection to the local channel manager
    public ListenerThread(InetAddress CMAddr, int CMPort) {
        this.CMAddr = CMAddr;
        this.CMPort = CMPort;
    }

	// returns the local ip adresses used for channel names
	public String[] getLocalAddresses() {
		return CMNameAddrs;
	}
    
    // Initializes thread execution
    // Returns the set of local IP adresses used for channel names
    // of null if an error occurs
    public String[] connectAndRun() {

        try {

        // start the connection to the local channel manager
        CMSock = new Socket(CMAddr,CMPort);
        is = new BufferedInputStream(CMSock.getInputStream());
        os = new BufferedOutputStream(CMSock.getOutputStream());
        
        // send HELO 
        byte[] helo = {'H','E','L','O','\r','\n'};
        os.write(helo); os.flush();
        
        }
        catch(IOException ioe) {
            stop = true;
            System.out.println("ERROR: sending helo");
            return null;   
        }
        
        // wait for HELO reply with IP adresses
        StringBuffer sb = new StringBuffer();
        int r;
        try {
            for (int i=0; i<4; i++) {
            	if ((r = is.read()) == -1) return null;
                sb.append((char) r); // "HELO"
            }
            if (!sb.toString().equals("HELO")) {
                CMNameAddrs = null;
                stop = true;
                return null;
            }
            
            // \r\n
			char c;
            c = (char) is.read();
			if (c=='\r') {
				if ((r = is.read()) == -1) return null;
				c = (char) r;
				if (c!='\n') {
					CMNameAddrs = null;
					stop = true;
					return null;
				}
			}
			else {
                CMNameAddrs = null;
                stop = true;
                return null;
            }

            sb = new StringBuffer();
            while (true) {
				if ((r = is.read()) == -1) return null;
                c = (char) r;
				if (c=='\r') {
					if ((r = is.read()) == -1) return null;					
					c = (char) r;
					if (c=='\n') break;
					sb.append('\r'); 
				}
                sb.append(c);           
            }
            int num = Integer.parseInt(sb.toString());
            CMNameAddrs = new String[num];
            
            for (int i=0; i<num; i++) {
                sb = new StringBuffer();
                while (true) {
					if ((r = is.read()) == -1) return null;
                    c = (char) r;
                    if (c=='\r') {
						if ((r = is.read()) == -1) return null;                    	
                    	c = (char) r;
                    	if (c=='\n') break;
                    	sb.append('\r');
                    }
                    sb.append(c);
                }
                try {
                    InetAddress.getByName(sb.toString());
                    CMNameAddrs[i] = sb.toString();
                }
                catch(UnknownHostException uhe) {
                    stop = true;
                    return null;
                }
            }            
        }
        catch (Exception e) {
            stop = true;
			return null;
        }

        return CMNameAddrs;
    }
    
    
	//	Starts the thread and waits for messages
    public void run() {

        // initialize the termination flag
        stop = false;
        
        // read messages from the channel manager
        // message format: <CHAN \r\n + IDX \r\n + LENGTH \r\n + DATA>  
        // (where IDX is an index of wt)
        MsgFromCM msg;
        while (!stop) {
            
            // waits for messages
            msg = MsgFromCM.getMessage(is);
            
            if (msg!=null) {
            
	            // select the blocked thread, return the data and unblock
	            // otherwise the data is lost
	                Blockable unblocked;
	                synchronized(this) {
	                    unblocked = wt.get(msg.wtIdx);
	                }
	                
	                // set values and unblock the waiting thread
	                synchronized (unblocked) { 
						unblocked.setData(msg.data);
						unblocked.setSubject(msg.chan);
						unblocked.setStatus(msg.status);
	                    unblocked.unblock(); 
	                }
            }
            else if (!stop) {
            	System.err.println("Error occured reading from the local channel manager");
            	System.exit(1);
            }
        }
    }

    // Checks if the thread is running
    public boolean isRunning() {
        return !stop;
    }

    // Terminates the execution
    public void terminate() throws IOException {
        stop = true;
        if (CMSock!=null)
            CMSock.close(); // unblocks the call to getMessage() in run()
    }

    
    // Sends a message to the local channel manager (automatically adds
    // the continuation to the message!!)
    // If 'blocked' is null the message is sent asynchronously
    // throws NetworkException or API_Exception
    public synchronized void sendLocal(MsgToCM msg, Blockable blocked) 
    	throws API_Exception {

        if (blocked==null) {
        	asendLocal(msg);
        	// TODO: WRITE A WARNING
        }
        else {
            // insert 'blocked' into the hashtable of waiting thread
            Integer key=null;
            while (wt.containsKey(key = new Integer(currentIdx))) {
            	if (currentIdx!=Integer.MAX_VALUE)
            		currentIdx++;
            	else
            		currentIdx=0;
            }
            wt.put(key,blocked);

            // set the continuation field of the message to the index of wt
            msg.setContinuation(new Integer(key).toString());

			// write the message to the output stream
			int res = msg.putMessage(os);
			
			// if a network error occurs in putMessage() 
			if (res==-1) {
				throw new NetworkException("Error writing to the local CM socket");
			}
			// if an initialization error occurs (invalid message)
			if (res==-2) {
				throw new API_Exception("Trying to send an invalid message");
			}
			// if a strange value is returned
			else if (res!=0) {
				throw new API_Exception("[api debug] unhandled return value (msg1.putMessage())");
			}

        }
    }
    
	// Sends (asynchronously) a message to the local channel manager (automatically
	// adds the continuation to the message!!)
	// throws NetworkException or API_Exception
	public synchronized void asendLocal(MsgToCM msg) throws API_Exception {
		msg.setContinuation("-1");
		int res = msg.putMessage(os);
		// if a network error occurs in putMessage() 
		if (res==-1) {
			throw new NetworkException("Error writing to the local CM socket");
		}
		// if an initialization error occurs (invalid message)
		if (res==-2) {
			throw new API_Exception("Trying to send an invalid message");
		}
		// if a strange value is returned
		else if (res!=0) {
			throw new API_Exception("[api debug] unhandled return value (msg1.putMessage())");
		}

	}    
	
	// Sends a message to the local channel manager without adding any continuation
	// (this can be used to send RMT messages to the local channel manager as it
	// was remote -- for instance for reverse forwarders in choiche encoding)
	// ATT: the message must have a continuation!=null or it is invalid
	// throws NetworkException or API_Exception
	public synchronized void sendLocalAsRemote(MsgToCM msg) throws API_Exception {
		int res = msg.putMessage(os);
		// if a network error occurs in putMessage() 
		if (res==-1) {
			throw new NetworkException("Error writing to the local CM socket");
		}
		// if an initialization error occurs (invalid message)
		if (res==-2) {
			throw new API_Exception("Trying to send an invalid message");
		}
		// if a strange value is returned
		else if (res!=0) {
			throw new API_Exception("[api debug] unhandled return value (msg1.putMessage())");
		}

	}
}
