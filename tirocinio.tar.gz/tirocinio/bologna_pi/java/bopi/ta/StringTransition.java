/*
 * StringTransition.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Oct 18, 2004
 */
package bopi.ta;
/**
 * Transition that matches string literals 
 * @author Samuele Carpineti
 */
class StringTransition extends MatchingTransition {
	/**
	 * Creates a new string transition.
	 * @param labels - a valid string label set
	 * @param src - the source state
	 * @param dst - the destination state
	 * @param variables - the set of variables to bind in the matching
	 * @throws RuntimeException if the the LabelSet does not match strings
	 */
	StringTransition(LabelSet labels, TAState src, TAState dst, int[] variables) {
		super(labels, src, dst, null, variables);
		if (!labels.MATCH_STRING)
			throw new RuntimeException("A string must be matched by this set of label");
	}
	/**
	 * Creates a new string transition that can match the particular string 
	 * literal (it can be SpecialLabels.ANY_STRING_PATTERN in this case the 
	 * transition matches every string literal).
	 * @param label - the string literal to match
	 * @param src - the source state
	 * @param dst - the destination state
	 * @param variables - the set of variables to bind in the matching
	 */
	StringTransition(String label, TAState src, TAState dst, int[] variables) {
		super(new LabelSet(MatchedType.MATCH_STRINGS), src, dst, null, variables);
        //Check if the number is an "integer label" or not. It is an integer label if it's the ANY_STRING label or if it is 
        //prefixed by the integer prefix: STRING_LITERAL  
		if (SpecialLabels.IS_ANY_STRING_PATTERN(label) || SpecialLabels.IS_STRING_LITERAL(label))
			labels.addLabel(label);
		else {
			labels.addLabel(SpecialLabels.STRING_LITERAL + label);
		}
	}
	/**
	 * Creates a new integer transition that can match every string literal
	 * @param src - the source state
	 * @param dst - the destination state
	 * @param variables - the set of variables to bind in the matching
	 */
	StringTransition(TAState src, TAState dst, int[] variables) {
		super(SpecialLabels.ANY_STRING_PATTERN, src, dst, null, variables);
	}
	/**
	 * Returns true if the transition match any string
	 * @return true if the transition match any string
	 */
	boolean matchAnyString() {
		return labels.matchAnyString();
	}
	public MatchingTransition duplicate(TAState src, TAState dst) {
		int[] vars= new int[variables.length];
		for (int j= 0; j < variables.length; j++) {
			vars[j]= variables[j];
		}
		return (new StringTransition((LabelSet) labels.clone(), src, dst, vars));
	}
    TreeAutomaton[] getContents() {
        return new TreeAutomaton[0];
    }
}
