/*
 * LabelledTransition.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 27, 2004
 */
package bopi.ta;

import bopi.values.*;

/**
 * Labelled transitions in a top-down automata have the following form:
 * q---X:L[TA]---->q'. Values instead are for example v1,a[v2],v3 then TA is the
 * sub-automata that recognizes the sub-tree v2. L is {l_1, ..., l_n}\{l_1',
 * ..., l_n'} (labels\diffLabels) X is a set of variables. This class is used as
 * superclass for all the transitions.
 * 
 * @author Samuele Carpineti
 */
abstract class AbstractLabelledTransition extends Transition {
    boolean visited;

    protected final static EpsilonTA epsTa = new EpsilonTA();

    /** Content automaton. It can be null for an empty content model */
    protected TreeAutomaton content;

    /** Transition variables used as accumulator */
    int[] variables;

    /** Transition's label set */
    LabelSet labels;

    /**
     * Initializes a (labelled) tree-transition from a state to another.
     * 
     * @param labels -
     *            the set of labels of the transition
     * @param src -
     *            the source state
     * @param dst -
     *            the destination state
     * @param content -
     *            the automaton that recognize the content
     * @param variables -
     *            the set of variables to bind in the matching
     */
    AbstractLabelledTransition(LabelSet labels, TAState src, TAState dst, TreeAutomaton content, int[] variables) {
        super(src, dst);
        this.labels = labels;
        this.content = content;
        this.variables = variables;
        if (labels.getMatchedType() != MatchedType.MATCH_LABELS && this instanceof LabelledTransition){ 
            throw new RuntimeException("Error Creating a Transition");
        }
    }

    /**
     * Initializes a (labelled) tree-transition from a state to another leaving
     * unspecified the set of labels. Subclasses must set the set of labels in
     * their constructor (or before using other methods)
     * 
     * @param src -
     *            the source state
     * @param dst -
     *            the destination state
     * @param content -
     *            the automaton that recognize the content
     * @param variables -
     *            the set of variables to bind in the matching
     */
    protected AbstractLabelledTransition(TAState src, TAState dst, TreeAutomaton content, int[] variables) {
        super(src, dst);
        this.content = content;
        this.variables = variables;
    }

    /**
     * Initializes a (labelled) tree-transition from a state to another. Content
     * will be empty.
     * 
     * @param label -
     *            the label of this transition
     * @param src -
     *            the source state
     * @param dst -
     *            the destination state
     */
    AbstractLabelledTransition(String label, TAState src, TAState dst) {
        this(new LabelSet(label), src, dst, epsTa, new int[0]);
    }

    /**
     * Initializes a (labelled) tree-transition from a state to another.
     * 
     * @param label -
     *            the label of this transition
     * @param src -
     *            the source state
     * @param dst -
     *            the destination state
     * @param content -
     *            the automaton that recognize the content
     * @param variables -
     *            transition's bindings
     */
    AbstractLabelledTransition(String label, TAState src, TAState dst, TreeAutomaton content, int[] variables) {
        this(new LabelSet(label), src, dst, content, variables);
    }

    /**
     * Initializes a (labelled) tree-transition from a state to another.
     * 
     * @param labels -
     *            the set of labels of the transition
     * @param src -
     *            the source state
     * @param dst -
     *            the destination state
     * @param content -
     *            the automaton that recognize the content
     */
    AbstractLabelledTransition(LabelSet labels, TAState src, TAState dst, TreeAutomaton content) {
        this(labels, src, dst, content, new int[0]);
    }

    /**
     * Returns true if the element is matched by this transition, false
     * otherwise
     * 
     * @return true if the element is matched by this transition, false
     *         otherwise
     */
    boolean match(LabelledElement element) {
        return matchLabel(element.tagName);
    }

    /**
     * Returns true if the set of labels matched by this transition is empty,
     * false otherwise
     * 
     * @return true if the set of labels matched by this transition is empty,
     *         false otherwise
     */
    boolean hasEmptyLabel() {
        return labels.matchNoValue();
    }

    /**
     * Returns true if the label is matched by the transition
     * 
     * @return true if the label is matched by the transition
     */
    boolean matchLabel(String label) {
        return (labels.matchLabel(label));
    }

    /**
     * Sets the automaton for the content
     * 
     * @param content -
     *            the automaton that recognize the content
     */
    void setContent(TreeAutomaton content) {
        this.content = content;
    }

    /**
     * Creates a copy of this transition with a new source state and a new
     * destination state. Bindings, labels and diffLabels are cloned, content is
     * copied (it's not cloned).
     * 
     * @param src -
     *            the new source state
     * @param dst -
     *            the new destination state
     * @return a new transition
     */
    abstract Transition duplicate(TAState src, TAState dst);

    /**
     * @return true if this transition matches every integer, false otherwise
     */
    boolean matchAny() {
        return labels.matchAny();
    }

    /**
     * Returns true if this transition binds a given variable
     * 
     * @param variable -
     *            the binder
     * @return true if this transition binds a given variable, false otherwise
     */
    public boolean binds(int variable) {
        for (int i = 0; i < variables.length; i++)
            if (variables[i] == variable) return true;
        return false;
    }

    /**
     * Returns a string representation of this transition
     * 
     * @return the string that represents the transition q--{x,y
     *         ...}:{l1,...,ln}\{l1', ..., ln'}[A]--&gt q'
     * @see java.lang.Object#toString()
     */
    public String toString() {
        String s = new String();
        s += src.toString();
        if (variables.length>0) 
            s += "-{";
        for (int i = 0; i < variables.length; i++) {
            s += variables[i];
            if (i < variables.length - 1) s += " ";
        }
        if (variables.length>0) s += "}:";
        s +="{" + labels.toString() + "}";
        if (content != null) s += "[Q" + content.getID() + "]";
        s += "->" + dst.toString();
        return s;
    }

    /**
     * Compares this transition with an onbject. If the object is a
     * LabelledTransition then for testing equality source, destination,
     * variables and content are compared. For ``content is tested only equality
     * between pointers.
     * 
     * @param o -
     *            the reference object with which to compare
     * @return true if this object is the same as the obj argument, false
     *         otherwise.
     */
    public boolean equals(Object o) {
        return ((o instanceof LabelledTransition) && (((LabelledTransition) o).dst == dst)
                && (((LabelledTransition) o).src == src) && (((LabelledTransition) o).content.equals(content))
                && (((LabelledTransition) o).variables.equals(variables)) && (((LabelledTransition) o).labels
                .equals(labels)));
    }
}