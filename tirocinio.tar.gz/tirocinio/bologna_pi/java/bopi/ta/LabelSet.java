/*
 * LabelSet.java project: BolognaPi @author Samuele Carpineti Created on Mar 1,
 * 2004
 */
package bopi.ta;

import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;
import java.util.Collection;




class MatchedType {
    boolean MATCH_INT = false;

    boolean MATCH_STRING = false;

    boolean MATCH_CHANNEL = false;

    boolean MATCH_LABEL = false;

    final static int MATCH_CHANNELS = 1;

    final static int MATCH_STRINGS = 2;

    final static int MATCH_INTEGERS = 3;

    final static int MATCH_LABELS = 4;

    protected int getMatchedType() {
        if (MATCH_CHANNEL) return 1;
        if (MATCH_STRING) return 2;
        if (MATCH_INT) return 3;
        if (MATCH_LABEL) return 4;
        return -1;
    }

    protected void setMatchedType(int matchedType) {
        if (matchedType == MATCH_CHANNELS) MATCH_CHANNEL = true;
        else if (matchedType == MATCH_STRINGS) MATCH_STRING = true;
        else if (matchedType == MATCH_INTEGERS) MATCH_INT = true;
        else if (matchedType == MATCH_LABELS) MATCH_LABEL = true;
        else throw new RuntimeException("MatchedType must be in [1;4]");
    }
}
/**
 * A set of labels that implements basic matching operations. Each LabelSet can
 * match only one of these types. So, for instance, in each LabelSet cannot
 * exists both integer labels and string labels.
 * 
 * @author Samuele Carpineti
 */

class LabelSet extends MatchedType {
    /**
     * The set of label of this label set; if the LabelSet matches any value
     * labels is used to store value that must not be matched. For instance a
     * pattern like ~Int / 5 is represented as a labelSet with: MATCH_INT =
     * true; labels = {5} A particular case is represented by channels. They are
     * like normal labels but the procedure works as follows. Labels for
     * channels have the form ~Chan+TypeName. When these kind of labels are
     * added to the set MATCH_ANY is set to true (the label match any channel
     * with the specified type) and a label #Chan+TypeName is added to the set
     * ``labels. The <it>matchLabel </it> method when receive a channel litaral
     * (#Chan+TypeName+#+nameofthechannel) returns true if the first part:
     * #Chan+TypeName is contained this set of labels ``labels. So in the case
     * of channels MATCH_ANY is always true and ``labels do not represent the
     * difference set. This don't give any problem because it's not possible to
     * specify literals for channels.
     */
    private Set<String> labels = new HashSet<String>();

    /**
     * True if the label set match any value except the value stored in labels.
     */
    private boolean MATCH_ANY = false;

    /**
     * Builds an empty label set
     */
    LabelSet(int matchedType) {
        setMatchedType(matchedType);
    }

    /**
     * Builds a label set with an initial label
     * 
     * @param label
     *            a label to add in the label set
     */
    public LabelSet(String label) {
        addLabel(label);
    }

    /**
     * Builds a label set with an initial label set
     * 
     * @param labelSet
     *            the label set to add
     */
    public LabelSet(Collection<String> labelSet) {
        addLabels(labelSet);
    }

    /**
     * Builds a label set with an initial label set
     * 
     * @param labelSet
     *            the label set to add
     */
    public LabelSet(LabelSet labelSet) {
        MATCH_ANY = labelSet.MATCH_ANY;
        setMatchedType(labelSet.getMatchedType());
        addLabels(labelSet.labels);
    }

    /**
     * Returns true if this LabelSet is empty
     * 
     * @return true if the LabelSet is empty, false otherwise
     */
    public boolean isEmpty() {
        return labels.isEmpty();
    }

    /**
     * Returns true if labels in this transition cannot match any value
     * 
     * @return true if labels in this transition cannot match any value, false
     *         otherwise
     */
    public boolean matchNoValue() {
        return (labels.isEmpty() && !MATCH_ANY);
    }

    /**
     * Returns an iterator on this set
     * 
     * @return an iterator on this set
     */
    public Iterator<String> iterator() {
        return labels.iterator();
    }

    /**
     * Adds the label set to the this set of label. If the collection contains a
     * wildcard label the LabelSet will recognize any labels except the labels
     * following the wildcard. ([a,b,~,c,d] becomes a label set ~\c,d.)
     * 
     * @param labelSet
     *            the set of labels to add
     */
    public void addLabels(Collection<String> labelSet) {
        Iterator<String> j = labelSet.iterator();
        while (j.hasNext()) {
            String l = j.next();
            addLabel(l);
        }
    }

    /**
     * Adds the label to this set of labels. If the label set matches any label
     * then the label is added and becomes part of the diffLabels
     * 
     * @param label -
     *            the label to add. It can be a label, an integer literal, a
     *            string literal but not a channel literal
     */
    public void addLabel(String label) {
        if (SpecialLabels.IS_ANY_PATTERN(label) && !MATCH_ANY) {
            labels.clear();
            MATCH_ANY = true;
            MATCH_LABEL = label.equalsIgnoreCase(SpecialLabels.ANY_LABEL_PATTERN);
            MATCH_INT = label.equalsIgnoreCase(SpecialLabels.ANY_INTEGER_PATTERN);
            MATCH_STRING = label.equalsIgnoreCase(SpecialLabels.ANY_STRING_PATTERN);
            MATCH_CHANNEL = label.startsWith(SpecialLabels.ANY_CHANNEL_PATTERN);
            if (MATCH_CHANNEL) {
                label = label.replaceFirst(SpecialLabels.ANY_CHANNEL_PATTERN, SpecialLabels.CHANNEL_LITERAL);
                labels.add(label);
            }
        } else if (SpecialLabels.IS_ANY_PATTERN(label) && MATCH_ANY) {
            MATCH_ANY = false;
            labels.clear();
        } else {
            if (SpecialLabels.IS_CHANNEL_LITERAL(label)) MATCH_CHANNEL = true;
            else if (SpecialLabels.IS_INTEGER_LITERAL(label)) {
                if (MATCH_STRING || MATCH_LABEL) throw new RuntimeException("Mixed labelSet is used");
                MATCH_INT = true;
            } else if (SpecialLabels.IS_STRING_LITERAL(label)) {
                if (MATCH_INT || MATCH_LABEL) throw new RuntimeException("Mixed labelSet is used");
                MATCH_STRING = true;
            } else {
                if (MATCH_INT || MATCH_STRING) throw new RuntimeException("Mixed labelSet is used");
                MATCH_LABEL = true;
            }
            labels.add(label);
        }
    }

    /**
     * Removes a label from the set of labels
     * 
     * @param label -
     *            the label to remove
     */
    public boolean remove(String label) {
        if (SpecialLabels.IS_ANY_PATTERN(label)) {
            MATCH_ANY = false;
            return true;
        }
        return labels.remove(label);
    }

    /**
     * Returns true if the transition match any value
     * 
     * @return true if the transition match any value, false otherwise
     */
    public boolean matchAny() {
        return MATCH_ANY;
    }

    /**
     * Returns true if the label is in this label set
     * 
     * @param label -
     *            label whose presence in this set is to be tested.
     */
    public boolean contains(String label) {
        return labels.contains(label);
    }

    /**
     * Returns true if the set matches channels, false otherwise
     * 
     * @return true if the set matches channels
     */
    public boolean matchChannel() {
        return MATCH_CHANNEL;
    }

    /**
     * Returns true if the set matches integers, false otherwise
     * 
     * @return true if the set matches integers
     */
    public boolean matchInt() {
        return MATCH_INT;
    }

    /**
     * Returns true if the set matches strings, false otherwise
     * 
     * @return true if the set matches strings
     */
    public boolean matchString() {
        return MATCH_STRING;
    }

    /**
     * True if this label set matches one of the label in the passed set
     * 
     * @param labelSet -
     *            the label set in which to look for labels
     * @return true if this label set matches one of the label in the passed set
     *         Complexity: O(|this| x |labelSet|)
     */
    public boolean matchLabel(LabelSet labelSet) {
        Iterator<String> i = labelSet.iterator();
        while (i.hasNext()) {
            if (matchLabel(i.next())) return true;
        }
        return false;
    }

    /**
     * True if this label set matches all the labels in the passed set
     * 
     * @param labelSet -
     *            the label set in which to look for labels
     * @return true if this label set matches all the labels in the passed set
     *         Complexity: O(|this| x |labelSet|)
     */
    public boolean matchAllLabel(LabelSet labelSet) {
        Iterator<String> i = labelSet.iterator();
        while (i.hasNext()) {
            if (!matchLabel(i.next())) return false;
        }
        return true;
    }

    /**
     * Returns true if this label set matches all the labels (~)
     * 
     * @return true if this label set matches all the labels (~)
     */
    public boolean matchAnyLabels() {
        return MATCH_ANY && MATCH_LABEL;
    }

    /**
     * Returns true if the label is matched by this label set, false otherwise.
     * 
     * @return true if the label is matched by this label set, false otherwise.
     */
    public boolean matchLabel(String label) {
        if (SpecialLabels.IS_STRING_LITERAL(label)) {
            if (!MATCH_STRING) return false;
            if (MATCH_ANY) return !labels.contains(label);
            return labels.contains(label);
        } else if (SpecialLabels.IS_INTEGER_LITERAL(label)) {
            if (!MATCH_INT) return false;
            if (MATCH_ANY) return !labels.contains(label);
            return labels.contains(label);
        } else if (SpecialLabels.IS_CHANNEL_LITERAL(label)) {
            if (!MATCH_CHANNEL) return false;
            if (MATCH_ANY) return true;
            return labels.contains(label);
        } else if (MATCH_LABEL) {
            if (MATCH_ANY) return !labels.contains(label);
            return labels.contains(label);
        }
        return false;
    }

    /**
     * Returns true if this label set match any integer not in getLabels(),
     * false otherwise (~/5 = true)
     * 
     * @return true if this label set match any integer not in getLabels()
     */
    public boolean matchAnyInteger() {
        return MATCH_ANY && MATCH_INT;
    }

    /**
     * Returns true if this label set match any string not in getLabels(), false
     * otherwise (~/"hello" = true)
     * 
     * @return true if this label set match any string not in getLabels()
     */
    public boolean matchAnyString() {
        return MATCH_ANY && MATCH_STRING;
    }

    /**
     * Returns the current set of labels. Labels are strings with a strange
     * format becuase they can be prefixed by the type in the case of base types
     * (integers, strings, and channels).
     * 
     * @return the set of labels
     */
    public final Collection getLabels() {
        return this.labels;
    }

    /**
     * Returns true if labelSet\diffLabels = 0
     * 
     * @param labelSet -
     *            the set of labels
     * @param diffLabelSet -
     *            the set of labels to subtract
     * @return true if labelSet\diffLabels = 0
     */
    static boolean diffIsEmpty(LabelSet labelSet, LabelSet diffLabelSet) {
        /* this works also with literals */
        if (diffLabelSet.MATCH_ANY) return true;
        if (labelSet.MATCH_ANY) return false;
        if (diffLabelSet.isEmpty() && !labelSet.isEmpty()) return false;
        Iterator<String> i = labelSet.iterator();
        while (i.hasNext())
            if (!diffLabelSet.matchLabel(i.next())) return false;
        return true;
    }

    public Object clone() {
        LabelSet s = new LabelSet(getMatchedType());
        s.MATCH_ANY = MATCH_ANY;
        s.addLabels(labels);
        return s;
    }

    /**
     * Returns L = l1 - l2
     * 
     * @param l1
     *            the first operand
     * @param l2
     *            the seconf operand
     * @return L = l1 - l2
     */
    static public LabelSet difference(LabelSet l1, LabelSet l2) {
        if (l1.getMatchedType() != l2.getMatchedType()) return (LabelSet) l1.clone();
        else if (l1.MATCH_ANY && !l2.MATCH_ANY) {
            /* ~\{a,b,c,d} \ {d,e,f} = ~\{a,b,c,d,e,f} */
            LabelSet l = (LabelSet) l1.clone();
            l.addLabels(l2.labels);
            return l;
        } else if (!l1.MATCH_ANY && l2.MATCH_ANY) {
            LabelSet ls = new LabelSet(l2.labels);
            ls.setMatchedType(l2.getMatchedType());
            return LabelSet.intersect(l1, ls);
        } else if (l1.MATCH_ANY && l2.MATCH_ANY) {
            /*
             * ~ \ (~\L2) = L2 (~ \L1) \ ~ = 0 (~\L1) \ (~\L2) = L1\L2
             */
            if (l1.labels.isEmpty()) {
                LabelSet ls = new LabelSet(l2.getMatchedType());
                return ls;
            }
            if (l2.labels.isEmpty()) {
                LabelSet ls = new LabelSet(l2.getMatchedType());
                return ls;
            }
            //LabelSet s= new LabelSet(l1.getMatchedType());
            //LabelSet tmp= new LabelSet(l1.getMatchedType());
            //s.MATCH_ANY= true;
            //tmp.MATCH_ANY= false;
            //tmp.addLabels(l1.labels);
            //return (LabelSet.difference(s, LabelSet.union(tmp, l2)));
            LabelSet s = new LabelSet(SetAlgorithms.difference(l1.labels, l2.labels));
            s.setMatchedType(l1.getMatchedType());
            return s;
        } else { //no any pattern
            LabelSet l = new LabelSet(l1.getMatchedType());
            Iterator<String> j = l1.labels.iterator();
            while (j.hasNext()) {
                String label =  j.next();
                if (!l2.matchLabel(label)) l.addLabel(label);
            }
            return l;
        }
    }

    static public LabelSet intersect(LabelSet l1, LabelSet l2) {
        LabelSet intersection = new LabelSet(l1.getMatchedType());
        intersection.setMatchedType(l1.getMatchedType());
        if (l1.getMatchedType() != l2.getMatchedType()) return intersection;
        intersection.MATCH_ANY = l1.MATCH_ANY && l2.MATCH_ANY;
        if (l1.MATCH_ANY && !l2.MATCH_ANY) //  ~\L1 intersect L2 = L2 \ L1
        //l1.labels contains the set of difference labels
        intersection.labels = SetAlgorithms.difference(l2.labels, l1.labels);
        else if (!l1.MATCH_ANY && l2.MATCH_ANY) //  L1 intersect ~/L 2 = L1 \L2
        intersection.labels = SetAlgorithms.difference(l1.labels, l2.labels);
        else if (!l1.MATCH_ANY && !l2.MATCH_ANY) //both match a finite set L1
                                                 // intersect L2 = L1 intersect
                                                 // L2
        intersection.labels = SetAlgorithms.intersect(l1.labels, l2.labels);
        return intersection;
    }

    static public LabelSet union(LabelSet l1, LabelSet l2) {
        if (l1.getMatchedType() != l2.getMatchedType()) { throw new RuntimeException(
                "Union between different types of LabelSet"); }
        LabelSet lSet = new LabelSet(l1.getMatchedType());
        lSet.setMatchedType(l1.getMatchedType());
        if (l1.MATCH_ANY || l2.MATCH_ANY) {
            if (l1.MATCH_INT) lSet.addLabel(SpecialLabels.ANY_INTEGER_PATTERN);
            if (l1.MATCH_LABEL) lSet.addLabel(SpecialLabels.ANY_LABEL_PATTERN);
            if (l1.MATCH_STRING) lSet.addLabel(SpecialLabels.ANY_STRING_PATTERN);
            if (l1.MATCH_ANY && l2.MATCH_ANY) {
                //~\L1 U ~\L2 = ~\(L1 inter L2)
                lSet.labels = SetAlgorithms.intersect(l1.labels, l2.labels);
            } else if (l1.MATCH_ANY && !l2.MATCH_ANY) {
                //~\L1 U L2 = ~\(L1\L 2)
                lSet.labels = SetAlgorithms.difference(l1.labels, l2.labels);
            } else if (!l1.MATCH_ANY && l2.MATCH_ANY) {
                //L1 U ~\L2 = ~\(L2\L1)
                lSet.labels = SetAlgorithms.difference(l2.labels, l1.labels);
            }
        } else {
            lSet.labels.addAll(l1.labels);
            lSet.labels.addAll(l2.labels);
        }
        return lSet;
    }

    public String toString() {
        String s = new String();
        if (MATCH_ANY && MATCH_INT) s += SpecialLabels.ANY_INTEGER_PATTERN;
        if (MATCH_ANY && MATCH_LABEL) s += SpecialLabels.ANY_LABEL_PATTERN;
        if (MATCH_ANY && MATCH_STRING) s += SpecialLabels.ANY_STRING_PATTERN;
        if (MATCH_ANY && !labels.isEmpty()) {
            s += "\\";
            if (labels.size() > 1) s += "(";
            Iterator<String> j = labels.iterator();
            while (j.hasNext()) {
                if (MATCH_STRING) s += "\"";
                s += SpecialLabels.DEL_LITERAL_PREFIX(j.next());
                if (MATCH_STRING) s += "\"";
                if (j.hasNext()) s += ",";
            }
            if (labels.size() > 1) s += ")";
        } else if (!labels.isEmpty()) {
            Iterator<String> j = labels.iterator();
            if (labels.size() > 1) s = "(" + s;
            while (j.hasNext()) {
                if (MATCH_STRING) s += "\"";
                s += SpecialLabels.DEL_LITERAL_PREFIX(j.next());
                if (MATCH_STRING) s += "\"";
                if (j.hasNext()) s += ",";
            }
            if (labels.size() > 1) s += ")";
        }
        return s;
    }

    public boolean equals(Object o) {
        if (o instanceof LabelSet) {
            LabelSet l = (LabelSet) o;
            if (MATCH_ANY != l.MATCH_ANY || l.getMatchedType() != getMatchedType()) { return false; }
            return LabelSet.diffIsEmpty(this, l) && LabelSet.diffIsEmpty(l, this);
        }
        return false;
    }

    static boolean test() {
        if (!LabelSet.diffIsEmpty(new LabelSet(SpecialLabels.ANY_INTEGER_PATTERN), new LabelSet(
                SpecialLabels.ANY_INTEGER_PATTERN))) { return false; }
        if (!LabelSet.diffIsEmpty(new LabelSet(SpecialLabels.ANY_STRING_PATTERN), new LabelSet(
                SpecialLabels.ANY_STRING_PATTERN))) { return false; }
        if (!LabelSet.diffIsEmpty(new LabelSet(SpecialLabels.ANY_LABEL_PATTERN), new LabelSet(
                SpecialLabels.ANY_LABEL_PATTERN))) { return false; }
        LabelSet op1 = new LabelSet(MatchedType.MATCH_LABELS);
        op1.addLabel(SpecialLabels.ANY_LABEL_PATTERN);
        op1.addLabel("a");
        op1.addLabel("b");
        LabelSet op2 = new LabelSet(MatchedType.MATCH_LABELS);
        op2.addLabel(SpecialLabels.ANY_LABEL_PATTERN);
        op2.addLabel("b");
        op2.addLabel("d");
        System.out.println(op1 + "\\" + op2 + "=" + LabelSet.difference(op1, op2));
        LabelSet ls = new LabelSet(MatchedType.MATCH_LABELS);
        ls.addLabel("h1");
        ls.addLabel("h2");
        ls.addLabel("h3");
        String h1 = new String("h1");
        String h2 = new String("h2");
        String h3 = new String("h3");
        String table = new String("table");
        if (!ls.matchLabel(h1)) return false;
        if (!ls.matchLabel(h2)) return false;
        if (!ls.matchLabel(h3)) return false;
        if (ls.matchLabel(table)) return false;
        LabelSet orLabels = new LabelSet("tr");
        orLabels.addLabel("table");
        orLabels.addLabel(h1);
        if (!ls.matchLabel(orLabels)) return false;
        orLabels.remove("h1");
        if (ls.matchLabel(orLabels)) return false;
        LabelSet dup = (LabelSet) ls.clone();
        ls.remove("h1");
        if (!dup.matchLabel("h1")) return false;
        if (ls.matchLabel("h1")) return false;
        return true;
    }
}
