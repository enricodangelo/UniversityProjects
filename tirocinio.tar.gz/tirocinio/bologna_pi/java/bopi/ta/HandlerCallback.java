/*
 * HandlerCallback.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Mar 18, 2004
 */
package bopi.ta;

import bopi.values.*;

/**
 * Callbacks used by the PatternDefaultHandler and by the VNodeDefaultHandler to write back the read automaton or 
 * the read node. This interface is implemented by a client who wants to use PatternDefaultHandler and VNodeDefaultHandler 
 * for XML fragments. At the end of the fragment both these handlers callback the client setting the automaton or the node and 
 * restoring the previous content handler.
 * @author Samuele Carpineti
 */
public interface HandlerCallback {
	/** 
	 * Sets the automaton
	 * @param ta - the processed automaton 
	 */
	public void setAutomaton(TreeAutomaton ta);
	/** 
	 * Sets the node
	 * @param node - the processed value 
	 */
	public void setVNode(VNode node);
    public void setXMLDocument(String xml);
}
