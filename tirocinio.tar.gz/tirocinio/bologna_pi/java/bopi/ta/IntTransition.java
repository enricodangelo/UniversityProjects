/*
 * IntTransition.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Oct 18, 2004
 */
package bopi.ta;
/**
 * Transition that matches integer literals
 * @author Samuele Carpineti
 */
class IntTransition extends MatchingTransition {
	/**
	  * Creates an IntTransition that matches an integer literal 
	  * @param labels -  a LabelSet matching integers
	  * @param src - the source state
	  * @param dst - the destination state
	  * @param variables - the set of variables to bind in the matching
	  * @throws RuntimeException if the the LabelSet does not match integers
	  */
	IntTransition(LabelSet labels, TAState src, TAState dst, int[] variables) {
		super(labels, src, dst, null, variables);
		if (!labels.MATCH_INT)
			throw new RuntimeException("An integer must be matched by this set of label");
	}
	/**
	  * Creates an IntTransition that matches an integer literal 
	  * @param number - the integer to match
	  * @param src - the source state
	  * @param dst - the destination state
	  * @param variables - the set of variables to bind in the matching
	  */
	IntTransition(int number, TAState src, TAState dst, int[] variables) {
		super(SpecialLabels.INTEGER_LITERAL + number, src, dst, null, variables);
	}
	/**
	  * Creates an IntTransition that matches an integer literal 
	  * @param number - the integer literal to match
	  * @param src - the source state
	  * @param dst - the destination state
	  * @param variables - the set of variables to bind in the matching
	  */
	IntTransition(String number, TAState src, TAState dst, int[] variables) {
		super(new LabelSet(MatchedType.MATCH_INTEGERS), src, dst, null, variables);
        //Check if the number is an "integer label" or not. It is an integer label if it's the ANY_INTEGER label or if it is 
        //prefixed by the integer prefix: INTEGER_LITERAL  
		if (SpecialLabels.IS_ANY_INTEGER_PATTERN(number) || SpecialLabels.IS_INTEGER_LITERAL(number))
			labels.addLabel(number);
		else {
			Integer.parseInt(number);
			labels.addLabel(SpecialLabels.INTEGER_LITERAL + number);
		}
	}
	/**
	  * Creates an IntTransition that matches every integer literal 
	  * @param src - the source state
	  * @param dst - the destination state
	  * @param variables - the set of variables to bind in the matching
	  */
	IntTransition(TAState src, TAState dst, int[] variables) {
		super(SpecialLabels.ANY_INTEGER_PATTERN, src, dst, null, variables);
	}
	/**
	 * Returns true if the transition match any integer
	 * @return true if the transition match any integer
	 */
	boolean matchAnyInteger() {
		return labels.matchAnyInteger();
	}
	public MatchingTransition duplicate(TAState src, TAState dst) {
		int[] vars= new int[variables.length];
		for (int j= 0; j < variables.length; j++) {
			vars[j]= variables[j];
		}
		return (new IntTransition((LabelSet) labels.clone(), src, dst, vars));
	}

    TreeAutomaton[] getContents() {
        return new TreeAutomaton[0];
    }
}
