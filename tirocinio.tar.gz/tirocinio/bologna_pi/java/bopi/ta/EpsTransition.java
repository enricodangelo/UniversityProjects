/*
 * EpsilonTransition.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 26, 2004
 */
package bopi.ta;
/**
 * Epsilon transition q-->q' without reading any datum
 * @author Samuele Carpineti
 */
class EpsTransition extends Transition {
	EpsTransition(TAState src, TAState dst) {
		super(src, dst);
	}
	public boolean equals(Object o) {
		return ((o instanceof EpsTransition) && (((EpsTransition) o).dst.equals(dst)) && (((EpsTransition) o).src.equals(src)));
	}
	public String toString() {
		return src.toString() + "-e->" + dst.toString();
	}
	protected EpsTransition duplicate(final TAState src, final TAState dst) {
		return new EpsTransition(src, dst);
	}
}
