/*
 * Transition.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 27, 2004
 */
package bopi.ta;
/**
 * A transition must have a source and a destination state. In our automaton there are epsilon transitions and labelled transitions.
 * @author Samuele Carpineti 
 */
abstract class Transition implements Comparable {
	/** The source state of the transition */
	TAState src;
	/** The destination state of the transition */
	TAState dst;
	/**
	 * Builds a new transition (the class is abstract so only subclasses can use this method)
	 * @param src - the source state
	 * @param dst - the destination state
	 */
	Transition(TAState src, TAState dst) {
		this.src= src;
		this.dst= dst;
	}
	/** 
	 * Duplicates this transition
	 * @param src - source state
	 * @param dst - destination state
	 * @return a new transition from src to dst 
	 */
	abstract Transition duplicate(TAState src, TAState dst);
	abstract public boolean equals(Object o);
	abstract public String toString();
	public int hashCode() {
		return (int) src.id;
	}
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		if (this.hashCode() < o.hashCode())
			return -1;
        if (equals(o)) return 0;
        return 1;
	}
}
