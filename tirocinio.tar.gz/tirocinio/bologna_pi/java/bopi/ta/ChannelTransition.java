/*
 * ChannelTransition.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Oct 18, 2004
 */
package bopi.ta;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
import bopi.values.ChannelLiteral;
import bopi.values.LabelledElement;

/**
 * Transition that matches channel literals. It supports I/O capabilities.
 * 
 * @author Samuele Carpineti
 */
class ChannelTransition extends MatchingTransition {
	//This set is used for differences between channels
	protected Set<ChannelTransition> diffTransitions = new TreeSet<ChannelTransition>();

	public final static int OUT_CAPABILITY = -1;

	public final static int IN_CAPABILITY = +1;

	public final static int IO_CAPABILITY = 2;

	final static int NO_CAPABILITY = 0;
	
	private int capability;
	
	protected boolean hasInputCapability() {
		return (capability == IN_CAPABILITY) || (capability == IO_CAPABILITY);
	}

	protected boolean hasOutputCapability() {
		return (capability == OUT_CAPABILITY) || (capability == IO_CAPABILITY);
	}

	public int getCapability() {
		return capability;
	}

	protected boolean hasMoreEqCapability(int capability) {
		return ((Math.abs(capability) > Math.abs(capability)) || (this.capability == capability));
	}

	protected int intersectCapability(ChannelTransition chTransition) {
		if (hasMoreEqCapability(chTransition.capability))
			return chTransition.capability;
		else if (chTransition.hasMoreEqCapability(this.capability))
			return capability;
		return NO_CAPABILITY;
	}

	public ChannelTransition(int capability, TAState srcState, TAState destState, TreeAutomaton automaton,
			Set<ChannelTransition> diffTransitions, int[] bindings) {
		this(capability, srcState, destState, null, bindings);
		this.content = automaton;
		this.diffTransitions = diffTransitions;
	}

	private LabelSet createChanLabel(int capability) {
//		Vector<String> v = new Vector<String>();
//		if (hasInputCapability())
//			v.add(SpecialLabels.CHANNEL_LITERAL + "#chan^i");
//		if (hasOutputCapability())
//			v.add(SpecialLabels.CHANNEL_LITERAL + "#chan^o");
//		return new LabelSet(v);
		return new LabelSet(SpecialLabels.CHANNEL_LITERAL + "#chan");
	}

	/**
	 * Creates a new channel transition that matches channels with a given type.
	 * 
	 * @param src
	 *            the source state
	 * @param dst
	 *            the destination state
	 * @param ta
	 *            schema of the channel
	 * @param variables
	 *            the set of variables to bind in the matching
	 */
	ChannelTransition(int capability, TAState src, TAState dst, TreeAutomaton ta, int[] variables) {
		super(src, dst, ta, variables);
		this.capability = capability;
		this.labels = createChanLabel(capability);
		if (!labels.MATCH_CHANNEL)
			throw new RuntimeException("A channel must be matched by this set of label");
	}

	ChannelTransition(int capability, LabelSet labels, TAState src, TAState dst, TreeAutomaton typeTA, int[] variables) {
		super(labels, src, dst, typeTA, variables);
		this.capability = capability;
		if (!labels.MATCH_CHANNEL)
			throw new RuntimeException("A channel must be matched by this set of label");
	}

	public MatchingTransition duplicate(TAState src, TAState dst) {
		int[] vars = new int[variables.length];
		for (int j = 0; j < variables.length; j++)
			vars[j] = variables[j];
		ChannelTransition ct =new ChannelTransition(capability, (LabelSet) labels.clone(), src, dst, content, vars);
		ct.MATCH_SOME_CHANNEL = this.MATCH_SOME_CHANNEL;
		return ct;
	}


	private boolean checkIn(ChannelTransition ct, Set<Assumption> assumptions) {
		Assumption assumption = new Assumption(content, ct.content);
		if (assumptions.contains(assumption)) {
			return false;
		} else {
			assumptions.add(assumption);
			boolean isSub = StaticAnalyzer.isSubtype(content, ct.content, assumptions);
			//assumptions.clear();
			return !isSub;
		}
	}

	private boolean checkOut(ChannelTransition ct, Set<Assumption> assumptions) {
		Assumption assumption = new Assumption(ct.content, content);
		if (assumptions.contains(assumption)) {
			return false;
		} else {
			assumptions.add(assumption);
			boolean isSub = StaticAnalyzer.isSubtype(ct.content, content, assumptions);
			//assumptions.clear();
			return !isSub;
		}
	}

	private boolean checkInOut(ChannelTransition ct, Set<Assumption> assumptions) {
		Assumption assumption0 = new Assumption(ct.content, content);
		Assumption assumption1 = new Assumption(content, ct.content);
		if (assumptions.contains(assumption0) && assumptions.contains(assumption1)) {
			return false;
		} else {
			assumptions.add(assumption0);
			assumptions.add(assumption1);
			boolean isSub = StaticAnalyzer.isSubtype(ct.content, content, assumptions);
			isSub &= StaticAnalyzer.isSubtype(content, ct.content, assumptions);
			//assumptions.clear();
			return !isSub;
		}

	}

	private int MATCH_SOME_CHANNEL = -1;
	public boolean matchSomeChannel(Set<Assumption> assumptions) {
		if (MATCH_SOME_CHANNEL == 1) return true;
		else if (MATCH_SOME_CHANNEL == 0) return false;
		Iterator<ChannelTransition> j = diffTransitions.iterator();
		boolean matchSomething = true;
		while (j.hasNext() && matchSomething) {
			ChannelTransition ct = j.next();
			if (!hasMoreEqCapability(ct.getCapability()))
				continue;
			int cap = intersectCapability(ct);
			if (cap == OUT_CAPABILITY) {
				if (!checkOut(ct, assumptions))
					matchSomething = false;
			} else if (cap == IN_CAPABILITY) {
				if (!checkIn(ct, assumptions))
					matchSomething = false;
			} else if (cap == IO_CAPABILITY) {
				if (!checkInOut(ct, assumptions))
					matchSomething = false;
			} else if (cap == NO_CAPABILITY)
				continue;
		}
		if (matchSomething) MATCH_SOME_CHANNEL = +1;
		else MATCH_SOME_CHANNEL = 0;
		return matchSomething;
	}

	/**
	 * Returns true if the element is matched by this transition, false
	 * otherwise
	 * 
	 * @return true if the element is matched by this transition, false
	 *         otherwise
	 */
	boolean match(LabelledElement element) {
		if (content == null)
			throw new RuntimeException("The content automata of a channel transition is null");
		if (element instanceof ChannelLiteral) {
			ChannelLiteral ch = (ChannelLiteral) element;
			if (!hasMoreEqCapability(ch.getCapability()))
				return false;
			if (hasOutputCapability()) {
				if (!StaticAnalyzer.isSubtype(content, ch.typeTA))
					return false;
//				//this code should be never used because diffTransitions is
//				// always empty in the high level type system
//				Iterator<ChannelTransition> j = diffTransitions.iterator();
//				while (j.hasNext())
//					if (StaticAnalyzer.isSubtype(j.next().content, ch.typeTA))
//						return false;
				return true;
			}
			if (hasInputCapability()) {
				if (!StaticAnalyzer.isSubtype(ch.typeTA, content))
					return false;
//				//this code should be never used because diffTransitions is
//				// always empty in the high level type system
//				Iterator<ChannelTransition> j = diffTransitions.iterator();
//				while (j.hasNext())
//					if (StaticAnalyzer.isSubtype(ch.typeTA, j.next().content))
//						return false;
				return true;
			}
		}
		return false;
	}

	public String toString() {
		String s = new String();
		s += src.toString();
		if (variables.length > 0)
			s += "-{";
		for (int i = 0; i < variables.length; i++) {
			s += variables[i];
			if (i < variables.length - 1)
				s += " ";
		}
		if (variables.length > 0)
			s += "}:";
		s += "    <";
		if (content != null)
			s += "[Q" + content.getID() + "]";
		else
			s += "Empty";
		s += ">";
		if (capability == IN_CAPABILITY)
			s += "^i";
		if (capability == OUT_CAPABILITY)
			s += "^o";
		if (capability == IO_CAPABILITY)
			s += "^io";
		if (!diffTransitions.isEmpty()) {
			s += "\\[";
			Iterator<ChannelTransition> j = diffTransitions.iterator();
			while (j.hasNext()) {
				String t = j.next().toString();
				s += t.substring(t.indexOf("<") + 2, t.indexOf("->"));
			}
		}
		s += "-->    " + dst.toString();
		return s;
	}

	/**
	 * Returns the list of automaton of this transition
	 * 
	 * @see bopi.ta.MatchingTransition#getContents()
	 */
	TreeAutomaton[] getContents() {
		TreeAutomaton[] c = new TreeAutomaton[1 + diffTransitions.size()];
		c[0] = content;
		Iterator<ChannelTransition> i = diffTransitions.iterator();
		for (int j = 1; j < c.length; j++)
			c[j] = i.next().content;
		return c;
	}
}