/*
 * TA.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 26, 2004
 */
package bopi.ta;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;
import java.util.Collection;
import java.util.Map;
import org.xml.sax.SAXException;
import bopi.ta.TransitionExceptions;
import bopi.values.*;

/**
 * <p>
 * Tree automata are just like normal string automata but elements are trees
 * instead of characters. An automaton is a quadruple (Q,I,F,T U E) formed by a
 * set Q of states, a subset I of Q that represents the set of the initial
 * states, a subset F of Q that represents the set of final states, a set of
 * transitions T and a set of epsilon transitions E.
 * </p>
 * <p>
 * Transitions can be either normal labeled transitions or epsilon (null)
 * transitions. A normal labelled transition has the form: <blockquote>
 * 
 * <pre>
 *      
 *       q1 l[content]-- &gt; q2
 *         
 *  
 * </pre>
 * 
 * </blockquote> and its meaning is: transit from state q1 to state q2 when the
 * next input element is a tag with name "l" and with the specified content.
 * Special kind of transitions are transition for integers, strings and
 * channels.
 * 
 * An epsilon transition has the form: <blockquote>
 * 
 * <pre>
 * q1-- &gt; q2
 * </pre>
 * 
 * </blockquote> and its meaning is: non deterministically transit from state q1
 * to state q2.
 * </p>
 */
public class TreeAutomaton {

    /** automaton id */
    private static int TA_ID = 0;

    /** Tree automaton identifier */
    private int id = 0;

    /** maximum bindings in the current automaton */
    private int maxBinding = -1;

    /** Epsilon transition of the automaton are stored in different sets */
    private TransitionsList<MatchingTransition> transitions = new TransitionsList<MatchingTransition>();

    /** Labelled transition of the automaton are stored in different sets */
    private TransitionsList<EpsTransition> epsTransitions = new TransitionsList<EpsTransition>();

    /** Set of states Q */
    private HashSet<TAState> states = new HashSet<TAState>();

    /** The set of initial states I */
    private HashSet<TAState> initialStates = new HashSet<TAState>();

    /** The set of final states F */
    private HashSet<TAState> finalStates = new HashSet<TAState>();

    /**
     * True if transitions are verified before the insertion; verification is
     * performed by checking that source and destination state are in Q
     */
    static protected boolean VERIFY_ADDED_TRANSITIONS = true;

    /**
     * True if the automaton have not useless states, false otherwise (this
     * method doesn't look in the subautomata
     */
    protected boolean WITHOUT_USELESS_STATES = false;

    /** Stores the color of non visited state */
    private int COLOR_NOT_VISITED_STATE = 0;

    /**
     * True if the automaton wasn't visited, true otherwise (avoids infinite
     * recursion on the same automata) Each method that uses VISITED must set
     * VISITED to false at the end.
     */
    protected boolean VISITED = false;

    /**
     * 1 if the automaton recognizes the empty language, 0 if the automaton
     * don't recognize the empty language, -1 if is not calculated yet
     */
    protected int RECOGNIZES_EMPTY_LANGUAGE = -1;

    /**
     * Builds a new empty tree automaton
     */
    protected TreeAutomaton() {
        id = TA_ID++;
    }

    /**
     * Returns true if the automaton have not epsilon transitions, false
     * otherwise (this method doesn't look in the subautomata)
     */
    private boolean withoutEpsilonTransitions() {
        return epsTransitions.size() == 0;
    }

    /**
     * Set the visited field of this automaton
     * 
     * @param mode -
     *            true if the property must be set to true, false otherwise
     */
    public void setVisited(boolean mode) {
        VISITED = mode;
    }

    /**
     * Return the visited field of this automaton
     * 
     * @return true if the property is set to true, false otherwise
     */
    public boolean isVisited() {
        return VISITED;
    }

    /**
     * Returns the id of the automaton
     * 
     * @return the id of the automaton
     */
    protected int getID() {
        return id;
    }

    /**
     * if (state.isFinal) F = F U {state} if (state.isInitial) I = I U {state} Q =
     * Q U {state} T = T U state.epsTransition U state.transitions
     * 
     * @param state
     *            the state to add; if the state is final is added to the set of
     *            final states instead if it's initial it's added to the set of
     *            initial states
     */
    protected void addState(TAState state) {
        if (state.isInitial) initialStates.add(state);
        if (state.isFinal) finalStates.add(state);
        state.color = COLOR_NOT_VISITED_STATE;
        states.add(state);
        epsTransitions.addAll(state.epsTransitions);
        transitions.addAll(state.transitions);
        WITHOUT_USELESS_STATES = false;
    }

    /**
     * F = F U {state}
     * 
     * @param state
     *            the state to set as final
     */
    protected void setFinal(TAState state) {
        if (states.contains(state)) {
            finalStates.add(state);
            state.isFinal = true;
        }
        return;
    }

    /**
     * I = I U {state}
     * 
     * @param state
     *            the state to set as initial
     */
    protected void setInitial(TAState state) {
        if (states.contains(state)) {
            initialStates.add(state);
            state.isInitial = true;
        }
    }

    protected boolean checkIFStates() {
        for (TAState state: initialStates)
            if (!state.isInitial) return false;
        for (TAState state:finalStates)
            if (!state.isFinal) return false;
        return true;
    }

    /**
     * Calls addState for state in the array
     * 
     * @param states
     *            an array with the states to add
     */
    protected void addAllStates(TAState[] states) {
        for (int i = 0; i < states.length; i++)
            addState(states[i]);
    }

    /**
     * Calls addState for state in the collection
     * 
     * @param states
     *            the collection with all the states to add
     */
    protected void addAllStates(Collection<TAState> states) {
        for (TAState state: states)
            addState(state);
    }
    
    public void addTransitions(TransitionsList<? extends Transition> transitions) {
        for (Transition t: transitions)
            addTransition(t);
    }
    /**
     * Add a transition to the automaton transitions
     * 
     * @param transition
     *            the transition to add
     * @throws TransitionExceptions
     *             if the source or the destination state doesn't exist or if
     *             the label set is empty
     */
    protected void addTransition(Transition transition) {
        if (TreeAutomaton.VERIFY_ADDED_TRANSITIONS) {
            if (!states.contains(transition.dst)) throw (new TransitionExceptions(transition.dst));
            if (!states.contains(transition.src)) throw (new TransitionExceptions(transition.src));
        }
        if (transition instanceof EpsTransition) {
			EpsTransition eps = (EpsTransition) transition;
            epsTransitions.add(eps);
            transition.src.epsTransitions.add(eps);
            transition.dst.incomingEpsTransitions.add(eps);
        } else if (transition instanceof MatchingTransition) {
            MatchingTransition t = (MatchingTransition) transition;
            //if (t.hasEmptyLabel()) return;
            transitions.add(t);
            transition.src.transitions.add(t);
            transition.dst.incomingTransitions.add(t);
            for (int i = 0; i < t.variables.length; i++)
                if (t.variables[i] > maxBinding) maxBinding = t.variables[i];
        } else throw new RuntimeException("Unexpected Transition Type");
        //when a new transition is added the previous result for emptyness is
        //reset
        RECOGNIZES_EMPTY_LANGUAGE = -1;
    }

    /**
     * Used to store if the automaton is visited by removeEpsilonTransitions
     */
    private boolean REMOVEPSVISITED = false;

    protected void removeTransition(Transition t) {
        epsTransitions.remove(t);
        transitions.remove(t);
        t.src.transitions.remove(t);
        t.src.epsTransitions.remove(t);
        t.dst.incomingTransitions.remove(t);
        t.dst.incomingEpsTransitions.remove(t);
    }

    /**
     * Removes epsilon transitions in the automaton. Complexity: O(|Q| x |E|)
     * NOTA BENE: withoutEpsilonTransitions is updated to true
     */
    protected void removeEpsilonTransitions() {
        if (REMOVEPSVISITED) return;
        if (!withoutEpsilonTransitions()) {
            for (TAState state: states){
                Set<TAState> closure = new HashSet<TAState>();
                /* a state belong to its closure */
                closure.add(state);
                /*
                 * the state is final if one of the state in its closure is
                 * final
                 */
                state.isFinal = epsilonClosure(state, state, closure, state.isFinal) || state.isFinal;
                if (state.isFinal) finalStates.add(state);
            }
            epsTransitions.clear();
            resetStatesTransitions();
            /* Sets pointer state.transitions and state.incomingTransitions */
            setStatesTransitions(false);
        }
        REMOVEPSVISITED = true;
        /* removes epsilon transitions in the subautomaton */
        for (MatchingTransition t: transitions){
            if (t.content != null) t.content.removeEpsilonTransitions();
        }
        REMOVEPSVISITED = false;
    }

    /**
     * Calculates the epsilon closure of a state 's'
     * 
     * @param initState
     *            the initial state of the closure
     * @param state
     *            the state to use as source calculating the epsilon closure
     * @param closure
     *            the current closure (this parameter is modified during the
     *            computation by adding new states)
     * @return true if one state in the closure is final, false otherwise
     */
    private boolean epsilonClosure(TAState initState, TAState state, Set<TAState> closure, boolean existAFinalState) {
        /*
         * The algorithm processes all the espilon transitions 't' from 'state'
         * and if the destination 'dst' isn't in the closure: 1. closure =
         * closure U {dst} 2. all the labelled transitions from 'dst' change its
         * source state to 'initState' 3. the same algorithm is called on 'dst'
         */
        for (EpsTransition t: state.epsTransitions){
            if (closure.add(t.dst)) {
                /*
                 * if one state in the closure is final then epsilonClosure
                 * returns true
                 */
                existAFinalState = existAFinalState || t.dst.isFinal;
                /*
                 * we add all the labelled transitions from t.dst with initState
                 * as source state
                 */
                TransitionsList<MatchingTransition> tList = null;
                if (!initState.equals(t.dst)) tList = t.dst.transitions.duplicateAndMap(t.dst, initState);
                boolean isFinal = this.epsilonClosure(initState, t.dst, closure, existAFinalState);
                existAFinalState = existAFinalState || isFinal;
                /*
                 * initState.transitions.addAll(set); is done outside becuase i
                 * cannot change state transitions during the computation
                 */
                if (!initState.equals(t.dst)) transitions.addAll(tList);
            }
        }
        return existAFinalState;
    }

    /**
     * References to transitions in all the states are resetted. Complexity:
     * O(Q)
     */
    private void resetStatesTransitions() {
        for (TAState state : states){
            state.epsTransitions.clear();
            state.transitions.clear();
            state.incomingEpsTransitions.clear();
            state.incomingTransitions.clear();
        }
    }

    protected void resetFinalStates() {
        for (TAState state : finalStates)
            state.isFinal = false;
        finalStates.clear();
    }

    /**
     * References to transitions in all the states are set by using current
     * transition set . Complexity if checkState O(T x 2C(In(state))) else O(T)
     * 
     * @param checkStates
     *            true if transitions are supposed to be valid, false if
     *            transitions are checked
     */
    private void setStatesTransitions(boolean checkStates) {
        for (MatchingTransition t: transitions){
            t.src.transitions.add(t);
            t.dst.incomingTransitions.add(t);
        }
        for (EpsTransition t: epsTransitions){
            if (checkStates) {
                if (!states.contains(t.src) || !states.contains(t.src)) break;
            }
            t.src.epsTransitions.add(t);
            t.dst.incomingEpsTransitions.add(t);
        }
    }

    /**
     * Used to store if the automaton is visited by removeUselessStates
     */
    private boolean REMOVEUSELESSVISITED = false;

    /**
     * Removes useless states in the automaton. Complexity: O(|Q|x|T|) + O(T x
     * 2C(In(state))) NOTA BENE: WITHOUT_USELESS_STATES is updated to true
     * 
     * @throws ExistsEpsTransitionException
     *             if one state has some epsilon transition
     */
    protected void removeUselessStates() {
        /*
         * Check if the automaton have not epsilon transitions, set visited to
         * false and removes empty transitions. Complexity O(|T|)
         */
        if (REMOVEUSELESSVISITED) return;
        if (!WITHOUT_USELESS_STATES) {
            Iterator<TAState> i = states.iterator();
            while (i.hasNext()) {
                TAState state = i.next();
                if (state.epsTransitions.size() > 0) throw (new ExistsEpsTransitionException(state));
                // all the transition in TranitionsList must be non-empty so
                // should be useless to call this method
                // that explicitly removes all empty transitions
                //state.transitions.removeEmpty();
                state.visited = false;
            }
            transitions.removeEmpty();
            states.clear();
            finalStates.clear();
            /* Look for states reacheable from initial states */
            i = initialStates.iterator();
            while (i.hasNext()) {
                TAState src = i.next();
                if (!src.visited) {
                    states.add(src);
                    if (src.isFinal) finalStates.add(src);
                    this.reacheableForward(src);
                }
            }
            /* Purge no more valid transitions O(T x 2C(In(state))) */
            Iterator<MatchingTransition> j = transitions.iterator();
            while (i.hasNext()) {
				MatchingTransition t = j.next();
                if (!states.contains(t.src) || !states.contains(t.dst)) i.remove();
            }
            this.resetStatesTransitions();
            this.setStatesTransitions(true);
            /* set visited to false */
            for (TAState state: states) state.visited = false;
            /*
             * Look for states reacheable from new final states by using
             * transitions backward
             */
            for (TAState dst: finalStates){
                if (!dst.visited) this.reacheableBackward(dst);
            }
            /* Erase state not visited from one of the final states */
            i = states.iterator();
            while (i.hasNext()) {
                TAState state = i.next();
                if (!state.visited) {
                    j = transitions.iterator();
                    while (j.hasNext()) {
                        MatchingTransition t = j.next();
                        if (t.src == state) t.dst.transitions.remove(t);
                        if (t.dst == state) t.src.transitions.remove(t);
                        if (t.dst == state || t.src == state) j.remove();
                    }
                    i.remove();
                }
            }
            /*
             * At this point i've a new Q without useless states Set up initial
             * and final state from the complete set of states and remove
             * useless transitions O(|Q|)
             */
            TransitionsList<MatchingTransition> newTransitions = new TransitionsList<MatchingTransition>();
            for (TAState state: states){
                newTransitions.addAll(state.transitions);
            }
            transitions = newTransitions;
        }
        REMOVEUSELESSVISITED = true;
        /* removes useless states in the subautomaton */
        for (MatchingTransition t: transitions){
            if (t.content != null) {
                WITHOUT_USELESS_STATES = true;
                t.content.removeUselessStates();
            }
        }
        REMOVEUSELESSVISITED = false;
    }

    /**
     * Add the set of reacheable states from a source to the automaton states;
     * if a final state is visited it's added to both: states and finalStates
     * (is a DFS then the complexity is O(|T|))
     * 
     * @param src -
     *            the source state
     * @throws ExistsEpsTransitionException
     *             if the state has some epsilon transition
     */
    private void reacheableForward(TAState src) {
        if (src.epsTransitions.size() != 0) throw (new ExistsEpsTransitionException(src));
        if (!src.visited) src.visited = true;
        else return;
        for (MatchingTransition t: src.transitions){
            addState(t.dst);
            this.reacheableForward(t.dst);
        }
    }

    /**
     * Visit states reacheable from a destination by using transitions backward
     * (visited is set to true); (is a DFS then the Complexity is O(|T|))
     * 
     * @param dst
     *            the source state
     * @throws ExistsEpsTransitionException
     *             if the state has some epsilon transition
     */
    private void reacheableBackward(TAState dst) {
        if (dst.epsTransitions.size() != 0) throw (new ExistsEpsTransitionException(dst));
        dst.visited = true;
        for (MatchingTransition t: dst.incomingTransitions){
            dst.visited = true;
            if (!t.src.visited) this.reacheableBackward(t.src);
        }
    }

    private boolean DESCENDANTVISITED = false;

    /**
     * Returns the set of automaton reacheable from the current one
     * 
     * @param set
     *            the initial set (usually should be an emtpy set)
     * @return the set of automaton reacheable from the current one
     */
    protected Set<TreeAutomaton> getDescendantAutomata(Set<TreeAutomaton> set) {
        if (DESCENDANTVISITED) return set;
        DESCENDANTVISITED = true;
        for (MatchingTransition t: transitions){
            //gets and puts contents that can be null (transitions without
            // content)
            TreeAutomaton[] contents = t.getContents();
            for (int j = 0; j < contents.length; j++) {
                if (contents[j] != null) {
                    set.add(contents[j]);
                    set = contents[j].getDescendantAutomata(set);
                }
            }
        }
        DESCENDANTVISITED = false;
        return set;
    }

    /** Used to store if the automaton is visited by the getMaxBinding method */
    private boolean MAXBVISITED = false;

    /**
     * Returns the max binding in the automaton. This method should not be used
     * becasue it's quite heavy. It
     * 
     * @return the max binding
     */
    public int getMaxBinding() {
        int maxB = maxBinding;
        MAXBVISITED = true;
        for (MatchingTransition t: transitions){
            if (t.content != null && !t.content.MAXBVISITED) {
                if (t.content.getMaxBinding() > maxB) maxB = t.content.getMaxBinding();
            }
        }
        MAXBVISITED = false;
        return maxB;
    }

    /** boolean value used in order to avoid infinite loops printing automata */
    private boolean ISPRINTEDYET = false;

    /*-------------------------------------------------------------------------------------------------------------*/
    /* Automaton to Bopi Regular Type: end */
    /*-------------------------------------------------------------------------------------------------------------*/

    public String toString() {
        Set<TreeAutomaton> child = new HashSet<TreeAutomaton>();
        String ta = new String();
        ta = this.toString(child);
        return ta;
    }

    /**
     * Returns a string representation of this automaton.
     * 
     * @return a string representation of this automaton
     */
    private String toString(Set<TreeAutomaton> child) {
        if (ISPRINTEDYET) return "";
        String ta = new String();
        ta += "Q" + id + ":=\t{";
        Iterator<TAState> j = states.iterator();
        while (j.hasNext()) {
            ta += j.next().toString();
            if (j.hasNext()) ta += ",";
        }
        ta += "}, I={";
        j = initialStates.iterator();
        while (j.hasNext()) {
            ta += j.next().toString();
            if (j.hasNext()) ta += ",";
        }
        ta += "}, F={";
        j = finalStates.iterator();
        while (j.hasNext()) {
            ta += j.next().toString();
            if (j.hasNext()) ta += ",";
        }
        ta += "}, T={\n";
        Iterator<MatchingTransition> i = transitions.iterator();
        while (i.hasNext()) {
			MatchingTransition t =  i.next();
            ta += "\t" + t + "\n";
                if ((t.content != null) && (t.content != this)) {
                    TreeAutomaton[] contents = t.getContents();
                    for (int k = 0; k < contents.length; k++) {
                        child.add(contents[k]);
                    }
                }
        }
        ta += "}";
        if (!epsTransitions.isEmpty()) ta += " U {" + epsTransitions + "};";
        ISPRINTEDYET = true;
        Iterator<TreeAutomaton> it = child.iterator();
        while (it.hasNext()) {
            TreeAutomaton childautoma = it.next();
            child.remove(childautoma);
            ta += "\n" + childautoma.toString(child);
            it = child.iterator();
        }
        ISPRINTEDYET = false;
        return ta;
    }

    /**
     * @return the initial states of the automaton (I)
     */
    public Collection<TAState> getInitialStates() {
        return new Vector<TAState>(initialStates);
    }

    /**
     * @return the final states of the automaton (F)
     */
    public Collection<TAState> getFinalStates() {
        return new Vector<TAState>(finalStates);
    }

    /**
     * @return the states of the automaton (Q)
     */
    public Collection<TAState> getStates() {
        return new Vector<TAState>(states);
    }

    
    /**
     * Union between automata. Automaton cannot be used after this invocation
     * because it will shares transitions with the current one
     * 
     * @param automaton -
     *            the automaton to put in or
     * @return a reference to this automaton
     */
    public TreeAutomaton or(TreeAutomaton automaton) {
        transitions.addAll(automaton.getMatchingTransitions());
        epsTransitions.addAll(automaton.getEpsTransitions());
        states.addAll(automaton.getStates());
        finalStates.addAll(automaton.getFinalStates());
        initialStates.addAll(automaton.getInitialStates());
        return this;
    }

    /**
     * Force the current automaton to have only one initial state
     */
    public TreeAutomaton toOneInitialState() {
        if (initialStates.size() > 1) {
            TAState init = new TAState(recognizeEpsilon(), true);
            addState(init);
            Iterator<TAState> i = initialStates.iterator();
            while (i.hasNext()) {
                TAState oldInitialState =  i.next();
                if (oldInitialState != init) {
                    oldInitialState.isInitial = false;
                    addTransition(new EpsTransition(init, oldInitialState));
                }
            }
            initialStates.clear();
            initialStates.add(init);
            removeEpsilonTransitions();
            removeUselessStates();
        }
        return this;
    }

    /**
     * Build the Kleen star of the autamaton. <br/>Automaton cannot be used
     * after this invocation because it will shares transitions with the current
     * automaton
     * 
     * @return a reference to this modified automaton
     */
    public TreeAutomaton star() {
        for (TAState src: initialStates){
            for (TAState dst: finalStates){
                epsTransitions.add(new EpsTransition(src, dst));
            }
        }
        TAState q0 = new TAState(false, true);
        for (TAState dst: initialStates){
            dst.isInitial = false;
            epsTransitions.add(new EpsTransition(q0, dst));
        }
        initialStates.clear();
        initialStates.add(q0);
        return this;
    }

    public Object[] clone(TransitionsList transitions) {
        /*
         * The algorithm works as follows: for each transition (the first round
         * reads epsilon transitions while the second processes labelled
         * transitions) 1. if the source state wasn't visited jet its relative
         * become its clone that is added to the new automaton 2. if the
         * destination state wasn't visited jet its relative become its clone
         * that is added to the new automaton 3. a new transition from
         * source.relative to dest.relative is created duplicating the previous
         * one (the content automaton of a labelled transition is not cloned due
         * the semantics of duplicate)
         */
        TreeAutomaton copy = new TreeAutomaton();
        TransitionsList<Transition> retT = new TransitionsList<Transition>();
        for (int k = 0; k < 2; k++) {
            Iterator<? extends Transition> i = null;
            if (k == 0) i = this.epsTransitions.iterator();
            else i = this.transitions.iterator();
            while (i.hasNext()) {
                Transition t =  i.next();
                if (t.src.color == COLOR_NOT_VISITED_STATE) {
                    t.src.relative = (TAState) t.src.clone();
                    copy.addState(t.src.relative);
                    t.src.color = (COLOR_NOT_VISITED_STATE + 1) % 2;
                }
                if (t.dst.color == COLOR_NOT_VISITED_STATE) {
                    t.dst.relative = (TAState) t.dst.clone();
                    copy.addState(t.dst.relative);
                    t.dst.color = (COLOR_NOT_VISITED_STATE + 1) % 2;
                }
                Transition newt = t.duplicate(t.src.relative, t.dst.relative);
                if (transitions.contains(t)) retT.add(newt);
                copy.addTransition(newt);
            }
        }
        COLOR_NOT_VISITED_STATE = (COLOR_NOT_VISITED_STATE + 1) % 2;
        Object[] ret = { copy, retT };
        if (!copy.checkIFStates()) throw new RuntimeException("Error Cloning");
        return ret;
    }

    /**
     * Clones the automaton only at top level (if a labelled transition points
     * to another automaton it's not cloned)
     * 
     * @return a first level copy of this automaton
     */
    public Object clone() {
        /*
         * The algorithm works as follows: for each transition (the first round
         * reads epsilon transitions while the second processes labelled
         * transitions) 1. if the source state wasn't visited jet its relative
         * become its clone that is added to the new automaton 2. if the
         * destination state wasn't visited jet its relative become its clone
         * that is added to the new automaton 3. a new transition from
         * source.relative to dest.relative is created duplicating the previous
         * one (the content automaton of a labelled transition is not cloned due
         * the semantics of duplicate)
         */
        TreeAutomaton copy = new TreeAutomaton();
        Iterator<TAState> j = initialStates.iterator();
        while (j.hasNext()) {
            TAState state = j.next();
            if (state.epsTransitions.size() + state.transitions.size() == 0) copy.addState((TAState) state.clone());
        }
        for (int k = 0; k < 2; k++) {
            Iterator<? extends Transition> i = null;
            if (k == 0) i = epsTransitions.iterator();
            else i = transitions.iterator();
            while (i.hasNext()) {
                Transition t =  i.next();
                if (t.src.color == COLOR_NOT_VISITED_STATE) {
                    t.src.relative = (TAState) t.src.clone();
                    copy.addState(t.src.relative);
                    t.src.color = (COLOR_NOT_VISITED_STATE + 1) % 2;
                }
                if (t.dst.color == COLOR_NOT_VISITED_STATE) {
                    t.dst.relative = (TAState) t.dst.clone();
                    copy.addState(t.dst.relative);
                    t.dst.color = (COLOR_NOT_VISITED_STATE + 1) % 2;
                }
                Transition newt = t.duplicate(t.src.relative, t.dst.relative);
                copy.addTransition(newt);
            }
        }
        COLOR_NOT_VISITED_STATE = (COLOR_NOT_VISITED_STATE + 1) % 2;
        if (!copy.checkIFStates()) throw new RuntimeException("Error Cloning");
        return copy;
    }

    /**
     * Returns all the labelled transitions of the automaton
     * 
     * @return the automaton's labelled transitions
     */
    protected final TransitionsList<MatchingTransition> getMatchingTransitions() {
        return transitions;
    }

    /**
     * Returns all the epsilon transitions of the automaton
     * 
     * @return the automaton's epsilon transitions
     */
    protected final TransitionsList<EpsTransition> getEpsTransitions() {
        return epsTransitions;
    }

    /**
     * Indicates whether some other object is "equal to" this one.
     * 
     * @param o -
     *            the reference object with which to compare
     */
    public boolean equals(Object o) {
        return ((o instanceof TreeAutomaton) && ((TreeAutomaton) o).id == id);
    }

    /**
     * Returns a hash code value for this automaton
     * 
     * @return a hash code value for this automaton
     */
    public int hashCode() {
        return id;
    }

    /**
     * An automaton recognize epsilon if one of the initial state is final. The
     * alghorithm works also in presence of epsilon transition. Complexity
     * O(|I|)
     * 
     * @return true if the automaton recognizes epsilon, false otherwise
     */
    public boolean recognizeEpsilon() {
        Vector<TAState> states = new Vector<TAState>(initialStates);
        HashSet<TAState> visited = new HashSet<TAState>();
        while (!states.isEmpty()) {
            TAState s = states.get(0);
            states.remove(0);
            visited.add(s);
            if (s.isFinal) return true;
            Iterator<EpsTransition> j = s.epsTransitions.iterator();
            while (j.hasNext()) {
                EpsTransition e = j.next();
                if (!visited.contains(e.dst)) states.add(e.dst);
            }
        }
        return false;
    }

    /*-------------------------------------------------------------------------------------------------------------*/
    /* Pattern matching alghorithm: methods */
    /*-------------------------------------------------------------------------------------------------------------*/
    /**
     * Matches the automaton against a value and builds a new environment.
     * 
     * @return true if the automaton matches the value, false otherwise
     * @param value
     *            the node to match
     * @param env
     *            the environment where add bindings. It's not modified if the
     *            value is not matched by the pattern
     * @throws ExistsEpsTransitionException
     *             if the automaton has epsilon transitions
     */
    public boolean matchValue(VNode value, VNode[] env) {
        VNode v = VNode.derefer(env, value);
        boolean matched = match(v, env, initialStates);
        if (matched) {
            bindAll(v, env);
            if (v != null) v.clearAnnotations();
        }
        return matched;
    }

    /**
     * Returns an environment built by using bindings annotations written in the
     * pattern matching method.
     * 
     * @param annotatedValue
     *            a value annotated with bindings
     * @param env
     *            the starting environment (it's modified in place because it's
     *            used as accumulator in the recursion)
     */
    private void bindAll(VNode annotatedValue, VNode[] env) {
        /*
         * There are two cases: 1: S[v1, v2, v3, ..., vn] ==> goes inside and
         * processes the first value v1 then v2, ...,vn are reached by using v1
         * 2: a[v1] | Litaral ==> a) binds the node with its variables and
         * processes its siblings
         */
        if (annotatedValue instanceof VNodePointer) {
            this.bindAll(env[((VNodePointer) annotatedValue).getEnvIndex()], env);
            //throw new RuntimeException("Pointers cannot be in a pattern
            // matching");
        } else if (annotatedValue instanceof Sequence) {
            this.bindAll(annotatedValue.getChild(0), env);
        } else if (annotatedValue instanceof LabelledElement) {
            /*
             * annotated value can be a Literal or a LabelledElement so it can
             * have siblings
             */
            int[] bindings = annotatedValue.getBindings();
            for (int i = 0; i < bindings.length; i++) {
                int var = bindings[i];
                VNode oldValue = env[var];
                if (oldValue == null) {
                    env[var] = annotatedValue;
                } else if (oldValue instanceof Sequence) {
                    ((Sequence) oldValue).addChild(annotatedValue);
                } else {
                    Sequence newSeq = new Sequence();
                    newSeq.addChild(oldValue);
                    newSeq.addChild(annotatedValue);
                    env[var] = newSeq;
                }
            }
            this.bindAll(annotatedValue.getChild(0), env);
        } else if (annotatedValue instanceof SequenceElement) {
            this.bindAll(((SequenceElement) annotatedValue).getElementValue(), env);
            this.bindAll(((SequenceElement) annotatedValue).getNext(), env);
        }
    }

    /**
     * Matches a value departing from a set of states
     * 
     * @return true if the object matches the value; value is annotated with
     *         variables
     * @param states
     *            the states to use as initial states
     * @param value
     *            the value to match
     */
    private boolean match(VNode value, VNode[] env, HashSet<TAState> states) {
        if (epsTransitions.size() > 0) throw (new ExistsEpsTransitionException(((epsTransitions.iterator().next())).src));
        for (TAState state: states){
            if (match(value, env, state, false, false)) return true;
        }
        return false;
    }

    /**
     * Matches a value with the automaton departing from state
     * 
     * @return true if the automaton matches the value by using the passed state
     *         as initial state
     * @param value
     *            the value to match (NOTA BENE: it's annotated with variables
     *            bindings)
     * @param state
     *            the state to use as initial state
     * @param inSequence
     *            true if the value is inside a sequence, false otherwise
     * @param cast
     *            true if the pattern matching can cast basic data types
     */
    private boolean match(VNode value, VNode[] env, TAState state, boolean inSequence, boolean cast) {
        if (cast && value instanceof StringLiteral && value.toString().trim().length() == 0) {
            StringLiteral strLit = (StringLiteral) value;
            strLit.bindToEmpty();
            boolean matchRes = (state != null) && (inSequence || state.isFinal);
            if (!matchRes) value.clearAnnotations();
            else return true;
        }
        if (cast && value instanceof SequenceElement && !((SequenceElement) value).hasNext()
                && ((SequenceElement) value).getElementValue() instanceof StringLiteral
                && value.toString().length() == 0 && state.isFinal) {
            ((StringLiteral) ((SequenceElement) value).getElementValue()).bindToEmpty();
            return true;
        }
        if (value == null) return state.isFinal;
        Iterator<MatchingTransition> i = state.transitions.iterator();
        while (i.hasNext()) {
            MatchingTransition t = i.next();
            if (value instanceof VNodePointer) throw new RuntimeException("Only dereferenced types can be matched: "
                    + value);
            else if (value instanceof Sequence) return match(value.getChild(0), env, state, true, cast);
            else if (value instanceof SequenceElement) {
                SequenceElement el = (SequenceElement) value;
                //here i need to try only one transition so i set the
                // transitions set
                //from from 'state' to t and i restore the set after the match
                // operation
                TransitionsList<MatchingTransition> tl = state.transitions;
                state.transitions = new TransitionsList<MatchingTransition>();
                state.transitions.add(t);
                boolean matchEl = match(el.getElementValue(), env, state, true, cast);
                state.transitions = tl;
                if (!matchEl) el.clearAnnotations();
                else {
                    if (cast && el.getElementValue() instanceof StringLiteral
                            && el.getElementValue().toString().length() == 0) {
                        if (match(el.getNext(), env, state, true, cast)) return true;
                    } else if (match(el.getNext(), env, t.dst, true, cast)) return true;
                }
            } else if (value instanceof LabelledElement) {
                LabelledElement el = (LabelledElement) value;
                TAState s = null;
                if (!cast) s = matchLabelledElement(el, env, t);
                else s = matchLabelledElementIgnBaseType(el, env, t);
                boolean matchRes = (s != null) && (inSequence || s.isFinal);
                if (!matchRes) el.clearAnnotations();
                else {
                    el.setBindings(t.variables);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Checks if a labelled element is matched by a transition
     * 
     * @param el -
     *            the labelled element
     * @param t -
     *            the transition with which try to match
     * @return a state of this automaton if t match el, null otherwise
     */
    private TAState matchLabelledElement(LabelledElement el, VNode[] env, MatchingTransition t) {
        VNode child = el.getChild();
        boolean match = t.match(el);
        if (!match) return null;
        if (el instanceof Literal) return t.dst;
        if (t.content.match(child, env, t.content.initialStates)) { return t.dst; }
        return null;
    }

    /*-------------------------------------------------------------------------------------------------------------*/
    /* End of Pattern matching alghorithm */
    /*-------------------------------------------------------------------------------------------------------------*/
    /*-------------------------------------------------------------------------------------------------------------*/
    /* Emptiness alghorithm: methods */
    /*-------------------------------------------------------------------------------------------------------------*/
    /**
     * Returns true if the language recognized by the automaton is empty, false
     * otherwise. It uses the alghorithm proposed by Hosoya then it uses two
     * fixed point iteractions. If the property was calculated before this
     * method returns the previuos result.
     * 
     * @return true if the language recognized by the automaton is empty
     */
    public boolean isNull(Set<Assumption> emptynessAssumption) {
        if (RECOGNIZES_EMPTY_LANGUAGE == 1) return true;
        if (RECOGNIZES_EMPTY_LANGUAGE == 0) return false;
        removeEpsilonTransitions();
        removeUselessStates();
        WITHOUT_USELESS_STATES = false;
        // take the list of all the subautomata and include myself
        Set<TreeAutomaton> descendents = getDescendantAutomata(new HashSet<TreeAutomaton>());
        descendents.add(this);
        /*
         * In the fixpoint algorithm defined below the following mapping from
         * automata to boolean values will contain the partial emptiness values
         * of the automata.
         */
        Map<TreeAutomaton, Boolean> map = new HashMap<TreeAutomaton, Boolean>();
        /*
         * Initialize mapping from automata to emptiness values in the following
         * way. Given a subautomaton sa: - if RECOGNIZES_EMPTY_LANGUAGE=1 then
         * map[ta] = true - else if RECOGNIZES_EMPTY_LANGUAGE=0 then map[ta] =
         * false - else if RECOGNIZES_EMPTY_LANGUAGE=-1 then if
         * recognizeEpsilon() map[ta] = false - else map[sa] = true The
         * algorithm would work well also filling all emptiness values with true
         * (the inizialization above is an optimization)
         */
        Iterator<TreeAutomaton> i = descendents.iterator();
        while (i.hasNext()) {
            TreeAutomaton ta = i.next();
            if (ta.finalStates.isEmpty()) ta.RECOGNIZES_EMPTY_LANGUAGE = 1;
            if (ta.RECOGNIZES_EMPTY_LANGUAGE == 1) map.put(ta, Boolean.TRUE);
            else if (ta.RECOGNIZES_EMPTY_LANGUAGE == 0) map.put(ta, Boolean.FALSE);
            else if (ta.recognizeEpsilon()) map.put(ta, Boolean.FALSE);
            else map.put(ta, Boolean.TRUE);
        }
        boolean fixpoint;
        do {
            fixpoint = true;
            Iterator<TreeAutomaton> it = map.keySet().iterator();
            while (it.hasNext()) {
                TreeAutomaton ta = it.next();
                if (map.get(ta).booleanValue() && !ta.isNullYet(map, emptynessAssumption)) {
                    /*
                     * the empty value for sa is changed! update the map and
                     * force another loop
                     */
                    map.put(ta, Boolean.FALSE);
                    fixpoint = false;
                }
            }
        } while (!fixpoint);
        // updates the values of myself and of all the descendant automata
        Iterator<Map.Entry<TreeAutomaton, Boolean>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<TreeAutomaton, Boolean> e = it.next();
            TreeAutomaton ta =  e.getKey();
            boolean taIsNull = e.getValue().booleanValue();
            if (taIsNull) ta.RECOGNIZES_EMPTY_LANGUAGE = 1;
            else ta.RECOGNIZES_EMPTY_LANGUAGE = 0;
        }
        return (RECOGNIZES_EMPTY_LANGUAGE == 1);
    }

    /**
     * This function is used inside isNull().
     * 
     * @param map
     *            a map from automata to boolean. The value associated to an
     *            automaton is false if it recognize a non-empty language, true
     *            if we don't know (maybe yes or maybe not)
     * @return true if
     */
    private boolean isNullYet(Map<TreeAutomaton, Boolean> map, Set<Assumption> emptynessAssumption) {
        // the valid transitions are the transitions with a non-empty content
        // automaton or non empty ChannelTransition
        TransitionsList<MatchingTransition> validTransitions = new TransitionsList<MatchingTransition>();
        Iterator<MatchingTransition> i = transitions.iterator();
        while (i.hasNext()) {
            MatchingTransition t = i.next();
            if (t instanceof ChannelTransition) {
                ChannelTransition c = (ChannelTransition) t;
                if (c.matchSomeChannel(emptynessAssumption)) {
                    validTransitions.add(t);
                }
            } else if (t.content != null) {
                if (!map.get(t.content).booleanValue()) {
                    validTransitions.add(t);
                }
            } else if (!t.labels.MATCH_LABEL && !t.labels.matchNoValue()) {
                validTransitions.add(t);
            }
        }
        // validStates are states reachable from the the initial ones
        Iterator<TAState> stateIt = states.iterator();
        while (stateIt.hasNext())
            stateIt.next().visited = false;
        stateIt = initialStates.iterator();
        while (stateIt.hasNext()) {
            TAState source = (TAState) stateIt.next();
            if (reacheableContainsFinal(source, validTransitions)) 
				return false;
        }
        stateIt = states.iterator();
        while (stateIt.hasNext())
            ((TAState) stateIt.next()).visited = false;
        return true;
    }

    private boolean reacheableContainsFinal(TAState source, TransitionsList<MatchingTransition> tList) {
        if (source.isFinal) return true;
        Iterator<MatchingTransition> j = tList.iterator();
        while (j.hasNext()) {
            MatchingTransition lt = j.next();
            if (lt.src.equals(source) && !lt.dst.visited) {
                lt.dst.visited = true;
                if (reacheableContainsFinal(lt.dst, tList)) return true;
                lt.dst.visited = false;
            }
        }
        return false;
    }

    /*-------------------------------------------------------------------------------------------------------------*/
    /* End of Emptiness alghorithm */
    /*-------------------------------------------------------------------------------------------------------------*/
    /*-------------------------------------------------------------------------------------------------------------*/
    /* Basic operations: +, x, - */
    /*-------------------------------------------------------------------------------------------------------------*/
    /**
     * Sums the passed automata
     * 
     * @param automata -
     *            an array of tree automata
     * @return a new automaton which represent the sum of the passed automata
     */
    static public TreeAutomaton union(final Object automata[]) {
        TreeAutomaton copies[] = new TreeAutomaton[automata.length];
        for (int i = 0; i < automata.length; i++)
            copies[i] = (TreeAutomaton) ((TreeAutomaton) automata[i]).clone();
        for (int i = 1; i < automata.length; i++)
            copies[0].or(copies[i]);
        return copies[0];
    }

    /**
     * Minimize the automaton
     * 
     * @param automaton -
     *            the automaton to minimize
     * @return the minimum automaton
     */
    static public TreeAutomaton minimize(final TreeAutomaton automaton) {
        //TODO Implements a Top level minimization Hopcroft
        System.err.println("TreeAutomaton.minimize: Not yet implemented");
        return automaton;
    }

    /**
     * Builds a new automaton C = AxB. Bindings in A are present in C while
     * bindings in B are non added in C
     * 
     * @param A -
     *            the first automaton
     * @param B -
     *            the second automaton
     * @return AxB
     */
    static public TreeAutomaton product(final TreeAutomaton A, final TreeAutomaton B) {
        if (A == null || B == null) return null;
        Map<Object,TreeAutomaton> productMap = new TreeMap<Object,TreeAutomaton>();
        TreeAutomaton AxB = new TreeAutomaton();
        TreeAutomaton.product(TreeAutomaton.addProductStates(AxB, A, B), A, B, productMap);
        AxB.removeEpsilonTransitions();
        AxB.removeUselessStates();
        return AxB;
    }

    static private TreeAutomaton addProductStates(TreeAutomaton AxB, final TreeAutomaton A, final TreeAutomaton B) {
        Iterator<TAState> i = A.getStates().iterator();
        while (i.hasNext()) {
            TAState sa =  i.next();
            Iterator<TAState> j = B.getStates().iterator();
            while (j.hasNext()) {
                TAState sb = j.next();
                boolean isFinal = sb.isFinal && sa.isFinal;
                boolean isInitial = sb.isInitial && sa.isInitial;
                TAState sab = new TAState(isFinal, isInitial);
                sab.fst = sa;
                sab.snd = sb;
                AxB.addState(sab);
            }
        }
        return AxB;
    }

    static private TreeAutomaton product(TreeAutomaton AxB, final TreeAutomaton A, final TreeAutomaton B,
            Map<Object, TreeAutomaton> productTable) {
        //Building the set of state of AxB: they are pair where the first state
        // is in A
        //and the second is in B. The state is initial if both (fst,snd) are
        // initial. The state
        //is final if both (fst,snd) are final.
        class Key implements Comparable {
            TreeAutomaton A;

            TreeAutomaton B;

            Key(TreeAutomaton A, TreeAutomaton B) {
                this.A = A;
                this.B = B;
            }

            public String toString() {
                return A.id + " " + B.id;
            }

            public boolean equals(Object o) {
                return ((o instanceof Key) && ((Key) o).A.equals(A) && ((Key) o).B.equals(B));
            }

            public int compareTo(Object o) {
                if (o instanceof Key) {
                    Key key = (Key) o;
                    if (key.A.id < A.id || key.B.id < B.id) return -1;
                    else if ((key.A.id == A.id && key.B.id == B.id) || (key.A.id == B.id && key.A.id == B.id)) return 0;
                    else return 1;
                }
                throw new ClassCastException();
            }
        }
        productTable.put(new Key(A, B), AxB);
        //Building the transition set
        Iterator<TAState> i = AxB.getStates().iterator();
        while (i.hasNext()) {
            TAState state = i.next();
            Iterator<MatchingTransition> ja = state.fst.transitions.iterator();
            while (ja.hasNext()) {
                MatchingTransition ltja = ja.next();
                Iterator<MatchingTransition> kb = state.snd.transitions.iterator();
                while (kb.hasNext()) {
                    MatchingTransition ltkb = kb.next();
                    LabelSet labelSet = LabelSet.intersect(ltkb.labels, ltja.labels);
                    if (!labelSet.matchNoValue()) {
                        Iterator<TAState> j = AxB.getStates().iterator();
                        TAState dst = null;
                        while (dst == null) {
                            TAState s =  j.next();
                            if ((s.fst.equals(ltkb.dst) && s.snd.equals(ltja.dst))
                                    || (s.snd.equals(ltkb.dst) && s.fst.equals(ltja.dst))) dst = s;
                        }
                        MatchingTransition la = null;
                        if (ltja instanceof IntTransition) la = new IntTransition(labelSet, state, dst, ltja.variables);
                        else if (ltja instanceof StringTransition) la = new StringTransition(labelSet, state, dst,
                                ltja.variables);
                        else if (ltja instanceof ChannelTransition) {
                            //<S>^o intersection <T>^o = <S+T>^o
                            //<S>^i intersection <T>^i = <S intersection T>^i
                            //<S>^io intersection <T>^io = <S intersection T>^i
                            ChannelTransition ct = (ChannelTransition) ltja;
                            ChannelTransition ctb = (ChannelTransition) ltkb;
                            int intCap = ct.intersectCapability(ctb);
                            switch (intCap) {
                            case ChannelTransition.OUT_CAPABILITY:
                                Object[] o = { ltja.content, ltkb.content };
                                la = new ChannelTransition(ChannelTransition.OUT_CAPABILITY, state, dst, TreeAutomaton
                                        .union(o), ltja.variables);
                                break;
                            case ChannelTransition.IN_CAPABILITY:
                                TreeAutomaton content = productTable.get(new Key(ltja.content, ltkb.content));
                                if (content == null) {
                                    TreeAutomaton caxcb = new TreeAutomaton();
                                    TreeAutomaton.addProductStates(caxcb, ltja.content, ltkb.content);
                                    content = TreeAutomaton.product(caxcb, ltja.content, ltkb.content, productTable);
                                }
                                la = new ChannelTransition(ChannelTransition.IN_CAPABILITY, state, dst, content,
                                        ltja.variables);
                                break;
                            case ChannelTransition.IO_CAPABILITY:
							case ChannelTransition.NO_CAPABILITY:
                                if ((StaticAnalyzer.isSubtype(ct.content, ctb.content) && (StaticAnalyzer.isSubtype(
                                        ct.content, ctb.content)))) la = new ChannelTransition(
                                        ChannelTransition.IO_CAPABILITY, state, dst, ct.content, ct.variables);
                                else continue;
                                break;
                            }

                        } else if (ltja instanceof LabelledTransition) {
                            TreeAutomaton content = (TreeAutomaton) productTable
                                    .get(new Key(ltja.content, ltkb.content));
                            if (content == null) {
                                TreeAutomaton caxcb = new TreeAutomaton();
                                TreeAutomaton.addProductStates(caxcb, ltja.content, ltkb.content);
                                content = TreeAutomaton.product(caxcb, ltja.content, ltkb.content, productTable);
                            }
                            la = new LabelledTransition(labelSet, state, dst, content, ltja.variables);
                        } else throw new RuntimeException("Unexpected transition type");
                        AxB.addTransition(la);
                    }
                }
            }
        }
        return AxB;
    }

    /*-------------------------------------------------------------------------------------------------------------*/
    /* Difference alghorithm: methods (The algorithm is exponential) */
    /*-------------------------------------------------------------------------------------------------------------*/
    /**
     * Computes the difference between the passed automaton
     * 
     * @param A
     *            the first automaton
     * @param B
     *            the second automaton
     * @return a new automaton which represent A\B
     */
    public static TreeAutomaton difference(TreeAutomaton A, TreeAutomaton B) {
        TreeAutomaton ta = TreeAutomaton.difference(A, B, new TreeMap<Object,TreeAutomaton>());
        ta.removeUselessStates();
        return ta;
    }

    private static TreeAutomaton difference(TreeAutomaton A, TreeAutomaton B, Map<Object,TreeAutomaton> diffsTable) {
        return difference(new TreeAutomaton(), A, B, diffsTable);
    }

    private static TreeAutomaton difference(TreeAutomaton AminusB, TreeAutomaton A, TreeAutomaton B, Map<Object,TreeAutomaton> diffsTable) {
        //Intial states of AminusB are as much as those of first automaton and
        // are built in
        //the following way: each initial state is a new state where the
        // diffState field has at
        //position 0 the initial state of A and at the other positions the list
        // of initial states of
        //the second automaton. The state is final only if is final in the
        // first automaton and
        //is there are not any final state in the second automaton.
        Collection<TAState> initStatesOfB = B.getInitialStates();
        boolean isFinal = false;
        //checking if exists a final state in initStatesOfB
        Iterator<TAState> i = initStatesOfB.iterator();
        while (i.hasNext()) {
            if (i.next().isFinal) isFinal = true;
        }
        i = A.getInitialStates().iterator();
        Vector<TAState> state2process = new Vector<TAState>(A.getInitialStates().size());
        while (i.hasNext()) {
            TAState stateOfA = (TAState) i.next();
            // create the subset state that collects states of second automaton
            TAState s = new TAState(stateOfA.isFinal && !isFinal, true);
            s.diffStates = new TAState[initStatesOfB.size() + 1];
            s.diffStates[0] = stateOfA;
            s.diffStatesIsFinal = isFinal;
            Iterator<TAState> j = initStatesOfB.iterator();
            for (int k = 0; k < initStatesOfB.size(); k++)
                s.diffStates[k + 1] = (TAState) j.next();
            AminusB.addState(s);
            state2process.add(s);
        }
        // Then iterate adding transitions and the other states
        while (!state2process.isEmpty()) {
            state2process.addAll(TreeAutomaton.processState(AminusB, (TAState) state2process.get(0), diffsTable));
            state2process.removeElementAt(0);
        }
        return AminusB;
    }

    private static Vector<TAState> processState(TreeAutomaton AminusB, TAState s, Map<Object,TreeAutomaton> diffsTable) {
        Vector<TAState> newStates = new Vector<TAState>();
        // build the list of transitions exiting from the difference states
        TransitionsList<MatchingTransition> t = new TransitionsList<MatchingTransition>();
        for (int i = 1; i < s.diffStates.length; i++) {
            Iterator<MatchingTransition> j = s.diffStates[i].transitions.iterator();
            while (j.hasNext()) {
                t.add(j.next());
            }
        }
        TransitionsList<MatchingTransition> srcTransitions = TransitionsList.normalizeLabels(s.diffStates[0].transitions, t);
        // now loops through transitions
        Iterator<MatchingTransition> i = srcTransitions.iterator();
        while (i.hasNext()) {
            MatchingTransition t1 = (MatchingTransition) i.next();
            // build the list of transitions label-matching with t1
            Vector<MatchingTransition> tList = new Vector<MatchingTransition>();
            Iterator<MatchingTransition> j = t.iterator();
            while (j.hasNext()) {
                MatchingTransition t2 = j.next();
                if (!LabelSet.intersect(t2.labels, t1.labels).matchNoValue()) tList.add(t2);
            }
            newStates.addAll(processMatchingTransitions(AminusB, t1, tList, s, diffsTable));
        }
        return newStates;
    }

    private static TAState createDifferenceState(TAState state, HashSet<TAState> diffStates) {
        TAState destState = new TAState(state.isFinal, false);
        destState.diffStates = new TAState[diffStates.size() + 1];
        destState.diffStates[0] = state;
        Iterator<TAState> i = diffStates.iterator();
        for (int k = 1; k < diffStates.size() + 1; k++) {
            destState.diffStates[k] = i.next();
            if (destState.diffStates[k].isFinal) destState.isFinal = false;
        }
        return destState;
    }

    /**
     * <p>
     * Implements the PARTITIONING algorithm or equivalently the REC rule of the
     * old subtyping algorithm you can find in PhD thesis of Hosoya.
     * </p>
     * <p>
     * Also if it resembles to the subset construction and it has less or more
     * the same role that subset construction algorithm has in the standard
     * string automata theory the two algorithms are significatively different
     * (see class documentation to know more).
     * </p>
     * 
     * @param t1
     *            the list of transitions that exit from s1 (where srcState =
     *            &lt;s1,sList&gt;)
     * @param tList
     *            the list of transitions that exit from states in sList (where
     *            srcState = &lt;s1,sList&gt;)
     * @param srcState
     *            the source difference state to process
     */
    private static Collection<TAState> processMatchingTransitions(TreeAutomaton AminusB, MatchingTransition t1,
            Vector<MatchingTransition> tList, TAState srcState, Map<Object,TreeAutomaton> diffsTable) {
        Collection<TAState> newStates = new Vector<TAState>();
        if (t1 instanceof IntTransition || t1 instanceof StringTransition) {
            HashSet<TAState> diffStates = new HashSet<TAState>(); // set of (destination) states
            for (int c = 0; c < tList.size(); c++) {
                MatchingTransition lt = tList.elementAt(c);
                diffStates.add(lt.dst);
            }
            TAState destState = getState(AminusB, t1.dst, diffStates);
            if (destState == null) {
                destState = createDifferenceState(t1.dst, diffStates);
                AminusB.addState(destState);
                newStates.add(destState);
            }
            MatchingTransition newT;
            if (t1 instanceof IntTransition) newT = new IntTransition(new LabelSet(t1.labels), srcState, destState,
                    new int[0]);
            else newT = new StringTransition(new LabelSet(t1.labels), srcState, destState, new int[0]);
            AminusB.addTransition(newT);
        } else if (t1 instanceof ChannelTransition) {
            /*
             * Given n = tList.size() we need to build 2**n new transitions that
             * will start from srcState and will go into 2**n distinct (possibly
             * new) states, all with "l" as label.
             */
            int n = tList.size();
            int subsetNum = 1 << n;
            /*
             * loop through the first 2**n naturals (c stands for counter). c is
             * used both as counter and as subset specifier of tList: the first
             * n digits of the counter represent the elements of tList (1 is in
             * the subset, 0 is not). For each loop of this cycle we create a
             * new transition and possibly a new state
             */
            for (int c = 0; c < subsetNum; c++) {
                Set<ChannelTransition> diffTransitions = new HashSet<ChannelTransition>(); // set of transitions
                HashSet<TAState> diffStates = new HashSet<TAState>(); // set of destination states
                for (int i = 0; i < n; i++) {
                    int bitmask = 1 << i;
                    ChannelTransition ct = (ChannelTransition) tList.elementAt(i);
                    if ((c & bitmask) != 0) diffStates.add(ct.dst);
                    else diffTransitions.add(ct);
                }
                TAState destState = getState(AminusB, t1.dst, diffStates);
                if (destState == null) {
                    destState = createDifferenceState(t1.dst, diffStates);
                    AminusB.addState(destState);
                    newStates.add(destState);
                }
                int capability = ((ChannelTransition) t1).getCapability();
                ChannelTransition newT = new ChannelTransition(capability, srcState, destState, t1.content,
                        diffTransitions, new int[0]);
                AminusB.addTransition(newT);
            }
        } else if (t1 instanceof LabelledTransition) {
            /*
             * Given n = tList.size() we need to build 2**n new transitions that
             * will start from srcState and will go into 2**n distinct (possibly
             * new) states, all with "l" as label.
             */
            int n = tList.size();
            int subsetNum = 1 << n;
            /*
             * loop through the first 2**n naturals (c stands for counter). c is
             * used both as counter and as subset specifier of tList: the first
             * n digits of the counter represent the elements of tList (1 is in
             * the subset, 0 is not). For each loop of this cycle we create a
             * new transition and possibly a new state
             */
            for (int c = 0; c < subsetNum; c++) {
                HashSet<TreeAutomaton> diffTrees = new HashSet<TreeAutomaton>(); // set of automata
                HashSet<TAState> diffStates = new HashSet<TAState>(); // set of destination states
                LabelSet l = new LabelSet(t1.labels);
                for (int i = 0; i < n; i++) {
                    int bitmask = 1 << i;
                    MatchingTransition lt = tList.elementAt(i);
                    if ((c & bitmask) != 0) diffStates.add(lt.dst);
                    else diffTrees.add(lt.content);
                }
                TAState destState = getState(AminusB, t1.dst, diffStates);
                if (destState == null) {
                    destState = createDifferenceState(t1.dst, diffStates);
                    AminusB.addState(destState);
                    newStates.add(destState);
                }
                // create the new transition discarding bindings which are
                // not important
                TreeAutomaton contentAutomaton = getContentDiffAutomaton(t1.content, diffTrees, diffsTable);
                LabelledTransition newT = new LabelledTransition(l, srcState, destState, contentAutomaton);
                AminusB.addTransition(newT);
            }
        }
        return newStates;
    }

    /** Search a state and returns the state or null if not found */
    private static TAState getState(TreeAutomaton ta, TAState fstOfDiff, Collection sList) {
        Iterator<TAState> i = ta.getStates().iterator();
        while (i.hasNext()) {
            TAState s = i.next();
            if (s.diffStates == null) continue;
            else if (s.diffStates.length == 1 && s.diffStates[0].equals(fstOfDiff) && sList.size() == 0) {
                return s;
            } else if (sList.size() != s.diffStates.length - 1) continue;
            else {
                int found = 0;
                if (s.diffStates[0].equals(fstOfDiff)) {
                    for (int j = 1; j < s.diffStates.length; j++)
                        if (sList.contains(s.diffStates[j])) found++;
                    if (found == s.diffStates.length - 1) return s;
                }
            }
        }
        return null;
    }

    private static TreeAutomaton getContentDiffAutomaton(TreeAutomaton a1, Set alNames, Map<Object, TreeAutomaton> diffsTable) {
        class Key implements Comparable {
            TreeAutomaton a1;

            Set alNames;

            Key(TreeAutomaton ta, Set diffTa) {
                this.a1 = ta;
                this.alNames = diffTa;
            }

            public boolean equals(Object o) {
                return ((o instanceof Key) && ((Key) o).a1.equals(a1) && ((Key) o).alNames.equals(alNames));
            }

            public int compareTo(Object o) {
                if (o instanceof Key) {
                    Key key = (Key) o;
                    if (key.a1.id < a1.id) return -1;
                    else if (key.a1.id > a1.id) return 1;
                    else return 0;
                }
                throw new ClassCastException();
            }
        }
        /*
         * Optimizations: 1) A \ [] = A (if A is null returns null) 2) null \
         * [..] = null 3) A \ [A] = null
         */
        if (alNames.size() == 0 || a1 == null) return a1;
        if (alNames.contains(a1)) return null;
        // search the automaton
        Key key = new Key(a1, alNames);
        TreeAutomaton contentAutomaton = diffsTable.get(key);
        if (contentAutomaton == null) {
            // if it doesn't exist create it
            TreeAutomaton a2 = TreeAutomaton.union(alNames.toArray());
            // create the difference automaton
            contentAutomaton = new TreeAutomaton();
            diffsTable.put(key, contentAutomaton);
            contentAutomaton = TreeAutomaton.difference(contentAutomaton, a1, a2, diffsTable);
        }
        return contentAutomaton;
    }

    /*-------------------------------------------------------------------------------------------------------------*/
    /* End of Difference alghorithm */
    /*-------------------------------------------------------------------------------------------------------------*/
    /*-------------------------------------------------------------------------------------------------------------*/
    /* Basic operations: end */
    /*-------------------------------------------------------------------------------------------------------------*/
    /*-------------------------------------------------------------------------------------------------------------*/
    /* Cast VNode */
    /*-------------------------------------------------------------------------------------------------------------*/
    /**
     * Casts a value to be of the type of this automaton. The difference with
     * the general matching function is that the pattern (the automaton) wins
     * against the value. This means that if the value has a basic type where
     * the automaton expects another basic type a dynamic cast is performed and
     * the value is modified.
     * 
     * @param value -
     *            the node to convert (NOTA BENE: can be modified if the pattern
     *            matches the automaton)
     * @param env -
     *            the environment where add bindings. It's not modified if the
     *            value is not matched by the pattern
     * @return true if the automaton matches the value, false otherwise
     * @throws ExistsEpsTransitionException
     *             if the automaton has epsilon transitions
     * @throws VNodeCastException
     *             if the conversion cannot be performed
     */
    public VNode castVNode(VNode value, VNode[] env, boolean inPlace) throws ExistsEpsTransitionException,
            VNodeCastException {
        VNode v = VNode.derefer(env, value);
        if (matchNodes(v, env)) {
            VNode newNode = null;
            if (!inPlace) newNode = castTree(v);
            if (inPlace) newNode = castTreeInPlace(v);
            bindAll(newNode, env);
            if (v != null) v.clearAnnotations();
            if (newNode != null) newNode.clearAnnotations();
            return newNode;
        }
        if (v == null) throw new VNodeCastException(Void.class);
        throw new VNodeCastException(value.getClass());

    }

    /**
     * Matches a value departing from the initial states. Only the structure of
     * the tree is matching then basic type are annotated for the cast performed
     * in castTree.
     * 
     * @param value -
     *            the value to match
     * @return true if the object matches the value; value is annotated with
     *         variables and casts
     */
    private boolean matchNodes(VNode value, VNode[] env) throws ExistsEpsTransitionException {
        return matchNodes(value, env, initialStates);
    }

    /**
     * Matches a value departing from a set of states
     * 
     * @return true if the object matches the value; value is annotated with
     *         variables and casts
     * @param states -
     *            the states to use as initial states
     * @param value -
     *            the value to match
     */
    private boolean matchNodes(VNode value, VNode[] env, HashSet<TAState> states) {
        if (epsTransitions.size() > 0) { throw (new ExistsEpsTransitionException(((epsTransitions
                .iterator().next())).src)); }
        for (TAState state: states){
            if (match(value, env, state, false, true)) return true;
        }
        return false;
    }

    /**
     * Values, during the pattern matching with rectricted types are annotated
     * with variables and optionally with a cast. This method converts the old
     * tree in a new one casting, where indicated, strings to channels or
     * integers. It casts the node in place without building a new node.
     * 
     * @param node
     *            the node to convert (NOTA BENE: it's converted in place)
     * @return the converted tree
     */
    private VNode castTreeInPlace(VNode node) throws VNodeCastException {
        if (node == null) return node;
        if (node instanceof Literal) {
            Literal lit = (Literal) node;
            return lit.castToType();
        }
        if (node instanceof SequenceElement) { return castTreeInPlace(((SequenceElement) node).getElementValue()); }
        if (node instanceof LabelledElement) {
            node.setChild(0, castTree(node.getChild(0)));
            return node;
        }
        if (node instanceof Sequence) {
            for (int i = 0; i < node.getChildrenNumber(); i++)
                ((Sequence) node).setChild(i, castTree(node.getChild(i)));
            return node;
        }
        return node;
    }

    /**
     * Values, during the pattern matching with rectricted types are annotated
     * with variables and optionally with a cast. This method converts the old
     * tree in a new one casting, where indicated, strings to channels or
     * integers.
     * 
     * @param node
     *            the node to convert (NOTA BENE: it's converted in place)
     * @return the converted tree
     */
    private VNode castTree(VNode node) throws VNodeCastException {
        if (node == null) return node;
        if (node instanceof Literal) {
            Literal lit = (Literal) node;
            return lit.castToType();
        }
        if (node instanceof SequenceElement) { return castTree(((SequenceElement) node).getElementValue()); }
        if (node instanceof LabelledElement) {
            LabelledElement lab = (LabelledElement) node;
            LabelledElement l = new LabelledElement(lab.tagName, castTree(lab.getChild()), lab.getBindings());
            return l;
        }
        if (node instanceof Sequence) {
            Sequence s = new Sequence();
            for (int i = 0; i < node.getChildrenNumber(); i++)
                s.addChild(castTree(node.getChild(i)));
            return s;
        }
        return node;
    }

    /**
     * Annotates the labelled element for the type conversion performed in
     * castTree (if it is possible).
     * 
     * @param el -
     *            the labelled element
     * @param t -
     *            the transition with which try to match
     * @return a state of this automaton if t match el, null otherwise
     */
    private TAState matchLabelledElementIgnBaseType(LabelledElement el, VNode[] env, MatchingTransition t) {
        if ((el instanceof Literal) && (t instanceof LabelledTransition)) return null;
        else if (t instanceof LabelledTransition) {
            if (!t.match(el)) return null;
            VNode child = el.getChild();
            if (t.content.recognizeEpsilon() && child instanceof Literal
                    && child.getValue().toString().trim().length() == 0) {
                Literal lit = (Literal) child;
                lit.bindToEmpty();
                return t.dst;
            } else if (t.content.matchNodes(el.getChild(), env)) return t.dst;
            else return null;
        } else if (el instanceof Literal) {
            Literal value = (Literal) el;
            String literal = SpecialLabels.DEL_LITERAL_PREFIX(el.tagName);
            if (t instanceof ChannelTransition) {
                //Get the wsdl
                //build the channel automaton by using the xml description of
                // its bopi type
                //check if the automaton on the transition is a subtype of the
                // automaton of the type
                //typeXML[0] defs, typeXML[1] name of this type:()
				try {
					String fileName = literal.trim();
					String[] typedefsAndType = WSDLParser.getTypeFromWSDL(fileName);
					int capability = WSDLParser.getCapabilityFromWSDL(fileName);
					Map<String, TreeAutomaton> chTypeDefs = PatternFactory.parseTypeDeclaration(typedefsAndType[0]
							.getBytes());
					TreeAutomaton chTypeTA = PatternFactory.generatePattern(chTypeDefs, typedefsAndType[1].getBytes());
					ChannelLiteral c = new ChannelLiteral(fileName, chTypeDefs, chTypeTA, capability);
					if (t.match(c)) {
						value.bindToChannel(chTypeDefs, chTypeTA, capability);
						return t.dst;
					}
				} catch (IOException e) {
					// do nothing
				} catch (SAXException s) {
					// do nothing
				}
				return null;
            } else if (t instanceof IntTransition) {
                try {
                    Integer.parseInt(literal);
                    String intLabel = SpecialLabels.INTEGER_LITERAL + literal;
                    if (t.matchAny() || t.matchLabel(intLabel)) {
                        value.bindToInteger();
                        return t.dst;
                    }
                    return null;
                } catch (NumberFormatException e) {
                    return null;
                }
            } else if (t instanceof StringTransition) {
                if (t.matchAny() || t.matchLabel(SpecialLabels.STRING_LITERAL + literal)) {
                    value.bindToString();
                    return t.dst;
                }
                return null;
            } else throw new RuntimeException("Unexpected type");
        }
        return null;
    }

    /*-------------------------------------------------------------------------------------------------------------*/
    /* Cast VNode: end */
    /*-------------------------------------------------------------------------------------------------------------*/
	static protected boolean test() {
		boolean result = true;
		if (!testEpsilonAndUseless()) {
			System.err.println("Epsilon Transitions and Useless states elimination: Error!");
			result = false;
		}
		if (!(testMatching())) {
			System.out.println("Simple match1: Error!");
			result = false;
		}
		if (!testLiteralMatching()) {
			System.err.println("Simple match2: Error!");
			result = false;
		}
		if (!testProduct()) {
			System.err.println("Product: Error!");
			result = false;
		}
		if (!testIsNull()) {
			System.err.println("IsNull: Error!");
			result = false;
		}
		if (!testDifference() || !testDifferenceFromDeclFile()) {
			System.err.println("Difference: Error!");
			result = false;
		}
		if (!testCast()) {
			System.err.println("Cast: Error!");
			result = false;
		}
		if (result)
			System.out.println("TA: TEST Ok!");
		return result;
	}

	static protected boolean testMatching() {
		/*
		 * Matching value with a simple automaton 'a': q0_i --br[()]--> q1_f
		 * q0_i --h1[()]--> q1_f q0_i --h2[()]--> q1_f
		 */
		TreeAutomaton a = new TreeAutomaton();
		TAState q0 = new TAState(false, true);
		TAState q1 = new TAState(true, false);
		a.addState(q0);
		a.addState(q1);
		LabelledTransition t = new LabelledTransition("br", q0, q1, new EpsilonTA(), (new int[0]));
		LabelledTransition t1 = new LabelledTransition("h1", q0, q1, new EpsilonTA(), (new int[0]));
		LabelledTransition t2 = new LabelledTransition("h2", q0, q1, new EpsilonTA(), (new int[0]));
		a.addTransition(t);
		a.addTransition(t1);
		a.addTransition(t2);
		LabelledElement foo = new LabelledElement("foo", null);
		LabelledElement value = new LabelledElement("h2", null);
		/* h1[h2[()]] */
		LabelledElement lTree = new LabelledElement("h1", value);
		if (a.match(foo, new VNode[0], a.initialStates)) // root cannot match
			return false;
		if (!a.match(value, new VNode[0], a.initialStates)) // must match
			return false;
		if (a.match(lTree, new VNode[0], a.initialStates)) // subtree cannot
			// match
			return false;
		if (a.isNull(new TreeSet<Assumption>())) {
			System.err.println(a + "\n cannot  be empty");
			return false;
		}
		/*
		 * Matching a sequence 's' with a sequence automaton 'b' q0_i
		 * --l0[()]--> q1_f q(j) --lj[()]--> q(j+1) q9 --h9[()]--> q10_f
		 */
		int SIZE = 10;
		TreeAutomaton b = new TreeAutomaton();
		TAState[] q = new TAState[SIZE];
		for (int i = 0; i < SIZE; i++) {
			q[i] = new TAState();
		}
		q[0].isInitial = true;
		q[SIZE - 1].isFinal = true;
		b.addAllStates(q);
		Sequence s = new Sequence();
		for (int i = 1; i < SIZE; i++) {
			/* Element and transition with bindings for the sequence automaton */
			String label = "l" + (new Integer(i)).toString();
			LabelledElement el = new LabelledElement(label, null);
			s.addChild(el);
			int[] vars = new int[i + 1];
			for (int j = 0; j <= i; j++)
				vars[j] = j;
			LabelledTransition t3 = new LabelledTransition(label, q[i - 1], q[i], new EpsilonTA(), vars);
			b.addTransition(t3);
		}
		VNode[] env = new VNode[b.getMaxBinding() + 1];
		b.matchValue(s, env);
		for (int i = 0; i < env.length; i++)
			System.out.println(i + "=" + env[i]);
		if (b.isNull(new TreeSet<Assumption>())) {
			System.err.println(b + "\n cannot  be empty");
			return false;
		}
		return true;
	}

	static protected boolean testLiteralMatching() {
		TreeAutomaton A = new TreeAutomaton();
		TAState begin = new TAState(false, true);
		TAState end = new TAState(true, false);
		A.addState(begin);
		A.addState(end);
		String wsdl = "http://127.0.0.1/~samuele/WebServices/chan1.wsdl";
		int[] var = new int[1];
		var[0] = 0;
		A.addTransition(new StringTransition(begin, end, var));
		TreeAutomaton chan1TA;
		try {
			chan1TA = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), "<pattern><int/></pattern>"
					.getBytes());
		} catch (SAXException e) {
			return false;
		} catch (IOException e) {
			return false;
		}
		A.addTransition(new ChannelTransition(ChannelTransition.OUT_CAPABILITY, begin, end, chan1TA, var));
		A.addTransition(new IntTransition(begin, end, var));
		StringLiteral sLit = new StringLiteral("hello wonderful world");
		IntLiteral iLit = new IntLiteral(100);
		ChannelLiteral cLit;
		try {
			cLit = new ChannelLiteral(wsdl, new HashMap(), chan1TA, ChannelLiteral.OUT_CAPABILITY);
		} catch (IOException e1) {
			e1.printStackTrace();
			return false;
		}
		VNode[] env = new VNode[A.getMaxBinding() + 1];
		A.matchValue(sLit, env);
		for (int i = 0; i < env.length; i++)
			System.out.println(i + "=" + env[i]);
		env = new VNode[A.getMaxBinding() + 1];
		A.matchValue(iLit, env);
		for (int i = 0; i < env.length; i++)
			System.out.println(i + "=" + env[i]);
		env = new VNode[A.getMaxBinding() + 1];
		A.matchValue(cLit, env);
		for (int i = 0; i < env.length; i++)
			System.out.println(i + "=" + env[i]);
		if (A.isNull(new TreeSet<Assumption>())) {
			System.err.println(A + "\n cannot  be empty");
			return false;
		}
		return true;
	}

	/**
	 * Tests useless states elimination and epsilon transition elimination (the
	 * automaton is the same used in Fabrizio's thesis 4.2.1)
	 * 
	 * @return true if ok, false otherwise
	 */
	static protected boolean testEpsilonAndUseless() {
		TreeAutomaton a = new TreeAutomaton(); /*
												 * q0 is initialState, q5 the
												 * final state
												 */
		TAState q0 = new TAState(false, true);
		TAState q1 = new TAState();
		TAState q2 = new TAState();
		TAState q3 = new TAState();
		TAState q4 = new TAState();
		TAState q5 = new TAState(true, false);
		a.addState(q0);
		a.addState(q1);
		a.addState(q2);
		a.addState(q3);
		a.addState(q4);
		a.addState(q5);
		int[] s = new int[0];
		LabelledTransition t = new LabelledTransition("a", q0, q1, new EpsilonTA(), s);
		LabelledTransition t1 = new LabelledTransition("b", q3, q4, new EpsilonTA(), s);
		a.addTransition(t);
		a.addTransition(t1);
		a.addTransition(new EpsTransition(q1, q2));
		a.addTransition(new EpsTransition(q2, q3));
		a.addTransition(new EpsTransition(q4, q3));
		a.addTransition(new EpsTransition(q4, q5));
		a.addTransition(new EpsTransition(q2, q5));
		a.removeEpsilonTransitions();
		if (a.epsTransitions.size() > 0)
			return false;
		if (a.states.size() != 6)
			return false;
		if (a.transitions.size() != 5)
			return false;
		if (a.initialStates.size() != 1)
			return false;
		if (!a.initialStates.contains(q0))
			return false;
		if (a.finalStates.size() != 4)
			return false;
		if (!a.finalStates.contains(q1))
			return false;
		if (!a.finalStates.contains(q2))
			return false;
		if (!a.finalStates.contains(q4))
			return false;
		if (!a.finalStates.contains(q5))
			return false;
		a.removeUselessStates();
		if (a.isNull(new TreeSet<Assumption>())) {
			System.err.println("Automaton\n" + a + "\n cannot be empty");
			return false;
		}
		/** Builds q_i-----Int-----q'_f q'----eps---q q----eps---q'* */
		TreeAutomaton a1 = new TreeAutomaton();
		TAState initS = new TAState(false, true);
		TAState finalS = new TAState(true, false);
		a1.addState(initS);
		a1.addState(finalS);
		a1.addTransition(new EpsTransition(initS, finalS));
		a1.addTransition(new EpsTransition(finalS, initS));
		a1.addTransition(new IntTransition(initS, finalS, new int[0]));
		a1.removeEpsilonTransitions();
		a1.removeUselessStates();
		if (!(a1.epsTransitions.size() == 0))
			return false;
		if (a1.isNull(new TreeSet<Assumption>())) {
			System.err.println("Automaton\n" + a1 + "\n cannot be empty");
			return false;
		}
		/** Strange situation q_i-----Int-----q'_f q'----eps---q q----eps---q'* */
		TreeAutomaton a2 = new TreeAutomaton();
		TAState initS2 = new TAState(false, true);
		TAState q = new TAState();
		TAState finalS2 = new TAState(true, false);
		a2.addState(initS2);
		a2.addState(q);
		a2.addState(finalS2);
		a2.addTransition(new EpsTransition(initS2, finalS2));
		a2.addTransition(new IntTransition(initS2, q, new int[0]));
		a2.addTransition(new StringTransition(q, finalS2, new int[0]));
		a2.addTransition(new EpsTransition(finalS2, initS2));
		a2.removeEpsilonTransitions();
		a2.removeUselessStates();
		if (!(a2.epsTransitions.size() == 0))
			return false;
		if (a2.isNull(new TreeSet<Assumption>())) {
			System.err.println("Automaton\n" + a2 + "\n cannot be empty");
			return false;
		}
		return true;
	}

	static protected boolean testProduct() {
		try {
			// a[5]xa[int]
			String p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><label type='UNION'><labelName name='a'/><intLit>   5  </intLit></label></pattern>";
			String p2 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><label type='UNION'><labelName name='a'/><int/></label></pattern>";
			TreeAutomaton taa = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			TreeAutomaton tab = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p2.getBytes());
			TreeAutomaton AxB = TreeAutomaton.product(taa, tab);
			if (AxB.matchValue(new LabelledElement("a", new IntLiteral(7)), new VNode[0]))
				return false;
			if (!AxB.matchValue(new LabelledElement("a", new IntLiteral(5)), new VNode[0]))
				return false;
			p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><choice><label type='UNION'><labelName name='a'/><intLit>5</intLit></label><label type='UNION'><labelName name='a'/><strLit>Hello</strLit></label></choice></pattern>";
			TreeAutomaton taora = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			TreeAutomaton AorAxAorA = TreeAutomaton.product(taora, taora);
			p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><bind target='1'><sequence minOccurs='0' maxOccurs='unbounded'><int/></sequence></bind><bind target='2'><sequence minOccurs='0' maxOccurs='unbounded'><int/></sequence></bind></sequence></pattern>";
			TreeAutomaton intsintints = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1
					.getBytes());
			TreeAutomaton intsininsXintsinins = TreeAutomaton.product(intsintints, intsintints);
			// a[5],String X a[Int],"hello"
			p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><label type='UNION'><labelName name='a'/><intLit>5</intLit></label><string/></sequence></pattern>";
			p2 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><label type='UNION'><labelName name='a'/><int/></label><strLit>hello</strLit></sequence></pattern>";
			TreeAutomaton taa1 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			TreeAutomaton tab1 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p2.getBytes());
			TreeAutomaton A1xB1 = TreeAutomaton.product(taa1, tab1);
			Sequence s = new Sequence();
			s.addChild(new LabelledElement("a", new IntLiteral(5)));
			s.addChild(new StringLiteral("hello"));
			if (!A1xB1.matchValue(s, new VNode[0]))
				return false;
			s.addChild(new IntLiteral(3));
			if (A1xB1.matchValue(s, new VNode[0]))
				return false;
			Sequence s1 = new Sequence();
			s1.addChild(new LabelledElement("a", new IntLiteral(5)));
			s1.addChild(new StringLiteral("world"));
			if (A1xB1.matchValue(s1, new VNode[0]))
				return false;
			p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><chan capability='o'><int/></chan><string/></sequence></pattern>";
			p2 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><chan capability='o'><string/></chan><string/></sequence></pattern>";
			TreeAutomaton c1 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			TreeAutomaton c2 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p2.getBytes());
			TreeAutomaton C1xC2 = TreeAutomaton.product(c1, c2);
			p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><chan capability='i'><int/></chan><string/></sequence></pattern>";
			p2 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><chan capability='i'><choice><string/><int/></choice></chan><string/></sequence></pattern>";
			c1 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			c2 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p2.getBytes());
			C1xC2 = TreeAutomaton.product(c1, c2);
			System.out.println("<int + string>^io,string  X  <string + int>^io,string");
			p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><chan capability='io'><choice><string/><int/></choice></chan><string/></sequence></pattern>";
			p2 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><chan capability='io'><choice><int/><string/></choice></chan><string/></sequence></pattern>";
			c1 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			c2 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p2.getBytes());
			C1xC2 = TreeAutomaton.product(c1, c2);
			if (C1xC2.isNull(new TreeSet<Assumption>()))
				return false;
			return true;
		} catch (Exception e) {
			System.err.println(e);
			e.printStackTrace();
			return false;
		}
	}

	static protected boolean testDifference() {
		try {
			System.out.println("Int \\ 5");
			String five = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><intLit>   5  </intLit></pattern>";
			String integer = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><int/></pattern>";
			TreeAutomaton i = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), integer.getBytes());
			TreeAutomaton f = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), five.getBytes());
			TreeAutomaton fminusi = TreeAutomaton.difference(i, f);
			System.out.println(fminusi);
			if (fminusi.matchValue(new IntLiteral(5), new VNode[0]))
				return false;
			if (!fminusi.matchValue(new IntLiteral(6), new VNode[0]))
				return false;
			System.out.println("Int* \\ 5*");
			String fiveS = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence minOccurs='0' maxOccurs='unbounded'><intLit>   5  </intLit></sequence></pattern>";
			String integerS = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence minOccurs='0' maxOccurs='unbounded'><int/></sequence></pattern>";
			TreeAutomaton is = PatternFactory
					.generatePattern(new HashMap<String, TreeAutomaton>(), integerS.getBytes());
			TreeAutomaton fs = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), fiveS.getBytes());
			TreeAutomaton fsminusis = TreeAutomaton.difference(is, fs);
			System.out.println(fsminusis);
			if (fminusi.matchValue(new IntLiteral(5), new VNode[0]))
				return false;
			if (!fminusi.matchValue(new IntLiteral(6), new VNode[0]))
				return false;
			System.out.println("======a[5] \\ a[int]======");
			String p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><label type='UNION'><labelName name='a'/><intLit>   5  </intLit></label></pattern>";
			String p2 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><label type='UNION'><labelName name='a'/><int/></label></pattern>";
			TreeAutomaton taa = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			TreeAutomaton tab = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p2.getBytes());
			System.out.println("A= \n" + taa);
			System.out.println("B= \n" + tab);
			TreeAutomaton AminusB = TreeAutomaton.difference(taa, tab);
			System.out.println("AminusB= \n" + AminusB);
			if (AminusB.matchValue(new LabelledElement("a", new IntLiteral(5)), new VNode[0]))
				return false;
			if (AminusB.matchValue(new LabelledElement("a", new IntLiteral(100)), new VNode[0]))
				return false;
			System.out.println("======a[int] \\ a[5]======");
			TreeAutomaton BminusA = TreeAutomaton.difference(tab, taa);
			System.out.println("BminusA= \n" + BminusA);
			if (BminusA.matchValue(new LabelledElement("a", new IntLiteral(5)), new VNode[0]))
				return false;
			if (!BminusA.matchValue(new LabelledElement("a", new IntLiteral(100)), new VNode[0]))
				return false;
			// a[5],String \ a[Int],"hello"
			System.out.println("======a[5],String \\ a[int], hello======");
			p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><label type='UNION'><labelName name='a'/><intLit>5</intLit></label><string/></sequence></pattern>";
			p2 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><label type='UNION'><labelName name='a'/><int/></label><strLit>hello</strLit></sequence></pattern>";
			TreeAutomaton taa1 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			TreeAutomaton tab1 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p2.getBytes());
			System.out.println("A1= \n" + taa1);
			System.out.println("B1= \n" + tab1);
			TreeAutomaton A1minusB1 = TreeAutomaton.difference(taa1, tab1);
			System.out.println("A1minusB1= \n" + A1minusB1);
			Sequence seq1 = new Sequence();
			seq1.addChild(new LabelledElement("a", new IntLiteral(5)));
			seq1.addChild(new StringLiteral("hello"));
			if (A1minusB1.matchValue(seq1, new VNode[0]))
				return false;
			Sequence seq2 = new Sequence();
			seq2.addChild(new LabelledElement("a", new IntLiteral(5)));
			seq2.addChild(new StringLiteral("world"));
			if (!A1minusB1.matchValue(seq2, new VNode[0]))
				return false;
			Sequence seq3 = new Sequence();
			seq3.addChild(new LabelledElement("a", new IntLiteral(6)));
			seq3.addChild(new StringLiteral("world"));
			if (A1minusB1.matchValue(seq3, new VNode[0]))
				return false;
			System.out.println("======a[int],hello \\ a[5], string======");
			TreeAutomaton B1minusA1 = TreeAutomaton.difference(tab1, taa1);
			System.out.println("B1minusA1= \n" + B1minusA1);
			Sequence seq4 = new Sequence();
			seq4.addChild(new LabelledElement("a", new IntLiteral(6)));
			seq4.addChild(new StringLiteral("hello"));
			if (!B1minusA1.matchValue(seq4, new VNode[0]))
				return false;
			Sequence seq5 = new Sequence();
			seq5.addChild(new LabelledElement("a", new IntLiteral(6)));
			seq5.addChild(new StringLiteral("world"));
			if (B1minusA1.matchValue(seq5, new VNode[0]))
				return false;
			Sequence seq6 = new Sequence();
			seq6.addChild(new LabelledElement("a", new IntLiteral(5)));
			seq6.addChild(new StringLiteral("world"));
			if (B1minusA1.matchValue(seq6, new VNode[0]))
				return false;
			System.out.println("======a[int],b[string] \\ a[5],b[hello]======");
			p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><label type='UNION'><labelName name='a'/><int/></label><label type='UNION'><labelName name='b'/><string/></label></sequence></pattern>";
			p2 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><label type='UNION'><labelName name='a'/><intLit>5</intLit></label><label type='UNION'><labelName name='b'/><strLit>hello</strLit></label></sequence></pattern>";
			taa1 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			tab1 = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p2.getBytes());
			B1minusA1 = TreeAutomaton.difference(taa1, tab1);
			System.out.println("B1minusA1= \n" + B1minusA1);
			Sequence seq7 = new Sequence();
			seq7.addChild(new LabelledElement("a", new IntLiteral(6)));
			seq7.addChild(new LabelledElement("b", new StringLiteral("hello")));
			if (!B1minusA1.matchValue(seq7, new VNode[0]))
				return false;
			Sequence seq8 = new Sequence();
			seq8.addChild(new LabelledElement("a", new IntLiteral(5)));
			seq8.addChild(new LabelledElement("b", new StringLiteral("world")));
			if (!B1minusA1.matchValue(seq8, new VNode[0]))
				return false;
			Sequence seq9 = new Sequence();
			seq9.addChild(new LabelledElement("a", new IntLiteral(5)));
			seq9.addChild(new LabelledElement("b", new StringLiteral("hello")));
			if (B1minusA1.matchValue(seq9, new VNode[0]))
				return false;
			return true;
		} catch (SAXException e) {
			System.err.println(e);
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			System.err.println(e);
			e.printStackTrace();
			return false;
		}
	}

	static protected boolean testDifferenceFromDeclFile() {
		java.io.FileInputStream stream = null;
		try {
			stream = new java.io.FileInputStream("examples/typeDecl4Diff.xml");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		byte[] pbuffer = null;
		try {
			pbuffer = new byte[stream.available()];
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try {
			stream.read(pbuffer);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		Map<String, TreeAutomaton> m = null;
		try {
			m = PatternFactory.parseTypeDeclaration(pbuffer);
		} catch (SAXException e3) {
			e3.printStackTrace();
		} catch (IOException e3) {
			e3.printStackTrace();
		}
		TreeAutomaton T = m.get(new String("T"));
		TreeAutomaton T1 = m.get(new String("T'"));
		TreeAutomaton TminusT1 = TreeAutomaton.difference(T, T1);
		if (!TminusT1.isNull(new TreeSet<Assumption>()))
			return false;
		TreeAutomaton TxT1 = TreeAutomaton.product(T, T1);
		TreeAutomaton S = m.get(new String("S"));
		TreeAutomaton S1 = m.get(new String("S'"));
		TreeAutomaton SminusS1 = TreeAutomaton.difference(S, S1);
		if (!SminusS1.isNull(new TreeSet<Assumption>()))
			return false;
		TreeAutomaton SxS1 = TreeAutomaton.product(S, S1);
		TreeAutomaton U = m.get(new String("U"));
		TreeAutomaton U1 = m.get(new String("U'"));
		TreeAutomaton UminusU1 = TreeAutomaton.difference(U, U1);
		if (!UminusU1.isNull(new TreeSet<Assumption>()))
			return false;
		TreeAutomaton UxU1 = TreeAutomaton.product(U, U1);
		TreeAutomaton V = m.get(new String("V"));
		TreeAutomaton V1 = m.get(new String("V'"));
		TreeAutomaton VminusV1 = TreeAutomaton.difference(V, V1);
		TreeAutomaton Z = m.get(new String("Z"));
		TreeAutomaton Z1 = m.get(new String("Z1"));
		TreeAutomaton ZminusZ1 = TreeAutomaton.difference(Z, Z1);
		if (!ZminusZ1.isNull(new TreeSet<Assumption>()))
			return false;
		TreeAutomaton Z1minusZ = TreeAutomaton.difference(Z1, Z);
		if (Z1minusZ.isNull(new TreeSet<Assumption>()))
			return false;
		return true;
	}

	static protected boolean testIsNull() {
		TreeAutomaton ta = new TreeAutomaton();
		if (!ta.isNull(new TreeSet<Assumption>())) {
			System.err.println(ta + "\n must be empty");
			return false;
		}
		ta.RECOGNIZES_EMPTY_LANGUAGE = -1;
		TAState q0 = new TAState(false, true);
		TAState q1 = new TAState(true, false);
		ta.addState(q0);
		ta.addState(q1);
		LabelledTransition t = new LabelledTransition(new LabelSet("a"), q0, q1, ta, new int[0]);
		ta.addTransition(t);
		if (!ta.isNull(new TreeSet<Assumption>())) {
			System.err.println(ta + "\n must be empty");
			return false;
		}
		ta.RECOGNIZES_EMPTY_LANGUAGE = -1;
		t.content = new EpsilonTA();
		if (ta.isNull(new TreeSet<Assumption>())) {
			System.err.println(ta + "\n cannot  be empty");
			return false;
		}
		return true;
	}

	static protected boolean testCast() {
		try {
			String xml = "<value xmlns='" + VNodeDefaultHandler.VNODE_NAMESPACE
					+ "'><a>5</a><b>http://127.0.0.1/~samuele/WebServices/chan0.wsdl</b></value>";
			VNode node = VNodeFactory.generateVNode(xml.getBytes());
			String p1 = "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><label type='UNION'><labelName name='a'/><int/></label><label type='UNION'><labelName name='b'/><chan capability='o'><int/></chan></label></sequence></pattern>";
			TreeAutomaton ta = PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), p1.getBytes());
			VNode[] env = new VNode[0];
			VNode node2 = ta.castVNode(node, env, false);
			System.out.println(node2);
			String xml2 = "<value xmlns='" + VNodeDefaultHandler.VNODE_NAMESPACE + "'><a>5</a><b>99</b><c/></value>";
			node = VNodeFactory.generateVNode(xml2.getBytes());
			try {
				node2 = ta.castVNode(node, env, false);
				return false;
			} catch (VNodeCastException e) {
				// do nothing
			}
			return true;
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
	}

	/*-------------------------------------------------------------------------------------------------------------*/
	/* Testing methods Ends */
	/*-------------------------------------------------------------------------------------------------------------*/

    /*-------------------------------------------------------------------------------------------------------------*/
    /* Automaton to Bopi Regular Type: begin */
    /*-------------------------------------------------------------------------------------------------------------*/

    /** Epsilon schema */
    private final String VOID = "void";

    /** Empty schema */
    private final String EMPTY = "empty";

    /**
     * Calculate a string with the defition of regular expression type of this
     * automaton
     * 
     * @return a string with the definition of all the types in the automaton
     */
    public String toRegExType() {
        Set<TreeAutomaton> subAutoma = getDescendantAutomata(new HashSet<TreeAutomaton>());
        return idSostitution(toRegExType(subAutoma));
    }

    /**
     * Calculate a string with the defition of the regular expression type of
     * this automaton and recursively on his child
     * 
     * @param childs
     *            a set that contains the list of the automa linked to automaton
     *            which call this method
     * @return a string with the definition of all the types in the automaton
     */
    private String toRegExType(Set<TreeAutomaton> childs) {
        String schema = EMPTY;
        String s = EMPTY;
        if ((this.getInitialStates().isEmpty()) || (this.getFinalStates().isEmpty()) || (this.isNull(new TreeSet<Assumption>()))) {
            schema = EMPTY;
        } else {
            for (TAState qi : getInitialStates()) {
                for (TAState qf : getFinalStates()) {
                    Collection<TAState> statesSet = this.getStates();
                    s = path2type(statesSet, qi, qf);
                    if (!s.equals("")) schema = unionPath(schema, s);
                    else schema = s;
                }
            }
        }
        String def = "S" + this.id + "=  " + schema + ";";

        if (!childs.isEmpty()) {
            for (TreeAutomaton childautoma : childs) {
                if (!this.equals(childautoma)) {
                    String childString = childautoma.toRegExType(new HashSet<TreeAutomaton>());
                    def += "\n" + childString;
                }
            }
        }
        return def;
    }

    /**
     * Calculate all the possible paths between stateinit and statefin crossing
     * among {states}
     * 
     * @param states
     *            a set of states where paths walk through
     * @param stateinit
     *            the state where begin all paths
     * @param statefin
     *            the ending states of paths
     * @return a string with the rappresentation of the path in a regular
     *         expression type
     */
    private String path2type(Collection<TAState> states, TAState stateinit, TAState statefin) {
        Collection<TAState> statesCollection = new Vector<TAState>(states);
        if (!statesCollection.isEmpty()) {
            /* Select the first state to become separator */
            Iterator<TAState> it = statesCollection.iterator();
            TAState separator = it.next();
            //TAState separator = selectSeparator(statesCollection);
            it.remove();

            /*
             * Merger with optimization for empty S=s1+s2,s3*,s4
             */
            boolean isEmpty = false;
            String s3 = "";
            String s3star = EMPTY;
            String s4 = "";
            String s2s3stars4 = "";

            String s2 = path2type(statesCollection, stateinit, separator);
            if (s2.equals(EMPTY)) isEmpty = true;
            if (!isEmpty) {
                s4 = path2type(statesCollection, separator, statefin);
                if (s4.equals(EMPTY)) isEmpty = true;
            }
            if (!isEmpty) {
                s3 = path2type(statesCollection, separator, separator);
                s3star = starPath(s3);
                if (s3star.equals(EMPTY)) return "errore";
                s2s3stars4 = concatPath(concatPath(s2, s3star), s4);
            } else s2s3stars4 = EMPTY;

            String s1 = path2type(statesCollection, stateinit, statefin);

            if (s1.equals(EMPTY)) return s2s3stars4;
            else {
                /* Optimazation for void */
                if (s2.equals(s3) && s1.equals(s4)) // a+b,b*,a --> b*,a
                return concatPath(s3star, s1);
                else if (s4.equals(s3) && s1.equals(s2)) // a+a,b*,b --> a,b*
                return concatPath(s1, s3star);
                else return unionPath(s1, s2s3stars4);
            }
        } else {
            boolean exTrans = existTransition(stateinit, statefin);
            if ((!exTrans) && (stateinit.equals(statefin))) return VOID;
            else if ((!exTrans) && (!stateinit.equals(statefin))) return EMPTY;
            else {
                Set<MatchingTransition> transSet = getTransition(stateinit, statefin);
                Iterator<MatchingTransition> it = transSet.iterator();
                String transString = "";
                String transList = "";
                for (MatchingTransition tr : transSet) {
                    if (tr instanceof ChannelTransition) {
                        ChannelTransition chTr = (ChannelTransition) tr;
                        String cap = "";
                        if (chTr.hasInputCapability() && chTr.hasOutputCapability()) cap = "^io";
                        else if (chTr.hasInputCapability()) cap = "^i";
                        else if (chTr.hasOutputCapability()) cap = "^o";
                        transString = "<S" + tr.content.getID() + ">" + cap;
                        if (!chTr.diffTransitions.isEmpty()) {
                            transString += "\\";
                            Iterator<ChannelTransition> j = chTr.diffTransitions.iterator();
                            while (j.hasNext()) {
                                ChannelTransition t = j.next();
                                if (t.hasInputCapability() && chTr.hasOutputCapability()) cap = "^io";
                                else if (t.hasInputCapability()) cap = "^i";
                                else if (t.hasOutputCapability()) cap = "^o";
                                transString += "<S" + t.content.getID() + ">" + cap;
                                if (j.hasNext()) transString += "+";
                            }
                        }
                    } else if (tr instanceof LabelledTransition) {
                        if (tr.labels.toString().equals("~") || tr.labels.toString().matches("^[a-z].*")) {
                            if (tr.content == null) transString = "";
                            else transString = tr.labels.toString() + "[S" + tr.content.getID() + "]";
                        } else transString = "{" + cleanBracket(tr.labels.toString()) + "}" + "[S" + tr.content.getID()
                                + "]";
                    } else if (tr instanceof IntTransition) {
                        if (tr.labels.matchAnyInteger()) {
                            transString = tr.labels.toString().replaceAll(SpecialLabels.ANY_INTEGER_PATTERN, "int");
                        } else transString = tr.labels.toString().replaceAll(SpecialLabels.INTEGER_LITERAL, "");
                    } else if (tr instanceof StringTransition) {
                        if (tr.labels.matchAnyString()) transString = tr.labels.toString().replaceAll(
                                SpecialLabels.ANY_STRING_PATTERN, "string");
                        else transString = tr.labels.toString().replaceAll(SpecialLabels.STRING_LITERAL, "");
                    } else {
                        System.err.println("TRANSITION UNKNOWN");
                    }
                    transList = transList + " +" + transString;
                }
                transList = transList.substring(2, transList.length());
                if (transSet.size() > 1) transList = "(" + transList + ")";
                transSet.clear();
                return transList;
            }
        }
    }

    /**
     * Select the state separator who have most incoming and outcoming
     * transitions
     * 
     * @param stateCollect
     *            a collection of states
     * @return the state with more transition
     */
    protected TAState selectSeparator(Collection<TAState> stateCollect) {
        Iterator<TAState> it = stateCollect.iterator();
        TAState selectState = it.next();
        int maxTotTr = selectState.transitions.size() + selectState.incomingTransitions.size();
        for (TAState currentState : stateCollect) {
            int totTr = currentState.transitions.size() + currentState.incomingTransitions.size();
            if (totTr > maxTotTr) {
                selectState = currentState;
                maxTotTr = totTr;
            }
        }
        return selectState;
    }

    /**
     * Verify if exist a transition not epsilon between the two input states
     * 
     * @param i
     *            the source state of transitions
     * @param f
     *            the destination state of transitions
     * @return true if exist a transition in the automaton, false otherwise
     */
    private boolean existTransition(TAState i, TAState f) {
        if ((i.transitions.isEmpty()) || (f.incomingTransitions.isEmpty())) return false;
        else {
            Iterator<MatchingTransition> it = i.transitions.iterator();
            boolean find = false;
            while ((it.hasNext()) && (!find)) {
                MatchingTransition t =  it.next();
                if (t.dst.equals(f)) {
                    find = true;
                }
            }
            return find;
        }
    }

    /**
     * Return a set of transitions not epsilon between the states i and f
     * 
     * @param i
     *            the source state where transition start
     * @param f
     *            the destination state where transitio end
     * @return a set of transition
     */
    private Set<MatchingTransition> getTransition(TAState i, TAState f) {
        Set<MatchingTransition> set = new HashSet<MatchingTransition>();
        if ((!i.transitions.isEmpty()) && (!f.incomingTransitions.isEmpty())) {
            for (MatchingTransition t : i.transitions) {
                if ((t instanceof MatchingTransition) && (t.dst.equals(f))) set.add(t);
            }
        }
        return set;
    }

    /**
     * Check if in the definition string of Regular Expression Types typed
     * exactly: <br/>S[Anydigit]= "definition"; <br/>there is an Id that define:
     * void , String Litteral , Integer Litteral , string , int. <br/>and
     * replace the schemaId with the schema keyword definition in all the
     * defition
     * 
     * @param s
     *            a string that contain the definition of Regular Expression
     *            Type without the simple type
     * @return a string with the simple schema semplification
     */
    private String idSostitution(String s) {
        String str = s + "\n";
        String schId = "";
        String schDef = "";
        String[] strSplit = str.split(";\n");
        if (strSplit.length == 1) return s;
        for (int i = 0; i < strSplit.length; i++) {
            if (strSplit[i].matches("S(\\d+)=(\\s*)int")) {
                schId = strSplit[i].substring(0, strSplit[i].indexOf("="));
                str = str.replaceAll(strSplit[i] + ";\n", "");
                str = str.replaceAll(schId, "int");
            }
        }
        for (int i = 0; i < strSplit.length; i++) {
            if (strSplit[i].matches("S(\\d+)=(\\s*)string")) {
                schId = strSplit[i].substring(0, strSplit[i].indexOf("="));
                str = str.replaceAll(strSplit[i] + ";\n", "");
                str = str.replaceAll(schId, "string");
            }
        }
        for (int i = 0; i < strSplit.length; i++) {
            if (strSplit[i].matches("S(\\d+)=(\\s*)(\\d+)")) {
                schId = strSplit[i].substring(0, strSplit[i].indexOf("="));
                schDef = strSplit[i].substring(strSplit[i].indexOf("=") + 1, strSplit[i].length()).trim();
                str = str.replaceAll(strSplit[i] + ";\n", "");
                str = str.replaceAll(schId, schDef);
            }
        }
        for (int i = 0; i < strSplit.length; i++) {
            if (strSplit[i].matches("S(\\d+)=(\\s*)\"(.*)\"")) {
                schId = strSplit[i].substring(0, strSplit[i].indexOf("="));
                schDef = strSplit[i].substring(strSplit[i].indexOf("=") + 1, strSplit[i].length()).trim();
                str = str.replaceAll(strSplit[i] + ";\n", "");
                str = str.replaceAll(schId, schDef);
            }
        }
        for (int i = 0; i < strSplit.length; i++) {
            if (strSplit[i].matches("S(\\d+)=(\\s*)" + VOID)) {
                schId = strSplit[i].substring(0, strSplit[i].indexOf("="));
                str = str.replaceAll(strSplit[i] + ";\n", "");
                str = str.replaceAll("\\[" + schId + "\\]", "[]");
                str = str.replaceAll("<" + schId + ">", "<" + VOID + ">");
            }
        }
        if (str.endsWith("\n")) str = str.substring(0, str.length() - "\n".length());
        return str;
    }

    /*-------------------------------------------------------------------------------------------------------------*/
    /* Regular Expression Operations (union,concatenation,kleeneclosure): begin */
    /*-------------------------------------------------------------------------------------------------------------*/

    /*
     * Implements the regular expressions operation using semplification for the
     * types empty and epsilon
     */

    /**
     * Return the regular expression formed by the union of regEx s1 and regEx
     * s2
     * 
     * 
     * @param s1
     *            a string that rappresent a regular expression
     * @param s2
     *            a string that rappresent a regular expression
     * @return a string with the union: s1+s2
     */
    private String unionPath(String s1, String s2) {
        if (s1.equals(EMPTY)) return s2;
        else if (s2.equals(EMPTY)) return s1;
        else if (s1.equals(s2)) return s1;

        return "(" + s1 + " + " + s2 + ")";
    }

    /**
     * Return the regular expression formed by the concatenation of regEx s1 and
     * regEx s2
     * 
     * @param s1
     *            a string that rappresent a regular expression
     * @param s2
     *            a string that rappresent a regular expression
     * @return a string with the union: s1,s2
     */
    private String concatPath(String s1, String s2) {
        if ((s1.equals(EMPTY)) || (s2.equals(EMPTY))) return EMPTY;
        else if (s1.equals(VOID)) return s2;
        else if (s2.equals(VOID)) return s1;

        return s1 + "," + s2;
    }

    /**
     * Return the regular expression formed by the Kleene Closure of regEx s1
     * 
     * @param s1
     *            a string that rappresent a regular expression
     * @return a string with the star operation: s1*
     */
    private String starPath(String s1) {
        if ((s1.equals(EMPTY)) || (s1.equals(VOID))) return VOID;
        if (isBasicType(s1)) return s1 + "*";

        return "(" + cleanBracket(s1) + ")*";

    }

    /**
     * Verify if the string is a BoPi basic schema
     * 
     * @param s
     *            a string with the BoPiSchema
     */
    private boolean isBasicType(String s) {
        return (s.equals("int") || s.equals("string") || isMarkedType(s, '{', "]") || isMarkedType(s, '<', ">")
                || isMarkedType(s, '<', "^o") || isMarkedType(s, '<', "^i") || isMarkedType(s, '<', "^io")
                || isMarkedType(s, '"', "\"") || s.matches("(\\d)*"));
    }

    private boolean isMarkedType(String type, char begin, String end) {
        String s = type;
        if (s.startsWith(String.valueOf(begin)) && s.endsWith(String.valueOf(end))) {
            String content = s.substring(1, s.length() - end.length());
            int indexBegin = content.indexOf(begin);
            int indexEnd = content.indexOf(end);
            if ((indexBegin == -1) && (indexEnd == -1)) return true;
        }
        return false;
    }

    /**
     * clean a regular expression type from the brakets
     * 
     * @param str
     *            a string that rappresent a regular expression type
     * @return a string that the content without brackets
     */
    protected String cleanBracket(String str) {
        String s = str;
        if (s.startsWith("(") && s.endsWith(")")) {
            String content = s.substring(1, s.length() - 1);
            int indexBegin = content.indexOf('(');
            int indexEnd = content.indexOf(')');
            if (indexBegin == -1) // no brackets in the content
            return content;
            else if (indexBegin < indexEnd) // no brackets at the same level
            return content;
        }
        return s;
    }

    /*-------------------------------------------------------------------------------------------------------------*/
    /* Regular Expression Operations: end */
    /*-------------------------------------------------------------------------------------------------------------*/

    /*-------------------------------------------------------------------------------------------------------------*/
    /* Automaton to Bopi Regular Type: end */
    /*-------------------------------------------------------------------------------------------------------------*/
}
