/*
 * TransitionExceptions.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 28, 2004
 */
package bopi.ta;

/**
 * A transition is invalid when the either source or destination state does not
 * exist
 * 
 * @author Samuele Carpineti
 */
class TransitionExceptions extends RuntimeException {
	private static final long serialVersionUID = 3906933361296619316L;
	TAState state;

    TransitionExceptions(TAState state) {
        this.state = state;
    }

    TransitionExceptions() {
        //do nothing
    }

    public String toString() {
        if (state != null) return "Invalid epsilon transition "
                + state.toString();
        return super.toString();
    }
}
/**
 * This exception is used when exists an unexpected epsilon transition
 * 
 * @author Samuele Carpineti
 */

class ExistsEpsTransitionException extends RuntimeException {
	private static final long serialVersionUID = 3690480208012784184L;
	private TAState state;

    ExistsEpsTransitionException(TAState state) {
        this.state = state;
    }

    public String toString() {
        return state.toString();
    }
}