/*
 * Created on May 19, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.ta;

//In order to verify channels differences assumption must be used. The
// solution adopted uses a static field for storing assumptions.
//This solution is temporary but because of the weakness of the approach it
// is adopted for future updates.
public class Assumption implements Comparable {
	Assumption(TreeAutomaton fst, TreeAutomaton snd) {
		this.fst = fst;
		this.snd = snd;
	}

	private TreeAutomaton fst;

	private TreeAutomaton snd;

	public String toString() {
		return fst.getID() + " " + snd.getID();
	}
	
	public boolean equals(Object o) {
		if (o instanceof Assumption) {
			Assumption a = (Assumption) o;
			return fst.equals(a.fst) && snd.equals(a.snd);
		}
		return false;
	}

	public int compareTo(Object o) {
		if (o instanceof Assumption) {
			Assumption a = (Assumption) o;
			if (fst.getID() == a.fst.getID() && snd.getID() == a.snd.getID())
				return 0;
			else if (fst.getID() >= a.fst.getID())
				return 1;
			else
				return -1;
		}
		return -1;
	}
}