/*
 * StaticAnalyzer.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Jun 29, 2004
 */
package bopi.ta;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

import org.xml.sax.SAXException;

/**
 * Implements basic operations on automata
 * 
 * @author Samuele Carpineti
 */
public class StaticAnalyzer {
    /**
     * Checks the subtyping relation between two types
     * 
     * @param T
     *            the first type
     * @param S
     *            the second type
     * @return true if T &lt S
     */
    public static boolean isSubtype(TreeAutomaton T, TreeAutomaton S) {
        return isSubtype(T,S, new TreeSet<Assumption>());
    }
	/**
     * Checks the subtyping relation between two types
     * 
     * @param T
     *            the first type
     * @param S
     *            the second type
     * @return true if T &lt S
     */
    public static boolean isSubtype(TreeAutomaton T, TreeAutomaton S, Set<Assumption> emptynessAssumption) {
        if (T == S || T.equals(S)) return true;
        //if (T.isNull(emptynessAssumption)) return true;
        TreeAutomaton TminusS = TreeAutomaton.difference(T, S);
        return TminusS.isNull(emptynessAssumption);
    }

    /**
     * Checks if a pattern is ambiguous with respect a given type. The algorithm
     * checks for weakly ambiguity in the following way: 1. patXpat = pattern X
     * pattern 2. inXpatXpat = type X patXpat 3. checks if exist a state s(s_i,
     * s_pXp (s_p, s_p')) in inXpatXpat where s_p = s_p' If the third condition
     * is not valid then there are two different pattern for the same value
     * (pattern is weakly ambiguous for the type)
     * 
     * @param inputType
     *            the input type
     * @param pattern
     *            the pattern
     * @return true if the pattern is not ambiguous, false otherwise
     */
    public static boolean isNotAmbiguous(TreeAutomaton inputType, TreeAutomaton pattern) {
        TreeAutomaton patXpat = TreeAutomaton.product(pattern, pattern);
        TreeAutomaton inXpatXpat = TreeAutomaton.product(patXpat, inputType);
        return isNotAmbiguous(inXpatXpat);
    }

    private static boolean isNotAmbiguous(TreeAutomaton inXpatXpat) {
        inXpatXpat.setVisited(true);
        Iterator<TAState> i = inXpatXpat.getStates().iterator();
        while (i.hasNext()) {
            TAState state =  i.next();
            if (!state.fst.fst.equals(state.fst.snd)) //pattern is ambiguous
                                                      // with respect the given
                                                      // type
            return false;
            Iterator<MatchingTransition> j = state.transitions.iterator();
            while (j.hasNext()) {
                TreeAutomaton ta = j.next().content;
                if (ta == null || !ta.isVisited()) continue;
                else if (!isNotAmbiguous((ta))) return false;
            }
        }
        inXpatXpat.setVisited(false);
        //pattern is not ambiguous with respect the given type
        return true;
    }

    public static boolean isNotWeaklyAmbiguous(TreeAutomaton inputType, TreeAutomaton pattern) {
        TreeAutomaton patXpat = TreeAutomaton.product(pattern, pattern);
        TreeAutomaton inXpatXpat = TreeAutomaton.product(patXpat, inputType);
        return isNotWeaklyAmbiguousInXpatXpat(inXpatXpat);
    }

    public static boolean isNotWeaklyAmbiguous(TreeAutomaton pattern) {
        TreeAutomaton patXpat = TreeAutomaton.product(pattern, pattern);
        //TODO this step should be avoided and ambiguity should be checked
        // directly on patXpat
        TreeAutomaton patXpatXpat = TreeAutomaton.product(patXpat, pattern);
        return isNotWeaklyAmbiguousInXpatXpat(patXpatXpat);
    }

    private static boolean isNotWeaklyAmbiguousInXpatXpat(TreeAutomaton inXpatXpat) {
        inXpatXpat.setVisited(true);
        Iterator<TAState> i = inXpatXpat.getStates().iterator();
        while (i.hasNext()) {
            TAState state = i.next();
            if (!state.fst.fst.equals(state.fst.snd)) { //pattern is ambiguous
                                                        // with respect the
                                                        // given type
                Iterator<MatchingTransition> k = state.incomingTransitions.iterator();
                while (k.hasNext()) {
                    Iterator<MatchingTransition> j = state.incomingTransitions.iterator();
                    MatchingTransition alt1 = k.next();
                    while (j.hasNext()) {
                        MatchingTransition alt2 = j.next();
                        if (alt1.variables.length != alt2.variables.length) return false;
                        for (int n = 0; n < alt1.variables.length; n++) {
                            boolean found = false;
                            for (int m = 0; m < alt2.variables.length; m++) {
                                if (alt1.variables[n] == alt2.variables[m]) {
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) return false;
                        }
                    }
                }
            }
            Iterator<MatchingTransition> j = state.transitions.iterator();
            while (j.hasNext()) {
                TreeAutomaton ta = j.next().content;
                if (ta == null || !ta.isVisited()) continue;
                else if (!isNotAmbiguous((ta))) return false;
            }
        }
        inXpatXpat.setVisited(false);
        //pattern is not ambiguous with respect the given type
        return true;
    }

    /**
     * Check if a pattern matches some values that belong to a given type
     * 
     * @param type
     *            the type
     * @param pattern
     *            the pattern
     * @return true if the pattern does not match any value, false if it matches
     *         some values
     */
    public static boolean isUseless(TreeAutomaton type, TreeAutomaton pattern) {
        // this check is not really necessary, usefulness is
        // checked also by the irredundancy test
        //return (a \cap p = 0);
        TreeAutomaton acapp = TreeAutomaton.product(type, pattern);
        return acapp.isNull(new TreeSet<Assumption>());
    }

    /**
     * Checks if a list of pattern is exhaustive with respect to a given type
     * 
     * @param type
     *            the type of the value that will be matched
     * @param patterns
     *            the list of patterns used for matching the value
     * @return true if the list of patterns is exhaustive, false otherwise
     */
    public static boolean isExaustive(TreeAutomaton type, TreeAutomaton[] patterns) {
        //return (p is exaustive wrt a);
        TreeAutomaton union = TreeAutomaton.union(patterns);
        TreeAutomaton diff = TreeAutomaton.difference(type, union);
        return diff.isNull(new TreeSet<Assumption>());
    }

    /**
     * Checks if there is a value that belong to the type specified
     * 
     * @param type
     *            an automatonfor the type
     * @return true if the type does not recognize any value, false otherwise
     */
    public static boolean isEmpty(TreeAutomaton type) {
        return type.isNull(new TreeSet<Assumption>());
    }

    /*-------------------------------------------------------------------------------------------------------------*/
    /* Testing methods */
    /*-------------------------------------------------------------------------------------------------------------*/
    protected static boolean test() {
        return test0000() && test000() && test00() && test0() && test1() && test2() && test3() && test4() && test5()
                && test6();
    }

    /**
     * Tests: T = P=(a* + b*)* y, b* x Ambiguity check must be true for Weak
     * Ambiguity
     */
    private static boolean test0000() {
        try {
            System.out.println("Testing T = P=(a* + b*)* y, b* x  ");
            FileInputStream stream = new FileInputStream("examples/patternDeclAmb1.xml");
            byte[] pbuffer = new byte[stream.available()];
            stream.read(pbuffer);
            TreeAutomaton pattern = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(), pbuffer);
            if (isNotWeaklyAmbiguous(pattern, pattern)) return false;
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        }
    }

    /**
     * Tests: T = P=(a* + b*)* y,b x Ambiguity check must be false for Weak
     * Ambiguity
     */
    private static boolean test000() {
        try {
            System.out.println("Testing T = (a* + b*)*,b*    P=(a* + b*)* y, b x  ");
            FileInputStream stream = new FileInputStream("examples/patternDeclNotAmb.xml");
            byte[] pbuffer = new byte[stream.available()];
            stream.read(pbuffer);
            TreeAutomaton pattern = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(), pbuffer);
            //if (isNotAmbiguous(pattern, pattern))
            //return false;
            if (!isNotWeaklyAmbiguous(pattern, pattern)) return false;
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        }
    }

    /**
     * Tests: T = (a* + b*)*,b* P=(a* + b*)*,b* x Ambiguity check must be true
     */
    private static boolean test00() {
        try {
            System.out.println("Testing T = (a* + b*)*,b*    P=(a* + b*)* y, (b* x)  ");
            FileInputStream stream = new FileInputStream("examples/typeDeclAmb.xml");
            byte[] pbuffer = new byte[stream.available()];
            stream.read(pbuffer);
            Map<String,TreeAutomaton> m = PatternFactory.parseTypeDeclaration(pbuffer);
            TreeAutomaton type = m.get(new String("T1"));
            stream = new FileInputStream("examples/patternDeclAmb.xml");
            pbuffer = new byte[stream.available()];
            stream.read(pbuffer);
            TreeAutomaton pattern = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(), pbuffer);
            if (isNotAmbiguous(type, pattern)) return false;
            if (isNotWeaklyAmbiguous(type, pattern)) return false;
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        }
    }

    /**
     * Tests: T = (a* + b*)*,b* P=(a* + b*)*,b* x Ambiguity check must be true
     */
    private static boolean test0() {
        try {
            System.out.println("Testing T = (a* + b*)*,b*    P=(a* + b*)*, (b* x)  ");
            FileInputStream stream = new FileInputStream("examples/typeDeclAmb.xml");
            byte[] pbuffer = new byte[stream.available()];
            stream.read(pbuffer);
            Map<String,TreeAutomaton> m = PatternFactory.parseTypeDeclaration(pbuffer);
            TreeAutomaton type = m.get(new String("T1"));
            stream = new FileInputStream("examples/patternDeclAmb1.xml");
            pbuffer = new byte[stream.available()];
            stream.read(pbuffer);
            TreeAutomaton pattern = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(), pbuffer);
            if (isNotAmbiguous(type, pattern)) return false;
            if (isNotWeaklyAmbiguous(type, pattern)) return false;
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        }
    }

    /**
     * Tests: T = a* P=a* Ambiguity check must be false
     */
    private static boolean test1() {
        System.out.println("Testing T = a*    P=a* ");
        TreeAutomaton pattern = new TreeAutomaton();
        TAState state = new TAState(true, true);
        pattern.addState(state);
        pattern.addTransition(new LabelledTransition("a", state, state));
        TreeAutomaton type = new TreeAutomaton();
        TAState tstate = new TAState(true, true);
        type.addState(tstate);
        type.addTransition(new LabelledTransition("a", tstate, tstate));
        if (!isNotAmbiguous(type, pattern)) return false;
        if (!isNotWeaklyAmbiguous(type, pattern)) return false;
        return true;
    }

    /**
     * Tests: T = a* P=a*a* Ambiguity check must be false only for Weak
     */
    private static boolean test2() {
        System.out.println("Testing T = a*    P=a*a* ");
        TreeAutomaton pattern = new TreeAutomaton();
        TAState state1 = new TAState(false, true);
        TAState state2 = new TAState(true, false);
        pattern.addState(state1);
        pattern.addState(state2);
        pattern.addTransition(new LabelledTransition("a", state1, state1));
        pattern.addTransition(new LabelledTransition("a", state1, state2));
        pattern.addTransition(new LabelledTransition("a", state2, state2));
        TreeAutomaton type = new TreeAutomaton();
        TAState tstate = new TAState(true, true);
        type.addState(tstate);
        type.addTransition(new LabelledTransition("a", tstate, tstate));
        if (isNotAmbiguous(type, pattern)) return false;
        if (!isNotWeaklyAmbiguous(type, pattern)) return false;
        return true;
    }

    /**
     * Tests: T = a* P=a** Ambiguity check must be false only for Weak ambiguity
     */
    private static boolean test3() {
        System.out.println("Testing T = a*    P=a** ");
        TreeAutomaton pattern = new TreeAutomaton();
        TAState state1 = new TAState(true, true);
        pattern.addState(state1);
        pattern.addTransition(new LabelledTransition("a", state1, state1));
        pattern.addTransition(new LabelledTransition("a", state1, state1));
        TreeAutomaton type = new TreeAutomaton();
        TAState tstate = new TAState(true, true);
        type.addState(tstate);
        type.addTransition(new LabelledTransition("a", tstate, tstate));
        if (isNotAmbiguous(type, pattern)) return true;
        if (!isNotWeaklyAmbiguous(type, pattern)) return false;
        return false;
    }

    /**
     * Tests: T = a P=a x| a x Ambiguity check must be true
     */
    private static boolean test4() {
        System.out.println("Testing T = a    P=a x | a x");
        TreeAutomaton pattern = new TreeAutomaton();
        TAState state1 = new TAState(false, true);
        TAState state2 = new TAState(true, false);
        TAState state3 = new TAState(true, false);
        pattern.addState(state1);
        pattern.addState(state2);
        pattern.addState(state3);
        int[] vars1 = { 1 };
        int[] vars2 = { 2 };
        pattern.addTransition(new LabelledTransition("a", state1, state2, new EpsilonTA(), vars1));
        pattern.addTransition(new LabelledTransition("a", state1, state3, new EpsilonTA(), vars2));
        TreeAutomaton type = new TreeAutomaton();
        TAState tstate1 = new TAState(false, true);
        TAState tstate2 = new TAState(true, false);
        type.addState(tstate1);
        type.addState(tstate2);
        type.addTransition(new LabelledTransition("a", tstate1, tstate2));
        if (isNotAmbiguous(type, pattern)) return false;
        if (isNotWeaklyAmbiguous(type, pattern)) return false;
        return true;
    }

    private static boolean test5() {
        System.out.println("Testing isUseless");
        try {
            TreeAutomaton type = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(),
                    "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><label type='UNION'><labelName name='a'/><int/></label></pattern>"
                            .getBytes());
            TreeAutomaton pat1 = PatternFactory
                    .generatePattern(
                            new HashMap<String,TreeAutomaton>(),
                            "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><label type='UNION'><labelName name='a'/><intLit>1</intLit></label></pattern>"
                                    .getBytes());
            TreeAutomaton pat2 = PatternFactory
                    .generatePattern(
                            new HashMap<String,TreeAutomaton>(),
                            "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><label type='UNION'><labelName name='a'/><string/></label></pattern>"
                                    .getBytes());
            TreeAutomaton pat3 = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(),
                    "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><label type='UNION'><labelName name='b'/><int/></label></pattern>"
                            .getBytes());
            TreeAutomaton pat4 = PatternFactory
                    .generatePattern(
                            new HashMap<String,TreeAutomaton>(),
                            "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><sequence><label type='UNION'><labelName name='a'/><intLit>1</intLit></label><int/></sequence></pattern>"
                                    .getBytes());
            TreeAutomaton patterns[] = { pat1, pat2, pat3, pat4 };
            if (StaticAnalyzer.isUseless(type, pat1)) return false;
            if (!StaticAnalyzer.isUseless(type, pat2)) return false;
            if (!StaticAnalyzer.isUseless(type, pat3)) return false;
            if (!StaticAnalyzer.isUseless(type, pat4)) return false;
            if (StaticAnalyzer.isExaustive(type, patterns)) return false;
            TreeAutomaton pat5 = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(),
                    "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><label type='UNION'><labelName name='a'/><int/></label></pattern>"
                            .getBytes());
            TreeAutomaton exPatterns[] = { pat1, pat2, pat3, pat4, pat5 };
            if (!StaticAnalyzer.isExaustive(type, exPatterns)) return false;
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    private static boolean test6() {
        System.out.println("Testing isSubtype");
        try {
            TreeAutomaton type = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(),
                    "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><chan><int/></chan></pattern>".getBytes());
            TreeAutomaton pat1 = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(),
                    "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><chan><intLit>5</intLit></chan></pattern>"
                            .getBytes());
            TreeAutomaton pat2 = PatternFactory.generatePattern(new HashMap<String,TreeAutomaton>(),
                    "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><chan><choice><intLit>5</intLit><int/></choice></chan></pattern>"
                            .getBytes());
            TreeAutomaton pat3 = PatternFactory
                    .generatePattern(
                            new HashMap<String,TreeAutomaton>(),
                            "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><chan><choice><intLit>5</intLit><string/></choice></chan></pattern>"
                                    .getBytes());
            TreeAutomaton pat4 = PatternFactory
                    .generatePattern(
                            new HashMap<String,TreeAutomaton>(),
                            "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'><choice><chan><intLit>5</intLit></chan><chan><int/></chan></choice></pattern>"
                                    .getBytes());
            if (!StaticAnalyzer.isSubtype(type, type)) return false;
            if (!StaticAnalyzer.isSubtype(type, pat1)) return false;
            if (StaticAnalyzer.isSubtype(pat1, type)) return false;
            if (!StaticAnalyzer.isSubtype(type, pat2)) return false;
            if (!StaticAnalyzer.isSubtype(pat2, type)) return false;
            if (StaticAnalyzer.isSubtype(type, pat3)) return false;
            if (StaticAnalyzer.isSubtype(pat3, type)) return false;
            if (!StaticAnalyzer.isSubtype(type, pat4)) return false;
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

}