/*
 * SetAlghorithms.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on May 19, 2004
 */
package bopi.ta;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
/**
 * Some trivial algorithms on sets: difference, union, intersection
 * @param <T>
 * @author Samuele Carpineti
 */
public class SetAlgorithms {
	
	/**
	 * Computes a new set C containing elements which are in both A and B (C= A \cap B)
     * @param A - the first set
     * @param B - the second set
     * @return a new set C = A \cap B
	 */
	public static <T> Set<T> intersect(final Set<T> A, final Set<? extends T> B) {
		Set<T> intersection= new HashSet<T>();
		Iterator<T> i= A.iterator();
		while (i.hasNext()) {
			T o= i.next();
			if (B.contains(o))
				intersection.add(o);
		}
		return intersection;
	}
	/**
     * Computes a new set C containing elements which are in A and not in B (C= A \ B)
     * @param A - the first set
     * @param B - the second set 
     *  @return a new set C = A \ B
     */
	public static <T> Set<T> difference(final Set<T> A, final Set<? extends T> B) {
		Set<T> set= new HashSet<T>(A);
		Iterator<T> i= set.iterator();
		while (i.hasNext()) {
			T o= i.next();
			if (B.contains(o))
				i.remove();
		}
		return set;
	}
	/**
     * Computes a new set C containing elements which are either in A or in B (C= A U B)
     * @param A - the first set
     * @param B - the second set
     * @return a new set C = A U B 
     */
	public static <T> Set<T> union(final Set<T> A, final Set<? extends T> B) {
		Set<T> set= new HashSet<T>(A);
		set.addAll(B);
		return set;
	}
}
