/*
 * LabelledTransition.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Oct 18, 2004
 */
package bopi.ta;

/**
 * This class implements a labelled transition used for recognizing XML elements.
 * @author Samuele Carpineti
 */
class LabelledTransition extends MatchingTransition {
    /**
     * Initializes a (labelled) tree-transition from a state to another.
     * 
     * @param labels
     *            the set of labels of the transition
     * @param src
     *            the source state
     * @param dst
     *            the destination state
     * @param content
     *            the automaton that recognize the content
     * @param variables
     *            the set of variables to bind in the matching
     */
    LabelledTransition(LabelSet labels, TAState src, TAState dst, TreeAutomaton content, int[] variables) {
        super(labels, src, dst, content, variables);
    }

    /**
     * Initializes a (labelled) tree-transition from a state to another. Content
     * will be empty (so it recognizes the epsilon).
     * 
     * @param label 
     *            the label of this transition
     * @param src
     *            the source state
     * @param dst
     *            the destination state
     */
    LabelledTransition(String label, TAState src, TAState dst) {
        super(new LabelSet(label), src, dst, new EpsilonTA(), new int[0]);
    }

    /**
     * Initializes a (labelled) tree-transition from a state to another.
     * 
     * @param label
     *            the label of this transition
     * @param src
     *            the source state
     * @param dst
     *            the destination state
     * @param content
     *            the automaton that recognize the content
     * @param variables
     *            transition's bindings
     */
    LabelledTransition(String label, TAState src, TAState dst, TreeAutomaton content, int[] variables) {
        super(new LabelSet(label), src, dst, content, variables);
    }

    /**
     * Initializes a (labelled) tree-transition from a state to another.
     * 
     * @param labels
     *            the set of labels of the transition
     * @param src
     *            the source state
     * @param dst
     *            the destination state
     * @param content
     *            the automaton that recognize the content
     */
    LabelledTransition(LabelSet labels, TAState src, TAState dst, TreeAutomaton content) {
        this(labels, src, dst, content, new int[0]);
    }

    public LabelledTransition duplicate(TAState src, TAState dst) {
        int[] vars = new int[variables.length];
        for (int j = 0; j < variables.length; j++) {
            vars[j] = variables[j];
        }
        return (new LabelledTransition((LabelSet) labels.clone(), src, dst, content, vars));
    }

    public boolean equals(Object o) {
        if (o.getClass().equals(this.getClass())) {
            LabelledTransition lt = (LabelledTransition) o;
            //the set of bindings is not checked because ambiguity avoids to
            // have two transition from the same state to the same state which
            // differ only
            //for the set of viariables
            if (lt.src.equals(src) && lt.dst.equals(dst) && lt.content.equals(content)
                    && LabelSet.diffIsEmpty(lt.labels, labels) && LabelSet.diffIsEmpty(labels, lt.labels)) return true;
        }
        return false;
    }
    /** 
     * @see bopi.ta.MatchingTransition#getContents()
     */
    TreeAutomaton[] getContents() {
        TreeAutomaton[] c = new TreeAutomaton[1];
        c[0]=content;
        return c;
    }
}