/*
 * EpsilonTA.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Jun 30, 2004
 */
package bopi.ta;

/**
 * An efficient implementation of the automaton for epsilon.
 * 
 * @author Samuele Carpineti
 */
class EpsilonTA extends TreeAutomaton {
    private static TAState state = new TAState(true, true);
	
    EpsilonTA() {
        super();
        addState(state);
		RECOGNIZES_EMPTY_LANGUAGE = 0;
		WITHOUT_USELESS_STATES = true;
    }

    public int getMaxBinding() {
        return 0;
    }

    /**
     * (non-Javadoc)
     * 
     * @see bopi.ta.TreeAutomaton#recognizeEpsilon()
     */
    public boolean recognizeEpsilon() {
        return true;
    }

    /**
     * (non-Javadoc)
     * 
     * @see java.lang.Object#clone()
     */
    public Object clone() {
        return this;
    }
}