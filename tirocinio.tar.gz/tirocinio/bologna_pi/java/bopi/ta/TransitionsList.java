/*
 * TransitionList.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 27, 2004
 */
package bopi.ta;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;
/**
 * A list of transitions.
 * @author Samuele Carpineti
 */
class TransitionsList<T extends Transition> extends HashSet<T> {
	
	private static final long serialVersionUID = 3257569494657152822L;
	/**
	 * For optimization purposes.  Removes useless transitions 
	 * with empty labels or empty content.
	 */
	void removeEmpty() {
		Iterator<T> i= this.iterator();
		while (i.hasNext()) {
			Transition t= (Transition) i.next();
			if (t instanceof LabelledTransition) {
				LabelledTransition lt= (LabelledTransition) t;
				if (lt.hasEmptyLabel())
					i.remove();
				else if (lt.content != null && lt.content.getFinalStates().isEmpty())
					i.remove();
				else if (lt.content != null && lt.content.RECOGNIZES_EMPTY_LANGUAGE == 1)
					i.remove();
			}
		}
	}
	/**
	 * Returns a new transition list by mapping an old source state in a new source state
	 * @param oldSrc the old source state
	 * @param newSrc the new source state
	 * @return a new transition list
	 */
	TransitionsList<T> duplicateAndMap(TAState oldSrc, TAState newSrc) {
		TransitionsList<T> tl= new TransitionsList<T>();
		Iterator<T> j= this.iterator();
		while (j.hasNext()) {
			T t= j.next();
			if (t.src.equals(oldSrc)) {
				Transition dup= t.duplicate(newSrc, t.dst);
				tl.add((T)dup);
			}
		}
		return tl;
	}
	/**
	 * Maps an old source state in a new source state in this list of transitions  
	 * @param oldSrc the old source state
	 * @param newSrc the new source state
	 */
	TransitionsList map(TAState oldSrc, TAState newSrc) {
		Iterator<T> j= this.iterator();
		while (j.hasNext()) {
			T t= j.next();
			if (t.src.equals(oldSrc))
				t.src= newSrc;
		}
		return this;
	}
	/**
	* Returns a string representation of this list
	* @return a string representation of this list
	*/
	public String toString() {
		TreeSet<Transition> t= new TreeSet<Transition>(this);
		return t.toString();
	}
	/**
	 * Given a set of transitions T and a set of transition to subtract D builds a new set of transitions S equivalent to the first one 
	 * (it recognizes the same language) but with the following property: 
	 * For every pair (t,t') where t \in S and t' \in D label(t)\cap label(t') = label(t) or \emptyset.
	 * -unions are splitted:       a|b[T] / T' = a[T] + b[T] / T' 
	 * -any labels are splitted:  ~[T] / (a0[T0]+...+an[Tn]) = a0[T]+...+an[T] + ~/a0...an[T]  / a0[T0]+...+an[Tn]
	 * -any labels in diffTransition are concretized:     a[T] / a0[T0]+...+an[Tn] + ~[T'] = a[T] / a0[T0]+...+an[Tn] + a[T']
	 * @param sourceTransitions - the first set of transition T
	 * @param diffTransitions - the set of transition D to subtract
	 * @return the set of normalized labels  
	 */
	static TransitionsList<MatchingTransition> normalizeLabels(TransitionsList<MatchingTransition> sourceTransitions, TransitionsList<MatchingTransition> diffTransitions) {
		TransitionsList<MatchingTransition> tList= new TransitionsList<MatchingTransition>();
		Iterator<MatchingTransition> i= sourceTransitions.iterator();
		while (i.hasNext()) {
			MatchingTransition t= i.next();
			if (t instanceof ChannelTransition) {
			    //channel transition do not need to be normalized!
				tList.add(t);
			} else {
				//a|b[T] / T' = a[T] + b[T] / T'
				if (!t.matchAny()) {
					Iterator<String> j= t.labels.iterator();
					while (j.hasNext()) {
						String label= j.next();
						MatchingTransition newT;
						//TODO check this code. it shoud be erased. 
						if (t instanceof IntTransition)
							newT= new IntTransition(label, t.src, t.dst, t.variables);
						else if (t instanceof StringTransition)
							newT= new StringTransition(label, t.src, t.dst, t.variables);
						else 
						if (t instanceof LabelledTransition)
							newT= new LabelledTransition(label, t.src, t.dst, t.content, t.variables);
						else
							throw new RuntimeException("Unexepected transition type");
						tList.add(newT);
					}
				}
				//~[T] /a0[T0]+...+an[Tn] = a0[T]+...+an[T] + (~/a0...an)[T]  / a0[T0]+...+an[Tn]
				else if (t.matchAny()) {
					Collection<String> labels= new Vector<String>();
					Iterator<MatchingTransition> j= diffTransitions.iterator();
					LabelSet diffLabelSet= new LabelSet(t.labels);
					while (j.hasNext()) {
						MatchingTransition diffT= j.next();
                        if (diffT.getClass() != t.getClass()) 
                            continue;
						if (!diffT.matchAny()) {
							Iterator<String> k= diffT.labels.iterator();
							while (k.hasNext()) {
								String label=  k.next();
								if (t.labels.contains(label))
									continue;
								MatchingTransition newT;
								if (t instanceof IntTransition)
									newT= new IntTransition(label, t.src, t.dst, t.variables);
								else if (t instanceof StringTransition)
									newT= new StringTransition(label, t.src, t.dst, t.variables);
								else 
								    if (t instanceof LabelledTransition)
									newT= new LabelledTransition(label, t.src, t.dst, t.content, t.variables);
								else
									throw new RuntimeException("Unexpected transition type");
								tList.add(newT);
								labels.add(label);
							}
						} else if (diffT.matchAny()) {
							MatchingTransition newT;
							LabelSet labelsSet= LabelSet.difference(t.labels, diffT.labels);
							if (labelsSet.isEmpty())
								continue;
							if (t instanceof IntTransition)
								newT= new IntTransition(labelsSet, t.src, t.dst, t.variables);
							else if (t instanceof StringTransition)
								newT= new StringTransition(labelsSet, t.src, t.dst, t.variables);
							else if (t instanceof LabelledTransition)
								newT= new LabelledTransition(labelsSet, t.src, t.dst, t.content, t.variables);
							else
								throw new RuntimeException("Unexpected transition type");
							tList.add(newT);
						}
						diffLabelSet= LabelSet.difference(diffLabelSet, diffT.labels);
					}
					if (!diffLabelSet.matchNoValue()){
					MatchingTransition lt;
					if (t instanceof IntTransition)
						lt= new IntTransition(diffLabelSet, t.src, t.dst, t.variables);
					else if (t instanceof StringTransition)
						lt= new StringTransition(diffLabelSet, t.src, t.dst, t.variables);
					else if (t instanceof LabelledTransition)
						lt= new LabelledTransition(diffLabelSet, t.src, t.dst, t.content, t.variables);
					else
						throw new RuntimeException("Unexpected transition type");
					
					tList.add(lt);
					}
				}
			}
		}
		return tList;
	}
}
