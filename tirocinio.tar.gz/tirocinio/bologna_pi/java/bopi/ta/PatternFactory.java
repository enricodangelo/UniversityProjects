/*
 * PatternFactory.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Mar 10, 2004
 */
package bopi.ta;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.SAXException;
import java.io.ByteArrayInputStream;
import org.xml.sax.InputSource;
import java.io.IOException;
/**
 * A pattern factory can be shared among different threads. It parses type declarations and pattern definitions.
 * In this library this class is present only to test some xml. Actually PatternDefaultHandlers are used to parse 
 * only xml fragments, not a whole document.
 * @author Samuele Carpineti
 */
public class PatternFactory {
	private static final String DEFAULT_PARSER_NAME= "org.apache.xerces.parsers.SAXParser";
	private static XMLReader parser= null;
	private static PatternDefaultHandler defaultHandler= null;
	private PatternFactory(Map<String, TreeAutomaton> types) throws SAXException {
		parser= XMLReaderFactory.createXMLReader(DEFAULT_PARSER_NAME);
		defaultHandler= new PatternDefaultHandler(types);
		parser.setContentHandler(defaultHandler);
		parser.setErrorHandler(defaultHandler);
	}
	/** 
	 * Generates Tree Automata parsing an xml document. 
	 * (Look bopi.xsd : typeDefType in order to have the schema)
	 * @param types - a map from type name to automaton
	 * @param source - the xml document containing the pattern description
	 * @return a Tree Automaton which represent the xml documents 
	 */
	public synchronized static TreeAutomaton generatePattern(Map<String, TreeAutomaton> types, byte[] source) throws SAXException, IOException {
		if (parser == null || defaultHandler == null)
			new PatternFactory(types);
		parser.parse(new InputSource(new ByteArrayInputStream(source)));
		TreeAutomaton ta= defaultHandler.getAutomaton();
		return ta;
	}
	/**
	 * Generates a map from type name to Tree Automaton parsing an xml document.
	 * (Look bopi.xsd : typeDefType in order to have the schema)
	 * @param source - the xml document containing the type declaration (it can be mutually recursive)
	 * @return a map from type to the correspondent Tree Automaton
	 */
	public synchronized static Map<String, TreeAutomaton> parseTypeDeclaration(byte[] source) throws SAXException, IOException {
		HashMap<String, TreeAutomaton> m= new HashMap<String, TreeAutomaton>();
		new PatternFactory(m);
		parser.parse(new InputSource(new ByteArrayInputStream(source)));
		return m;
    }
	/** 
	 * A simple internal test procedure
	 * @return true if the test is ok, false otherwise
	 */
	static boolean test() {
		/* int,string*/
		String xml=
			"<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>"
				+ "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'>"
				+ "<sequence>"
				+ "<int/>"
				+ "<string/>"
				+ "</sequence>"
				+ "</pattern>";
		try {
			TreeAutomaton ta= PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), xml.getBytes());
			//System.out.println(ta);
			/* a[A] | A -- Int|String , String*/
			xml=
				"<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n"
					+ "<pattern xmlns='http://www.cs.unibo.it/fusion/bopi'>\n"
					+ "<bind target='1'>"
					+ "<sequence minOccurs='0' maxOccurs='unbounded'>"
					+ "<label type='UNION'>\n"
					+ "\t<labelName name='a'/>\n"
					+ "\t<sequence>\n"
					+ "\t\t<choice>\n"
					+ "\t\t\t<int/>\n"
					+ "\t\t\t<string/>\n"
					+ "\t\t</choice>\n"
					+ "\t\t<string/>\n"
					+ "\t\t<intLit>66</intLit>\n"
					+ "\t\t<chan><int/></chan>\n"
					+ "\t</sequence>\n"
					+ "</label>\n"
					+ "</sequence>"
					+ "</bind>"
					+ "</pattern>";
			ta= PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), xml.getBytes());
			if (ta.isNull(new HashSet<Assumption>())) {
				System.err.println(ta + "\n cannot  be empty");
				return false;
			}
			xml ="<pattern><choice><bind target='1'><int/></bind><chan capability='io'><int/></chan></choice></pattern>";
			TreeAutomaton ta1= PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), xml.getBytes());
			System.out.println(ta1);
			xml= "<pattern><choice><label type='UNION'><labelName name='a'/></label><empty/></choice></pattern>";
			TreeAutomaton ta2= PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), xml.getBytes());
			if (!ta2.recognizeEpsilon()) return false;
			xml= "<pattern><choice><choice><int/><string/></choice><choice><string/><int/></choice></choice></pattern>";
			TreeAutomaton ch= PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), xml.getBytes());
			if (ch.isNull(new HashSet<Assumption>())) return false;
			xml= "<pattern><sequence><chan capability='o'><choice><chan capability='o'><int/></chan><int/></choice></chan></sequence></pattern>";
			TreeAutomaton ch2= PatternFactory.generatePattern(new HashMap<String, TreeAutomaton>(), xml.getBytes());
			System.out.println(ch2);
			return true;
		} catch (SAXException s) {
			System.err.println(s);
			return false;
		} catch (IOException e) {
			System.err.println(e);
			return false;
		}
	}
}
