/*
 * Created on May 30, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.ta;


public class StringTA extends TreeAutomaton {
	
	private static TAState init = new TAState(false, true);
	
	private static TAState fin = new TAState(true, false);
	
    StringTA() {
        super();
        addState(init);
		addState(fin);
		addTransition(new StringTransition(SpecialLabels.ANY_STRING_PATTERN, init, fin, new int[0]));
		RECOGNIZES_EMPTY_LANGUAGE = 0;
		WITHOUT_USELESS_STATES = true;
    }
	
    public int getMaxBinding() {
        return 0;
    }

    /**
     * (non-Javadoc)
     * 
     * @see bopi.ta.TreeAutomaton#recognizeEpsilon()
     */
    public boolean recognizeEpsilon() {
        return false;
    }

    /**
     * (non-Javadoc)
     * 
     * @see java.lang.Object#clone()
     */
    public Object clone() {
        return new StringTA();
    }
}
