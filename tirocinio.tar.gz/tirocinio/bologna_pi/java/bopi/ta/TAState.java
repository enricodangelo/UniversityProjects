/*
 * TAState.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 27, 2004
 */
package bopi.ta;
/**
 * Automaton's state. 
 * @author Samuele Carpineti
 */
class TAState {
	private static long state_id= 0;
	/** state's identifier */
	long id;
	/** true if the node is visited, false otherwise */
	boolean visited;
	/** 
	 * Used when the automaton is cloned (only for efficiency), stores the state where this state is mapped
	 */
	TAState relative;
	/** 
	 * State can be marked for some purpose, color is used to allow this operation
	 */
	int color;
	/** 
	 * In products automaton's states have a pair of associated states. fst is the first one.
	 */
	TAState fst;
	/** 
	 * In products automaton's states have a pair of associated states. snd is the second one.
	 */
	TAState snd;
    /**
     * This array is used when a difference automaton is built. Each state become an array that contains at 
     * position 0 the state of the first automaton and position (i != 0) states of the second automaton 
     */
    TAState diffStates[];
    /**
     * True if one of the state in the diffStates array is final (the state at position 0 is not considered)
     */
    boolean diffStatesIsFinal;
	/**
	 * Builds a new state
	 */
	TAState() {
		id= state_id++;
	}
	/**
	 * Builds a new state setting its properties
	 * @param isFinal true if the state is final, false otherwise
	 * @param isInitial true if the state is initial, false otherwise 
	 */
	TAState(boolean isFinal, boolean isInitial) {
		id= state_id++;
		this.isFinal= isFinal;
		this.isInitial= isInitial;
	}
	/**
	 * True if the state is final, false otherwise
	 */
	boolean isFinal= false;
	/**
	 * True if the state is initial, false otherwise
	 */
	boolean isInitial= false;
	/**
	 * The list of labelled transitions that have the state as 
	 * source
	 */
	TransitionsList<MatchingTransition> transitions= new TransitionsList<MatchingTransition>();
	/**
     * The list of epsilon transitions that have the state as 
     * source
     */
	TransitionsList<EpsTransition> epsTransitions= new TransitionsList<EpsTransition>();
	/**
     * The list of labelled transitions that have the state as 
     * destination
     */
	TransitionsList<MatchingTransition> incomingTransitions= new TransitionsList<MatchingTransition>();
	/**
     * The list of epsilon transitions that have the state as 
     * destination
     */
	TransitionsList<EpsTransition> incomingEpsTransitions= new TransitionsList<EpsTransition>();
	/**
	 * Returns a string representation of the state
	 * @return a string representation of this state
	 */
	public String toString() {
		String s= new String();
//		The commented code is useful for debugging. It prints diffstates built during operation on automata
//		if (fst != null)
//			s += "<";
		s += "q" + id;
//		if (isInitial)
//			s += "_i";
//		if (isFinal)
//			s += "_f";		
//		if (fst != null)
//			s += ", " + fst + ", " + snd + ">";
//        if (diffStates!=null){
//            s += "<";
//            for (int i=0; i < diffStates.length; i++){
//                    s += diffStates[i].toString();
//            }
//            s += ">";
//        }
		return s;
	}
    /**
     * @see Object#equals(Object) 
     */
	public boolean equals(Object o) {
		return ((o instanceof TAState) && (((TAState) o).id == id));
	}
	/**
	 * Clones this state (properties isFinal, isInitial are inherited)
     * @return a copy of this state
	 */
	public Object clone() {
		TAState state= new TAState(isFinal, isInitial);
		return state;
	}
}
