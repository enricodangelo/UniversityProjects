/*
 * Tester.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 27, 2004
 *
 */
package bopi.ta;
import java.io.FileInputStream;
import java.io.IOException;
import org.xml.sax.SAXException;
import bopi.values.*;

import java.util.HashSet;
import java.util.Map;
import java.util.Iterator;
import java.util.TreeSet;
/**
 * Simple test for classes included in this package
 * @author Samuele Carpineti
 */
class Tester {
	static private boolean createValueTest0() {
		StringLiteral str= new StringLiteral("hello");
		IntLiteral i= new IntLiteral(1);
		IntLiteral j= new IntLiteral(2);
		StringLiteral str2= new StringLiteral("i don't want a '<bopi:string>' label");
		LabelledElement a= new LabelledElement("a", str2);
		/* create s = "hello",1,2,a["i don't want a ..."]*/
		Sequence s= new Sequence();
		s.addChild(str);
		s.addChild(i);
		s.addChild(j);
		s.addChild(a);
		//Empty () is at the end of the sequence; 
		if (s.getChildrenNumber() != 4) {
			System.out.println(s.getChildrenNumber());
			return false;
		}
		/* create root["hello",1,2,a["i don't ..."]]*/
		LabelledElement root= new LabelledElement("root", s);
		byte[] data= root.marshal();
		String xml= new String(data);
		String out= "<root>hello12<a>i don't want a '<bopi:string>' label</a></root>";
		if (!xml.equalsIgnoreCase(out))
			return false;
		return true;
	}
	static private boolean parseTypes() throws IOException, SAXException {
		String fsPrefix= "examples/";
		Map m= buildAutomata(fsPrefix + "typeDecl1.xml");
		Iterator i= m.values().iterator();
		while (i.hasNext()) {
			TreeAutomaton ta= (TreeAutomaton) i.next();
			if (!ta.isNull(new HashSet<Assumption>())) {
				System.err.println("typeDecl1.xml should be empty " + ta);
				return false;
			}
			TreeAutomaton diff= TreeAutomaton.difference(ta, ta);
			if (!diff.isNull(new HashSet<Assumption>())) {
				System.out.println(diff);
				return false;
			}
		}
		m= buildAutomata(fsPrefix + "typeDecl2.xml");
		i= m.values().iterator();
		while (i.hasNext()) {
			TreeAutomaton ta= (TreeAutomaton) i.next();
			if (!ta.isNull(new HashSet<Assumption>())) {
				System.err.println("typeDecl2.xml should be empty " + ta);
				return false;
			}
			TreeAutomaton diff= TreeAutomaton.difference(ta, ta);
			if (!diff.isNull(new HashSet<Assumption>())) {
				System.out.println(diff);
				return false;
			}
		}
		m= buildAutomata(fsPrefix + "typeDecl3.xml");
		i= m.values().iterator();
		while (i.hasNext()) {
			TreeAutomaton ta= (TreeAutomaton) i.next();
			if (!ta.isNull(new HashSet<Assumption>())) {
				System.err.println("typeDecl3.xml should be empty " + ta);
				return false;
			}
			TreeAutomaton diff= TreeAutomaton.difference(ta, ta);
			if (!diff.isNull(new HashSet<Assumption>())) {
				System.out.println(diff);
				return false;
			}
		}
		m= buildAutomata(fsPrefix + "typeDecl4.xml");
		i= m.values().iterator();
		while (i.hasNext()) {
			TreeAutomaton ta= (TreeAutomaton) i.next();
			if (ta.isNull(new TreeSet<Assumption>())) {
				System.err.println("typeDecl4.xml cannot be empty " + ta);
				return false;
			}
			TreeAutomaton diff= TreeAutomaton.difference(ta, ta);
			if (!diff.isNull(new TreeSet<Assumption>())) {
				System.out.println(diff);
				return false;
			}
		}
		m= buildAutomata(fsPrefix + "typeDecl5.xml");
		i= m.values().iterator();
		while (i.hasNext()) {
			TreeAutomaton ta= (TreeAutomaton) i.next();
			if (ta.isNull(new TreeSet<Assumption>())) {
				System.err.println("typeDecl5.xml cannot be empty " + ta);
				return false;
			}
			TreeAutomaton diff= TreeAutomaton.difference(ta, ta);
			if (!diff.isNull(new TreeSet<Assumption>())) {
				System.out.println(diff);
				return false;
			}
		}
		m= buildAutomata(fsPrefix + "typeDeclTailRecursion.xml");
		TreeAutomaton ta1 = (TreeAutomaton) m.get("T4");
		Sequence sequence =new Sequence();
		sequence.addChild(new IntLiteral(1));
		sequence.addChild(new IntLiteral(2));
		sequence.addChild(new IntLiteral(3));
		sequence.addChild(new IntLiteral(4));
		sequence.addChild(new IntLiteral(5));
		sequence.addChild(new StringLiteral("hello"));
		if (!ta1.matchValue(sequence,new VNode[0])) return false;
		return true;
	}
	static private Map buildAutomata(String typeDeclFile) throws IOException, SAXException {
		FileInputStream stream= new FileInputStream(typeDeclFile);
		byte[] pbuffer= new byte[stream.available()];
		stream.read(pbuffer);
		return PatternFactory.parseTypeDeclaration(pbuffer);
	}
	static private boolean matchFromFile(String patternFile, String valueFile) throws IOException, SAXException {
		FileInputStream stream= new FileInputStream(patternFile);
		byte[] pbuffer= new byte[stream.available()];
		stream.read(pbuffer);
		TreeAutomaton t= PatternFactory.generatePattern(new java.util.HashMap<String, TreeAutomaton>(), pbuffer);
		if (t.isNull(new TreeSet<Assumption>())) {
			System.err.println("Warning" + patternFile + "\n" + t + "\n is empty ... strange test");
			return false;
		}
		VNode[] env= new VNode[t.getMaxBinding() + 1];
		stream= new FileInputStream(valueFile);
		byte[] vbuffer= new byte[stream.available()];
		stream.read(vbuffer);
		VNode value= VNodeFactory.generateVNode(vbuffer);
		System.out.println(value);
		try {
			t.castVNode(value, env, true);
		} catch (VNodeCastException e) {
			return false;
		}
		//t.matchValue(value, env);
		for (int i= 0; i < env.length; i++) {
			System.out.print(i + "=" + env[i]);
			if (env[i] != null)
				System.out.println(" (" + env[i].getClass() + ")");
			else
				System.out.println(" (void)");
		}
		return true;
	}
	static private boolean match() throws IOException, SAXException {
		String fsPrefix= "examples/";
		if (!matchFromFile(fsPrefix + "pattern1.xml", fsPrefix + "value1.xml"))
			return false;
		if (!matchFromFile(fsPrefix + "pattern2.xml", fsPrefix + "value2.xml")) {
			return false;
		}
		if (!matchFromFile(fsPrefix + "pattern3.xml", fsPrefix + "value3.xml")) {
			return false;
		}
		if (!matchFromFile(fsPrefix + "pattern4.xml", fsPrefix + "value4.xml")) {
			return false;
		}
		if (!matchFromFile(fsPrefix + "pattern5.xml", fsPrefix + "value5.xml")) {
			return false;
		}
		if (!matchFromFile(fsPrefix + "pattern6.xml", fsPrefix + "value6.xml")) {
			return false;
		}
		if (!matchFromFile(fsPrefix + "pattern7.xml", fsPrefix + "value7.xml")) {
			return false;
		}
		if (!matchFromFile(fsPrefix + "pattern8.xml", fsPrefix + "value8.xml")) {
			return false;
		}
		return true;
	}
	public static void main(String[] args) throws Exception, Throwable {
		System.out.println("Starting some tests");
		System.out.println("-----------------------TESTING LABELS-------------------------");
		if (!LabelSet.test())
			System.err.println("LabelSet test Failed!");
		else
			System.out.println("LabelSet test Ok!");
		System.out.println("-----------------------TESTING CREATION/MARSHAL OF VALUES-------------------------");
		if (!createValueTest0())
			System.err.println("Error creating/marshalling values");
		else
			System.out.println("Marshalling Ok!");
		System.out.println("-----------------------TESTING OPERATIONS ON TA-------------------------");
		if (!TreeAutomaton.test())
			System.err.println("Error creating the automaton");
		else
			System.out.println("Automaton creation Ok!");
		System.out.println("-----------------------TESTING VNODES-------------------------");
		if (!VNodeFactory.test())
			System.err.println("VNode test Failed!");
		else
			System.out.println("VNode test Ok!");
		System.out.println("-----------------------TESTING PATTERN FACTORY-------------------------");
		if (!PatternFactory.test())
			System.err.println("Pattern test Failed!");
		else
			System.out.println("Pattern test Ok!");
		System.out.println("-----------------------TESTING PATTERN MATCHING-------------------------");
		if (!match())
			System.err.println("Match test Failed!");
		else
			System.out.println("Match test Ok!");
		System.out.println("-----------------------TESTING \"TYPES\" FACTORY-------------------------");
		if (!parseTypes())
			System.err.println("Type declaration Failed!");
		else
			System.out.println("Type declaration Ok!");
		System.out.println("-----------------------TESTING AMBIGUITY,SUBTYPING,EXHAUSTIVENESS ON TA-------------------------");
		if (!StaticAnalyzer.test())
			System.err.println("Error testing Static analyzer");
		else
			System.out.println("Static analyzer test ok!");
	}
}
