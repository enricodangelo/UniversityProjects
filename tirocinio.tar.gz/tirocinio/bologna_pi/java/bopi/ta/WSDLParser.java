/*
 * WSDLParser.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Jan 19, 2005
 */
package bopi.ta;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.URLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

/**
 * @author Samuele Carpineti
 */
public class WSDLParser {

	public static String WSDL_ROOT_DIRECTORY = "/home/" + System.getenv("USER") + "/public_html";

	private static String WSDL_RELATIVE_DIRECTORY = "/WebServices/";

	public void setWSDLRootDirectory(String root) {
		WSDLParser.WSDL_ROOT_DIRECTORY = root;
	}

	private static String getPage(String url) throws IOException {
		InputStream stream = null;
		if (url.startsWith("file://")) {
			stream = new java.io.FileInputStream(url.substring("file://".length()));
		} else if (url.startsWith("http://")) {
			try {
				URL httpUrl = new URL(url);
				URLConnection connection = httpUrl.openConnection();
				stream = connection.getInputStream();
			} catch (MalformedURLException mfe) {
				System.err.println("I'm not able to get the WSDL file " + url + ". " + mfe);
			}
		} else
			throw new IOException("Error reading " + url);
		byte[] pbuffer = new byte[stream.available()];
		stream.read(pbuffer);
		String decl = new String(pbuffer);
		return decl;
	}

	/**
	 * @param wsdl
	 *            the wsdl to download
	 * @return a pair containing as first element an XML type declaration (&lt
	 *         types &gt is the root element) and as second element the type
	 *         definition
	 */
	public static String[] getTypeFromWSDL(String wsdl) throws IOException {
		String decl = WSDLParser.getPage(wsdl);
		int splitPos = decl.indexOf("</types>") + "</types>".length();
		String typeDecl = decl.substring(decl.indexOf("<types>"), splitPos);
		//String pattern = decl.substring(decl.indexOf("<pattern>"), decl.indexOf("</pattern>") + "</pattern>".length()
		//		+ 1);
		decl= decl.substring(decl.indexOf("<message"));
		int begin = decl.indexOf("type=");
		decl= decl.substring(begin + "type=".length());
		String pattern = "<pattern><type name=" + decl.substring(0,decl.indexOf("/>")) + "/></pattern>";
		String[] res = { typeDecl, pattern };
		return res;
	}

	public static String getChannelAddress(String wsdl) throws IOException {
		String decl = getPage(wsdl);
		String chNum = decl.substring(decl.indexOf("<bopi:operation location='"), decl.length());
		chNum = chNum.substring("<bopi:operation location='".length(), chNum.indexOf("/>") - 1);
		String chMgr = decl.substring(decl.indexOf("<bopi:address location=") + 1, decl.length());
		chMgr = chMgr.substring("<bopi:address location=".length(), chMgr.indexOf("/>") - 1);
		return chMgr + chNum;
	}

	public static String createWSDL(String typeName, String channel, String xmlBoPiTypeDefs, String xmlBoPiType) {
		String wsdl = new String();
		typeName = typeName.trim();
		channel = channel.trim();
		wsdl += "<definitions name='" + channel + "'";
		wsdl += "\n  xmlns:tns='http://www.cs.unibo.it/bopi/" + channel + "'";
		wsdl += "\n  xmlns:soap='http://schemas.xmlsoap.org/wsdl/soap/'";
		wsdl += "\n  xmlns:bopi='http://www.cs.unibo.it/bopi/'";
		wsdl += "\n  xmlns:mime='http://mime.org";
		wsdl += "\n  xmlns='http://schemas.xmlsoap.org/wsdl/' >\n";
		wsdl += "<types>\n" + xmlBoPiTypeDefs.replaceFirst("<types>", "").replaceFirst("</types>", "") + "\n";
		if (!xmlBoPiType.trim().equals(""))
			wsdl += "	<complexType name='"+ typeName + "'>\n<sequence>" + xmlBoPiType + "\n</sequence>\n</complexType>\n";
		wsdl += "</types>\n";
		wsdl += "<message name='Document'>\n";
		wsdl += "  <part name='documentContent' type='"+ typeName + "' />\n";
		wsdl += "</message>\n";
		wsdl += "<portType name='documentContentPortType'>\n";
		wsdl += "  <operation name='operation'>\n";
		wsdl += "  <input message='tns:Document'/>\n";
		wsdl += "</portType>\n";
		wsdl += "<!--CONCRETE PART: BOPI SERVICE-->\n";
		wsdl += "<binding name='BoPiBinding' type='tns:documentContentPortType'>\n";
		wsdl += "<bopi:binding style='document' transport='http://www.cs.unibo.it/bopi/chmgr/'/>\n";
		wsdl += "<operation name='operation'>\n";
		wsdl += "<bopi:operation location='" + channel.substring(channel.indexOf('#'), channel.length()) + "'/>\n";
		wsdl += "<input>\n";
		wsdl += "<mime:content type='application/xml'/>\n";
		wsdl += "</input>\n";
		wsdl += "</operation>\n";
		wsdl += "</binding>\n";
		wsdl += "<service name='" + channel + "'>\n";
		wsdl += "<port name='operation' binding='BoPiBinding'>\n";
		wsdl += "<bopi:address location='" + channel.substring(0, channel.indexOf('#')) + "'/>\n";
		wsdl += "</port>\n";
		wsdl += "</service>\n";
		wsdl += "</definitions>\n";
		return wsdl;
	}

	public static String writeWSDL(String wsdl, String channel) {
		File file = null;
		try {
			String path= WSDL_ROOT_DIRECTORY + WSDL_RELATIVE_DIRECTORY + channel.replace('#', '_') + ".wsdl";
			file = new File(path);
			if (!file.createNewFile()){
				System.err.println("wsdl replaced");
			}
			FileOutputStream fo = new FileOutputStream(file);
			fo.write(wsdl.getBytes());
			InetAddress addr = InetAddress.getLocalHost();
			String ipAddr = addr.getHostAddress();
			return "http://" + ipAddr + "/~" + System.getenv("USER") + WSDL_RELATIVE_DIRECTORY + file.getName();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return null;
	}

	/**
	 * @param fileName
	 * @return the capability of the service
	 */
	public static int getCapabilityFromWSDL(String fileName) {
		// TODO implements this method
		return ChannelTransition.OUT_CAPABILITY;
	}
}
