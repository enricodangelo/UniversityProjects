/*
 * PatternDefaultHandler.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Mar 8, 2004
 */
package bopi.ta;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;

import java.util.Collection;
import java.util.Map;
import java.util.Stack;
import java.util.Iterator;
import java.util.Vector;
import java.util.HashMap;
import java.util.Set;

/**
 * This class is the default handler for pattern and type definitions. Both are
 * implemented here given the similarity between patterns and types. Typically
 * pattern definitions and type declarations are xml fragments not a whole xml
 * documents. So this class will be used from a more general parser that needs
 * to set (only for a fragment) this object as default handler and, after the
 * pattern/type xml fragment, needs to be restored, by re-setting the previous
 * default handler, when the fragments is finished. For this reason users
 * (typically parsers) must use setParserHandler. It guarantees that at the end
 * of the fragment a callback will be called restoring the previous parser's
 * handler and, if necessary, setting the parsing result. Patterns start with
 * the pattern element <pattern>and contain:
 * 
 * <pre>
 *                       
 *                       [int] = &lt;bopi:integer/&gt;                 |
 *                       [string] = &lt;bopi:string/&gt;               |--&gt; Basic types / wildchar basic patterns
 *                      
 *                       [channel&lt;Type_Name&gt;] = &lt;bopi:channel type=&quot;Type_Name&quot;/&gt; 
 *                       channel&lt;a[Int,b[String]] | a[String,b[Int]]&gt;
 *                       where P is a restricted type and does not contain literals 
 *                       
 *                       [n] = &lt;bopi:intLit&gt;n&lt;/bopi:intLit&gt;                     |
 *                       [&quot;text&quot;] = &lt;bopi:strLit&gt;text&lt;/bopi:strLit&gt;         |--&gt; Literals (are patterns not types)
 *                       [chan] = &lt;bopi:chanLit&gt;chan&lt;/bopi:chanLit&gt;    |
 *                       [TYPE] = &lt;type name=&quot;name&quot;/&gt;
 *                       [a[T]] = &lt;bopi:label name=&quot;a&quot;&gt;[T]&lt;/bopi:label&gt; |--&gt;label can be &tilde; 
 *                       [T*] = &lt;bopi:star&gt;[T]&lt;/bopi:star&gt;
 *                       [T1 , ..., Tn] = &lt;bopi:sequence&gt;[T1] ... [Tn]&lt;/bopi:sequence&gt;
 *                       [T1 | ...| Tn] = &lt;bopi:choice&gt;[T1] ... [Tn]&lt;/bopi:choice&gt;
 *                       [P as Y] = &lt;bopi:bind target=&quot;idx&quot;&gt;[P]&lt;/bopi:bind&gt;
 *                       
 *                       Type definitions start with element &lt;types&gt; and contain:
 *                       &lt;typedef name=&quot;T&quot;&gt;
 *                            &lt;!--Pattern P without binding (recursion is allowed but not at top level)--&gt;
 *                            [P]
 *                       &lt;/typedef&gt;
 *  
 *  
 * </pre>
 * 
 * The strategy used for the construction of the automaton is the following: At
 * the beginnig a new automaton A is allocated with an intiale state q0 and A,q0
 * are added to automatonStack and stateStack; then start the parsing of the
 * document doing different actions for different elements read as follow:
 * <ol>
 * <li>lab[P] : Start: a new labelled transition with label 'lab' and source
 * the first state onto the stack is added to the set of transitions of the
 * first automanton onto the stack (the top of the stack become the destination
 * of this new transition and the old top is deleted from the stack) End: pop on
 * both automatonStack and stateStack. Bindings are reset. Nota bene: the label
 * can be the wildcard ~
 * <li>int, string End: a new transition is added to the automaton on the top
 * of automatonStack
 * <li>Choice: P1|...|Pn Start-End: epsilon transitions are created from the
 * top of stateStack to the first state of each pattern (P1,...Pn) then epsilon
 * transitions from the last state of each pattern to another state created only
 * for this purpose is added to the current autoamaton (that is on the top of
 * automatonStack)
 * <li>Bind: An array of integers is used to keep all the available bindings.
 * -1 is used to distinguish binding not in the current automaton. When bind
 * starts the target is pop onto the stack and when is finishes an element is
 * pop from the stack. When transitions are created this stack is read until -1
 * and read values are added to the bindings.
 * <li>Sequence: nothing is done
 * <li>Star, Plus: P*, P+ P is read and the first and the last state of P are
 * linked through epsilon transitions: one from the first state of P to its last
 * state in the case of P* and the another from this last state to the initial
 * one in both the cases (P*, P+). NOTA BENE: P* and P+ can be implemented by
 * using T=P T* = P,T|() and P+=P,P* however we use an ad hoc implementation
 * that does not need to define a new type T ans uses less epsilon transitions.
 * <li>intLiteral, stringLiteral In this case we need to create a labelled
 * transition where the label is obtained reading the content of the element.
 * This operations is done in 'characters' and a field literal is used to store
 * the content.
 * <li>TypeName: In this case if a type name K is read inside a label, it's
 * content become the automaton for this type (written in the type environment)
 * otherwise the automaton A for K is cloned (only a first level clone is
 * needed). In the latter case however epsilon transitions are used to link the
 * state on the top of the stack to the set of initial states of A. Then the
 * final states of A are added via an epsilon transition to a state created only
 * for this purpose.
 * <ol>
 * 
 * @throws PatternParseException
 *             when a parse exception is found
 * @author Samuele Carpineti
 */
// This code seems to work but is ugly and need to be rewritten.
public class PatternDefaultHandler implements ContentHandler, ErrorHandler {
	class PatternParseException extends RuntimeException {

		private static final long serialVersionUID = 3256725074122649911L;

		PatternParseException() {
			super();
		}

		PatternParseException(String message) {
			super(message);
		}
	}

	/**
	 * A simple utilty class: a pair of state
	 */
	class StatePair {
		StatePair(TAState src, TAState dst) {
			this.src = src;
			this.dst = dst;
		}

		TAState src;

		TAState dst;
	}

	/**
	 * Simple utility class used for handling type names. Each times that a type
	 * name is found a new fake state is added and it is linked by an epsilon
	 * transition to the previous one. When the map from type to automaton is
	 * returned all the fake state are replaced with the correspondent
	 * automaton. This class is used for relating each fake-states with the
	 * correspondent automaton, typename and epsilon transition 'EPS=s0--->s1'
	 * that links the fake-state s1 to the previous state. When the type
	 * automaton T is retrieved it's linked to the automaton with:
	 * <ol>
	 * <li>a new set of epsilon transitions s1--eps-->I(T)={initial states of
	 * T}</li>
	 * <li>all the trasition departing from the fake state need to depart from
	 * F(T)={final states of T}</li>
	 * </ol>
	 */
	class StateAndAutomaton {
		StateAndAutomaton(TreeAutomaton ta, EpsTransition eps, String type) {
			this.ta = ta;
			this.eps = eps;
			this.type = type;
		}

		TreeAutomaton ta;

		EpsTransition eps;

		String type;

		public String toString() {
			return "(" + ta.getID() + "," + eps + ")";
		}
	}

	// ---------------------------------------------------------------------------------------------------------------//
	// Private fields used to store parsed data
	// ---------------------------------------------------------------------------------------------------------------//
	private static EpsilonTA epsilonTa = new EpsilonTA();

	private Locator locator;

	private String XMLread = new String();

	private static boolean KEEP_XML = false;
	
	private final static IntTA intTA = new IntTA();
	
	private final static StringTA stringTA = new StringTA();
	/**
	 * A reference to the automaton that the parser builds reading the XML
	 * fragments. It has labelled transition that can point to other automaton.
	 */
	private TreeAutomaton automaton;

	/**
	 * A stack of Strings. Each string is the name of the xml node (LABEL,BIND,
	 * SEQUENCE, ...)
	 */
	private Stack<String> nodeStack = new Stack<String>();

	private Stack<int[]> maxminOccurs = new Stack<int[]>();

	/**
	 * A stack of States. The state on the top of the stack is the one that must
	 * be used to create new transitions
	 */
	private Stack<TAState> stateStack = new Stack<TAState>();

	/**
	 * A stack of automata TA. Stores the automaton where add new states and
	 * transitions. A stack is used becuase each time that a label is read a new
	 * automaton for its content need to be created.
	 */
	private Stack<TreeAutomaton> automataStack = new Stack<TreeAutomaton>();

	/**
	 * A stack of Vectors. Each vector contains the states that conclude the
	 * choice pattern. It's used to create a new state as final state for each
	 * choice. An epsilon transition from each the state contained in the vector
	 * to a new state, that is added to stateStack, is added to the current
	 * automaton.
	 */
	private Stack<Collection<TAState>> finalChoiceStates = new Stack<Collection<TAState>>();

	/**
	 * A stack of States where the first state of a star is stored
	 */
	private Stack<TAState> firstOfStar = new Stack<TAState>();

	/**
	 * String for literal. Each time that characters are found in the xml they
	 * are written in literal
	 */
	private String literal = new String();

	/**
	 * A stack of variables name (integers). -1 is in the stack to divide an
	 * automaton from each other (otherwise we should use a stack for each
	 * automaton)
	 */
	private Stack<Integer> variableStack = new Stack<Integer>(); 

	/**
	 * A stack of LabelledTransition used to retrieve the last transition added
	 * to the automaton and change its content. This is used for type names.
	 */
	private Stack<MatchingTransition> labelledTransition = new Stack<MatchingTransition>();

	/**
	 * True if we are parsing the first element in a sequence
	 */
	private boolean firstOfSequence = false;

	/**
	 * Old content handler to set when the xml fragments is finished
	 */
	private ContentHandler oldContentHandler;

	/**
	 * Old error handler to set when the xml fragments is finished
	 */
	private ErrorHandler oldErrorHandler;

	/**
	 * Old parser to set when the xml fragments is finished
	 */
	private XMLReader parser;

	/**
	 * Object to callback
	 */
	private HandlerCallback taRequester;

	/**
	 * A map from type names to their automaton
	 */
	private Map<String, TreeAutomaton> automatonMap = new HashMap<String, TreeAutomaton>();

	/**
	 * A map from ``placeholder states" to the type name T. It's used to
	 * substitute each placeholder with the automaton that corresponds to the
	 * type name T.
	 */
	private Stack<StateAndAutomaton> stateToType = new Stack<StateAndAutomaton>();
	
	private final static IntTA intAutoma = new IntTA();
	private final static StringTA stringAutoma = new StringTA();
	/**
	 * Builds a PatternDefaultHandler for parsing type declarations or patterns.
	 * 
	 * @param automatonMap -
	 *            the map where the default handler stores mappings from type
	 *            names to their automaton (if the parser read some type
	 *            declaration) and gets the automaton for just defined types
	 */
	public PatternDefaultHandler(Map<String, TreeAutomaton> automatonMap) {
		this.automatonMap = automatonMap;
	}

	/**
	 * Set the content handler of the parser with a PatternDefaultHandler
	 * 
	 * @param parser -
	 *            the parser
	 * @param h -
	 *            the handler where callback sending the automaton
	 * @param automatonMap -
	 *            the map from type definition to automaton (it's filled by the
	 *            PatterDefaultHandler if a tytpe declaration is read)
	 */
	static public void setParserHandler(XMLReader parser, HandlerCallback h, Map<String, TreeAutomaton> automatonMap) {
		PatternDefaultHandler p = new PatternDefaultHandler(automatonMap);
		KEEP_XML = false;
		p.oldContentHandler = parser.getContentHandler();
		p.oldErrorHandler = parser.getErrorHandler();
		p.taRequester = h;
		p.parser = parser;
		parser.setContentHandler(p);
		parser.setErrorHandler(p);
	}

	static public void setParserHandler(XMLReader parser, HandlerCallback h, Map<String, TreeAutomaton> automatonMap,
			boolean keep_XML) {
		setParserHandler(parser, h, automatonMap);
		KEEP_XML = keep_XML;
	}

	/**
	 * Set the content handler of the parser with a PatternDefaultHandler
	 * 
	 * @param parser
	 *            the parser
	 * @param automatonMap
	 *            the map from type definition to automaton (it's filled by the
	 *            PatterDefaultHandler if a tytpe declaration is read)
	 */
	static public void setParserHandler(XMLReader parser, Map<String, TreeAutomaton> automatonMap) {
		PatternDefaultHandler.setParserHandler(parser, null, automatonMap);
	}

	/**
	 * Returns the automaton built reading the xml fragment
	 * 
	 * @return the automaton built reading the xml fragment
	 */
	protected TreeAutomaton getAutomaton() {
		if (!automaton.checkIFStates()) {
			System.err.println("getAutomaton: Error Building Automaton");
		}
		automaton.removeEpsilonTransitions();
		automaton.removeUselessStates();
		if (!automaton.checkIFStates()) {
			System.err.println("getAutomaton: Error Building Automaton ");
		}
		return automaton;
	}

	/**
	 * Replaces all the placeholders with the correspondent automaton. Top level
	 * recursion is not allowed.
	 */
	private void fillAutomatonMap() {
		Vector n = new Vector();
		while (!stateToType.empty()) {
			StateAndAutomaton entry = stateToType.pop();
			EpsTransition fakeT = entry.eps;
			// the automaton that needs to be completed
			TreeAutomaton incompleteTA = entry.ta;
			// the automaton that must complete
			TreeAutomaton typeTA = (TreeAutomaton) automatonMap.get(entry.type);
			if (typeTA == null)
				throw new PatternParseException(entry.type + " is undefined");
			if (typeTA.equals(incompleteTA))
				throw new RuntimeException("Names must be bound");
			//            
			// if (typeTA.equals(incompleteTA)) {
			// //incompleteTA.removeTransition(fakeT);
			// //X = X,S is not allowed. X=X* is allowed because uses epsilon
			// // transitions.
			// if (fakeT.dst.transitions.size() > 0)
			// throw new PatternParseException("Only tail recursion is
			// allowed");
			//
			// if (fakeT.dst.epsTransitions.size() > 0) {
			// Iterator j = fakeT.dst.transitions.iterator();
			// while (j.hasNext()) {
			// Iterator sti = stateToType.iterator();
			// while (sti.hasNext()) {
			// StateAndAutomaton sanda = (StateAndAutomaton) o;
			// if (sanda.eps.equals(j.next())) throw new PatternParseException(
			// "Only tail recursion is allowed");
			// }
			// }
			// }
			// //In X = X | X = X + S (X can b deleted)
			// if (fakeT.dst.isFinal && fakeT.src.isInitial) {
			// typeTA.removeTransition(fakeT);
			// continue;
			// }
			// Iterator i = incompleteTA.getInitialStates().iterator();
			// if (i.hasNext()) {
			// if (fakeT.dst.isFinal) {
			// incompleteTA.getFinalStates().remove(fakeT.dst);
			// fakeT.dst.isFinal = false;
			// }
			// incompleteTA.addTransition(new EpsTransition(fakeT.dst, (TAState)
			// i.next()));
			// }
			// while (i.hasNext()) {
			// incompleteTA.addTransition(new EpsTransition(fakeT.src, (TAState)
			// i.next()));
			// }
			// }
			// The cloned automaton is stored in the table of incomplete automa
			TransitionsList<EpsTransition> tl = new TransitionsList<EpsTransition>();
			Iterator<StateAndAutomaton> i = stateToType.iterator();
			// find epsTransitions to patch of the original automaton
			while (i.hasNext()) {
				StateAndAutomaton sa = i.next();
				if (sa.ta.equals(typeTA))
					tl.add(entry.eps);
			}
			// clone the automaton returning the new automaton and a list of
			// transition correspondent to the set of the transitions that need
			// to be completed
			Object[] o1 = typeTA.clone(tl);
			// the cloned automaton that must complete incompleteTA (we need the
			// clone because it can be necessary to change the automaton)
			TreeAutomaton copyOfTypeTA = (TreeAutomaton) o1[0];
			TransitionsList<EpsTransition> t = (TransitionsList<EpsTransition>) o1[1];
			i = stateToType.iterator();
			while (i.hasNext()) {
				StateAndAutomaton sa = i.next();
				if (entry.type.equals(sa.type) && typeTA.equals(incompleteTA)) {
					Iterator<EpsTransition> it = t.iterator();
					while (it.hasNext()) {
						stateToType.add(new StateAndAutomaton(copyOfTypeTA, it.next(), entry.type));
					}
				}
			}

			Iterator<TAState> j = copyOfTypeTA.getStates().iterator();
			while (j.hasNext()) {
				TAState dst = j.next();
				boolean isInitial = dst.isInitial;
				boolean isFinal = dst.isFinal;
				dst.isInitial = false;
				dst.isFinal = false;
				if (!isInitial && !isFinal) {
					incompleteTA.addState(dst);
				}
				if (isInitial) {
					incompleteTA.addState(dst);
					incompleteTA.addTransition(new EpsTransition(fakeT.src, dst));
				}
				if (isFinal) {
					incompleteTA.addState(dst);
					incompleteTA.addTransition(new EpsTransition(dst, fakeT.dst));
				}
			}

			Object[] array = { incompleteTA, fakeT, typeTA };
			n.add(array);
		}
		Iterator k = n.iterator();
		while (k.hasNext()) {
			Object[] array = (Object[]) k.next();
			TreeAutomaton incompleteTA = (TreeAutomaton) array[0];
			EpsTransition fakeT = (EpsTransition) array[1];
			TreeAutomaton typeTA = (TreeAutomaton) array[2];
			Iterator k1 = fakeT.dst.epsTransitions.iterator();
			boolean isStar = false;
			while (k1.hasNext()) {
				EpsTransition e = (EpsTransition) k1.next();
				if (e.dst.equals(fakeT.src))
					isStar = true;
			}
			if (!(typeTA.recognizeEpsilon() || isStar))
				incompleteTA.removeTransition(fakeT);

		}
		Set<Map.Entry<String, TreeAutomaton>> taSet = automatonMap.entrySet();
		Iterator<Map.Entry<String, TreeAutomaton>> j = taSet.iterator();
		while (j.hasNext()) {
			TreeAutomaton ta = j.next().getValue();
			ta.removeEpsilonTransitions();
			ta.removeUselessStates();
			if (!ta.checkIFStates()) {
				System.err.println("fillAutomataMap: Error Building Automaton");
			}
		}
	}

	/**
	 * Resets the handler
	 */
	private void reset() {
		nodeStack.clear();
		maxminOccurs.clear();
		stateStack.clear();
		automataStack.clear();
		finalChoiceStates.clear();
		firstOfStar.clear();
		labelledTransition.clear();
		literal = "";
		firstOfSequence = false;
		variableStack.clear(); /* x as (int ,y String) */
		variableStack.push(new Integer(-1));
		automaton = new TreeAutomaton();
		TAState q = new TAState(false, true);
		automaton.addState(q);
		stateStack.push(q);
		automataStack.push(automaton);
	}

	/**
	 * Resets the fields used for type declarations
	 */
	private void resetTypeDecl() {
		stateToType = new Stack<StateAndAutomaton>();
		PARSING_TYPE_DECLARATION = false;
	}

	/**
	 * @see org.xml.sax.ContentHandler#setDocumentLocator(org.xml.sax.Locator)
	 */
	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}

	/**
	 * @see org.xml.sax.ContentHandler#startDocument()
	 */
	public void startDocument() throws SAXException {
		reset();
	}

	/**
	 * @see org.xml.sax.ContentHandler#endDocument()
	 */
	public void endDocument() throws SAXException {
		// do nothing
	}

	/**
	 * @see org.xml.sax.ContentHandler#startPrefixMapping(java.lang.String,
	 *      java.lang.String)
	 */
	public void startPrefixMapping(String prefix, String uri) throws SAXException {
		// do nothing

	}

	/**
	 * @see org.xml.sax.ContentHandler#endPrefixMapping(java.lang.String)
	 */
	public void endPrefixMapping(String prefix) throws SAXException {
		// do nothing
	}

	// === Names of the xml elements ====//
	public static final String BOPI_NAMESPACE = "http://www.cs.unibo.it/fusion/bopi";

	public static final String ANY_INT = "int";

	public static final String ANY_STRING = "string";

	public static final String CHAN = "chan";

	public static final String ATT_CHAN_CAPABILITY = "capability";

	public static final String BOTTOM = "bottom";

	public static final String VOID = "empty";

	public static final String ATT_TYPE_NAME = "type";

	public static final String SEQUENCE = "sequence";

	public static final String CHOICE = "choice";

	public static final String INT_LIT = "intLit";

	public static final String STR_LIT = "strLit";

	// public static final String STAR = "star";
	//
	// public static final String PLUS = "plus";

	public static final String BIND = "bind";

	public static final String TARGET = "target";

	public static final String LABEL = "label";

	public static final String DIFF_LABEL = "DIFFERENCE";

	public static final String UNION_LABEL = "UNION";

	public static final String ANY_LABEL = "ANY";

	public static final String LABEL_NAME = "labelName";

	public static final String ATT_LABEL_TYPE = "type";

	public static final String ATT_LABEL_VALUE = "name";

	public static final String CHAN_LABEL = "chan";

	public static final String EMPTY = "empty";

	public static final String KTYPE = "type";
	
	public static final String ELEMENT = "element";

	public static final String ATT_KTYPE_NAME = "name";

	/* root for patterns */
	public static final String PATTERN_ROOT = "pattern";

	/* root for functions return type */
	public static final String TYPE_ROOT = "returntype";

	private boolean PARSING_TYPE_DECLARATION = false;

	/*
	 * <types> <complexType name='T0'> [T] </complexType> </types>
	 */
	/* root for type declarations */
	public static final String TYPE_DECLARATION_ROOT = "types";

	public static final String TYPE_DEFINITION = "complexType";

	/* type definition name */
	public static final String ATT_TYPE_DEF_NAME = "name";

	private void startPatternRoot() {
		reset();
		resetTypeDecl();
	}

	private void startTypeRoot() {
		reset();
		resetTypeDecl();
	}

	private void startTypeDeclRoot() {
		reset();
		resetTypeDecl();
		PARSING_TYPE_DECLARATION = true;
	}

	private void startStar() {
		StatePair pair = getSrcDst();
		automataStack.peek().addTransition(new EpsTransition(pair.src, pair.dst));
		firstOfStar.push(pair.dst);
	}

	private void startPlus() {
		firstOfStar.push(stateStack.peek());
	}

	private void startSequence(String minOccurs, String maxOccurs) {
		if (minOccurs == null)
			minOccurs = "1";
		if (maxOccurs == null)
			maxOccurs = "1";
		int min = Integer.parseInt(minOccurs);
		int max;
		if (maxOccurs.equalsIgnoreCase("unbounded"))
			max = -1;
		else 
			max = Integer.parseInt(maxOccurs);
		if (min == 0 && max == 0)
			return;
		else if (min == 1 && max == -1) {
			startPlus();
			StatePair pair = getSrcDst();
			automataStack.peek().addTransition(new EpsTransition(pair.src, pair.dst));
		} else if (min == 0 && max == -1) {
			startStar();
			StatePair pair = getSrcDst();
			automataStack.peek().addTransition(new EpsTransition(pair.src, pair.dst));
		} else if (min == 1 && max == 1) {
			StatePair pair = getSrcDst();
			automataStack.peek().addTransition(new EpsTransition(pair.src, pair.dst));
		} else
			throw new RuntimeException("Unsupported Choice: minOccurs=" + minOccurs + " maxOccurs=" + maxOccurs);
		int[] minmax = { min, max };
		maxminOccurs.push(minmax);
	}

	private void startChoice(String minOccurs, String maxOccurs) {
		if (minOccurs == null)
			minOccurs = "1";
		if (maxOccurs == null)
			maxOccurs = "1";
		int min = Integer.parseInt(minOccurs);
		int max;
		try {
			max = Integer.parseInt(maxOccurs);
		} catch (NumberFormatException nfe) {
			// -1 unbounded
			max = -1;
		}
		if (min == 0 && max == 0)
			return;
		else if (min == 1 && max == -1) {
			startPlus();
			if (!inChoice())
				finalChoiceStates.push(new Vector<TAState>());
		} else if (min == 0 && max == -1) {
			startStar();
			if (!inChoice())
				finalChoiceStates.push(new Vector<TAState>());
		} else if (min == 1 && max == 1) {
			if (!inChoice())
				finalChoiceStates.push(new Vector<TAState>());
		} else
			throw new RuntimeException("Unsupported Choice: minOccurs=" + minOccurs + " maxOccurs=" + maxOccurs);
		int[] minmax = { min, max };
		maxminOccurs.push(minmax);
	}

	private void startTypeDefinition(String type) {
		// if the bytecode handler parses a type definition need to call
		// startTypeDeclRoot explicitly
		if (!PARSING_TYPE_DECLARATION)
			startTypeDeclRoot();
		if (automatonMap.put(type, automataStack.peek()) != null)
			throw new PatternParseException("Schema name " + type + " bound twice");
	}

	private void startTypeName(String type) {
		TreeAutomaton typeTA = (TreeAutomaton) this.automatonMap.get(type);
		String topL = (String) this.nodeStack.peek();
		if ((topL.equals(LABEL) || topL.equals(CHAN_LABEL)) && typeTA != null) {
			// we are in the following situation: <chan> <type name='T'/>
			// </chan>
			// where we have an automaton for T so we do not need placeholders.
			// We merely use the automaton for T
			automataStack.pop();
			MatchingTransition t =  labelledTransition.peek();
			t.content = typeTA;
			automataStack.push(typeTA);
		} else if (topL == null || topL.equals(PATTERN_ROOT)) {
			automataStack.pop();
			this.automaton = typeTA;
			automataStack.push(typeTA);
		} else if (PARSING_TYPE_DECLARATION) {
			if (automataStack.size() == 1) // && automatonMap.get(type) !=
				// automataStack.peek())
				throw new PatternParseException("\"" + type
						+ "\" must be bound. For top level recursions you must use the Kleene Operator \"*\".");
			StatePair pair = this.getSrcDst();
			EpsTransition eps = new EpsTransition(pair.src, pair.dst);
			automataStack.peek().addTransition(eps);
			stateToType.push(new StateAndAutomaton((TreeAutomaton) automataStack.peek(), eps, type));
		} else if (!PARSING_TYPE_DECLARATION && typeTA == null) {
			throw new RuntimeException("Type -" + type + "- in pattern not defined");
		} else if (!PARSING_TYPE_DECLARATION && typeTA != null) {
			TreeAutomaton topTA = (TreeAutomaton) automataStack.peek();
			TreeAutomaton copyOfTA = (TreeAutomaton) typeTA.clone();
			TAState newFinalState = new TAState(false, false);
			topTA.addState(newFinalState);
			if (typeTA.recognizeEpsilon()) {
				TAState src = (TAState) stateStack.peek();
				topTA.addTransition(new EpsTransition(src, newFinalState));
			}
			int[] vars = this.getVariables();
			// if we are not parsing a type declatration we do not need to
			// explore the set of epsilon transition
			// for every transition: 1. change the set of bindings 2.
			Iterator<TAState> i = copyOfTA.getStates().iterator();
			while (i.hasNext()) {
				TAState state = i.next();
				Iterator<MatchingTransition> j = state.transitions.iterator();
				while (j.hasNext()) {
					MatchingTransition l = j.next();
					l.variables = vars;
				}
				boolean isInitial = state.isInitial;
				boolean isFinal = state.isFinal;
				state.isFinal = false;
				state.isInitial = false;
				if (!(isFinal || isInitial))
					topTA.addState(state);
				if (isFinal) {
					topTA.addState(state);
					EpsTransition eps = new EpsTransition(state, newFinalState);
					topTA.addTransition(eps);
				}
				if (isInitial) {
					topTA.addState(state);
					TAState src = (TAState) stateStack.peek();
					EpsTransition eps = new EpsTransition(src, state);
					topTA.addTransition(eps);
				}
			}
			if (!topTA.checkIFStates()) {
				System.err.println("Error building automaton");
			}
			stateStack.push(newFinalState);
		}
	}

	private void startEmpty() {
		String topL = (String) nodeStack.peek();
		if (topL.equals(LABEL) || topL.equals(CHAN_LABEL))
			labelledTransition.peek().content = PatternDefaultHandler.epsilonTa;
		else if (nodeStack.peek() != SEQUENCE) {
			StatePair pair = getSrcDst();
			EpsTransition eps = new EpsTransition(pair.src, pair.dst);
			TreeAutomaton parent = automataStack.peek();
			parent.addTransition(eps);
		}
	}

	private void startBind(String target) {
		Integer var = new Integer(target);
		variableStack.push(var);
	}

	private void startLabel(String type) {
		TreeAutomaton parent = automataStack.peek();
		/*
		 * create a new automaton for the content and push it on the top of the
		 * stack of automaton
		 */
		TreeAutomaton content = new TreeAutomaton();
		StatePair pair = getSrcDst();
		int[] vars = getVariables();
		LabelSet labelSet = new LabelSet(MatchedType.MATCH_LABELS);
		if (!type.equals(UNION_LABEL))
			labelSet.addLabel(SpecialLabels.ANY_LABEL_PATTERN);
		LabelledTransition l = new LabelledTransition(labelSet, pair.src, pair.dst, content, vars);
		parent.addTransition(l);
		labelledTransition.push(l);
		automataStack.push(content);
		TAState q = new TAState(false, true);
		content.addState(q);
		stateStack.push(q);
		variableStack.push(new Integer(-1));
	}

	private void startLabelName(String labelName) {
		labelledTransition.peek().labels.addLabel(labelName);
	}

	private void startChan(String capability) {
		TreeAutomaton parent = (TreeAutomaton) automataStack.peek();
		/*
		 * create a new automaton for the content and push it on the top of the
		 * stack of automaton
		 */
		TreeAutomaton content = new TreeAutomaton();
		StatePair pair = getSrcDst();
		int[] vars = getVariables();
		int cap = ChannelTransition.OUT_CAPABILITY;
		if (capability != null) {
			if (capability.equals("i"))
				cap = ChannelTransition.IN_CAPABILITY;
			else if (capability.equals("io"))
				cap = ChannelTransition.IO_CAPABILITY;
		}
		ChannelTransition l = new ChannelTransition(cap, pair.src, pair.dst, content, vars);
		parent.addTransition(l);
		labelledTransition.push(l);
		automataStack.push(content);
		TAState q = new TAState(false, true);
		content.addState(q);
		stateStack.push(q);
		variableStack.push(new Integer(-1));
	}

	private void startVoid() {
		// do nothing
	}

	private void startBottom() {
		// do nothing
	}

	private void startIntLit() {
		// do nothing
	}

	private void startStrLit() {
		// do nothing
	}

	private void startAnyStr() {
		// do nothing
	}

	private void startAnyLit() {
		// do nothing
	}

	/**
	 * @return a pair with a the source and the destination state for the new
	 *         transition. Source and destination are never set to
	 *         initial/final. This method uses as source state the last state on
	 *         the stack and it's set to initial if the top of the
	 *         firstOfSequence stack is true. The destination state can be a new
	 *         state and it's added to the set of the state of the automaton on
	 *         the top fo the stack .
	 */
	private StatePair getSrcDst() {
		TAState dst = new TAState();
		TAState src = null;
		/*
		 * if the element is inside a choice the initial state cannot be erased
		 * becuase it needs to be reused also for other transitions (so we peek
		 * instead of pop)
		 */
		boolean isInChoice = inChoice();
		if (isInChoice) {
			src = (TAState) stateStack.peek();
		} else {
			src = (TAState) stateStack.pop();
		}
		stateStack.push(dst);
		((TreeAutomaton) automataStack.peek()).addState(dst);
		return (new StatePair(src, dst));
	}

	private String startElementToXML(String namespaceURI, String localName, String qName, Attributes atts) {
		String XML = new String();
		XML += "<" + localName;
		if (atts.getLength() > 0)
			XML += " ";
		for (int i = 0; i < atts.getLength(); i++) {
			XML += atts.getLocalName(i) + "='" + atts.getValue(i) + "'";
		}
		XML += ">";
		return XML;
	}
	
	private void startElement(String elementName, String typeName) {
		TreeAutomaton parent = automataStack.peek();
		LabelSet labelSet = new LabelSet(MatchedType.MATCH_LABELS);
		labelSet.addLabel(elementName);
		/*
		 * create a new automaton for the content and push it on the top of the
		 * stack of automaton
		 */
		if (typeName == null){
			TreeAutomaton content = new TreeAutomaton();
			StatePair pair = getSrcDst();
			int[] vars = getVariables();
			LabelledTransition l = new LabelledTransition(labelSet, pair.src, pair.dst, content, vars);
			labelledTransition.push(l);
			automataStack.push(content);
			TAState q = new TAState(false, true);
			content.addState(q);
			stateStack.push(q);
			variableStack.push(new Integer(-1));
		}
		else if (typeName.equals("int") || typeName.equals("xsd:integer")){
			StatePair pair = getSrcDst();
			int[] vars = getVariables();
			LabelledTransition l= new LabelledTransition(labelSet, pair.src, pair.dst, intTA, vars);
			parent.addTransition(l);
			automataStack.push(null);
		}
		else if (typeName.equals("string") || typeName.equals("xsd:string")){
			StatePair pair = getSrcDst();
			int[] vars = getVariables();
			LabelledTransition l= new LabelledTransition(labelSet, pair.src, pair.dst, stringTA, vars);
			parent.addTransition(l);
			automataStack.push(null);
		}
		else {
			TreeAutomaton content = this.automatonMap.get(typeName);
			StatePair pair = getSrcDst();
			int[] vars = getVariables();
			LabelledTransition l = new LabelledTransition(labelSet, pair.src, pair.dst, content, vars);
			parent.addTransition(l);
			automataStack.push(null);
		}
	}
	
	/**
	 * @see org.xml.sax.ContentHandler#startElement(java.lang.String,
	 *      java.lang.String, java.lang.String, org.xml.sax.Attributes)
	 */
	public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
		if (KEEP_XML) {
			this.XMLread += startElementToXML(namespaceURI, localName, qName, atts);
		}
		if (localName == PATTERN_ROOT)
			startPatternRoot();
		else if (localName == TYPE_ROOT)
			startTypeRoot();
		else if (localName == TYPE_DECLARATION_ROOT)
			startTypeDeclRoot();
		// else if (localName == STAR) startStar();
		// else if (localName == PLUS) startPlus();
		else if (localName == SEQUENCE)
			startSequence(atts.getValue("minOccurs"), atts.getValue("maxOccurs"));
		else if (localName == TYPE_DEFINITION) {
			String name = atts.getValue(ATT_TYPE_DEF_NAME);
			if (name != null)
				startTypeDefinition(atts.getValue(ATT_TYPE_DEF_NAME));
			else {
				// continue with the rest
			}
		} else if (localName == KTYPE) {
			startTypeName(atts.getValue(ATT_KTYPE_NAME));
		} else if (localName == EMPTY)
			startEmpty();
		else if (localName == BIND)
			startBind(atts.getValue(TARGET));
		else if (localName == CHOICE)
			startChoice(atts.getValue("minOccurs"), atts.getValue("maxOccurs"));
		else if (localName == LABEL)
			startLabel(atts.getValue(ATT_LABEL_TYPE));
		else if (localName == LABEL_NAME)
			startLabelName(atts.getValue(ATT_LABEL_VALUE));
		else if (localName == CHAN)
			startChan(atts.getValue(ATT_CHAN_CAPABILITY));
		else if (localName == BOTTOM)
			startBottom();
		else if (localName == VOID)
			startVoid();
		else if (localName == ELEMENT)
			startElement(atts.getValue("name"), atts.getValue("type"));
		else if (localName == ANY_INT)
			startAnyLit();
		else if (localName == ANY_STRING)
			startAnyStr();
		else if (localName == INT_LIT)
			startIntLit();
		else if (localName == STR_LIT)
			startStrLit();
		else
			throw new PatternParseException("Unexpected start element " + localName);
		nodeStack.push(localName);
	}

	private void endPatternRoot() {
		if (!automataStack.isEmpty()) {
			TreeAutomaton lastTA = (TreeAutomaton) automataStack.peek();
			lastTA.setFinal((TAState) stateStack.peek());
		}
		if (parser != null) {
			parser.setContentHandler(oldContentHandler);
			parser.setErrorHandler(oldErrorHandler);
		}
		if (taRequester != null) {
			taRequester.setAutomaton(getAutomaton());
			if (KEEP_XML)
				taRequester.setXMLDocument(XMLread);
		}
	}

	private void endTypeRoot() {
		TreeAutomaton lastTA = (TreeAutomaton) automataStack.peek();
		lastTA.setFinal((TAState) stateStack.peek());
	}

	private void endTypeDefinition() {
		TreeAutomaton lastTA = (TreeAutomaton) automataStack.peek();
		lastTA.setFinal((TAState) stateStack.peek());
		reset();
	}

	private void endTypeDeclRoot() {
		if (!automataStack.empty()) {
			// the automataStack is empty if the type declaration does not
			// contain type definitions
			TreeAutomaton lastTA = (TreeAutomaton) automataStack.peek();
			lastTA.setFinal((TAState) stateStack.peek());
		}
		if (parser != null) {
			parser.setContentHandler(oldContentHandler);
			parser.setErrorHandler(oldErrorHandler);
		}
		fillAutomatonMap();
		if (taRequester != null)
			taRequester.setAutomaton(getAutomaton());
	}

	private void endLabel() {
		TreeAutomaton lastTA = automataStack.pop();
		lastTA.setFinal(stateStack.pop());
		labelledTransition.pop();
		while (((Integer) variableStack.pop()).intValue() != -1)
			;
		if (inChoice() && notInSequence())
			// if the top element is a choice the last state onto the stack need
			// to
			// be added to the final state
			// for this branch of the choice
			finalChoiceStates.peek().add(stateStack.pop());
	}

	private void endLabelConstant() {
		// do nothing
	}

	private void endChan() throws SAXException {
		endLabel();
	}

	private void endSequence() {
		if (inChoice() && notInSequence()) {
			finalChoiceStates.peek().add(stateStack.pop());
		}
		int[] minmax = maxminOccurs.pop();
		if (minmax[0] == 0 && minmax[1] == -1)
			endStar();
		if (minmax[0] == 1 && minmax[1] == -1)
			endPlus();
	}

	private void endStar() {
		TreeAutomaton lastTA = (TreeAutomaton) automataStack.peek();
		TAState init = (TAState) firstOfStar.pop();
		TAState finalState = (TAState) stateStack.peek();
		lastTA.addTransition(new EpsTransition(init, finalState));
		lastTA.addTransition(new EpsTransition(finalState, init));
		// StatePair pair = getSrcDst();
		// lastTA.addTransition(new EpsTransition(finalState, pair.dst));
		if (inChoice() && notInSequence()) {
			// if the top element is a choice the last state onto the stack need
			// to be added to the final state
			// for this branch of the choice
			finalChoiceStates.peek().add(stateStack.pop());
		}
	}

	private void endPlus() {
		TreeAutomaton lastTA = (TreeAutomaton) automataStack.peek();
		TAState init = (TAState) firstOfStar.pop();
		TAState finalState = (TAState) stateStack.peek();
		lastTA.addTransition(new EpsTransition(finalState, init));
		if (inChoice() && notInSequence()) {
			finalChoiceStates.peek().add(stateStack.pop());
		}
	}

	private void endBind() {
		variableStack.peek();
		if (!PARSING_TYPE_DECLARATION)
			variableStack.pop();
	}

	private void endChoice() {
		// creates a common final state for this choice (finalChoiceStates
		// contains the set of states that must be joint with
		// this new common state)
		if (!inChoice()) {
			// removes the state used as source state for each brach of this
			// choice
			stateStack.pop();
			TAState q = new TAState();
			stateStack.push(q);
			TreeAutomaton a = (TreeAutomaton) automataStack.peek();
			a.addState(q);
			Iterator<TAState> i = finalChoiceStates.pop().iterator();
			while (i.hasNext()) {
				TAState src = (TAState) i.next();
				a.addTransition(new EpsTransition(src, q));
			}
			if (inChoice() && notInSequence()) {
				finalChoiceStates.peek().add(q);
			}
		}
		int[] minmax = maxminOccurs.pop();
		if (minmax[0] == 0 && minmax[1] == -1)
			endStar();
		if (minmax[0] == 1 && minmax[1] == -1)
			endPlus();
	}

	private void endEmpty() {
		if (inChoice() && notInSequence()) {
			finalChoiceStates.peek().add(stateStack.pop());
		}
	}

	private void endTypeName() {
		if (inChoice() && notInSequence()) {
			finalChoiceStates.peek().add(stateStack.pop());
		}
	}

	private void endAnyInt() {
		Transition l = null;
		StatePair pair = getSrcDst();
		int[] vars = getVariables();
		l = new IntTransition(pair.src, pair.dst, vars);
		((TreeAutomaton) automataStack.peek()).addTransition(l);
		if (inChoice() && notInSequence()) {
			finalChoiceStates.peek().add(stateStack.pop());
		}
		literal = "";
	}

	private void endAnyString() {
		Transition l = null;
		StatePair pair = getSrcDst();
		int[] vars = getVariables();
		l = new StringTransition(pair.src, pair.dst, vars);
		((TreeAutomaton) automataStack.peek()).addTransition(l);
		if (inChoice() && notInSequence()) {
			finalChoiceStates.peek().add(stateStack.pop());
		}
		literal = "";
	}

	private void endIntLit() {
		Transition l = null;
		StatePair pair = getSrcDst();
		int[] vars = getVariables();
		l = new IntTransition(Integer.parseInt(literal.trim()), pair.src, pair.dst, vars);
		((TreeAutomaton) automataStack.peek()).addTransition(l);
		if (inChoice() && notInSequence())
			finalChoiceStates.peek().add(stateStack.pop());
		literal = "";
	}

	private void endBottom() {
		// creates a transition that cannot match
		StatePair pair = getSrcDst();
		Transition l = new LabelledTransition(new LabelSet(MatchedType.MATCH_LABELS), pair.src, pair.dst, null,
				getVariables());
		automataStack.peek().addTransition(l);
	}

	private void endStrLit() {
		Transition l = null;
		StatePair pair = getSrcDst();
		int[] vars = getVariables();
		l = new StringTransition(literal, pair.src, pair.dst, vars);
		((TreeAutomaton) automataStack.peek()).addTransition(l);
		if (inChoice() && notInSequence()) {
			finalChoiceStates.peek().add(stateStack.pop());
		}
		literal = "";
	}

	private void endVoid() {
		Transition l = null;
		StatePair pair = getSrcDst();
		l = new EpsTransition(pair.src, pair.dst);
		((TreeAutomaton) automataStack.peek()).addTransition(l);
		if (inChoice() && notInSequence()) {
			finalChoiceStates.peek().add(stateStack.pop());
		}
	}
	private void endElement(){
		TreeAutomaton lastTA = automataStack.pop();
		if (lastTA == null) return;
		lastTA.setFinal(stateStack.pop());
		while (variableStack.pop().intValue() != -1)
			;
		if (inChoice() && notInSequence())
			// if the top element is a choice the last state onto the stack need
			// to
			// be added to the final state
			// for this branch of the choice
			finalChoiceStates.peek().add(stateStack.pop());
	}

	private String endElementToXML(String namespaceURI, String localName, String qName) {
		return "</" + localName + ">";
	}

	/**
	 * @see org.xml.sax.ContentHandler#endElement(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
		if (KEEP_XML) {
			this.XMLread += endElementToXML(namespaceURI, localName, qName);
		}
		if (!nodeStack.isEmpty())
			nodeStack.pop();
		if (localName == PATTERN_ROOT)
			endPatternRoot();
		else if (localName == TYPE_ROOT)
			endTypeRoot();
		else if (localName == TYPE_DEFINITION)
			endTypeDefinition();
		else if (localName == TYPE_DECLARATION_ROOT)
			endTypeDeclRoot();
		else if (localName == LABEL)
			endLabel();
		else if (localName == LABEL_NAME)
			endLabelConstant();
		else if (localName == CHAN)
			endChan();
		else if (localName == SEQUENCE)
			endSequence();
		// else if (localName == STAR) endStar();
		// else if (localName == PLUS) endPlus();
		else if (localName == BIND)
			endBind();
		else if (localName == CHOICE)
			endChoice();
		else if (localName == EMPTY)
			endEmpty();
		else if (localName == ANY_INT)
			endAnyInt();
		else if (localName == ANY_STRING)
			endAnyString();
		else if (localName == INT_LIT)
			endIntLit();
		else if (localName == STR_LIT)
			endStrLit();
		else if (localName == KTYPE)
			endTypeName();
		else if (localName == ELEMENT)
			endElement();
		else if (localName == VOID)
			endVoid();
		else if (localName == BOTTOM)
			endBottom();
		else
			throw new PatternParseException("Unexpected element " + localName);
		if (firstOfSequence)
			firstOfSequence = false;
	}

	/**
	 * @see org.xml.sax.ContentHandler#characters(char[], int, int)
	 */
	public void characters(char[] ch, int start, int length) throws SAXException {
		if (KEEP_XML)
			this.XMLread += new String(ch, start, length);
		if (!nodeStack.isEmpty()) {
			String top = (String) nodeStack.peek();
			if (top == INT_LIT || top == STR_LIT) {
				literal += new String(ch, start, length);
			} else
				literal = "";
		}
	}

	/**
	 * @see org.xml.sax.ContentHandler#ignorableWhitespace(char[], int, int)
	 */
	public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
		// do nothing
	}

	/**
	 * @see org.xml.sax.ContentHandler#processingInstruction(java.lang.String,
	 *      java.lang.String)
	 */
	public void processingInstruction(String target, String data) throws SAXException {
		// do nothing
	}

	/**
	 * @see org.xml.sax.ContentHandler#skippedEntity(java.lang.String)
	 */
	public void skippedEntity(String name) throws SAXException {
		// do nothing
	}

	/**
	 * @see org.xml.sax.ErrorHandler#warning(org.xml.sax.SAXParseException)
	 */
	public void warning(SAXParseException exception) throws SAXException {
		System.out.println("Warning: " + exception.toString());
	}

	/**
	 * @see org.xml.sax.ErrorHandler#error(org.xml.sax.SAXParseException)
	 */
	public void error(SAXParseException exception) throws SAXException {
		System.out.println("Error: " + exception.toString());
	}

	/**
	 * @see org.xml.sax.ErrorHandler#fatalError(org.xml.sax.SAXParseException)
	 */
	public void fatalError(SAXParseException exception) throws SAXException {
		System.out.println("Fatal Error: " + exception.toString());
	}

	/**
	 * Returns the variables to use for the labelled transition. It reads until
	 * -1 is read on the stack of bindings
	 * 
	 * @return an array of variables
	 */
	private int[] getVariables() {
		if (!(variableStack.size() > 1))
			return (new int[0]);
		Vector<Integer> vars = new Vector<Integer>();
		int i = variableStack.size() - 1;
		Integer var = variableStack.get(i);
		while (var.intValue() != -1) {
			vars.add(var);
			i--;
			var = (Integer) variableStack.get(i);
		}
		int[] variables = new int[vars.size()];
		for (i = 0; i < vars.size(); i++) {
			variables[i] = ((Integer) vars.get(i)).intValue();
		}
		return variables;
	}

	/**
	 * Returns true if the current element is a child of a choice
	 * 
	 * @return true if the current element is a child of a choice, false
	 *         otherwise
	 */
	private boolean inChoice() {
		String topElement;
		for (int j = nodeStack.size() - 1; j >= 0; j--) {
			topElement = (String) nodeStack.get(j);
			if (topElement.equalsIgnoreCase(CHOICE))
				return true;
			else if (topElement.equalsIgnoreCase(BIND))
				continue;
			else if (topElement.equalsIgnoreCase(LABEL_NAME))
				continue;
			else if (topElement.equalsIgnoreCase(INT_LIT))
				continue;
			else if (topElement.equalsIgnoreCase(STR_LIT))
				continue;
			else if (topElement.equalsIgnoreCase(ANY_INT))
				continue;
			else if (topElement.equalsIgnoreCase(ANY_STRING))
				continue;
			// else if (firstOfSequence && !topElement.equalsIgnoreCase(LABEL)
			// && !topElement.equalsIgnoreCase(CHAN_LABEL)) continue;
			else
				return false;
		}
		return false;
	}

	/**
	 * Returns true if the current element is a child of a sequence
	 * 
	 * @return true if the current element is a child of a sequence, false
	 *         otherwise
	 */
	private boolean notInSequence() {
		String topElement;
		for (int j = nodeStack.size() - 1; j >= 0; j--) {
			topElement = (String) nodeStack.get(j);
			if (topElement.equalsIgnoreCase(SEQUENCE))
				return false;
			else if (topElement.equalsIgnoreCase(BIND))
				continue;
			else if (topElement.equalsIgnoreCase(LABEL_NAME))
				continue;
			else if (topElement.equalsIgnoreCase(LABEL))
				continue;
			else if (topElement.equalsIgnoreCase(CHAN))
				continue;
			else
				return true;
		}
		return true;
	}
}