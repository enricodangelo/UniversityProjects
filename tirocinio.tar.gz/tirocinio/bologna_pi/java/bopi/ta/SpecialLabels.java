/*
 * SpecialLabels.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Mar 3, 2004
 */
package bopi.ta;

/**
 * Special labels used for literals, types and patterns.
 * <ul>
 * <li> ~ is used for any label in patterns and types (like XDUCE) </li>
 * <li> ~String is used for any string in patterns and types </li>
 * <li> ~Int is used for any integer in patterns and types </li>
 * <li> #StrL_ is used as prefix for any string literal and for patterns where string literals are used</li>
 * <li> #IntL_ is used as prefix for any integer literal and for patterns where integer literal are used</li>
 * <li> #ChnL_ is used as prefix for any channel literal (channel literal cannot be used as pattern). 
 * The internal format used for channel literals is the following: #ChnL_&ltTypeName&gt#&lt channel &gt. 
 * In this way channels are always annotated with their type name </li>
 * </ul>
 * @author Samuele Carpineti 
 */
public final class SpecialLabels {
	/** Matches any Label */
	public static final String ANY_LABEL_PATTERN = "~";
	/** Matches any string */
    public static final String ANY_STRING_PATTERN = "~String";
	/** Matches any integer */
    public static final String ANY_INTEGER_PATTERN = "~Int";
	/** Matches any channel (must be present for Any type) */
    public static final String ANY_CHANNEL_PATTERN = "~Chan";
	/** Literals are codified as labels this is the length of each literal prefix (the prefix is not part of the literal)*/
    public static final int LITERAL_PREFIX_LENGTH = 6;
	/** Prefix for string literals */
    public static final String STRING_LITERAL = "#StrL_";
	/** Prefix for integers literals */
    public static final String INTEGER_LITERAL = "#IntL_";
	/** Prefix for channel literals */
    public static final String CHANNEL_LITERAL = "#ChnL_";
    public static final String CHANNEL_TYPE_END = "#";
    /** 
     * Checks if the label is one of  <it>any pattern</it>: any string, any label, any integer
     * @param label - the label to check 
     * @return true if the label represent one of the <it>any pattern<it>
     */
    public static final boolean IS_ANY_PATTERN(String label) {
		return (
			label.equalsIgnoreCase(SpecialLabels.ANY_LABEL_PATTERN)
				|| label.equalsIgnoreCase(SpecialLabels.ANY_STRING_PATTERN)
				|| label.equalsIgnoreCase(SpecialLabels.ANY_INTEGER_PATTERN)
				|| label.startsWith(SpecialLabels.ANY_CHANNEL_PATTERN));
	}
    /** 
     * Checks if the label is any string
     * @param label - the label to check 
     * @return true if the label is any string
     */
    public static final boolean IS_ANY_STRING_PATTERN(final String label) {
		return label.equalsIgnoreCase(SpecialLabels.ANY_STRING_PATTERN);
	}
    /** 
     * Checks if the label is any integer
     * @param label - the label to check 
     * @return true if the label is any integer
     */
    public static final boolean IS_ANY_INTEGER_PATTERN(final String label) {
		return label.equalsIgnoreCase(SpecialLabels.ANY_INTEGER_PATTERN);
	}
    /** 
     * Checks if the label is a string literal
     * @param label - the label to check 
     * @return true if the label is a string literal
     */
    public static final boolean IS_STRING_LITERAL(final String label) {
		return label.startsWith(SpecialLabels.STRING_LITERAL);
	}
    /** 
     * Checks if the label is a channel literal
     * @param label - the label to check 
     * @return true if the label is a channel literal
     */
    public static final boolean IS_CHANNEL_LITERAL(final String label) {
		return label.startsWith(SpecialLabels.CHANNEL_LITERAL);
	}
    /** 
     * Checks if the label is an integer literal
     * @param label - the label to check 
     * @return true if the label is an integer literal
     */
    public static final boolean IS_INTEGER_LITERAL(final String label) {
		return label.startsWith(SpecialLabels.INTEGER_LITERAL);
	}
    /** 
     * Checks if the label is a literal
     * @param label - the label to check 
     * @return true if the label is a literal
     */
    public static final boolean IS_LITERAL(final String label) {
		return (
			label.startsWith(STRING_LITERAL)
				|| label.startsWith(INTEGER_LITERAL)
				|| label.startsWith(CHANNEL_LITERAL));
	}
    /** 
     * Removes the literal prefix 
     * @param annotatedLiteral - the literal 
     * @return  a new string obtained by removing the internal prefix from annotatedLiteral  
     */
    public static final String DEL_LITERAL_PREFIX(String annotatedLiteral) {
		if (!IS_LITERAL(annotatedLiteral))
			return annotatedLiteral;
		return annotatedLiteral.substring(LITERAL_PREFIX_LENGTH);
	}
}
