/*
 * StringLiteral.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 26, 2004
 */
package bopi.values;

import java.io.IOException;
import java.util.Map;
import bopi.ta.SpecialLabels;
import bopi.ta.TreeAutomaton;

/**
 * String Literal is a labelled elements with an empty child (it is always a
 * leaf) (STRING_LITERAL[null])
 * 
 * @author Samuele Carpineti
 */
public class StringLiteral extends Literal {
    private String value;

    /**
     * Builds a new StringLiteral with the specified value
     * 
     * @param value
     *            the literal value
     */
    public StringLiteral(String value) {
        this.value = value;
        this.tagName = SpecialLabels.STRING_LITERAL + value;
    }

    /**
     * Builds a new StringLiteral with the specified value and a specified set
     * of bindings
     * 
     * @param value
     *            the literal value
     */
    StringLiteral(String value, int[] bindings) {
        this(value);
        setBindings(bindings);
    }

    /**
     * @see VNode#marshal()
     */
    public byte[] marshal() {
        return value.getBytes();
    }

    /**
     * Marshals the literal adding a the &lt string &gt label
     * 
     * @return a string representation of value
     * @see VNode#marshalWET()
     */
    public byte[] marshalWET() {
        return ("<string>" + value.toString() + "</string>").getBytes();
    }

    /**
     * Returns the literal value
     * 
     * @return the literal value
     */
    public Object getValue() {
        return value;
    }

    /**
     * Sets the literal value
     * 
     * @param value -
     *            the literal value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Returns a copy of this object
     * 
     * @return a copy of this object
     */
    public Object clone() {
        StringLiteral copy = new StringLiteral(value);
        return copy;
    }

    /**
     * Returns a string representation of the literal
     * 
     * @return a string representation of the literal
     */
    public String toString() {
        return value;
    }

    /**
     * Returns true if the first operand and the second one are equals, false
     * otherwise
     * 
     * @param op1
     *            the first operand
     * @param op2 
     *            the second operand
     * @return true if the first operand and the second one are equals, false
     *         otherwise
     */
    public static boolean eq(final StringLiteral op1, final IntLiteral op2) {
        return op1.value.equals(op2.getValue());
    }

    /**
     * Returns true if the first operand and the second one are equals (ignoring
     * the case), false otherwise
     * 
     * @param op1
     *            the first operand
     * @param op2 
     *            the second operand
     * @return true if the first operand and the second one are equals (ignoring
     *         the case), false otherwise
     */
    public static boolean eqIgnoreCase(final StringLiteral op1,
            final IntLiteral op2) {
        return op1.value.equalsIgnoreCase((String) op2.getValue());
    }

    /**
     * @see Literal#toEmpty()
     */
    public VNode toEmpty() throws ClassCastException {
        if (value.trim().length() > 0 || value.equals("void")) throw new ClassCastException(
                "StringLiteral must be empty");
        return null;
    }

    /**
     * Return the conversion to channel literal
     * 
     * @param typeDefs -
     *            a mpa from schema names to tree automaton
     * @param chType -
     *            the automaton specifying the schema of the data carried by the
     *            channel
     * @return the conversion to a new channel literal
     * @see Literal#toChannelLiteral(Map, TreeAutomaton)
     * @throws VNodeCastException -
     *             if there is a type error during the conversion
     */
    public ChannelLiteral toChannelLiteral(Map typeDefs, TreeAutomaton chType, int capability)
            throws VNodeCastException {
        try {
            return new ChannelLiteral(value, typeDefs, chType, capability, getBindings());
        } catch (IOException e) {
            throw new VNodeCastException(StringLiteral.class,
                    ChannelLiteral.class);
        }
    }

    /**
     * Returns the conversion of this string literal to integer literal
     * 
     * @return the conversion to a new integer literal
     * @throws VNodeCastException
     *             if the string literal cannot be represent as integer literal
     */
    public IntLiteral toIntLiteral() throws VNodeCastException {
        try {
            IntLiteral intLit = new IntLiteral(new Integer(value.trim()),
                    getBindings());
            return intLit;
        } catch (NumberFormatException ex) {
            throw new VNodeCastException(StringLiteral.class, IntLiteral.class);
        }
    }

    /**
     * Copies the string literal into another string literal
     * 
     * @return a copy of this string literal
     */
    public StringLiteral toStringLiteral() {
        return new StringLiteral(value, getBindings());
    }
}