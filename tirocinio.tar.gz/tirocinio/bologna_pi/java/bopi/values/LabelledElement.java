/*
 * Tag.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 26, 2004
 */
package bopi.values;

/**
 * Labelled value: element[node] | element[()]
 * 
 * @author Samuele Carpineti
 */
public class LabelledElement extends VNode {
    /** the child of the labelled element (can be null if the content is empty) */
    private VNode child;

    /** tag name */
    public String tagName;

    /** Default constructor used by subclasses */
    LabelledElement() {
        //do nothing
    }

    /**
     * Builds element[node] if node is a reference to null element[()] is
     * created
     * 
     * @param element 
     *            tag value
     * @param node 
     *            element content
     */
    public LabelledElement(String element, VNode node) {
        tagName = element;
        child = node;
    }

    /**
     * Builds a new labelled element
     * 
     * @param string -
     *            the label
     * @param node -
     *            content
     * @param bindings
     *            -bindings
     */
    public LabelledElement(String string, VNode node, int[] bindings) {
        this(string, node);
        setBindings(bindings);
    }

    /**
     * @return <tag>child.marshal() </tag>
     * @see VNode#marshal()
     */
    public byte[] marshal() {
        String xml = "<" + tagName + ">";
        if (child != null) xml += new String(child.marshal());
        xml += "</" + tagName + ">";
        return xml.getBytes();
    }

    /**
     * @return <tag>child.marshalWET() </tag>
     * @see VNode#marshalWET()
     */
    public byte[] marshalWET() {
        String xml = "<" + tagName + ">";
        if (child != null) xml += new String(child.marshal());
        xml += "</" + tagName + ">";
        return xml.getBytes();
    }

    /**
     * A tag can have only one child so the current is overwritten by using this
     * method
     * 
     * @param n
     *            the node to add
     * @see VNode#addChild(bopi.ta.VNode)
     */
    public void addChild(VNode n) {
        child = n;
    }

    /**
     * @return the child (position is ignored)
     * @see VNode#getChild(int)
     */
    public VNode getChild(int position) {
        return child;
    }

    /**
     * Position is ignored then the unique child is set to n
     * 
     * @see bopi.ta.VNode#setChild(int, VNode)
     */
    public void setChild(int position, VNode n) {
        child = n;
    }

    /**
     * @return the child
     * @see VNode#getChild(int)
     */
    public VNode getChild() {
        return child;
    }

    /**
     * @return 0 if the content is empty 1 otherwise (it can contains a
     *         sequence)
     * @see VNode#getChildrenNumber()
     */
    public int getChildrenNumber() {
        if (this.child == null) return 0;
        return 1;
    }

    /**
     * @return an array with the elment's child
     * @see VNode#getChildren()
     */
    public VNode[] getChildren() {
        VNode[] v = new VNode[1];
        v[0] = this.getChild();
        return v;
    }

    /**
     * Always throws the runtime exception MethodNotSupportedException
     */
    public Object getValue() {
        throw new RuntimeException("The method is not supported");
    }

    /**
     * Returns a string representation of the node
     * 
     * @return 'tag'[child.toString]
     */
    public String toString() {
        String out = new String();
        out += this.bindingsToString();
        out += tagName + "[";
        if (this.getChild() != null) out += this.getChild().toString();
        return out + "]";
    }

    /**
     * Returns a copy of this object
     * 
     * @return a copy of this object
     */
    public Object clone() {
        if (child == null) new LabelledElement(tagName, null);
        if (child == null) return new LabelledElement(tagName, null);
        return new LabelledElement(tagName, (VNode) child.clone());
    }

    /*
     * (non-Javadoc)
     * 
     * @see bopi.values.VNode#eq(bopi.values.VNode, bopi.values.VNode[])
     */
    public boolean eq(VNode node, VNode[] env) {
        if (node instanceof VNodePointer || node instanceof VNodeOperation) { throw new RuntimeException(
                "eq invoked on " + node.getClass()); }
        if (node instanceof Sequence) { return node.eq(this, env); }

        LabelledElement e = (LabelledElement) node;
        return child.eq(node.getChild(0), env) && tagName.equals(e.tagName);

    }
}