/*
 * Created on Mar 5, 2005
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.values;

/**
 * @author samuele
 * 
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class VNodeBinaryOperation extends VNodeOperation {
    private int operation;

    private final static int EQ = 0;

    private final static int ADD = 1;

    private final static int SUB = 2;

    private final static int LT = 3;

    private final static int GT = 4;

    private final static int LEQ = 5;

    private final static int GEQ = 6;

    private int op1;

    private int op2;

    /**
     * @param operation
     * @param op1
     * @param op2
     */
    public VNodeBinaryOperation(String operation, int op1, int op2) {
        if (operation.equals("eq")) this.operation = EQ;
        else if (operation.equals("add")) this.operation = ADD;
        else if (operation.equals("sub")) this.operation = SUB;
        else if (operation.equals("lt")) this.operation = LT;
        else if (operation.equals("gt")) this.operation = GT;
        else if (operation.equals("leq")) this.operation = LEQ;
        else if (operation.equals("geq")) this.operation = GEQ;
        this.op1 = op1;
        this.op2 = op2;
    }

    public VNodeBinaryOperation(int operation, int op1, int op2) {
        this.operation = operation;
        this.op1 = op1;
        this.op2 = op2;
    }

    /*
     * (non-Javadoc)
     * 
     * @see bopi.values.VNodeOperation#evaluate(bopi.values.VNode[])
     */
    public VNode evaluate(VNode[] env) {
        VNode operand1 = VNode.derefer(env, env[op1]);
        VNode operand2 = VNode.derefer(env, env[op2]);
        switch (operation) {
        case EQ:
            if (operand1.eq(operand2, env)) return new IntLiteral(1);
            return new IntLiteral(0);
        case ADD:
            if (operand1 instanceof IntLiteral && operand2 instanceof IntLiteral) return IntLiteral.add(
                    (IntLiteral) operand1, (IntLiteral) operand2);
            throw new RuntimeException("Try to add " + operand1.getClass() + " " + operand2.getClass());
        case SUB:
            if (operand1 instanceof IntLiteral && operand2 instanceof IntLiteral) return IntLiteral.sub(
                    (IntLiteral) operand1, (IntLiteral) operand2);
            throw new RuntimeException("Try to sub " + operand1.getClass() + " " + operand2.getClass());
        case GT:
            if (operand1 instanceof IntLiteral && operand2 instanceof IntLiteral) {
                if (IntLiteral.gt((IntLiteral) operand1, (IntLiteral) operand2)) return new IntLiteral(1);
                else return new IntLiteral(0);
            }
            throw new RuntimeException("> applied to " + operand1.getClass() + " " + operand2.getClass());
        case LT:
            if (operand1 instanceof IntLiteral && operand2 instanceof IntLiteral) {
                if (IntLiteral.lt((IntLiteral) operand1, (IntLiteral) operand2)) {
                    return new IntLiteral(1);
                }  
                return new IntLiteral(0);
            }
            throw new RuntimeException("< applied to " + operand1.getClass() + " " + operand2.getClass());
        case GEQ:
            if (operand1 instanceof IntLiteral && operand2 instanceof IntLiteral) {
                if (IntLiteral.geq((IntLiteral) operand1, (IntLiteral) operand2)) 
                    return new IntLiteral(1);
                return new IntLiteral(0);
            }
            throw new RuntimeException("> applied to " + operand1.getClass() + " " + operand2.getClass());
        case LEQ:
            if (operand1 instanceof IntLiteral && operand2 instanceof IntLiteral){ 
                if (IntLiteral.leq((IntLiteral) operand1, (IntLiteral) operand2))
                    return new IntLiteral(1);
                return new IntLiteral(0);
            }
            throw new RuntimeException("< applied to " + operand1.getClass() + " " + operand2.getClass());
        default:
            throw new RuntimeException("Not Implemented Operator " + operation);
        }
    }

    /** 
     * @see VNode#marshal()
     */
    public byte[] marshal() {
        throw new RuntimeException("An operation must be evaluated before marshalling");
    }

    /*
     * (non-Javadoc)
     * 
     * @see bopi.values.VNode#marshalWET()
     */
    public byte[] marshalWET() {
        throw new RuntimeException("An operation must be evaluated before marshalling");
    }

    /**
     * 
     * @see VNode#getValue()
     */
    public Object getValue() {
        throw new RuntimeException("getValue invoked on " + this.getClass());
    }

    /**
     * 
     * @see VNode#addChild(bopi.values.VNode)
     */
    public void addChild(VNode child) {
        throw new RuntimeException("addChild invoked on " + this.getClass());
    }

    /**
     * 
     * @see VNode#getChild(int)
     */
    public VNode getChild(int position) {
        throw new RuntimeException("getChild invoked on " + this.getClass());
    }

    /**
     * 
     * @see VNode#setChild(int, bopi.values.VNode)
     */
    public void setChild(int position, VNode child) {
        throw new RuntimeException("setChild invoked on " + this.getClass());
    }

    /**
     * 
     * @see VNode#getChildren()
     */
    public VNode[] getChildren() {
        return new VNode[0];
    }

    /**
     * 
     * @see VNode#getChildrenNumber()
     */
    public int getChildrenNumber() {
        return 0;
    }

    /**
     * 
     * @see java.lang.Object#clone()
     */
    public Object clone() {
        return new VNodeBinaryOperation(operation, op1, op2);
    }

    /**
     * 
     * @see VNode#eq(VNode, VNode[])
     */
    public boolean eq(VNode node, VNode[] env) {
        throw new RuntimeException("eq invoked on " + this.getClass());
    }

}