/*
 * MethodNotSupportedException.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 26, 2004
 *
 */
package bopi.values;
/**
 * If the class doesn't implement the method
 * @author Samuele Carpineti 
 */
class MethodNotSupportedException extends RuntimeException {
}
