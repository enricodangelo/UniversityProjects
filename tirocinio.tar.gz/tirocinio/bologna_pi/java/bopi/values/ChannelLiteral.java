/*
 * ChannelLiteral.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 26, 2004
 *
 */
package bopi.values;

import java.io.IOException;
import java.util.Map;
import bopi.ta.SpecialLabels;
import bopi.ta.StaticAnalyzer;
import bopi.ta.TreeAutomaton;
import bopi.ta.WSDLParser;

/**
 * A Channel Literal is the node for representing services. It has the following
 * information:
 * <ol>
 * <li>The address where the channel must be reacheable. It should be either
 * the name given by the channel manager for bopi channels or a URI
 * corresponding to the location of the service</li>
 * <li>The address of the WSDL where (1) the type of the service and (2) the
 * concrete part (protocol +uri) are stored</li>
 * <li></li>
 * </ol>
 * it become more complex. Channel literals are leaves in our trees.
 * 
 * @author Samuele Carpineti
 */
public class ChannelLiteral extends Literal {
    public static int OUT_CAPABILITY = -1;

    public static int IN_CAPABILITY = +1;

    public static int IO_CAPABILITY = 2;

    private int capability = OUT_CAPABILITY;

    public int getCapability() {
        return capability;
    }

    /** the URI where the wsdl is available */
    private String wsdlAddr;

    /** channel name: the URI where the channel is available */
    private String channelAddr;

    /**
     * xml description of the type carried by the channel - it is a map for
     * handling recursion
     */
    private Map typeDefs;

    /** automaton for the schema carried by the channel */
    public TreeAutomaton typeTA;

    /**
     * Builds a new channel literal that can send data of type 'type'
     * 
     * @param channelAddress -
     *            tha channel name
     * @param wsdlAddr -
     *            the URI of the wsdl address
     * @param typeDefs -
     *            a map from schema names to tree automata
     * @param typeTA -
     *            the tree automaton representing the schema carried by the
     *            channel
     * @param capability -
     *            the I/O capability of the channel
     */
    public ChannelLiteral(final String channelAddress, final String wsdlAddr, final Map typeDefs, TreeAutomaton typeTA,
            int capability) {
        this.wsdlAddr = wsdlAddr;
        this.channelAddr = channelAddress;
        String cap = null;
        if (capability == IO_CAPABILITY) cap = "^io";
        if (capability == IN_CAPABILITY) cap = "^i";
        if (capability == OUT_CAPABILITY) cap = "^o";
        this.tagName = SpecialLabels.CHANNEL_LITERAL + "#chan" + cap;
        this.typeDefs = typeDefs;
        this.typeTA = typeTA;
    }

    public String getIPAddress() {
        return channelAddr;
    }

    /**
     * Builds a new channel literal that can send data of type 'type'
     * 
     * @param channelAddress -
     *            tha channel name
     * @param wsdlAddr -
     *            the URI of the wsdl address
     * @param typeDefs -
     *            a map from schema names to tree automata
     * @param typeTA -
     *            the tree automaton representing the schema carried by the
     *            channel
     * @param bindings -
     *            the array of bindings
     */
    public ChannelLiteral(final String channelAddress, final String wsdlAddr, final Map typeDefs, TreeAutomaton typeTA,
            int capability, int[] bindings) {
        this(channelAddress, wsdlAddr.trim(), typeDefs, typeTA, capability);
        setBindings(bindings);
    }

    public ChannelLiteral(final String wsdlAddr, final Map typeDefs, TreeAutomaton typeTA, int capability,
            int[] bindings) throws IOException {
        this(WSDLParser.getChannelAddress(wsdlAddr.trim()), wsdlAddr.trim(), typeDefs, typeTA, capability, bindings);
    }

    public ChannelLiteral(final String wsdlAddr, final Map typeDefs, TreeAutomaton typeTA, int capability)
            throws IOException {
        this(WSDLParser.getChannelAddress(wsdlAddr), wsdlAddr.trim(), typeDefs, typeTA, capability);
    }

    /**
     * Returns the name of the channels
     * 
     * @return the channel name
     */
    public Object getValue() {
        return wsdlAddr;
    }

    /**
     * Returns an array of bytes that represent the channel
     * 
     * @return an array of bytes that represent the channel
     */
    public byte[] marshal() {
        String s = wsdlAddr;
        return s.getBytes();
    }

    /**
     * Marshals the literal adding a the &lt channel &gt label
     * 
     * @return a string representation of value
     * @see VNode#marshalWET()
     */
    public byte[] marshalWET() {
        return ("<channel>" + wsdlAddr + "</channel>").getBytes();
    }

    /**
     * Returns a copy of this object
     * 
     * @return a copy of this object
     */
    public Object clone() {
        try {
            ChannelLiteral copy;
            copy = new ChannelLiteral(channelAddr, wsdlAddr, typeDefs, typeTA, capability, getBindings());
            return copy;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Returns a string representation of the literal
     * 
     * @return 'type': 'channel_name'
     */
    public String toString() {
        return "<" + wsdlAddr + ">";
    }

    /**
     * Returns true if the first channel is equal to the second one, false
     * otherwise
     * 
     * @param op1 -
     *            the first channel
     * @param op2 -
     *            the second channel
     * @return true if the first channel is equal to the second one, false
     *         otherwise
     */
    static public boolean eq(final ChannelLiteral op1, final ChannelLiteral op2) {
        return op1.wsdlAddr.equalsIgnoreCase(op2.wsdlAddr);
    }

    /**
     * Returns the conversion of this channel literal to a string
     * 
     * @return the string literal that represents this channel literal
     * @see Literal#toStringLiteral()
     */
    public StringLiteral toStringLiteral() {
        return new StringLiteral(wsdlAddr);
    }

    /**
     * Returns the conversion of this channel literal to an integer
     * 
     * @return an integer literal that represents this channel literal
     * @see Literal#toIntLiteral()
     * @throws ClassCastException
     *             if the literal cannot be casted to an integer
     */
    public IntLiteral toIntLiteral() throws VNodeCastException {
        try {
            int i = Integer.parseInt(wsdlAddr);
            return new IntLiteral(i, getBindings());
        } catch (NumberFormatException ex) {
            throw new VNodeCastException(ChannelLiteral.class, IntLiteral.class);
        }
    }

    /**
     * Copies the channel literal into a new channel literal
     * 
     * @param typeDefs -
     *            a map from schema names to tree automata
     * @param typeTA -
     *            the tree automaton representing the schema carried by the
     *            channel
     * @return a clone of this channel literal
     * @see Literal#toChannelLiteral(Map,TreeAutomaton)
     */
    public ChannelLiteral toChannelLiteral(Map typeDefs, TreeAutomaton typeTA, int capability) {
        return (ChannelLiteral) clone();
    }

    /**
     * Returns the conversion of this channel literal into an empty literal
     * 
     * @throws VNodeCastException
     *             if the channel literal is not empty
     * @see Literal#toEmpty()
     * @return the representation of empty (null)
     */
    public VNode toEmpty() throws VNodeCastException {
        if (wsdlAddr.length() > 0) throw new VNodeCastException(ChannelLiteral.class, null);
        return null;
    }

    /**
     * Returns true if the node is equal to this node.
     * 
     * @param node -
     *            the node to compare with
     * @param env -
     *            the environment in which look-up node pointers
     * @return true if the node is equal to this node, false otherwise
     * @see VNode#eq(bopi.values.VNode, bopi.values.VNode[])
     */
    public boolean eq(VNode node, VNode[] env) {
        if (node instanceof VNodePointer) {
            VNodePointer pointer = (VNodePointer) node;
            return eq(env[pointer.getEnvIndex()], env);
        }
        if (node instanceof Sequence) {
            return node.eq(this, env);
        } else if (node instanceof ChannelLiteral) {
            ChannelLiteral chan = (ChannelLiteral) node;
            return (wsdlAddr.equals(chan.wsdlAddr) || (StaticAnalyzer.isSubtype(chan.typeTA, typeTA) && StaticAnalyzer
                    .isSubtype(chan.typeTA, typeTA)));
        } else return false;
    }
}