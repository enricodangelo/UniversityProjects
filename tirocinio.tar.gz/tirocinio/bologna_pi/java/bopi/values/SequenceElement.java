/**
 * SequenceElement.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Mar 20, 2004
 */
package bopi.values;

/**
 * An element in a sequence is a pair (value,next)
 * 
 * @author Samuele Carpineti
 */
public class SequenceElement extends VNode {
    /**
     * Builds a new sequence element
     * 
     * @param value -
     *            the value
     * @param next -
     *            the element that follows the current one (is nul if the
     *            element is the last of the sequencel)
     */
    public SequenceElement(VNode value, SequenceElement next) {
        this.value = value;
        this.next = next;
    }

    /** The value field of the sequence element */
    private VNode value;

    /** The next element in the sequence */
    private SequenceElement next;

    /**
     * @return the next element
     */
    public SequenceElement getNext() {
        return next;
    }

    /**
     * Set the next element
     * 
     * @param value
     */
    void setNext(SequenceElement value) {
        next = value;
    }

    /**
     * @return the value of this element
     */
    public VNode getElementValue() {
        return value;
    }

    /**
     * @see VNode#marshal()
     */
    public byte[] marshal() {
        return value.marshal();
    }

    /**
     * @see VNode#marshalWET()
     */
    public byte[] marshalWET() {
        return value.marshalWET();
    }

    /**
     * @see VNode#addChild(VNode)
     */
    public void addChild(VNode n) {
        value.addChild(n);
    }

    /**
     * @see VNode#getChild(int)
     */
    public VNode getChild(int position) {
        return value.getChild(position);
    }

    /**
     * @see VNode#setChild(int, bopi.ta.VNode)
     */
    public void setChild(int position, VNode child) {
        value.setChild(position, child);
    }

    /**
     * @see VNode#getChildren()
     */
    public VNode[] getChildren() {
        return value.getChildren();
    }

    /**
     * @see VNode#getChildrenNumber()
     */
    public int getChildrenNumber() {
        return value.getChildrenNumber();
    }

    /**
     * Returns true if the element is not at the end of the sequence, false
     * otherwise
     * 
     * @return true if the element is followed by another element, false if it's
     *         the last of the sequence
     */
    public boolean hasNext() {
        return (next != null);
    }

    /**
     * Deletes all the annotations in the sequence
     */
    public void clearAnnotations() {
        value.clearAnnotations();
    }

    /**
     * Always throws the runtime exception MethodNotSupportedException
     */
    public Object getValue() {
		throw new RuntimeException("The method is not supported");
    }

    public String toString() {
        return value.toString();
    }

    /**
     * Returns a copy of this object
     * 
     * @return a copy of this object
     */
    public Object clone() {
        throw new RuntimeException(
                "SequenceElement cannot be cloned ... sequence must handle its elements");
    }

    /**
     * @see VNode#eq(bopi.values.VNode, bopi.values.VNode[])
     */
    public boolean eq(VNode node, VNode[] env) {
        if (node instanceof VNodePointer || node instanceof VNodeOperation) {
            throw new RuntimeException("eq invoked on " + node.getClass());
        } else if (node instanceof SequenceElement) {
            SequenceElement se = (SequenceElement) node;
            return value.eq(se.getElementValue(), env);
        } else return value.eq(node, env);
    }
}