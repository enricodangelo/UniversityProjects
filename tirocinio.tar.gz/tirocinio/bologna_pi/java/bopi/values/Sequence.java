/*
 * Sequence.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 26, 2004
 */
package bopi.values;
import java.util.Vector;
/**
 * A sequence is a list of values. Values are stored in a container and are pairs (value, next). 
 * @author Samuele Carpineti 
 */
public class Sequence extends VNode {
	/** Children container. It contains SequenceElement objects */
	protected Vector<SequenceElement> children= new Vector<SequenceElement>();
	/** 
	 * Returns an array of bytes that represent the sequence. No explicit information 
	 * about the type is added here. Restriction on types should avoid ambigous types like
	 * int,int that the receiver can read like a single string. The constraint must be ensure by the type system 
	 * so here no ckecks ane performed.
	 * @return given a string representation of this Sequence
	 */
	public byte[] marshal() {
		String xml= new String();
		for (int i= 0; i < children.size(); i++) {
			VNode child= children.get(i);
			xml += new String(child.marshal());
		}
		return xml.getBytes();
	}
    /** 
     * Returns an array of bytes that represent the sequence. No explicit information 
     * about the type is added here. Restriction on types should avoid ambigous types like
     * int,int that the receiver can read like a single string. The constraint must be ensure 
     * by the type system so here no ckecks ane performed. It calls child.marshalWET() 
     * for any child.
     * @return given a string representation of this Sequence
     */
	public byte[] marshalWET() {
		String xml= new String();
		for (int i= 0; i < children.size(); i++) {
			VNode child= (SequenceElement) children.get(i);
			xml += new String(child.marshalWET());
		}
		return xml.getBytes();
	}
	/**
	 * If the node to add is the empty sequence () (void) the element is
	 * not added, otherwise the element is added to the sequence
	 * @param node - the node to add 
	 */
	public void addChild(final VNode node) {
		if (node == null)
			return;
		if (node instanceof Sequence){
				for (int i = 0 ; i < node.getChildrenNumber(); i++)
					addChild(node.getChild(i));
		}
		else {
			SequenceElement s= new SequenceElement(node, null);
			if (children.size() > 0)
				 ((SequenceElement) children.lastElement()).setNext(s);
			children.add(s);
		}
	}
	/**
	 * @return the child at the specified position 
	 * @param position - the child's position
	 * @see VNode#getChild(int)
	 */
	public VNode getChild(int position) {
		return (SequenceElement) children.get(position);
	}
	public SequenceElement getFirst() {
		return (SequenceElement) children.get(0);
	}
	public SequenceElement getLast() {
		return (SequenceElement) children.lastElement();
	}
	/** 
	 * Sets the i-th child (if the node is an Empty node method
	 * returns immediatly without effects)
	 * @param position - the child's position
	 * @param n - the node to add (if the node is null is not added to the sequence)
	 * @see VNode#setChild(int, VNode)
	 */
	public void setChild(int position, VNode n) {
		SequenceElement next= ((SequenceElement) children.get(position)).getNext();
		if (n instanceof Sequence){
			System.err.println("----");
		}
		SequenceElement s= new SequenceElement(n, next);
		if (position > 0) {
			SequenceElement previous= (SequenceElement) children.get(position - 1);
			previous.setNext(s);
		}
		children.set(position, s);
	}
	public void removeNull(){
		while (children.remove(null));
	}
	/**
	 * Returns the number of the children of this sequence
	 * @return number of children 
	 * @see VNode#getChildrenNumber()
	 */
	public int getChildrenNumber() {
		return children.size();
	}
	/** 
	 * Returns the children list
	 * @return an array that contains the list of the children 
	 */
	public VNode[] getChildren() {
		VNode[] nodes= new VNode[this.getChildrenNumber()];
		for (int i= 0; i < children.size(); i++)
			nodes[i]= (VNode) children.get(i);
		return nodes;
	}
	/**
	 * Always throws the runtime exception MethodNotSupportedException
	 */
	public Object getValue() {
		throw new RuntimeException("The method is not supported");
	}
	/** 
	 * Returns a string representation of this sequence 
	 * @return a string representation of this sequence
	 */
	public String toString() {
		String out= new String();
		VNode[] nodes= this.getChildren();
		for (int i= 0; i < nodes.length; i++)
			out += nodes[i].toString();
		return out;
	}
	/**
	 * Clones this sequence
	 * @return a clone of this object
	 */
	public Object clone() {
		Sequence seq= new Sequence();
		for (int i= 0; i < getChildrenNumber(); i++) {
			VNode childValue= ((SequenceElement) getChild(i)).getElementValue();
			seq.addChild((VNode) childValue.clone());
		}
		return seq;
	}
	/** 
	 * @see VNode#eq(bopi.values.VNode, bopi.values.VNode[])
	 */
	public boolean eq(VNode node, VNode[] env) {
		if (node == null) return children.size() == 0;
		if (node.getChildrenNumber() != children.size()) return false;
		boolean eq= true;
		for (int i=1; i<children.size() && eq; i++){
			 eq = getChild(i).eq(node.getChild(i),env);
		}
		return eq;
	}
}
