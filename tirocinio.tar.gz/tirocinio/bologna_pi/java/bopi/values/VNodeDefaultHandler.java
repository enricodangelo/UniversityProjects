/*
 * VNodeContentHandler.java
 * project: BolognaPi
 * @author Samuele Carpinetire
 * Created on Mar 5, 2004
 */
package bopi.values;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXParseException;
import java.util.Stack;
import org.xml.sax.XMLReader;
import bopi.ta.HandlerCallback;
/**
 * Default VNode handler. It builds a VNode parsing  XML fragments.
 * It does not handle attributes.
 * @author Samuele Carpineti 
 */
public class VNodeDefaultHandler implements ContentHandler, ErrorHandler {
	private VNode root;
	private Stack<VNode> nodeStack = new Stack<VNode>();
	private Literal lastLiteral;
	private Locator locator;
	private boolean VNODE_ROOT_ISPARSED = false;
	public final static String VNODE_ROOT = "value";
	public final static String VNODE_LOAD = "load";
	public final static String VNODE_EQOP = "eq";
	public final static String VNODE_ADD = "add";
	public final static String VNODE_SUB = "sub";
	public final static String VNODE_LEQ = "leq";
	public final static String VNODE_GEQ = "geq";
	public final static String VNODE_LT = "lt";
	public final static String VNODE_GT = "gt";
	public final static String VNODE_LOAD_ATTR = "value";
	public final static String VNODE_NAMESPACE = "http://www.cs.unibo.it/fusion/BoPi";
	public final static String VNODE_STRINGLIT = "strLit";
	public final static String VNODE_INTLIT = "intLit";
	private int valueCounter = 0;
	private XMLReader parser;
	private HandlerCallback taRequester;
	private ContentHandler oldContentHandler;
	private ErrorHandler oldErrorHandler;
	/** This property must be set to true in order to add empty string literals between labelled element */
	static public boolean ADD_EMPTY_STRLIT = false;
	static public void setParserHandler(XMLReader parser, HandlerCallback h) {
		VNodeDefaultHandler v = new VNodeDefaultHandler();
		v.oldContentHandler = parser.getContentHandler();
		v.oldErrorHandler = parser.getErrorHandler();
		v.taRequester = h;
		v.parser = parser;
		parser.setContentHandler(v);
		parser.setErrorHandler(v);
	}
	/** 
	 * Resets internal fields allowing use the same handler many times 
	 */
	protected void reset() {
		valueCounter = 0;
		root = null;
		nodeStack.clear();
		lastLiteral = null;
	}
	/**
	 * @see org.xml.sax.ContentHandler#setDocumentLocator(org.xml.sax.Locator)
	 */
	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}
	/**
	 * @see org.xml.sax.ContentHandler#startDocument()
	 */
	public void startDocument() throws SAXException {
	}
	/**
	 * @see org.xml.sax.ContentHandler#endDocument()
	 */
	public void endDocument() throws SAXException {
	}
	/**
	 * @see org.xml.sax.ContentHandler#startPrefixMapping(java.lang.String, java.lang.String)
	 */
	public void startPrefixMapping(String prefix, String uri) throws SAXException {
		// do nothing
	}
	/**
	 * @see org.xml.sax.ContentHandler#endPrefixMapping(java.lang.String)
	 */
	public void endPrefixMapping(String prefix) throws SAXException {
		// do nothing
	}
	/** 
	 * @see org.xml.sax.ContentHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
	 */
	public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
		throws SAXException {
		if (localName == VNODE_ROOT) valueCounter++;
		if (localName == VNODE_ROOT && valueCounter == 1) {
			VNODE_ROOT_ISPARSED = true;
			return;
		}
		lastLiteral = null;
		VNode element = null;
		if (localName == VNODE_LOAD && namespaceURI == VNODE_NAMESPACE) {
			element = new VNodePointer(new Integer(atts.getValue(VNODE_LOAD_ATTR)).intValue());
		} else if (localName == VNODE_INTLIT && namespaceURI == VNODE_NAMESPACE) {
			element = new IntLiteral(0);
			lastLiteral = (IntLiteral) element;
		} else if (localName == VNODE_STRINGLIT && namespaceURI == VNODE_NAMESPACE) {
			element = new StringLiteral("");
			lastLiteral = (Literal) element;
		} else if (localName == VNODE_EQOP && namespaceURI == VNODE_NAMESPACE) {
			element =
				new VNodeBinaryOperation(
					localName,
					Integer.parseInt(atts.getValue("op1")),
					Integer.parseInt(atts.getValue("op2")));
		} else if (localName == VNODE_ADD && namespaceURI == VNODE_NAMESPACE) {
			element =
				new VNodeBinaryOperation(
					localName,
					Integer.parseInt(atts.getValue("op1")),
					Integer.parseInt(atts.getValue("op2")));
		} else if (localName == VNODE_SUB && namespaceURI == VNODE_NAMESPACE) {
			element =
				new VNodeBinaryOperation(
					localName,
					Integer.parseInt(atts.getValue("op1")),
					Integer.parseInt(atts.getValue("op2")));
		} else if (localName == VNODE_LT && namespaceURI == VNODE_NAMESPACE) {
			element =
				new VNodeBinaryOperation(
					localName,
					Integer.parseInt(atts.getValue("op1")),
					Integer.parseInt(atts.getValue("op2")));
		} else if (localName == VNODE_GT && namespaceURI == VNODE_NAMESPACE) {
			element =
				new VNodeBinaryOperation(
					localName,
					Integer.parseInt(atts.getValue("op1")),
					Integer.parseInt(atts.getValue("op2")));
		} else if (localName == VNODE_GEQ && namespaceURI == VNODE_NAMESPACE) {
			element =
				new VNodeBinaryOperation(
					localName,
					Integer.parseInt(atts.getValue("op1")),
					Integer.parseInt(atts.getValue("op2")));
		} else if (localName == VNODE_LEQ && namespaceURI == VNODE_NAMESPACE) {
			element =
				new VNodeBinaryOperation(
					localName,
					Integer.parseInt(atts.getValue("op1")),
					Integer.parseInt(atts.getValue("op2")));
		} else
			element = new LabelledElement(localName, null);
		if (root == null) {
			nodeStack.clear();
			root = element;
		} else if (nodeStack.empty()) {
			//top level sequence
			addBrother(element);
		} else if (!(nodeStack.peek() instanceof Literal)) {
			VNode parent =  nodeStack.peek();
			addChild(parent, element);
		} else {
			throw new RuntimeException("Unexpected value in parsing");
		}
		nodeStack.push(element);
	}
	private void addBrother(VNode element) {
		if (root instanceof Sequence) {
			root.addChild(element);
			if (!(element instanceof StringLiteral) && ADD_EMPTY_STRLIT)
				root.addChild(new StringLiteral(""));
		} else {
			VNode oldRoot = root;
			root = new Sequence();
			if (!(oldRoot instanceof StringLiteral) && ADD_EMPTY_STRLIT)
				root.addChild(new StringLiteral(""));
			root.addChild(oldRoot);
			if (!(element instanceof StringLiteral) && ADD_EMPTY_STRLIT)
				root.addChild(new StringLiteral(""));
			root.addChild(element);
			if (!(element instanceof StringLiteral) && ADD_EMPTY_STRLIT)
				root.addChild(new StringLiteral(""));
		}
	}
	private void addChild(VNode parent, VNode child) {
			if (parent instanceof LabelledElement) {
				VNode oldChild = parent.getChild(0);
				if (oldChild == null) { //empty content model
					if (!(child instanceof StringLiteral) && ADD_EMPTY_STRLIT) {
						Sequence sequence = new Sequence();
						sequence.addChild(new StringLiteral(""));
						sequence.addChild(child);
						sequence.addChild(new StringLiteral(""));
						parent.setChild(0, sequence);
					} else
						parent.setChild(0, child);
				} else if (oldChild instanceof Sequence) {
					VNode last = ((Sequence) oldChild).getLast().getElementValue();
					if (!(last instanceof StringLiteral) && !(child instanceof StringLiteral) && ADD_EMPTY_STRLIT)
						oldChild.addChild(new StringLiteral(""));
					oldChild.addChild(child);
				} else {
					Sequence sequence = new Sequence();
					if (!(parent.getChild(0) instanceof StringLiteral) && ADD_EMPTY_STRLIT)
						sequence.addChild(new StringLiteral(""));
					sequence.addChild(parent.getChild(0));
					sequence.addChild(child);
					sequence.addChild(new StringLiteral(""));
					parent.setChild(0, sequence);
				}
			}
	}
	/**
	 * @see org.xml.sax.ContentHandler#endElement(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
		if (localName == VNODE_ROOT)
			valueCounter--;
		if (localName == VNODE_ROOT && valueCounter == 0) {
			if (parser != null) {
				parser.setContentHandler(oldContentHandler);
				parser.setErrorHandler(oldErrorHandler);
			}
			if (taRequester != null) {
				taRequester.setVNode(getVNode());
				reset();
			}
		} else {
			VNode element = nodeStack.pop();
			if (element instanceof LabelledElement) {
				//void is not a network type if there are no characters then and emtpy literal is used.
				if (element.getChild(0) == null && ADD_EMPTY_STRLIT)
					element.setChild(0, new StringLiteral(""));
				if (element.getChild(0) instanceof Sequence) {
					Sequence sequence = (Sequence) element.getChild(0);
					if (!(sequence.getLast().getElementValue() instanceof StringLiteral) && ADD_EMPTY_STRLIT) {
						sequence.addChild(new StringLiteral(""));
					}
				}
			}
			lastLiteral = null;
		}
	}
	/**
	 * @see org.xml.sax.DocumentHandler#characters(char[], int, int)
	 */
	public void characters(char[] ch, int start, int length) throws SAXException {
		if (!VNODE_ROOT_ISPARSED)
			return;
		String content = new String(ch, start, length);
		if (content == null)
			content = "";
		if (lastLiteral == null) {
			lastLiteral = new StringLiteral(content);
			if (!nodeStack.empty()) {
				VNode parent = nodeStack.peek();
				addChild(parent, lastLiteral);
			} else if (root==null){
				root = lastLiteral;
			} else addBrother(lastLiteral);
			return;
		} else if (lastLiteral instanceof IntLiteral) {
			IntLiteral il = (IntLiteral) lastLiteral;
			il.setValue(Integer.parseInt(il.getValue().toString() + content));
		} else if (lastLiteral instanceof StringLiteral) {
			StringLiteral sl = (StringLiteral) lastLiteral;
			sl.setValue(sl.getValue() + content);
		}
	}
	/**
	 * @see org.xml.sax.DocumentHandler#ignorableWhitespace(char[], int, int)
	 */
	public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
		System.err.println("Whitespaces cannot be ignored");
	}
	/**
	 * @see org.xml.sax.DocumentHandler#processingInstruction(java.lang.String, java.lang.String)
	 */
	public void processingInstruction(String target, String data) throws SAXException {
		// processing instruction are not part of the data
		// then do nothing
	}
	/**
	 * @see org.xml.sax.ContentHandler#skippedEntity(java.lang.String)
	 */
	public void skippedEntity(String name) throws SAXException {
		// identities are not part of the data 
		// then do nothing
	}
	/**
	 * @see org.xml.sax.ErrorHandler#warning(org.xml.sax.SAXParseException)
	 */
	public void warning(SAXParseException exception) throws SAXException {
		System.out.println("Warning: " + exception.toString());
	}
	/**
	 * @see org.xml.sax.ErrorHandler#error(org.xml.sax.SAXParseException)
	 */
	public void error(SAXParseException exception) throws SAXException {
		System.out.println("Error: " + exception.toString());
	}
	/** 
	 * @see org.xml.sax.ErrorHandler#fatalError(org.xml.sax.SAXParseException)
	 */
	public void fatalError(SAXParseException exception) throws SAXException {
		System.out.println("Fatal Error: " + exception.toString());
	}
	public VNode getVNode() {
		return root;
	}
}
