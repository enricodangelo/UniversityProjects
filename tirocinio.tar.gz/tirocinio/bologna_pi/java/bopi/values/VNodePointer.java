/*
 * VNodePointer.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Mar 29, 2004
 */
package bopi.values;


/**
 * A VNode pointer is used for load operations that create reference in the environment.
 * This value can be <it>dereferenced</it> only at runtime.
 * @author Samuele Carpineti
 */
public class VNodePointer extends VNode {
	/** 
	 * Pointed value is an index in the environment
	 */
	protected int node;
	/**
	 * Builds a new pointer to node
	 * @param index - the node to point to
	 */
	public VNodePointer(int index) {
		this.node= index;
	}
	/**
     * Always throws a runtime exception because this method cannot be invoked on  pointers
     */
	public byte[] marshal() {
	    throw new RuntimeException("marshal invoked on "+this.getClass());
	}
    /**
     * Always throws a runtime exception because this method cannot be invoked on  pointers
     */
    public byte[] marshalWET() {
        throw new RuntimeException("marshal invoked on "+this.getClass());
    }
	/**
	 * Always throws a runtime exception because this method cannot be invoked on  pointers
	 */
	public Object getValue() {
        throw new RuntimeException("getValue invoked on "+this.getClass());
	}
	/**
     * Always throws a runtime exception because this method cannot be invoked on  pointers
     */
	public void addChild(VNode n) {
        throw new RuntimeException("addChild invoked on "+this.getClass());
	}
	/**
     * Always throws a runtime exception because this method cannot be invoked on  pointers
     */
	public VNode getChild(int position) {
        //throw new RuntimeException("getChild invoked on "+this.getClass());
        return null;
	}
	/**
     * Always throws a runtime exception because this method cannot be invoked on  pointers
     */
	public void setChild(int position, VNode child) {
        throw new RuntimeException("setChild invoked on "+this.getClass());
	}
	/**
     * Always throws a runtime exception because this method cannot be invoked on  pointers
     */
	public VNode[] getChildren() {
        //throw new RuntimeException("getChildren invoked on "+this.getClass());
        return new VNode[0];
	}
	/**
     * Always throws a runtime exception because this method cannot be invoked on  pointers
     */
	public int getChildrenNumber() {
        //throw new RuntimeException("getChildrenNumber invoked on "+this.getClass());
        return 0;
	}
    /**
     * Returns the index pointed by this pointer
     * @return the index pointed by this pointer
     */
    public int getEnvIndex(){
        return node;
    }
    /**
     * Returns a string representation of this node
     * @return a string representation of this node
     */
    public String toString(){
        return "Env[" + node + "]";
    }
    /**
     * @return a copy of this object
     */
    public Object clone(){
        VNodePointer copy= new VNodePointer(node);
        return copy;
    }
	/**
	 * Throws a runtime exception
	 * @see bopi.values.VNode#eq(bopi.values.VNode, VNode[])
	 */
	public boolean eq(VNode node, VNode[] env) {
		throw new RuntimeException("eq invoked on "+this.getClass());
	}
}
