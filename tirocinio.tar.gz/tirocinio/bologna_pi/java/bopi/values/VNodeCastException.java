/*
 * VNodeCastException.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Jul 16, 2004
 */
package bopi.values;

/**
 * This exception can be thrown whenever a node is converted into another node
 * of a different and not appropriate type
 * 
 * @author Samuele Carpineti
 */
public class VNodeCastException extends Exception {
  
	/**
	 * 
	 */
	private static final long serialVersionUID = 3258417209566377779L;

	private Class from;

    private Class to;

    /**
     * Constructs a new VNodeCastException
     * 
     * @param from -
     *            the name of the class of the element that should be converted
     */
    public VNodeCastException(Class from) {
        this.from = from;
    }

    /**
     * Constructs a new VNodeCastException
     * 
     * @param from -
     *            the name of the class of the element that should be converted
     * @param to -
     *            the name of the destination class
     */
    public VNodeCastException(Class from, Class to) {
        this.from = from;
        this.to = to;
    }

    public String toString() {
        if (to == null) return "Error converting the class " + from;
        return "Error converting the class " + from + " to " + to;
    }
}