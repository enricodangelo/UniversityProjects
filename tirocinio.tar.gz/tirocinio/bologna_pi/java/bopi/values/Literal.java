/*
 * Literal.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Mar 17, 2004
 */
package bopi.values;

import java.util.Map;

import bopi.ta.TreeAutomaton;

/**
 * A Literal is a base datatype (so it will be String | Int | Chan in the
 * current implementation). Literals are leaves in our trees.
 * 
 * @author Samuele Carpineti
 */
public abstract class Literal extends LabelledElement {
    public static final boolean IS_DEREFERENCED = true;

    /**
     * Always throws the runtime exception MethodNotSupportedException because a
     * literal cannot have children
     * 
     * @see VNode#addChild(VNode)
     */
    public void addChild(VNode n) {
		throw new RuntimeException("The method is not supported");
    }

    /**
     * Always returns null because a literal has not children
     * 
     * @return null
     * @see VNode#getChild(int)
     */
    public VNode getChild(int position) {
        return null;
    }

    /**
     * Always throws the runtime exception MethodNotSupportedException because a
     * literal cannot have children
     * 
     * @see VNode#getChild(int,VNode)
     */
    public void setChild(int position, VNode n) {
		throw new RuntimeException("The method is not supported");
    }

    /**
     * Always returns 0 because a literal cannot have children
     * 
     * @return 0
     * @see VNode#getChildrenNumber()
     */
    public int getChildrenNumber() {
        return 0;
    }

    /**
     * @return an empty array
     * @see VNode#getChildren()
     */
    public VNode[] getChildren() {
        return (new VNode[0]);
    }

    /**
     * Returns an array of bytes that represent the literal
     * 
     * @return an array of bytes that represent the literal
     */
    abstract public byte[] marshal();

    /**
     * Returns an array of bytes that represent the literal
     * 
     * @return an array of bytes that represent the literal
     */
    abstract public byte[] marshalWET();

    /**
     * Returns a copy of this object
     * 
     * @return a copy of this object
     */
    abstract public Object clone();

    /**
     * Annotates the literal with a class that represent another basic type.
     * This method is useful for cast.
     */
    private Class castTo;

    /**
     * Annotates the literal with the type definition of the channel (only for
     * casts to channels).
     */
    private Map cast_ChTypeDefs;

    /**
     * Annotates the literal with the automaton of the channel (only for casts
     * to channels).
     */
    private TreeAutomaton cast_ChTA;
    
    private int cast_Capability;

    /** Annotates the literal for cast it to a string */
    public void bindToString() {
        castTo = StringLiteral.class;
    }

    /** Annotates the literal for cast it to an integer */
    public void bindToInteger() {
        castTo = IntLiteral.class;
    }

    /** Annotates the literal for cast it to a channel */
    public void bindToChannel(Map chTypeDefs, TreeAutomaton chTypeTA, int capability) {
        castTo = ChannelLiteral.class;
        this.cast_ChTypeDefs = chTypeDefs;
        this.cast_ChTA = chTypeTA;
        this.cast_Capability = capability;
    }

    /** Annotates the literal for cast it to empty */
    public void bindToEmpty() {
        castTo = null;
    }

    /***************************************************************************
     * The following methods are used for converting the literal to some other *
     * type. This oparators are useful for type conversions and in particular
     * for * marshalling and unmarshalling *
     **************************************************************************/
    /** Casts this node to a string literal */
    abstract public StringLiteral toStringLiteral() throws VNodeCastException;

    /** Casts this node to an integer literal */
    abstract public IntLiteral toIntLiteral() throws VNodeCastException;

    /** Casts this node to a channel literal */
    abstract public ChannelLiteral toChannelLiteral(Map chTypeDefs, TreeAutomaton typeDef, int capability)
            throws VNodeCastException;

    /** Casts this node to an empty */
    abstract public VNode toEmpty() throws VNodeCastException;

    /** Casts this node with respect to its annotation */
    public VNode castToType() throws VNodeCastException {
        if (castTo == ChannelLiteral.class) {
            return toChannelLiteral(cast_ChTypeDefs, cast_ChTA, cast_Capability);
        }
        if (castTo == IntLiteral.class) return toIntLiteral();
        if (castTo == StringLiteral.class) return toStringLiteral();
        if (castTo == null) return toEmpty();
        throw new RuntimeException("Error casting: castTo is unspecified");
    }

    public boolean eq(VNode node, VNode[] env) {
        if (node instanceof VNodePointer || node instanceof VNodeOperation) {
            //VNodePointer pointer= (VNodePointer) node;
            //return eq(env[pointer.getEnvIndex()],env);
            throw new RuntimeException("eq invoked on " + node.getClass());
        }
        if (node instanceof Sequence) { return node.eq(this, env); }
        if (node instanceof Literal) {
            Literal lit = (Literal) node;
            return tagName.equals(lit.tagName);
        }
        return false;
    }
}