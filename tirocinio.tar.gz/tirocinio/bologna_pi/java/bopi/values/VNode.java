/*
 * BasicVNode.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Mar 2, 2004
 */
package bopi.values;

/** 
 * Basic implementation of  ``Bologna-Pi values''
 * @author Samuele Carpineti
 */
public abstract class VNode {
	/** node's bindings */
	private int[] bindings = new int[0];
	/** 
	 * Returns an array of bytes that represent the node
	 * @return an array of bytes that represent the node
	 */
	abstract public byte[] marshal();
	/** 
	 * Returns an array of bytes that represent the node. This is a marshal operation with explicit types. 
	 * So types must be added with their type (for XML documents this means that every base value 
	 * has its type as label). 
	 * @return an array of bytes that represent the node
	 */
	abstract public byte[] marshalWET();
	/**
	 * Returns the  value of this node
	 * @return the value of this node
	 */
	abstract public Object getValue();
	/**
	 * Adds a child to the current node. Can throws an exception if the node cannot have child
	 * @param child - the node to add
	 */
	abstract public void addChild(VNode child);
	/**
	 * Returns a child at the specified position
	 * @param position - the index of the child 
	 * @return the child at the specified position 
	 */
	abstract public VNode getChild(int position);
	/**
	 * Sets the child at position i of the current node
	 * @param position - the position of the child
	 * @param child - the value of the child
	 */
	abstract public void setChild(int position, VNode child);
	/** 
	 * Returns an array containing the children of the this node
	 * @return an array containing the children of the this node
	 */
	abstract public VNode[] getChildren();
	/**
	 * Returns the number of the children of the current node
	 * @return the number of the children of the current node
	 */
	abstract public int getChildrenNumber();
	/**
	 * Returns the bindings for the current node
	 * @return the bindings of this node
	 */
	public int[] getBindings() {
		return bindings;
	}
	/** 
	 * Sets the bindings of the node
	 * @param variables - a list of variables that binds the node 
	 */
	public void setBindings(int[] variables) {
		this.bindings = variables;
	}
	/** 
	 * Resets bindings in the node and in it's subtree
	 */
	public void clearAnnotations() {
		bindings = new int[0];
		for (int i = 0; i < this.getChildrenNumber(); i++)
			this.getChild(i).clearAnnotations();
	}
	/**
	 * Returns a string representation of the bindings
	 */
	public String bindingsToString() {
		String out = new String();
		int length = bindings.length;
		if (length > 0) {
			out += "{";
			for (int j = 0; j < length; j++)
				out += bindings[j];
			out += "}:";
		}
		return out;
	}
	/**
	 * Clones this node 
	 * @return a clone of this node
	 */
	abstract public Object clone();
	/**
	 * Transforms a node with pointers to a new node without pointers
	 * @param env - the environment where pointers refer
	 * @param node - the node 
	 * @return the node where any pointer is replaced with its value in the environment
	 */
	public static VNode derefer(VNode[] env, VNode node) {
		if (node == null)
			return null;
		if (node instanceof Literal)
			return node;
		if (node instanceof SequenceElement) {
			return VNode.derefer(env, ((SequenceElement) node).getElementValue());
		} else if (node instanceof LabelledElement) {
			node.setChild(0, derefer(env, node.getChild(0)));
			return node;
		} else if (node instanceof Sequence) {
			Sequence os = (Sequence) node;
			Sequence s = new Sequence();
			for (int i = 0; i < os.getChildrenNumber(); i++)
				s.addChild(derefer(env, os.getChild(i)));
			os.children = s.children;
			return os;
		} else if (node instanceof VNodeOperation){
			return ((VNodeOperation)node).evaluate(env);
		}
		else if (node instanceof VNodePointer) {
			VNode value;
			//Cyclic pointers are also verified in order to avoid divergence. 
			boolean[] visited = new boolean[env.length];
			for (int i = 0; i < env.length; i++)
				visited[i] = false;
			do {
				int idx = ((VNodePointer) node).getEnvIndex();
				value = env[idx];
				if (value == null)
					return null;
				if (visited[idx])
					throw new RuntimeException("Cyclic pointer found");
				visited[((VNodePointer) node).getEnvIndex()] = true;
			} while (value instanceof VNodePointer);
			return value;
		} else
			throw new RuntimeException("Dereferencing an unexpected VNode");
	}
	public abstract boolean eq(VNode node, VNode[] env);
		
}
