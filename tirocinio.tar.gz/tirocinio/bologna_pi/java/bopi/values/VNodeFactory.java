/*
 * VNodeReader.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Mar 5, 2004
 */
package bopi.values;

import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.SAXException;
import java.io.ByteArrayInputStream;
import org.xml.sax.InputSource;
import java.io.IOException;

/**
 * Generates VNode reading xml documents
 * 
 * @author Samuele Carpineti
 */
public class VNodeFactory {
    private static final String DEFAULT_PARSER_NAME = "org.apache.xerces.parsers.SAXParser";

    private static XMLReader parser;

    private static VNodeDefaultHandler defaultHandler;

    public VNodeFactory() throws SAXException {
        parser = XMLReaderFactory.createXMLReader(DEFAULT_PARSER_NAME);
        defaultHandler = new VNodeDefaultHandler();
        parser.setContentHandler(defaultHandler);
        parser.setErrorHandler(defaultHandler);
    }

    public synchronized static VNode generateVNode(byte[] source) throws SAXException, IOException {
        String value = new String(source);
        //ignore header
        value = value.replaceFirst("<\\?(.*)\\?>[\\s*]?", "").trim();
        if (value.startsWith("<value xmlns='" + VNodeDefaultHandler.VNODE_NAMESPACE + "'>")) return generateVNode(
                source, false);
        value = "<value xmlns='" + VNodeDefaultHandler.VNODE_NAMESPACE + "'>" + value + "</value>";
        return generateVNode(value.getBytes());

    }

    /** A single VNodeFactoryFactory can be shared among different threads */
    public synchronized static VNode generateVNode(byte[] source, boolean addEmtpyStringLiteral) throws SAXException,
            IOException {
        if (parser == null || defaultHandler == null) new VNodeFactory();
        boolean oldAddEmptyStringLiteral = VNodeDefaultHandler.ADD_EMPTY_STRLIT;
        //TODO Check the examples with this
        VNodeDefaultHandler.ADD_EMPTY_STRLIT = addEmtpyStringLiteral;
        //VNodeDefaultHandler.ADD_EMPTY_STRLIT = false;
        parser.parse(new InputSource(new ByteArrayInputStream(source)));
        VNodeDefaultHandler.ADD_EMPTY_STRLIT = oldAddEmptyStringLiteral;
        VNode node = defaultHandler.getVNode();
        defaultHandler.reset();
        return node;
    }

    public static boolean test() {
        return (test1() && test2() && test3());
    }

    protected static boolean test1() {
        String xml = new String();
        xml += "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><value xmlns='" + VNodeDefaultHandler.VNODE_NAMESPACE
                + "'>" + "<root>" + "hello " + "<b>wonderful</b>" + " world" + "</root></value>";
        try {
            VNode node = VNodeFactory.generateVNode(xml.getBytes());
            String out = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><value xmlns='"
                    + VNodeDefaultHandler.VNODE_NAMESPACE + "'>" + new String(node.marshal()) + "</value>";
            if (!out.equalsIgnoreCase(xml)) return false;
            return true;
        } catch (SAXException s) {
            return false;
        } catch (IOException e) {
            return false;
        }
    }

    protected static boolean test2() {
        String xml = new String();
        xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" + "<value xmlns='"
                + VNodeDefaultHandler.VNODE_NAMESPACE + "'>" + "<addrbook>" + "<person>"
                + "<name> Haruo Hosoya </name>" + "<email> hahosoya@kyoto-u </email>"
                + "<email> hahosoya@upenn </email>" + "</person>" + "<person>" + "<name> Benjamin Pierce </name>"
                + "<email> bcpierce@upenn </email>" + "<tel> 123-456-789 </tel>" + "</person>" + "</addrbook>"
                + "</value>";
        try {
            VNode node = VNodeFactory.generateVNode(xml.getBytes());
            System.out.println(node);
            String out = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" + "<value xmlns='"
                    + VNodeDefaultHandler.VNODE_NAMESPACE + "'>" + new String(node.marshal()) + "</value>";
            if (!out.equalsIgnoreCase(xml)) return false;
            return true;
        } catch (SAXException s) {
            return false;
        } catch (IOException e) {
            return false;
        }
    }

    protected static boolean test3() {
        try {
            String xml = new String();
            xml = "<value xmlns='" + VNodeDefaultHandler.VNODE_NAMESPACE + "'><eq xmlns='"
                    + VNodeDefaultHandler.VNODE_NAMESPACE + "' op1='0' op2='1'/></value>";
            VNode node = VNodeFactory.generateVNode(xml.getBytes());
            IntLiteral op1 = new IntLiteral(5);
            IntLiteral op2 = new IntLiteral(7);
            IntLiteral op = new IntLiteral(1);
            VNode[] env = { op1, op2 };
            op.eq(VNode.derefer(env, node), env);
            xml = "<value xmlns='" + VNodeDefaultHandler.VNODE_NAMESPACE + "'><add xmlns='"
                    + VNodeDefaultHandler.VNODE_NAMESPACE + "' op1='0' op2='1'/></value>";
            op = new IntLiteral(12);
            op.eq(VNode.derefer(env, node), env);
            return true;
        } catch (SAXException s) {
            return false;
        } catch (IOException e) {
            return false;
        }
    }

}