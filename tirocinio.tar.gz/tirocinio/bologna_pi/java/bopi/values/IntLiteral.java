/*
 * IntLiteral.java
 * project: BolognaPi
 * @author Samuele Carpineti
 * Created on Feb 26, 2004
 */
package bopi.values;

import java.util.Map;

import bopi.ta.SpecialLabels;
import bopi.ta.TreeAutomaton;

/**
 * Integer Literal is a labelled element whith an empty child
 * (INTEGER_LITERAL[null]). Integer literals are leaves in our trees.
 * 
 * @author Samuele Carpineti
 */
public class IntLiteral extends Literal {
    /** literal value */
    private Integer value;

    /**
     * Builds a new integer literal with the specified value
     * 
     * @param value -
     *            literal value
     */
    public IntLiteral(final Integer value) {
        this.value = value;
        this.tagName = SpecialLabels.INTEGER_LITERAL + value.toString();
    }

    /**
     * Builds a new integer literal with the specified value
     * 
     * @param value -
     *            literal value
     */
    public IntLiteral(final int value) {
        this(new Integer(value));
    }

    /**
     * Builds a new integer literal with the specified value and with a
     * specified set of bindings
     * 
     * @param value -
     *            literal value
     * @param bindings -
     *            a list of binders
     */
    IntLiteral(final Integer value, int[] bindings) {
        this(value);
        setBindings(bindings);
    }

    /**
     * Builds a new integer literal with the specified value and with a
     * specified set of bindings
     * 
     * @param value -
     *            literal value
     * @param bindings -
     *            a list of binders
     */
    IntLiteral(int value, int[] bindings) {
        this(value);
        setBindings(bindings);
    }

    /**
     * Marshals the literal
     * 
     * @return a string representation of value
     * @see VNode#marshal()
     */
    public byte[] marshal() {
        return value.toString().getBytes();
    }

    /**
     * Marshals the literal adding a the &lt int &gt label
     * 
     * @return a string representation of value
     * @see VNode#marshalWET()
     */
    public byte[] marshalWET() {
        return ("<int>" + value.toString() + "</int>").getBytes();
    }

    /**
     * Returns the literal value
     * 
     * @return the literal value
     */
    public Object getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public void setValue(int value) {
        this.value = new Integer(value);
    }

    /**
     * Returns a string representations of this literal
     * 
     * @return a string representations of this literal
     */
    public String toString() {
        return value.toString();
    }

    /**
     * Returns a copy of this object
     * 
     * @return a copy of this object
     */
    public Object clone() {
        IntLiteral copy = new IntLiteral(value);
        return copy;
    }

    /**
     * Adds two integers
     * 
     * @param op1 -
     *            the first operand
     * @param op2 -
     *            the second operand
     * @return a new IntLiteral as sum of op1 and op2
     */
    public static IntLiteral add(final IntLiteral op1, final IntLiteral op2) {
        return new IntLiteral(op1.value.intValue() + op2.value.intValue());
    }

    /**
     * Subtracts two integers
     * 
     * @param op1
     *            the first operand
     * @param op2
     *            the second operand
     * @return a new IntLiteral as subtraction of op1 and op2
     */
    public static IntLiteral sub(final IntLiteral op1, final IntLiteral op2) {
        return new IntLiteral(op1.value.intValue() - op2.value.intValue());
    }

    /**
     * Returns true if the first operand is less the the second one, false
     * otherwise
     * 
     * @param op1
     *            the first operand
     * @param op2
     *            the second operand
     * @return true if the first operand is less then the second one, false
     *         otherwise
     */
    public static boolean lt(final IntLiteral op1, final IntLiteral op2) {
        return op1.value.intValue() < op2.value.intValue();
    }

    /**
     * Returns true if the first operand is either equal or greater then the
     * second one, false otherwise
     * 
     * @param op1
     *            the first operand
     * @param op2
     *            the second operand
     * @return true if the first operand is either equal or less then the second
     *         one
     */
    public static boolean leq(final IntLiteral op1, final IntLiteral op2) {
        return op1.value.intValue() <= op2.value.intValue();
    }

    /**
     * Returns true if the first operand is greater then the second one
     * 
     * @param op1
     *            the first operand
     * @param op2
     *            the second operand
     * @return true if the first operand is greater then the second one, false
     *         otherwise
     */
    public static boolean gt(final IntLiteral op1, final IntLiteral op2) {
        return op1.value.intValue() > op2.value.intValue();
    }

    /**
     * Returns true if the first operand is either equal or greater then the
     * second one, false otherwise
     * 
     * @param op1
     *            the first operand
     * @param op2
     *            the second operand
     * @return true if the first operand is either equal or greater then the
     *         second one, false otherwise
     */
    public static boolean geq(final IntLiteral op1, final IntLiteral op2) {
        return op1.value.intValue() >= op2.value.intValue();
    }

    /**
     * Returns true if the first operand and the second one are equals, false
     * otherwise
     * 
     * @param op1
     *            the first operand
     * @param op2
     *            the second operand
     * @return true if the first operand and the second one are equals, false
     *         otherwise
     */
    public static boolean eq(final IntLiteral op1, final IntLiteral op2) {
        return op1.value.intValue() == op2.value.intValue();
    }

    /**
     * Copies the string literal to a new string literal
     * 
     * @see Literal#toStringLiteral()
     */
    public StringLiteral toStringLiteral() {
        return new StringLiteral(value.toString(), getBindings());
    }

    /**
     * Returns the conversion of this channel literal to an integer literal
     * 
     * @return the conversion of this channel literal to an integer literal
     * @see Literal#toIntLiteral()
     */
    public IntLiteral toIntLiteral() {
        return new IntLiteral(value, getBindings());
    }

    /**
     * It always throws a VNodeCastException.
     * 
     * @see Literal#toChannelLiteral(Map,TreeAutomaton)
     */
    public ChannelLiteral toChannelLiteral(Map typeDefs, TreeAutomaton typeTA, int capability)
            throws VNodeCastException {
        throw new VNodeCastException(IntLiteral.class, null);
    }

    /**
     * It always throws a VNodeCastException.
     * 
     * @see Literal#toEmpty()
     * @throws VNodeCastException
     */
    public VNode toEmpty() throws VNodeCastException {
        throw new VNodeCastException(IntLiteral.class, null);
    }
}
