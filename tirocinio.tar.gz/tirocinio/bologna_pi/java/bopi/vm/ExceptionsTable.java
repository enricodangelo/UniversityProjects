/*
 * ExceptionTable.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Jun 19, 2004
 */
package bopi.vm;

import java.util.Iterator;
import java.util.TreeSet;
/**
 * This class is a global table from code fragments to their exception handler
 * @author Samuele Carpineti
 */
class ExceptionsTable {
    /**
     * An exception handler keeps the handler that should be excecuted when an 
     * exception is thrown exceuting an instruction of a given code. Exception handlers differ for 
     * the code fragment they protect, for the exception they catch and for the handle code. 
     */
	private class ExceptionHandler implements Comparable {
		private int start;
        private int end;
        private String exception;
        private BCInstruction[] handler;
		ExceptionHandler(int start, int end, String exception, BCInstruction[] handler) {
			this.start= start;
			this.end= end;
			this.exception= exception;
			this.handler= handler;
		}
		public boolean contains(int value) {
			return (value >= start && value <= end);
		}
		/**
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		public int compareTo(Object o) {
			if (o instanceof ExceptionHandler) {
				ExceptionHandler exH= (ExceptionHandler) o;
				if (exH.start == start && exH.end == end) {
					if (exH.exception.equals(exception) && exH.handler == handler)
						return 0;
					else if (exH.exception.equals(exception))
						return exH.handler.toString().compareTo(handler.toString());
					else
						return exH.exception.compareTo(exception);
				} else if (exH.start <= start && exH.end >= end)
					return 1;
				else if (exH.start >= start && exH.end <= end)
					return -1;
				else
					throw new RuntimeException("Elements are not comparable " + o + " and " + this);
			} 
			throw new ClassCastException();
		}
		public String toString() {
			return "[" + start + ":" + end + "] " + " " + exception;
		}
		public boolean equals(Object o) {
			if (!(o instanceof ExceptionHandler))
				return false;
			ExceptionHandler exH= (ExceptionHandler) o;
			return (exH.end == end && exH.start == start && exH.exception.equals(exH.exception) && exH.handler == exH.handler);
		}
	}
    private BCInstruction[] code;
    private TreeSet<ExceptionHandler> table;
    public ExceptionsTable(BCInstruction[] code){
        this.code = code;
        this.table = new TreeSet<ExceptionHandler>();
    }
    /**
     * Add a handler for an exception thrown in fragment of the code 
     * @param handler - handler code
     * @param exception - exception name
     * @param start - minimum index handled by handler
     * @param end - maximum index handled by handler
     */
	void addHandler(int start, int end, BCInstruction[] handler, String exception) {
		table.add(new ExceptionHandler(start, end, exception, handler));
	}
    /**
     * Given a code, a program counter, and the name of the exception return the 
     * exception handler if it exists or null if it does not exist
     * @param pc - the program counter
     * @param exception - the exception name
     * @return the handler or null if it does not exist
     */
	BCInstruction[] getHandler(int pc, String exception) {
		//The elements are returned in ascending order    
		Iterator<ExceptionHandler> i= table.iterator();
		while (i.hasNext()) {
			ExceptionHandler exH= i.next();
			if (exH.start == pc) {
				if (exH.exception.equals(exception)) {
					return exH.handler;
				}
			}
			if (exH.contains(pc) && exH.exception.equals(exception))
				return exH.handler;
		}
		return null;
	}
}
