package bopi.vm;

import java.util.Hashtable;
import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.ta.TreeAutomaton;
import bopi.ta.HandlerCallback;
import bopi.ta.PatternDefaultHandler;
import bopi.values.VNode;
/**
 * This class implements the match statement. The runtime bahvior is simple if the pattern matching 
 * succeds executes the continuation with the new bindings otherwise jumps to the otherwise branch.  
 * @author Paolo Milazzo
 */
public class BCI_Match implements BCInstruction, HandlerCallback {
	// jumps for if-then-else implementation.. They are initialized -1
	// and updated during the parsing
	private int elseIdx = -1;
	private int endIdx = -1;
	private BCI_Jump thenEndJump = null;
	private int value;
	private TreeAutomaton pattern;
	private XMLHandler_Data data;
	private String errorMsg = VMThread.DEF_NOERROR_MSG;
	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
		value = Integer.parseInt(attributes.getValue("", "value"));
		// setParserHandler parses the pattern and returns its tree automaton
		// by calling the call back method setAutomaton
		PatternDefaultHandler.setParserHandler(data.parser, this, data.typesMap);
		// the <ifmatch> and <default> branches are parsed by the XMLBytecodeHandler
		// that uses some callbacks 
		this.data = data;
		codeFragment.add(idx, this);
		return idx + 1;
	}
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		if (!pattern.matchValue(env[value], env))
			thread.setProgramCounter(elseIdx - 1);
		return VMThread.RUNNING;
	}
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getError() {
		return errorMsg;
	}
	/*
	 * Callbacks for the XMLBytecodeHandler
	 */
	public void setElseIndex(int idx) {
		this.elseIdx = idx;
	}
	public void setJumpInstrAtThenEnd(BCI_Jump instr) {
		this.thenEndJump = instr;
	}
	public void setIndexAfterElse(int idx) {
		this.endIdx = idx;
		this.thenEndJump.setTarget(idx);
	}
	// This method is the callback for the ContentHandler that
	// parses the pattern
	public void setAutomaton(TreeAutomaton ta) {
		pattern = ta;
		data.prog.setEnvSize(data.currentThrOrFun, pattern.getMaxBinding());
		data = null;
	}
	public void setVNode(VNode v) {
		//do nothing
	}
	public void setXMLDocument(String xml) {
		//do nothing
	}
}
