/*
 * Created on 24-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.util.Hashtable;
import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.ta.TreeAutomaton;
import bopi.ta.HandlerCallback;
import bopi.values.VNode;
import bopi.values.VNodeDefaultHandler;
/**
 * 
 * @author Paolo Milazzo
 */
public class BCI_Store implements BCInstruction, HandlerCallback {
	private int target= -1;
	private VNode value= null;
	private VNode originalValue= null;
	private ActivationRecord previousAR= null;
	private String errorMsg= VMThread.DEF_NOERROR_MSG;
    private boolean oldAddEmptyStringLiteral;
	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
		target= Integer.parseInt(attributes.getValue("", "target"));
		data.prog.setEnvSize(data.currentThrOrFun, target);
        oldAddEmptyStringLiteral= VNodeDefaultHandler.ADD_EMPTY_STRLIT;
		VNodeDefaultHandler.ADD_EMPTY_STRLIT= false;
		VNodeDefaultHandler.setParserHandler(data.parser, this);
		codeFragment.add(idx, this);
		return idx + 1;
	}
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		//value cannot be modified in place. It needs to be cloned when the activation record is different
		//otherwise recursive functions cannot work (they use the same store many times then if a value is 
		//dereferenced information about the environment is lost)
		if (previousAR == null || previousAR != thread.getActivationRecord()) {
			previousAR= thread.getActivationRecord();
			value= (VNode) originalValue.clone();
		}
		env[target]= value;
		//VNode.derefer(env, env[target]);
		return VMThread.RUNNING;
	}
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getError() {
		return errorMsg;
	}
	public void setAutomaton(TreeAutomaton ta) {
	    //do nothing
	}
	public void setVNode(VNode v) {
        VNodeDefaultHandler.ADD_EMPTY_STRLIT= oldAddEmptyStringLiteral;
		originalValue= v;
	}
	public void setXMLDocument(String xml) {
	    //do nothing
	}
}
