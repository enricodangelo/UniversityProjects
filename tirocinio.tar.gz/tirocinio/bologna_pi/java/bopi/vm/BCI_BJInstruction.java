/*
 * BCIBindingInstruction.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Oct 27, 2004
 */
package bopi.vm;
/**
 * 
 * @author Samuele Carpineti
 */
abstract class BCI_BJInstruction implements BCInstruction {
	private String errorMsg= "Unhandled exception using the Java Binding";
	static final protected String OBJECT_NOT_FOUND_EXCEPTION= "ObjectNotFoundException";
	static final protected String NO_SUCH_METHOD_EXCEPTION= "NoSuchMethodException";
	static final protected String INSTANTIATION_EXCEPTION= "InstantiationException";
	static final protected String ILLEGAL_ACCESS_EXCEPTION= "IllegalAccessException";
	static final protected String INVOCATION_TARGET_EXCEPTION= "InvocationTargetException";
	static final protected String ILLEGAL_ARGUMENT_EXCEPTION= "IllegalArgumentException";
	static final protected String NOT_SUPPORTED_RETURN_TYPE= "NotSupportedReturnType";
	public String getError() {
		return errorMsg;
	}
}
