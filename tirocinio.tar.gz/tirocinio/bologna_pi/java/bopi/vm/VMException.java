/*
 * Created on 9-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

/**
 * 
 * @author Paolo Milazzo
 */
public class VMException extends Exception {
	private static final long serialVersionUID = 3546362829369325361L;
	static public final Integer CASTTOINT_EXCEPTION = new Integer(0);
    static public final Integer CHANNEL_EXCEPTION = new Integer(1);;
	public VMException() {
		super();
	}

	public VMException(String message) {
		super(message);
	}

}
