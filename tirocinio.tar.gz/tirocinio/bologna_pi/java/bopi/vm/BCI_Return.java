/*
 * Created on 24-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;
import java.util.Hashtable;

import java.util.Vector;

import org.xml.sax.Attributes;

import bopi.values.VNode;

/**
 * 
 * @author Paolo Milazzo
 */
public class BCI_Return implements BCInstruction {

	private int value;
	
	private String errorMsg = VMThread.DEF_NOERROR_MSG;

	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
		codeFragment.add(idx, this);
		String valueString = attributes.getValue("","value");
		// value is optional (if function type is void it is missing)
		if (valueString!=null) value = Integer.parseInt(valueString);
		else value = -1;
		return idx+1;
	}

	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		int target = thread.getRetValTarget();
		thread.popActivationRecord();
		thread.setRetVal(target, env[value]);
		return VMThread.RUNNING;
	}

	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getError() {
		return errorMsg;
	}

}
