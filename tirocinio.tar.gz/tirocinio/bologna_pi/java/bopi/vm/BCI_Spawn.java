package bopi.vm;

import java.util.Hashtable;
import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.values.VNode;
/**
 * This instruction handles spawns. Spawn has one private field which stores the number of instruction to jump. 
 * The runtime behavior is to start a new thread with the pc pointing to the next instruction and to increment 
 * the program counter of the current thread of a value correspoding to the field steps.   
 * @author Samuele Carpineti
 */
public class BCI_Spawn implements BCInstruction {
	private VMProgram prog= null;
	private String errorMsg= "Error crating a new thread";
	protected int steps;
	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
         //when the spawn element starts steps stores the current idx
		steps= idx; 
		prog= data.prog;
		codeFragment.add(idx, this);
		return idx + 1;
	}
	public int setTermination(Vector<BCInstruction> codeFragment, int idx) {
        //when the spawn element end steps stores the number of instructions to jump
		this.steps= idx - steps;
		codeFragment.add(idx, new BCI_Terminate());
		return idx + 1;
	}
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		VNode[] newEnv= new VNode[env.length];
		for (int i= 0; i < env.length; i++)
			newEnv[i]= env[i];
		int pc= thread.pc + 1;
		try {
			sched.load(prog, pc, newEnv);
			thread.pc += steps;
		} catch (VMException e) {
			errorMsg= e.getMessage();
			return VMThread.ERROR;
		}
		return VMThread.RUNNING;
	}
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getError() {
		return errorMsg;
	}
}
