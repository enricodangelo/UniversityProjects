package bopi.vm;

import bopi.values.VNode;
/**
 * An activation record is an element of the stack of a vmthread
 * 
 * @author Paolo Milazzo
 */
public class ActivationRecord {
	/**
	 * A reference to the code
	 */
	protected BCInstruction[] codeRef;
	/**
	 * The environment
	 */
	protected VNode[] env;
	/**
	 * The signature of the function related to this activation record
	 */
	protected String signature;
	/**
	 * The program counter of the caller
	 */
	protected int oldPC;
	/**
	 * The address where the return value will be stored. -1 means
	 * no return value.
	 */
	protected int retValTarget;
	/**
	 * Default constructor. Sets the signature and the environment
	 * 
	 * @param sign the signature of the just called function
	 * @param env the initial environment
	 * @param oldPC the program counter of the caller
	 */
	public ActivationRecord(String sign, VNode[] env, int oldPC, int retValTarget, BCInstruction[] codeRef) {
		this.env= env;
		this.signature= sign;
		this.oldPC= oldPC;
		this.retValTarget= retValTarget;
		this.codeRef= codeRef;
	}
}
