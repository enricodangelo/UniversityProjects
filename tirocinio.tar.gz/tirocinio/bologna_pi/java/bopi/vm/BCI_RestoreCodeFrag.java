/*
 * BCI_RestoreCodeFrag.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Jun 19, 2004
 */
package bopi.vm;

import java.util.Hashtable;
import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.values.VNode;

/**
 * This instruction is not present in the bytecode. Only it's memory representation  has BCI_RestoreCodeFrag 
 * for restoring the activation record executed before the exception. When a code fragment throws an 
 * exception another code fragment (the right exception handler) is exceuted. When the handler finishes 
 * its execution the control must go back to the previous code fragment but the pc must be updated to 
 * another value (the first instruction of the code following the try-catch statement).  
 * @author Samuele Carpineti
 */
public class BCI_RestoreCodeFrag implements BCInstruction {
    private int pc;
    private String errorMsg = VMThread.DEF_NOERROR_MSG;
    public BCI_RestoreCodeFrag(int pc){
        this.pc = pc;
    }
	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
		return 0;
	}
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		thread.codeRef = thread.codeFrags.pop();
        thread.pc = pc;
		return VMThread.RUNNING;
	}
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getError() {
		return errorMsg;
	}
}
