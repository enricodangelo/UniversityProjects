package bopi.vm;

import java.io.IOException;
import org.xml.sax.SAXException;
import bopi.api.API_Exception;
import bopi.api.Blockable;
import bopi.api.BolognaPiImpl;
import bopi.ta.TreeAutomaton;
import bopi.values.ChannelLiteral;
import bopi.values.VNode;
import bopi.values.VNodeCastException;
import bopi.values.VNodeFactory;

/**
 * 
 * @author Paolo Milazzo
 */
public class VMBlockableImpl implements Blockable {
    private byte[] data;

    private String subject;

    private Scheduler scheduler;

    private int status;

    private VMThread thread;

    private VNode[] env;

    private int[] channels;

    private int target;

    private TreeAutomaton[] patterns;

    int idx = -1;

    public VMBlockableImpl(Scheduler scheduler) {
        this.scheduler = scheduler;
    }

    public void initRecv(VNode[] env, int[] channels, int target, TreeAutomaton[] patterns) {
        this.env = env;
        this.channels = channels;
        this.target = target;
        this.patterns = patterns;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public byte[] getData() {
        return data;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void block() {
        thread = scheduler.blockThread(scheduler.currentIdx);
    }

    public void unblock() {
        //unblock a synchronous send
        if (env == null) {
            scheduler.unblockThread(thread);
            return;
        } 
        //unblocks a receive: if the value is wrong it is discarded and the
        // thread is not unblocked
        String[] channelNames = new String[channels.length];
        for (int i = 0; i < channelNames.length; i++) {
            channelNames[i] = ((ChannelLiteral) env[channels[i]]).getIPAddress();
            if (subject.equals(((ChannelLiteral) env[channels[i]]).getIPAddress())) idx = i;
        }
        try {
            VNode value = VNodeFactory.generateVNode(data);
            VNode readNode = null;
            //Since the value is read from the network it can be converted
            if (patterns[idx] != null) {
                readNode = patterns[idx].castVNode(value, env, true);
            }
            if (target != -1) env[target] = readNode;
        } catch (SAXException e) {
            return;
        } catch (IOException e) {
            return;
        } catch (VNodeCastException v) {
            return;
        }
        try {
            scheduler.unblockThread(thread);
            BolognaPiImpl.getInstance().undoFwd(channelNames, subject);
        } catch (API_Exception e1) {
            e1.printStackTrace();
        }

    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}