/*
 * Created on 21-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.util.Hashtable;
import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.api.API_Exception;
import bopi.api.BolognaPiAPI;
import bopi.api.BolognaPiImpl;
import bopi.values.ChannelLiteral;
import bopi.values.VNode;
/**
 * 
 * @author Paolo Milazzo
 */
public class BCI_Send implements BCInstruction {
	private int sourceChannel;
	private int value;
	private String channelName;
	private String errorMsg= VMThread.DEF_NOERROR_MSG;
	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
		try {
			sourceChannel= Integer.parseInt(attributes.getValue("", "ch"));
		} catch (NumberFormatException nfe) {
			channelName= attributes.getValue("", "name");
		}
		value= Integer.parseInt(attributes.getValue("", "value"));
		codeFragment.add(idx, this);
		return idx + 1;
	}
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		try {
			BolognaPiAPI api= BolognaPiImpl.getInstance();
			api.initAPI();
			VNode msg = VNode.derefer(env,env[value]);
			if (channelName == null)
				api.send(((ChannelLiteral) env[sourceChannel]).getIPAddress(), msg.marshal(), thread.getBlockable());
			else
				api.send(channelName, msg.marshal(), thread.getBlockable());
			api.exitAPI();
		} catch (API_Exception e) {
			errorMsg= e.getMessage();
			return VMThread.ERROR;
		}
		boolean isSingleThread= (thread.mode == VirtualMachine.SINGLE_THREAD);
		if (isSingleThread)
			return VMThread.WAITING;
		return VMThread.RUNNING;
	}
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getError() {
		return errorMsg;
	}
}
