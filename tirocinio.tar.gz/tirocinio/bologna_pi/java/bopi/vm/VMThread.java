/*
 * Created on 21-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Stack;
import bopi.api.Blockable;
import bopi.api.BlockableImpl;
import bopi.values.VNode;

/**
 * 
 * @author Paolo Milazzo
 */
public class VMThread extends Thread {
    protected Stack<BCInstruction []> codeFrags = new Stack<BCInstruction []>();

    /**
     * Error state: no further steps are possible. The description of the error
     * is given by the getError() method
     * 
     * @see VMThread#getError()
     */
    public static final int ERROR = -1;

    /**
     * Terminated state: no further steps are possible.
     */
    public static final int TERMINATED = 0;

    /**
     * Running state: normal execution
     */
    public static final int RUNNING = 1;

    /**
     * Waiting state: the thread is blocked. The execution will continue when
     * someone will unblock it.
     */
    public static final int WAITING = 2;

    /**
     * Ready state: normal execution (before first instruction)
     */
    public static final int READY = 3;

    /**
     * The default phrase used in error messages to describe the "no errors"
     * state
     */
    public static final String DEF_NOERROR_MSG = "no errors";

    /**
     * Execution mode: SINGLE_THREAD or MULTI_THREAD
     */
    protected int mode;

    /**
     * Log printer
     */
    private VMLogs log = null;

    /**
     * State of the thread and error message (contains the cause of the occured
     * error if state==ERROR)
     */
    private int state = READY;

    private String errMessage = DEF_NOERROR_MSG;

    /**
     * bytecode to be executed (object-based representation) and program counter
     */
    protected BCInstruction[] codeRef;

    protected ExceptionsTable exceptionsTableRef;

    protected int pc;

    /**
     * Stack containing activation records. Each activation record contains the
     * environment of the current funcion. Activation record at the bottom of
     * the stack contains the environment created at thread start. An ArrayList
     * object is used (instead of a Vector or a Stack) because it is
     * unsynchronized so it has better performances
     */
    private ArrayList<ActivationRecord> stack = new ArrayList<ActivationRecord>();

    private int topStack = -1; // index of the element at the top (-1=empty)

    /**
     * A reference to the activation record at the top of the stack
     */
    private ActivationRecord currentAR = null;

    protected final ActivationRecord getActivationRecord() {
        return currentAR;
    }

    protected VMProgram prog = null;

    /**
     * Thread identifier
     */
    private String tid; // TODO: USE IT IN (ERROR) MESSAGES

    /**
     * A reference to the scheduler
     */
    private Scheduler sched;

    public VMThread(int mode, VMProgram prog, Scheduler sched, String threadName, VNode[] env, String tid, VMLogs vmlog) {
        this(mode, prog, sched, prog.getProgramCounter(threadName), env, tid, vmlog);
    }

    /**
     * Default constructor. Creates the VMThread object, initializes the
     * execution mode (SINGLE_THREAD or MULTI_THREAD) and the log printer using
     * the values passed as arguments
     * 
     * @param mode
     *            SINGLE_THREAD or MULTI_THREAD: constants of the VirtualMachine
     *            class
     * @param vmlog
     *            a log printer object. If it is null a new printer is created
     *            using 'vmthreadLog' as the filename
     * @param pc
     *            index of the first instruction in the code array
     * @param tid
     *            a string representing the thread (a thread identifier)
     * @param prog
     *            the program to execute
     * 
     * @see VirtualMachine
     * @see BCInstruction
     */
    public VMThread(int mode, VMProgram prog, Scheduler sched, int pc, VNode[] env, String tid, VMLogs vmlog) {
        // initializing the log printer
        if (vmlog == null) {
            System.err.println("VMTHREAD: null VMLogs received in thread constructor...");
            System.err.println("VMTHREAD: ...using file vmthreadLogs, log level 0 (min)");
            try {
                log = new VMLogs("vmthreadLogs", 0);
            } catch (FileNotFoundException e) {
                System.err.println("VMTHREAD: cannot initialize log file");
                System.err.println("VMTHREAD: shutting down the virtual machine");
                System.exit(1);
            }
        } else log = vmlog;
        // initializing the mode: MULTI_THREAD or SINGLE_THREAD
        if (mode == VirtualMachine.MULTI_THREAD || mode == VirtualMachine.SINGLE_THREAD) {
            this.mode = mode;
        } else {
            log.println("VMTHREAD: [debug] mode!= SINGLE_THREAD or MULTI_THREAD in constructor");
            log.println("VMTHREAD: setting SINGLE_THREAD mode (default)");
            this.mode = VirtualMachine.SINGLE_THREAD;
        }
        // initializing the program, the code, the program counter and the
        // exception code for the code
        this.prog = prog;
        this.codeRef = prog.getCode();
        this.exceptionsTableRef = prog.getExceptionTable(codeRef);
        this.pc = pc;
        // initializing the reference to the scheduler
        this.sched = sched;
        // initializing the stack
        if (env == null) {
            // We can't create a new empty env because we don't know
            // its size
            log.println("VMTHREAD: [debug] empty environment in constructor");
            log.println("VMTHREAD: shutting down the virtual machine");
            System.exit(1);
        } else {
            this.pushActivationRecord(tid, env, -1, codeRef);
            this.currentAR = (ActivationRecord) stack.get(topStack);
            this.tid = new String(tid);
        }
    }

    /**
     * Takes the next instruction an executes it
     * 
     * @return the status of the thread after the step
     */
    public int step() {
        switch (state) {
        case ERROR:
        case TERMINATED:
        case WAITING:
            return state;
        case READY:
        case RUNNING:
            try {
                state = codeRef[pc].execute(this, sched, currentAR.env);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (state == ERROR) errMessage = codeRef[pc].getError();
            pc++;
            return state;
        default: {
            errMessage = "[debug] unknown state in step()";
            return ERROR;
        }
        }
    }

    /**
     * executes the vmthread when the virtual machine runs in MULTI_THREAD mode
     */
    public void run() {
        if (mode == VirtualMachine.MULTI_THREAD) while (state != TERMINATED)
            step();
        else if (mode == VirtualMachine.SINGLE_THREAD) {
            state = ERROR;
            errMessage = "Trying to use the vmthread as a Java thread in SINGLE_THREAD mode";
        } else {
            state = ERROR;
            errMessage = "[debug] unknown mode in run()";
        }
    }

    /**
     * Sets the return value of a called function. Used by the instruction that
     * implements the return from a function
     * 
     * @param target -
     *            the address of the caller environment where the return value
     *            will be stored
     * @param r -
     *            the return value
     */
    protected void setRetVal(int target, VNode r) {
        switch (state) {
        case ERROR:
        case TERMINATED:
        case WAITING:
            log.println("VMTHREAD: [debug] setRetVal called in state " + state);
            break;
        case READY:
        case RUNNING:
            currentAR.env[target] = r;
        }
    }

    /**
     * Returns the return value of a called function. Used by the instruction
     * that implements the function call
     */
    public int getRetValTarget() {
        switch (state) {
        case ERROR:
        case TERMINATED:
        case WAITING:
            log.println("VMTHREAD: [debug] getRetVal called in state " + state);
            break;
        case READY:
        case RUNNING:
            return currentAR.retValTarget;
        }
        return -1;
    }

    /**
     * Adds a new activation record on the top o the stack. The size of the
     * environment passed as argument must be enough to contain all the
     * variables used during execution. The current value of the program counter
     * is stored into the new activation record.
     * 
     * @param signature -
     *            the signature of the called function
     * @param initEnv -
     *            the initial environment of the new record
     */
    protected void pushActivationRecord(String signature, VNode[] initEnv, int retValTarget, BCInstruction[] codeRef) {
        switch (state) {
        case ERROR:
        case TERMINATED:
        case WAITING:
            log.println("VMTHREAD: [debug] setActivationRecord called in state " + state);
            break;
        case READY:
        case RUNNING:
            topStack++;
            // the program counter is stored into the activation record
            int oldPC = pc;
            currentAR = new ActivationRecord(signature, initEnv, oldPC, retValTarget, codeRef);
            stack.add(topStack, currentAR);
        }
    }

    /**
     * Removes the activation record at the top of the stack. This method is
     * usually called together with setRetVal() by the implementation of the
     * 'return' instruction.
     */
    protected void popActivationRecord() {
        switch (state) {
        case ERROR:
        case TERMINATED:
        case WAITING:
            log.println("VMTHREAD: [debug] setActivationRecord called in state " + state);
            break;
        case READY:
        case RUNNING:
            stack.remove(topStack);
            topStack--;
            currentAR = (ActivationRecord) stack.get(topStack);
        }
    }

    protected void setState(int s) {
        if (mode == VirtualMachine.MULTI_THREAD) {
            state = ERROR;
            errMessage = "Trying to set the state during a MULTI_THREAD execution";
        }
        if (s < TERMINATED || s > READY) {
            state = ERROR;
            errMessage = "Trying to set a wrong state";
        } else state = s;
    }

    /**
     * Return the description of the error occured
     * 
     * @return the error message or the "No errors" string
     */
    public String getError() {
        return errMessage;
    }

    /**
     * Sets the program counter to a new value
     * 
     * @param newPC
     *            the new value of the program counter
     */
    protected void setProgramCounter(int newPC) {
        pc = newPC;
    }

    /**
     * Returns an object implementing the Blockable interface in agreement with
     * the value of 'mode'
     * 
     * @return a Blockable implementation
     */
    protected Blockable getBlockable() {
        if (mode == VirtualMachine.MULTI_THREAD) {
            return new BlockableImpl();
        } else if (mode == VirtualMachine.SINGLE_THREAD) {
            return new VMBlockableImpl(sched);
        } else {
            log.println("VMTHREAD: [Debug] Invalid mode in getBlockable");
            log.println("VMTHREAD: Shutting down the virtual machine");
            System.exit(1);
        }
        return null; // paranoid
    }

    int handleException(String exception) {
        if (exceptionsTableRef == null) return VMThread.ERROR;
        BCInstruction[] handler = exceptionsTableRef.getHandler(pc, exception);
        if (handler == null) return VMThread.ERROR;
        codeFrags.push(codeRef);
        codeRef = handler;
        exceptionsTableRef = prog.getExceptionTable(handler);
        pc = -1;
        return VMThread.RUNNING;
    }
}