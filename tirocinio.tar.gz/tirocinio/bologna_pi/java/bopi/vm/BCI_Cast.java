/*
 * BCI_CastToInt.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Jun 18, 2004
 */
package bopi.vm;

import java.util.Hashtable;
import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.ta.HandlerCallback;
import bopi.ta.PatternDefaultHandler;
import bopi.ta.TreeAutomaton;
import bopi.values.VNode;

/**
 * 
 * @author Samuele Carpineti
 */
public class BCI_Cast implements BCInstruction, HandlerCallback {
    private String errorMsg = "Unhandled exception: CastException";
    public String CAST_EXCEPTION="CastException";
    private int source;
    private TreeAutomaton type;
	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
        source= Integer.parseInt(attributes.getValue("","source"));
        PatternDefaultHandler.setParserHandler(data.parser,this,data.typesMap);
        codeFragment.add(idx, this);
		return idx+1;
	}
	
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
        try{
		  type.castVNode(env[source],env,false);
          return VMThread.RUNNING;
        }catch (bopi.values.VNodeCastException e){
                return thread.handleException(CAST_EXCEPTION);
        }
	}
	
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public String getError() {
        return errorMsg;
	}

	/**
	 * @see bopi.ta.HandlerCallback#setAutomaton(bopi.ta.TreeAutomaton)
	 */
	public void setAutomaton(TreeAutomaton ta) {
		this.type = ta;
	}

	/**
	 * @see bopi.ta.HandlerCallback#setVNode(bopi.ta.VNode)
	 */
	public void setVNode(VNode node) {
		// TODO Auto-generated method stub
	}

	/* (non-Javadoc)
	 * @see bopi.ta.HandlerCallback#setXMLDocument(java.lang.String)
	 */
	public void setXMLDocument(String xml) {
		// TODO Auto-generated method stub
		
	}
}
