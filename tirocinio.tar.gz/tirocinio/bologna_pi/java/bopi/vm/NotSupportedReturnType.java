package bopi.vm;

/**
 * @author Samuele Carpineti 
 */
public class NotSupportedReturnType extends Exception {
	
	private String string;
	/**
	 * Constructor NotSupportedReturnType.
	 * @param string
	 */
	public NotSupportedReturnType(String string) {
			this.string = string;
	}

	public String toString(){
		return "Type"+ string +"not supported in this library \n";
	}

}
