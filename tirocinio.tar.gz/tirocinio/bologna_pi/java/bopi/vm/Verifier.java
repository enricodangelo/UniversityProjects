/*
 * Created on 13-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

/**
 * Bytecode verifier
 * @author Samuele Carpineti
 */
public class Verifier {

    static public boolean verify(VMProgram prog) {
        // TODO: checks:
        // - no assignments to non-empty indexes of the environment
        // - types
        boolean isCorrect = true;
        if (!prog.verify())
            return false;
        BCInstruction[] code = prog.getCode();
        String errors = new String();
        for (int i = 0; i < code.length; i++) {
            if (code[i].verify(null) != 0) {
                errors += "Bytecode: Error at line " + i + " " + code[i].toString();
                isCorrect = false;
            }
        }
        return isCorrect;
    }
}