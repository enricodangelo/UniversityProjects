/*
 * Created on 30-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.util.Hashtable;
import java.util.Vector;

import org.xml.sax.Attributes;

import bopi.values.VNode;

/**
 * This interface is implemented by specific instruction interpreters. This
 * means that every class that implements this interface is used to execute a
 * bytecode instruction in a given environment. It offers also a method that can
 * be used to verify correctness of the bytecode instruction by a verifier based
 * on data flow analisys.
 * 
 * @author Paolo Milazzo
 */
public interface BCInstruction {

    /**
     * Parses an instruction using the SAX parser passed as argument. This must
     * be a static method that substitutes the constructor of the class
     * 
     * @param attributes -
     *            the attributes of the tag representing the instruction
     * @param codeFragment -
     *            a dynamic array (a Vector object) used to build the code array
     * @param idx -
     *            the index of the next free position in codeFragment
     * @param data -
     *            a set of data that can be passed/modified during the parsing
     * @return the updated index of codeFragment
     */
    public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data);

    /**
     * Execute the instruction on the environment passed as argument
     * 
     * @param thread -
     *            the vmthread that is in execution
     * @param env -
     *            the environment where the instruction is executed
     * @return the state of the thread after the execution (running, waiting,
     *         etc...) using macros provided by the VMThread class
     * 
     * @see VMThread
     */
    public int execute(VMThread thread, Scheduler sched, VNode[] env);

    /**
     * Verify the correctness of the instruction
     * @param symbolTable TODO
     * 
     * @return an integer representing the result of the verification. Such
     *         integer is 0 if the verification succeds, or a different number
     *         if some errors have been found
     */
    public int verify(Hashtable symbolTable);

    /**
     * Returns the description of the occured error (if any)
     * 
     * @return the description of the error
     */
    public String getError();

}