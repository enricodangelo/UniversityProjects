/*
 * Created on 21-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.util.Hashtable;
import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.values.VNode;

/**
 * 
 * @author Paolo Milazzo
 */
public class BCI_Jump implements BCInstruction {

	private int targetIdx;

	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
		codeFragment.add(idx, this);
		return idx+1;		
	}

	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		thread.setProgramCounter(targetIdx-1);
		return VMThread.RUNNING;
	}

	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getError() {
		return VMThread.DEF_NOERROR_MSG;
	}

	public void setTarget(int i) {
		this.targetIdx = i;
	}
}
