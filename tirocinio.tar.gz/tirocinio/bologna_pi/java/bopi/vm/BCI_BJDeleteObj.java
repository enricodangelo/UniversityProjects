/*
 * BCI_DeleteObj.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Oct 27, 2004
 */
package bopi.vm;
import java.util.Hashtable;

import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.values.VNode;
/**
 * 
 * @author Samuele Carpineti
 */
public class BCI_BJDeleteObj extends BCI_BJInstruction{
	int objIDRef;
	/* (non-Javadoc)
	 * @see bopi.vm.BCInstruction#parse(org.xml.sax.Attributes, java.util.Vector, int, bopi.vm.XMLHandler_Data)
	 */
	public int parse(Attributes attributes, Vector codeFragment, int idx, XMLHandler_Data data) {
		objIDRef= Integer.parseInt(attributes.getValue("", "objIDRef"));
		codeFragment.add(idx, this);
		return idx + 1;
	}
	/* (non-Javadoc)
     * * <deleteObj objIDRef="int"/> a referece in the environment
	 * @see bopi.vm.BCInstruction#execute(bopi.vm.VMThread, bopi.vm.Scheduler, bopi.values.VNode[])
	 */
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		try {
			sched.vm.reflector.delete(new Integer(env[objIDRef].toString()));
            return VMThread.RUNNING;
		} catch (ObjectNotFoundException onfe) {
			return thread.handleException(BCI_BJInstruction.OBJECT_NOT_FOUND_EXCEPTION);
		}
	}
	/* (non-Javadoc)
	 * @see bopi.vm.BCInstruction#verify()
	 */
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
	/* (non-Javadoc)
	 * @see bopi.vm.BCInstruction#getError()
	 */
	public String getError() {
		// TODO Auto-generated method stub
		return null;
	}
}
