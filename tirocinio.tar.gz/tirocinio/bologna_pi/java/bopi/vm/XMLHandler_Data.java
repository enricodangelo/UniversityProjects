/*
 * Created on 6-mar-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.util.Map;
import java.util.Stack;
import org.xml.sax.XMLReader;
import bopi.ta.TreeAutomaton;

public class XMLHandler_Data {
	public Stack nestingStack = null;
	public String currentThrOrFun = null;
	public XMLReader parser = null;
	public VMProgram prog = null;
	public Map<String, TreeAutomaton> typesMap = null;
    public int mode;
}
