/*
 * Created on 29-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import bopi.api.API_Exception;
import bopi.api.BolognaPiAPI;
import bopi.api.BolognaPiImpl;
import bopi.api.Channel;
import bopi.ta.PatternDefaultHandler;
import bopi.ta.TreeAutomaton;
import bopi.values.VNode;
import bopi.values.VNodeCastException;
/**
 * The virtual machine has two threads. One waits for xml programs 
 * to be uploaded and trasform them in bytecode. The second 
 * thread interpretes the bytecode.
 * The machine can use java thread (attribute mode=1) or can manage 
 * threads with an internal scheduler (attribute mode=0).
 * @author Paolo Milazzo
 */
public class VirtualMachine extends Thread {
	public static final int SINGLE_THREAD= 0;
	public static final int MULTI_THREAD= 1;
	private static final String DEFAULT_PARSER_NAME= "org.apache.xerces.parsers.SAXParser";
	private XMLReader parser= null;
	private XMLBytecodeHandler handler= null;
	private BolognaPiAPI api= null;
	private Scheduler scheduler= null;
	/** 
     * loadChannel contains the channel used to load programs (the loader thread is waiting on this channel)
     */
	private Channel loadChannel= null;
	public VirtualMachine(int mode, String CMaddr, int CMport, String logfile, int loglevel) throws VMException {
		if (mode != SINGLE_THREAD && mode != MULTI_THREAD)
			throw new VMException("Wrong mode");
		try {
			scheduler= new Scheduler(this, mode, new VMLogs(logfile, loglevel));
			parser= XMLReaderFactory.createXMLReader(DEFAULT_PARSER_NAME);
			handler= new XMLBytecodeHandler(parser, mode);
			parser.setContentHandler(handler);
			parser.setErrorHandler(handler);
			parser.setFeature("http://xml.org/sax/features/validation", true);
			parser.setFeature("http://apache.org/xml/features/validation/schema", true);
			api= BolognaPiImpl.getInstance(CMaddr, CMport);
			api.initAPI();
			loadChannel= new Channel();
			api.exitAPI();
			System.out.println("Please send bytecode to: " + loadChannel.getName());
			this.start();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
			System.exit(1);
		} catch (SAXException e) {
			e.printStackTrace();
			throw new VMException("Unable to create a SAX Parser");
		} catch (API_Exception e) {
			e.printStackTrace();
			try {
				api.exitAPI();
			} catch (API_Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	public void run() {
		try {
			api.initAPI();
			while (true) {
				byte[] bytecode= loadChannel.recv();
				System.out.println("Code have been uploaded");
                String strBytecode= new String(bytecode);
				ByteArrayInputStream is= new ByteArrayInputStream(bytecode);
				try {
					parser.parse(new InputSource(is));
				} catch (Exception e) {
                    System.err.println("Error loading the program");
                    System.err.println(strBytecode);
					e.printStackTrace();
					continue;
				}
				VMProgram prog= handler.getProgram();
				prog.setTypeDefs(strBytecode.substring(strBytecode.indexOf("<"+PatternDefaultHandler.TYPE_DECLARATION_ROOT+">"), strBytecode.indexOf("</" + PatternDefaultHandler.TYPE_DECLARATION_ROOT + ">")));
				String[] mains= handler.getMains(); // Function names (at loadtime) or a thread name (migration)
				VNode[] mainParams= handler.getMainParams();
				if (Verifier.verify(prog)) {
					for (int i= 0; i < mains.length; i++) {
						int envSize= prog.getEnvSize(mains[i]);
						VNode[] newEnv= new VNode[envSize];
						VNode v= mainParams[i];
						TreeAutomaton pattern= prog.getPattern(mains[i]);
						// if pattern==null means no parameters
						if (pattern != null) {
							try {
								pattern.castVNode(v, newEnv, true);
							} catch (VNodeCastException vnce) {
								System.err.println("Error loading the program: the input parameter does not match "+ vnce );
                                continue;
							}
						}
						if (prog.verify()){
							scheduler.load(prog, mains[i], newEnv);
						}
						else System.err.println("A program cannot be loaded because it is not correct");
					}
				}
			}
		} catch (API_Exception e) {
			e.printStackTrace();
			try {
				api.exitAPI();
			} catch (API_Exception e2) {
				e2.printStackTrace();
			}
		} catch (VMException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Returns the channel used to load programs
	 * @return the channel used to load programs into the virtual machine
	 */
	public Channel getLoaderChannel() {
		return loadChannel;
	}
	public static void main(String[] args) throws VMException {
		VirtualMachine vm= new VirtualMachine(SINGLE_THREAD, args[0], Integer.parseInt(args[1]), "VMlog", 2);
	}
}
