package bopi.vm;

import java.util.Hashtable;
import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.ta.TreeAutomaton;
import bopi.values.VNode;

/**
 * This class implements both function and agent call. The runtime behavior is:
 * <ol>
 * <li>create an environment E computing the pattern</li>
 * <li>to allocate a new activation record and push it on the current thread
 * with the environment E</li>
 * <li>to set the program counter to the first instruction of the definition
 * </li>
 * </ol>
 * 
 * @author Samuele Carpineti
 */
public class BCI_Call implements BCInstruction {
    private String function;

    private int target;

    private int value;

    private VMProgram prog;

    private String errorMsg = VMThread.DEF_NOERROR_MSG;

    public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
        function = attributes.getValue("", "function");
        if (function == null) function = attributes.getValue("", "thread");
        String targetString = attributes.getValue("", "target");
        // target is optional and in particular is missing in case of agent
        // calls
        if (targetString != null) target = Integer.parseInt(targetString);
        else target = -1;
        String valueString = attributes.getValue("", "value");
        // value is optional (it is missing if the function has no parameters)
        if (valueString != null) value = Integer.parseInt(valueString);
        else value = -1;
        this.prog = data.prog;
        codeFragment.add(idx, this);
        return idx + 1;
    }

    public int execute(VMThread thread, Scheduler sched, VNode[] env) {
        int envSize = prog.getEnvSize(function);
        VNode[] newEnv = new VNode[envSize];
        TreeAutomaton pattern = prog.getPattern(function);
        // if pattern==null means no parameters
        if (pattern != null && value != -1) {
            VNode v = VNode.derefer(env, env[value]);
            if (!pattern.matchValue(v, newEnv)) throw new RuntimeException(
                    "Error: Parameters do non match the function/thread signature");
        }
        thread.pushActivationRecord(function, newEnv, target, thread.codeRef);
        thread.setProgramCounter(prog.getProgramCounter(function) - 1);
        return VMThread.RUNNING;
    }

    public int verify(Hashtable symbolTable) {
        // TODO Auto-generated method stub
        return 0;
    }

    public String getError() {
        return errorMsg;
    }
}