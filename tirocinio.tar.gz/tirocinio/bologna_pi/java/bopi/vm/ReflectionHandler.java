package bopi.vm;
import java.lang.reflect.*;
import java.util.*;
/**
 * @author Samuele Carpineti 
 */
public class ReflectionHandler {
	private String request;
	private Map m;
	static private int counter;
	/** The requested object is not available */
	static final String na= "<na/>";
	/** The invocation succeeds */
	static final String ok= "<ok/>";
	public ReflectionHandler(String request) {
		this.request= request;
	}
	public ReflectionHandler() {
		m= VirtualMachine.m;
	}
	/**
	 * @param objID - is a string (actually is an XML fragment) in the following form: 
	 *                  "<ref>int</ref>| <class>String</class>"
	 * @param method - is a string (actually is an XML fragment) in the following form: "<method>String</method>"                 
	 * @param pars - is an array of strings in the following form: "<int>Integer|<string>String | <ref>Integer". 
	 * It's not an XML fragment.
	 * 
	 */
	public Object invoke(String objID, String method, String[] parsType, String[] pars)
		throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, ObjectNotFoundException, NoSuchMethodException {
		Object obj= null;
		Class c= null;
		if (objID.startsWith("<ref>")) {
			String idx= objID.substring(objID.indexOf('>') + 1, objID.indexOf("</"));
			Integer objref= new Integer(idx);
			obj= m.get(objref);
			if (obj == null)
				throw new ObjectNotFoundException(objref.toString());
			c= obj.getClass();
		} else if (objID.startsWith("<class>")) {
			String className= objID.substring(objID.indexOf('>') + 1, objID.indexOf("</"));
			try {
				c= Class.forName(className);
			} catch (ClassNotFoundException cnfe) {
				//it's a little bit wrong: the static class definition is not available (not the
				//object) 
				throw new ObjectNotFoundException(className);
			}
		}
		Object parameters[]= new Object[pars.length];
		Class[] parametersClass= new Class[pars.length];
		for (int i= 0; i < pars.length; i++) {
			if (pars[i].startsWith("<int>")) {
				parameters[i]= (new Integer(pars[i].substring(pars[i].indexOf('>') + 1)));
			} else if (pars[i].startsWith("<string>"))
				parameters[i]= new String(pars[i].substring(pars[i].indexOf('>') + 1));
			else if (pars[i].startsWith("<ref>")) {
				Integer ref= new Integer(pars[i].substring(pars[i].indexOf('>') + 1));
				parameters[i]= m.get(ref);
				if (parameters[i] == null)
					throw new ObjectNotFoundException(ref.toString());
			}
		}
		for (int i= 0; i < parsType.length; i++) {
			try {
                String className=new String(parsType[i].substring(parsType[i].indexOf('>') + 1));
                if (className.equals("int")) parametersClass[i]=Integer.TYPE;
                else if (className.equals("string")) parametersClass[i]=Integer.TYPE;
				else parametersClass[i]= Class.forName(className);
			} catch (Exception e) {
				throw new NoSuchMethodException(method);
			}
		}
		Method m= c.getMethod(method, parametersClass);
		Object ris= m.invoke(obj, parameters);
		return ris;
	}
	public String call(String objID, String method, String[] parsType, String[] pars)
		throws IllegalArgumentException, NotSupportedReturnType, IllegalAccessException, InvocationTargetException, ObjectNotFoundException, NoSuchMethodException {
		Object ris= invoke(objID, method, parsType, pars);
		if (ris instanceof Integer) {
			return "<int>" + ris.toString() + "</int>";
		}
		if (ris instanceof String) {
			return "<string>" + ris + "</string>";
		}
		if (ris instanceof Boolean) {
			throw new NotSupportedReturnType(ris.getClass().toString());
		}
		if (ris instanceof Float) {
			throw new NotSupportedReturnType(ris.getClass().toString());
		}
		if (ris instanceof Double) {
			throw new NotSupportedReturnType(ris.getClass().toString());
		} else {
			Integer idx= new Integer(++counter);
			m.put(idx, ris);
			return "<ref>" + idx.intValue() + "</ref>";
		}
	}
	public String create(String name, String[] pars)
		throws ObjectNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
		try {
			Class c= Class.forName(name);
			Object parameters[]= new Object[pars.length];
			Class[] parametersClass= new Class[pars.length];
			for (int i= 0; i < pars.length; i++) {
				if (pars[i].startsWith("<int>")) {
					parameters[i]= new Integer(pars[i].substring(pars[i].indexOf('>') + 1));
				} else if (pars[i].startsWith("<string>"))
					parameters[i]= new String(pars[i].substring(pars[i].indexOf('>') + 1));
				else if (pars[i].startsWith("<ref>")) {
					Integer ref= new Integer(pars[i].substring(pars[i].indexOf('>') + 1));
					parameters[i]= m.get(ref);
					if (parameters[i] == null)
						throw new ObjectNotFoundException(ref.toString());
				}
				parametersClass[i]= parameters[i].getClass();
			}
			Constructor contructor= c.getConstructor(parametersClass);
			Object ris= contructor.newInstance(parameters);
			Integer idx= new Integer(++counter);
			m.put(idx, ris);
			String objRef= "<ref>" + idx.toString() + "</ref>";
			return objRef;
		} catch (ClassNotFoundException cnfe) {
			//it's a little bit wrong: the static class definition is not available (not the
			//object) 
			throw new ObjectNotFoundException(name);
		}
	}
	public void delete(Integer objID) throws ObjectNotFoundException {
		if (m.remove(objID) == null) {
			throw new ObjectNotFoundException(objID.toString());
		}
	}
}
