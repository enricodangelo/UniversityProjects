/*
 * BCI_CreateObj.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Oct 27, 2004
 */
package bopi.vm;
import java.util.Hashtable;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Vector;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import bopi.values.VNode;
import bopi.values.VNodeFactory;
/**
 * @author Samuele Carpineti
 */
public class BCI_BJCreateObj extends BCI_BJInstruction {
	private String parsRef;
	private int target;
	private String className;
	/* (non-Javadoc)
	 * <createObj pars="int" target="int" className="java.util.Vector"/>
	 * @see bopi.vm.BCInstruction#parse(org.xml.sax.Attributes, java.util.Vector, int, bopi.vm.XMLHandler_Data)
	 */
	public int parse(Attributes attributes, Vector codeFragment, int idx, XMLHandler_Data data) {
		parsRef= attributes.getValue("", "pars");
		target= Integer.parseInt(attributes.getValue("", "target"));
		className= attributes.getValue("", "className");
		codeFragment.add(idx, this);
		return idx + 1;
	}
	/* (non-Javadoc)
	 * @see bopi.vm.BCInstruction#execute(bopi.vm.VMThread, bopi.vm.Scheduler, bopi.values.VNode[])
	 */
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		String parElement= new String();
		String[] pars;
		if (parsRef != null) {
			parElement += new String(env[Integer.parseInt(parsRef)].marshal());
			pars= parElement.split("</.*>");
		} else
			pars= new String[0];
		try {
			try {
				String result= "<value>" + sched.vm.reflector.create(className, pars) + "</value>";
				env[target]= VNodeFactory.generateVNode(result.getBytes());
			} catch (SAXException se) {
				se.printStackTrace(System.err);
				return VMThread.ERROR;
			} catch (IOException ioe) {
				ioe.printStackTrace(System.err);
				return VMThread.ERROR;
			}
			return VMThread.RUNNING;
		} catch (ObjectNotFoundException e) {
			return thread.handleException(BCI_BJInstruction.OBJECT_NOT_FOUND_EXCEPTION);
		} catch (NoSuchMethodException e) {
			return thread.handleException(BCI_BJInstruction.NO_SUCH_METHOD_EXCEPTION);
		} catch (InstantiationException e) {
			return thread.handleException(BCI_BJInstruction.INSTANTIATION_EXCEPTION);
		} catch (IllegalAccessException e) {
			return thread.handleException(BCI_BJInstruction.ILLEGAL_ACCESS_EXCEPTION);
		} catch (InvocationTargetException e) {
			return thread.handleException(BCI_BJInstruction.INVOCATION_TARGET_EXCEPTION);
		}
	}
	/* (non-Javadoc)
	 * @see bopi.vm.BCInstruction#verify()
	 */
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
}
