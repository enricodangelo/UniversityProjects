/*
 * Created on 21-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.util.Hashtable;
import java.io.IOException;
import java.util.Vector;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import bopi.api.API_Exception;
import bopi.api.Blockable;
import bopi.api.BolognaPiImpl;
import bopi.ta.HandlerCallback;
import bopi.ta.PatternDefaultHandler;
import bopi.ta.TreeAutomaton;
import bopi.values.ChannelLiteral;
import bopi.values.VNode;
import bopi.values.VNodeCastException;
import bopi.values.VNodeFactory;
/**
 * 
 * @author Paolo Milazzo
 */
public class BCI_Recv implements BCInstruction, HandlerCallback {
	private int sourceChannel;
	private int target = -1;
	protected TreeAutomaton pattern;
	private String errorMsg = VMThread.DEF_NOERROR_MSG;
	private XMLHandler_Data data;
	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
		sourceChannel = Integer.parseInt(attributes.getValue("", "ch"));
		String targetValue = attributes.getValue("", "target");
		data.prog.setEnvSize(data.currentThrOrFun, target);
		if (targetValue!= null) 
			target = Integer.parseInt(attributes.getValue("", "target"));
		PatternDefaultHandler.setParserHandler(data.parser, this, data.typesMap, true);
		this.data =data;
		codeFragment.add(idx++, this);
		return idx;
	}
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		BolognaPiImpl api = null;
		boolean isSingleThread = (thread.mode == VirtualMachine.SINGLE_THREAD);
		try {
			api = BolognaPiImpl.getInstance();
			api.initAPI();
			if (isSingleThread) {
				VMBlockableImpl blk = (VMBlockableImpl) thread.getBlockable();
				int[] sourceChannels = { sourceChannel };
				TreeAutomaton[] patterns = {pattern};
				blk.initRecv(env, sourceChannels, target, patterns);
				String[] chan = new String[1];
				chan[0] = ((ChannelLiteral) env[sourceChannel]).getIPAddress();
				api.reqRecv(chan, blk);
			} else if (!isSingleThread) {
				Blockable blk = thread.getBlockable();
				byte[] recvdValue = api.recv(((ChannelLiteral) env[sourceChannel]).getIPAddress(), blk);
				try {
					VNode value = VNodeFactory.generateVNode(recvdValue);
					pattern.castVNode(value, env, true);
					if (target != -1)
						env[target] = value;
					//the thread executes again the receive in case of an error in the value
				} catch (VNodeCastException v) {
					api.exitAPI();
					return execute(thread, sched, env);
				} catch (SAXException e) {
					api.exitAPI();
					return execute(thread, sched, env);
				} catch (IOException e) {
					api.exitAPI();
					return execute(thread, sched, env);
				}
			}
			api.exitAPI();
		} catch (API_Exception e) {
			errorMsg = e.getMessage();
			return VMThread.ERROR;
		}
		if (isSingleThread)
			return VMThread.WAITING;
		return VMThread.RUNNING;
	}
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getError() {
		return errorMsg;
	}
	/* (non-Javadoc)
	 * @see bopi.ta.HandlerCallback#setAutomaton(bopi.ta.TreeAutomaton)
	 */
	public void setAutomaton(TreeAutomaton ta) {
		pattern = ta;
		data.prog.setEnvSize(data.currentThrOrFun, pattern.getMaxBinding());
		data = null;
	}
	public void setVNode(VNode node) {
	    //do nothing
	}
	public void setXMLDocument(String xml) {
	    //do nothing
	}
}
