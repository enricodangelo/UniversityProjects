/*
 * Created on 13-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Stack;
import java.util.Vector;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import bopi.ta.PatternDefaultHandler;
import bopi.ta.HandlerCallback;
import bopi.ta.TreeAutomaton;
import bopi.values.VNode;
import bopi.values.VNodeDefaultHandler;
import java.util.Iterator;
/**
 *  
 * @author Paolo Milazzo
 */
public class XMLBytecodeHandler extends DefaultHandler {
	private class Handler {
		private int start;
		private int end;
		private Vector code;
		private String exception;
		Handler(String exception, int start, int end, Vector code) {
			this.exception= exception;
			this.start= start;
			this.end= end;
			this.code= code;
		}
	}
	private Vector code= null;
	//This table contains a mapping from a vector representing hte code of a fragment to another vector containing
	//the list of handlers of that code.  exceptionTable: code ------> handlersList. This data structured contains code represented as
	//Vector while we use a more effcient array representation during the execution. For this reason setProgram reads this structure 
	//and set code in the VMProgram to BCInstruction[].  
	private IdentityHashMap exceptionsTable= null;
	//This variable is a stack of tuples: (P, bytecode slot index for jump, last index of P) try P catch Q
	private Stack exceptionData= null;
	private int codeIdx= 0;
	private XMLHandler_Data data= null;
	// references to the following things are contained in "data".
	// "data" is passed to Bytecode Instructions during parsing.
	// Here, every time we re-new some of the followings, we must
	// update the reference in "data".
	private Stack nestingStack= null;
	private Stack tryStartIndex= null;
	private String currentThrOrFun= null;
	private XMLReader parser= null;
	private VMProgram prog= null;
	private Vector mains= null;
	private Vector mainParams= null;
	// maps type/pattern names into automata
	private HashMap typesMap= null;
	public XMLBytecodeHandler(XMLReader parser, int mode) {
		data= new XMLHandler_Data();
		this.parser= parser;
		data.parser= parser;
		data.mode= mode;
		exceptionData= new Stack();
	}
	/**
	 * @param handlers - a list of handlers
	 * @param code - a vector of BCInstruction
	 * @param globalExceptionsTable - the exception table where handlers should be added. It is a map from the returned BCInstruction[] 
	 * to the correspondent exception table 
	 * @return code converted to BCInstruction[]
	 */
	private BCInstruction[] createExceptionTable(Vector code, Vector handlers, IdentityHashMap globalExceptionsTable) {
		//code is stored in Vector. Here we put the code into a more efficient BCInstruction[].
		//This function is recursive. When is called on a code fragments it looks for its handlers and then the fuction is called 
		//again on the code of these handlers. The passed object globalExceptionTable is modified by adding new maps from code 
		//fragments to their exceptionsTable  
		Object[] tmp= code.toArray();
		BCInstruction[] newcode= new BCInstruction[tmp.length];
		for (int i= 0; i < tmp.length; i++) {
			newcode[i]= (BCInstruction) tmp[i];
		}
		if (handlers == null)
			return newcode;
		Iterator j= handlers.iterator();
		ExceptionsTable et= null;
		if (j.hasNext()) {
			et= new ExceptionsTable(newcode);
			globalExceptionsTable.put(newcode, et);
		}
		while (j.hasNext()) {
			Handler iHandlerRef= (Handler) j.next();
			BCInstruction[] handlerCode= createExceptionTable(iHandlerRef.code, (Vector) exceptionsTable.get(iHandlerRef.code), globalExceptionsTable);
			et.addHandler(iHandlerRef.start, iHandlerRef.end, handlerCode, iHandlerRef.exception);
		}
		return newcode;
	}
    public Map getTypeDefs(){
        return typesMap;
    }
	public VMProgram getProgram() {
		Vector handlers= (Vector) exceptionsTable.get(code);
		IdentityHashMap newExceptionsTable= new IdentityHashMap();
		prog.setCode(createExceptionTable(code, handlers, newExceptionsTable));
		prog.setExceptionTable(newExceptionsTable);
		return prog;
	}
	public String[] getMains() {
		Object[] tmp= mains.toArray();
		String[] ret= new String[tmp.length];
		for (int i= 0; i < ret.length; i++)
			ret[i]= (String) tmp[i];
		return ret;
	}
	public VNode[] getMainParams() {
		Object[] tmp= mainParams.toArray();
		VNode[] ret= new VNode[tmp.length];
		for (int i= 0; i < ret.length; i++)
			ret[i]= (VNode) tmp[i];
		return ret;
	}
	public void startDocument() throws SAXException {
		code= new Vector();
		exceptionData= new Stack();
		mains= new Vector();
		mainParams= new Vector();
		exceptionsTable= new IdentityHashMap();
		tryStartIndex= new Stack();
		codeIdx= 0;
		data.nestingStack= nestingStack= new Stack();
		data.currentThrOrFun= currentThrOrFun= null;
		data.prog= prog= new VMProgram();
		data.typesMap= typesMap= new HashMap();
        
	}
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (localName.equals("bopiLoader")) {
		    //read the code
		} else if (localName.equals("start")) {
			mains.add(attributes.getValue("", "thread"));
			VNodeDefaultHandler.setParserHandler(data.parser, new StartHandlerCallback(mainParams));
		} else if (localName.equals("bolognaPi")) {
			String length= attributes.getValue("", "length");
			if (length != null)
				code.ensureCapacity(Integer.parseInt(length));
			String depth= attributes.getValue("", "depth");
			if (depth != null)
				data.nestingStack.ensureCapacity(Integer.parseInt(depth));
		} else if (localName.equals(PatternDefaultHandler.TYPE_DECLARATION_ROOT)) {
			// setParserHandler handles the pattern (type) and calls back
			PatternDefaultHandler.setParserHandler(parser, typesMap);
		} else if (localName.equals("thread")) {
			String threadName= attributes.getValue("", "name");
			currentThrOrFun= data.currentThrOrFun = threadName;
			String envSizeString= attributes.getValue("", "envsize");
			int envSize= Integer.parseInt(envSizeString);
			// the end address is left -1: it will be changed at the end
			// of the parsing of the thread body
			// the pattern element will be set by the
			// callback of the pattern parser
			prog.addSymTable(threadName, VMProgram.THREAD, codeIdx, -1, envSize);
			// ParamHandlerCallback is an inner class implementing HandlerCallback
			// -false- means that there is no return type to be parsed
			ParamHandlerCallback callback= new ParamHandlerCallback(threadName, false);
			// setParserHandler handles the pattern and calls back
			PatternDefaultHandler.setParserHandler(parser, callback, typesMap);
		} else if (localName.equals("function")) {
			String funName= attributes.getValue("", "name");
			currentThrOrFun= data.currentThrOrFun = funName;
			String envSizeString= attributes.getValue("", "envsize");
			int envSize= Integer.parseInt(envSizeString);
			// the end address is left -1: it will be changed at the end
			// of the parsing of the thread body
			// the pattern and the type element will be set by the
			// callback of the pattern parser
			prog.addSymTable(funName, VMProgram.THREAD, codeIdx, -1, envSize);
			// ParamHandlerCallback is an inner class implementing HandlerCallback
			// -true- means that also the return type must be parsed
			ParamHandlerCallback callback= new ParamHandlerCallback(funName, true);
			// setParserHandler handles the pattern and calls back
			PatternDefaultHandler.setParserHandler(parser, callback, typesMap);
		} else if (localName.equals("send")) {
			BCInstruction instr= new BCI_Send();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("asend")) {
			BCInstruction instr= new BCI_Asend();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("recv")) {
			BCInstruction instr= new BCI_Recv();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("migrate")) {
			// TODO MIGRATION
		} else if (localName.equals("new")) {
			BCInstruction instr= new BCI_New();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("match")) {
			BCInstruction instr= new BCI_Match();
			nestingStack.push(instr);
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("store")) {
			BCInstruction instr= new BCI_Store();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		}
		// TODO nexpr and strexp
		else if (localName.equals("spawn")) {
			BCInstruction instr= new BCI_Spawn();
            nestingStack.push(instr);
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("call")) {
			BCInstruction instr= new BCI_Call();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("return")) {
			BCInstruction instr= new BCI_Return();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("delete")) {
			BCInstruction instr= new BCI_Delete();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("cast")) {
			BCInstruction instr= new BCI_Cast();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		}  else if (localName.equals("try")) {
			Object[] startAndFlag= { new Integer(codeIdx), new Boolean(true)};
			tryStartIndex.push(startAndFlag);
		} else if (localName.equals("catch")) {
			Object[] startAndFlag= (Object[]) tryStartIndex.peek();
			int start= ((Integer) startAndFlag[0]).intValue();
			boolean isFirst= ((Boolean) startAndFlag[1]).booleanValue();
			if (isFirst) {
				startAndFlag[1]= new Boolean(false);
				//first catch saves the current code, the current codeIdx into the stack and allocates
				//a vector in order to store every handler  specified through the keyword catch 
				Object[] codeAndHoles= { code, new Vector(), new Integer(codeIdx - 1)};
				exceptionData.push(codeAndHoles);
				//Creates a new code for the exception handler and reset the codeIdx 
				code= new Vector();
				codeIdx= 0;
			}
			//Add the exception handler for the code
			String handledException= attributes.getValue("", "exception");
			Object codeAndHoles[]= (Object[]) exceptionData.peek();
			Vector handledCode= (Vector) codeAndHoles[0];
			Vector handlers= (Vector) exceptionsTable.get(handledCode);
			if (handlers == null) {
				handlers= new Vector();
				exceptionsTable.put(handledCode, handlers);
			}
			handlers.add(new Handler(handledException, start, ((Integer) codeAndHoles[2]).intValue(), code));
		}
		/*
		 * The following two are special rules for the <match> instruction
		 */
		else if (localName.equals("ifmatch")) {
			BCInstruction topStack= (BCInstruction) nestingStack.peek();
			if (topStack.getClass().equals(BCI_Match.class)) {
				// do nothing... 
			} else {
				throw new RuntimeException("BCI_Match class missing in XMLBytecodeReader");
			}
		} else if (localName.equals("default")) {
			BCInstruction topStack= (BCInstruction) nestingStack.peek();
			if (topStack.getClass().equals(BCI_Match.class)) {
				((BCI_Match) topStack).setElseIndex(codeIdx);
			} else {
				throw new RuntimeException("BCI_Match class missing in XMLBytecodeReader");
			}
		} else if (localName.equals("select")) {
			BCInstruction instr= new BCI_Select();
			nestingStack.push(instr);
			codeIdx= instr.parse(attributes, code, codeIdx, data);
		} else if (localName.equals("case")) {
			BCI_Select select= (BCI_Select) nestingStack.peek();
			//a receive insruction is created but not really stored in the code because the codeIdx is decremented
			//after the parsing. So the parsing is used only for taking the pattern of each case.
			BCI_Recv instr= new BCI_Recv();
			codeIdx= instr.parse(attributes, code, codeIdx, data);
			codeIdx--;
			select.start[select.current]= codeIdx;
			select.sourceChannels[select.current]= Integer.parseInt(attributes.getValue("ch"));
			select.patterns[select.current]= instr.pattern; 
            code.add(codeIdx,new BCI_Jump());
            codeIdx++;
		}
	}
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (localName.equals("bolognaPi")) {
		} else if (localName.equals(PatternDefaultHandler.TYPE_DEFINITION)) {
		} else if (localName.equals("thread")) {
			// ADDS A TERMINATING INSTRUCTION TO THE END OF THE THREAD
			// FOR SAFETY REASONS 
			BCI_Terminate instr= new BCI_Terminate();
			prog.setEndAddress(currentThrOrFun, codeIdx);
			codeIdx= instr.parse(null, code, codeIdx, data);
		} else if (localName.equals("function")) {
			BCI_Terminate instr= new BCI_Terminate();
			prog.setEndAddress(currentThrOrFun, codeIdx);
			codeIdx= instr.parse(null, code, codeIdx, data);
		} else if (localName.equals("send")) {
		} else if (localName.equals("asend")) {
		} else if (localName.equals("recv")) {
		} else if (localName.equals("migrate")) {
			// TODO MIGRATION
		} else if (localName.equals("new")) {
		} else if (localName.equals("match")) {
			Object out= nestingStack.pop();
		} else if (localName.equals("store")) {
		}
		// TODO nexpr and strexp
		else if (localName.equals("spawn")) {
            BCI_Spawn instr = (BCI_Spawn) nestingStack.pop();
            codeIdx = instr.setTermination(code, codeIdx); /* calculates the number of step  to jump */  
		} else if (localName.equals("call")) {
		} else if (localName.equals("return")) {
		} else if (localName.equals("delete")) {
		} else if (localName.equals("ifmatch")) {
			BCInstruction topStack= (BCInstruction) nestingStack.peek();
			if (topStack.getClass().equals(BCI_Match.class)) {
				BCI_Jump instr= new BCI_Jump();
				codeIdx= instr.parse(null, code, codeIdx, data);
				((BCI_Match) topStack).setJumpInstrAtThenEnd(instr);
			} else {
				throw new RuntimeException("BCI_Match class missing in XMLBytecodeReader");
			}
		} else if (localName.equals("default")) {
			BCInstruction topStack= (BCInstruction) nestingStack.peek();
			if (topStack.getClass().equals(BCI_Match.class)) {
				((BCI_Match) topStack).setIndexAfterElse(codeIdx);
			} else {
				throw new RuntimeException("BCI_Match class missing in XMLBytecodeReader");
			}
		} else if (localName.equals("try")) {
			tryStartIndex.pop();
			Object[] codeAndHoles= (Object[]) exceptionData.pop();
			Vector handler= code;
			code= (Vector) codeAndHoles[0];
			int endIdx= ((Integer) codeAndHoles[2]).intValue();
			Vector holes= (Vector) codeAndHoles[1];
			Iterator i= holes.iterator();
			while (i.hasNext()) {
				Integer pos= (Integer) i.next();
				handler.set(pos.intValue(), new BCI_RestoreCodeFrag(endIdx));
			}
			codeIdx= endIdx + 1;
		} else if (localName.equals("catch")) {
			//leaves an empty slot for the special goto instruction. The slot will be filled when the 
			//try element is closed 
			code.add(codeIdx, null);
			Vector holes= (Vector) (((Object[]) exceptionData.peek())[1]);
			holes.add(new Integer(codeIdx++));
		} else if (localName.equals("createObj")) {
		} else if (localName.equals("deleteObj")) {
		} else if (localName.equals("callObjMethod")) {
		} else if (localName.equals("invokeObjMethod")) {
		} else if (localName.equals("cast")) {
		} else if (localName.equals("select")) {
			BCI_Select select = (BCI_Select)nestingStack.pop();
            for (int i=0; i<select.start.length; i++)
                ((BCI_Jump)(code.get(select.start[i]))).setTarget(codeIdx); 
		} else if (localName.equals("case")) {
			BCI_Select select= (BCI_Select) nestingStack.peek();
			select.end[select.current]= codeIdx;
			select.current++;
		}
	}
	private class StartHandlerCallback implements HandlerCallback {
		private Vector vect;
		public StartHandlerCallback(Vector vect) {
			this.vect= vect;
		}
		public void setAutomaton(TreeAutomaton ta) {
		}
		public void setVNode(VNode v) {
			// TODO CONTROLLARE CHE v NON CONTENGA PUNTATORI
			vect.add(v);
		}
		/* (non-Javadoc)
		 * @see bopi.ta.HandlerCallback#setXMLDocument(java.lang.String)
		 */
		public void setXMLDocument(String xml) {
			// TODO Auto-generated method stub
			
		}
	}
	private class ParamHandlerCallback implements HandlerCallback {
		private String key;
		// in a function definition both parameters and return type must
		// be parsed. At the end of the parsing of parameters the callback
		// function starts the parsing of the return type
		// parseReturn says if the return type must be parsed (function) 
		// or not (thread). The same callback function is used for both
		// parsings: wasParam is used to distingush which of them was
		// parsed.
		private boolean parseReturn;
		private boolean wasParam= true;
		public ParamHandlerCallback(String k, boolean pr) {
			key= k;
			parseReturn= pr;
		}
		public void setAutomaton(TreeAutomaton ta) {
			if (wasParam) {
				prog.setPattern(key, ta);
				prog.setEnvSize(key, ta.getMaxBinding());
				if (parseReturn) {
					wasParam= false;
					PatternDefaultHandler.setParserHandler(parser, this, typesMap);
				}
			} else {
				prog.setReturnType(key, ta);
			}
		}
		public void setVNode(VNode v) {
			// TODO Auto-generated method stub
		}
		/* (non-Javadoc)
		 * @see bopi.ta.HandlerCallback#setXMLDocument(java.lang.String)
		 */
		public void setXMLDocument(String xml) {
			// TODO Auto-generated method stub
			
		}
	}
}
