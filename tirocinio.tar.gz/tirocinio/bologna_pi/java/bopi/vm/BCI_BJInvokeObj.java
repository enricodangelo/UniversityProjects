/*
 * BCI_BJInvoke.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Nov 24, 2004
 */
package bopi.vm;

import java.util.Hashtable;

import java.lang.reflect.InvocationTargetException;
import java.util.Vector;
import org.xml.sax.Attributes;
import bopi.values.VNode;

/**
 * 
 * @author Samuele Carpineti
 */
public class BCI_BJInvokeObj extends BCI_BJInstruction {
    private String objIDRef;

    private String parsRef;

    private int methodRef;

    /*
     * (non-Javadoc) <invokeObjMethod objIDRef="int or className" pars="int"
     * target="int" method="add"/>
     * 
     * @see bopi.vm.BCInstruction#parse(org.xml.sax.Attributes,
     *      java.util.Vector, int, bopi.vm.XMLHandler_Data)
     */
    public int parse(Attributes attributes, Vector codeFragment, int idx, XMLHandler_Data data) {
        objIDRef = attributes.getValue("", "objIDRef");
        parsRef = attributes.getValue("", "pars");
        methodRef = Integer.parseInt(attributes.getValue("", "method"));
        codeFragment.add(idx, this);
        return idx + 1;
    }

    /*
     * (non-Javadoc)
     * 
     * @see bopi.vm.BCInstruction#execute(bopi.vm.VMThread, bopi.vm.Scheduler,
     *      bopi.values.VNode[])
     */
    public int execute(VMThread thread, Scheduler sched, VNode[] env) {
        String parElement = new String();
        if (parsRef != null) parElement += new String(env[Integer.parseInt(parsRef)].marshalWET());
        String[] pars = parElement.split("</.*>");
        try {
            String methodDescr = new String(env[methodRef].marshal());
            String methodName = methodDescr.substring(methodDescr.indexOf(">") + 1, methodDescr.indexOf("</method>"));
            String parsTypeListContent = methodDescr.substring(
                    methodDescr.indexOf("<parTypeList>") + "<parTypeList>".length(),
                    methodDescr.indexOf("</parTypeList>")).trim();
            String[] parsTypeList;
            if (parsTypeListContent.length() != 0) parsTypeList = parsTypeListContent.split("</.*>");
            else parsTypeList = new String[0];
            try {
                int objId = Integer.parseInt(objIDRef);
                sched.vm.reflector.invoke(new String(env[objId].marshal()), methodName, parsTypeList, pars);
            } catch (NumberFormatException nfe) {
                sched.vm.reflector.invoke("<class>" + objIDRef + "</class>", methodName, parsTypeList, pars);
            }
            return VMThread.RUNNING;
        } catch (ObjectNotFoundException e) {
            return thread.handleException(BCI_BJInstruction.OBJECT_NOT_FOUND_EXCEPTION);
        } catch (NoSuchMethodException e) {
            return thread.handleException(BCI_BJInstruction.NO_SUCH_METHOD_EXCEPTION);
        } catch (IllegalAccessException e) {
            return thread.handleException(BCI_BJInstruction.ILLEGAL_ACCESS_EXCEPTION);
        } catch (IllegalArgumentException e) {
            return thread.handleException(BCI_BJInstruction.ILLEGAL_ARGUMENT_EXCEPTION);
        } catch (InvocationTargetException e) {
            return thread.handleException(BCI_BJInstruction.INVOCATION_TARGET_EXCEPTION);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see bopi.vm.BCInstruction#verify()
     */
    public int verify(Hashtable symbolTable) {
        // TODO Auto-generated method stub
        return 0;
    }
}