/*
 * Created on 13-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.util.Hashtable;
import java.util.Iterator;

import bopi.ta.StaticAnalyzer;
import bopi.ta.TreeAutomaton;
import java.util.Map;
import java.util.Map.Entry;

/**
 * 
 * @author Paolo Milazzo
 */
public class VMProgram {
    private BCInstruction[] code = null;

    private Map<BCInstruction[], ExceptionsTable> globExTable = null;

    private Hashtable<String, SymTableElem> symbolTable = new Hashtable<String, SymTableElem>(); //thread-safe

    public static int THREAD = 0;

    public static int FUNCTION = 1;

    private Map typeDefs;

    private String XMLTypeDefs;

    /**
     * Sets the exception table for this program
     * @param exceptionsTable
     *            a map from code fragments to the correspondent exception table
     */
    public void setExceptionTable(Map<BCInstruction[], ExceptionsTable> exceptionsTable) {
        this.globExTable = exceptionsTable;
    }

    public ExceptionsTable getExceptionTable(BCInstruction[] codeFragment) {
        if (globExTable == null) return null;
        return (ExceptionsTable) globExTable.get(codeFragment);
    }

    public BCInstruction[] getCode() {
        return code;
    }

    public Map getTypeDefs() {
        return typeDefs;
    }

    public String getXMLTypeDefs() {
        return XMLTypeDefs;
    }

    public void setCode(BCInstruction[] code) {
        this.code = code;
    }

    public boolean addSymTable(String name, int type, int initAddr, int endAddr, int envSize) {
        if (isPresent(name)) return false;
        else symbolTable.put(name, new SymTableElem(type, initAddr, endAddr, envSize));
        return true;
    }

    public int getType(String name) {
        return ((SymTableElem) symbolTable.get(name)).type;
    }

    public int getEnvSize(String name) {
        return ((SymTableElem) symbolTable.get(name)).envSize;
    }

    public int getProgramCounter(String name) {
        return ((SymTableElem) symbolTable.get(name)).initAddr;
    }

    // the address of the last instruction
    public int getEndAddress(String name) {
        return ((SymTableElem) symbolTable.get(name)).endAddr;
    }

    public TreeAutomaton getPattern(String name) {
        return ((SymTableElem) symbolTable.get(name)).pattern;
    }

    public TreeAutomaton getReturnType(String name) {
        return ((SymTableElem) symbolTable.get(name)).retType;
    }

    public void setEndAddress(String name, int endAddr) {
        ((SymTableElem) symbolTable.get(name)).endAddr = endAddr;
    }

    public void setPattern(String name, TreeAutomaton ta) {
        ((SymTableElem) symbolTable.get(name)).pattern = ta;
    }

    public void setReturnType(String name, TreeAutomaton ta) {
        ((SymTableElem) symbolTable.get(name)).retType = ta;
    }

    public void setTypeDefs(Map typedefs) {
        this.typeDefs = typedefs;
    }

    public void setTypeDefs(String typedefs) {
        this.XMLTypeDefs = typedefs;
    }

    public boolean isPresent(String name, int type) {
        SymTableElem elem = (SymTableElem) symbolTable.get(name);
        if (elem == null) return false;
        return (elem.type == type);
    }

    public boolean isPresent(String name) {
        SymTableElem elem = (SymTableElem) symbolTable.get(name);
        return (elem != null);
    }

    //Simple verification procedure. It merely verifies that input patterns are
    // not ambiguos
    public boolean verify() {
        Iterator<Entry<String,SymTableElem>> i = symbolTable.entrySet().iterator();
        while (i.hasNext()) {
			Map.Entry<String,SymTableElem> entry = i.next();
            TreeAutomaton pattern = entry.getValue().pattern;
            if (!StaticAnalyzer.isNotWeaklyAmbiguous(pattern)) {
                System.err.println(entry.getKey() + " has an ambiguous input pattern");
                return false;
            }
        }
        for (int j = 0; j < code.length; j++) {
            if (code[j].verify(null) != 0) {
                System.err.println(code[j] + " is a wrong instruction");
                return false;
            }
        }
        return true;
    }

    class SymTableElem {
        public int type; // THREAD or FUNCTION

        public int initAddr;

        public int endAddr;

        public int envSize;

        public TreeAutomaton pattern;

        public TreeAutomaton retType; // only for functions

        public SymTableElem(int t, int i, int e, int s) {
            type = t;
            initAddr = i;
            endAddr = e;
            envSize = s;
        }
    }

    /**
     * Sets the envsize to the specified integer if it is greater then the size
     * of the environment
     * 
     * @param name
     *            the name of the function/thread
     * @param i
     *            the size
     */
    public void setEnvSize(String name, int i) {
        SymTableElem s = (SymTableElem) symbolTable.get(name);
        if (s.envSize <= i) s.envSize = i + 1;
    }
}
