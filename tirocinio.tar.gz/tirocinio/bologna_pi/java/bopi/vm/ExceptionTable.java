/*
 * ExceptionTable.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Jun 19, 2004
 */
package bopi.vm;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Collection;
import java.util.Vector;
import java.util.Iterator;
/**
 * 
 * @author Samuele Carpineti
 */
class ExceptionTable {
	class Interval implements Comparable {
		private int interval[]= new int[2];
		Interval(int start, int end) {
			interval[0]= start;
			interval[1]= end;
		}
		int starts() {
			return interval[0];
		}
		int ends() {
			return interval[1];
		}
		public boolean contains(int value) {
			return (value >= interval[0] && value <= interval[1]);
		}
		/**
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		public int compareTo(Object o) {
			if (o instanceof Interval) {
				Interval i= (Interval) o;
				if (i.interval[0] == interval[0] && i.interval[1] == interval[1])
					return 0;
				else if (i.interval[0] <= interval[0] && i.interval[1] >= interval[1])
					return 1;
				else if (i.interval[0] >= interval[0] && i.interval[1] <= interval[1])
					return -1;
				else
					throw new RuntimeException("Elements are not comparable " + o + " and " + this);
			} else
				throw new ClassCastException();
		}
		public String toString() {
			return "[" + starts() + ":" + ends() + "]";
		}
	}
	private TreeMap m= new TreeMap();
	void addHandler(int start, int end, BCInstruction[] handler, String exception) {
		Object h[]= { exception, handler };
		m.put(new Interval(start, end), h);
	}
	BCInstruction[] getHandler(int pc, String Exception) {
		//TODO change this with a more efficient implementation
		Collection c= m.keySet();
		SortedMap handlers= new TreeMap();
		Iterator i= c.iterator();
		while (i.hasNext()) {
			Interval interval= (Interval) i.next();
			if (interval.starts() == pc) {
				Object h[]= (Object[]) m.get(interval);
				if (((String) h[0]).equals(Exception))
					return (BCInstruction[]) ((Vector) m.get(interval)).toArray();
			}
			if (interval.contains(pc)) {
				handlers.put(interval, ((Object[]) m.get(interval))[1]);
			}
		}
		return (BCInstruction[]) handlers.get(handlers.firstKey());
	}
}
