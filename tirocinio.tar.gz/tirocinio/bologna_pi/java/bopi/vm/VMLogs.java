/*
 * Created on 21-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.FileOutputStream;

/**
 * 
 * @author Paolo Milazzo
 */
public class VMLogs extends PrintStream {

	// default filename of the log file
	private static final String DEFAULT_LOGFILE = "vmLogs";
	// level of verbosity (0 - minimun, 1 - average, 2 - maximum)
	private int loglevel = 0;
	
	// default constructor
	public VMLogs() throws FileNotFoundException {
		this(DEFAULT_LOGFILE,0);
	}
	
	// constructor that allows the definition of the filename
	public VMLogs(String filename, int level) throws FileNotFoundException {
		super(new FileOutputStream(filename),true);
		loglevel = ((level>=0)&&(level<=2)?level:0);
		this.println("log file printer initialized with verbosity level " + level);
	}
	
}
