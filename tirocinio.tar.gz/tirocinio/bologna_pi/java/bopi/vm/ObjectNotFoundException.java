package bopi.vm;

/**
 * @author Samuele Carpineti
 * An object cannot be found in the local object table
 */
public class ObjectNotFoundException extends Exception {
	  private String objectId;
	  ObjectNotFoundException(String objectId){
		this.objectId = objectId;
	  }
	  public String toString(){
		return "Object"+ objectId +"not found in local table \n";
	  }
}


