/*
 * Created on 9-feb-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

/**
 * 
 * @author Paolo Milazzo
 */
public class CodeFragmentException extends VMException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3258410629743522870L;

	public CodeFragmentException() {
		super();
	}

	public CodeFragmentException(String message) {
		super(message);
	}

}
