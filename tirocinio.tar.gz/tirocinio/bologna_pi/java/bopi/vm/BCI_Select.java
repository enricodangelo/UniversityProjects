/*
 * BCI_Select.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Nov 25, 2004
 */
package bopi.vm;

import java.util.Hashtable;
import java.io.IOException;
import java.util.Vector;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import bopi.api.API_Exception;
import bopi.api.Blockable;
import bopi.api.BolognaPiImpl;
import bopi.ta.TreeAutomaton;
import bopi.values.ChannelLiteral;
import bopi.values.VNode;
import bopi.values.VNodeFactory;
/**
 * 
 * @author Samuele Carpineti
 */
public class BCI_Select implements BCInstruction {
	int[] sourceChannels;
	int target;
	int[] start;
    int[] end;
	int current= 0;
	TreeAutomaton[] patterns;
	private String errorMsg= VMThread.DEF_NOERROR_MSG;
	public int parse(Attributes attributes, Vector<BCInstruction> codeFragment, int idx, XMLHandler_Data data) {
		int num= Integer.parseInt(attributes.getValue("", "num"));
		sourceChannels= new int[num];
		target= Integer.parseInt(attributes.getValue("target"));
		data.prog.setEnvSize(data.currentThrOrFun, target);
		start = new int[num];
        end= new int[num];
        patterns = new TreeAutomaton[num];
		codeFragment.add(idx++, this);
		return idx;
	}
	public int execute(VMThread thread, Scheduler sched, VNode[] env) {
		BolognaPiImpl api= null;
		boolean isSingleThread= (thread.mode == VirtualMachine.SINGLE_THREAD);
		String[] chan= new String[sourceChannels.length];
		for (int i= 0; i < sourceChannels.length; i++)
			chan[i]= ((ChannelLiteral) env[sourceChannels[i]]).getIPAddress();
		try {
			api= BolognaPiImpl.getInstance();
			api.initAPI();
			if (isSingleThread) {
				VMBlockableImpl blk= (VMBlockableImpl)thread.getBlockable();
                blk.initRecv(env, sourceChannels, target, patterns);
				api.reqRecv(chan, blk);
			} else if (!isSingleThread) {
				Blockable blk= thread.getBlockable();
				byte[] recvdValue= api.recv(chan, blk);
				env[target]= VNodeFactory.generateVNode(recvdValue);
                int chosen;
				for (chosen= 0;!(((ChannelLiteral) env[sourceChannels[chosen]]).getIPAddress()).equals(blk.getSubject()); chosen++);
				thread.pc=start[chosen]-1;
			}
			api.exitAPI();
		} catch (API_Exception e) {
			errorMsg= e.getMessage();
			return VMThread.ERROR;
		} catch (SAXException e) {
			e.printStackTrace();
			try {
				api.exitAPI();
			} catch (API_Exception e1) {
				e1.printStackTrace();
			}
			return VMThread.ERROR;
		} catch (IOException e) {
			e.printStackTrace();
			try {
				api.exitAPI();
			} catch (API_Exception e1) {
				e1.printStackTrace();
			}
			return VMThread.ERROR;
		}
		if (isSingleThread)
			return VMThread.WAITING;
		return VMThread.RUNNING;
	}
	public int verify(Hashtable symbolTable) {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getError() {
		return errorMsg;
	}
}
