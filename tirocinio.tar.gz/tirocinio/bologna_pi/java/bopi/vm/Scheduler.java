/*
 * Created on 20-gen-2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package bopi.vm;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import bopi.values.VNode;

/**
 * This class implements the scheduler of the BolognaPi Virtual Machine.
 * 
 * SINGLE_THREAD mode: VMThread objects are stored in a deploymenent bag (that
 * is an ArrayList) and they're executed step-by-step using a round robin
 * policy.
 * 
 * MULTI_THREAD mode: VMThread objects are executed as Java threads
 * 
 * @author Paolo Milazzo
 */
public class Scheduler extends Thread {
    // log printer
    private VMLogs log = null;

    // execution mode: SINGLE_THREAD or MULTI_THREAD
    private int mode;

    // deployment bag: a list containig the running vmthreads
    private List<VMThread> depBag = Collections.synchronizedList(new ArrayList<VMThread>());

    // deployment bag: a list containig the running vmthreads
    private List<VMThread> waitingBag = Collections.synchronizedList(new ArrayList<VMThread>());

    // index of the currently executed vmthread
    protected int currentIdx = 0;

    // size of the list (= depBag.size() but faster)
    protected int size = 0;

    // reference to the currently executed vmthread
    private VMThread currentThread = null;

    // tid counter (thread id)
    private int tidCounter = 0;

    protected VirtualMachine vm = null;

    /**
     * Default constructor. Creates the scheduler object and initializes the
     * file used for logs
     * 
     * @param vm
     *            the vritual machine which is using this scheduler
     * @param mode
     *            SINGLE_THREAD or MULTI_THREAD
     * @param vmlog
     *            the log-file handler. If it is 'null' a new one is created
     *            using 'shedulerLogs' as filename
     * 
     * @see VirtualMachine
     */
    public Scheduler(VirtualMachine vm, int mode, VMLogs vmlog) {
        this.vm = vm;
        // initializing logs
        if (vmlog == null) {
            System.err.println("SCHEDULER: null VMLogs received in scheduler constructor...");
            System.err.println("SCHEDULER: ...using file schedulerLogs, log level 0 (min)");
            try {
                log = new VMLogs("schedulerLogs", 0);
            } catch (FileNotFoundException e) {
                System.err.println("SCHEDULER: cannot initialize log file");
                System.err.println("SCHEDULER: shutting down the virtual machine");
                System.exit(1);
            }
        } else log = vmlog;
        if (mode == VirtualMachine.SINGLE_THREAD) {
            this.mode = mode;
            this.start();
        } else if (mode == VirtualMachine.MULTI_THREAD) {
            this.mode = mode;
        } else {
            log.println("SCHEDULER: mode != SINGLE_THREAD or MULTI_THREAD in constructor");
            log.println("SCHEDULER: setting SINGLE_THREAD mode (default)");
            this.mode = VirtualMachine.SINGLE_THREAD;
            this.start();
        }
    }

    /**
     * In SINGLE_THREAD mode executes step-by-step vmthreads in the deployment
     * bag In MULTI_THREAD mode does nothing
     */
    public void run() {
        log.println("SCHEDULER: Starting to run");
        if (mode == VirtualMachine.SINGLE_THREAD) {
            // vmthreads are scheduled using a Round Robin policy
            while (true) {
                synchronized (this) { // this is for synchronization with load()
                    // wait for elements in the deployment bag
                    try {
                        if (size == 0) {
                            this.wait(); // notified by load() and by unblock
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        continue;
                    }
                    // get currentThread from the deployment bag
                    currentThread = depBag.get(currentIdx);
                    // execute one step and update currentIdx
                    int step = currentThread.step();
                    if (step == VMThread.TERMINATED) {
                        terminateThread(currentIdx);
                    } else if (step == VMThread.WAITING) {
                        //i do not need to remove someone else removes the
                        // thread by means of
                        //blockThread
                    } else currentIdx = (currentIdx++) % size;
                }
            }
        } else if (mode == VirtualMachine.MULTI_THREAD) {
            // do nothing: we do this because we want to
            // allow programmers to use the scheduler in the
            // same way for both MULTI_THREAD and SINGLE_THREAD
            // modes
        } else {
            log.println("SCHEDULER: [debug] unknown mode in run()");
            log.println("SCHEDULER: shutting down the virtual machine");
            System.exit(1);
        }
    }

    protected synchronized void terminateThread(int idx) {
        depBag.remove(currentIdx);
        size--;
    }

    protected synchronized VMThread blockThread(int idx) {
        VMThread thread =  depBag.remove(idx);
        thread.setState(VMThread.WAITING);
        waitingBag.add(thread);
        size--;
        return thread;
    }

    protected synchronized void unblockThread(int idx) {
        VMThread thread = waitingBag.remove(idx);
        thread.setState(VMThread.READY);
        depBag.add(thread);
        size++;
        this.notify();
    }

    protected synchronized void unblockThread(VMThread thread) {
        waitingBag.remove(thread);
        thread.setState(VMThread.READY);
        depBag.add(thread);
        size++;
        this.notify();
    }

    /**
     * In SINGLE_THREAD mode puts a new VMThread object in the deployment bag.
     * In MULTI_THREAD mode start a new VMThread as a Java thread The new thread
     * is started with an empty environment
     * 
     * @param prog
     *            the code fragment of the new thread
     * @param threadName
     *            the name of the thread to load
     */
    public synchronized void load(VMProgram prog, String threadName) throws VMException {
        load(prog, threadName, new VNode[prog.getEnvSize(threadName)]);
    }

    public synchronized void load(VMProgram prog, int idx, VNode[] env) throws VMException {
        if (prog == null) { throw new VMException("The code fragment is null"); }
        if (idx > prog.getCode().length) { throw new VMException("pc " + idx + " out of bounds"); }
        VMThread newThread = new VMThread(mode, prog, this, idx, env, newTid(), log);
        if (mode == VirtualMachine.SINGLE_THREAD) {
            depBag.add(newThread);
            size++;
            if (size == 1) this.notify();
        } else if (mode == VirtualMachine.MULTI_THREAD) {
            newThread.start();
        } else {
            log.println("SCHEDULER: [debug] unknown mode in load()");
            log.println("SCHEDULER: shutting down the virtual machine");
            System.exit(1);
        }
    }

    /**
     * In SINGLE_THREAD mode puts a new VMThread object in the deployment bag.
     * In MULTI_THREAD mode start a new VMThread as a Java thread
     * 
     * @param prog
     *            the code fragment of the new thread
     * @param name
     *            the name of the thread to load
     * @param env
     *            the initial environment of the new thread
     */
    public synchronized void load(VMProgram prog, String name, VNode[] env) throws VMException {
        if (prog == null) throw new VMException("The code fragment is null");

        if (!prog.isPresent(name)) throw new VMException("Thread/function " + name + " not present");

        if (env == null) {
            log.println("SCHEDULER: [warning] The environment is null: an empty one is created");
            env = new VNode[prog.getEnvSize(name)];
        }
        VMThread newThread = new VMThread(mode, prog, this, name, env, newTid(), log);
        if (mode == VirtualMachine.SINGLE_THREAD) {
            depBag.add(newThread);
            size++;
            if (size == 1) this.notify();
        } else if (mode == VirtualMachine.MULTI_THREAD) {
            newThread.start();
        } else {
            log.println("SCHEDULER: [debug] unknown mode in load()");
            log.println("SCHEDULER: shutting down the virtual machine");
            System.exit(1);
        }
    }

    /**
     * Generates a new thread identifier
     * 
     * @return the new thread identifier
     */
    private String newTid() {
        return Integer.toString(tidCounter++);
    }
}
