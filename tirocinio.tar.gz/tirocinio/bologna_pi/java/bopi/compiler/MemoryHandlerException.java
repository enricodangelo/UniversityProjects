/*
 * Created on Dec 4, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package bopi.compiler;

/**
 * @author milazzo
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MemoryHandlerException extends Exception {
	public MemoryHandlerException() {
		super();
	}
	public MemoryHandlerException(String message) {
		super(message);
	}
}
