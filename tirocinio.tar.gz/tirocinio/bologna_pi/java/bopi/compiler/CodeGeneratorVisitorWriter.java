package bopi.compiler;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;

/**
 * @author samuele
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class CodeGeneratorVisitorWriter extends PrintWriter {
	private boolean keepCode = false;
	public void setKeepCode(boolean keepCode) {
		this.keepCode = keepCode;
	}
	/**
	 * @param writer
	 * @param b
	 */
	public CodeGeneratorVisitorWriter(OutputStreamWriter writer, boolean b) {
		super(writer, b);
	}
	/**
	 * @param os
	 */
	public CodeGeneratorVisitorWriter(OutputStream os) {
		super(os);
	}
	private String s="";
	/**
	 * @param out
	 */
	public CodeGeneratorVisitorWriter(Writer out) {
		super(out);
	}
	public void print(String code) {
		super.print(code);
		if (keepCode)
			this.s += code;
	}
	public void println(String code) {
		super.print(code);
		super.println();
		if (keepCode)
			this.s += code + "\n";
	}
	public String getRead() {
		return s;
	}
}
