#bash
/usr/local/javacc-3.2/bin/jjtree BolognaPi.jjt
/usr/local/javacc-3.2/bin/javacc BolognaPi.jj
