package bopi.compiler;

import java.io.OutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Vector;

import com.sun.org.apache.bcel.internal.generic.BasicType;

/**
 * @author milazzo To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CodeGeneratorVisitor implements BoPiCompilerVisitor {
	// counts type declarations at the beginning of the program
	// it is used to decide between adding either a </typeDecl> or a <typeDecl/>
	// to the output
	// after adding such a tag, it is set to -2
	private int typeDeclarationCounter = -1;

	public static final String DEFAULT_FILE_NAME = "BoPiOutput.xml";

	private String outFileName = DEFAULT_FILE_NAME;

	private CodeGeneratorVisitorWriter outFile;

	private String any = "";
//	private String any = "<complexType name=\"Any\">\n"
//			+ "	<sequence maxOccurs='unbounded' minOccurs='0'><choice><label type='ANY'><type name='Any'/></label><chan capability='o'><bottom/></chan><chan capability='i'><type name='Any'/></chan><int/><string/></choice></sequence>\n"
//			+ "</complexType>";

	private String encoding = "UTF8";

	// handles memory location numbers
	private MemoryHandler memory;

	// collects exception thrown during the visit
	private Vector<MemoryHandlerException> exceptions = new Vector<MemoryHandlerException>();

	// expression visitor
	private ExpressionPostVisitor expressionPostVisitor = null;

	public CodeGeneratorVisitor() {
		this.memory = new MemoryHandler(null);
	}

	/**
	 * @param os
	 */
	public CodeGeneratorVisitor(OutputStream os) {
		this.memory = new MemoryHandler(null);
		this.outFileName = "Temporary Output Stream";
		outFile = new CodeGeneratorVisitorWriter(os);
		outFile.setKeepCode(true);
	}

	public CodeGeneratorVisitor(String filename) {
		this.memory = new MemoryHandler(null);
		this.outFileName = filename;
		try {
			outFile = new CodeGeneratorVisitorWriter(
					new OutputStreamWriter(new FileOutputStream(outFileName), encoding), true);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public String getReadCode() {
		return this.outFile.getRead();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.SimpleNode,
	 *      java.lang.Object)
	 */
	public Object visit(SimpleNode node, Object data) {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTBoPiProgram,
	 *      java.lang.Object)
	 */
	public Object visit(ASTBoPiProgram node, Object data) {
		expressionPostVisitor = new ExpressionPostVisitor(outFile);
		// outFile.println(
		// "<?xml version=\"1.0\" encoding=\"" + (encoding.compareTo("UTF8") ==
		// 0 ? "UTF-8" : encoding) + "\"?>");
		outFile.println("<bolognaPi>");
		outFile.println("");
		node.childrenAccept(this, data);
		if (this.typeDeclarationCounter == -1) {
			outFile.println("<types>");
			outFile.println(any);
		} else if (this.typeDeclarationCounter > -1) {
			outFile.println(any);
			outFile.println("</types>");
		}
		this.typeDeclarationCounter = -2;
		outFile.println("");
		outFile.println("</bolognaPi>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTTypeDeclaration,
	 *      java.lang.Object)
	 */
	public Object visit(ASTTypeDeclaration node, Object data) {
		// the <types> tag will be closed either by visit(ASTFunctionDefinition,
		// Object) or
		// by visit(ASTBoPiProgram, Object)
		if (this.typeDeclarationCounter == -1) {
			outFile.println("<types>");
		}
		outFile.println("<complexType name=\"" + node.name + "\">");
		if (node.children[0] instanceof ASTBasicType)
			outFile.println("<sequence>");
		node.childrenAccept(this, data);
		if (node.children[0] instanceof ASTBasicType)
			outFile.println("</sequence>");
		outFile.println("</complexType>");
		this.typeDeclarationCounter++;
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTFunctionDefinition,
	 *      java.lang.Object)
	 */
	public Object visit(ASTFunctionDefinition node, Object data) {
		if (this.typeDeclarationCounter == -1) {
			outFile.println("<types>");
			outFile.println(any);
			outFile.println("</types>");
		} else if (this.typeDeclarationCounter > -1) {
			outFile.println(any);
			outFile.println("</types>");
		}
		outFile.println("");
		this.typeDeclarationCounter = -2;
		enterNewScope();
		outFile.println("<function name=\"" + node.name + "\" envsize=\"" + ((ASTFunctionDefinition) node).envSize
				+ "\">");
		outFile.println("<!--  return type and parameters -->");
		outFile.println("<returntype>");
		node.children[0].jjtAccept(this, data);
		outFile.println("</returntype>");
		outFile.println("<pattern>");
		node.children[1].jjtAccept(this, data);
		outFile.println("</pattern>");
		outFile.println();
		outFile.println("<!--  body -->");
		for (int i = 2; i < node.children.length; i++) {
			String prefix = node.name;
			node.children[i].jjtAccept(this, prefix);
		}
		outFile.println("</function>");
		outFile.println();
		exitScope();
		// }
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTTypeBinding,
	 *      java.lang.Object)
	 */
	public Object visit(ASTTypeBinding node, Object data) {
		int location = -1;
		try {
			location = memory.allocate(node.binder);
		} catch (MemoryHandlerException e) {
			exceptions.add(e);
		}
		outFile.println("<bind target=\"" + location + "\">");
		node.childrenAccept(this, data);
		outFile.println("</bind>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTTypeChoice,
	 *      java.lang.Object)
	 */
	public Object visit(ASTTypeChoice node, Object data) {
		outFile.println("<choice>");
		node.childrenAccept(this, data);
		outFile.println("</choice>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTTypeSequence,
	 *      java.lang.Object)
	 */
	public Object visit(ASTTypeSequence node, Object data) {
		outFile.println("<sequence>");
		node.childrenAccept(this, data);
		outFile.println("</sequence>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStarType,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStarType node, Object data) {
		String tag = "sequence maxOccurs='unbounded' ";
		tag += (node.symbol.equals("*") ? "minOccurs='0'" : (node.symbol.equals("+") ? "minOccurs='1'" : ""));
		outFile.println("<" + tag + ">");
		node.childrenAccept(this, data);
		outFile.println("</sequence>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTBasicType,
	 *      java.lang.Object)
	 */
	public Object visit(ASTBasicType node, Object data) {
		switch (node.whichType) {
		case ASTBasicType.CHANNEL:
			outFile.println("<chan capability=\"" + node.capability.substring(1) + "\">");
			node.children[0].jjtAccept(this, data);
			outFile.println("</chan>");
			break;
		case ASTBasicType.PORT:
			outFile.println("<port capability=\"" + node.capability.substring(1) + "\">");
			outFile.println(node.children[0].jjtAccept(this, data));
			outFile.println("</port>");
			break;
		case ASTBasicType.INT:
			outFile.println("<int/>");
			break;
		case ASTBasicType.STRING:
			outFile.println("<string/>");
			break;
		case ASTBasicType.ANY:
			outFile.println("<type name=\"Any\"/>");
			break;
		case ASTBasicType.ANY_STRING_SCHEMA:
			outFile.println("<any_ss/>");
			break;
		case ASTBasicType.VOID:
			outFile.println("<empty/>");
			break;
		case ASTBasicType.LABEL:
			if (node.label == "~") {
				outFile.println("<label type=\"ANY\">");
				node.childrenAccept(this, data);
				outFile.println("</label>");
			} else if (node.label != null) {
				// singleton
				outFile.print("<element name=\"" + node.label + "\"");
				if ((node.children.length == 1) && (node.children[0] instanceof ASTBasicType)) {
					ASTBasicType content = (ASTBasicType) node.children[0];
					switch (content.whichType) {
					case ASTBasicType.INT:
						outFile.print(" type=\"int\"");
						outFile.println("/>");
						break;
					case ASTBasicType.STRING:
						outFile.print(" type=\"string\"");
						outFile.println("/>");
						break;
					case ASTBasicType.ID:
						outFile.print(" type=\""+ content.id +"\"");
						outFile.println("/>");
						break;	
					case ASTBasicType.VOID:
						outFile.println("/>");
						break;	
					default:
						outFile.println(">");
						outFile.println("<complexType>");
						outFile.println("<sequence>");
						node.childrenAccept(this, data);
						outFile.println("</sequence>");
						outFile.println("</complexType>");
						outFile.println("</element>");
						break;
					}
				} else {
					outFile.println(">");
					outFile.println("<complexType>");
					node.childrenAccept(this, data);
					outFile.println("</complexType>");
					outFile.println("</element>");
				}
			} else {
				outFile.println("<label type=\"UNION\">");
				outFile.println("<labelName name=\"" + node.label + "\"/>");
				node.childrenAccept(this, data);
				outFile.println("</label>");
			}

			break;
		case ASTBasicType.LABEL_SET:
			if (node.label == "~")
				outFile.println("<label type=\"DIFFERENCE\">");
			else
				outFile.println("<label type=\"UNION\">");
			for (int i = 0; i < node.unionLabelSet.size(); i++) {
				outFile.println("<labelName name=\"" + node.unionLabelSet.get(i) + "\"/>");
			}
			node.childrenAccept(this, data);
			outFile.println("</label>");
			break;
		case ASTBasicType.ID:
			outFile.println("<type name=\"" + node.id + "\"/>");
			break;
		case ASTBasicType.INT_LIT:
			outFile.println("<intLit>" + node.int_lit + "</intLit>");
			break;
		case ASTBasicType.STRING_LIT:
			outFile.println("<strLit>" + node.str_lit.substring(1, node.str_lit.length() - 1) + "</strLit>");
			break;
		case ASTBasicType.ANYCHAN:
			outFile.println("<chan><bottom/></chan>");
			break;
		default:
			return null;
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpSeq,
	 *      java.lang.Object)
	 */
	public Object visit(ASTExpSeq node, Object data) {
		expressionPostVisitor.setMemory(memory);
		int location = -1;
		node.childrenAccept(this, Boolean.FALSE);
		if ((data != null) && ((Boolean) data).booleanValue() == true) {
			String freshvar = memory.getFreshVariable();
			try {
				location = memory.locationOf(freshvar);
			} catch (MemoryHandlerException e) {
				System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTExpSeq, Object)");
				System.exit(1);
			}
			outFile.println("<store target=\"" + location + "\">");
			outFile.print("<value>");
			node.childrenAccept(expressionPostVisitor, null);
			outFile.println("</value>");
			outFile.println("</store>");
		}
		return new Integer(location);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpOp,
	 *      java.lang.Object)
	 */
	public Object visit(ASTExpOp node, Object data) {
		expressionPostVisitor.setMemory(memory);
		int location = -1;
		node.loc1 = ((Integer) node.children[0].jjtAccept(this, Boolean.TRUE)).intValue();
		node.loc2 = ((Integer) node.children[1].jjtAccept(this, Boolean.TRUE)).intValue();
		if ((data != null) && ((Boolean) data).booleanValue() == true) {
			String freshvar = memory.getFreshVariable();
			try {
				location = memory.locationOf(freshvar);
			} catch (MemoryHandlerException e) {
				System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTExpOp, Object)");
				System.exit(1);
			}
			outFile.println("<store target=\"" + location + "\">");
			outFile.print("<value>");
			node.jjtAccept(expressionPostVisitor, null);
			outFile.println("</value>");
			outFile.println("</store>");
		}
		return new Integer(location);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpFunctionCall,
	 *      java.lang.Object)
	 */
	public Object visit(ASTExpFunctionCall node, Object data) {
		// TODO
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpLabelled,
	 *      java.lang.Object)
	 */
	public Object visit(ASTExpLabelled node, Object data) {
		expressionPostVisitor.setMemory(memory);
		int location = -1;
		node.childrenAccept(this, Boolean.FALSE);
		if ((data != null) && ((Boolean) data).booleanValue() == true) {
			String freshvar = memory.getFreshVariable();
			try {
				location = memory.locationOf(freshvar);
			} catch (MemoryHandlerException e) {
				System.out
						.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTExpLabelled, Object)");
				System.exit(1);
			}
			outFile.println("<store target=\"" + location + "\">");
			outFile.print("<value>");
			node.jjtAccept(expressionPostVisitor, null);
			outFile.println("</value>");
			outFile.println("</store>");
		}
		return new Integer(location);
	}

	public Object visit(ASTExpIdentifier node, Object data) {
		expressionPostVisitor.setMemory(memory);
		int location = -1;
		if ((data != null) && ((Boolean) data).booleanValue() == true) {
			String freshvar = memory.getFreshVariable();
			try {
				location = memory.locationOf(freshvar);
			} catch (MemoryHandlerException e) {
				System.out
						.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTExpIdentifier, Object)");
				System.exit(1);
			}
			outFile.println("<store target=\"" + location + "\">");
			outFile.print("<value>");
			node.jjtAccept(expressionPostVisitor, null);
			outFile.println("</value>");
			outFile.println("</store>");
		}
		return new Integer(location);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpInteger,
	 *      java.lang.Object)
	 */
	public Object visit(ASTExpInteger node, Object data) {
		expressionPostVisitor.setMemory(memory);
		int location = -1;
		if ((data != null) && ((Boolean) data).booleanValue() == true) {
			String freshvar = memory.getFreshVariable();
			try {
				location = memory.locationOf(freshvar);
			} catch (MemoryHandlerException e) {
				System.out
						.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTExpInteger, Object)");
				System.exit(1);
			}
			outFile.println("<store target=\"" + location + "\">");
			outFile.print("<value>");
			node.jjtAccept(expressionPostVisitor, null);
			outFile.println("</value>");
			outFile.println("</store>");
		}
		return new Integer(location);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpString,
	 *      java.lang.Object)
	 */
	public Object visit(ASTExpString node, Object data) {
		expressionPostVisitor.setMemory(memory);
		int location = -1;
		if ((data != null) && ((Boolean) data).booleanValue() == true) {
			String freshvar = memory.getFreshVariable();
			try {
				location = memory.locationOf(freshvar);
			} catch (MemoryHandlerException e) {
				System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTExpString, Object)");
				System.exit(1);
			}
			outFile.println("<store target=\"" + location + "\">");
			outFile.print("<value>");
			node.jjtAccept(expressionPostVisitor, null);
			outFile.println("</value>");
			outFile.println("</store>");
		}
		return new Integer(location);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpVoid,
	 *      java.lang.Object)
	 */
	public Object visit(ASTExpVoid node, Object data) {
		expressionPostVisitor.setMemory(memory);
		int location = -1;
		if ((data != null) && ((Boolean) data).booleanValue() == true) {
			String freshvar = memory.getFreshVariable();
			try {
				location = memory.locationOf(freshvar);
			} catch (MemoryHandlerException e) {
				System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTExpVoid, Object)");
				System.exit(1);
			}
			outFile.println("<store target=\"" + location + "\">");
			outFile.print("<value>");
			node.jjtAccept(expressionPostVisitor, null);
			outFile.println("</value>");
			outFile.println("</store>");
		}
		return new Integer(location);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTProcessDefinition,
	 *      java.lang.Object)
	 */
	public Object visit(ASTProcessDefinition node, Object data) {
		if (this.typeDeclarationCounter == -1) {
			outFile.println("<types>");
			outFile.println(any);
			outFile.println("</types>");
		} else if (this.typeDeclarationCounter > -1) {
			outFile.println(any);
			outFile.println("</types>");
		}
		this.typeDeclarationCounter = -2;
		outFile.println("");
		enterNewScope();
		outFile
				.println("<thread name=\"" + node.name + "\" envsize=\"" + ((ASTProcessDefinition) node).envSize
						+ "\">");
		outFile.println("<!--  parameters -->");
		outFile.println("<pattern>");
		node.children[0].jjtAccept(this, data);
		outFile.println("</pattern>");
		outFile.println();
		outFile.println("<!--  body -->");
		for (int i = 1; i < node.children.length; i++)
			node.children[i].jjtAccept(this, data);
		outFile.println("</thread>");
		outFile.println();
		exitScope();
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmSend,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmSend node, Object data) {
		Integer location = (Integer) node.children[0].jjtAccept(this, Boolean.TRUE);
		if (!node.isLiteral)
			try {
				outFile.println("<send ch=\"" + memory.locationOf(node.channel) + "\" value=\"" + location + "\"/>");
			} catch (MemoryHandlerException e1) {
				System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTStmSend, Object)");
				System.exit(1);
			}
		else
			outFile.println("<send name=\"" + node.channel + "\" value=\"" + location + "\"/>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmAsend,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmAsend node, Object data) {
		Integer location = (Integer) node.children[0].jjtAccept(this, Boolean.TRUE);
		if (!node.isLiteral)
			try {
				outFile.println("<asend ch=\"" + memory.locationOf(node.channel) + "\" value=\"" + location + "\"/>");
			} catch (MemoryHandlerException e1) {
				System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTStmAsend, Object)");
				System.exit(1);
			}
		else
			outFile.println("<asend name=" + node.channel + " value=\"" + location + "\"/>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmRecv,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmRecv node, Object data) {
		int location = -1;
		if (data == null) { // if this is a recv (and not a case of a select)
			String freshvar = memory.getFreshVariable();
			try {
				location = memory.locationOf(freshvar);
			} catch (MemoryHandlerException e) {
				System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTStmRecv, Object)");
				System.exit(1);
			}
			if (!node.isLiteral)
				try {
					outFile
							.println("<recv ch=\"" + memory.locationOf(node.channel) + "\" target=\"" + location
									+ "\">");
				} catch (MemoryHandlerException e) {
					System.out
							.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTStmRecv, Object)");
					System.exit(1);
				}
			else
				outFile.println("<recv name=\"" + node.channel + "\" target=\"" + location + "\"/>");
			outFile.println("<pattern>");
			node.children[0].jjtAccept(this, null);
			outFile.println("</pattern>");
			outFile.println("</recv>");
		} else { // if this is a case of a select
			location = ((Integer) data).intValue();
			try {
				outFile.println("<case ch=\"" + memory.locationOf(node.channel) + "\" target=\"" + location + "\">");
			} catch (MemoryHandlerException e) {
				System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTStmRecv, Object)");
				System.exit(1);
			}
			outFile.println("<pattern>");
			node.children[0].jjtAccept(this, null);
			outFile.println("</pattern>");
			// outFile.println("</case>");
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmFunctionCall,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmFunctionCall node, Object data) {
		int dummyLocation = -1;
		try {
			dummyLocation = memory.locationOf(memory.getFreshVariable());
		} catch (MemoryHandlerException e1) {
			System.out
					.println("FATAL ERROR: dummy variable error in CodeGeneratorVisitor.visit(ASTStmFunctionCall, Object)");
			System.exit(1);
		}
		if (node.children == null || node.children.length == 0)
			outFile.println("<call function=\"" + node.name + "\" target=\"" + dummyLocation + "\"/>");
		else {
			Integer location = (Integer) node.children[0].jjtAccept(this, Boolean.TRUE);
			outFile.println("<call function=\"" + node.name + "\" target=\"" + dummyLocation + "\" value=\"" + location
					+ "\"/>");
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmAssignment,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmAssignment node, Object data) {
		// Generates the code for the evaluation and then pattern matches the
		// resulting location
		try {
			int binder = memory.allocate(node.name);
			outFile.println("<!-- Assignement -->");
			Integer location = (Integer) node.children[1].jjtAccept(this, Boolean.TRUE);
			outFile.println("<match value=\"" + location + "\">");
			outFile.println("	<pattern>");
			outFile.println("	<bind target=\"" + binder + "\">");
			node.children[0].jjtAccept(this, null); // First MatchCase node
			outFile.println("  </bind>");
			outFile.println("  </pattern>");
			outFile.println("  <ifmatch/>");
			outFile.println("	<default/>");
			outFile.println("</match>");
			outFile.println("<!-- End Assignement -->");
		} catch (MemoryHandlerException mhe) {
			exceptions.add(mhe);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmIfThenElse,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmIfThenElse node, Object data) {
		// Generates the code for the evaluation and then pattern matches the
		// resulting location
		outFile.println("<!-- If-Then-Else -->");
		Integer location = (Integer) node.children[0].jjtAccept(this, Boolean.TRUE);
		outFile.println("<match value=\"" + location + "\">");
		outFile.println("	<pattern>");
		outFile.println("		<intLit>0</intLit>");
		outFile.println("  </pattern>");
		outFile.println("  <ifmatch>");
		outFile.println("		<!-- Else -->");
		node.children[2].jjtAccept(this, null);
		outFile.println("  </ifmatch>");
		outFile.println("	<default>");
		outFile.println("		<!-- Then -->");
		node.children[1].jjtAccept(this, null);
		outFile.println("	</default>");
		outFile.println("</match>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTBlock,
	 *      java.lang.Object)
	 */
	public Object visit(ASTBlock node, Object data) {
		for (int i = 0; i < node.children.length; i++) {
			node.children[i].jjtAccept(this, data);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmMatch,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmMatch node, Object data) {
		// in every match the first child is an expression and the return value
		// is an integer specifying its position
		Integer location = (Integer) node.children[0].jjtAccept(this, Boolean.TRUE);
		outFile.println("<match value=\"" + location + "\">");
		enterNewScope();
		if (node.children.length > 1)
			node.children[1].jjtAccept(this, null); // First MatchCase node
		exitScope();
		outFile.println("<default>");
		enterNewScope(); // TODO FIXME PROBLEMA CON GLI SCOPE... GLI SCOPE DI
		// DUE CASE
		// DIVERSI NON SONO SEPARATI MA ANNIDATI... NON SI POSSONO USARE
		// GLI STESSI NOMI DI BINDING
		if (node.children.length > 2) {
			Vector cases = new Vector();
			cases.add(location); // The first element is the location of the
			// expression
			// TODO FIXME -- MULTIPLE EVALUATION OF THE SAME EXPRESSION
			// AND PROBLEM WITH SIDE EFFECTS!!!
			for (int i = 3; i < node.children.length; i++)
				cases.add(node.children[i]); // The other elements are the
			// remaining MatchCase nodes
			node.children[2].jjtAccept(this, cases);
		}
		exitScope();
		outFile.println("</default>");
		outFile.println("</match>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTMatchCase,
	 *      java.lang.Object)
	 */
	public Object visit(ASTMatchCase node, Object data) {
		if (data == null) { // null means first matchcase
			outFile.println("<pattern>");
			node.children[0].jjtAccept(this, data);
			outFile.println("</pattern>");
			outFile.println("<ifmatch>");
			for (int i = 1; i < node.children.length; i++)
				node.children[i].jjtAccept(this, data);
			outFile.println("</ifmatch>");
		} else { // matchcase inside an else block
			// store a copy of the location of the expression
			int location = ((Integer) ((Vector) data).elementAt(0)).intValue();
			outFile.println("<match value=\"" + location + "\">");
			outFile.println("<pattern>");
			node.children[0].jjtAccept(this, null);
			outFile.println("</pattern>");
			outFile.println("<ifmatch>");
			for (int i = 1; i < node.children.length; i++)
				node.children[i].jjtAccept(this, null);
			outFile.println("</ifmatch>");
			if (((Vector) data).size() != 1) { // if there are other cases
				outFile.println("<default>");
				// remove the next ASTMatchCase node
				ASTMatchCase nextcase = (ASTMatchCase) ((Vector) data).remove(1);
				nextcase.jjtAccept(this, data);
				outFile.println("</default>");
			} else
				outFile.println("<default/>");
			outFile.println("</match>");
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmIfParse,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmIfParse node, Object data) {
		outFile.println("IFMATCH NON IMPLEMENTATO -- LINEA: " + node.line);
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTSelectCase,
	 *      java.lang.Object)
	 */
	public Object visit(ASTSelectCase node, Object data) {
		String receivedData_freshvar = memory.getFreshVariable();
		int location = -1;
		try {
			location = memory.locationOf(receivedData_freshvar);
		} catch (MemoryHandlerException e) {
			System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTStmSelectCase, Object)");
			System.exit(1);
		}
		for (int i = 0; i < node.children.length; i++)
			// the new integer informs visit(ASTRecv,Object) that this is a
			// select
			node.children[i].jjtAccept(this, new Integer(location));
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmSelect,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmSelect node, Object data) {
		// The same location (denoted by the fresh variable) is used for all the
		// inputs of the
		// choice (all the cases of the select). A new scope is created for each
		// case, therefore
		// the fresh variable will be accessed as a variable of a previous scope
		// (one indirection).
		String receivedData_freshvar = memory.getFreshVariable();
		int location = -1;
		try {
			location = memory.locationOf(receivedData_freshvar);
		} catch (MemoryHandlerException e) {
			System.out.println("FATAL ERROR: allocation error in CodeGeneratorVisitor.visit(ASTStmSelect, Object)");
			System.exit(1);
		}
		outFile.println("<select num=\"" + node.children.length + "\">");
		for (int i = 0; i < node.children.length; i++) {
			// outFile.println("<case>");
			enterNewScope();
			node.children[i].jjtAccept(this, new Integer(location));
			exitScope();
			outFile.println("</case>");
		}
		outFile.println("</select>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmSpawn,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmSpawn node, Object data) {
		outFile.println("<spawn>");
		enterNewScope();
		node.childrenAccept(this, data);
		exitScope();
		outFile.println("</spawn>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmReturn,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmReturn node, Object data) {
		Integer location = (Integer) node.children[0].jjtAccept(this, Boolean.TRUE);
		outFile.println("<return value=\"" + location + "\"/>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmTryCatch,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmTryCatch node, Object data) {
		outFile.println("<try>");
		for (int i = 0; i < node.children.length; i++)
			node.children[i].jjtAccept(this, data);
		outFile.println("</try>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTCatchException,
	 *      java.lang.Object)
	 */
	public Object visit(ASTCatchException node, Object data) {
		outFile.println("<catch " + "exception=\"" + node.exception.substring(1, node.exception.length() - 1) + "\""
				+ ">");
		if (node.children == null) {
			outFile.println("</catch>");
			return null;
		}
		for (int i = 0; i < node.children.length; i++)
			node.children[i].jjtAccept(this, data);
		outFile.println("</catch>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmNewChannel,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmNewChannel node, Object data) {
		try {
			outFile.println("<new target=\"" + memory.allocate(node.name) + "\">");
			outFile.println("	<pattern>");
		} catch (MemoryHandlerException mhe) {
			exceptions.add(mhe);
		}
		node.childrenAccept(this, data);
		outFile.println("	</pattern>");
		outFile.println("</new>");
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmNil,
	 *      java.lang.Object)
	 */
	public Object visit(ASTStmNil node, Object data) {
		// Nothing to do...
		return null;
	}

	private void enterNewScope() {
		MemoryHandler old = this.memory;
		this.memory = new MemoryHandler(this.memory);
	}

	private void exitScope() {
		this.memory = this.memory.getFather();
	}
}
