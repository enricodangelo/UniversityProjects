/*
 * Created on Sep 25, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package bopi.compiler;

import java.util.HashMap;

/**
 * @author milazzo
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MemoryHandler {

	private HashMap symTable = new HashMap();
	private MemoryHandler father = null;
	private int locationCounter = 0;

	public MemoryHandler(MemoryHandler myfather) {
		this.father = myfather;
		this.locationCounter = (myfather!=null ? father.getLocationCounter() : 0);
	}
	
	public int getLocationCounter() {
		return locationCounter;
	}
	
	public MemoryHandler getFather() {
		return father;
	}
	
	public int allocate(String variable) throws MemoryHandlerException {
		// check double declarations
		if (symTable.containsKey(variable)) throw new MemoryHandlerException("Multiple definition of: " + variable);
		symTable.put(variable,new Integer(locationCounter));
		return locationCounter++; 
	}
	
	public int locationOf(String variable) throws MemoryHandlerException {
		if (symTable.containsKey(variable))
			return ((Integer) symTable.get(variable)).intValue();
		else if (father!=null)
			return father.locationOf(variable);
		else throw new MemoryHandlerException("Variable undefined: " + variable);
	}
	
	public String getFreshVariable() {
		int loc = locationCounter;
		try {
			this.allocate("__freshvar__" + loc);
		}
		catch(MemoryHandlerException mhe) {
			System.out.println("FATAL ERROR: allocation error in MemoryHandler.getFreshVariable()");
			System.exit(1);
		}
		return "__freshvar__" + loc;
	}
}
