/*
 * Loader.java
 * BolognaPi
 * author: Samuele Carpineti
 * Created on Nov 24, 2004
 */
package bopi.compiler;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import bopi.api.API_Exception;
import bopi.api.BolognaPiAPI;
import bopi.api.BolognaPiImpl;
import bopi.api.Channel;
import bopi.ta.WSDLParser;
import bopi.values.VNodeDefaultHandler;
/**
 * 
 * @author Samuele Carpineti
 */
public class Loader {
	public static void load(String file) throws IOException, API_Exception {
		FileInputStream is= new FileInputStream(file);
		byte[] bytes= new byte[is.available()];
		is.read(bytes);
		String content= new String(bytes);
		String[] lines= content.split("\n");
		HashMap locations= new HashMap();
		HashMap chans= new HashMap();
		String typeDefs= new String();
		int chanCounter=0;
		for (int i= 0; i < lines.length; i++) {
			String line= lines[i].trim();
			if (line.trim().length() == 0)
				continue;
			if (line.trim().startsWith("%"))
				continue;
			if (line.startsWith("location")) {
				String[] nameAndLoc= line.substring("location".length() + 1).split("=");
				locations.put(nameAndLoc[0].trim(), nameAndLoc[1].trim());
			} else if (line.trim().startsWith("typedef")) {
				typeDefs += line.trim();
                continue;
			} else if (line.startsWith("chan")) {
				String[] chanAndLoc= line.substring("chan".length() + 1).split("=",2);
				String howAndWhere= chanAndLoc[1].trim();
				if (howAndWhere.startsWith("new")) {
					String locName= howAndWhere.substring(howAndWhere.indexOf("@") + 1).trim();
					String locValue= locations.get(locName).toString();
					String ip= locValue.substring(0, locValue.indexOf(':'));
					int port= Integer.parseInt(locValue.substring(locValue.indexOf(':') + 1));
					BolognaPiAPI api= BolognaPiImpl.getInstance(ip, port);
					api.initAPI();
					Channel chan= new Channel(ip, port);
					api.exitAPI();
					String type= howAndWhere.substring(howAndWhere.indexOf('<') + 1, howAndWhere.indexOf('@') - 1);
					String typeName= "Chan_Type_Tmp"+ chanCounter;
					typeDefs += "typedef " + typeName + "=" +type +";";					
					String xmlTypeDefs = BoPiCompiler.compile(new ByteArrayInputStream(typeDefs.getBytes()));
					xmlTypeDefs= xmlTypeDefs.replaceAll("<bolognaPi>","").replaceAll("</bolognaPi>","").trim();
					String xmlType = "<type name='Chan_Type_Tmp" +chanCounter +"'/>";
                    String wsdl= WSDLParser.writeWSDL(WSDLParser.createWSDL(typeName, chan.getName(), xmlTypeDefs, ""), chan.getName());
					chanCounter++;
					chans.put(chanAndLoc[0].trim(), wsdl);
				} else if (howAndWhere.startsWith("import")) {
					//for the moment it works only with lines like:
					//chan chanName= import [ip:port] ...
					//which import bopi channels. External Web services are not supported.
					String chanName= howAndWhere.substring(howAndWhere.indexOf('[') + 1, howAndWhere.indexOf(']'));
					String channelAddress=WSDLParser.getChannelAddress(chanName);
					String ip= channelAddress.substring(0, channelAddress.indexOf(':'));
					String sPort = channelAddress.substring(channelAddress.indexOf(':') + 1, channelAddress.indexOf('#'));
					int port= Integer.parseInt(sPort);
					BolognaPiAPI api= BolognaPiImpl.getInstance(ip, port);
					api.initAPI();
					Channel chan= Channel.getReference(channelAddress);
					api.exitAPI();
					chans.put(chanAndLoc[0].trim(), chanName);
				}
			} else if (line.startsWith("load")) {
				String fileName= line.substring("load".length() + 1, line.indexOf('.')).trim() + ".xml";
				String threadName= line.substring(line.indexOf('.') + 1, line.indexOf('(')).trim();
				String pars= line.substring(line.indexOf('(') + 1, line.indexOf(')')).trim();
				Set chanList= chans.entrySet();
				Iterator it= chanList.iterator();
				while (it.hasNext()) {
					Map.Entry entry= (Map.Entry) it.next();
					String chName= entry.getKey().toString();
                    String chValue= entry.getValue().toString();
					pars= pars.replaceAll(chName, chValue);
				}
				String header=
					"<?xml version='1.0' encoding='UTF-8'?>\n"
						+ "<bopiLoader xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'"
						+ " xsi:schemaLocation='http://www.cs.unibo.it/fusion/bopi'>\n"
						+ "<start thread='"
						+ threadName
						+ "'>\n  "
						+ "<value xmlns='" + VNodeDefaultHandler.VNODE_NAMESPACE + "'>\n    "
						+ pars
						+ "\n  </value>\n</start>";
				FileInputStream bis= new FileInputStream(fileName);
				byte[] code= new byte[bis.available()];
				bis.read(code);
				String bytecode= header + new String(code) + "</bopiLoader>";
				String location= locations.get(line.substring(line.indexOf("@") + 1, line.indexOf("#")).trim().toString()).toString();
				String ip= location.substring(0, location.indexOf(':'));
				int port= Integer.parseInt(location.substring(location.indexOf(':') + 1));
				BolognaPiAPI api= BolognaPiImpl.getInstance(ip, port);
				api.initAPI();
				Channel c= Channel.getReference(location + "#" + line.substring(line.indexOf("#") + 1));
				c.asend(bytecode.getBytes());
				api.exitAPI();
				System.out.println("Code sent: " + line);
			} else
				throw new IOException("Wrong loading file: line " + i + " does not start with a directive: " + lines[i]);
		}
	}
	public static void main(String[] args) throws IOException, API_Exception {
		for (int i= 0; i < args.length; i++)
			Loader.load(args[i]);
	}
}
