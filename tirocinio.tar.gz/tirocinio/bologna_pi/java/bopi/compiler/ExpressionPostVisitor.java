/*
 * Created on Feb 17, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package bopi.compiler;

import java.io.PrintWriter;

import bopi.values.VNodeDefaultHandler;

/**
 * @author milazzo
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ExpressionPostVisitor implements BoPiCompilerVisitor {

	private PrintWriter outFile = null;
	private MemoryHandler memory = null;
	
	public ExpressionPostVisitor(PrintWriter out) {
		outFile = out;
	}

	public void setMemory (MemoryHandler newMem) {
		memory = newMem;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.SimpleNode, java.lang.Object)
	 */
	public Object visit(SimpleNode node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTBoPiProgram, java.lang.Object)
	 */
	public Object visit(ASTBoPiProgram node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTTypeDeclaration, java.lang.Object)
	 */
	public Object visit(ASTTypeDeclaration node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTFunctionDefinition, java.lang.Object)
	 */
	public Object visit(ASTFunctionDefinition node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTBasicType, java.lang.Object)
	 */
	public Object visit(ASTBasicType node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTProcessDefinition, java.lang.Object)
	 */
	public Object visit(ASTProcessDefinition node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTTypeChoice, java.lang.Object)
	 */
	public Object visit(ASTTypeChoice node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTTypeSequence, java.lang.Object)
	 */
	public Object visit(ASTTypeSequence node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStarType, java.lang.Object)
	 */
	public Object visit(ASTStarType node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTTypeBinding, java.lang.Object)
	 */
	public Object visit(ASTTypeBinding node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpSeq, java.lang.Object)
	 */
	public Object visit(ASTExpSeq node, Object data) {
		node.childrenAccept(this,data);
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpOp, java.lang.Object)
	 */
	public Object visit(ASTExpOp node, Object data) {
		outFile.print("<"+ node.operator + " xmlns=\"" + VNodeDefaultHandler.VNODE_NAMESPACE +"\"" + " op1=\"" + node.loc1 + "\" op2=\"" + node.loc2 + "\"/>");
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpFunctionCall, java.lang.Object)
	 */
	public Object visit(ASTExpFunctionCall node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpLabelled, java.lang.Object)
	 */
	public Object visit(ASTExpLabelled node, Object data) {
		//outFile.print("<label name=\"" + node.label + "\">");
		outFile.print("<" + node.label + ">");
		node.childrenAccept(this,data);
		outFile.print("</" + node.label + ">");
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpIdentifier, java.lang.Object)
	 */
	public Object visit(ASTExpIdentifier node, Object data) {
		try {
			outFile.print("<load xmlns=\"" + VNodeDefaultHandler.VNODE_NAMESPACE +"\" value=\"" + memory.locationOf(node.name) + "\"/>");
		} catch (MemoryHandlerException e) {
			System.out.println("FATAL ERROR: allocation error in ExpressionPostVisitor.visit(ASTExpIdentifier, Object)");
			e.printStackTrace();
			System.exit(1);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpInteger, java.lang.Object)
	 */
	public Object visit(ASTExpInteger node, Object data) {
		outFile.print("<intLit xmlns=\"" + VNodeDefaultHandler.VNODE_NAMESPACE + "\">"+ node.value + "</intLit>");
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpString, java.lang.Object)
	 */
	public Object visit(ASTExpString node, Object data) {
		outFile.print("<strLit xmlns=\"" + VNodeDefaultHandler.VNODE_NAMESPACE + "\">"+ node.value + "</strLit>");
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTExpVoid, java.lang.Object)
	 */
	public Object visit(ASTExpVoid node, Object data) {
		outFile.print("<void xmlns=\"" + VNodeDefaultHandler.VNODE_NAMESPACE +"\"" + "/>");
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmSend, java.lang.Object)
	 */
	public Object visit(ASTStmSend node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmAsend, java.lang.Object)
	 */
	public Object visit(ASTStmAsend node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmRecv, java.lang.Object)
	 */
	public Object visit(ASTStmRecv node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmFunctionCall, java.lang.Object)
	 */
	public Object visit(ASTStmFunctionCall node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmAssignment, java.lang.Object)
	 */
	public Object visit(ASTStmAssignment node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmIfThenElse, java.lang.Object)
	 */
	public Object visit(ASTStmIfThenElse node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmMatch, java.lang.Object)
	 */
	public Object visit(ASTStmMatch node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmIfParse, java.lang.Object)
	 */
	public Object visit(ASTStmIfParse node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmSelect, java.lang.Object)
	 */
	public Object visit(ASTStmSelect node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmSpawn, java.lang.Object)
	 */
	public Object visit(ASTStmSpawn node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmReturn, java.lang.Object)
	 */
	public Object visit(ASTStmReturn node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmTryCatch, java.lang.Object)
	 */
	public Object visit(ASTStmTryCatch node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmNewChannel, java.lang.Object)
	 */
	public Object visit(ASTStmNewChannel node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTStmNil, java.lang.Object)
	 */
	public Object visit(ASTStmNil node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTCatchException, java.lang.Object)
	 */
	public Object visit(ASTCatchException node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTSelectCase, java.lang.Object)
	 */
	public Object visit(ASTSelectCase node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTMatchCase, java.lang.Object)
	 */
	public Object visit(ASTMatchCase node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see bopi.compiler.BoPiCompilerVisitor#visit(bopi.compiler.ASTBlock, java.lang.Object)
	 */
	public Object visit(ASTBlock node, Object data) {
		// TODO Auto-generated method stub
		return null;
	}

}
