/*
 * BoPiApplet.java
 * project: BolognaPi
 * @author Simone Tacconi
 * Created on Mar 2005
 */

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.TreeSet;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

import org.xml.sax.SAXException;
import bopi.compiler.BoPiCompiler;
import bopi.compiler.ParseException;
import bopi.ta.Assumption;
import bopi.ta.PatternFactory;
import bopi.ta.StaticAnalyzer;
import bopi.ta.TreeAutomaton;

/**
 * The Main class for create, handle and run the BoPiApplet and his functions
 */

public class SchemaApplet extends JApplet implements ActionListener {

    private static final long serialVersionUID = 3977298815378600245L;

    TextArea t1, out1, result;

    Panel out1_pan, op_panel, ris_panel;

    ButtonGroup cbg;

    JRadioButton a, s;

    Label label;

    SelectFrameSingleTwoList f2 = null;

    SelectFrameSingle f1 = null;

    Map<String, TreeAutomaton> map1;

    String lastSchemaComp = null;

    final int Fontsize = 14;

    BoPiCompiler bopiCompiler;

    /**
     * Make a new operation button
     * 
     * @param label
     *            the string that contain the label of the button
     * @param command
     *            the action command refer to this button
     * @return the new object button
     */
    private JButton opbutton(String label, String command) {
        JButton jb = new JButton(label);
        jb.setActionCommand(command);
        jb.addActionListener(this);
        return jb;
    }

    /**
     * Make a new function button (just like a clear button the clean the text
     * area)
     * 
     * @param label
     *            the string that contain the label of the button
     * @param command
     *            the action command refer to this button
     * @return the new object button
     */
    private Button funbutton(String label, String command) {
        Button b = new Button(label);
        b.setActionCommand(command);
        b.addActionListener(this);
        b.setSize(5, 5);
        return b;
    }

    /**
     * Create and initialize the applet and all his components
     */
    public void init() {
        System.out.println("BoPi Applet Execution Terminal \n\n");

        /* Set layout to the applet */
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        getContentPane().setLayout(gridbag);
        c.insets = new Insets(5, 12, 5, 12);
        setSize(900, 825);

        /* Applet components creation */
        /* Create panel for schema1 */
        Panel schema1_pan = new Panel();
        schema1_pan.setLayout(new BorderLayout());
        t1 = new TextArea("", 3, 4, TextArea.SCROLLBARS_VERTICAL_ONLY);
        t1.setFont(new Font("SansSerif", Font.PLAIN, Fontsize + 2));
        schema1_pan.add(t1, BorderLayout.CENTER);
        Panel top = new Panel();
        top.setLayout(new BorderLayout());
        label = new Label("Schema Definition ::=");
        label.setFont(new Font("SansSerif", Font.BOLD, 22));
        top.add(label, BorderLayout.WEST);
        Label schemaId = new Label("Id");
        schemaId.setFont(new Font("SansSerif", Font.ITALIC, 16));
        schemaId.setAlignment(Label.RIGHT);
        Label define = new Label("= S    |    SchemaDefinition ;  SchemaDefinition ");
        define.setFont(new Font("SansSerif", Font.PLAIN, 16));
        define.setAlignment(Label.LEFT);
        Panel definition = new Panel(new FlowLayout(FlowLayout.LEFT));
        definition.add(schemaId);
        definition.add(define);
        top.add(definition, BorderLayout.CENTER);
        Panel topeast = new Panel();
        topeast.add(funbutton("clear", "CLEARTYPE"));
        top.add(topeast, BorderLayout.EAST);
        schema1_pan.add(top, BorderLayout.NORTH);

        /* create button for operation */
        op_panel = new Panel();
        op_panel.setLayout(new GridLayout(4, 1, 10, 20));
        op_panel.add(funbutton("clear", "CLEARRESULT"));
        op_panel.add(funbutton("+", "MOREFONT"));
        op_panel.add(funbutton("-", "LESSFONT"));
        op_panel.add(funbutton("reset", "NORMALFONT"));

        /* Creare panel for result */
        Panel ris_panel = new Panel();
        ris_panel.setLayout(new BorderLayout(10, 0));
        top = new Panel();
        top.setLayout(new FlowLayout(FlowLayout.LEFT));
        label = new Label("Operations on Schema");
        label.setFont(new Font("SansSerif", Font.BOLD, 22));
        top.add(label);
        top.add(opbutton("SubSchema", "SUBTYPE"));
        top.add(opbutton("Equals", "EQUALS"));
        top.add(opbutton("Difference", "DIFFERENCE"));
        top.add(opbutton("Product", "PRODUCT"));
        top.add(opbutton("Union", "UNION"));

        Panel p = new Panel();
        p.setLayout(new GridLayout(1, 2));
        cbg = new ButtonGroup();
        a = new JRadioButton("Automa", false);
        s = new JRadioButton("Schema", true);
        a.setActionCommand("Automa");
        s.setActionCommand("Schema");
        cbg.add(a);
        ;
        cbg.add(s);
        p.add(a);
        p.add(s);
        top.add(p);

        result = new TextArea("", 1, 80);
        result.setFont(new Font("Dialog", Font.PLAIN, Fontsize));
        result.setEditable(true);
        ris_panel.add(result, BorderLayout.CENTER);
        ris_panel.add(top, BorderLayout.NORTH);
        ris_panel.add(op_panel, BorderLayout.EAST);

        /* create output panel for schema 1 */
        out1_pan = new Panel(new BorderLayout());
        Panel t = new Panel();
        t.setLayout(new BorderLayout());
        label = new Label("Output");
        label.setFont(new Font("SansSerif", Font.BOLD, 22));
        t.add(label, BorderLayout.WEST);
        Panel bottomPan = new Panel(new FlowLayout(FlowLayout.LEFT));
        bottomPan.add(opbutton("xml", "XMLTYPE"));
        bottomPan.add(opbutton("Automa", "AUTOMA"));
        bottomPan.add(opbutton("RegEx", "REGEX"));
        bottomPan.add(opbutton("IsEmpty", "ISEMPTY"));
        t.add(bottomPan, BorderLayout.CENTER);
        topeast = new Panel();
        topeast.add(funbutton("clear", "CLEAROUT"));
        t.add(topeast, BorderLayout.EAST);
        out1 = new TextArea("", 10, 40);
        out1.setFont(new Font("Dialog", Font.PLAIN, Fontsize));
        out1_pan.add(out1, BorderLayout.CENTER);
        out1_pan.add(t, BorderLayout.NORTH);

        /* Insert and position of components */
        c.fill = GridBagConstraints.BOTH; // Set component expansion
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.gridwidth = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(schema1_pan, c);
        getContentPane().add(schema1_pan);

        c.fill = GridBagConstraints.BOTH;
        c.weightx = 0.0;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridheight = 2;
        c.weighty = 3.0;
        gridbag.setConstraints(out1_pan, c);
        getContentPane().add(out1_pan);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weighty = 1.0;
        gridbag.setConstraints(ris_panel, c);
        getContentPane().add(ris_panel);

    }

    public void start() {
        clearAllComputing();
    }

    public void stop() {
        //do nothing
    }

    /**
     * Remove all the existing components
     */
    public void destroy() {
        removeAll();
    }

    /**
     * Invoke the corresponding operation when a button is pressed
     * 
     * @param e
     *            the event generate by the relative button
     */
    public void actionPerformed(ActionEvent e) {
        String lab = e.getActionCommand();

        if (lab.equals("CLEARTYPE")) // clear the text area schema 1
        t1.setText("");
        if (lab.equals("CLEARRESULT")) // clear the result area
        result.setText("");
        if (lab.equals("CLEAROUT")) out1.setText("");
        if (lab.equals("MOREFONT")) moreFontsize();
        if (lab.equals("LESSFONT")) lessFontsize();
        if (lab.equals("NORMALFONT")) setFontsize(Fontsize);

        if (!isFieldEmpty(t1.getText())) {
            if (lab.equals("UNION") || lab.equals("DIFFERENCE") || lab.equals("EQUALS") || lab.equals("PRODUCT")
                    || lab.equals("SUBTYPE")) try {
                computeType(t1.getText());
                selectOperBinary(lab);
            } catch (AppletException ex) {
                openDialog(ex.getSource(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        if (!isFieldEmpty(t1.getText())) {
            if (lab.equals("XMLTYPE")) try {
                printXML(t1.getText());
            } catch (AppletException ex) {
                openDialog(ex.getSource(), "Error", JOptionPane.ERROR_MESSAGE);
            }

            else if (lab.equals("AUTOMA") || lab.equals("ISEMPTY") || lab.equals("REGEX")) try {
                computeType(t1.getText());
                selectOperUnary(t1.getText(), lab);
            } catch (AppletException ex) {
                openDialog(ex.getSource(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Create a dialog window to comunicate an error
     * 
     * @param er
     *            a string with the error
     * @param title
     *            a string with the title of dialog
     * @param messageType
     *            the type of dialog
     */
    public void openDialog(String er, String title, int messageType) {
        JOptionPane pane = new JOptionPane(er, messageType);
        JDialog jdialog = pane.createDialog(this, "BoPiApplet " + title);
        jdialog.setVisible(true);

    }

    /**
     * Check if the string is empty
     * 
     * @param s
     *            the string from a text area
     * @return true if the string is empty or only ";", false otherwise
     */
    public boolean isFieldEmpty(String s) {
        s = s.trim();
        if ((s.equals("")) || (s.equals(";"))) return true;
        else return false;
    }

    /**
     * Compute for which schema we invoke the operation and veryfing if it is
     * necessary: if the string is the last computated the don't recompile to
     * XML and don't generate the maps
     * 
     * @param s
     *            a string writen in the BoPi schema syntax
     * 
     */
    public void computeType(String s) {
        if ((lastSchemaComp == null) || (!isTypeComputated(s, lastSchemaComp))) {
            map1 = CompileAndMapping(s);
            lastSchemaComp = s;
        }
    }

    /**
     * Check which schema (1 or 2) and then verify if we have to take a choice
     * between schemas ( create a selecting window) or call the method to do the
     * operation
     * 
     * @param s
     *            a string writen in the BoPi schema syntax
     * @param op
     *            the string with the operation selected
     */
    public void selectOperUnary(String s, String op) {
        if (f1 != null) {
            f1.setVisible(false);
            remove(f1);
            f1 = null;
        }
        if (map1.size() > 1) f1 = new SelectFrameSingle(this, map1, op);
        else {
            if (op.equals("AUTOMA")) printAutoma(map1, getFirstTypeName(map1));
            else if (op.equals("ISEMPTY")) isLangEmpty(map1, getFirstTypeName(map1));
            else if (op.equals("REGEX")) printRegEx(map1, getFirstTypeName(map1));
        }
    }

    /**
     * Print on result area the compiled XML generated by the BoPi compiler
     * OPTIMIZATION: verify if exists the XML and the don't compile
     * 
     * @param s
     *            a string writen in the BoPi schema syntax
     */
    public void printXML(String s) {
        s = s.trim();
        String ris = compile(setStringType(s));
        ris = cleanXML(ris);
        // ris = hideANY(ris);
        out1.append("XML FOR SCHEMA DECLARATION:\n" + ris + "\n\n");
    }

    /**
     * Print the automa extract of the specified schema in the result area
     * 
     * @param m
     *            the map contained the builted automa
     * @param type
     *            the type name to print
     * 
     */
    public void printAutoma(Map<String, TreeAutomaton> m, String type) {
        TreeAutomaton ta = getTreeAutomaton(m, type);
        out1.append("AUTOMATA FOR " + type + " :\n" + ta.toString() + "\n\n");
    }

    /**
     * Verifing if a schema has value using the BoPi methods and print the
     * answer on the rght area
     * 
     * @param m
     *            the map contained the builted automa
     * @param type
     *            the schema name to print
     */
    public void isLangEmpty(Map<String, TreeAutomaton> m, String type) {
        TreeAutomaton ta = getTreeAutomaton(m, type);
        if (StaticAnalyzer.isEmpty(ta)) out1.append(type + " HAS NO VALUES\n\n");
        else out1.append(type + " HAS VALUES \n\n");
    }

    public void printRegEx(Map<String, TreeAutomaton> m, String type) {
        TreeAutomaton ta = getTreeAutomaton(m, type);
        String RegEx = ta.toRegExType();
        out1.append("REGULAR EXPRESSION FOR " + type + " :\n" + RegEx + "\n\n");

    }

    /**
     * Runs the select operation between two schema and eventually create a
     * selection window
     * 
     * @param op
     *            the string with the operation name invoked
     */
    public void selectOperBinary(String op) {
        if (map1.size() > 1) {
            if (f2 != null) {
                f2.setVisible(false);
                remove(f2);
                f2 = null;
            }
            f2 = new SelectFrameSingleTwoList(this, map1, map1, op);

        } else if (op.equals("SUBTYPE")) verifySubtyping(map1, map1, getFirstTypeName(map1), getFirstTypeName(map1));
        else if (op.equals("UNION")) computeUnion(map1, map1, getFirstTypeName(map1), getFirstTypeName(map1));
        else if (op.equals("DIFFERENCE")) computeDifference(map1, map1, getFirstTypeName(map1), getFirstTypeName(map1));
        else if (op.equals("PRODUCT")) computeProduct(map1, map1, getFirstTypeName(map1), getFirstTypeName(map1));
        else if (op.equals("EQUALS")) verifyEquals(map1, map1, getFirstTypeName(map1), getFirstTypeName(map1));
    }

    /**
     * verifing subtyping between t1 and t2 extracting the relative automata
     * from the two automaton maps
     * 
     * @param m1
     *            map from schema 1
     * @param m2
     *            map from schema 2
     * @param t1
     *            the schema name selected from schema 1
     * @param t2
     *            the schema name selected from schema 2
     */
    public void verifySubtyping(Map<String, TreeAutomaton> m1, Map<String, TreeAutomaton> m2, String t1, String t2) {
        TreeAutomaton ta1 = getTreeAutomaton(m1, t1);
        TreeAutomaton ta2 = getTreeAutomaton(m2, t2);
        if ((ta1 == ta2) || (ta1.equals(ta2)) || (ta1.isNull(new TreeSet<Assumption>()))) result.append(t1
                + " IS A SUBSCHEMA OF " + t2);
        else {
            TreeAutomaton t = TreeAutomaton.difference(ta1, ta2);
            if (t.isNull(new TreeSet<Assumption>())) result.append(t1 + " IS SUBSCHEMA OF " + t2);
            else {
                result.append(t1 + " IS NOT A SUBSCHEMA OF " + t2 + " : " + t1 + "\\" + t2 + " NOT EMPTY");
                if (cbg.getSelection().getActionCommand().equals("Schema")) result.append("   Schema:\n"
                        + t.toRegExType());
                else if (cbg.getSelection().getActionCommand().equals("Automa")) result.append("   Automa:\n"
                        + t.toString().trim());
            }
        }
        result.append("\n\n");
    }

    public void verifyEquals(Map<String, TreeAutomaton> m1, Map<String, TreeAutomaton> m2, String t1, String t2) {
        TreeAutomaton ta1 = getTreeAutomaton(m1, t1);
        TreeAutomaton ta2 = getTreeAutomaton(m2, t2);
        boolean ta1IsSubtypeta2 = StaticAnalyzer.isSubtype(ta1, ta2);
        boolean ta2IsSubtypeta1 = StaticAnalyzer.isSubtype(ta2, ta1);
        if (ta1IsSubtypeta2 && ta2IsSubtypeta1) result.append(t1 + " IS EQUAL TO " + t2);
        else result.append(t1 + " IS NOT EQUAL TO " + t2);
        result.append("\n\n");
    }

    /**
     * create and visualize an automa builded from union of the two input automa
     * 
     * @param m1
     *            map from schema 1
     * @param m2
     *            map from schema 2
     * @param t1
     *            the schema name selected from schema 1
     * @param t2
     *            the schema name selected from schema 2
     */
    public void computeUnion(Map<String, TreeAutomaton> m1, Map<String, TreeAutomaton> m2, String t1, String t2) {
        TreeAutomaton[] AutomatonArray = new TreeAutomaton[2];
        AutomatonArray[0] = getTreeAutomaton(m1, t1);
        AutomatonArray[1] = getTreeAutomaton(m2, t2);
        TreeAutomaton ta;
        if (StaticAnalyzer.isSubtype(AutomatonArray[0], AutomatonArray[1])) ta = AutomatonArray[1];
        else if (StaticAnalyzer.isSubtype(AutomatonArray[1], AutomatonArray[0])) ta = AutomatonArray[0];
        else ta = TreeAutomaton.union(AutomatonArray);
        result.append("UNION OF " + t1 + " + " + t2);
        if (cbg.getSelection().getActionCommand().equals("Schema")) result.append("   Schema:\n" + ta.toRegExType());
        else if (cbg.getSelection().getActionCommand().equals("Automa")) result.append("   Automa:\n"
                + ta.toString().trim());
        result.append("\n\n");
    }

    /**
     * create and visualize an automa builded from the difference of thetwo
     * input automa
     * 
     * @param m1
     *            map from schema 1
     * @param m2
     *            map from schema 2
     * @param t1
     *            the schema name selected from schema 1
     * @param t2
     *            the schema name selected from schema 2
     */
    public void computeDifference(Map<String, TreeAutomaton> m1, Map<String, TreeAutomaton> m2, String t1, String t2) {
        TreeAutomaton ta = TreeAutomaton.difference(getTreeAutomaton(m1, t1), getTreeAutomaton(m2, t2));
        result.append("DIFFERENCE " + t1 + " / " + t2);
        if (cbg.getSelection().getActionCommand().equals("Schema")) result.append("   Schema:\n" + ta.toRegExType());
        else if (cbg.getSelection().getActionCommand().equals("Automa")) result.append("   Automa:\n"
                + ta.toString().trim());
        result.append("\n\n");
    }

    /**
     * create and visualize an automa builded from the product of the two input
     * automa
     * 
     * @param m1
     *            map from schema 1
     * @param m2
     *            map from schema 2
     * @param t1
     *            the schema name selected from schema 1
     * @param t2
     *            the schema name selected from schema 2
     */
    public void computeProduct(Map<String, TreeAutomaton> m1, Map<String, TreeAutomaton> m2, String t1, String t2) {
        TreeAutomaton ta = TreeAutomaton.product(getTreeAutomaton(m1, t1), getTreeAutomaton(m2, t2));
        result.append("PRODUCT " + t1 + " * " + t2);
        if (cbg.getSelection().getActionCommand().equals("Schema")) result.append("   Schema:\n" + ta.toRegExType());
        else if (cbg.getSelection().getActionCommand().equals("Automa")) result.append("   Automa:\n"
                + ta.toString().trim());
        result.append("\n\n");
    }

    /**
     * Compile and create automaton map in one times from a string in the bopi
     * schema syntax
     * 
     * @param s
     *            the bopi schema definition
     */
    public Map<String, TreeAutomaton> CompileAndMapping(String s) {
        String XMLval = compile(setStringType(s.trim())); /* COMPILE */
        Map<String, TreeAutomaton> map = getMapTypeAutomaton(cleanXML(XMLval));/*
                                                                                 * GENERATE
                                                                                 * AUTOMATON
                                                                                 * MAP
                                                                                 */
        return map;
    }

    /**
     * Return the Map of schema definition from the input XML value
     */
    public Map<String, TreeAutomaton> getMapTypeAutomaton(String def) {
        Map<String, TreeAutomaton> map = null;
        String error;
        try {
            System.out.print("Creating automatons map...");
            map = PatternFactory.parseTypeDeclaration(def.getBytes());
            System.out.println("CREATED");
            return map;
        } catch (SAXException se) {
            error = "PARSING ERROR: SAXException";
            System.err.println(error + "\n");
            throw new AppletException("Automaton Parser: SAXException");
        } catch (IOException eio) {
            error = "PARSING ERROR: IOException";
            System.err.println(error + "\n");
            throw new AppletException("Automaton Parser: IOException");
        } catch (Exception e) {
            error = "PARSING ERROR: " + e.toString();
            System.err.println(error + "\n");
            throw new AppletException("Automaton Parser: cannot create automa\n" + error);
        }
    }

    /**
     * Return the automaton of "type" from the "map"
     */
    public TreeAutomaton getTreeAutomaton(Map<String, TreeAutomaton> m, String type) {
        System.out.print("Extracting automaton for schema " + type + ".....");
        if (m.isEmpty()) System.err.println("ERROR:map empty");
        if (!m.containsKey(type)) System.err.println("ERROR:TYPEDEF:" + type + " NOT FOUND");
        TreeAutomaton ta = m.get(type);
        System.out.println("EXTRACTED");
        return ta;
    }

    /**
     * Return a string of the schema name list insert in the Map
     */
    public String typeList(Map<String, TreeAutomaton> m) {
        String list = "SCHEMA LIST: ";
        for (String typename : m.keySet()) {
            list += typename + " - ";
        }
        if (list.endsWith(" - ")) list = list.substring(0, list.length() - 3);
        list.concat("\n");
        return list;
    }

    /**
     * Check the input string of every schema definition and insert "typedef"
     * and ";" where it need
     */
    public String setStringType(String s) {
        String[] types = s.split(";");
        for (int i = 0; i < types.length; i++) {
            types[i] = types[i].trim();
            if (!(types[i].startsWith("typedef"))) types[i] = "typedef " + types[i];
            if (!types[i].endsWith(";")) types[i] += ";";
        }
        String ret = "";
        for (int i = 0; i < types.length; i++)
            ret += types[i];
        return ret;
    }

    /**
     * clean the string that contain the XML from the <bolognaPi>tag and the bug
     * </typedecl>
     */
    public String cleanXML(String s) {
        s = s.replaceFirst("<bolognaPi>", ""); /* clear the bolognaPi tag */
        s = s.replaceFirst("</bolognaPi>", ""); /* clear the bolognaPi tag */
        s = s.trim();
        s = s.replaceAll("\\n\\n", "\n");
        return s.trim();
    }

    /**
     * return the XML string without the type definition of "Any"
     */
    public String hideANY(String s) {
        int begin = s.indexOf("<typedef name=\"Any\">");
        if (begin == -1) return s;
        int end = s.indexOf("</typedef>", begin);
        end += "</typedef>".length();
        String st = s.substring(0, begin) + s.substring(end).trim();
        return st;
    }

    /**
     * return the XML value of the schema string using the BoPi compiler the
     * input string have to be in a correct state: it has checking by the method
     * setStringType
     */
    public String compile(String type) {
        String s = "";
        System.out.print("COMPILE: " + type + "\n");
        bopiCompiler = new BoPiCompiler(new ByteArrayInputStream(type.getBytes()));
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            s = bopiCompiler.internalCompilation(os);
            return s;
        } catch (ParseException err) {
            throw new AppletException("BoPi Compiler: Syntax Error");
        } catch (Exception err) {
            throw new AppletException("BoPi Compiler: " + err.toString());
        }
    }

    /**
     * Return the string that contain the schema name of the first definition on
     * the XML string definition
     */
    public String getFirstTypeName(String XMLtype) {
        int beginindex = XMLtype.indexOf("<typedef name=\"");
        int endindex = XMLtype.indexOf("\">", beginindex);
        beginindex += "<typedef name=\"".length();
        return XMLtype.substring(beginindex, endindex);
    }

    /**
     * Return the string that contain the schema name of the first definition
     * different from Any on the map of automaton
     */
    public String getFirstTypeName(Map<String, TreeAutomaton> m) {
        for (String s : m.keySet()) {
            if (!s.equals("Any")) return s;
        }
        return m.keySet().iterator().next();
    }

    /**
     * Verify if the string s passed to a operation method is equals to the
     * input string in the text area
     */
    public boolean isTypeComputated(String s, String input) {
        return s.trim().equals(input.trim());
    }

    /**
     * clear the enviroment variable of the applet used for computing
     */
    public void clearAllComputing() {
        map1 = null;
        lastSchemaComp = null;
    }

    /**
     * Increment the font size of all the area text
     */
    public void moreFontsize() {
        Font ft = t1.getFont();
        t1.setFont(new Font(ft.getName(), ft.getStyle(), ft.getSize() + 1));
        ft = out1.getFont();
        out1.setFont(new Font(ft.getName(), ft.getStyle(), ft.getSize() + 1));
        ft = result.getFont();
        result.setFont(new Font(ft.getName(), ft.getStyle(), ft.getSize() + 1));
    }

    /**
     * Decrement the font size of all the text area
     */
    public void lessFontsize() {
        Font ft = t1.getFont();
        t1.setFont(new Font(ft.getName(), ft.getStyle(), ft.getSize() - 1));
        ft = out1.getFont();
        out1.setFont(new Font(ft.getName(), ft.getStyle(), ft.getSize() - 1));
        ft = result.getFont();
        result.setFont(new Font(ft.getName(), ft.getStyle(), ft.getSize() - 1));
    }

    /**
     * Set the font size of all the text area
     */
    public void setFontsize(int size) {
        t1.setFont(new Font(t1.getFont().getName(), t1.getFont().getStyle(), size + 2));
        out1.setFont(new Font(out1.getFont().getName(), out1.getFont().getStyle(), size));
        result.setFont(new Font(result.getFont().getName(), result.getFont().getStyle(), size));
    }

    public String getAppletInfo() {
        return "BoPiApplet: \n" + "A simple applet to verify BoPi schema and their operations\n"
                + "A trasformation of BoPi automata to regular expression type\n" + "Author: Simone Tacconi \n";
    }

    /**
     * A simple class that implements a windows that contain the list of schema
     * definition of each input area where you can select the specific schemas
     * for the selected operation
     */
    class SelectFrameSingleTwoList extends JFrame implements ActionListener {

        private static final long serialVersionUID = 3834030242716005689L;

        Map<String, TreeAutomaton> map1, map2;

        String op;

        Panel typepanel1, typepanel2;

        List typelist1;

        List typelist2;

        LayoutManager lm;

        JButton close, deselect, confirm;

        SchemaApplet applet;

        /** a refers to the applet that run this windows */

        /**
         * Build a frame with two list of types and initialize the components
         */
        SelectFrameSingleTwoList(SchemaApplet applet, Map<String, TreeAutomaton> m1, Map<String, TreeAutomaton> m2,
                String op) {
            super(op + " Schema Select ");
            if ((!m1.isEmpty()) && (!m2.isEmpty())) {

                this.applet = applet;
                this.map1 = m1;
                this.map2 = m2;
                this.op = op;

                initSelectFrameTwoList();
                setLocation(applet.getLocationOnScreen().x + applet.getSize().width - 440,
                        applet.getLocationOnScreen().y + applet.getSize().height - 220);
                setSize(360, 220);
                setVisible(true);

            } else System.err.println("ERROR:CANNOT CREATE THE SCHEMA SELECT WINDOW: schemalist is EMPTY!!!!!!!");
        }

        /**
         * Initialize the frame components with schema names listed in t1 and t2
         */
        public void initSelectFrameTwoList() {
            typepanel1 = new Panel();
            typepanel2 = new Panel();

            lm = new BorderLayout();
            getContentPane().setLayout(lm);

            typelist1 = new List();
            typelist1.setMultipleMode(false);
            for (String str : map1.keySet()) {
                // if (!str.equals("Any")) //BUG: don't visualize type "Any"
                typelist1.add(str);
            }
            typelist1.select(0);
            typelist1.setSize(typelist1.getPreferredSize(map1.size()));

            lm = new BorderLayout();
            typepanel1.setLayout(lm);
            Label lab = new Label("Schema 1");
            lab.setFont(new Font("SansSerif", Font.BOLD, 18));
            typepanel1.add(lab, BorderLayout.NORTH);
            typepanel1.add(typelist1, BorderLayout.CENTER);

            typelist2 = new List();
            typelist2.setMultipleMode(false);
            for (String str : map2.keySet()) {
                // if (!str.equals("Any")) //BUG: don't visualize type "Any"
                typelist2.add(str);
            }
            typelist2.select(0);
            typelist2.setSize(typelist2.getPreferredSize(this.map2.size()));

            lm = new BorderLayout();
            typepanel2.setLayout(lm);
            lab = new Label("Schema 2");
            lab.setFont(new Font("SansSerif", Font.BOLD, 18));

            typepanel2.add(lab, BorderLayout.NORTH);
            typepanel2.add(typelist2, BorderLayout.CENTER);

            Panel schema_p = new Panel();
            lm = new FlowLayout(FlowLayout.CENTER, 10, 5);
            schema_p.setLayout(lm);
            schema_p.add(typepanel1);
            if (this.op.equals("SUBTYPE")) {
                lab = new Label("<:");
            } else if (this.op.equals("DIFFERENCE")) {
                lab = new Label("\\");
            } else if (this.op.equals("UNION")) {
                lab = new Label("U");
            } else if (this.op.equals("PRODUCT")) {
                lab = new Label("*");
            } else if (this.op.equals("EQUALS")) {
                lab = new Label("=");
            }
            lab.setFont(new Font("SansSerif", Font.BOLD, 24));
            schema_p.add(lab);
            schema_p.add(typepanel2);

            getContentPane().add(schema_p, BorderLayout.CENTER);

            Panel bottom = new Panel();
            confirm = new JButton("Confirm");
            confirm.addActionListener(this);
            bottom.add(confirm);
            deselect = new JButton("Deselect");
            deselect.addActionListener(this);
            bottom.add(deselect);
            close = new JButton("Close");
            close.addActionListener(this);
            bottom.add(close);
            getContentPane().add(bottom, BorderLayout.SOUTH);

        }

        /** 
         */
        public void actionPerformed(ActionEvent e) {
            String action = e.getActionCommand();
            if (action.equals("Confirm")) {
                if ((typelist1.getSelectedItem() != null) && (typelist2.getSelectedItem() != null)) {
                    if (this.op.equals("SUBTYPE")) applet.verifySubtyping(map1, map2, typelist1.getSelectedItem(),
                            typelist2.getSelectedItem());
                    else if (this.op.equals("UNION")) applet.computeUnion(map1, map2, typelist1.getSelectedItem(),
                            typelist2.getSelectedItem());
                    else if (this.op.equals("PRODUCT")) applet.computeProduct(map1, map2, typelist1.getSelectedItem(),
                            typelist2.getSelectedItem());
                    else if (this.op.equals("DIFFERENCE")) applet.computeDifference(map1, map2, typelist1
                            .getSelectedItem(), typelist2.getSelectedItem());
                    else if (this.op.equals("EQUALS")) applet.verifyEquals(map1, map2, typelist1.getSelectedItem(),
                            typelist2.getSelectedItem());
                    setVisible(false);

                }
            }
            if (action.equals("Deselect")) {
                typelist1.deselect(typelist1.getSelectedIndex());
                typelist2.deselect(typelist2.getSelectedIndex());
            }
            if (action.equals("Close")) {
                setVisible(false);
            }
        }
    }

    /**
     * A simple class implements a windows that contain the list of schemas
     * definition of an input area where you can select the specific schemas for
     * the selected operation
     */
    class SelectFrameSingle extends JFrame implements ActionListener {

        private static final long serialVersionUID = 3833752066290888760L;

        String operation;

        Map<String, TreeAutomaton> map;

        Panel type_p, typepanel;

        List typelist;

        LayoutManager lm;

        JButton close, deselect, confirm;

        SchemaApplet applet;

        /**
         * Build a frame with a list of types name
         */
        SelectFrameSingle(SchemaApplet single, Map<String, TreeAutomaton> m, String op) {
            super(op + " Schema Select ");
            if ((m != null) && !m.isEmpty()) {
                this.applet = single;
                this.map = m;
                this.operation = op;
                setSize(280, 180);
                initSelectFrame();
                setLocation(applet.getLocationOnScreen().x + applet.getSize().width / 2 - 300, applet
                        .getLocationOnScreen().y + 170);
                setVisible(true);
            } else System.err.println("ERROR:CANNOT CREATE THE SCHEMAS SELECT WINDOW: schemalist is EMPTY!!!!!!!");
        }

        /**
         * Initialize a frame with single schema list
         */
        public void initSelectFrame() {
            typepanel = new Panel();
            lm = new BorderLayout();
            getContentPane().setLayout(lm);

            typelist = new List();
            typelist.setMultipleMode(true);
            ;
            for (String str : map.keySet()) {
                // if (!str.equals("Any")) //BUG: don't visualize type "Any"
                typelist.add(str);
            }
            typelist.select(0);
            typelist.setSize(typelist.getPreferredSize(map.size()));
            Panel center = new Panel();
            center.add(typelist);
            getContentPane().add(center, BorderLayout.CENTER);

            Panel bottom = new Panel();
            confirm = new JButton("Confirm");
            confirm.addActionListener(this);
            bottom.add(confirm);
            deselect = new JButton("Deselect");
            deselect.addActionListener(this);
            bottom.add(deselect);
            close = new JButton("Close");
            close.addActionListener(this);
            bottom.add(close);

            getContentPane().add(bottom, BorderLayout.SOUTH);
        }

        /** 
         */
        public void actionPerformed(ActionEvent e) {
            String action = e.getActionCommand();
            int[] selectitems = typelist.getSelectedIndexes();
            if ((selectitems.length != 0) && (selectitems != null)) {
                if (action.equals("Confirm")) {
                    if ((operation.equals("AUTOMA"))) {
                        for (int i : selectitems) {
                            applet.printAutoma(map, typelist.getItem(i));
                        }
                    } else if (operation.equals("ISEMPTY")) {
                        for (int i : selectitems) {
                            applet.isLangEmpty(map, typelist.getItem(i));
                        }
                    } else if (operation.equals("REGEX")) {
                        for (int i : selectitems) {
                            applet.printRegEx(map, typelist.getItem(i));
                        }
                    }
                    setVisible(false);
                }
                if (action.equals("Deselect")) {
                    for (int i : selectitems)
                        typelist.deselect(i);
                }
            }
            if (action.equals("Close")) {
                setVisible(false);
            }
        }
    }

    /**
     * This exception is throwed only when the BoPiCompiler or the Automaton
     * Builder failed
     */
    class AppletException extends RuntimeException {

        private static final long serialVersionUID = 3257567308670185780L;

        private String error;

        public AppletException(String s) {
            this.error = s;
        }

        public String getSource() {
            return this.error;
        }
    }

}
