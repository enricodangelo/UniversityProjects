public class SingleLabelException extends Exception {

	public SingleLabelException() {
		super("Operazione non supportata");

	}
}

