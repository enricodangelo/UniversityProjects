
import java.util.Iterator;
import java.util.Vector;

/**
 * Classe astratta dei singoli oggetti multimediali
 */

public abstract class SingleMultimediaObject extends MultimediaObject {

	public SingleMultimediaObject() {
		super();
		this.labelVector = new Vector();
	}

	public boolean add(MultimediaObject mo) throws SingleMultimediaException {
		throw new SingleMultimediaException();
	}

	public boolean remove(MultimediaObject mo) throws SingleMultimediaException {
		throw new SingleMultimediaException();
	}

	public MultimediaObject getChild(MultimediaObject mo)
			throws SingleMultimediaException {
		throw new SingleMultimediaException();
	}

	public String toString() {
		String s = "{ " + this.getNome() + " > ";
		Iterator ite = labelVector.listIterator();
		while (ite.hasNext()) {
			s = s + ite.next().toString();
		}
		return s + " }\n";
	}
}