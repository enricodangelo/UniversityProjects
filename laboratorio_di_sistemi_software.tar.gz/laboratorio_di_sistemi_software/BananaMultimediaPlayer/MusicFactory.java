
import java.io.IOException;
import java.util.List;
import java.util.Vector;

/**
 * Factory dei brani musicali
 */
public class MusicFactory extends BananaFactory {

	private static MusicFactory musicInstance = null;

	public MusicFactory(Vector labelVector, Vector moVector) {
		super(labelVector, moVector);

	}

	public List getOptions(String s) {
		if (s.equals("1"))
			return labelVector;
		return null;
	}

	public void addToList(Object object) {
		this.moVector.addElement(object);

	}

	public Object newElement() {
		Music music = new Music();

		return music;
	}

	public List questionMenu() {
		Vector a = new Vector();
		a
				.addElement("Inserisci un nuovo brano\nInserire il nome del nuovo brano: ");
		a.addElement("1. Applica una label");
		a.addElement("2. Esci");
		return a;
	}

	public boolean action(String param, Object object) throws IOException {
		if (param.equals("1")) {
			((MultimediaObject) object).addLabel((Label) getOptions(param).get(
					selectionList(getOptions(param))));
			return true;
		}
		if (param.equals("2"))
			return false;
		return true;
	}

	public static MusicFactory getInstance(Vector l, Vector m) {
		if (musicInstance == null) {
			musicInstance = new MusicFactory(l, m);
		}
		return musicInstance;

	}

}