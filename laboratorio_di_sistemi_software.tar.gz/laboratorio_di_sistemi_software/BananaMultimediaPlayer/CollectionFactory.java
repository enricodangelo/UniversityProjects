
import java.io.IOException;
import java.util.List;
import java.util.Vector;

/**
 * Factory degli oggetti multimediali composti
 */
public class CollectionFactory extends BananaFactory {

	private static CollectionFactory collectionInstance = null;

	public CollectionFactory(Vector labelVector, Vector moVector) {
		super(labelVector, moVector);
	}


	public List getOptions(String s) {
		if (s.equals("1"))
			return labelVector;
		if (s.equals("2"))
			return moVector;
		return null;
	}


	public Object newElement() {
		CompoundMultimediaObject object = new CompoundMultimediaObject();

		return object;
	}

	

	public List questionMenu() {
		Vector a = new Vector();
		a
				.addElement("Inserisci un nuovo album\nInserire il nome del nuovo album: ");
		a.addElement("1. Applica una label");
		a.addElement("2. Aggiungi un oggetto multimediale");
		a.addElement("3. Esci");
		return a;
	}

	
	public boolean action(String param, Object object) throws IOException {
		if (param.equals("1")) {
			((MultimediaObject) object).addLabel((Label) getOptions(param).get(
					selectionList(getOptions(param))));
			return true;
		}
		if (param.equals("2")) {
			try {
				((MultimediaObject) object).add((MultimediaObject) getOptions(
						param).get(selectionList(getOptions(param))));
			} catch (SingleMultimediaException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		}
		if (param.equals("3"))
			return false;
		return true;
	}

	public void addToList(Object object) {
		this.moVector.addElement(object);

	}

	public static CollectionFactory getInstance(Vector l, Vector m) {
		if (collectionInstance == null) {
			collectionInstance = new CollectionFactory(l, m);
		}
		return collectionInstance;

	}

}