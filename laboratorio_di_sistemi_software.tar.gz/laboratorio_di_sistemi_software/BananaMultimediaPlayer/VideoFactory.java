
import java.io.IOException;
import java.util.List;
import java.util.Vector;

/**
 * Factory dei filmati
 */
public class VideoFactory extends BananaFactory {

	private static VideoFactory videoInstance = null;

	public VideoFactory(Vector labelVector, Vector moVector) {
		super(labelVector, moVector);

	}

	public List getOptions(String s) {
		if (s.equals("1"))
			return labelVector;
		return null;
	}

	public void addToList(Object object) {
		this.moVector.addElement(object);

	}

	public Object newElement() {
		Video video = new Video();

		return video;
	}

	public List questionMenu() {
		Vector a = new Vector();
		a
				.addElement("Inserisci un nuovo fimato\nInserire il nome del nuovo filmato: ");
		a.addElement("1. Applica una label");
		a.addElement("2. Esci");
		return a;
	}

	public boolean action(String param, Object object) throws IOException {
		if (param.equals("1")) {
			((MultimediaObject) object).addLabel((Label) getOptions(param).get(
					selectionList(getOptions(param))));
			return true;
		}
		if (param.equals("2"))
			return false;
		return true;
	}

	public void action(Label object) throws IOException {
	}

	public static VideoFactory getInstance(Vector l, Vector m) {
		if (videoInstance == null) {
			videoInstance = new VideoFactory(l, m);
		}
		return videoInstance;

	}

}