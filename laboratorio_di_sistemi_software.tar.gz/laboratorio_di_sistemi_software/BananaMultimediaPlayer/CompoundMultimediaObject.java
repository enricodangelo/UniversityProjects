
import java.util.Iterator;
import java.util.Vector;

/**
 * Classe che gestisce gli oggetti multimediali composti  
 */
public class CompoundMultimediaObject extends MultimediaObject {

	private Vector multimediaVector;

	
	public CompoundMultimediaObject() {
		super();
		this.multimediaVector = new Vector();
	}

	public boolean add(MultimediaObject mo) throws SingleMultimediaException {
		if (multimediaVector.contains(mo)) {
			return false;
		} else {
			multimediaVector.addElement(mo);
			return true;
		}
	}


	public boolean remove(MultimediaObject mo) throws SingleMultimediaException {
		return multimediaVector.removeElement(mo);
	}

	
	public MultimediaObject getChild(MultimediaObject mo)
			throws SingleMultimediaException {
		return (MultimediaObject) multimediaVector.get(multimediaVector
				.indexOf(mo));
	}


	public String toString() {
		String s = "{ " + this.getNome() + " > ";
		Iterator ite = labelVector.listIterator();
		while (ite.hasNext()) {
			s = s + ite.next().toString();
		}
		s = s + ">>\n";
		ite = multimediaVector.listIterator();
		while (ite.hasNext()) {
			s = s + ite.next().toString();
		}
		return s + "}\n";

	}
}