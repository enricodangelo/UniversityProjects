
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

/**
 * Classe che gestisce le playlist
 */

public class BananaPlayList implements Observer {

	private Vector playlist;

	private Label selectionLabel;

	public BananaPlayList(Label selectionLabel) {
		playlist = new Vector();
		this.selectionLabel = selectionLabel;
		if (!selectionLabel.getLabelUser().isEmpty())
			playlist.addAll(selectionLabel.getLabelUser());
		selectionLabel.addObserver(this);
	}

	/* 	 * 
	 * controlla se l'oggetto ? stato aggiunto o rimosso e aggiorna la playlist
	 */
	public void update(Observable label, Object mo) {
		if (playlist.contains(mo)) {
			//se lo ho trovato va tolto
			playlist.removeElement(mo);
		} else {
			//non lo ho trovato va aggiunto
			playlist.addElement(mo);
		}

	}


	public String toString() {
		String s = "PlayList \t" + selectionLabel.toString() + "\n";
		Iterator ite = playlist.listIterator();
		while (ite.hasNext()) {
			s = s + "\t" + ite.next().toString();
		}
		return s + "\n\n";
	}
}