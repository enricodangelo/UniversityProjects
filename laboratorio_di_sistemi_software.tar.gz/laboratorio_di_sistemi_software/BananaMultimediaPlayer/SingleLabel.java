
import java.util.List;
import java.util.Vector;

/**
 * Classe che gestisce le label semplici
 */

public class SingleLabel extends Label {

	public SingleLabel(String s, String v) {
		this.name = s;
		this.value = v;
		this.labelUser = new Vector();
	}

	public SingleLabel() {
		this.labelUser = new Vector();
	}

	public boolean usedBy(MultimediaObject mo) {
		if (labelUser.contains(mo)) {
			return false;
		} else {
			labelUser.addElement(mo);
			this.setChanged();
			this.notifyObservers(mo);

			return true;
		}
	}

	public void noLongerUsedBy(MultimediaObject mo) {
		labelUser.removeElement(mo);
		this.setChanged();
		this.notifyObservers(mo);

	}

	public List getLabelUser() {
		return labelUser;
	}

	public boolean setValue(String value) {
		this.value = value;
		return true;
	}

	public boolean add(Label label) throws SingleLabelException {
		throw new SingleLabelException();
	}

	public boolean remove(Label label) throws SingleLabelException {
		throw new SingleLabelException();
	}

	public Label getChild(Label label) throws SingleLabelException {
		throw new SingleLabelException();
	}

	public boolean equals(Object o) {
		if (o instanceof SingleLabel)
			return this.name.equals(((Label) o).getValue()[0])
					&& this.value.equals(((Label) o).getValue()[1]);
		else
			return false;
	}

	public String toString() {
		String s = "[ " + name + " : " + value + " ]";
		return s;
	}

}