
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * Classe che gestisce le label composte
 */

public class CompoundLabel extends Label {

	private Vector vector;

	public CompoundLabel() {
		vector = new Vector();
	}

	public boolean add(Label label) {
		if (vector.contains(label)) {
			return false;
		} else {
			vector.addElement(label);
			return true;
		}
	}

	public boolean remove(Label label) {
		return vector.removeElement(label);

	}

	public Label getChild(Label label) {
		return (Label) vector.get(vector.indexOf(label));

	}

	public boolean equals(Object o) {
		if (o instanceof CompoundLabel) {
			return this.vector.equals(((CompoundLabel) o).vector);
		} else
			return false;
	}


	public boolean usedBy(MultimediaObject mo) {
		if (labelUser.contains(mo)) {
			return false;
		} else {
			labelUser.addElement(mo);
			this.setChanged();
			this.notifyObservers(mo);

			return true;
		}
	}


	public void noLongerUsedBy(MultimediaObject object) {
		labelUser.removeElement(object);
		this.setChanged();
		this.notifyObservers(object);
	}



	public String toString() {
		String s = "[ " + name + " : " + value + " >";
		Iterator ite = vector.listIterator();
		while (ite.hasNext()) {
			s = s + ite.next().toString();
		}

		return s + " ]";
	}


	public List getLabelUser() {
		return labelUser;
	}
}