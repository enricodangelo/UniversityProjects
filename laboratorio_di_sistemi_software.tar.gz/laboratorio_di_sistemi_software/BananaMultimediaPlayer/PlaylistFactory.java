
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ListIterator;
import java.util.Vector;

/**
* Factory delle playlist
 */
public class PlaylistFactory {

	Vector labelVector;

	private static PlaylistFactory playlistInstance = null;

	public PlaylistFactory(Vector labelVector) {
		super();
		this.labelVector = labelVector;
	}

	public BananaPlayList createPlayList() throws NumberFormatException,
			IOException {
		System.out.println("Scegli una label di selezione: \n");
		ListIterator ite = labelVector.listIterator();
		while (ite.hasNext()) {
			System.out.println(ite.nextIndex() + ". " + ite.next().toString());
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));

		int selected = (new Integer(reader.readLine())).intValue();

		return new BananaPlayList((Label) labelVector.get(selected));
	}

	public static PlaylistFactory getInstance(Vector l) {
		if (playlistInstance == null) {
			playlistInstance = new PlaylistFactory(l);
		}
		return playlistInstance;

	}

}