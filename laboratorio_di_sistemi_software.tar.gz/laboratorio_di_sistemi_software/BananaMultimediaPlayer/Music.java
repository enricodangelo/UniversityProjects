/**
 * Classe concreta dei brani musicali
 */
public class Music extends SingleMultimediaObject {

	public Music() {
		super();
		
	}
}
