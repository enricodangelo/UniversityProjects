public class Video extends SingleMultimediaObject {

	public Video() {
		super();
	}
}