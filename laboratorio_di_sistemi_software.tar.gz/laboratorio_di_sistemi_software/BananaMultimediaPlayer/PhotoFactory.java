
import java.io.IOException;
import java.util.List;
import java.util.Vector;

/**
 * Factory delle fotografie
 */
public class PhotoFactory extends BananaFactory {

	private static PhotoFactory photoInstance = null;

	public PhotoFactory(Vector labelVector, Vector moVector) {
		super(labelVector, moVector);

	}

	public List getOptions(String s) {
		if (s.equals("1"))
			return labelVector;
		return null;
	}

	public void addToList(Object object) {
		this.moVector.addElement(object);

	}


	public Object newElement() {
		Photo photo = new Photo();

		return photo;
	}

	public List questionMenu() {
		Vector a = new Vector();
		a
				.addElement("Inserisci un nuova immagine\nInserire il nome dell'immagine: ");
		a.addElement("1. Applica una label");
		a.addElement("2. Esci");
		return a;
	}

	public boolean action(String param, Object object) throws IOException {
		if (param.equals("1")) {
			((MultimediaObject) object).addLabel((Label) getOptions(param).get(
					selectionList(getOptions(param))));
			return true;
		}
		if (param.equals("2"))
			return false;
		return true;
	}

	public static PhotoFactory getInstance(Vector l, Vector m) {
		if (photoInstance == null) {
			photoInstance = new PhotoFactory(l, m);
		}
		return photoInstance;

	}

}