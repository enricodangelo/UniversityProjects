
import java.util.List;
import java.util.Observable;
import java.util.Vector;

/**
 * Classe astratta delle label
 */
public abstract class Label extends Observable {

	public abstract List getLabelUser();

	protected String value;

	protected String name;
	
	protected Vector labelUser;

	public abstract boolean add(Label label) throws SingleLabelException;

	public abstract boolean remove(Label label) throws SingleLabelException;

	public abstract Label getChild(Label label) throws SingleLabelException;

	public abstract boolean usedBy(MultimediaObject mo);

	public abstract void noLongerUsedBy(MultimediaObject object);

	public void setValue(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public String[] getValue() {
		String s[] = new String[2];
		s[0] = name;
		s[1] = value;
		return s;
	}

	

}