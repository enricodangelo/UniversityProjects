
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

/**
 * Classe astratta delle factory
 *
 */
public abstract class BananaFactory {

	protected Vector labelVector;

	protected Vector moVector;

	protected BananaFactory(Vector labelVector, Vector moVector) {
		this.labelVector = labelVector;
		this.moVector = moVector;
	}

	public MultimediaObject createMultimediaObject() throws IOException,
			SingleLabelException {
		List a = questionMenu();
		System.out.println(a.get(0));

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));

		String nome = reader.readLine();

		MultimediaObject object = (MultimediaObject) newElement();
		object.setNome(nome);

		String param = new String("1");

		do {
			System.out.println(object);
			System.out.println("Scegli una delle opzioni: \n");
			ListIterator ite = a.listIterator(1);
			while (ite.hasNext()) {
				System.out.println(ite.next());
			}
			param = reader.readLine();
		} while (action(param, object));
		addToList(object);

		return object;

	}

	public Label createLabel() throws IOException, SingleLabelException {
		List a = questionMenu();
		System.out.println(a.get(0));
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		String nome = reader.readLine();
		System.out.println(a.get(1));
		Label label = (Label) newElement();
		label.setValue(nome, reader.readLine());

		String param = new String("1");

		do {
			System.out.println(label);
			System.out.println("Scegli una delle opzioni: \n");
			ListIterator ite = a.listIterator(2);
			while (ite.hasNext()) {
				System.out.println(ite.next());
			}
			param = reader.readLine();
		} while (action(param, label));

		addToList(label);

		return label;

	}

	protected int selectionList(List elementi) throws IOException {

		Iterator iterator = elementi.iterator();
		int num = 0;

		while (iterator.hasNext())
			System.out.println(num++ + ". " + iterator.next());

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));

		String letto = reader.readLine();
		if (letto.equalsIgnoreCase("q")) {
			return -1;
		}

		Integer intletto = new Integer(letto);
		int intfinale = intletto.intValue();

		if (intfinale >= 0 && intfinale <= num) {
			return intfinale;
		} else
			return -1;
	}

	public abstract boolean action(String param, Object object)
			throws IOException, SingleLabelException;

	public abstract List questionMenu();

	public abstract Object newElement();

	public abstract void addToList(Object o);
}