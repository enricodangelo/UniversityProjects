
import java.util.Vector;

/**
 * Classe che gestisce gli oggetti multimediali
 */
abstract public class MultimediaObject {

	protected String nome;

	protected Vector labelVector;

	public MultimediaObject() {
		this.labelVector = new Vector();
	}

	public abstract boolean add(MultimediaObject mo)
			throws SingleMultimediaException;

	public abstract boolean remove(MultimediaObject mo)
			throws SingleMultimediaException;

	public abstract MultimediaObject getChild(MultimediaObject mo)
			throws SingleMultimediaException;;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public boolean addLabel(Label label) {
		if (label == null)
			return false;
		if (labelVector.contains(label)) {
			return false;
		} else {
			label.usedBy(this);
			labelVector.addElement(label);
			return true;
		}
	}

	public boolean removeLabel(Label label) {
		label.noLongerUsedBy(this);
		return labelVector.removeElement(label);
	}
}
