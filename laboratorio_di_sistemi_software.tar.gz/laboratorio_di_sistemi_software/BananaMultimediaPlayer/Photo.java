/**
 * Classe concreta delle fotografie
 */

public class Photo extends SingleMultimediaObject {

	public Photo() {
		super();
		
	}
}
