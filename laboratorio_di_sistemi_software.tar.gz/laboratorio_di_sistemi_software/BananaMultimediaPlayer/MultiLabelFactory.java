
import java.io.IOException;
import java.util.List;
import java.util.Vector;

/**
 * Factory delle label complesse
 */
public class MultiLabelFactory extends BananaFactory {

	private static MultiLabelFactory labelInstance = null;

	public MultiLabelFactory(Vector labelVector, Vector moVector) {
		super(labelVector, moVector);

	}

	public void addToList(Object o) {

	}

	public List getOptions(String s) {
		if (s.equals("1"))
			return labelVector;
		return null;
	}

	public Object newElement() {
		CompoundLabel label = new CompoundLabel();
		return label;
	}

	public List questionMenu() {
		Vector a = new Vector();
		a
				.addElement("Inserisci una nuova label composta\nInserire il nome della nuova label: ");
		a.addElement("Inserisci il valore della nuova label:");
		a.addElement("1. Aggiungi nuova label alla multilabel");
		a.addElement("2. Esci");
		return a;
	}

	public boolean action(String s, Object label) throws SingleLabelException,
			IOException {
		if (s.equals("1")) {
			((Label) label).add((Label) getOptions("1").get(
					selectionList(getOptions("1"))));

			if (!labelVector.contains(label)) {
				labelVector.addElement(label);
			}
			return true;
		} else
			return false;
	}

	public static MultiLabelFactory getInstance(Vector l, Vector m) {
		if (labelInstance == null) {
			labelInstance = new MultiLabelFactory(l, m);
		}
		return labelInstance;

	}

}
