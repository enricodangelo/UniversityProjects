
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

/**
 * Classe principale del bananamediaplayer
 * Presenta l'interfaccia di alcune funzioni
 */

public class BananaMediaPlayer {

	public static void main(String[] args) {

		Vector labelVector = new Vector();
		Vector moVector = new Vector();
		//Vector albumVector = new Vector();
		Vector playlistVector = new Vector();

		labelVector.addElement(new SingleLabel("Autore", "Tiziano Ferro"));
		labelVector.addElement(new SingleLabel("Autore", "Gigi D'alessio"));
		labelVector.addElement(new SingleLabel("Anno", "1999"));
		labelVector.addElement(new SingleLabel("Anno", "2001"));
		labelVector.addElement(new SingleLabel("Genere", "Metal"));
		labelVector.addElement(new SingleLabel("Genere", "Tecno"));
		labelVector.addElement(new SingleLabel("Localita", "Firenze"));
		labelVector.addElement(new SingleLabel("Durata", "03:02"));

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));

		MusicFactory musicFactory = MusicFactory.getInstance(labelVector,
				moVector);
		CollectionFactory collectionFactory = CollectionFactory.getInstance(
				labelVector, moVector);
		LabelFactory labelFactory = LabelFactory.getInstance(labelVector,
				moVector);
		MultiLabelFactory mlFactory = MultiLabelFactory.getInstance(
				labelVector, moVector);
		PhotoFactory fotoFactory = PhotoFactory.getInstance(labelVector,
				moVector);
		VideoFactory videoFactory = VideoFactory.getInstance(labelVector,
				moVector);
		PlaylistFactory playlistFactory = PlaylistFactory
				.getInstance(labelVector);

		String opzione = "";
		do {
			System.out.println("Scegli l'opzione:\n" + "l. Crea nuova label\n"
					+ "L. Crea una label composta\n"
					+ "c. Crea nuova canzone\n" + "i. Crea nuovo video\n"
					+ "f. Crea nuova foto\n"
					+ "M. Crea nuova collezione di oggetti\n"
					+ "p. Crea playlist\n" + "v. Visualizza oggetti\n"
					+ "q. Quit");
			try {
				opzione = reader.readLine();

				switch (opzione.charAt(0)) {
				case 'l':
					labelFactory.createLabel();
					break;
				case 'L':
					mlFactory.createLabel();
					break;
				case 'c':
					musicFactory.createMultimediaObject();
					break;
				case 'i':
					videoFactory.createMultimediaObject();
					break;
				case 'f':
					fotoFactory.createMultimediaObject();
					break;
				case 'M':
					collectionFactory.createMultimediaObject();
					break;
				case 'p':
					playlistVector.addElement(playlistFactory.createPlayList());
					break;
				case 'v':
					System.out.println(labelVector);
					System.out.println(moVector);
					//System.out.println(albumVector);
					System.out.println(playlistVector);
					break;
				case 'q':
					System.out
							.println("Grazie per aver usato BananaMediaPlayer(tm)");
					break;
				default:
					System.out.println("opzione non valida");
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SingleLabelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} while (!opzione.equals("q"));

	}
}