public class SingleMultimediaException extends Exception {

	public SingleMultimediaException() {
		super("Operazione non supportata");

	}
}

