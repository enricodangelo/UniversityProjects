import java.io.IOException;
import java.util.List;
import java.util.Vector;

/**
 * Factory della label
 */
public class LabelFactory extends BananaFactory {

	private static LabelFactory labelInstance = null;

	public LabelFactory(Vector labelVector, Vector moVector) {
		super(labelVector, moVector);

	}


	public void addToList(Object o) {

	}

	public List getOptions(String s) {
		if (s.equals("1"))
			return labelVector;
		return null;
	}


	public Object newElement() {
		SingleLabel label = new SingleLabel();
		return label;
	}

	public List questionMenu() {
		Vector a = new Vector();
		a
				.addElement("Inserisci una nuova label singola\nInserire il nome della nuova label: ");
		a.addElement("Inserisci il valore della nuova label:");
		return a;
	}


	public void action(Label label) throws IOException {
		if (!labelVector.contains(label)) {
			labelVector.addElement(label);
		}
	}


	public boolean action(String param, Object object) throws IOException {
		return false;
	}

	public static LabelFactory getInstance(Vector l, Vector m) {
		if (labelInstance == null) {
			labelInstance = new LabelFactory(l, m);
		}
		return labelInstance;

	}

}