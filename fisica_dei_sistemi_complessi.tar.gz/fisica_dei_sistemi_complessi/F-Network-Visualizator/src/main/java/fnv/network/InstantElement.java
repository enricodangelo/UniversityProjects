/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fnv.network;

/**
 *
 * @author enrico
 */
public class InstantElement {

    public final int quantity;
    public final float frequency;

    public InstantElement(int quantity, float frequency) {
	this.quantity = quantity;
	this.frequency = frequency;
    }
}
