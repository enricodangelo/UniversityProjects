package fr.inria.gforge.treeds.utils;

import java.util.HashMap;
import fr.inria.gforge.telex.application.Action;

public class ActionNameGenerator {
	private static int n;
	private static HashMap<Action, String> actionsNamesMap = new HashMap<Action, String>();

	public static String generateName(Action action, String actionType,
			String nodeName, String[] actionParams) {
		String name = "";

		name += actionType + ":" + nodeName + "-" + ++n;

		for (int i = 0; i < actionParams.length; i++) {
			name += ":" + actionParams[i];
		}

		actionsNamesMap.put(action, name);

		return name;
	}

	public static String getName(Action action) {
		String name = actionsNamesMap.get(action);

		return name;
	}
}
