package fr.inria.gforge.treeds.check;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import fr.inria.gforge.treeds.utils.Constants;

public class FinalStateWriter {
	BufferedWriter writer;
	String finalState;
	ArrayList<String> finalOperations;
	ArrayList<String> allOperations;

	public FinalStateWriter(String outputFilename) {
		finalOperations = new ArrayList<String>();
		allOperations = new ArrayList<String>();
		try {
			writer = new BufferedWriter(new FileWriter(outputFilename));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void resetFinalOperations() {
		finalOperations = new ArrayList<String>();
	}

	public void addOperation(String action) {
		finalOperations.add(action);
	}

	public void resetAllOperations() {
		allOperations = new ArrayList<String>();
	}

	public void addOperationToAllOperations(String action) {
		allOperations.add(action);
	}

	public void setFinalState(String finalState) {
		this.finalState = finalState;
	}

	public void write() {
		try {
			writer.write(Constants.OPERATIONS_START_DELIMITER + "\n");
			if (!finalOperations.isEmpty()) {
				for (String action : finalOperations) {
					writer.write(action + "\n");
				}
			} else {
				writer.write("empty" + "\n");
			}
			writer.write(Constants.OPERATIONS_END_DELIMITER + "\n");

			writer.write(Constants.ALLOPERATIONS_START_DELIMITER + "\n");
			if (!allOperations.isEmpty()) {
				for (String action : allOperations) {
					writer.write(action + "\n");
				}
			} else {
				writer.write("empty" + "\n");
			}
			writer.write(Constants.ALLOPERATIONS_END_DELIMITER + "\n");

			writer.write(Constants.FINALSTATE_START_DELIMITER + "\n");
			if (finalState != null) {
				writer.write(finalState + "\n");
			} else {
				writer.write("empty" + "\n");
			}
			writer.write(Constants.FINALSTATE_END_DELIMITER + "\n");

			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
