/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.inria.gforge.treeds.action;

import fr.inria.gforge.telex.application.Constraint;
import fr.inria.gforge.telex.application.Fragment;
import fr.inria.gforge.treeds.utils.Constants;

/**
 * 
 * @author edangelo
 * 
 *         Merges a node WITHOUT root to another node.
 */
public class MergeAction extends TreeAbstractAction {
	private static final long serialVersionUID = -6221860212050431267L;
	private String nodeID;
	private String newParentID;

	public String getNewParentID() {
		return newParentID;
	}

	public void setNewParentID(String newParentID) {
		this.newParentID = newParentID;
	}

	public String getNodeID() {
		return nodeID;
	}

	public void setNodeID(String nodeID) {
		this.nodeID = nodeID;
	}

	@Override
	public Object[] getArgs() {
		return new Object[] { nodeID, newParentID };
	}

	@Override
	public String[] getModifiedObjects() {
		return new String[] { nodeID, newParentID };
	}

	public MergeAction(String nodeID, String newRootID) {
		setMethodName(Constants.MERGEACTION_METHODNAME);
		this.nodeID = nodeID;
		this.newParentID = newRootID;
	}

	@Override
	public String toString() {
		String result = getClass().getCanonicalName() + " ";

		result += nodeID + " ";
		result += newParentID;

		return result;
	}

	@Override
	public Fragment getSemanticConstraints(TreeAction a, TreeAction b) {
		Fragment fragment = new Fragment();

		if (b.getSpecificAction() instanceof CreateAction) {
			CreateAction createAction = (CreateAction) b.getSpecificAction();

			if ((createAction.getNodeID().equals(nodeID))
					|| (createAction.getNodeID().equals(newParentID))) {
				Constraint constraint1 = new Constraint(b,
						Constraint.Type.ENABLES, a);
				Constraint constraint2 = new Constraint(b,
						Constraint.Type.NOT_AFTER, a);
				fragment.add(constraint1);
				fragment.add(constraint2);
			}
		} else if (b.getSpecificAction() instanceof RemoveAction) {
			RemoveAction removeAction = (RemoveAction) b.getSpecificAction();

			if ((removeAction.getNodeID().equals(nodeID))
					|| (removeAction.getNodeID().equals(newParentID))) {
				Constraint constraint = new Constraint(a,
						Constraint.Type.NOT_AFTER, b);
				fragment.add(constraint);
			}
		} else if (b.getSpecificAction() instanceof MergeAction) {
			Constraint constraint = new Constraint(b,
					Constraint.Type.NON_COMMUTING, a);
			fragment.add(constraint);
		} else if (b.getSpecificAction() instanceof SplitAction) {
			SplitAction splitAction = (SplitAction) b.getSpecificAction();

			if (splitAction.getNodeID().equals(nodeID)) {
				if (!b.isCommitted()) {
					Constraint constraint1 = new Constraint(b,
							Constraint.Type.NOT_AFTER, a);
					Constraint constraint2 = new Constraint(a,
							Constraint.Type.NOT_AFTER, b);
					fragment.add(constraint1);
					fragment.add(constraint2);
				}
			}
		}

		return fragment;
	}

	@Override
	public Fragment getAllNonCommutetiveConstraints(TreeAction a, TreeAction b) {
		Fragment fragment = new Fragment();

		Constraint constraint1 = new Constraint(b,
				Constraint.Type.NON_COMMUTING, a);
		fragment.add(constraint1);

		return fragment;
	}

	@Override
	public Fragment getSameObjectNonCommutativeConstraints(TreeAction a,
			TreeAction b) {
		Fragment fragment = new Fragment();

		if (b.getSpecificAction() instanceof CreateAction) {
			CreateAction createAction = (CreateAction) b.getSpecificAction();

			if (createAction.getNodeID().equals(nodeID)) {
				Constraint constraint = new Constraint(b,
						Constraint.Type.NON_COMMUTING, a);
				fragment.add(constraint);
			}
		} else if (b.getSpecificAction() instanceof RemoveAction) {
			RemoveAction removeAction = (RemoveAction) b.getSpecificAction();

			if (removeAction.getNodeID().equals(nodeID)) {
				Constraint constraint = new Constraint(b,
						Constraint.Type.NON_COMMUTING, a);
				fragment.add(constraint);
			}
		} else if (b.getSpecificAction() instanceof MergeAction) {
			MergeAction mergeAction = (MergeAction) b.getSpecificAction();

			if (mergeAction.getNodeID().equals(nodeID)) {
				if (!b.isCommitted()) {
					Constraint constraint = new Constraint(b,
							Constraint.Type.NON_COMMUTING, a);
					fragment.add(constraint);
				}
			}
		} else if (b.getSpecificAction() instanceof SplitAction) {
			SplitAction splitAction = (SplitAction) b.getSpecificAction();

			if (splitAction.getNodeID().equals(nodeID)) {
				Constraint constraint = new Constraint(b,
						Constraint.Type.NON_COMMUTING, a);
				fragment.add(constraint);
			}
		}

		return fragment;
	}
}
