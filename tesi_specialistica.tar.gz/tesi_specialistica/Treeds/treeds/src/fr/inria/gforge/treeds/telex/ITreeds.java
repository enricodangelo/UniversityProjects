package fr.inria.gforge.treeds.telex;

import java.util.LinkedList;

import fr.inria.gforge.treeds.utils.TreedsProperties;

public interface ITreeds {

	public void setProperties(TreedsProperties treedsProperties);

	public void start();

	public void exit();

	public String getTreeSpaceString();

	public boolean testCreatePrecondition(String nodeID);

	public boolean testSplitNodePrecondition(String nodeID);

	public boolean testMergePrecondition(String nodeID, String newParentID);

	public boolean testRemovePrecondition(String nodeID);

	public LinkedList<String> getUsedIDs();

	public void createTree(String nodeID);

	public void remove(String nodeID);

	public void merge(String nodeID, String newParentID);

	public void splitNode(String nodeID);

	public void closeDocument();
}
