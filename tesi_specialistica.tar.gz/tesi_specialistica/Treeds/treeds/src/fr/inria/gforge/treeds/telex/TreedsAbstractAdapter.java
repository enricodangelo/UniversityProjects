package fr.inria.gforge.treeds.telex;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

import fr.inria.gforge.telex.ClosedDocumentException;
import fr.inria.gforge.telex.Document;
import fr.inria.gforge.telex.IncompatibleOpenModeException;
import fr.inria.gforge.telex.InvalidScheduleException;
import fr.inria.gforge.telex.Schedule;
import fr.inria.gforge.telex.application.Action;
import fr.inria.gforge.telex.application.Constraint;
import fr.inria.gforge.telex.application.Fragment;
import fr.inria.gforge.telex.application.ProcessingParameters;
import fr.inria.gforge.telex.application.TelexApplication;
import fr.inria.gforge.telex.extensions.IterableScheduleGenerator;
import fr.inria.gforge.telex.extensions.ScheduleGenerator;
import fr.inria.gforge.treeds.action.CausalDependencyHandler;
import fr.inria.gforge.treeds.action.CreateAction;
import fr.inria.gforge.treeds.action.MergeAction;
import fr.inria.gforge.treeds.action.RemoveAction;
import fr.inria.gforge.treeds.action.SplitAction;
import fr.inria.gforge.treeds.action.TreeAction;
import fr.inria.gforge.treeds.action.TreeConstraintChecker;
import fr.inria.gforge.treeds.check.Statistics;
import fr.inria.gforge.treeds.state.TreeSpace;
import fr.inria.gforge.treeds.telex.responseParser.ResponseSchedule;
import fr.inria.gforge.treeds.utils.TreedsProperties;

public abstract class TreedsAbstractAdapter implements ITreeds,
		TelexApplication {

	/*
	 * latest state of the tree as result of the execution of the latest
	 * schedule
	 */
	private TreeSpace treeSpace;
	/* the constraint checker */
	private TreeConstraintChecker constraintChecker;
	/* tells the application wich causal dependency policy use */
	private CausalDependencyHandler causalDependencyHandler;
	private String documentLocation;
	private String latestScheduleID = "";
	private boolean check = false;
	private String nodeName;
	private String nodeIP;

	public TreedsAbstractAdapter() {
	}

	public void setProperties(TreedsProperties treedsProperties) {
		nodeName = treedsProperties.getNodeName();
		nodeIP = treedsProperties.getNodeIP();
		documentLocation = treedsProperties.getDocumentLocation();
		check = treedsProperties.isCheck();
		constraintChecker = new TreeConstraintChecker(
				treedsProperties.getOperationsCommutativityPolicy());
		causalDependencyHandler = new CausalDependencyHandler(
				treedsProperties.getCausalDependencyPolicy());
	}

	public String getDocumentLocation() {
		return documentLocation;
	}
	
	public String getLatestScheduleID() {
		return latestScheduleID;
	}
	
	public void setLatestScheduleID(String latestScheduleID) {
		this.latestScheduleID = latestScheduleID;
	}

	public String getNodeName() {
		return nodeName;
	}

	public String getNodeIP() {
		return nodeIP;
	}
	
	public TreeConstraintChecker getConstraintChecker() {
		return getConstraintChecker();
	}

	public void start() {
		treeSpace = new TreeSpace();

		// define documents' processing parameters
		ProcessingParameters parameters;
		try {
			parameters = new ProcessingParameters(treeSpace, TreeAction.class,
					Constraint.class, constraintChecker);
		} catch (Exception e) {
			System.err.println("cannot define parameters: " + e);
			System.exit(1);
			return;
		}

		startTelex(parameters);

		System.out.println("Opening: " + documentLocation);
		concreteOpenDocument();

		startThreads();
	}

	public abstract void startTelex(ProcessingParameters parameters);

	public abstract void concreteOpenDocument();

	public abstract void startThreads();

	public void closeDocument() {
		concreteCloseDocument();
		System.out.println("Document closed.");
	}

	public abstract void concreteCloseDocument();

	public abstract void exit();

	public void execute(Document document, ScheduleGenerator generator) {
		IterableScheduleGenerator iterableSchedulerGenerator = null;

		if (generator instanceof IterableScheduleGenerator) {
			// in our case, generator is of type IterableScheduleGenerator
			iterableSchedulerGenerator = (IterableScheduleGenerator) generator;
		} else {
			throw new RuntimeException("unknown schedule generator");
		}

		/* considers only the first schedule */
		Iterator<Schedule> scheduledIterator = iterableSchedulerGenerator
				.iterator();
		
		
		
		if (scheduledIterator.hasNext()) {
			Schedule schedule = scheduledIterator.next();
			
			try {
				schedule.getDocument().propose(schedule);
			} catch (ClosedDocumentException e) {
				e.printStackTrace();
			} catch (IncompatibleOpenModeException e) {
				e.printStackTrace();
			} catch (InvalidScheduleException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			Action[] actions = schedule.getActions();
			Action[] nonActions = schedule.getNonActions();
			ArrayList<TreeAction> treeActions = new ArrayList<TreeAction>();
			ArrayList<TreeAction> treeNonActions = new ArrayList<TreeAction>();

			for (int i = 0; i < actions.length; i++) {
				treeActions.add((TreeAction) actions[i]);
			}

			for (int i = 0; i < nonActions.length; i++) {
				treeNonActions.add((TreeAction) nonActions[i]);
			}

			ResponseSchedule responseSchedule = new ResponseSchedule(
					schedule.getId(), schedule.getDocument().getId(),
					treeActions, treeNonActions);

			executeResponseSchedule(responseSchedule);
		}

		generator.release();
	}

	/* for TreedsTelexMobileAdapter */
	public void execute(ArrayList<ResponseSchedule> schedules) {
		
		/* considers only the last schedule */
		ResponseSchedule responseSchedule = schedules.get(schedules.size() - 1);

		executeResponseSchedule(responseSchedule);

		setLatestScheduleID(responseSchedule.getId());
	}

	public void executeResponseSchedule(ResponseSchedule responseSchedule) {
		int schedulerNumber = 0;

		if (check) {
			Statistics.getInstance().setTotalActions(
					responseSchedule.getActions().size() +
					responseSchedule.getNonActions().size());
			Statistics.getInstance().setAbortedActions(
					responseSchedule.getNonActions().size());
			Statistics.getInstance().setExecutionEndtime(
					System.currentTimeMillis());
			int decidedActions = 0;
			for (TreeAction action : responseSchedule.getActions()) {
				if (action.isActionStable()) {
					decidedActions++;
				}
			}
			Statistics.getInstance().setDecidedActions(decidedActions);
		}

		executeActions(
				responseSchedule.getActions().toArray(new TreeAction[responseSchedule.getActions().size()]),
				responseSchedule.getNonActions().toArray(new TreeAction[responseSchedule.getNonActions().size()]));

		schedulerNumber++;
	}

	private synchronized void executeActions(TreeAction[] actions,
			TreeAction[] nonActions) {
		int stateNumber = 0;
		int actionNumber = 1;

		/* substitute the old state with the new one */
		treeSpace = new TreeSpace();

		if (check) {
			stateNumber++;

			ArrayList<TreeAction> allActions = new ArrayList<TreeAction>();

			for (TreeAction action : actions) {
				if (action.getSubmitterNode().equals(getNodeName())) {
					if (!allActions.contains(action)) {
						allActions.add(action);
					}
				}
			}
			for (TreeAction action : nonActions) {
				if (action.getSubmitterNode().equals(getNodeName())) {
					if (!allActions.contains(action)) {
						allActions.add(action);
					}
				}
			}
			for (TreeAction action : allActions) {
				if (action.isActionStable()) {
					Statistics.getInstance().addConsensusEndTime(
							action.getSpecificAction().toString(),
							System.currentTimeMillis());
				}
			}
		}

		for (TreeAction action : actions) {
			if (action.isCommitted()) {
				try {
					for (Method method : treeSpace.getClass()
							.getDeclaredMethods()) {
						/*
						 * obtains the method to execute on the targetInstance
						 * corresponding to this telex action
						 */

						if (method.getName().equals(
								action.getSpecificAction().getMethodName())) {
							Object[] methodArgs = action.getSpecificAction()
									.getArgs();

							/*
							 * executes the method corresponding to the telex
							 * action
							 */
							Boolean executed = (Boolean) method.invoke(
									treeSpace, methodArgs);

							if (executed) {
								if (check) {
                                                                    actionNumber++;
                                                                    stateNumber++;

								}
							}
							break; // no need to cycle again
						}
					}
				} catch (IllegalAccessException ex) {
					Logger.getLogger(TreedsTelexAdapter.class.getName()).log(
							Level.SEVERE, null, ex);
				} catch (IllegalArgumentException ex) {
					Logger.getLogger(TreedsTelexAdapter.class.getName()).log(
							Level.SEVERE, null, ex);
				} catch (InvocationTargetException ex) {
					Logger.getLogger(TreedsTelexAdapter.class.getName()).log(
							Level.SEVERE, null, ex);
				} catch (SecurityException ex) {
					Logger.getLogger(TreedsTelexAdapter.class.getName()).log(
							Level.SEVERE, null, ex);
				}
			}
		}
	}

	public void bindDocument(Document opened, Document bound) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	public void execute(Document document, Schedule schedule) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	private void submitFragment(TreeAction action) {
		if (check) {
			Statistics.getInstance().addConsensusStartTime(
					action.getSpecificAction().toString(),
					System.currentTimeMillis());
		}

		Fragment fragment = causalDependencyHandler.setCausalDependency(action);
		concreteSubmitFragment(fragment);
	}

	public abstract void concreteSubmitFragment(Fragment fragment);

	public String getTreeSpaceString() {
		return treeSpace.toString();
	}

	public boolean testCreatePrecondition(String nodeID) {
		return treeSpace.createPrecondition(nodeID);
	}

	public boolean testSplitNodePrecondition(String nodeID) {
		return treeSpace.splitNodePrecondition(nodeID);
	}

	public boolean testMergePrecondition(String nodeID, String newParentID) {
		return treeSpace.mergePrecondition(nodeID, newParentID);
	}

	public boolean testRemovePrecondition(String nodeID) {
		return treeSpace.removePrecondition(nodeID);
	}

	public synchronized LinkedList<String> getUsedIDs() {
		return treeSpace.getUsedIDs();
	}

	public void createTree(String nodeID) {
		CreateAction creatAction = new CreateAction(nodeID);
		TreeAction treeAction = new TreeAction(new int[] { nodeID.hashCode() },
				creatAction, nodeName, false);

		submitFragment(treeAction);
	}

	public void remove(String nodeID) {
		RemoveAction removeAction = new RemoveAction(nodeID);
		TreeAction treeAction = new TreeAction(new int[] { nodeID.hashCode() },
				removeAction, nodeName, false);

		submitFragment(treeAction);
	}

	public void merge(String nodeID, String newParentID) {
		MergeAction mergeAction = new MergeAction(nodeID, newParentID);
		TreeAction treeAction = new TreeAction(new int[] { nodeID.hashCode(),
				newParentID.hashCode() }, mergeAction, nodeName, false);

		submitFragment(treeAction);
	}

	public void splitNode(String nodeID) {
		SplitAction splitAction = new SplitAction(nodeID);
		TreeAction treeAction = new TreeAction(new int[] { nodeID.hashCode() },
				splitAction, nodeName, false);

		submitFragment(treeAction);
	}
}