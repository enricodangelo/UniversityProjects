package fr.inria.gforge.treeds.utils;

public class ConstraintNameGenerator {
	private static int n = 0;

	public static String getName(String prefix) {
		String name = "";

		name += "constraint-";
		name += prefix + "-";
		name += ++n;

		return name;
	}
}
