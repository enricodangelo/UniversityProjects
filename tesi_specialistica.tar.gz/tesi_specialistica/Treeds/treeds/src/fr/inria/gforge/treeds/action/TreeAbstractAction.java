package fr.inria.gforge.treeds.action;

import java.io.Serializable;

import fr.inria.gforge.telex.application.Fragment;
import fr.inria.gforge.treeds.utils.Constants.OPERATIONS_COMMUTATIVITY_POLICY;

public abstract class TreeAbstractAction implements Serializable {

	private static final long serialVersionUID = -2267123056995770762L;

	/* the name of the method to be invoked to executed the Action */
	private String methodName;

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getMethodName() {
		return methodName;
	}

	public abstract Object[] getArgs();

	public abstract String[] getModifiedObjects();

	public Fragment getConstraints(TreeAction a, TreeAction b,
			OPERATIONS_COMMUTATIVITY_POLICY operationsCommutativityPolicy) {
		Fragment fragment = new Fragment();

		switch (operationsCommutativityPolicy) {
		case ALL_NON_COMMUTATIVE:
			fragment = getAllNonCommutetiveConstraints(a, b);
			break;
		case SAME_OBJECT_ALL_NON_COMMUTATIVE:
			fragment = getSameObjectNonCommutativeConstraints(a, b);
			break;
		case SEMANTIC_COMMUTATIVITY:
			fragment = getSemanticConstraints(a, b);
			break;
		}

		return fragment;
	}

	public abstract Fragment getSemanticConstraints(TreeAction a, TreeAction b);

	public abstract Fragment getAllNonCommutetiveConstraints(TreeAction a,
			TreeAction b);

	public abstract Fragment getSameObjectNonCommutativeConstraints(
			TreeAction a, TreeAction b);
}
