package fr.inria.gforge.treeds.telex.responseParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import fr.inria.gforge.treeds.action.TreeAction;

public class ResponseParser {
	private static String name;
	private static int statusCode;
	private static String description;
	private static String cause = "";
	private static ArrayList<ResponseSchedule> schedules = new ArrayList<ResponseSchedule>();
	private static ArrayList<GetConstraintsPair> getConstraints = new ArrayList<GetConstraintsPair>();

	public static TelexResponse parse(String responseString) {
		if (responseString.isEmpty()) {
			return null;
		}

		SAXBuilder builder = new SAXBuilder();
		Reader reader = new StringReader(responseString);
		Document doc = null;
		TelexResponse telexResponse = null;

		try {
			doc = builder.build(reader);
		} catch (JDOMException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		if (doc != null) {
			Iterator<Element> itr = doc.getRootElement().getChildren()
					.iterator();

			while (itr.hasNext()) {
				Element element = itr.next();
				if (element.getName().equals("executed-commands")) {
					parseExecutedCommands(element);
				} else if (element.getName().equals("schedules")) {
					parseSchedules(element);
				} else if (element.getName().equals("get-constraints")) {
					parseGetConstraints(element);
				}
			}

			telexResponse = new TelexResponse(name, statusCode, description,
					cause, schedules, getConstraints);
		}

		return telexResponse;
	}

	private static void parseExecutedCommands(Element element) {
		Iterator<Element> itr1 = element.getChildren().iterator();

		while (itr1.hasNext()) {
			Element element1 = itr1.next();

			if (element1.getName().equals("command")) {
				Iterator<Element> itr2 = element1.getChildren().iterator();

				while (itr2.hasNext()) {
					Element element2 = itr2.next();
					if (element2.getName().equals("name")) {
						name = element2.getValue();
					} else if (element2.getName().equals("status-code")) {
						statusCode = Integer.parseInt(element2.getValue());
					} else if (element2.getName().equals("description")) {
						description = element2.getValue();
					} else if (element2.getName().equals("cause")) {
						cause = element2.getValue();
					} else {
						System.out.println("unrecognized element (expected: name, status-code, description, cause): "
										+ element2.getName());
					}
				}
			} else {
				System.out.println("unrecognized element (expected: command): "
						+ element1.getName());
			}
		}
	}

	private static void parseSchedules(Element element) {
		Iterator<Element> itr1 = element.getChildren().iterator();

		while (itr1.hasNext()) {
			Element element1 = itr1.next();
			ResponseSchedule schedule = null;

			if (element1.getName().equals("schedule")) {
				String id = "";
				String docID = "";
				ArrayList<TreeAction> treeActions = new ArrayList<TreeAction>();
				ArrayList<TreeAction> nonTreeActions = new ArrayList<TreeAction>();

				Iterator<Element> itr2 = element1.getChildren().iterator();

				while (itr2.hasNext()) {
					Element element2 = itr2.next();
					if (element2.getName().equals("schedule-id")) {
						id = element2.getValue();
					} else if (element2.getName().equals("doc-id")) {
						docID = element2.getValue();
					} else if (element2.getName().equals("actions")) {
						treeActions = parseAction(element2, "action");
					} else if (element2.getName().equals("non-actions")) {
						nonTreeActions = parseAction(element2, "action");
					} else {
						System.out
								.println("unrecognized element (expected: schedule-id, doc-id, actions, non-actions)");
					}
				}
				schedule = new ResponseSchedule(id, docID, treeActions,
						nonTreeActions);
			}
			schedules.add(schedule);
		}
	}

	private static ArrayList<TreeAction> parseAction(Element element,
			String elementName) {
		ArrayList<TreeAction> actions = new ArrayList<TreeAction>();
		Iterator<Element> actionsItr = element.getChildren().iterator();

		while (actionsItr.hasNext()) {
			Element actionElement = actionsItr.next();

			if (actionElement.getName().equals(elementName)) {
				TreeAction treeAction;
				String actionDescription = "";
				String actionID = "";

				Iterator<Element> itr = actionElement.getChildren().iterator();

				while (itr.hasNext()) {
					Element innerElement = itr.next();

					if (innerElement.getName().equals("action-description")) {
						actionDescription = innerElement.getValue();
					} else if (innerElement.getName().equals("action-id")) {
						actionID = innerElement.getValue();
					} else {
						System.out
								.println("unrecognized element (expected: schedule-id, doc-id)");
					}
				}

				treeAction = TelexMobileAction.toTreeAction(actionDescription,
						actionID);

				actions.add(treeAction);
			} else {
				System.out.println("unrecognized element: actionElement.getName() = " + actionElement.getName() + " expected elementName = " + elementName);
			}
		}

		return actions;
	}

	private static void parseGetConstraints(Element element) {
		Iterator<Element> itr1 = element.getChildren().iterator();

		while (itr1.hasNext()) {
			Element element1 = itr1.next();
			GetConstraintsPair getConstraintsPair = null;

			if (element1.getName().equals("get-constraints")) {
				Iterator<Element> itr2 = element1.getChildren().iterator();
				String action1Description = "";
				String action1ID = "";
				String action2Description = "";
				String action2ID = "";

				while (itr2.hasNext()) {
					Element element2 = itr2.next();
					if (element2.getName().equals("constraint")) {
						Iterator<Element> itr3 = element2.getChildren()
								.iterator();

						Element action1Element = itr3.next();

						if (action1Element.getName().equals(
								"action-description")) {
							action1Description = action1Element.getValue();
						} else if (action1Element.getName().equals("action-id")) {
							action1ID = action1Element.getValue();
						} else {
							System.out
									.println("unrecognized element (expected: schedule-id, doc-id)");
						}

						Element action2Element = itr3.next();

						if (action2Element.getName().equals(
								"action-description")) {
							action2Description = action2Element.getValue();
						} else if (action2Element.getName().equals("action-id")) {
							action2ID = action2Element.getValue();
						} else {
							System.out
									.println("unrecognized element (expected: schedule-id, doc-id)");
						}
					} else {
						System.out
								.println("unrecognized element (expected: constraint)");
					}
				}

				getConstraintsPair = new GetConstraintsPair(
						TelexMobileAction.toTreeAction(action1Description,
								action1ID), TelexMobileAction.toTreeAction(
								action2Description, action2ID));
			}
			getConstraints.add(getConstraintsPair);
		}
	}

	private static String streamToString(InputStream response) {
		String responseToString = "";
		BufferedReader streamReader = new BufferedReader(new InputStreamReader(
				response));
		String line;

		try {
			while ((line = streamReader.readLine()) != null) {
				responseToString += line;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return responseToString;
	}
}
