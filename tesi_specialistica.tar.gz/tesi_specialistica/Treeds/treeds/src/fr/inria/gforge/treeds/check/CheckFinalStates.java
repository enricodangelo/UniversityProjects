package fr.inria.gforge.treeds.check;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import fr.inria.gforge.treeds.utils.Constants;

public class CheckFinalStates {
	private static String outputDirectoryLocation;
	private static String reportFilemane;
	private static String operationsOkMessage = "The final operations are all the same.";
	private static String operationsErrMessage = "The final operations are not the same.";
	private static String allOperationsOkMessage = "The operations are all the same.";
	private static String allOperationsErrMessage = "The operations are not the same.";
	private static String stateOkMessage = "The final states are all the same.";
	private static String stateErrMessage = "The final states are not the same.";

	public static void main(String[] args) {
		if (args.length == 1) {
			outputDirectoryLocation = args[0];
		} else if (args.length == 2) {
			outputDirectoryLocation = args[0];
			reportFilemane = args[1];
		} else {
			System.exit(1);
		}

		File outputDirectory = null;
		BufferedReader reader = null;
		BufferedWriter writer = null;
		try {
			outputDirectory = new File(outputDirectoryLocation);
			writer = new BufferedWriter(new FileWriter(reportFilemane));

			checkFinalOperations(outputDirectory, reader, writer);
			checkAllOperations(outputDirectory, reader, writer);
			checkFinalState(outputDirectory, reader, writer);

			if (writer != null) {
				writer.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	private static void checkFinalOperations(File outputDirectory,
			BufferedReader reader, BufferedWriter writer) {
		try {
			String line;
			ArrayList<String> previousActions = new ArrayList<String>();
			ArrayList<String> currentActions = new ArrayList<String>();
			boolean equals = true;

			for (String outputFile : outputDirectory.list()) {
				reader = new BufferedReader(new FileReader(outputDirectory
						+ File.separator + outputFile));

				if (writer != null) {
					System.out.println("Writing output from file: "
							+ outputFile);
					writer.write(outputFile + "\n");
				}

				do {
					line = reader.readLine();
				} while (!line.equals(Constants.OPERATIONS_START_DELIMITER));

				currentActions = new ArrayList<String>();
				do {
					line = reader.readLine();

					if (!line.equals(Constants.OPERATIONS_END_DELIMITER)) {
						currentActions.add(line);
						if (writer != null) {
							writer.write(line + "\n");
						}
					}

				} while (!line.equals(Constants.OPERATIONS_END_DELIMITER));

				if (!previousActions.isEmpty()) {
					boolean previousContainsAllCurrent = true;
					boolean currentContainsAllprevious = true;

					for (String currentAction : currentActions) {
						if (!previousActions.contains(currentAction)) {
							previousContainsAllCurrent = false;
						}
					}

					for (String previousAction : previousActions) {
						if (!currentActions.contains(previousAction)) {
							currentContainsAllprevious = false;
						}
					}

					equals = previousContainsAllCurrent
							&& currentContainsAllprevious;
				}

				previousActions = new ArrayList<String>();
				for (String action : currentActions) {
					previousActions.add(action);
				}

			}

			if (equals) {
				System.out.println(operationsOkMessage);
				if (writer != null) {
					writer.write(operationsOkMessage + "\n");
				}
			} else {
				System.out.println(operationsErrMessage);
				if (writer != null) {
					writer.write(operationsErrMessage + "\n");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void checkAllOperations(File outputDirectory,
			BufferedReader reader, BufferedWriter writer) {
		try {
			String line;
			ArrayList<String> previousActions = new ArrayList<String>();
			ArrayList<String> currentActions = new ArrayList<String>();
			boolean equals = true;

			for (String outputFile : outputDirectory.list()) {
				reader = new BufferedReader(new FileReader(outputDirectory
						+ File.separator + outputFile));

				if (writer != null) {
					System.out.println("Writing output from file: "
							+ outputFile);
					writer.write(outputFile + "\n");
				}

				do {
					line = reader.readLine();
				} while (!line.equals(Constants.ALLOPERATIONS_START_DELIMITER));

				currentActions = new ArrayList<String>();
				do {
					line = reader.readLine();

					if (!line.equals(Constants.ALLOPERATIONS_END_DELIMITER)) {
						currentActions.add(line);
						if (writer != null) {
							writer.write(line + "\n");
						}
					}
				} while (!line.equals(Constants.ALLOPERATIONS_END_DELIMITER));

				if (!previousActions.isEmpty()) {
					boolean previousContainsAllCurrent = true;
					boolean currentContainsAllprevious = true;

					for (String currentAction : currentActions) {
						if (!previousActions.contains(currentAction)) {
							previousContainsAllCurrent = false;
						}
					}

					for (String previousAction : previousActions) {
						if (!currentActions.contains(previousAction)) {
							currentContainsAllprevious = false;
						}
					}

					equals = previousContainsAllCurrent
							&& currentContainsAllprevious;
				}

				previousActions = new ArrayList<String>();
				for (String action : currentActions) {
					previousActions.add(action);
				}

			}

			if (equals) {
				System.out.println(allOperationsOkMessage);
				if (writer != null) {
					writer.write(allOperationsOkMessage + "\n");
				}
			} else {
				System.out.println(allOperationsErrMessage);
				if (writer != null) {
					writer.write(allOperationsErrMessage + "\n");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void checkFinalState(File outputDirectory,
			BufferedReader reader, BufferedWriter writer) {
		try {
			String line;
			String previousState = "";
			String currentState = "";
			boolean equals = true;

			for (String outputFile : outputDirectory.list()) {
				reader = new BufferedReader(new FileReader(outputDirectory
						+ File.separator + outputFile));

				do {
					line = reader.readLine();
				} while (!line.equals(Constants.FINALSTATE_START_DELIMITER));

				do {
					line = reader.readLine();

					currentState = line;

					if (!currentState
							.equals(Constants.FINALSTATE_END_DELIMITER)) {
						if (!previousState.isEmpty()) {
							if (!previousState.equals(currentState)) {
								equals = false;
							}
						}
						previousState = currentState;
					}

					if ((writer != null)
							&& (!line
									.equals(Constants.FINALSTATE_END_DELIMITER))) {
						System.out.println("Writing output from file: "
								+ outputFile);
						writer.write(outputFile + "\n" + currentState + "\n");
					}
				} while (!line.equals(Constants.FINALSTATE_END_DELIMITER));
			}

			if (equals) {
				System.out.println(stateOkMessage);
				if (writer != null) {
					writer.write(stateOkMessage + "\n");
				}
			} else {
				System.out.println(stateErrMessage);
				if (writer != null) {
					writer.write(stateErrMessage + "\n");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
