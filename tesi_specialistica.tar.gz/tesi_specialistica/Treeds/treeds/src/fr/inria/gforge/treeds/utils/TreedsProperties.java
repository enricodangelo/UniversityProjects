package fr.inria.gforge.treeds.utils;

import fr.inria.gforge.treeds.utils.Constants.CAUSAL_DEPENDENCY_POLICY;
import fr.inria.gforge.treeds.utils.Constants.OPERATIONS_COMMUTATIVITY_POLICY;

public class TreedsProperties {
	private static final long serialVersionUID = 6840682344438072092L;

	private String concreteAdapterClass;
	private String nodeName;
	private String nodeIP;
	private String documentLocation;
	private int numberOfOperations;
	private boolean check;
	private boolean checkOnly;
	private String statisticsFilename;
	private String operationsFilename;
	private CAUSAL_DEPENDENCY_POLICY causalDependencyPolicy;
	private OPERATIONS_COMMUTATIVITY_POLICY operationsCommutativityPolicy;
	private boolean executeTrace;

	public TreedsProperties(String concreteAdapterClass, String nodeName,
			String nodeIP, String documentLocation, int numberOfOperations,
			boolean check, boolean checkOnly, String outputFilename,
			String reportFilename, String operationsFilename,
			String statisticsFilename,
			CAUSAL_DEPENDENCY_POLICY causalDependencyPolicy,
			OPERATIONS_COMMUTATIVITY_POLICY operationsCommutativityPolicy,
			boolean executeTrace) {

		this.concreteAdapterClass = concreteAdapterClass;
		this.nodeName = nodeName;
		this.nodeIP = nodeIP;
		this.documentLocation = documentLocation;
		this.numberOfOperations = numberOfOperations;
		this.check = check;
		this.checkOnly = checkOnly;
		this.operationsFilename = operationsFilename;
		this.statisticsFilename = statisticsFilename;
		this.causalDependencyPolicy = causalDependencyPolicy;
		this.operationsCommutativityPolicy = operationsCommutativityPolicy;
		this.executeTrace = executeTrace;
	}

	public String getConcreteAdapterClass() {
		return concreteAdapterClass;
	}

	public String getNodeName() {
		return nodeName;
	}

	public String getNodeIP() {
		return nodeIP;
	}

	public String getDocumentLocation() {
		return documentLocation;
	}

	public int getNumberOfOperations() {
		return numberOfOperations;
	}

	public boolean isCheck() {
		return check;
	}

	public boolean isCheckOnly() {
		return checkOnly;
	}

	public String getOperationsFilename() {
		return operationsFilename;
	}

	public String getStatisticsFilename() {
		return statisticsFilename;
	}

	public CAUSAL_DEPENDENCY_POLICY getCausalDependencyPolicy() {
		return causalDependencyPolicy;
	}

	public OPERATIONS_COMMUTATIVITY_POLICY getOperationsCommutativityPolicy() {
		return operationsCommutativityPolicy;
	}

	public boolean isExecuteTrace() {
		return executeTrace;
	}
}
