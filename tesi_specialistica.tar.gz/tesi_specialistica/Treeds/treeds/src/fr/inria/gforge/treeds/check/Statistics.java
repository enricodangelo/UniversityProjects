package fr.inria.gforge.treeds.check;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Statistics {
	private volatile static Statistics instance;
	private BufferedWriter writer;
	private int totalActions;
	private int abortedActions;
	private long operationSubmissionStartTime;
	private long operationSubmissionEndTime;
	private HashMap<String, Long> consensusStartTime;
	private HashMap<String, Long> consensusEndTime;
	private long executionStartTime;
	private long executionEndtime;
	private int decidedActions;

	private Statistics() {
		consensusStartTime = new HashMap<String, Long>();
		consensusEndTime = new HashMap<String, Long>();
	}

	public static Statistics getInstance() {
		if (instance == null) {
			synchronized (Statistics.class) {
				if (instance == null)
					instance = new Statistics();
			}
		}
		return instance;
	}

	public void writeStatistics(String statisticsFilename) {
		try {
			writer = new BufferedWriter(new FileWriter(statisticsFilename));

			// abort rate
			writer.write("total actions: " + totalActions + "\n");
			writer.write("aborted actions: " + abortedActions + "\n");
			writer.write("abort rate: " + getAbortRate() + "\n");

			// consensus times
			ArrayList<Long> consensusTimes = getConsensusTimes();
			writer.write("consensus times (ms) (" + consensusTimes.size()
					+ " actions): ");
			for (Iterator<Long> iterator = consensusTimes.iterator(); iterator
					.hasNext();) {
				Long cTime = (Long) iterator.next();
				if (iterator.hasNext()) {
					writer.write(cTime.toString() + ":");
				} else {
					writer.write(cTime.toString());
				}
			}
			writer.write("\n");

			// mean. min e max consensus time
			long meanConsensusTime = 0;
			long minConsensusTime = Long.MAX_VALUE;
			long maxConsensusTime = Long.MIN_VALUE;
			int numberOfDecidedActions = getConsensusTimes().size();
			for (Long consensusTime : getConsensusTimes()) {
				//min consensus time
				if (consensusTime < minConsensusTime) {
					minConsensusTime = consensusTime;
				}
				//max consensus time
				if (consensusTime > maxConsensusTime) {
					maxConsensusTime = consensusTime;
				}
				//mean consensus time
				meanConsensusTime += consensusTime;
			}
			if (numberOfDecidedActions != 0) {
				meanConsensusTime /= numberOfDecidedActions;
				writer.write("mean consensus time (ms): " + meanConsensusTime + "\n");
				writer.write("min consensus time (ms): " + minConsensusTime + "\n");
				writer.write("max consensus time (ms): " + maxConsensusTime + "\n");
			}

			// execution time
			writer.write("execution time (ms): " + getExecutionTime() + "\n");

			// decided actions per second
			long executionTimeSeconds = getExecutionTime() / 1000;
			if (executionTimeSeconds != 0) {
				writer.write("decided actions per second: "
						+ (double) decidedActions
						/ (double) executionTimeSeconds + "\n");
			}

			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void setTotalActions(int totalActions) {
		this.totalActions = totalActions;
	}

	public void setAbortedActions(int abortedActions) {
		this.abortedActions = abortedActions;
	}

	private double getAbortRate() {
		return ((double) abortedActions / (double) totalActions);
	}

	public void setOperationSubmissionStartTime(
			long operationSubmissionStartTime) {
		this.operationSubmissionStartTime = operationSubmissionStartTime;
	}

	public void setOperationSubmissionEndTime(long operationSubmissionEndTime) {
		this.operationSubmissionEndTime = operationSubmissionEndTime;
	}

	public long getOperationSubmissionTime() {
		return operationSubmissionEndTime - operationSubmissionStartTime;
	}

	public void addConsensusStartTime(String action, long startTime) {
		if (consensusStartTime.containsKey(action)) {
			System.out
					.println("Error. consensusStartTime already contains an entry for that action.");
		}

		consensusStartTime.put(action, startTime);
	}

	public void addConsensusEndTime(String action, long endTime) {
		if (!consensusEndTime.containsKey(action)) {
			consensusEndTime.put(action, endTime);
		}
	}

	private ArrayList<Long> getConsensusTimes() {
		ArrayList<Long> consensusTimes = new ArrayList<Long>();

		for (String action : consensusEndTime.keySet()) {
			if (consensusStartTime.containsKey(action)) {
				long startTime = consensusStartTime.get(action);
				long endTime = consensusEndTime.get(action);
				
				consensusTimes.add(endTime - startTime);
			}
		}

		return consensusTimes;
	}

	public void setExecutionStartTime(long executionStartTime) {
		this.executionStartTime = executionStartTime;
	}

	public void setExecutionEndtime(long executionEndtime) {
		this.executionEndtime = executionEndtime;
	}

	private long getExecutionTime() {
		return executionEndtime - executionStartTime;
	}

	public void setDecidedActions(int decidedActions) {
		this.decidedActions = decidedActions;
	}
}
