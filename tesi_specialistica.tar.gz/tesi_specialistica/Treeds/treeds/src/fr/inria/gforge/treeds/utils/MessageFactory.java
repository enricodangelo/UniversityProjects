package fr.inria.gforge.treeds.utils;

import fr.inria.gforge.treeds.telex.TreedsTelexMobileAdapter;

public class MessageFactory {

	TreedsTelexMobileAdapter treedsTelexMobileAdapter;

	public MessageFactory(TreedsTelexMobileAdapter treedsTelexMobileAdapter) {
		this.treedsTelexMobileAdapter = treedsTelexMobileAdapter;
	}

	public String createInitMessage() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><commands><command><name>+</name><param>ECHO</param></command><command><name>+</name><param>TRACE</param></command><command><name>INIT</name><param>default</param><param>1</param><param>0</param></command></commands>";
	}

	public String createOpenMessage(String documentLocation) {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><commands><command><name>OPEN</name><param>"
				+ documentLocation
				+ "</param><param>CREATE</param></command></commands>";
	}

	public String createCloseMessage(String documentLocation) {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><commands><command><name>CLOSE</name><param>"
				+ documentLocation
				+ "</param><param>CREATE</param></command></commands>";
	}

	public String createActionMessage(String actionName, Integer[] keys) {
		String[] messageParams = new String[1 + keys.length];
		String message = "";

		messageParams[0] = actionName;

		for (int i = 0; i < keys.length; i++) {
			messageParams[1 + i] = Integer.toString(keys[i]);
		}

		message += "<?xml version=\"1.0\" encoding=\"UTF-8\"?><commands>";

		message += createActionCommandMessage(actionName, keys);

		message += "</commands>";

		return message;
	}

	public String createActionCommandMessage(String actionName, Integer[] keys) {
		String[] messageParams = new String[1 + keys.length];
		String message = "";

		messageParams[0] = actionName;

		for (int i = 0; i < keys.length; i++) {
			messageParams[1 + i] = Integer.toString(keys[i]);
		}

		message += "<command><name>ACTION</name>";

		for (int i = 0; i < messageParams.length; i++) {
			message += "<param>" + messageParams[i] + "</param>";
		}

		message += "</command>";

		return message;
	}

	public String createConstraintMessage(String constraintName,
			String action1Name, String action2Name, String constraint) {
		String message = "";
		String constraintPartA = "";
		String constraintPartB = "";
		String constraintNameA = "";
		String constraintNameB = "";

		if (constraint
				.equals(Constants.CONSTRAINTS_STRING[Constants.CONSTRAINTS.ATOMIC
						.ordinal()])) {
			constraintNameA = constraintName + "a";
			constraintNameB = constraintName + "b";
			constraintPartA = createConstraintCommandMessage(constraintNameA,
					action1Name, action2Name,
					Constants.CONSTRAINTS_STRING[Constants.CONSTRAINTS.ENABLES
							.ordinal()]);
			constraintPartB = createConstraintCommandMessage(constraintNameB,
					action2Name, action1Name,
					Constants.CONSTRAINTS_STRING[Constants.CONSTRAINTS.ENABLES
							.ordinal()]);
		} else if (constraint
				.equals(Constants.CONSTRAINTS_STRING[Constants.CONSTRAINTS.CAUSAL
						.ordinal()])) {
			constraintNameA = constraintName + "a";
			constraintNameB = constraintName + "b";
			constraintPartA = createConstraintCommandMessage(constraintNameA,
					action1Name, action2Name,
					Constants.CONSTRAINTS_STRING[Constants.CONSTRAINTS.ENABLES
							.ordinal()]);
			constraintPartB = createConstraintCommandMessage(
					constraintNameB,
					action1Name,
					action2Name,
					Constants.CONSTRAINTS_STRING[Constants.CONSTRAINTS.NOT_AFTER
							.ordinal()]);
		} else if (constraint
				.equals(Constants.CONSTRAINTS_STRING[Constants.CONSTRAINTS.ANTAGONISM
						.ordinal()])) {
			constraintNameA = constraintName + "a";
			constraintNameB = constraintName + "b";
			constraintPartA = createConstraintCommandMessage(
					constraintNameA,
					action1Name,
					action2Name,
					Constants.CONSTRAINTS_STRING[Constants.CONSTRAINTS.NOT_AFTER
							.ordinal()]);
			constraintPartB = createConstraintCommandMessage(
					constraintNameB,
					action2Name,
					action1Name,
					Constants.CONSTRAINTS_STRING[Constants.CONSTRAINTS.NOT_AFTER
							.ordinal()]);
		} else {
			constraintPartA = createConstraintCommandMessage(constraintName,
					action1Name, action2Name, constraint);
		}

		if (!constraintNameA.isEmpty()) {
			treedsTelexMobileAdapter.getConstraintsMap().put(constraintName,
					new String[] { constraintNameA, constraintNameB });
		}

		message += "<?xml version=\"1.0\" encoding=\"UTF-8\"?><commands>";

		message += constraintPartA;

		if (!constraintPartB.isEmpty()) {
			message += constraintPartB;
		}

		message += "</commands>";

		return message;
	}

	public String createConstraintCommandMessage(String constraintName,
			String action1Name, String action2Name, String constraint) {
		String[] params = new String[4];
		String message = "";

		params[0] = constraintName;
		params[1] = action1Name;
		params[2] = constraint;
		params[3] = action2Name;

		message += "<command><name>CONSTR</name>";

		for (int i = 0; i < params.length; i++) {
			message += "<param>" + params[i] + "</param>";
		}

		message += "</command>";

		return message;
	}

	public String createFragmentMessage(String document,
			String[] actionsCommands, String[] constraintsCommands,
			String[] actionsNames, String[] constraintsNames) {
		String[] messageParams = new String[1 + actionsNames.length
				+ constraintsNames.length];
		String message = "";

		messageParams[0] = document;

		for (int i = 0; i < actionsNames.length; i++) {
			messageParams[1 + i] = actionsNames[i];
		}

		for (int i = 0; i < constraintsNames.length; i++) {
			messageParams[1 + actionsNames.length + i] = constraintsNames[i];
		}

		message += "<?xml version=\"1.0\" encoding=\"UTF-8\"?><commands>";

		for (int i = 0; i < actionsCommands.length; i++) {
			message += actionsCommands[i];
		}

		for (int i = 0; i < constraintsCommands.length; i++) {
			message += constraintsCommands[i];
		}

		message += "<command><name>AFRAG</name>";

		for (int i = 0; i < messageParams.length; i++) {
			message += "<param>" + messageParams[i] + "</param>";
		}

		message += "</command></commands>";

		return message;
	}

	public String createGetLastScheduleMessage(String documentLocation) {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><commands><command><name>GETLASTSCHEDULES</name><param>"
				+ documentLocation + "</param></command></commands>";
	}

	public String createGetConstraintsMessage() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><commands><command><name>GETCONSTRAINTS</name></command></commands>";
	}

	public String createProposeMessage(String documentLocation,
			String scheduleID) {
		String message = "";

		message = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><commands><command><name>PROPOSE</name><param>"
				+ documentLocation
				+ "</param><param>"
				+ scheduleID
				+ "</param></command></commands>";

		return message;
	}
}
