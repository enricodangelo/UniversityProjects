/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.inria.gforge.treeds.state;

import fr.inria.gforge.telex.application.DocumentState;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;
import fr.inria.gforge.treeds.utils.Constants;

/**
 * 
 * @author edangelo
 */
public class TreeSpace implements DocumentState {

	private static final long serialVersionUID = -566567702650435921L;
	private TreeSet<Tree> trees;

	public TreeSpace() {
		trees = new TreeSet<Tree>();
	}

	public synchronized LinkedList<String> getUsedIDs() {
		LinkedList<String> usedIDs = new LinkedList<String>();

		for (Tree tree : trees) {
			usedIDs.add(tree.getID());
		}

		return usedIDs;
	}

	/*
	 * node IDs are assured to be unique, so the first node found is the right
	 * one
	 */
	private synchronized Tree getNode(String nodeID) {
		Tree result = null;

		for (Tree tree : trees) {
			if (tree.getID().equals(nodeID)) {
				result = tree;
				break;
			}
		}

		return result;
	}

	public synchronized boolean createPrecondition(String nodeID) {
		boolean result = false;
		Tree node = getNode(nodeID);

		if (node == null) {
			result = true;
		}

		return result;
	}

	public synchronized boolean create(String nodeID) {
		boolean result = false;

		if (createPrecondition(nodeID)) {
			Tree realTree = new Tree(nodeID);
			trees.add(realTree);
			result = true;
		}

		return result;
	}

	public synchronized boolean removePrecondition(String nodeID) {
		boolean result = false;
		Tree node = getNode(nodeID);

		if ((node != null) && (node.getChildren().isEmpty())) {
			result = true;
		}
		return result;
	}

	public synchronized boolean remove(String nodeID) {
		boolean result = false;
		Tree node = null;

		if (removePrecondition(nodeID)) {
			node = getNode(nodeID);
			String parentID = node.getParent();
			if (!parentID.isEmpty()) {
				Tree parent = getNode(parentID);
				parent.removeChild(nodeID);
			}

			trees.remove(node);
			result = true;
		}
		return result;
	}

	public synchronized boolean splitNodePrecondition(String nodeID) {
		boolean result = false;
		Tree node = getNode(nodeID);

		if (node != null) {
			String parentID = node.getParent();
			Tree parent = getNode(parentID);
			if (parent != null) {
				result = true;
			}
		}

		return result;
	}

	public synchronized boolean splitNode(String nodeID) {
		boolean result = false;
		Tree node = null;

		if (splitNodePrecondition(nodeID)) {
			node = getNode(nodeID);
			Tree parent = getNode(node.getParent());
			parent.removeChild(node.getID());
			node.setParent("");
			result = true;
		}

		return result;
	}

	private synchronized ArrayList<String> getSubTree(String nodeID) {
		ArrayList<String> subTrees = new ArrayList<String>();

		subTrees.add(nodeID);

		Tree node = getNode(nodeID);

		for (String child : node.getChildren()) {
			subTrees.addAll(getSubTree(child));
		}

		return subTrees;
	}

	public synchronized boolean mergePrecondition(String nodeID,
			String newParentID) {
		boolean result = false;
		Tree newParent = getNode(newParentID);
		Tree node = getNode(nodeID);

		if ((newParent != null) && (node != null) && (!node.hasParent())
				&& (!getSubTree(nodeID).contains(newParentID))) {
			result = true;
		}

		return result;
	}

	public synchronized boolean merge(String nodeID, String newParentID) {
		boolean result = false;
		Tree newParent = null;
		Tree node = null;

		if (mergePrecondition(nodeID, newParentID)) {
			newParent = getNode(newParentID);
			node = getNode(nodeID);
			newParent.merge(node);
			result = true;
		}

		return result;
	}

	public Serializable[] split() {
		return null;
	}

	public void assemble(Serializable[] parts) {
	}

	@Override
	public synchronized String toString() {
		String result = "";

		if (trees.isEmpty()) {
			result = Constants.EMPTY;
		} else {
			for (Iterator<Tree> treeIterator = trees.iterator(); treeIterator
					.hasNext();) {
				if (treeIterator.hasNext()) {
					Tree tree = treeIterator.next();

					result += tree;
					if (treeIterator.hasNext()) {
						result += Constants.NODE_DELIMITER;
					}
				}
			}
		}

		return result;
	}

	@Override
	public synchronized Object clone() {
		TreeSpace clonedTreespace = new TreeSpace();

		for (Tree tree : trees) {
			clonedTreespace.trees.add(tree);
		}

		return clonedTreespace;
	}
}
