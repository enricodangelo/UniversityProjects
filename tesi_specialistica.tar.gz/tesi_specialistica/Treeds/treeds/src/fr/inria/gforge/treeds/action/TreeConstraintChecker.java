/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.inria.gforge.treeds.action;

import fr.inria.gforge.telex.application.Action;
import fr.inria.gforge.telex.application.ConstraintChecker;
import fr.inria.gforge.telex.application.Fragment;
import fr.inria.gforge.treeds.utils.Constants.OPERATIONS_COMMUTATIVITY_POLICY;

/**
 * 
 * @author edangelo
 */
public class TreeConstraintChecker implements ConstraintChecker {
	private OPERATIONS_COMMUTATIVITY_POLICY operationsCommutativityPolicy;

	public TreeConstraintChecker(
			OPERATIONS_COMMUTATIVITY_POLICY operationCommutativityPolicy) {
		this.operationsCommutativityPolicy = operationCommutativityPolicy;
	}

	public Fragment getConstraints(Action a, Action b) {
		Fragment fragment = new Fragment();
		TreeAction treeActionA = (TreeAction) a;
		TreeAction treeActionB = (TreeAction) b;

		/*
		 * the constraints are checked only if the two actions are not both in a
		 * decided state: committed or aborted
		 */
		if (!(treeActionA.isCommitted() || treeActionA.isAborted())
				&& !(treeActionB.isCommitted() || treeActionB.isAborted())) {
			fragment = treeActionA.getSpecificAction().getConstraints(
					treeActionA, treeActionB, operationsCommutativityPolicy);
		}

		return fragment;
	}
}
