/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.inria.gforge.treeds.utils;

/**
 * 
 * @author edangelo
 */
public final class Constants {

	public final static String DOCUMENT_LOCATION = "TelexDocuments/TreeSpace.dox";
	public final static String EMPTY = "empty";
	// output constants
	public final static String NODE_DELIMITER = ";";
	public final static String FIELD_DELIMITER = ":";
	public final static String CHILD_DELIMITER = ",";
	public final static String START_EXECUTE_DELIMITER = "start execute";
	public final static String END_EXECUTE_DELIMITER = "end execute";
	public final static String START_SCHED_ITERATION_DELIMITER = "start scheduler iteration";
	public final static String END_SCHED_ITERATION_DELIMITER = "end scheduler operation";
	public final static String START_SCHED_DELIMITER = "start scheduler";
	public final static String END_SCHED_DELIMITER = "end scheduler";
	public final static String STATE_HEADER = "state";
	public final static String ACTION_HEADER = "action";
	// telex actions constants
	public final static String DESCRIPTION_FIELD = "method";
	public final static String ARGS_FIELD = "args";
	public final static String CREATEACTION_METHODNAME = "create";
	public final static String REMOVEACTION_METHODNAME = "remove";
	public final static String MERGEACTION_METHODNAME = "merge";
	public final static String SPLITACTION_METHODNAME = "splitNode";
	// xml constants
	public final static String XML_ROOT = "treeds-execution";
	public final static String XML_SCHEDULER_ITERATION = "scheduler-iteration";
	public final static String XML_SCHEDULER = "scheduler";
	public final static String XML_SCHEDULER_NUMBER_ATTR = "number";
	public final static String XML_STATE = "state";
	public final static String XML_STATE_NUMBER_ATTR = "number";
	public final static String XML_ACTION = "action";
	public final static String XML_ACTION_NUMBER_ATTR = "number";
	// properties constants
	public final static String DEFAULT_OUTPUT_FILENAME_POSTFIX = "finalstate.txt";
	public final static String DEFAULT_REPORT_FILENAME_POSTFIX = "report.xml";
	public final static String DEFAULT_OPERATIONS_FILENAME_POSTFIX = "operations.txt";
	public final static String DEFAULT_STATISTICS_FILENAME_POSTFIX = "statistics.txt";
	public final static String CONCRETE_ADAPTER_CLASS_PROPERTY = "ConcreteAdapterClass";
	public final static String NODE_NAME_PROPERTY = "NodeName";
	public final static String NODE_IP_PROPERTY = "NodeIP";
	public final static String DOCUMENT_LOCATION_PROPERTY = "DocumentLocation";
	public final static String NUMBER_OF_OPERATIONS_PROPERTY = "NumberOfOperations";
	public final static String CHECK_PROPERTY = "Check";
	public final static String CHECK_ONLY_PROPERTY = "CheckOnly";
	public final static String OUTPUT_FILENAME_PROPERTY = "OutputFilename";
	public final static String REPORT_FILENAME_PROPERTY = "ReportFilename";
	public final static String OPERATIONS_FILENAME_PROPERTY = "OperationsFilename";
	public final static String STATISTICS_FILENAME_PROPERTY = "StatisticsFilename";
	public final static String CAUSAL_DEPENDENCY_PROPERTY = "CausalDependency";
	public final static String DEFAULT_CAUSAL_DEPENDENCY_POLICY = "EVERY_OPERATION_ON_SAME_OBJECT";
	public final static String OPERATIONS_COMMUTATIVITY_PROPERTY = "OperationsCommutativity";
	public final static String DEFAULT_OPERATIONS_COMMUTATIVITY_POLICY = "SEMANTIC_COMMUTATIVITY";
	public final static String EXECUTE_TRACE_PROPERTY = "ExecuteTrace";

	//

	public static enum Operaitons {

		CREATE, REMOVE, MERGE, SPLIT
	};

	public static enum CAUSAL_DEPENDENCY_POLICY {

		EVERY_OPERATION, EVERY_OPERATION_ON_SAME_OBJECT
	};

	public static enum OPERATIONS_COMMUTATIVITY_POLICY {

		ALL_NON_COMMUTATIVE, SAME_OBJECT_ALL_NON_COMMUTATIVE, SEMANTIC_COMMUTATIVITY
	};

	//
	public final static String END_OPERATIONS = "END_OPERATIONS";
	public final static String OPERATIONS_START_DELIMITER = "Operations:";
	public final static String OPERATIONS_END_DELIMITER = "End Operations.";
	public final static String ALLOPERATIONS_START_DELIMITER = "All Operations:";
	public final static String ALLOPERATIONS_END_DELIMITER = "End All Operations.";
	public final static String FINALSTATE_START_DELIMITER = "State:";
	public final static String FINALSTATE_END_DELIMITER = "End State.";

	// TelexMobile Adapter
	public static enum CONSTRAINTS {
		ENABLES, NOT_AFTER, NON_COMMUTING, ATOMIC, CAUSAL, ANTAGONISM
	}

	public final static String[] CONSTRAINTS_STRING = { "ENABLES", "NOT_AFTER",
			"NON_COMMUTING", "ATOMIC", "CAUSAL", "ANTAGONISM" };
	public final static int STATUSCODE_OK = 200;
	public final static String GETCONSTRAINT_RETURN_COMMAND = "GETCONSTRAINTS";
	public final static String GETLASTSCHEDULE_RETURN_COMMAND = "GETLASTSCEDULES";
	public final static String PROPOSE_RETURN_COMMAND = "PROPOSE";
}
