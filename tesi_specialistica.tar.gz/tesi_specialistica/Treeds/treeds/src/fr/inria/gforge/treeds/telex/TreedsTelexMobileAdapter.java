package fr.inria.gforge.treeds.telex;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;

import fr.inria.gforge.telex.application.Action;
import fr.inria.gforge.telex.application.Constraint;
import fr.inria.gforge.telex.application.Fragment;
import fr.inria.gforge.telex.application.ProcessingParameters;
import fr.inria.gforge.treeds.action.TreeAbstractAction;
import fr.inria.gforge.treeds.action.TreeAction;
import fr.inria.gforge.treeds.telex.responseParser.ResponseParser;
import fr.inria.gforge.treeds.telex.responseParser.TelexResponse;
import fr.inria.gforge.treeds.utils.ActionNameGenerator;
import fr.inria.gforge.treeds.utils.Constants;
import fr.inria.gforge.treeds.utils.ConstraintNameGenerator;
import fr.inria.gforge.treeds.utils.MessageFactory;

public class TreedsTelexMobileAdapter extends TreedsAbstractAdapter {

	private HttpClient _client;
	private String serverUrl;
	private String clientId;
	private MessageFactory messageFactory;
	private HashMap<String, String[]> constraintsMap;
	private Set<String> submittedActions;
	private boolean running = true;
	private Thread getConstraintsThread;
	private Thread getLastScheduleThread;
	private Thread proposeThread;

	public TreedsTelexMobileAdapter() {
		_client = new HttpClient();

		constraintsMap = new HashMap<String, String[]>();
		submittedActions = new HashSet<String>();
		messageFactory = new MessageFactory(this);

		getConstraintsThread = new GetConstraintsThread(this);
		getLastScheduleThread = new GetLastScheduleThread(this);
		proposeThread = new ProposeThread(this);
	}

	public HashMap<String, String[]> getConstraintsMap() {
		return constraintsMap;
	}

	public boolean isRunning() {
		return running;
	}

	@Override
	public void startTelex(ProcessingParameters parameters) {
		String balancerAddress = "http://" + getNodeIP() + ":8080/init";

		System.out.println("balancerAddress: " + balancerAddress);

		connectToBalancer(balancerAddress);

		init();
	}

	@Override
	public void startThreads() {
		getConstraintsThread.start();
		getLastScheduleThread.start();
		proposeThread.start();
	}

	@Override
	public void concreteOpenDocument() {
		open(getDocumentLocation());
	}

	@Override
	public void concreteCloseDocument() {
		close(getDocumentLocation());
	}

	@Override
	public void exit() {
		running = false;
	}

	@Override
	public void concreteSubmitFragment(Fragment fragment) {
		ArrayList<Action> actions = new ArrayList<Action>();
		actions.addAll(fragment.getActions());
		ArrayList<Constraint> constraints = new ArrayList<Constraint>();
		constraints.addAll(fragment.getConstraints());
		String[] actionsNames = new String[actions.size()];
		String[] constraintsNames = new String[constraints.size()];
		String[] actionsCommands = new String[actions.size()];
		String[] constraintsCommands = new String[constraints.size()];

		for (int i = 0; i < actions.size(); i++) {
			Action action = actions.get(i);
			TreeAbstractAction treeAction = ((TreeAction) action)
					.getSpecificAction();
			String[] actionParams = new String[treeAction.getArgs().length];
			Integer[] keys = new Integer[action.getKeys().length];
			String actionName;

			for (int j = 0; j < treeAction.getArgs().length; j++) {
				actionParams[j] = (String) treeAction.getArgs()[j];
			}

			for (int j = 0; j < action.getKeys().length; j++) {
				keys[j] = action.getKeys()[j];
			}

			actionName = ActionNameGenerator.generateName(action,
					treeAction.getMethodName(), getNodeName(), actionParams);

			actionsCommands[i] = messageFactory.createActionCommandMessage(
					actionName, keys);

			actionsNames[i] = actionName;
		}

		for (int i = 0; i < constraints.size(); i++) {
			Constraint constraint = constraints.get(i);
			String constraintName = ConstraintNameGenerator
					.getName(getNodeName());

			constraintsCommands[i] = messageFactory
					.createConstraintCommandMessage(constraintName,
							ActionNameGenerator.getName(constraint
									.getFirstAction()), ActionNameGenerator
									.getName(constraint.getSecondAction()),
							Constants.CONSTRAINTS_STRING[constraint.getType()
									.ordinal()]);

			constraintsNames[i] = constraintName;
		}

		fragment(getDocumentLocation(), actionsCommands, constraintsCommands,
				actionsNames, constraintsNames);
	}

	/**
	 * 
	 * @param balancerAdress
	 *            address of server balancer
	 * @return an array of string containing the server URL and the client ID
	 *         received by balancer, null in case of error.
	 */
	public void connectToBalancer(String balancerAdress) {
		GetMethod getToBalancer = new GetMethod(balancerAdress);

		try {
			_client.executeMethod(getToBalancer);

			serverUrl = getHeaderValue(getToBalancer.getResponseHeaders(),
					"connectionPath");
			System.out.println("URL received from server: " + serverUrl);

			clientId = getHeaderValue(getToBalancer.getResponseHeaders(),
					"Set-Cookie");
			System.out.println("ID received from server: " + clientId);
		} catch (HttpException e) {
			System.err.println("getToBalancer Fatal protocol violation: "
					+ e.getMessage());
			e.printStackTrace();

			System.exit(1);
		} catch (IOException e) {
			System.err.println("getToBalancer Fatal transport error: "
					+ e.getMessage());
			e.printStackTrace();

			System.exit(1);
		} finally {
			getToBalancer.releaseConnection();
		}
	}

	public void init() {
		String initMessage = messageFactory.createInitMessage();

		postToServer(initMessage);
	}

	public void open(String documentLocation) {
		String openMessage = messageFactory.createOpenMessage(documentLocation);

		postToServer(openMessage);
	}

	public void close(String documentLocation) {
		String closeMessage = messageFactory
				.createCloseMessage(documentLocation);

		postToServer(closeMessage);
	}

	public void action(String actionName, Integer[] keys) {
		String actionMessage = messageFactory.createActionMessage(actionName,
				keys);

		postToServer(actionMessage);
	}

	public void constraint(String constraintName, String action1Name,
			String action2Name, String constraint) {
		String constraintMessage = messageFactory.createConstraintMessage(
				constraintName, action1Name, action2Name, constraint);

		postToServer(constraintMessage);
	}

	public void fragment(String document, String[] actionsCommands,
			String[] constraintsCommands, String[] actionsNames,
			String[] constraintsNames) {

		ArrayList<String> validActionsNames = new ArrayList<String>();
		ArrayList<String> validConstraintsNames = new ArrayList<String>();
		String response = "";
		TelexResponse telexResponse;

		for (String actionName : actionsNames) {
			if (!submittedActions.contains(actionName)) {
				validActionsNames.add(actionName);
			}
		}

		for (String constraintName : constraintsNames) {
			if (constraintsMap.containsKey(constraintName)) {
				String[] constraints = constraintsMap.get(constraintName);
				validConstraintsNames.addAll(Arrays.asList(constraints));
			} else {
				validConstraintsNames.add(constraintName);
			}
		}

		String fragmentMessage = messageFactory.createFragmentMessage(document,
				actionsCommands, constraintsCommands,
				validActionsNames.toArray(new String[0]),
				validConstraintsNames.toArray(new String[0]));

		response = postToServer(fragmentMessage);

		telexResponse = ResponseParser.parse(response);

		if (telexResponse != null) {
			if (telexResponse.getStatusCode() == Constants.STATUSCODE_OK) {
				for (String actionName : validActionsNames) {
					submittedActions.add(actionName);
				}
			}
		}
	}

	public TelexResponse getLastSchedule(String documentLocation) {
		TelexResponse telexResponse = null;

		String getLastScheduleMessage = messageFactory
				.createGetLastScheduleMessage(documentLocation);
		String response = postToServer(getLastScheduleMessage);
		telexResponse = ResponseParser.parse(response);

		return telexResponse;
	}

	public TelexResponse getConstraints() {
		TelexResponse telexResponse = null;

		String getConstraintsMessage = messageFactory
				.createGetConstraintsMessage();
		String response = postToServer(getConstraintsMessage);
		telexResponse = ResponseParser.parse(response);

		return telexResponse;
	}

	public TelexResponse propose(String documentLocation, String scheduleID) {
		TelexResponse telexResponse = null;

		String proposeMessage = messageFactory.createProposeMessage(
				documentLocation, scheduleID);
		postToServer(proposeMessage);

		return telexResponse;
	}

	/**
	 * same as postToServer(String serverUrl, String clientId, FileInputStream
	 * fileCommandsInputStream) but take an array of sting each string composed
	 * by command name and his parameters separated by a blank space instead of
	 * an fileInputStrem.
	 * 
	 * @param serverUrl
	 *            url of server to connect
	 * @param clientId
	 *            client id to send as cookie
	 * @param commands
	 *            an array of string, each string composed by a command name and
	 *            his parameters separated by blank space.
	 * @return the input stream of server response body or null in case of error
	 */
	private synchronized String postToServer(String commands) {
		PostMethod post = new PostMethod(serverUrl);
		post.addRequestHeader("Cookie", "id=" + clientId);
		String response = "";

//		// TODO debug
//		System.out.println("postToServer(): message = \n" + commands);

		try {
			RequestEntity reqEntity = new StringRequestEntity(commands,
					"text/xml", Charset.defaultCharset().name());

			post.setRequestEntity(reqEntity);

			int statusCode = _client.executeMethod(post);

			if (statusCode == HttpStatus.SC_OK) {
				response = post.getResponseBodyAsString();

//				// TODO debug
//				System.out.println("postToServer(): response = \n" + response);
			}

			return response;
		} catch (IOException e) {
			System.err.println("error in receiving response body: "
					+ e.getMessage());
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * 
	 * @param headers
	 *            headers to parse
	 * @param headerName
	 *            name of header
	 * @return the value of header specified in name parameters, null if it
	 *         doesn't exist
	 */
	private String getHeaderValue(Header[] headers, String headerName) {
		String result = null;

		for (Header h : headers) {
			if (h.getName().equalsIgnoreCase(headerName)) {
				result = h.getValue();
				break;
			}
		}
		if (result.contains("id=")) {
			return result.substring(3);
		} else {
			return result;
		}
	}
}