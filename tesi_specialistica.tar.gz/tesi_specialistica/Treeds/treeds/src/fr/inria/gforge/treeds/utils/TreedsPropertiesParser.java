/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.inria.gforge.treeds.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.Inet4Address;
import java.util.logging.Level;
import java.util.logging.Logger;

import fr.inria.gforge.treeds.utils.Constants.CAUSAL_DEPENDENCY_POLICY;
import fr.inria.gforge.treeds.utils.Constants.OPERATIONS_COMMUTATIVITY_POLICY;

/**
 * 
 * @author edangelo
 */
public class TreedsPropertiesParser extends java.util.Properties {

	private static final long serialVersionUID = -5127113266709364349L;
	private static String hostname;

	public TreedsPropertiesParser(String[] args) {
		String propertiesFilename = "";
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("-p")) {
				propertiesFilename = args[i + 1];
				break;
			}
		}

		if (propertiesFilename.isEmpty()) {
			System.err.println("You must specify a properties file.");
			System.exit(1);
		}

		try {
			load(new FileInputStream(propertiesFilename));
			hostname = Inet4Address.getLocalHost().getHostName();
		} catch (IOException ex) {
			Logger.getLogger(TreedsPropertiesParser.class.getName()).log(
					Level.SEVERE, null, ex);
		}
	}

	private String getConcreteAdapterClassProperty() {
		return getProperty(Constants.CONCRETE_ADAPTER_CLASS_PROPERTY, "");
	}

	private String getNodeNameProperty() {
		return getProperty(Constants.NODE_NAME_PROPERTY, "");
	}

	private String getNodeIPProperty() {
		return getProperty(Constants.NODE_IP_PROPERTY, "");
	}

	private String getDocumentLocationProperty() {
		String documentLocation = getProperty(
				Constants.DOCUMENT_LOCATION_PROPERTY, "./");
		if (documentLocation.startsWith("/")) {
			documentLocation = documentLocation.substring(1,
					documentLocation.length());
		}

		return documentLocation;
	}

	private int getNumberOfOperationsProperty() {
		return Integer.parseInt(getProperty(
				Constants.NUMBER_OF_OPERATIONS_PROPERTY, "0"));
	}

	private boolean isCheckProperty() {
		return Boolean.parseBoolean(getProperty(Constants.CHECK_PROPERTY,
				"false"));
	}

	private boolean isCheckOnlyProperty() {
		return Boolean.parseBoolean(getProperty(Constants.CHECK_ONLY_PROPERTY,
				"false"));
	}

	private String getOutputFilenameProperty() {
		return getProperty(Constants.OUTPUT_FILENAME_PROPERTY, hostname + "-"
				+ Constants.DEFAULT_OUTPUT_FILENAME_POSTFIX);
	}

	private String getReportFilenameProperty() {
		return getProperty(Constants.REPORT_FILENAME_PROPERTY, "");
	}

	private String getOperationsFilenameProperty() {
		return getProperty(Constants.OPERATIONS_FILENAME_PROPERTY, hostname
				+ "-" + Constants.DEFAULT_OPERATIONS_FILENAME_POSTFIX);
	}

	private String getStatisticsFilenameProperty() {
		return getProperty(Constants.STATISTICS_FILENAME_PROPERTY, hostname
				+ "-" + Constants.DEFAULT_STATISTICS_FILENAME_POSTFIX);
	}

	private CAUSAL_DEPENDENCY_POLICY getCausalDependencyPolicyProperty() {
		return CAUSAL_DEPENDENCY_POLICY.valueOf(getProperty(
				Constants.CAUSAL_DEPENDENCY_PROPERTY,
				Constants.DEFAULT_CAUSAL_DEPENDENCY_POLICY));
	}

	private OPERATIONS_COMMUTATIVITY_POLICY getOperatonsCommutativityPolicyProperty() {
		return OPERATIONS_COMMUTATIVITY_POLICY.valueOf(getProperty(
				Constants.OPERATIONS_COMMUTATIVITY_PROPERTY,
				Constants.DEFAULT_OPERATIONS_COMMUTATIVITY_POLICY));
	}

	private boolean isExecuteTraceProperty() {
		return Boolean.parseBoolean(getProperty(
				Constants.EXECUTE_TRACE_PROPERTY, ""));
	}

	public TreedsProperties parse() {
		String concreteAdapterClass = "";
		String nodeName = "";
		String nodeIP = "";
		String documentLocation = null;
		int numberOfOperations = 0;
		boolean check = false;
		boolean checkOnly = false;
		String outputFilename = null;
		String reportFilename = null;
		String operationsFilename = null;
		String statisticsFilename = null;
		CAUSAL_DEPENDENCY_POLICY causalDependencyPolicy = null;
		OPERATIONS_COMMUTATIVITY_POLICY operationsCommutativityPolicy = null;
		boolean executeTrace = false;

		concreteAdapterClass = getConcreteAdapterClassProperty();
		nodeName = getNodeNameProperty();
		nodeIP = getNodeIPProperty();
		documentLocation = getDocumentLocationProperty();
		numberOfOperations = getNumberOfOperationsProperty();
		check = isCheckProperty();
		checkOnly = isCheckOnlyProperty();
		outputFilename = getOutputFilenameProperty();
		reportFilename = getReportFilenameProperty();
		operationsFilename = getOperationsFilenameProperty();
		statisticsFilename = getStatisticsFilenameProperty();
		causalDependencyPolicy = getCausalDependencyPolicyProperty();
		operationsCommutativityPolicy = getOperatonsCommutativityPolicyProperty();
		executeTrace = isExecuteTraceProperty();

		return new TreedsProperties(concreteAdapterClass, nodeName, nodeIP,
				documentLocation, numberOfOperations, check, checkOnly,
				outputFilename, reportFilename, operationsFilename,
				statisticsFilename, causalDependencyPolicy,
				operationsCommutativityPolicy, executeTrace);
	}
}
