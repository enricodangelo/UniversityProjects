/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.inria.gforge.treeds.treetest;

import fr.inria.gforge.telex.User;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import fr.inria.gforge.treeds.telex.ITreeds;
import fr.inria.gforge.treeds.telex.TreedsAbstractAdapter;
import fr.inria.gforge.treeds.action.CreateAction;
import fr.inria.gforge.treeds.action.MergeAction;
import fr.inria.gforge.treeds.action.RemoveAction;
import fr.inria.gforge.treeds.action.SplitAction;
import fr.inria.gforge.treeds.check.Statistics;
import fr.inria.gforge.treeds.utils.Constants;
import fr.inria.gforge.treeds.utils.TreedsProperties;
import fr.inria.gforge.treeds.utils.TreedsPropertiesParser;

/**
 * 
 * @author edangelo
 */
public class Test {

	private static String prefix;
	private static ITreeds treedsAdapter;
	private static Random random = new Random();
	private static TreedsProperties treedsProperties;

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) {
		TreedsPropertiesParser propertiesParser = new TreedsPropertiesParser(
				args);
		treedsProperties = propertiesParser.parse();
		prefix = treedsProperties.getNodeName();

		// gives time to get all sites up
		System.out.println("Waiting to give time to all sites to be up.");
		try {
			Thread.sleep(20 * 1000);
		} catch (InterruptedException ex) {
			Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
		}

		if (!treedsProperties.isCheckOnly()) {
			try {
				treedsAdapter = (TreedsAbstractAdapter) Class.forName(
						treedsProperties.getConcreteAdapterClass())
						.newInstance();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				System.exit(1);
			} catch (InstantiationException e) {
				e.printStackTrace();
				System.exit(1);
			} catch (IllegalAccessException e) {
				e.printStackTrace();
				System.exit(1);
			}

			treedsAdapter.setProperties(treedsProperties);

			System.out.println("Starting execution.");
			treedsAdapter.start();

			if (treedsProperties.isExecuteTrace()) {
				readOperations(treedsProperties.getOperationsFilename());
			} else {
				generateOperations(treedsProperties.getOperationsFilename(),
						treedsProperties.getNumberOfOperations());
			}

			// gives time to get all operations.
			System.out.println("Waiting to give time to all sites to get all operations.");
			try {
				Thread.sleep((int)(2 * 60 * 1000));
			} catch (InterruptedException ex) {
				Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null,
						ex);
			}

			/* terminates the threads */
			treedsAdapter.exit();
			/* closes the Telex document */
			treedsAdapter.closeDocument();
			/* writes the statistics about the execution */
			Statistics.getInstance().writeStatistics(
					treedsProperties.getStatisticsFilename());
		}

		System.out.println(User.getInvokingUser().getName()
				+ ": execution finished.");
		System.exit(0);
	}

	public static LinkedList<String> getUsedIDs() {
		return treedsAdapter.getUsedIDs();
	}

	private static void generateOperations(String operationsFilename,
			int numberOfOperations) {
		try {
			boolean firstOperation = true;
			ArrayList<String> oldOperations = new ArrayList<String>();
			BufferedWriter writer = new BufferedWriter(new FileWriter(
					operationsFilename));
			String operationString = "";

			if (treedsProperties.isCheck()) {
				Statistics.getInstance().setOperationSubmissionStartTime(
						System.currentTimeMillis());
			}

			while (numberOfOperations > 0) {
				Constants.Operaitons operation = Constants.Operaitons.values()[(int) Math
						.floor(Constants.Operaitons.values().length
								* random.nextDouble())];

				switch (operation) {
				case CREATE:
					operationString = randomCreateString();
					break;
				case REMOVE:
					operationString = randomRemoveString();
					break;
				case MERGE:
					operationString = randomMergeString();
					break;
				case SPLIT:
					operationString = randomSplitString();
					break;
				}

				if ((!operationString.isEmpty())
						&& (!oldOperations.contains(operationString))) {
					// check if submitting the first operation
					if (treedsProperties.isCheck() && firstOperation) {
						firstOperation = false;
						Statistics.getInstance().setExecutionStartTime(
								System.currentTimeMillis());
					}
					executeOperations(operationString);
					writer.write(operationString);
					numberOfOperations--;
					oldOperations.add(operationString);
				}
			}

			if (treedsProperties.isCheck()) {
				Statistics.getInstance().setOperationSubmissionEndTime(
						System.currentTimeMillis());
			}

			writer.write(Constants.END_OPERATIONS + "\n");
			writer.close();
		} catch (IOException ex) {
			Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	private static void readOperations(String operationsFilename) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(
					operationsFilename));
			String line = reader.readLine();

			while (!line.equals(Constants.END_OPERATIONS)) {
				executeOperations(line);
			}

			reader.close();
		} catch (IOException ex) {
			Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	private static void executeOperations(String operationString) {
		String operationPart[];
		String nodeID;
		String newParentID;

		try {
			Thread.sleep((long)(1000 * 0.1));
		} catch (InterruptedException e) {}
		
		if (!operationString.isEmpty()) {
			if (operationString.startsWith(CreateAction.class
					.getCanonicalName())) {
				operationPart = operationString.split(" ");
				nodeID = operationPart[1].trim();

				treedsAdapter.createTree(nodeID);
			} else if (operationString.startsWith(RemoveAction.class
					.getCanonicalName())) {
				operationPart = operationString.split(" ");
				nodeID = operationPart[1].trim();

				treedsAdapter.remove(nodeID);
			} else if (operationString.startsWith(MergeAction.class
					.getCanonicalName())) {
				operationPart = operationString.split(" ");
				nodeID = operationPart[1].trim();
				newParentID = operationPart[2].trim();

				treedsAdapter.merge(nodeID, newParentID);
			} else if (operationString.startsWith(SplitAction.class
					.getCanonicalName())) {
				operationPart = operationString.split(" ");
				nodeID = operationPart[1].trim();

				treedsAdapter.splitNode(nodeID);
			} else {
				System.err.println("ERROR: operations file malformed.");
				System.exit(1);
			}
		}
	}

	private static String randomCreateString() {
		String operation = "";
		String nodeID = generateNodeID();

		if (treedsAdapter.testCreatePrecondition(nodeID)) {
			operation = CreateAction.class.getCanonicalName() + " " + nodeID
					+ "\n";
		}

		return operation;
	}

	private static String randomRemoveString() {
		String operation = "";
		if (!getUsedIDs().isEmpty()) {
			int index = (int) Math.floor(getUsedIDs().size()
					* random.nextDouble());
			try {
				String nodeID = getUsedIDs().get(index);

				if (treedsAdapter.testRemovePrecondition(nodeID)) {
					operation = RemoveAction.class.getCanonicalName() + " "
							+ nodeID + "\n";
				}
			} catch (IndexOutOfBoundsException ex) {
				return "";
			}
		}

		return operation;
	}

	private static String randomMergeString() {
		String operation = "";
		if (getUsedIDs().size() > 1) {
			int index1, index2;

			do {
				index1 = (int) Math.floor(getUsedIDs().size()
						* random.nextDouble());
				index2 = (int) Math.floor(getUsedIDs().size()
						* random.nextDouble());
			} while (index1 == index2);

			try {
				String nodeID = getUsedIDs().get(index1);
				String newParentID = getUsedIDs().get(index2);

				if (treedsAdapter.testMergePrecondition(nodeID, newParentID)) {
					operation = MergeAction.class.getCanonicalName() + " "
							+ nodeID + " " + newParentID + "\n";
				}
			} catch (IndexOutOfBoundsException ex) {
				return "";
			}
		}

		return operation;
	}

	private static String randomSplitString() {
		String operation = "";
		if (!getUsedIDs().isEmpty()) {
			int index = (int) Math.floor(getUsedIDs().size()
					* random.nextDouble());
			try {
				String nodeID = getUsedIDs().get(index);

				if (treedsAdapter.testSplitNodePrecondition(nodeID)) {
					operation = SplitAction.class.getCanonicalName() + " "
							+ nodeID + "\n";
				}
			} catch (IndexOutOfBoundsException ex) {
				return "";
			}
		}

		return operation;
	}

	private static String generateNodeID() {
		String id = "";

		id += System.currentTimeMillis();

		return prefix + "-" + id;
	}
}
