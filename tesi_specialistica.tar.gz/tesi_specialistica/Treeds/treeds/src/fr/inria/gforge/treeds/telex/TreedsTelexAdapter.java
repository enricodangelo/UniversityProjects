/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.inria.gforge.treeds.telex;

import fr.inria.gforge.telex.ClosedDocumentException;
import fr.inria.gforge.telex.Document;
import fr.inria.gforge.telex.IncompatibleOpenModeException;
import fr.inria.gforge.telex.InvalidFragmentException;
import fr.inria.gforge.telex.Telex;
import fr.inria.gforge.telex.UnknownDocumentTypeException;
import fr.inria.gforge.telex.application.Fragment;
import fr.inria.gforge.telex.application.ProcessingParameters;
import fr.inria.gforge.telex.scheduling.UnsoundGraphException;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * 
 * @author edangelo
 */
public class TreedsTelexAdapter extends TreedsAbstractAdapter {
	/* Telex instance */
	private Telex telex;
	/* Telex Document instance */
	private Document treedsDocument;

	@Override
	public void startTelex(ProcessingParameters parameters) {
		telex = Telex.getInstance(this, parameters);
	}

	@Override
	public void concreteOpenDocument() {
		try {
			treedsDocument = telex.openDocument(getDocumentLocation(),
					Telex.OpenMode.READ_WRITE);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnknownDocumentTypeException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void startThreads() {
	}

	public void concreteCloseDocument() {
		try {
			treedsDocument.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void exit() {
	}

	@Override
	public void concreteSubmitFragment(Fragment fragment) {
		try {
			treedsDocument.addFragment(fragment);
		} catch (ClosedDocumentException e) {
			e.printStackTrace();
		} catch (IncompatibleOpenModeException e) {
			e.printStackTrace();
		} catch (InvalidFragmentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (UnsoundGraphException e) {
			e.printStackTrace();
		}
	}
}
