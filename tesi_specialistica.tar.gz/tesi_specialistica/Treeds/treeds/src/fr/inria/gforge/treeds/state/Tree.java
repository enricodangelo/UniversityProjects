/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.inria.gforge.treeds.state;

import java.io.Serializable;
import java.util.Iterator;
import java.util.TreeSet;
import fr.inria.gforge.treeds.utils.Constants;

/**
 * 
 * @author edangelo
 */
public class Tree implements Serializable, Comparable<Tree> {
	private static final long serialVersionUID = -2716773739041841523L;
	/* unique ID of the tree */
	private String id;
	/* tree ID of the parent of this tree */
	private String parent;
	/* list of tree IDs of the children */
	private TreeSet<String> children;

	public String getID() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	public boolean hasParent() {
		if (!parent.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public TreeSet<String> getChildren() {
		return children;
	}

	public Tree(String id) {
		this.id = id;
		parent = "";
		children = new TreeSet<String>();
	}

	public void removeChild(String nodeID) {
		children.remove(nodeID);
	}

	public boolean merge(Tree node) {
		node.setParent(this.getID());
		if (!children.contains(node.getID())) {
			children.add(node.getID());
		}

		return true;
	}

	@Override
	public String toString() {
		String result = "";

		result += id + Constants.FIELD_DELIMITER;

		if (parent.isEmpty()) {
			result += Constants.EMPTY;
		} else {
			result += parent;
		}

		result += Constants.FIELD_DELIMITER;

		if (!children.isEmpty()) {
			for (Iterator<String> it = children.iterator(); it.hasNext();) {
				String child = it.next();

				result += child;

				if (it.hasNext()) {
					result += Constants.CHILD_DELIMITER;
				}
			}
		} else {
			result += Constants.EMPTY;
		}

		return result;
	}

	public int compareTo(Tree other) {
		return id.compareTo(other.getID());
	}
}
