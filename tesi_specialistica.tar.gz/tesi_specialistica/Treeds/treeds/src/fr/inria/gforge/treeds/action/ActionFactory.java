package fr.inria.gforge.treeds.action;

import fr.inria.gforge.treeds.utils.Constants;

public class ActionFactory {

	public static TreeAbstractAction getAction(String method, Object[] args) {
		TreeAbstractAction result = null;

		if (method.equals(Constants.CREATEACTION_METHODNAME)) {
			result = new CreateAction((String) args[0]);
		} else if (method.equals(Constants.REMOVEACTION_METHODNAME)) {
			result = new RemoveAction((String) args[0]);
		} else if (method.equals(Constants.MERGEACTION_METHODNAME)) {
			result = new MergeAction((String) args[0], (String) args[1]);
		} else if (method.equals(Constants.SPLITACTION_METHODNAME)) {
			result = new SplitAction((String) args[0]);
		}

		return result;
	}
}
