package fr.inria.gforge.treeds.telex.responseParser;

import java.util.ArrayList;

public class TelexResponse {

	private String name;
	private int statusCode;
	private String description;
	private String cause;
	private ArrayList<ResponseSchedule> schedules;
	private ArrayList<GetConstraintsPair> getConstraints;

	public TelexResponse(String name, int statusCode, String description,
			String cause, ArrayList<ResponseSchedule> schedules,
			ArrayList<GetConstraintsPair> getConstraints) {
		super();
		this.name = name;
		this.statusCode = statusCode;
		this.description = description;
		this.schedules = schedules;
		this.getConstraints = getConstraints;
	}

	public String getName() {
		return name;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public String getDescription() {
		return description;
	}

	public String getCause() {
		return cause;
	}

	public ArrayList<ResponseSchedule> getSchedules() {
		return schedules;
	}

	public ArrayList<GetConstraintsPair> getGetConstraints() {
		return getConstraints;
	}

	public String toString() {
		String string = "";

		string += "name: " + name + "\n";
		string += "statusCode: " + statusCode + "\n";
		string += "description: " + description + "\n";
		string += "cause: " + cause + "\n";
		string += schedules.toString();
		string += getConstraints.toString();

		return string;
	}
}