package fr.inria.gforge.treeds.telex.responseParser;

import java.util.ArrayList;

import fr.inria.gforge.treeds.action.TreeAction;

public class ResponseSchedule {
	private String id;
	private String docID;
	private ArrayList<TreeAction> treeActions;
	private ArrayList<TreeAction> nonTreeActions;

	public ResponseSchedule(String id, String docID,
			ArrayList<TreeAction> actions, ArrayList<TreeAction> nonActions) {
		super();
		this.id = id;
		this.docID = docID;
		this.treeActions = actions;
		this.nonTreeActions = nonActions;
	}

	public String getId() {
		return id;
	}

	public String getDocID() {
		return docID;
	}

	public ArrayList<TreeAction> getActions() {
		return treeActions;
	}

	public ArrayList<TreeAction> getNonActions() {
		return nonTreeActions;
	}

	public String toString() {
		String string = "";

		string += "id: " + id + "\n";
		string += "docID: " + docID + "\n";
		string += "actions:" + "\n";

		for (TreeAction action : treeActions) {
			string += action + "\n";
		}
		string += "nonActions:" + "\n";
		for (TreeAction nonAction : nonTreeActions) {
			string += nonAction + "\n";
		}
		return string;
	}
}
