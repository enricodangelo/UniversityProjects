/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.inria.gforge.treeds.action;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import fr.inria.gforge.telex.application.Action;
import fr.inria.gforge.telex.util.FileUtils;
import fr.inria.gforge.treeds.utils.Constants;

/**
 * 
 * @author edangelo
 * 
 *         Common root to all Action classes
 */
public class TreeAction extends Action {
	private static final long serialVersionUID = 2514917113898826799L;
	private TreeAbstractAction specificAction;
	private String submitterNode;
	private boolean stable = false;

	public TreeAction() {
	}

	public TreeAction(int[] keyset, TreeAbstractAction specificAction,
			String submitterNode, boolean stable) {
		super(keyset);
		this.specificAction = specificAction;
		this.submitterNode = submitterNode;
		this.stable = stable;
	}

	public TreeAbstractAction getSpecificAction() {
		return specificAction;
	}

	public String getSubmitterNode() {
		return submitterNode;
	}
	
	public boolean isActionStable() {
		return stable;
	}

	@Override
	public void write(DataOutput out) throws IOException {
		super.write(out);

		FileUtils.writeObject(Constants.DESCRIPTION_FIELD,
				specificAction.getMethodName(), out);
		FileUtils.writeObject(Constants.ARGS_FIELD, specificAction.getArgs(),
				out);
	}

	@Override
	public void read(DataInput in) throws IOException {
		super.read(in);

                String method = (String) FileUtils.readObject(Constants.DESCRIPTION_FIELD, in);
		Object[] args = (Object[]) FileUtils.readObject(Constants.ARGS_FIELD, in);
		
		specificAction = ActionFactory.getAction(method, args);
	}

	@Override
	public String toString() {
		String result;

		if (specificAction != null) {
			result = specificAction.toString() + "\n";
			result += "stable = " + stable + "\n";
		} else {
			result = super.toString();
		}

		return result;
	}
}
