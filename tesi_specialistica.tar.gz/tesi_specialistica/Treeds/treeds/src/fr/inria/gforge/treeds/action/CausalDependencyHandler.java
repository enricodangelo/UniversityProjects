package fr.inria.gforge.treeds.action;

import java.util.HashMap;
import java.util.Map;

import fr.inria.gforge.telex.application.Constraint;
import fr.inria.gforge.telex.application.Fragment;
import fr.inria.gforge.treeds.utils.Constants.CAUSAL_DEPENDENCY_POLICY;

public class CausalDependencyHandler {
	/* tells the application wich causal dependency policy use */
	private CAUSAL_DEPENDENCY_POLICY causalDependencyPolicy;
	/* keeps trak of the lastest action that modified each object */
	private Map<String, TreeAction> latestActions;
	/* keeps trak of the lastest action */
	private TreeAction latestAction;
	/* keeps trak of the lastest local action that modified each object */
	private Map<String, TreeAction> latestActionsLocal;
	/* keeps trak of the lastest local action */
	private TreeAction latestActionLocal;

	public CausalDependencyHandler(
			CAUSAL_DEPENDENCY_POLICY causalDependencyPolicy) {
		this.causalDependencyPolicy = causalDependencyPolicy;
		latestActions = new HashMap<String, TreeAction>();
		latestAction = null;
		latestActionsLocal = new HashMap<String, TreeAction>();
		latestActionLocal = null;
	}

	public Fragment setCausalDependency(TreeAction action) {
		Fragment constraintFragment = new Fragment();
		constraintFragment.add(action);

		switch (causalDependencyPolicy) {
		case EVERY_OPERATION:
			everyOperationCausalDependant(constraintFragment, action);
			break;
		case EVERY_OPERATION_ON_SAME_OBJECT:
			everyOperationOnSameObjectCausalDependant(constraintFragment,
					action);
			break;
		}

		return constraintFragment;
	}

	/*
	 * Clears the list of the latest action(s). Only the local actions will
	 * remain
	 */
	public void clearLatestActionRemote() {
		latestAction = latestActionLocal;
		latestActions = latestActionsLocal;
	}

	public void addLatestAction(TreeAction action) {
		switch (causalDependencyPolicy) {
		case EVERY_OPERATION:
			latestAction = action;
			if (action.isLocal()) {
				latestActionLocal = action;
			}
			break;
		case EVERY_OPERATION_ON_SAME_OBJECT:
			String[] modifiedObjects = action.getSpecificAction()
					.getModifiedObjects();
			for (String modifiedObject : modifiedObjects) {
				latestActions.put(modifiedObject, action);
				if (action.isLocal()) {
					latestActionsLocal.put(modifiedObject, action);
				}
			}
			break;
		}
	}

	private void everyOperationCausalDependant(Fragment constraintFragment,
			TreeAction action) {
		/*
		 * causality constraint between this operation and the latest issued
		 */
		if (latestAction != null) {
			if (!(latestAction.getSpecificAction() instanceof RemoveAction)) {
				constraintFragment.add(new Constraint(latestAction,
						Constraint.Type.NOT_AFTER, action));
				constraintFragment.add(new Constraint(latestAction,
						Constraint.Type.ENABLES, action));
			}
		}

		addLatestAction(action);
	}

	private void everyOperationOnSameObjectCausalDependant(
			Fragment constraintFragment, TreeAction action) {
		/*
		 * causality constraint between operations that modifies the same object
		 */
		String[] modifiedObjects = action.getSpecificAction()
				.getModifiedObjects();
		for (String modifiedObject : modifiedObjects) {

			TreeAction latestAction = latestActions.get(modifiedObject);
			if (latestAction != null) {
				if (!(latestAction.getSpecificAction() instanceof RemoveAction)) {
					constraintFragment.add(new Constraint(latestAction,
							Constraint.Type.NOT_AFTER, action));
					constraintFragment.add(new Constraint(latestAction,
							Constraint.Type.ENABLES, action));
				}
			}
		}

		addLatestAction(action);
	}
}
