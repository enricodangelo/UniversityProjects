package fr.inria.gforge.treeds.telex.responseParser;

import fr.inria.gforge.treeds.action.TreeAction;

public class GetConstraintsPair {
	private TreeAction action1;
	private TreeAction action2;

	public GetConstraintsPair(TreeAction action1, TreeAction action2) {
		super();
		this.action1 = action1;
		this.action2 = action2;
	}

	public TreeAction getAction1() {
		return action1;
	}

	public TreeAction getAction2() {
		return action2;
	}
}
