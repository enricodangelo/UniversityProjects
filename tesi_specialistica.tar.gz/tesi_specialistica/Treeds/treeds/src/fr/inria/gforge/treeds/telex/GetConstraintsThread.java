package fr.inria.gforge.treeds.telex;

import java.util.ArrayList;

import fr.inria.gforge.telex.application.Fragment;
import fr.inria.gforge.treeds.telex.responseParser.GetConstraintsPair;
import fr.inria.gforge.treeds.telex.responseParser.TelexResponse;
import fr.inria.gforge.treeds.utils.Constants;

public class GetConstraintsThread extends Thread {

	TreedsTelexMobileAdapter treedsTelexMobileAdapter;

	public GetConstraintsThread(
			TreedsTelexMobileAdapter treedsTelexMobileAdapter) {
		this.treedsTelexMobileAdapter = treedsTelexMobileAdapter;
	}

	@Override
	public void run() {
		System.out.println("Starting getConstraintThread.");

		while (treedsTelexMobileAdapter.isRunning()) {
			try {
				TelexResponse telexResponse = treedsTelexMobileAdapter.getConstraints();

				if (telexResponse != null) {
					if (telexResponse.getStatusCode() == Constants.STATUSCODE_OK) {
						if (telexResponse.getName().equals(Constants.GETCONSTRAINT_RETURN_COMMAND)) {
							ArrayList<GetConstraintsPair> getConstraints = telexResponse.getGetConstraints();

							for (GetConstraintsPair getConstraintsPair : getConstraints) {
								Fragment fragment = treedsTelexMobileAdapter.getConstraintChecker().getConstraints(
										getConstraintsPair.getAction1(),
										getConstraintsPair.getAction2());

								treedsTelexMobileAdapter.concreteSubmitFragment(fragment);
							}
						} else {
							System.err.println("telexResponse.getName() != " + Constants.GETCONSTRAINT_RETURN_COMMAND + ": "
									+ telexResponse.getName());
						}
					}
				}

				/* repeats the task every minute */
				Thread.sleep(5 * 1000);
			} catch (InterruptedException ex) {
			}
		}

		System.out.println("Stopping getConstraintThread.");
	}
}