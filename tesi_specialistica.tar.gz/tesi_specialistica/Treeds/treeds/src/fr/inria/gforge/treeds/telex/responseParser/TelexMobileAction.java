package fr.inria.gforge.treeds.telex.responseParser;

import fr.inria.gforge.treeds.action.CreateAction;
import fr.inria.gforge.treeds.action.MergeAction;
import fr.inria.gforge.treeds.action.RemoveAction;
import fr.inria.gforge.treeds.action.SplitAction;
import fr.inria.gforge.treeds.action.TreeAction;

public class TelexMobileAction {
	private String actionDescription;
	private String actionID;

	public TelexMobileAction(String actionDescription, String actionID) {
		super();
		this.actionDescription = actionDescription;
		this.actionID = actionID;
	}

	public String getActionDescription() {
		return actionDescription;
	}

	public String getActionID() {
		return actionID;
	}
	
	public static TreeAction toTreeAction(String actionDescription,
			String actionID) {
		TreeAction treeAction = null;
		boolean stable = false;

		String[] actionParts = actionDescription.split(":");
		String actionType = actionParts[0];
		String submitterNode = actionParts[1];
		String nodeID = actionParts[2];

		submitterNode = submitterNode.substring(0,
				submitterNode.lastIndexOf("-"));

		if (actionDescription.endsWith("+")) {
			stable = true;
		}
        if (actionDescription.endsWith("-")) {
			stable = true;
        }
        
		if (actionType.equals("create")) {
			if ((nodeID.endsWith("+")) || (nodeID.endsWith("-"))) {
				nodeID = nodeID.substring(0, nodeID.length() - 1);
			}
			treeAction = new TreeAction(new int[] { nodeID.hashCode() },
					new CreateAction(nodeID), submitterNode, stable);
		} else if (actionType.equals("remove")) {
			if ((nodeID.endsWith("+")) || (nodeID.endsWith("-"))) {
				nodeID = nodeID.substring(0, nodeID.length() - 1);
			}
			treeAction = new TreeAction(new int[] { nodeID.hashCode() },
					new RemoveAction(nodeID), submitterNode, stable);
		} else if (actionType.equals("merge")) {
			String newParentID = actionParts[3];
			if ((nodeID.endsWith("+")) || (nodeID.endsWith("-"))) {
				nodeID = nodeID.substring(0, nodeID.length() - 1);
			}
			if ((newParentID.endsWith("+")) || (newParentID.endsWith("-"))) {
				nodeID = nodeID.substring(0, nodeID.length() - 1);
			}
			treeAction = new TreeAction(new int[] { nodeID.hashCode() },
					new MergeAction(nodeID, newParentID), submitterNode, stable);
		} else if (actionType.equals("split")) {
			if ((nodeID.endsWith("+")) || (nodeID.endsWith("-"))) {
				nodeID = nodeID.substring(0, nodeID.length() - 1);
			}
			treeAction = new TreeAction(new int[] { nodeID.hashCode() },
					new SplitAction(nodeID), submitterNode, stable);
		}

		return treeAction;
	}

	public String toString() {
		String string = "";

		string += "actionDescription: " + actionDescription + "\n";
		string += "actionID: " + actionID;

		return string;
	}
}