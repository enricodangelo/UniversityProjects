/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.inria.gforge.treeds.action;

import fr.inria.gforge.telex.application.Constraint;
import fr.inria.gforge.telex.application.Fragment;
import fr.inria.gforge.treeds.utils.Constants;

/**
 * 
 * @author edangelo
 * 
 *         Splits a node WITH root to a new node without root
 */
public class SplitAction extends TreeAbstractAction {
	private static final long serialVersionUID = 713262563911277681L;
	private String nodeID;

	public String getNodeID() {
		return nodeID;
	}

	public void setNodeID(String nodeID) {
		this.nodeID = nodeID;
	}

	@Override
	public Object[] getArgs() {
		return new Object[] { nodeID };
	}

	@Override
	public String[] getModifiedObjects() {
		return new String[] { nodeID };
	}

	public SplitAction(String nodeID) {
		setMethodName(Constants.SPLITACTION_METHODNAME);
		this.nodeID = nodeID;
	}

	@Override
	public String toString() {
		String result = getClass().getCanonicalName() + " ";

		result += nodeID;

		return result;
	}

	@Override
	public Fragment getSemanticConstraints(TreeAction a, TreeAction b) {
		Fragment fragment = new Fragment();

		if (b.getSpecificAction() instanceof CreateAction) {
			CreateAction createAction = (CreateAction) b.getSpecificAction();

			if (createAction.getNodeID().equals(nodeID)) {
				Constraint constraint1 = new Constraint(b,
						Constraint.Type.ENABLES, a);
				Constraint constraint2 = new Constraint(b,
						Constraint.Type.NOT_AFTER, a);
				fragment.add(constraint1);
				fragment.add(constraint2);
			}
		} else if (b.getSpecificAction() instanceof RemoveAction) {
			RemoveAction removeAction = (RemoveAction) b.getSpecificAction();

			if (removeAction.getNodeID().equals(nodeID)) {
				Constraint constraint = new Constraint(a,
						Constraint.Type.NOT_AFTER, b);
				fragment.add(constraint);
			}
		} else if (b.getSpecificAction() instanceof MergeAction) {
			MergeAction mergeAction = (MergeAction) b.getSpecificAction();

			if (mergeAction.getNodeID().equals(nodeID)) {
				Constraint constraint = new Constraint(b,
						Constraint.Type.NON_COMMUTING, a);
				fragment.add(constraint);
			}
		} else if (b.getSpecificAction() instanceof SplitAction) {
			SplitAction splitAction = (SplitAction) b.getSpecificAction();

			if (splitAction.getNodeID().equals(nodeID)) {
				Constraint constraint = new Constraint(b,
						Constraint.Type.NON_COMMUTING, a);
				fragment.add(constraint);
			}
		}

		return fragment;
	}

	@Override
	public Fragment getAllNonCommutetiveConstraints(TreeAction a, TreeAction b) {
		Fragment fragment = new Fragment();

		Constraint constraint1 = new Constraint(b,
				Constraint.Type.NON_COMMUTING, a);
		fragment.add(constraint1);

		return fragment;
	}

	@Override
	public Fragment getSameObjectNonCommutativeConstraints(TreeAction a,
			TreeAction b) {
		Fragment fragment = new Fragment();

		if (b.getSpecificAction() instanceof CreateAction) {
			CreateAction createAction = (CreateAction) b.getSpecificAction();

			if (createAction.getNodeID().equals(nodeID)) {
				Constraint constraint1 = new Constraint(b,
						Constraint.Type.NON_COMMUTING, a);
				fragment.add(constraint1);
			}
		} else if (b.getSpecificAction() instanceof RemoveAction) {
			RemoveAction removeAction = (RemoveAction) b.getSpecificAction();

			if (removeAction.getNodeID().equals(nodeID)) {
				Constraint constraint1 = new Constraint(b,
						Constraint.Type.NON_COMMUTING, a);
				fragment.add(constraint1);
			}
		} else if (b.getSpecificAction() instanceof MergeAction) {
			MergeAction mergeAction = (MergeAction) b.getSpecificAction();

			if (mergeAction.getNodeID().equals(nodeID)) {
				if (!b.isCommitted()) {
					Constraint constraint1 = new Constraint(b,
							Constraint.Type.NON_COMMUTING, a);
					fragment.add(constraint1);
				}
			}
		} else if (b.getSpecificAction() instanceof SplitAction) {
			SplitAction splitAction = (SplitAction) b.getSpecificAction();

			if (splitAction.getNodeID().equals(nodeID)) {
				Constraint constraint1 = new Constraint(b,
						Constraint.Type.NON_COMMUTING, a);
				fragment.add(constraint1);
			}
		}

		return fragment;
	}
}
