package fr.inria.gforge.treeds.check;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import fr.inria.gforge.treeds.utils.Constants;

public class ReportWriter {
	private volatile static ReportWriter instance;
	private String reportFilename;
	private static XMLStreamWriter xmlStreamWriter;

	private ReportWriter() {
	}

	public void init(String reportFilename) {
		this.reportFilename = reportFilename;
		if (!this.reportFilename.isEmpty()) {
			try {
				xmlStreamWriter = XMLOutputFactory.newInstance()
						.createXMLStreamWriter(
								new BufferedWriter(new FileWriter(
										reportFilename)));
			} catch (XMLStreamException ex) {
				Logger.getLogger(ReportWriter.class.getName()).log(
						Level.SEVERE, null, ex);
			} catch (IOException ex) {
				Logger.getLogger(ReportWriter.class.getName()).log(
						Level.SEVERE, null, ex);
			}
		}
	}

	public void writeStartReport() {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.writeStartDocument();
				xmlStreamWriter.writeStartElement(Constants.XML_ROOT);
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void writeEndReport() {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.writeEndElement();
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void writeStartChedulerIteration() {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter
						.writeStartElement(Constants.XML_SCHEDULER_ITERATION);
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void writeEndSchedulerIteration() {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.writeEndElement();
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void writeStartScheduler(int schedulerNumber) {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.writeStartElement(Constants.XML_SCHEDULER);
				xmlStreamWriter.writeAttribute(
						Constants.XML_SCHEDULER_NUMBER_ATTR,
						Integer.toString(schedulerNumber));
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void writeEndScheduler() {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.writeEndElement();
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void writeStartState(int stateNumber, String appState) {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.writeStartElement(Constants.XML_STATE);
				xmlStreamWriter.writeAttribute(Constants.XML_STATE_NUMBER_ATTR,
						Integer.toString(stateNumber));
				xmlStreamWriter.writeCharacters(appState);
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void writeEndState() {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.writeEndElement();
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void writeStartAction(int actionNumber, String appAction) {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.writeStartElement(Constants.XML_ACTION);
				xmlStreamWriter.writeAttribute(
						Constants.XML_ACTION_NUMBER_ATTR,
						Integer.toString(actionNumber));
				xmlStreamWriter.writeCharacters(appAction);
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void writeEndAction() {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.writeEndElement();
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

	public void closeStream() {
		try {
			if (!this.reportFilename.isEmpty()) {
				xmlStreamWriter.flush();
				xmlStreamWriter.close();
			}
		} catch (XMLStreamException ex) {
			Logger.getLogger(ReportWriter.class.getName()).log(Level.SEVERE,
					null, ex);
		}
	}

}
