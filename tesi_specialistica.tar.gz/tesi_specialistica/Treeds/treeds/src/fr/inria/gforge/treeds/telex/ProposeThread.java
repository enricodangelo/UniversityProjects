package fr.inria.gforge.treeds.telex;

public class ProposeThread extends Thread {

	TreedsTelexMobileAdapter treedsTelexMobileAdapter;

	public ProposeThread(
			TreedsTelexMobileAdapter treedsTelexMobileAdapter) {
		this.treedsTelexMobileAdapter = treedsTelexMobileAdapter;
	}
	
	@Override
	public void run() {
		System.out.println("Starting ProposeThread.");

		while (treedsTelexMobileAdapter.isRunning()) {
			try {
				String latestScheduleID = treedsTelexMobileAdapter.getLatestScheduleID();

				if (!latestScheduleID.isEmpty()) {
					treedsTelexMobileAdapter.propose(treedsTelexMobileAdapter.getDocumentLocation(), latestScheduleID);
				}
				
				/* repeats the task every minute */
				Thread.sleep(5 * 1000);
			} catch (InterruptedException ex) {
			}
		}

		System.out.println("Stopping ProposeThread.");
	}
}
