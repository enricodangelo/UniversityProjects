package fr.inria.gforge.treeds.telex;

import fr.inria.gforge.treeds.telex.responseParser.TelexResponse;
import fr.inria.gforge.treeds.utils.Constants;

public class GetLastScheduleThread extends Thread {

	TreedsTelexMobileAdapter treedsTelexMobileAdapter;

	public GetLastScheduleThread(
			TreedsTelexMobileAdapter treedsTelexMobileAdapter) {
		this.treedsTelexMobileAdapter = treedsTelexMobileAdapter;
	}

	@Override
	public void run() {
		System.out.println("Starting getLastScheduleThread.");

		while (treedsTelexMobileAdapter.isRunning()) {
			try {
				TelexResponse telexResponse = treedsTelexMobileAdapter.getLastSchedule(treedsTelexMobileAdapter.getDocumentLocation());

				if (telexResponse != null) {
					if (telexResponse.getStatusCode() == Constants.STATUSCODE_OK) {
						if (telexResponse.getName().equals(Constants.GETLASTSCHEDULE_RETURN_COMMAND)) {
							treedsTelexMobileAdapter.execute(telexResponse.getSchedules());
						} else {
							System.err.println("telexResponse.getName() != " + Constants.GETLASTSCHEDULE_RETURN_COMMAND + ": "
									+ telexResponse.getName());
						}
					}
				}

				/* repeats the task every minute */
				Thread.sleep(5 * 1000);
			} catch (InterruptedException ex) {
			}
		}

		System.out.println("Stopping getLastScheduleThread.");
	}
}
