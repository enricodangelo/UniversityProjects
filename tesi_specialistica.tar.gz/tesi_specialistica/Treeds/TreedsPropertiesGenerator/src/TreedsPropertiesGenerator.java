import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TreedsPropertiesGenerator {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String dirName = "";
		String commonDirName = "/home/enrico/Dropbox/treeds_cluster_cs_test/nodes";
		//String concreteAdapter = "fr.inria.gforge.treeds.telex.TreedsTelexMobileAdapter";

		if (Constants.CS_NODES.length != Constants.CS_IPS.length) {
			System.out
					.println("Numero di nodi diverso da numero di undirizzi ip!!!!");
			System.exit(-1);
		}

		try {
			for (String nodeSize : Constants.NODES_SIZES) {
				for (String operationSize : Constants.OPERATIONS_SIZES) {
					for (String concreteAdapter : Constants.CONCRETE_ADAPTERS_CLASS_STRING) {
						for (String causalDependancyPolicy : Constants.CAUSAL_DEPENDENCY_POLICY_STRING) {
							for (String operationsCommutativityPolicy : Constants.OPERATIONS_COMMUTATIVITY_POLICY_STRING) {
								for (int i = 0; i < Constants.CS_NODES.length; i++) {
									String node = Constants.CS_NODES[i];
									String ip = Constants.CS_IPS[i];
									for (String run : Constants.RUNS) {
										BufferedWriter writer;

										if (((causalDependancyPolicy
												.equals(Constants.CAUSAL_DEPENDENCY_POLICY_STRING[0])) && (operationsCommutativityPolicy
												.equals(Constants.OPERATIONS_COMMUTATIVITY_POLICY_STRING[0])))
												|| ((causalDependancyPolicy
														.equals(Constants.CAUSAL_DEPENDENCY_POLICY_STRING[1])) && (operationsCommutativityPolicy
														.equals(Constants.OPERATIONS_COMMUTATIVITY_POLICY_STRING[1])))) {
											dirName = commonDirName
													+ File.separator
													+ node
													+ File.separator
													+ Constants.PROPERTIES_DIRECTORY;
											String fileName = nodeSize
													+ "_nodes"
													+ "-"
													+ operationSize
													+ "_operations"
													+ "-"
													+ concreteAdapter
													+ "-"
													+ causalDependancyPolicy
													+ "-"
													+ operationsCommutativityPolicy
													+ "-" + run;
											String outputFileName = "output"
												+ File.separator
												+ fileName
												+ "-"
												+ node;

											writer = new BufferedWriter(
													new FileWriter(dirName
															+ File.separator
															+ fileName + ".properties"));

											writer.write(Constants.CONCRETE_ADAPTER_CLASS_PROPERTY
													+ "="
													+ concreteAdapter
													+ "\n");
											writer.write(Constants.NODE_NAME_PROPERTY
													+ "=" + node + "\n");
											writer.write(Constants.NODE_IP_PROPERTY
													+ "=" + ip + "\n");
											writer.write(Constants.DOCUMENT_LOCATION_PROPERTY
													+ "="
													+ "/TelexDocuments/TreeSpace.dox"
													+ "\n");
											writer.write(Constants.NUMBER_OF_OPERATIONS_PROPERTY
													+ "="
													+ operationSize
													+ "\n");
											writer.write(Constants.CHECK_PROPERTY
													+ "=" + "true" + "\n");
											writer.write(Constants.CHECK_ONLY_PROPERTY
													+ "=" + "false" + "\n");
											writer.write(Constants.OUTPUT_FILENAME_PROPERTY
													+ "="
													+ outputFileName
													+ "-"
													+ "finalstate.txt" + "\n");
											writer.write(Constants.REPORT_FILENAME_PROPERTY
													+ "="
													+ outputFileName
													+ "-"
													+ "report.xml" + "\n");
											writer.write(Constants.OPERATIONS_FILENAME_PROPERTY
													+ "="
													+ outputFileName
													+ "-"
													+ "operations.txt" + "\n");
											writer.write(Constants.STATISTICS_FILENAME_PROPERTY
													+ "="
													+ outputFileName
													+ "-"
													+ "statistics.txt" + "\n");
											writer.write(Constants.CAUSAL_DEPENDENCY_PROPERTY
													+ "="
													+ causalDependancyPolicy
													+ "\n");
											writer.write(Constants.OPERATIONS_COMMUTATIVITY_PROPERTY
													+ "="
													+ operationsCommutativityPolicy
													+ "\n");
											if (run.equals("01")) {
												writer.write(Constants.EXECUTE_TRACE_PROPERTY
														+ "=" + "false" + "\n");
											} else {
												writer.write(Constants.EXECUTE_TRACE_PROPERTY
														+ "=" + "true" + "\n");
											}
											writer.close();
										}
									}
								}
							}
						}
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
